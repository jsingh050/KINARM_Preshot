function xcp = may23xcp

xcp.events     =  repmat(struct('id',{}, 'sampletime', {}, 'offset', {}), getNumEvents, 1 );
xcp.parameters =  repmat(struct('symbol',{}, 'size', {}, 'dtname', {}, 'baseaddr', {}), getNumParameters, 1 );
xcp.signals    =  repmat(struct('symbol',{}), getNumSignals, 1 );
xcp.models     =  cell(1,getNumModels);
    
xcp.models{1} = 'may23';
   
   
         
xcp.events(1).id         = 0;
xcp.events(1).sampletime = 0.00025;
xcp.events(1).offset     = 0.0;
         
xcp.events(2).id         = 1;
xcp.events(2).sampletime = 0.0005;
xcp.events(2).offset     = 0.0;
         
xcp.events(3).id         = 2;
xcp.events(3).sampletime = 0.001;
xcp.events(3).offset     = 0.0;
         
xcp.events(4).id         = 3;
xcp.events(4).sampletime = 0.1;
xcp.events(4).offset     = 0.0;
    
xcp.signals(1).symbol =  'may23_B.logging_enable';
    
xcp.signals(2).symbol =  'may23_B.event_code';
    
xcp.signals(3).symbol =  'may23_B.cursor_row';
    
xcp.signals(4).symbol =  'may23_B.cursor_state';
    
xcp.signals(5).symbol =  'may23_B.puck_row';
    
xcp.signals(6).symbol =  'may23_B.puck_state';
    
xcp.signals(7).symbol =  'may23_B.load_row';
    
xcp.signals(8).symbol =  'may23_B.barrier_target_row';
    
xcp.signals(9).symbol =  'may23_B.barrier_target_state';
    
xcp.signals(10).symbol =  'may23_B.start_target_row';
    
xcp.signals(11).symbol =  'may23_B.start_target_state';
    
xcp.signals(12).symbol =  'may23_B.goal_target_row';
    
xcp.signals(13).symbol =  'may23_B.goal_target_state';
    
xcp.signals(14).symbol =  'may23_B.preshot_area_row';
    
xcp.signals(15).symbol =  'may23_B.preshot_area_state';
    
xcp.signals(16).symbol =  'may23_B.e_Trial_Start';
    
xcp.signals(17).symbol =  'may23_B.e_Trial_End';
    
xcp.signals(18).symbol =  'may23_B.MatrixConcatenate';
    
xcp.signals(19).symbol =  'may23_B.Constant';
    
xcp.signals(20).symbol =  'may23_B.DataTypeConversion_j0';
    
xcp.signals(21).symbol =  'may23_B.DataTypeConversion1_pz';
    
xcp.signals(22).symbol =  'may23_B.Memory1_k';
    
xcp.signals(23).symbol =  'may23_B.Memory2_c';
    
xcp.signals(24).symbol =  'may23_B.Memory4';
    
xcp.signals(25).symbol =  'may23_B.readDigitaldiag';
    
xcp.signals(26).symbol =  'may23_B.readstatus';
    
xcp.signals(27).symbol =  'may23_B.Memory_d';
    
xcp.signals(28).symbol =  'may23_B.Memory1_l';
    
xcp.signals(29).symbol =  'may23_B.ArmOrientation';
    
xcp.signals(30).symbol =  'may23_B.M1orientation';
    
xcp.signals(31).symbol =  'may23_B.M2Orientation';
    
xcp.signals(32).symbol =  'may23_B.M1GearRatio';
    
xcp.signals(33).symbol =  'may23_B.M2GearRatio';
    
xcp.signals(34).symbol =  'may23_B.HasSecondaryEnc_h';
    
xcp.signals(35).symbol =  'may23_B.robottype_c';
    
xcp.signals(36).symbol =  'may23_B.robotversion_a';
    
xcp.signals(37).symbol =  'may23_B.torqueconstant';
    
xcp.signals(38).symbol =  'may23_B.isEP';
    
xcp.signals(39).symbol =  'may23_B.isHumanExo';
    
xcp.signals(40).symbol =  'may23_B.isNHPExo';
    
xcp.signals(41).symbol =  'may23_B.isClassicExo';
    
xcp.signals(42).symbol =  'may23_B.isUTSExo';
    
xcp.signals(43).symbol =  'may23_B.isPMAC';
    
xcp.signals(44).symbol =  'may23_B.isECAT';
    
xcp.signals(45).symbol =  'may23_B.robotRevision';
    
xcp.signals(46).symbol =  'may23_B.ArmOrientation_a';
    
xcp.signals(47).symbol =  'may23_B.M1orientation_i';
    
xcp.signals(48).symbol =  'may23_B.M2Orientation_a';
    
xcp.signals(49).symbol =  'may23_B.M1GearRatio_e';
    
xcp.signals(50).symbol =  'may23_B.M2GearRatio_n';
    
xcp.signals(51).symbol =  'may23_B.HasSecondaryEnc';
    
xcp.signals(52).symbol =  'may23_B.robottype';
    
xcp.signals(53).symbol =  'may23_B.robotversion';
    
xcp.signals(54).symbol =  'may23_B.torqueconstant_b';
    
xcp.signals(55).symbol =  'may23_B.isEP_f';
    
xcp.signals(56).symbol =  'may23_B.isHumanExo_k';
    
xcp.signals(57).symbol =  'may23_B.isNHPExo_l';
    
xcp.signals(58).symbol =  'may23_B.isClassicExo_j';
    
xcp.signals(59).symbol =  'may23_B.isUTSExo_n';
    
xcp.signals(60).symbol =  'may23_B.isPMAC_p';
    
xcp.signals(61).symbol =  'may23_B.isECAT_o';
    
xcp.signals(62).symbol =  'may23_B.robotRevision_p';
    
xcp.signals(63).symbol =  'may23_B.Product_g';
    
xcp.signals(64).symbol =  'may23_B.RateTransition_p';
    
xcp.signals(65).symbol =  'may23_B.RateTransition1_a';
    
xcp.signals(66).symbol =  'may23_B.RateTransition2_h';
    
xcp.signals(67).symbol =  'may23_B.AddTorques';
    
xcp.signals(68).symbol =  'may23_B.joint_loads_i';
    
xcp.signals(69).symbol =  'may23_B.LibraryPatchVersion';
    
xcp.signals(70).symbol =  'may23_B.LibraryVersion';
    
xcp.signals(71).symbol =  'may23_B.PauseType';
    
xcp.signals(72).symbol =  'may23_B.TaskVersion';
    
xcp.signals(73).symbol =  'may23_B.UsecustomTPsequence';
    
xcp.signals(74).symbol =  'may23_B.dlmbuildtime';
    
xcp.signals(75).symbol =  'may23_B.frame_of_reference_center';
    
xcp.signals(76).symbol =  'may23_B.xPCVersion';
    
xcp.signals(77).symbol =  'may23_B.Convert10';
    
xcp.signals(78).symbol =  'may23_B.Convert11';
    
xcp.signals(79).symbol =  'may23_B.Convert12';
    
xcp.signals(80).symbol =  'may23_B.Convert13';
    
xcp.signals(81).symbol =  'may23_B.Convert14';
    
xcp.signals(82).symbol =  'may23_B.Convert15';
    
xcp.signals(83).symbol =  'may23_B.Convert16';
    
xcp.signals(84).symbol =  'may23_B.Convert17';
    
xcp.signals(85).symbol =  'may23_B.Convert18';
    
xcp.signals(86).symbol =  'may23_B.Convert19_e';
    
xcp.signals(87).symbol =  'may23_B.Convert20';
    
xcp.signals(88).symbol =  'may23_B.Convert21';
    
xcp.signals(89).symbol =  'may23_B.Convert22';
    
xcp.signals(90).symbol =  'may23_B.Convert23';
    
xcp.signals(91).symbol =  'may23_B.Convert24';
    
xcp.signals(92).symbol =  'may23_B.Convert25';
    
xcp.signals(93).symbol =  'may23_B.Convert7';
    
xcp.signals(94).symbol =  'may23_B.Convert8';
    
xcp.signals(95).symbol =  'may23_B.Convert9';
    
xcp.signals(96).symbol =  'may23_B.Memory';
    
xcp.signals(97).symbol =  'may23_B.MinMax';
    
xcp.signals(98).symbol =  'may23_B.TPSelector';
    
xcp.signals(99).symbol =  'may23_B.out_m';
    
xcp.signals(100).symbol =  'may23_B.joint_loads';
    
xcp.signals(101).symbol =  'may23_B.sf_Ramp_Up_Down.scaling';
    
xcp.signals(102).symbol =  'may23_B.sf_Ramp_Up_Down1.scaling';
    
xcp.signals(103).symbol =  'may23_B.sf_Remove_NaNs_and_Inf.out';
    
xcp.signals(104).symbol =  'may23_B.out_p';
    
xcp.signals(105).symbol =  'may23_B.down_durationms';
    
xcp.signals(106).symbol =  'may23_B.down_durationms1';
    
xcp.signals(107).symbol =  'may23_B.up_durationms';
    
xcp.signals(108).symbol =  'may23_B.up_durationms1';
    
xcp.signals(109).symbol =  'may23_B.DataTypeConversion_gj';
    
xcp.signals(110).symbol =  'may23_B.DataTypeConversion1_ft';
    
xcp.signals(111).symbol =  'may23_B.Product_c';
    
xcp.signals(112).symbol =  'may23_B.Product1_j';
    
xcp.signals(113).symbol =  'may23_B.Reshape_b';
    
xcp.signals(114).symbol =  'may23_B.sf_Ramp_Up_Down_g.scaling';
    
xcp.signals(115).symbol =  'may23_B.sf_Ramp_Up_Down1_h.scaling';
    
xcp.signals(116).symbol =  'may23_B.sf_Remove_NaNs_and_Inf_d.out';
    
xcp.signals(117).symbol =  'may23_B.out';
    
xcp.signals(118).symbol =  'may23_B.y';
    
xcp.signals(119).symbol =  'may23_B.down_durationms_b';
    
xcp.signals(120).symbol =  'may23_B.up_durationms_h';
    
xcp.signals(121).symbol =  'may23_B.DataTypeConversion_pv';
    
xcp.signals(122).symbol =  'may23_B.DataTypeConversion1';
    
xcp.signals(123).symbol =  'may23_B.Product_i';
    
xcp.signals(124).symbol =  'may23_B.Product1';
    
xcp.signals(125).symbol =  'may23_B.Reshape_p';
    
xcp.signals(126).symbol =  'may23_B.Switch_h';
    
xcp.signals(127).symbol =  'may23_B.intarget_j';
    
xcp.signals(128).symbol =  'may23_B.ArraySelector_b';
    
xcp.signals(129).symbol =  'may23_B.Switch_i';
    
xcp.signals(130).symbol =  'may23_B.intarget_d';
    
xcp.signals(131).symbol =  'may23_B.ArraySelector';
    
xcp.signals(132).symbol =  'may23_B.Switch';
    
xcp.signals(133).symbol =  'may23_B.binary_file_names';
    
xcp.signals(134).symbol =  'may23_B.binary_files';
    
xcp.signals(135).symbol =  'may23_B.last_frame_ack';
    
xcp.signals(136).symbol =  'may23_B.last_perm_ack';
    
xcp.signals(137).symbol =  'may23_B.MatrixConcatenate_d';
    
xcp.signals(138).symbol =  'may23_B.MatrixConcatenate_d';
    
xcp.signals(139).symbol =  'may23_B.Convert';
    
xcp.signals(140).symbol =  'may23_B.Convert1';
    
xcp.signals(141).symbol =  'may23_B.Gain';
    
xcp.signals(142).symbol =  'may23_B.Memory_m';
    
xcp.signals(143).symbol =  'may23_B.MatrixConcatenate_d';
    
xcp.signals(144).symbol =  'may23_B.RateTransition2_p';
    
xcp.signals(145).symbol =  'may23_B.Receive_o1';
    
xcp.signals(146).symbol =  'may23_B.Receive_o2';
    
xcp.signals(147).symbol =  'may23_B.Unpack';
    
xcp.signals(148).symbol =  'may23_B.intarget_g';
    
xcp.signals(149).symbol =  'may23_B.ArraySelector_c';
    
xcp.signals(150).symbol =  'may23_B.Selector_n';
    
xcp.signals(151).symbol =  'may23_B.indisplay';
    
xcp.signals(152).symbol =  'may23_B.Selector_g';
    
xcp.signals(153).symbol =  'may23_B.intarget';
    
xcp.signals(154).symbol =  'may23_B.ArraySelector_m';
    
xcp.signals(155).symbol =  'may23_B.Selector';
    
xcp.signals(156).symbol =  'may23_B.sf_EmbeddedMATLABFunction_p.VCODE';
    
xcp.signals(157).symbol =  'may23_B.MatrixConcatenation1_k';
    
xcp.signals(158).symbol =  'may23_B.MatrixConcatenation1_k';
    
xcp.signals(159).symbol =  'may23_B.MatrixConcatenation1_k';
    
xcp.signals(160).symbol =  'may23_B.Selector_i';
    
xcp.signals(161).symbol =  'may23_B.sf_EmbeddedMATLABFunction_n.VCODE';
    
xcp.signals(162).symbol =  'may23_B.MatrixConcatenation1';
    
xcp.signals(163).symbol =  'may23_B.MatrixConcatenation1';
    
xcp.signals(164).symbol =  'may23_B.MatrixConcatenation1';
    
xcp.signals(165).symbol =  'may23_B.Selector_p';
    
xcp.signals(166).symbol =  'may23_B.sf_EmbeddedMATLABFunction_m.VCODE';
    
xcp.signals(167).symbol =  'may23_B.MatrixConcatenation1_g';
    
xcp.signals(168).symbol =  'may23_B.MatrixConcatenation1_g';
    
xcp.signals(169).symbol =  'may23_B.MatrixConcatenation1_g';
    
xcp.signals(170).symbol =  'may23_B.Selector_c';
    
xcp.signals(171).symbol =  'may23_B.sf_EmbeddedMATLABFunction_e.VCODE';
    
xcp.signals(172).symbol =  'may23_B.MatrixConcatenation1_e';
    
xcp.signals(173).symbol =  'may23_B.MatrixConcatenation1_e';
    
xcp.signals(174).symbol =  'may23_B.MatrixConcatenation1_e';
    
xcp.signals(175).symbol =  'may23_B.Selector_f';
    
xcp.signals(176).symbol =  'may23_B.sf_EmbeddedMATLABFunction_a.VCODE';
    
xcp.signals(177).symbol =  'may23_B.MatrixConcatenation1_a';
    
xcp.signals(178).symbol =  'may23_B.MatrixConcatenation1_a';
    
xcp.signals(179).symbol =  'may23_B.MatrixConcatenation1_a';
    
xcp.signals(180).symbol =  'may23_B.Selector_gx';
    
xcp.signals(181).symbol =  'may23_B.sf_EmbeddedMATLABFunction_h.VCODE';
    
xcp.signals(182).symbol =  'may23_B.MatrixConcatenation1_b';
    
xcp.signals(183).symbol =  'may23_B.MatrixConcatenation1_b';
    
xcp.signals(184).symbol =  'may23_B.MatrixConcatenation1_b';
    
xcp.signals(185).symbol =  'may23_B.Selector_d';
    
xcp.signals(186).symbol =  'may23_B.Abs';
    
xcp.signals(187).symbol =  'may23_B.Memory3';
    
xcp.signals(188).symbol =  'may23_B.Product_br';
    
xcp.signals(189).symbol =  'may23_B.SumofElements';
    
xcp.signals(190).symbol =  'may23_B.Switch_k';
    
xcp.signals(191).symbol =  'may23_B.puck_vcode_output';
    
xcp.signals(192).symbol =  'may23_B.force_scaling';
    
xcp.signals(193).symbol =  'may23_B.e_Puck_Stopped';
    
xcp.signals(194).symbol =  'may23_B.e_Puck_Hit';
    
xcp.signals(195).symbol =  'may23_B.force_vector';
    
xcp.signals(196).symbol =  'may23_B.DataTypeConversion_b';
    
xcp.signals(197).symbol =  'may23_B.PulseGenerator';
    
xcp.signals(198).symbol =  'may23_B.gethandmass';
    
xcp.signals(199).symbol =  'may23_B.getrectanglemass';
    
xcp.signals(200).symbol =  'may23_B.AnalogDataWidth';
    
xcp.signals(201).symbol =  'may23_B.RateTransition_e';
    
xcp.signals(202).symbol =  'may23_B.Subtract';
    
xcp.signals(203).symbol =  'may23_ConstB.Width';
    
xcp.signals(204).symbol =  'may23_B.voltagesOK';
    
xcp.signals(205).symbol =  'may23_B.DataTypeConversion_g';
    
xcp.signals(206).symbol =  'may23_B.RateTransition1';
    
xcp.signals(207).symbol =  'may23_B.RateTransition2';
    
xcp.signals(208).symbol =  'may23_ConstB.Width_g';
    
xcp.signals(209).symbol =  'may23_B.EventCodes';
    
xcp.signals(210).symbol =  'may23_B.NumberofEventCodes';
    
xcp.signals(211).symbol =  'may23_B.Subtract_i';
    
xcp.signals(212).symbol =  'may23_ConstB.Width_o';
    
xcp.signals(213).symbol =  'may23_B.bitfield';
    
xcp.signals(214).symbol =  'may23_B.touint';
    
xcp.signals(215).symbol =  'may23_B.touint1';
    
xcp.signals(216).symbol =  'may23_B.RateTransition_k';
    
xcp.signals(217).symbol =  'may23_ConstB.Width_m';
    
xcp.signals(218).symbol =  'may23_B.ButtonStatus';
    
xcp.signals(219).symbol =  'may23_B.CurrentBlockIndex';
    
xcp.signals(220).symbol =  'may23_B.CurrentBlockNumberinSet';
    
xcp.signals(221).symbol =  'may23_B.CurrentTPIndex';
    
xcp.signals(222).symbol =  'may23_B.CurrentTrialNumberinBlock';
    
xcp.signals(223).symbol =  'may23_B.CurrentTrialNumberinSet';
    
xcp.signals(224).symbol =  'may23_B.LastFrameAcknowledged';
    
xcp.signals(225).symbol =  'may23_B.LastFrameSent';
    
xcp.signals(226).symbol =  'may23_B.LastFrameSent1';
    
xcp.signals(227).symbol =  'may23_B.LoggingEnable';
    
xcp.signals(228).symbol =  'may23_B.RunStatus';
    
xcp.signals(229).symbol =  'may23_B.Servoupdatecount';
    
xcp.signals(230).symbol =  'may23_B.TaskControlButton';
    
xcp.signals(231).symbol =  'may23_B.Timestamp';
    
xcp.signals(232).symbol =  'may23_B.conv';
    
xcp.signals(233).symbol =  'may23_B.Product_f';
    
xcp.signals(234).symbol =  'may23_B.RateTransition';
    
xcp.signals(235).symbol =  'may23_B.RateTransition1_h';
    
xcp.signals(236).symbol =  'may23_B.RateTransition10';
    
xcp.signals(237).symbol =  'may23_B.RateTransition11';
    
xcp.signals(238).symbol =  'may23_B.RateTransition12';
    
xcp.signals(239).symbol =  'may23_B.RateTransition2_k';
    
xcp.signals(240).symbol =  'may23_B.RateTransition3';
    
xcp.signals(241).symbol =  'may23_B.RateTransition4';
    
xcp.signals(242).symbol =  'may23_B.RateTransition5';
    
xcp.signals(243).symbol =  'may23_B.RateTransition6';
    
xcp.signals(244).symbol =  'may23_B.RateTransition7';
    
xcp.signals(245).symbol =  'may23_B.RateTransition8';
    
xcp.signals(246).symbol =  'may23_B.RateTransition9';
    
xcp.signals(247).symbol =  'may23_ConstB.Width_f';
    
xcp.signals(248).symbol =  'may23_B.Pack_i';
    
xcp.signals(249).symbol =  'may23_ConstB.Width_j';
    
xcp.signals(250).symbol =  'may23_B.resetUDP';
    
xcp.signals(251).symbol =  'may23_B.data_out';
    
xcp.signals(252).symbol =  'may23_B.queue_size';
    
xcp.signals(253).symbol =  'may23_B.total_timeouts';
    
xcp.signals(254).symbol =  'may23_B.max_packet_id';
    
xcp.signals(255).symbol =  'may23_B.DataTypeConversion2_k';
    
xcp.signals(256).symbol =  'may23_B.queue_size_i';
    
xcp.signals(257).symbol =  'may23_B.timeouts';
    
xcp.signals(258).symbol =  'may23_B.TaskClock_e';
    
xcp.signals(259).symbol =  'may23_B.RateTransition1_l';
    
xcp.signals(260).symbol =  'may23_B.Convert1_a';
    
xcp.signals(261).symbol =  'may23_B.Convert19_h';
    
xcp.signals(262).symbol =  'may23_B.RateTransition_a';
    
xcp.signals(263).symbol =  'may23_B.RateTransition1_ot';
    
xcp.signals(264).symbol =  'may23_B.systemtype';
    
xcp.signals(265).symbol =  'may23_B.ReadHasFT';
    
xcp.signals(266).symbol =  'may23_B.timestamp_out';
    
xcp.signals(267).symbol =  'may23_B.start_time_out';
    
xcp.signals(268).symbol =  'may23_B.gazeXYCalculated';
    
xcp.signals(269).symbol =  'may23_B.pupil_area_GLOBAL';
    
xcp.signals(270).symbol =  'may23_B.gaze_unit_vector_GLOBAL';
    
xcp.signals(271).symbol =  'may23_B.pupil_GLOBAL';
    
xcp.signals(272).symbol =  'may23_B.pack_out';
    
xcp.signals(273).symbol =  'may23_B.len_out';
    
xcp.signals(274).symbol =  'may23_B.event_data_out';
    
xcp.signals(275).symbol =  'may23_B.Convert1_n';
    
xcp.signals(276).symbol =  'may23_B.Convert19';
    
xcp.signals(277).symbol =  'may23_B.Convert2';
    
xcp.signals(278).symbol =  'may23_B.Convert3';
    
xcp.signals(279).symbol =  'may23_B.Convert4';
    
xcp.signals(280).symbol =  'may23_B.DataTypeConversion_p5';
    
xcp.signals(281).symbol =  'may23_B.DataTypeConversion1_f';
    
xcp.signals(282).symbol =  'may23_B.DataTypeConversion3';
    
xcp.signals(283).symbol =  'may23_B.DataTypeConversion4';
    
xcp.signals(284).symbol =  'may23_B.DataTypeConversion5';
    
xcp.signals(285).symbol =  'may23_B.convert_n';
    
xcp.signals(286).symbol =  'may23_B.Gain_o';
    
xcp.signals(287).symbol =  'may23_B.RateTransition_i';
    
xcp.signals(288).symbol =  'may23_B.RateTransition1_n';
    
xcp.signals(289).symbol =  'may23_B.RateTransition2_l';
    
xcp.signals(290).symbol =  'may23_B.RateTransition3_c';
    
xcp.signals(291).symbol =  'may23_B.Reshape_a';
    
xcp.signals(292).symbol =  'may23_B.SelectorLeftEye';
    
xcp.signals(293).symbol =  'may23_B.Receive_o1_o';
    
xcp.signals(294).symbol =  'may23_B.Receive_o2_f';
    
xcp.signals(295).symbol =  'may23_B.SFunction_o1';
    
xcp.signals(296).symbol =  'may23_B.SAMPE_TYPE';
    
xcp.signals(297).symbol =  'may23_B.ContentFlags';
    
xcp.signals(298).symbol =  'may23_B.pupil_X';
    
xcp.signals(299).symbol =  'may23_B.pupilY';
    
xcp.signals(300).symbol =  'may23_B.HREFX';
    
xcp.signals(301).symbol =  'may23_B.HREFY';
    
xcp.signals(302).symbol =  'may23_B.pupilarea';
    
xcp.signals(303).symbol =  'may23_B.gaze_X';
    
xcp.signals(304).symbol =  'may23_B.gaze_Y';
    
xcp.signals(305).symbol =  'may23_B.resolutionX';
    
xcp.signals(306).symbol =  'may23_B.resolutionY';
    
xcp.signals(307).symbol =  'may23_B.statusflags';
    
xcp.signals(308).symbol =  'may23_B.extrainput';
    
xcp.signals(309).symbol =  'may23_B.buttons';
    
xcp.signals(310).symbol =  'may23_B.htype';
    
xcp.signals(311).symbol =  'may23_B.hdata';
    
xcp.signals(312).symbol =  'may23_B.SFunction_o18';
    
xcp.signals(313).symbol =  'may23_B.torques_out';
    
xcp.signals(314).symbol =  'may23_B.deltas';
    
xcp.signals(315).symbol =  'may23_B.DataStoreRead1_l';
    
xcp.signals(316).symbol =  'may23_B.Product_b';
    
xcp.signals(317).symbol =  'may23_B.Delay';
    
xcp.signals(318).symbol =  'may23_B.robot_count';
    
xcp.signals(319).symbol =  'may23_B.has_force_plate_1';
    
xcp.signals(320).symbol =  'may23_B.has_force_plate_2';
    
xcp.signals(321).symbol =  'may23_B.has_gaze_tracker';
    
xcp.signals(322).symbol =  'may23_B.has_robot_lift';
    
xcp.signals(323).symbol =  'may23_B.robot_failures';
    
xcp.signals(324).symbol =  'may23_B.torque_err_bitfield';
    
xcp.signals(325).symbol =  'may23_B.abs_diff';
    
xcp.signals(326).symbol =  'may23_B.rel_diff';
    
xcp.signals(327).symbol =  'may23_B.robot_limits';
    
xcp.signals(328).symbol =  'may23_B.filteredVals';
    
xcp.signals(329).symbol =  'may23_B.command_multiplier';
    
xcp.signals(330).symbol =  'may23_B.stop_vel_mode';
    
xcp.signals(331).symbol =  'may23_B.robot_err_bits_out';
    
xcp.signals(332).symbol =  'may23_B.DataStoreRead';
    
xcp.signals(333).symbol =  'may23_B.DataStoreRead1';
    
xcp.signals(334).symbol =  'may23_B.TaskClock_h';
    
xcp.signals(335).symbol =  'may23_B.Memory1';
    
xcp.signals(336).symbol =  'may23_B.Memory2';
    
xcp.signals(337).symbol =  'may23_B.Product_n';
    
xcp.signals(338).symbol =  'may23_B.AddR1';
    
xcp.signals(339).symbol =  'may23_B.AddR2';
    
xcp.signals(340).symbol =  'may23_B.Delay_l';
    
xcp.signals(341).symbol =  'may23_B.preview_detail';
    
xcp.signals(342).symbol =  'may23_B.y_o';
    
xcp.signals(343).symbol =  'may23_B.z';
    
xcp.signals(344).symbol =  'may23_B.value';
    
xcp.signals(345).symbol =  'may23_B.DataTypeConversion';
    
xcp.signals(346).symbol =  'may23_B.DataTypeConversion1_fy';
    
xcp.signals(347).symbol =  'may23_B.RunCommandReceive_o1';
    
xcp.signals(348).symbol =  'may23_B.RunCommandReceive_o2';
    
xcp.signals(349).symbol =  'may23_B.tp_out';
    
xcp.signals(350).symbol =  'may23_B.task_status';
    
xcp.signals(351).symbol =  'may23_B.tp';
    
xcp.signals(352).symbol =  'may23_B.block_idx';
    
xcp.signals(353).symbol =  'may23_B.trial_in_block';
    
xcp.signals(354).symbol =  'may23_B.block_in_set';
    
xcp.signals(355).symbol =  'may23_B.trial_in_set';
    
xcp.signals(356).symbol =  'may23_B.repeat_last_trial';
    
xcp.signals(357).symbol =  'may23_B.extra_trials';
    
xcp.signals(358).symbol =  'may23_B.e_exit_trial';
    
xcp.signals(359).symbol =  'may23_B.DataTypeConversion_p';
    
xcp.signals(360).symbol =  'may23_B.DataTypeConversion1_jo';
    
xcp.signals(361).symbol =  'may23_B.DataTypeConversion2';
    
xcp.signals(362).symbol =  'may23_B.DataTypeConversion3_m';
    
xcp.signals(363).symbol =  'may23_B.TaskClock';
    
xcp.signals(364).symbol =  'may23_B.Delay_h';
    
xcp.signals(365).symbol =  'may23_B.Delay1';
    
xcp.signals(366).symbol =  'may23_B.Product';
    
xcp.signals(367).symbol =  'may23_B.Product2';
    
xcp.signals(368).symbol =  'may23_B.Product3';
    
xcp.signals(369).symbol =  'may23_B.Selector1';
    
xcp.signals(370).symbol =  'may23_B.Selector2';
    
xcp.signals(371).symbol =  'may23_B.Subtract_a';
    
xcp.signals(372).symbol =  'may23_ConstB.Width1';
    
xcp.signals(373).symbol =  'may23_B.Width2';
    
xcp.signals(374).symbol =  'may23_B.total_trials';
    
xcp.signals(375).symbol =  'may23_B.trials_in_block';
    
xcp.signals(376).symbol =  'may23_B.total_blocks';
    
xcp.signals(377).symbol =  'may23_B.total_trials_in_exam';
    
xcp.signals(378).symbol =  'may23_B.total_trials_in_block';
    
xcp.signals(379).symbol =  'may23_B.total_blocks_in_exam';
    
xcp.signals(380).symbol =  'may23_B.sf_MATLABFunction_b.motors_enabled';
    
xcp.signals(381).symbol =  'may23_B.sf_MATLABFunction_gh.motors_enabled';
    
xcp.signals(382).symbol =  'may23_B.clipped_torques';
    
xcp.signals(383).symbol =  'may23_B.Switch1';
    
xcp.signals(384).symbol =  'may23_B.assessment_hand_pos_f';
    
xcp.signals(385).symbol =  'may23_B.contralateral_hand_pos_o';
    
xcp.signals(386).symbol =  'may23_B.assessment_hand_vel';
    
xcp.signals(387).symbol =  'may23_B.contralateral_hand_vel';
    
xcp.signals(388).symbol =  'may23_B.assessment_link_angles';
    
xcp.signals(389).symbol =  'may23_B.contralateral_link_angles';
    
xcp.signals(390).symbol =  'may23_B.assessment_link_vel';
    
xcp.signals(391).symbol =  'may23_B.contralateral_link_vel';
    
xcp.signals(392).symbol =  'may23_B.assessment_hand_pos';
    
xcp.signals(393).symbol =  'may23_B.contralateral_hand_pos';
    
xcp.signals(394).symbol =  'may23_B.assessment_hand_vel_n';
    
xcp.signals(395).symbol =  'may23_B.contralateral_hand_vel_d';
    
xcp.signals(396).symbol =  'may23_B.assessment_link_angles_m';
    
xcp.signals(397).symbol =  'may23_B.contralateral_link_angles_f';
    
xcp.signals(398).symbol =  'may23_B.assessment_link_vel_n';
    
xcp.signals(399).symbol =  'may23_B.contralateral_link_vel_a';
    
xcp.signals(400).symbol =  'may23_B.BARRIER_ROWBarriertargetBarriernone';
    
xcp.signals(401).symbol =  'may23_B.CURSOR_ROWHandTargetRowtargethandnone';
    
xcp.signals(402).symbol =  'may23_B.GOAL_ROWGoalRowtargetGoalnone';
    
xcp.signals(403).symbol =  'may23_B.GOAL_TIMEGoaltimesfloatTimethatpuckhastostayingoaltotriggersucc';
    
xcp.signals(404).symbol =  'may23_B.LOAD_ROWLoadRowloadLoadnone';
    
xcp.signals(405).symbol =  'may23_B.PRESHOT_ROWPreshotAreatargetPreshotAreanone';
    
xcp.signals(406).symbol =  'may23_B.PUCK_DAMPINGPuckdampingfloatDampingconstantonpuckbetween0and1no';
    
xcp.signals(407).symbol =  'may23_B.PUCK_ROWPuckTargetRowtargetPucknone';
    
xcp.signals(408).symbol =  'may23_B.SECONDSTrialdurationsfloatHowlongisthetrialinsecondsnone';
    
xcp.signals(409).symbol =  'may23_B.SHOT_READY_TIMEShotreadytimesfloatTimetoholdinstarttargetduring';
    
xcp.signals(410).symbol =  'may23_B.SHOT_SET_TIMEShotsettimesfloatTimetoholdinstarttargetafterpresh';
    
xcp.signals(411).symbol =  'may23_B.SHOT_TIMEShottimesfloatTimetomakeashotintothegoalnone';
    
xcp.signals(412).symbol =  'may23_B.START_HOLD_TIMEStartholdtimesfloatTimetoholdinstarttargetbefore';
    
xcp.signals(413).symbol =  'may23_B.START_ROWStartPositiontargetStartingSpotforPtnone';
    
xcp.signals(414).symbol =  'may23_B.E_BEGIN_PRESHOTbeginpreshotroutinenone';
    
xcp.signals(415).symbol =  'may23_B.E_ENTER_STARTenterstarttargetnone';
    
xcp.signals(416).symbol =  'may23_B.E_FAILUREfailurered';
    
xcp.signals(417).symbol =  'may23_B.E_HAND_IN_BARRIERhandinbarriernone';
    
xcp.signals(418).symbol =  'may23_B.E_NO_EVENTnaThisevent_codedoesnotsaveaneventinthedatafileitjust';
    
xcp.signals(419).symbol =  'may23_B.E_PUCK_IN_BARRIERpuckinbarriernone';
    
xcp.signals(420).symbol =  'may23_B.E_PUCK_IN_GOALpuckingoalnone';
    
xcp.signals(421).symbol =  'may23_B.E_PUCK_MISSpuckmissnone';
    
xcp.signals(422).symbol =  'may23_B.E_SHOT_GOshotgonone';
    
xcp.signals(423).symbol =  'may23_B.E_SHOT_READYshotreadynone';
    
xcp.signals(424).symbol =  'may23_B.E_START_TARGET_ONstarttargetonnone';
    
xcp.signals(425).symbol =  'may23_B.E_SUCCESSsuccessgreen';
    
xcp.signals(426).symbol =  'may23_B.E_TIMEOUTtimeoutred';
    
xcp.signals(427).symbol =  'may23_B.E_TRIAL_STARTtrialstartnone';
    
xcp.signals(428).symbol =  'may23_B.F_BUMPF_BUMPfloatCompletelyarbitraryparameterbasedonwhatfeelsgo';
    
xcp.signals(429).symbol =  'may23_B.MASS_CIRCLECircletargetmassfloatnone';
    
xcp.signals(430).symbol =  'may23_B.MASS_RECTRectangletargetmassfloatnone';
    
xcp.signals(431).symbol =  'may23_B.PERT_DURPerturbationDurationfloatmsTimethattheperturbationishig';
    
xcp.signals(432).symbol =  'may23_B.PERT_RAMPPerturbationRampTimefloatmsTimefortheperturbationtoram';
    
xcp.signals(433).symbol =  'may23_B.FIRST_FILLFirstfillcolorcolourFirstfillcolorforaselectedtargetc';
    
xcp.signals(434).symbol =  'may23_B.HEIGHTHeightfloatRectangleheightcmnone';
    
xcp.signals(435).symbol =  'may23_B.RADIUS_LOGlogicalradiusfloatcomputationalradiuscmnone';
    
xcp.signals(436).symbol =  'may23_B.RADIUS_VISradiusvisfloatradiusincmlegacynone';
    
xcp.signals(437).symbol =  'may23_B.ROTATIONRotationfloatRectangleroationdegreesnone';
    
xcp.signals(438).symbol =  'may23_B.SECOND_FILLSecondfillcolorcolourSecondfillcolorforaselectedtarg';
    
xcp.signals(439).symbol =  'may23_B.STROKE_COLORStrokecolourcolourStrokecolorcolornone';
    
xcp.signals(440).symbol =  'may23_B.STROKE_WIDTHWidthofthestrokefloatStrokeweightcmnone';
    
xcp.signals(441).symbol =  'may23_B.THIRD_FILLthirdfillcolorcolourThirdfillcolorforaselectedtargetc';
    
xcp.signals(442).symbol =  'may23_B.WIDTHWidthorRadiusfloatRectanglewidthorCircleRadiuscmnone';
    
xcp.signals(443).symbol =  'may23_B.col_xXfloatXPositioncmofthetargetrelativetolocal00none';
    
xcp.signals(444).symbol =  'may23_B.col_yYfloatYPositioncmofthetargetrelativetolocal00none';
    
xcp.signals(445).symbol =  'may23_B.INSTRUCTIONS';
    
xcp.signals(446).symbol =  'may23_B.LOAD_FOREITHER';
    
xcp.signals(447).symbol =  'may23_B.FORCE_MULTIPLIERForcemultiplierfloatnone';
    
xcp.signals(448).symbol =  'may23_B.delay';
    
xcp.signals(449).symbol =  'may23_B.RateTransition1_c';
    
xcp.signals(450).symbol =  'may23_B.SFunctionBuilder_o1';
    
xcp.signals(451).symbol =  'may23_B.SFunctionBuilder_o2';
    
xcp.signals(452).symbol =  'may23_B.SFunctionBuilder_o3';
    
xcp.signals(453).symbol =  'may23_B.vis_cmd';
    
xcp.signals(454).symbol =  'may23_B.vis_cmd_len';
    
xcp.signals(455).symbol =  'may23_B.vis_cmd_cropped';
    
xcp.signals(456).symbol =  'may23_B.frame_number';
    
xcp.signals(457).symbol =  'may23_B.vcode_err_id';
    
xcp.signals(458).symbol =  'may23_B.Convert_j';
    
xcp.signals(459).symbol =  'may23_B.RateTransition1_o';
    
xcp.signals(460).symbol =  'may23_B.Compare_j';
    
xcp.signals(461).symbol =  'may23_B.scaling';
    
xcp.signals(462).symbol =  'may23_B.perturbation';
    
xcp.signals(463).symbol =  'may23_B.DataTypeConversion_bl';
    
xcp.signals(464).symbol =  'may23_B.DataTypeConversion2_gv';
    
xcp.signals(465).symbol =  'may23_B.hand_vcodes_e';
    
xcp.signals(466).symbol =  'may23_B.MatrixConcatenate1';
    
xcp.signals(467).symbol =  'may23_B.hand_vcodes';
    
xcp.signals(468).symbol =  'may23_B.dd_out';
    
xcp.signals(469).symbol =  'may23_B.Output_h';
    
xcp.signals(470).symbol =  'may23_B.Compare_o';
    
xcp.signals(471).symbol =  'may23_B.DataTypeConversion_i';
    
xcp.signals(472).symbol =  'may23_B.IdealFramesPerPacket';
    
xcp.signals(473).symbol =  'may23_B.MathFunction';
    
xcp.signals(474).symbol =  'may23_B.t1';
    
xcp.signals(475).symbol =  'may23_B.t2';
    
xcp.signals(476).symbol =  'may23_B.MinMax_b';
    
xcp.signals(477).symbol =  'may23_B.Product_i0';
    
xcp.signals(478).symbol =  'may23_B.RelationalOperator';
    
xcp.signals(479).symbol =  'may23_B.Selector_pl';
    
xcp.signals(480).symbol =  'may23_B.Subtract_h';
    
xcp.signals(481).symbol =  'may23_B.Width';
    
xcp.signals(482).symbol =  'may23_B.DataTypeConversion_pa';
    
xcp.signals(483).symbol =  'may23_B.Memory1_m';
    
xcp.signals(484).symbol =  'may23_B.trigger';
    
xcp.signals(485).symbol =  'may23_B.Receive_o1_m';
    
xcp.signals(486).symbol =  'may23_B.Receive_o2_c';
    
xcp.signals(487).symbol =  'may23_B.Unpack_n';
    
xcp.signals(488).symbol =  'may23_B.Pack_c';
    
xcp.signals(489).symbol =  'may23_ConstB.Width_g1';
    
xcp.signals(490).symbol =  'may23_B.strobe_out';
    
xcp.signals(491).symbol =  'may23_B.RateTransition1_l1';
    
xcp.signals(492).symbol =  'may23_B.RateTransition2_a';
    
xcp.signals(493).symbol =  'may23_B.forces_e';
    
xcp.signals(494).symbol =  'may23_B.moments_i';
    
xcp.signals(495).symbol =  'may23_B.timer_a';
    
xcp.signals(496).symbol =  'may23_B.Receive_o1_p';
    
xcp.signals(497).symbol =  'may23_B.Receive_o2_b';
    
xcp.signals(498).symbol =  'may23_B.forces';
    
xcp.signals(499).symbol =  'may23_B.moments';
    
xcp.signals(500).symbol =  'may23_B.timer';
    
xcp.signals(501).symbol =  'may23_B.Receive1_o1';
    
xcp.signals(502).symbol =  'may23_B.Receive1_o2';
    
xcp.signals(503).symbol =  'may23_ConstB.Width_h';
    
xcp.signals(504).symbol =  'may23_ConstB.Width_gf';
    
xcp.signals(505).symbol =  'may23_B.errVals';
    
xcp.signals(506).symbol =  'may23_B.DCErrVals';
    
xcp.signals(507).symbol =  'may23_B.intAddresses';
    
xcp.signals(508).symbol =  'may23_B.floatAddresses';
    
xcp.signals(509).symbol =  'may23_B.motorEnableState';
    
xcp.signals(510).symbol =  'may23_B.Bias';
    
xcp.signals(511).symbol =  'may23_B.max_errors_to_fault';
    
xcp.signals(512).symbol =  'may23_B.DataTypeConversion_pn';
    
xcp.signals(513).symbol =  'may23_B.convert1_l';
    
xcp.signals(514).symbol =  'may23_B.BKINEtherCATinit_o1';
    
xcp.signals(515).symbol =  'may23_B.BKINEtherCATinit_o2';
    
xcp.signals(516).symbol =  'may23_B.BKINEtherCATinit_o3';
    
xcp.signals(517).symbol =  'may23_B.BKINEtherCATinit_o4';
    
xcp.signals(518).symbol =  'may23_B.BKINEtherCATinit1_o1';
    
xcp.signals(519).symbol =  'may23_B.BKINEtherCATinit1_o2';
    
xcp.signals(520).symbol =  'may23_B.BKINEtherCATinit1_o3';
    
xcp.signals(521).symbol =  'may23_B.BKINEtherCATinit1_o4';
    
xcp.signals(522).symbol =  'may23_B.Switch_f';
    
xcp.signals(523).symbol =  'may23_B.Switch1_b';
    
xcp.signals(524).symbol =  'may23_B.measures_out';
    
xcp.signals(525).symbol =  'may23_B.status_out';
    
xcp.signals(526).symbol =  'may23_B.LogicalOperator';
    
xcp.signals(527).symbol =  'may23_B.RateTransition_b';
    
xcp.signals(528).symbol =  'may23_B.trigger_calibration';
    
xcp.signals(529).symbol =  'may23_B.kinarm_data';
    
xcp.signals(530).symbol =  'may23_B.primary_encoder_data_out';
    
xcp.signals(531).symbol =  'may23_B.statusInts';
    
xcp.signals(532).symbol =  'may23_B.newMessage';
    
xcp.signals(533).symbol =  'may23_B.sentMessageCount';
    
xcp.signals(534).symbol =  'may23_B.is_calibrated';
    
xcp.signals(535).symbol =  'may23_B.DataStoreRead_d';
    
xcp.signals(536).symbol =  'may23_B.Dataready';
    
xcp.signals(537).symbol =  'may23_B.DelayRead';
    
xcp.signals(538).symbol =  'may23_B.ErrMsgs';
    
xcp.signals(539).symbol =  'may23_B.Primaryread';
    
xcp.signals(540).symbol =  'may23_B.Read';
    
xcp.signals(541).symbol =  'may23_B.ReadHW';
    
xcp.signals(542).symbol =  'may23_B.ReadKinematics';
    
xcp.signals(543).symbol =  'may23_B.ServoRead';
    
xcp.signals(544).symbol =  'may23_B.Statusread';
    
xcp.signals(545).symbol =  'may23_B.torquefeedback1';
    
xcp.signals(546).symbol =  'may23_B.DataTypeConversion_f';
    
xcp.signals(547).symbol =  'may23_B.DataTypeConversion1_d';
    
xcp.signals(548).symbol =  'may23_B.Compare_ny';
    
xcp.signals(549).symbol =  'may23_B.sf_splitKINDataarm1.link_lengths';
    
xcp.signals(550).symbol =  'may23_B.sf_splitKINDataarm1.pointer_offset';
    
xcp.signals(551).symbol =  'may23_B.sf_splitKINDataarm1.shoulder_loc';
    
xcp.signals(552).symbol =  'may23_B.sf_splitKINDataarm1.arm_orientation';
    
xcp.signals(553).symbol =  'may23_B.sf_splitKINDataarm1.shoulder_ang';
    
xcp.signals(554).symbol =  'may23_B.sf_splitKINDataarm1.elbow_ang';
    
xcp.signals(555).symbol =  'may23_B.sf_splitKINDataarm1.shoulder_ang_velocity';
    
xcp.signals(556).symbol =  'may23_B.sf_splitKINDataarm1.elbow_ang_velocity';
    
xcp.signals(557).symbol =  'may23_B.sf_splitKINDataarm1.shoulder_ang_acceleration';
    
xcp.signals(558).symbol =  'may23_B.sf_splitKINDataarm1.elbow_ang_acceleration';
    
xcp.signals(559).symbol =  'may23_B.sf_splitKINDataarm1.joint_torque_cmd';
    
xcp.signals(560).symbol =  'may23_B.sf_splitKINDataarm1.motor_torque_cmd';
    
xcp.signals(561).symbol =  'may23_B.sf_splitKINDataarm1.link_angle';
    
xcp.signals(562).symbol =  'may23_B.sf_splitKINDataarm1.link_velocity';
    
xcp.signals(563).symbol =  'may23_B.sf_splitKINDataarm1.link_acceleration';
    
xcp.signals(564).symbol =  'may23_B.sf_splitKINDataarm1.hand_position';
    
xcp.signals(565).symbol =  'may23_B.sf_splitKINDataarm1.hand_velocity';
    
xcp.signals(566).symbol =  'may23_B.sf_splitKINDataarm1.hand_acceleration';
    
xcp.signals(567).symbol =  'may23_B.sf_splitKINDataarm1.elbow_position';
    
xcp.signals(568).symbol =  'may23_B.sf_splitKINDataarm1.elbow_velocity';
    
xcp.signals(569).symbol =  'may23_B.sf_splitKINDataarm1.elbow_acceleration';
    
xcp.signals(570).symbol =  'may23_B.sf_splitKINDataarm1.motor_status';
    
xcp.signals(571).symbol =  'may23_B.sf_splitKINDataarm1.force_sensor_force_uvw';
    
xcp.signals(572).symbol =  'may23_B.sf_splitKINDataarm1.force_sensor_torque_uvw';
    
xcp.signals(573).symbol =  'may23_B.sf_splitKINDataarm1.force_sensor_force_xyz';
    
xcp.signals(574).symbol =  'may23_B.sf_splitKINDataarm1.force_sensor_torque_xyz';
    
xcp.signals(575).symbol =  'may23_B.sf_splitKINDataarm1.force_sensor_timestamp';
    
xcp.signals(576).symbol =  'may23_B.sf_splitKINDataarm2.link_lengths';
    
xcp.signals(577).symbol =  'may23_B.sf_splitKINDataarm2.pointer_offset';
    
xcp.signals(578).symbol =  'may23_B.sf_splitKINDataarm2.shoulder_loc';
    
xcp.signals(579).symbol =  'may23_B.sf_splitKINDataarm2.arm_orientation';
    
xcp.signals(580).symbol =  'may23_B.sf_splitKINDataarm2.shoulder_ang';
    
xcp.signals(581).symbol =  'may23_B.sf_splitKINDataarm2.elbow_ang';
    
xcp.signals(582).symbol =  'may23_B.sf_splitKINDataarm2.shoulder_ang_velocity';
    
xcp.signals(583).symbol =  'may23_B.sf_splitKINDataarm2.elbow_ang_velocity';
    
xcp.signals(584).symbol =  'may23_B.sf_splitKINDataarm2.shoulder_ang_acceleration';
    
xcp.signals(585).symbol =  'may23_B.sf_splitKINDataarm2.elbow_ang_acceleration';
    
xcp.signals(586).symbol =  'may23_B.sf_splitKINDataarm2.joint_torque_cmd';
    
xcp.signals(587).symbol =  'may23_B.sf_splitKINDataarm2.motor_torque_cmd';
    
xcp.signals(588).symbol =  'may23_B.sf_splitKINDataarm2.link_angle';
    
xcp.signals(589).symbol =  'may23_B.sf_splitKINDataarm2.link_velocity';
    
xcp.signals(590).symbol =  'may23_B.sf_splitKINDataarm2.link_acceleration';
    
xcp.signals(591).symbol =  'may23_B.sf_splitKINDataarm2.hand_position';
    
xcp.signals(592).symbol =  'may23_B.sf_splitKINDataarm2.hand_velocity';
    
xcp.signals(593).symbol =  'may23_B.sf_splitKINDataarm2.hand_acceleration';
    
xcp.signals(594).symbol =  'may23_B.sf_splitKINDataarm2.elbow_position';
    
xcp.signals(595).symbol =  'may23_B.sf_splitKINDataarm2.elbow_velocity';
    
xcp.signals(596).symbol =  'may23_B.sf_splitKINDataarm2.elbow_acceleration';
    
xcp.signals(597).symbol =  'may23_B.sf_splitKINDataarm2.motor_status';
    
xcp.signals(598).symbol =  'may23_B.sf_splitKINDataarm2.force_sensor_force_uvw';
    
xcp.signals(599).symbol =  'may23_B.sf_splitKINDataarm2.force_sensor_torque_uvw';
    
xcp.signals(600).symbol =  'may23_B.sf_splitKINDataarm2.force_sensor_force_xyz';
    
xcp.signals(601).symbol =  'may23_B.sf_splitKINDataarm2.force_sensor_torque_xyz';
    
xcp.signals(602).symbol =  'may23_B.sf_splitKINDataarm2.force_sensor_timestamp';
    
xcp.signals(603).symbol =  'may23_B.active_arm';
    
xcp.signals(604).symbol =  'may23_B.servoCounter';
    
xcp.signals(605).symbol =  'may23_B.calibrationButtonBits';
    
xcp.signals(606).symbol =  'may23_B.handFF_Dex';
    
xcp.signals(607).symbol =  'may23_B.Selector_i2';
    
xcp.signals(608).symbol =  'may23_B.Selector1_b';
    
xcp.signals(609).symbol =  'may23_B.Selector2_e';
    
xcp.signals(610).symbol =  'may23_B.sf_split_primary.link_angles';
    
xcp.signals(611).symbol =  'may23_B.sf_split_primary.link_velocities';
    
xcp.signals(612).symbol =  'may23_B.sf_split_primary.link_acceleration';
    
xcp.signals(613).symbol =  'may23_B.sf_split_primary1.link_angles';
    
xcp.signals(614).symbol =  'may23_B.sf_split_primary1.link_velocities';
    
xcp.signals(615).symbol =  'may23_B.sf_split_primary1.link_acceleration';
    
xcp.signals(616).symbol =  'may23_B.Selector1_e';
    
xcp.signals(617).symbol =  'may23_B.Selector2_l';
    
xcp.signals(618).symbol =  'may23_B.ecatTorques';
    
xcp.signals(619).symbol =  'may23_B.DataStoreRead_h';
    
xcp.signals(620).symbol =  'may23_B.DataTypeConversion_nc';
    
xcp.signals(621).symbol =  'may23_B.DataTypeConversion1_px';
    
xcp.signals(622).symbol =  'may23_B.DataTypeConversion6';
    
xcp.signals(623).symbol =  'may23_B.Product_d';
    
xcp.signals(624).symbol =  'may23_B.Compare_n';
    
xcp.signals(625).symbol =  'may23_B.Compare_oi';
    
xcp.signals(626).symbol =  'may23_B.sf_MATLABFunction_a.is_right_arm';
    
xcp.signals(627).symbol =  'may23_B.sf_MATLABFunction_a.isExo';
    
xcp.signals(628).symbol =  'may23_B.sf_MATLABFunction_a.has_high_res_encoders';
    
xcp.signals(629).symbol =  'may23_B.sf_MATLABFunction1.is_right_arm';
    
xcp.signals(630).symbol =  'may23_B.sf_MATLABFunction1.isExo';
    
xcp.signals(631).symbol =  'may23_B.sf_MATLABFunction1.has_high_res_encoders';
    
xcp.signals(632).symbol =  'may23_B.Compare_d';
    
xcp.signals(633).symbol =  'may23_B.filteredVals_n';
    
xcp.signals(634).symbol =  'may23_B.Delay_a';
    
xcp.signals(635).symbol =  'may23_B.torque_multiplier_out';
    
xcp.signals(636).symbol =  'may23_B.stop_vel_mode_out';
    
xcp.signals(637).symbol =  'may23_B.encoder_err_threshold';
    
xcp.signals(638).symbol =  'may23_B.Memory1_e';
    
xcp.signals(639).symbol =  'may23_B.Compare';
    
xcp.signals(640).symbol =  'may23_B.FixPtRelationalOperator_g';
    
xcp.signals(641).symbol =  'may23_B.Uk1_e';
    
xcp.signals(642).symbol =  'may23_B.FixPtRelationalOperator_f';
    
xcp.signals(643).symbol =  'may23_B.Uk1_h';
    
xcp.signals(644).symbol =  'may23_B.Compare_e';
    
xcp.signals(645).symbol =  'may23_B.Output';
    
xcp.signals(646).symbol =  'may23_B.BlockDefinitions';
    
xcp.signals(647).symbol =  'may23_B.BlockSequence';
    
xcp.signals(648).symbol =  'may23_B.LoadTable';
    
xcp.signals(649).symbol =  'may23_B.TPTable';
    
xcp.signals(650).symbol =  'may23_B.TargetLabels';
    
xcp.signals(651).symbol =  'may23_B.TargetTable';
    
xcp.signals(652).symbol =  'may23_B.Taskwideparam';
    
xcp.signals(653).symbol =  'may23_B.VCODES_out';
    
xcp.signals(654).symbol =  'may23_B.MatrixConcatenation';
    
xcp.signals(655).symbol =  'may23_B.Reshape';
    
xcp.signals(656).symbol =  'may23_B.Reshape1';
    
xcp.signals(657).symbol =  'may23_B.FixPtSum1_h';
    
xcp.signals(658).symbol =  'may23_B.FixPtSwitch_c';
    
xcp.signals(659).symbol =  'may23_B.Sum';
    
xcp.signals(660).symbol =  'may23_B.UnitDelay_h';
    
xcp.signals(661).symbol =  'may23_B.Output_a';
    
xcp.signals(662).symbol =  'may23_B.sf_FindRobottype.robotType';
    
xcp.signals(663).symbol =  'may23_B.SDOCommand_j';
    
xcp.signals(664).symbol =  'may23_B.intSDOValues_m';
    
xcp.signals(665).symbol =  'may23_B.floatSDOValues_d';
    
xcp.signals(666).symbol =  'may23_B.complete_b';
    
xcp.signals(667).symbol =  'may23_B.forceMotorState_o';
    
xcp.signals(668).symbol =  'may23_B.sf_size.count';
    
xcp.signals(669).symbol =  'may23_B.sf_size1.count';
    
xcp.signals(670).symbol =  'may23_B.encoderCounts_j';
    
xcp.signals(671).symbol =  'may23_B.FTSensorOffset_k';
    
xcp.signals(672).symbol =  'may23_B.calibPinAngles_i';
    
xcp.signals(673).symbol =  'may23_B.absAngOffsets_p';
    
xcp.signals(674).symbol =  'may23_B.linkLengths_p';
    
xcp.signals(675).symbol =  'may23_B.L2CalibPinOffset_e';
    
xcp.signals(676).symbol =  'may23_B.continuousTorques_m';
    
xcp.signals(677).symbol =  'may23_B.gearRatios_j';
    
xcp.signals(678).symbol =  'may23_B.isCalibrated_j';
    
xcp.signals(679).symbol =  'may23_B.offsetRads_a';
    
xcp.signals(680).symbol =  'may23_B.offsetRadsPrimary_f';
    
xcp.signals(681).symbol =  'may23_B.robotRevision_h';
    
xcp.signals(682).symbol =  'may23_B.constantsReady_p';
    
xcp.signals(683).symbol =  'may23_B.hasSecondary_l';
    
xcp.signals(684).symbol =  'may23_B.hasFT_c';
    
xcp.signals(685).symbol =  'may23_B.robotOrientation_o';
    
xcp.signals(686).symbol =  'may23_B.motorOrientation_j';
    
xcp.signals(687).symbol =  'may23_B.encOrientation_m';
    
xcp.signals(688).symbol =  'may23_B.absEnc_m';
    
xcp.signals(689).symbol =  'may23_B.readTrigger_l';
    
xcp.signals(690).symbol =  'may23_B.R1M1_LinkAngle';
    
xcp.signals(691).symbol =  'may23_B.R1M1_PrimaryLinkAngle';
    
xcp.signals(692).symbol =  'may23_B.R1M1_PrimaryLinkVelocity';
    
xcp.signals(693).symbol =  'may23_B.R1M1_RecordedTorque';
    
xcp.signals(694).symbol =  'may23_B.R1M1_digitalInputs';
    
xcp.signals(695).symbol =  'may23_B.R1M1_digitalDiagnostics';
    
xcp.signals(696).symbol =  'may23_B.R1_calibrationButton';
    
xcp.signals(697).symbol =  'may23_B.R1_EPGripSensor';
    
xcp.signals(698).symbol =  'may23_B.R1M1_EMCY_codes';
    
xcp.signals(699).symbol =  'may23_B.R1M1_CurrentLimitEnabled';
    
xcp.signals(700).symbol =  'may23_B.R1M2_LinkAngle';
    
xcp.signals(701).symbol =  'may23_B.R1M2_PrimaryLinkAngle';
    
xcp.signals(702).symbol =  'may23_B.R1M2_PrimaryLinkVelocity';
    
xcp.signals(703).symbol =  'may23_B.R1M2_RecordedTorque';
    
xcp.signals(704).symbol =  'may23_B.R1M2_digitalInputs';
    
xcp.signals(705).symbol =  'may23_B.R1M2_digitalDiagnostics';
    
xcp.signals(706).symbol =  'may23_B.R1M2_EMCY_codes';
    
xcp.signals(707).symbol =  'may23_B.R1M2_CurrentLimitEnabled';
    
xcp.signals(708).symbol =  'may23_B.R1_RobotType';
    
xcp.signals(709).symbol =  'may23_B.R1_hasSecondary';
    
xcp.signals(710).symbol =  'may23_B.R1_hasFT';
    
xcp.signals(711).symbol =  'may23_B.R1_robotOrientation';
    
xcp.signals(712).symbol =  'may23_B.R1_motorOrientation';
    
xcp.signals(713).symbol =  'may23_B.R1_encOrientation';
    
xcp.signals(714).symbol =  'may23_B.R1_encodercounts';
    
xcp.signals(715).symbol =  'may23_B.R1_FTSensorAngleOffset';
    
xcp.signals(716).symbol =  'may23_B.R1_calibPinAngle';
    
xcp.signals(717).symbol =  'may23_B.R1_absAngleOffset';
    
xcp.signals(718).symbol =  'may23_B.R1_LinkLength';
    
xcp.signals(719).symbol =  'may23_B.R1_L2CalibPinOffset';
    
xcp.signals(720).symbol =  'may23_B.R1_maxContinuousTorque_i';
    
xcp.signals(721).symbol =  'may23_B.R1_gearRatios';
    
xcp.signals(722).symbol =  'may23_B.R1_isCalibrated';
    
xcp.signals(723).symbol =  'may23_B.R1_OffsetRads';
    
xcp.signals(724).symbol =  'may23_B.R1_OffsetRadsPrimary';
    
xcp.signals(725).symbol =  'may23_B.R1_RobotRevision';
    
xcp.signals(726).symbol =  'may23_B.R1_constantsReady_p';
    
xcp.signals(727).symbol =  'may23_B.R1_maxContinuousTorque';
    
xcp.signals(728).symbol =  'may23_B.R1_constantsReady';
    
xcp.signals(729).symbol =  'may23_B.sf_FindRobottype_i.robotType';
    
xcp.signals(730).symbol =  'may23_B.SDOCommand';
    
xcp.signals(731).symbol =  'may23_B.intSDOValues';
    
xcp.signals(732).symbol =  'may23_B.floatSDOValues';
    
xcp.signals(733).symbol =  'may23_B.complete';
    
xcp.signals(734).symbol =  'may23_B.forceMotorState';
    
xcp.signals(735).symbol =  'may23_B.sf_size_l.count';
    
xcp.signals(736).symbol =  'may23_B.sf_size1_b.count';
    
xcp.signals(737).symbol =  'may23_B.encoderCounts';
    
xcp.signals(738).symbol =  'may23_B.FTSensorOffset';
    
xcp.signals(739).symbol =  'may23_B.calibPinAngles';
    
xcp.signals(740).symbol =  'may23_B.absAngOffsets';
    
xcp.signals(741).symbol =  'may23_B.linkLengths';
    
xcp.signals(742).symbol =  'may23_B.L2CalibPinOffset';
    
xcp.signals(743).symbol =  'may23_B.continuousTorques';
    
xcp.signals(744).symbol =  'may23_B.gearRatios';
    
xcp.signals(745).symbol =  'may23_B.isCalibrated';
    
xcp.signals(746).symbol =  'may23_B.offsetRads';
    
xcp.signals(747).symbol =  'may23_B.offsetRadsPrimary';
    
xcp.signals(748).symbol =  'may23_B.robotRevision_g';
    
xcp.signals(749).symbol =  'may23_B.constantsReady';
    
xcp.signals(750).symbol =  'may23_B.hasSecondary';
    
xcp.signals(751).symbol =  'may23_B.hasFT';
    
xcp.signals(752).symbol =  'may23_B.robotOrientation';
    
xcp.signals(753).symbol =  'may23_B.motorOrientation';
    
xcp.signals(754).symbol =  'may23_B.encOrientation';
    
xcp.signals(755).symbol =  'may23_B.absEnc';
    
xcp.signals(756).symbol =  'may23_B.readTrigger';
    
xcp.signals(757).symbol =  'may23_B.R2M1_LinkAngle';
    
xcp.signals(758).symbol =  'may23_B.R2M1_PrimaryLinkAngle';
    
xcp.signals(759).symbol =  'may23_B.R2M1_PrimaryLinkVelocity';
    
xcp.signals(760).symbol =  'may23_B.R2M1_RecordedTorque';
    
xcp.signals(761).symbol =  'may23_B.R2M1_digitalInputs';
    
xcp.signals(762).symbol =  'may23_B.R2M1_digitalDiagnostics';
    
xcp.signals(763).symbol =  'may23_B.R2_calibrationButton';
    
xcp.signals(764).symbol =  'may23_B.R2_EPGripSensor';
    
xcp.signals(765).symbol =  'may23_B.R2M1_EMCY_codes';
    
xcp.signals(766).symbol =  'may23_B.R2M1_CurrentLimitEnabled';
    
xcp.signals(767).symbol =  'may23_B.R2M2_LinkAngle';
    
xcp.signals(768).symbol =  'may23_B.R2M2_PrimaryLinkAngle';
    
xcp.signals(769).symbol =  'may23_B.R2M2_PrimaryLinkVelocity';
    
xcp.signals(770).symbol =  'may23_B.R2M2_RecordedTorque';
    
xcp.signals(771).symbol =  'may23_B.R2M2_digitalInputs';
    
xcp.signals(772).symbol =  'may23_B.R2M2_digitalDiagnostics';
    
xcp.signals(773).symbol =  'may23_B.R2M2_EMCY_codes';
    
xcp.signals(774).symbol =  'may23_B.R2M2_CurrentLimitEnabled';
    
xcp.signals(775).symbol =  'may23_B.R2_RobotType';
    
xcp.signals(776).symbol =  'may23_B.R2_hasSecondary';
    
xcp.signals(777).symbol =  'may23_B.R2_hasFT';
    
xcp.signals(778).symbol =  'may23_B.R2_robotOrientation';
    
xcp.signals(779).symbol =  'may23_B.R2_motorOrientation';
    
xcp.signals(780).symbol =  'may23_B.R2_encOrientation';
    
xcp.signals(781).symbol =  'may23_B.R2_encodercounts';
    
xcp.signals(782).symbol =  'may23_B.R2_FTSensorAngleOffset';
    
xcp.signals(783).symbol =  'may23_B.R2_calibPinAngle';
    
xcp.signals(784).symbol =  'may23_B.R2_absAngleOffset';
    
xcp.signals(785).symbol =  'may23_B.R2_LinkLength';
    
xcp.signals(786).symbol =  'may23_B.R2_L2CalibPinOffset';
    
xcp.signals(787).symbol =  'may23_B.R2_maxContinuousTorque_c';
    
xcp.signals(788).symbol =  'may23_B.R2_gearRatios';
    
xcp.signals(789).symbol =  'may23_B.R2_isCalibrated';
    
xcp.signals(790).symbol =  'may23_B.R2_OffsetRads';
    
xcp.signals(791).symbol =  'may23_B.R2_OffsetRadsPrimary';
    
xcp.signals(792).symbol =  'may23_B.R2_RobotRevision';
    
xcp.signals(793).symbol =  'may23_B.R2_constantsReady_b';
    
xcp.signals(794).symbol =  'may23_B.R2_maxContinuousTorque';
    
xcp.signals(795).symbol =  'may23_B.R2_constantsReady';
    
xcp.signals(796).symbol =  'may23_B.Compare_k';
    
xcp.signals(797).symbol =  'may23_B.Output_hd';
    
xcp.signals(798).symbol =  'may23_B.drive1';
    
xcp.signals(799).symbol =  'may23_B.drive2';
    
xcp.signals(800).symbol =  'may23_B.drive3';
    
xcp.signals(801).symbol =  'may23_B.drive4';
    
xcp.signals(802).symbol =  'may23_B.MasterStateOut';
    
xcp.signals(803).symbol =  'may23_B.errVal';
    
xcp.signals(804).symbol =  'may23_B.masterState';
    
xcp.signals(805).symbol =  'may23_B.DCErrVal';
    
xcp.signals(806).symbol =  'may23_B.MasterToNetworkClkDiff';
    
xcp.signals(807).symbol =  'may23_B.DCInitState';
    
xcp.signals(808).symbol =  'may23_B.NetworkToSlaveClkDiff';
    
xcp.signals(809).symbol =  'may23_B.convert';
    
xcp.signals(810).symbol =  'may23_B.swap_order';
    
xcp.signals(811).symbol =  'may23_B.bitField';
    
xcp.signals(812).symbol =  'may23_B.kinematicsOut';
    
xcp.signals(813).symbol =  'may23_B.kinematicsOutPrimary';
    
xcp.signals(814).symbol =  'may23_B.delays';
    
xcp.signals(815).symbol =  'may23_B.servoCounterOut';
    
xcp.signals(816).symbol =  'may23_B.dataReadyStatus';
    
xcp.signals(817).symbol =  'may23_B.outMem';
    
xcp.signals(818).symbol =  'may23_B.settingsOut';
    
xcp.signals(819).symbol =  'may23_B.calibrationsOut';
    
xcp.signals(820).symbol =  'may23_B.DataStore';
    
xcp.signals(821).symbol =  'may23_B.DataStore1';
    
xcp.signals(822).symbol =  'may23_B.DataTypeConversion_g0';
    
xcp.signals(823).symbol =  'may23_B.DataTypeConversion1_b';
    
xcp.signals(824).symbol =  'may23_B.DataTypeConversion2_h2';
    
xcp.signals(825).symbol =  'may23_B.DataTypeConversion3_o';
    
xcp.signals(826).symbol =  'may23_B.DataTypeConversion4_l';
    
xcp.signals(827).symbol =  'may23_B.DataTypeConversion5_c';
    
xcp.signals(828).symbol =  'may23_B.sf_Createtimestamp.timestamp_out';
    
xcp.signals(829).symbol =  'may23_B.DataTypeConversion_e';
    
xcp.signals(830).symbol =  'may23_B.ByteReversal_m';
    
xcp.signals(831).symbol =  'may23_B.ByteReversal1';
    
xcp.signals(832).symbol =  'may23_B.ReceivefromRobot1ForceSensor_o1';
    
xcp.signals(833).symbol =  'may23_B.ReceivefromRobot1ForceSensor_o2';
    
xcp.signals(834).symbol =  'may23_B.Unpack_o1';
    
xcp.signals(835).symbol =  'may23_B.Unpack_o2_h';
    
xcp.signals(836).symbol =  'may23_B.Switch_m';
    
xcp.signals(837).symbol =  'may23_B.sf_Createtimestamp_o.timestamp_out';
    
xcp.signals(838).symbol =  'may23_B.DataTypeConversion1_o';
    
xcp.signals(839).symbol =  'may23_B.ByteReversal_c';
    
xcp.signals(840).symbol =  'may23_B.ByteReversal1_f';
    
xcp.signals(841).symbol =  'may23_B.ReceivefromRobot2ForceSensor_o1';
    
xcp.signals(842).symbol =  'may23_B.ReceivefromRobot2ForceSensor_o2';
    
xcp.signals(843).symbol =  'may23_B.Unpack1_o1';
    
xcp.signals(844).symbol =  'may23_B.Unpack1_o2';
    
xcp.signals(845).symbol =  'may23_B.Switch1_g';
    
xcp.signals(846).symbol =  'may23_B.Compare_f';
    
xcp.signals(847).symbol =  'may23_B.force_scale';
    
xcp.signals(848).symbol =  'may23_B.robot1DataOut_k';
    
xcp.signals(849).symbol =  'may23_B.robot2DataOut_i';
    
xcp.signals(850).symbol =  'may23_B.robot1PrimaryEncDataOut';
    
xcp.signals(851).symbol =  'may23_B.robot2PrimaryEncDataOut';
    
xcp.signals(852).symbol =  'may23_B.robot1DataOut';
    
xcp.signals(853).symbol =  'may23_B.robot2DataOut';
    
xcp.signals(854).symbol =  'may23_B.Conversion1';
    
xcp.signals(855).symbol =  'may23_B.Conversion2';
    
xcp.signals(856).symbol =  'may23_B.Conversion7';
    
xcp.signals(857).symbol =  'may23_B.Convert2_o';
    
xcp.signals(858).symbol =  'may23_B.DataTypeConversion_g5x';
    
xcp.signals(859).symbol =  'may23_B.DataTypeConversion1_pf';
    
xcp.signals(860).symbol =  'may23_B.DataTypeConversion2_n';
    
xcp.signals(861).symbol =  'may23_B.DataTypeConversion3_d';
    
xcp.signals(862).symbol =  'may23_B.DataTypeConversion4_m';
    
xcp.signals(863).symbol =  'may23_B.MinMax_o';
    
xcp.signals(864).symbol =  'may23_B.MinMax1';
    
xcp.signals(865).symbol =  'may23_B.SFunction_o1_j';
    
xcp.signals(866).symbol =  'may23_B.SFunction_o2';
    
xcp.signals(867).symbol =  'may23_B.SFunction_o3';
    
xcp.signals(868).symbol =  'may23_B.SFunction_o4';
    
xcp.signals(869).symbol =  'may23_B.SFunction_o5';
    
xcp.signals(870).symbol =  'may23_B.SFunction_o6';
    
xcp.signals(871).symbol =  'may23_B.SFunction_o7';
    
xcp.signals(872).symbol =  'may23_B.SFunction_o8';
    
xcp.signals(873).symbol =  'may23_B.SFunction_o9';
    
xcp.signals(874).symbol =  'may23_B.SFunction_o10';
    
xcp.signals(875).symbol =  'may23_B.outStatus';
    
xcp.signals(876).symbol =  'may23_B.Output_n';
    
xcp.signals(877).symbol =  'may23_B.kinematics_l';
    
xcp.signals(878).symbol =  'may23_B.primary_o';
    
xcp.signals(879).symbol =  'may23_B.Constant_k';
    
xcp.signals(880).symbol =  'may23_B.Constant1_f';
    
xcp.signals(881).symbol =  'may23_B.DataTypeConversion_m';
    
xcp.signals(882).symbol =  'may23_B.DataTypeConversion1_i';
    
xcp.signals(883).symbol =  'may23_B.DataTypeConversion2_h';
    
xcp.signals(884).symbol =  'may23_B.SFunction';
    
xcp.signals(885).symbol =  'may23_B.Unpack_o';
    
xcp.signals(886).symbol =  'may23_B.Switch_g';
    
xcp.signals(887).symbol =  'may23_B.Compare_h';
    
xcp.signals(888).symbol =  'may23_B.Compare_ec';
    
xcp.signals(889).symbol =  'may23_B.kinematics';
    
xcp.signals(890).symbol =  'may23_B.primary';
    
xcp.signals(891).symbol =  'may23_B.Constant_d';
    
xcp.signals(892).symbol =  'may23_B.Constant1';
    
xcp.signals(893).symbol =  'may23_B.DataTypeConversion_o';
    
xcp.signals(894).symbol =  'may23_B.DataTypeConversion1_j';
    
xcp.signals(895).symbol =  'may23_B.DataTypeConversion2_f';
    
xcp.signals(896).symbol =  'may23_B.Receive_o1_i';
    
xcp.signals(897).symbol =  'may23_B.Receive_o2_l';
    
xcp.signals(898).symbol =  'may23_B.Unpack_o1_n';
    
xcp.signals(899).symbol =  'may23_B.Unpack_o2';
    
xcp.signals(900).symbol =  'may23_B.Compare_e2';
    
xcp.signals(901).symbol =  'may23_B.isEP_a';
    
xcp.signals(902).symbol =  'may23_B.isHumanEXO_c';
    
xcp.signals(903).symbol =  'may23_B.isNHPEXO_p';
    
xcp.signals(904).symbol =  'may23_B.isClassicExo_n';
    
xcp.signals(905).symbol =  'may23_B.isUTSEXO_k';
    
xcp.signals(906).symbol =  'may23_B.isPMAC_c';
    
xcp.signals(907).symbol =  'may23_B.isECAT_b';
    
xcp.signals(908).symbol =  'may23_B.elbowangleoffset';
    
xcp.signals(909).symbol =  'may23_B.L1';
    
xcp.signals(910).symbol =  'may23_B.L2';
    
xcp.signals(911).symbol =  'may23_B.L3Error';
    
xcp.signals(912).symbol =  'may23_B.M1GearRatio_p';
    
xcp.signals(913).symbol =  'may23_B.M1orientation_b';
    
xcp.signals(914).symbol =  'may23_B.M2GearRatio_i';
    
xcp.signals(915).symbol =  'may23_B.M2Orientation_k';
    
xcp.signals(916).symbol =  'may23_B.ArmOrientation_f';
    
xcp.signals(917).symbol =  'may23_B.Pointeroffset';
    
xcp.signals(918).symbol =  'may23_B.HasSecondaryEnc_n';
    
xcp.signals(919).symbol =  'may23_B.shoulderangleoffset';
    
xcp.signals(920).symbol =  'may23_B.ShoulderX';
    
xcp.signals(921).symbol =  'may23_B.ShoulderY';
    
xcp.signals(922).symbol =  'may23_B.torqueconstant_bz';
    
xcp.signals(923).symbol =  'may23_B.robottype_a';
    
xcp.signals(924).symbol =  'may23_B.robotversion_h';
    
xcp.signals(925).symbol =  'may23_B.Statusread1';
    
xcp.signals(926).symbol =  'may23_B.isEP_e';
    
xcp.signals(927).symbol =  'may23_B.isHumanEXO';
    
xcp.signals(928).symbol =  'may23_B.isNHPEXO';
    
xcp.signals(929).symbol =  'may23_B.isClassicExo_e';
    
xcp.signals(930).symbol =  'may23_B.isUTSEXO';
    
xcp.signals(931).symbol =  'may23_B.isPMAC_a';
    
xcp.signals(932).symbol =  'may23_B.isECAT_i';
    
xcp.signals(933).symbol =  'may23_B.elbowangleoffset_o';
    
xcp.signals(934).symbol =  'may23_B.L1_e';
    
xcp.signals(935).symbol =  'may23_B.L2_j';
    
xcp.signals(936).symbol =  'may23_B.L3Error_a';
    
xcp.signals(937).symbol =  'may23_B.M1GearRatio_a';
    
xcp.signals(938).symbol =  'may23_B.M1orientation_f';
    
xcp.signals(939).symbol =  'may23_B.M2GearRatio_ie';
    
xcp.signals(940).symbol =  'may23_B.M2Orientation_c';
    
xcp.signals(941).symbol =  'may23_B.ArmOrientation_m';
    
xcp.signals(942).symbol =  'may23_B.Pointeroffset_a';
    
xcp.signals(943).symbol =  'may23_B.HasSecondaryEnc_c';
    
xcp.signals(944).symbol =  'may23_B.shoulderangleoffset_j';
    
xcp.signals(945).symbol =  'may23_B.ShoulderX_b';
    
xcp.signals(946).symbol =  'may23_B.ShoulderY_n';
    
xcp.signals(947).symbol =  'may23_B.torqueconstant_l';
    
xcp.signals(948).symbol =  'may23_B.robottype_j';
    
xcp.signals(949).symbol =  'may23_B.robotversion_f';
    
xcp.signals(950).symbol =  'may23_B.Statusread1_c';
    
xcp.signals(951).symbol =  'may23_B.Output_o';
    
xcp.signals(952).symbol =  'may23_B.FixPtSum1';
    
xcp.signals(953).symbol =  'may23_B.FixPtSwitch';
    
xcp.signals(954).symbol =  'may23_B.FixPtSum1_d';
    
xcp.signals(955).symbol =  'may23_B.FixPtSwitch_ii';
    
xcp.signals(956).symbol =  'may23_B.sf_Whistlestate.ControlWord';
    
xcp.signals(957).symbol =  'may23_B.sf_Whistlestate.motorStatus';
    
xcp.signals(958).symbol =  'may23_B.sf_Whistlestate.isPermFaulted';
    
xcp.signals(959).symbol =  'may23_B.sf_cleanword.out_val';
    
xcp.signals(960).symbol =  'may23_B.Memory_p';
    
xcp.signals(961).symbol =  'may23_B.sf_Whistlestate_a.ControlWord';
    
xcp.signals(962).symbol =  'may23_B.sf_Whistlestate_a.motorStatus';
    
xcp.signals(963).symbol =  'may23_B.sf_Whistlestate_a.isPermFaulted';
    
xcp.signals(964).symbol =  'may23_B.sf_cleanword_k.out_val';
    
xcp.signals(965).symbol =  'may23_B.Memory_jp';
    
xcp.signals(966).symbol =  'may23_B.sf_MATLABFunction1_k.mode';
    
xcp.signals(967).symbol =  'may23_B.sf_AbsEncodermachine.setupData';
    
xcp.signals(968).symbol =  'may23_B.sf_AbsEncodermachine.SDORequest';
    
xcp.signals(969).symbol =  'may23_B.sf_AbsEncodermachine.encoderOutputs';
    
xcp.signals(970).symbol =  'may23_B.sf_AbsEncodermachine.complete';
    
xcp.signals(971).symbol =  'may23_B.sf_setupvalues.setupValues';
    
xcp.signals(972).symbol =  'may23_B.sf_setupvalues.setupValuesCount';
    
xcp.signals(973).symbol =  'may23_B.sf_setupvalues.pollValues';
    
xcp.signals(974).symbol =  'may23_B.sf_setupvalues.encoderValues';
    
xcp.signals(975).symbol =  'may23_B.sf_setupvalues.encoderValuesCount';
    
xcp.signals(976).symbol =  'may23_B.Memory_my';
    
xcp.signals(977).symbol =  'may23_B.Memory1_b';
    
xcp.signals(978).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o1_l';
    
xcp.signals(979).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o2_n';
    
xcp.signals(980).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o1_kp';
    
xcp.signals(981).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o2_pz';
    
xcp.signals(982).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o3_n';
    
xcp.signals(983).symbol =  'may23_B.sf_AbsEncodermachine_l.setupData';
    
xcp.signals(984).symbol =  'may23_B.sf_AbsEncodermachine_l.SDORequest';
    
xcp.signals(985).symbol =  'may23_B.sf_AbsEncodermachine_l.encoderOutputs';
    
xcp.signals(986).symbol =  'may23_B.sf_AbsEncodermachine_l.complete';
    
xcp.signals(987).symbol =  'may23_B.sf_setupvalues_b.setupValues';
    
xcp.signals(988).symbol =  'may23_B.sf_setupvalues_b.setupValuesCount';
    
xcp.signals(989).symbol =  'may23_B.sf_setupvalues_b.pollValues';
    
xcp.signals(990).symbol =  'may23_B.sf_setupvalues_b.encoderValues';
    
xcp.signals(991).symbol =  'may23_B.sf_setupvalues_b.encoderValuesCount';
    
xcp.signals(992).symbol =  'may23_B.Memory_ir';
    
xcp.signals(993).symbol =  'may23_B.Memory1_i';
    
xcp.signals(994).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o1_h1';
    
xcp.signals(995).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o2_b4';
    
xcp.signals(996).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o1_g';
    
xcp.signals(997).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o2_b';
    
xcp.signals(998).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o3_k';
    
xcp.signals(999).symbol =  'may23_B.sf_SDOreadmachine_i.enable';
    
xcp.signals(1000).symbol =  'may23_B.sf_SDOreadmachine_i.complete';
    
xcp.signals(1001).symbol =  'may23_B.sf_values.outVal';
    
xcp.signals(1002).symbol =  'may23_B.sf_values2.outVal';
    
xcp.signals(1003).symbol =  'may23_B.readAddr_a';
    
xcp.signals(1004).symbol =  'may23_B.DataTypeConversion1_iw';
    
xcp.signals(1005).symbol =  'may23_B.DataTypeConversion2_h5';
    
xcp.signals(1006).symbol =  'may23_B.convert_o';
    
xcp.signals(1007).symbol =  'may23_B.convert1_n';
    
xcp.signals(1008).symbol =  'may23_B.convert2_e';
    
xcp.signals(1009).symbol =  'may23_B.convert3_b';
    
xcp.signals(1010).symbol =  'may23_B.status_n';
    
xcp.signals(1011).symbol =  'may23_B.Memory_g4';
    
xcp.signals(1012).symbol =  'may23_B.sf_MATLABFunction_ae.out_err_code';
    
xcp.signals(1013).symbol =  'may23_B.sf_SDOwritemachine.enable';
    
xcp.signals(1014).symbol =  'may23_B.sf_SDOwritemachine.complete';
    
xcp.signals(1015).symbol =  'may23_B.sf_convert.y';
    
xcp.signals(1016).symbol =  'may23_B.writeData_g';
    
xcp.signals(1017).symbol =  'may23_B.DataTypeConversion1_p2';
    
xcp.signals(1018).symbol =  'may23_B.DataTypeConversion2_a';
    
xcp.signals(1019).symbol =  'may23_B.status_d';
    
xcp.signals(1020).symbol =  'may23_B.Memory_n';
    
xcp.signals(1021).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o1_c';
    
xcp.signals(1022).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o2_a';
    
xcp.signals(1023).symbol =  'may23_B.Memory_k5';
    
xcp.signals(1024).symbol =  'may23_B.Memory1_g';
    
xcp.signals(1025).symbol =  'may23_B.Memory2_a';
    
xcp.signals(1026).symbol =  'may23_B.RateTransition_gd';
    
xcp.signals(1027).symbol =  'may23_B.RateTransition1_i';
    
xcp.signals(1028).symbol =  'may23_B.RateTransition2_ph';
    
xcp.signals(1029).symbol =  'may23_B.sf_Whistlestate_l.ControlWord';
    
xcp.signals(1030).symbol =  'may23_B.sf_Whistlestate_l.motorStatus';
    
xcp.signals(1031).symbol =  'may23_B.sf_Whistlestate_l.isPermFaulted';
    
xcp.signals(1032).symbol =  'may23_B.sf_cleanword_e.out_val';
    
xcp.signals(1033).symbol =  'may23_B.Memory_k';
    
xcp.signals(1034).symbol =  'may23_B.sf_Whistlestate_m.ControlWord';
    
xcp.signals(1035).symbol =  'may23_B.sf_Whistlestate_m.motorStatus';
    
xcp.signals(1036).symbol =  'may23_B.sf_Whistlestate_m.isPermFaulted';
    
xcp.signals(1037).symbol =  'may23_B.sf_cleanword_i.out_val';
    
xcp.signals(1038).symbol =  'may23_B.Memory_j';
    
xcp.signals(1039).symbol =  'may23_B.sf_AbsEncodermachine_j.setupData';
    
xcp.signals(1040).symbol =  'may23_B.sf_AbsEncodermachine_j.SDORequest';
    
xcp.signals(1041).symbol =  'may23_B.sf_AbsEncodermachine_j.encoderOutputs';
    
xcp.signals(1042).symbol =  'may23_B.sf_AbsEncodermachine_j.complete';
    
xcp.signals(1043).symbol =  'may23_B.sf_setupvalues_p.setupValues';
    
xcp.signals(1044).symbol =  'may23_B.sf_setupvalues_p.setupValuesCount';
    
xcp.signals(1045).symbol =  'may23_B.sf_setupvalues_p.pollValues';
    
xcp.signals(1046).symbol =  'may23_B.sf_setupvalues_p.encoderValues';
    
xcp.signals(1047).symbol =  'may23_B.sf_setupvalues_p.encoderValuesCount';
    
xcp.signals(1048).symbol =  'may23_B.Memory_pj';
    
xcp.signals(1049).symbol =  'may23_B.Memory1_lg';
    
xcp.signals(1050).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o1_d';
    
xcp.signals(1051).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o2_g';
    
xcp.signals(1052).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o1_d2';
    
xcp.signals(1053).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o2_f';
    
xcp.signals(1054).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o3_c';
    
xcp.signals(1055).symbol =  'may23_B.sf_AbsEncodermachine_n.setupData';
    
xcp.signals(1056).symbol =  'may23_B.sf_AbsEncodermachine_n.SDORequest';
    
xcp.signals(1057).symbol =  'may23_B.sf_AbsEncodermachine_n.encoderOutputs';
    
xcp.signals(1058).symbol =  'may23_B.sf_AbsEncodermachine_n.complete';
    
xcp.signals(1059).symbol =  'may23_B.sf_setupvalues_o.setupValues';
    
xcp.signals(1060).symbol =  'may23_B.sf_setupvalues_o.setupValuesCount';
    
xcp.signals(1061).symbol =  'may23_B.sf_setupvalues_o.pollValues';
    
xcp.signals(1062).symbol =  'may23_B.sf_setupvalues_o.encoderValues';
    
xcp.signals(1063).symbol =  'may23_B.sf_setupvalues_o.encoderValuesCount';
    
xcp.signals(1064).symbol =  'may23_B.Memory_i';
    
xcp.signals(1065).symbol =  'may23_B.Memory1_n';
    
xcp.signals(1066).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o1_f';
    
xcp.signals(1067).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o2_f';
    
xcp.signals(1068).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o1_k1';
    
xcp.signals(1069).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o2';
    
xcp.signals(1070).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o3';
    
xcp.signals(1071).symbol =  'may23_B.sf_SDOreadmachine_f.enable';
    
xcp.signals(1072).symbol =  'may23_B.sf_SDOreadmachine_f.complete';
    
xcp.signals(1073).symbol =  'may23_B.sf_values_p.outVal';
    
xcp.signals(1074).symbol =  'may23_B.sf_values2_a.outVal';
    
xcp.signals(1075).symbol =  'may23_B.readAddr';
    
xcp.signals(1076).symbol =  'may23_B.Conversion1_o';
    
xcp.signals(1077).symbol =  'may23_B.Conversion2_i';
    
xcp.signals(1078).symbol =  'may23_B.convert_b';
    
xcp.signals(1079).symbol =  'may23_B.convert1';
    
xcp.signals(1080).symbol =  'may23_B.convert2';
    
xcp.signals(1081).symbol =  'may23_B.convert3';
    
xcp.signals(1082).symbol =  'may23_B.status_f';
    
xcp.signals(1083).symbol =  'may23_B.Memory_ms';
    
xcp.signals(1084).symbol =  'may23_B.sf_MATLABFunction_c.out_err_code';
    
xcp.signals(1085).symbol =  'may23_B.sf_SDOwritemachine_g.enable';
    
xcp.signals(1086).symbol =  'may23_B.sf_SDOwritemachine_g.complete';
    
xcp.signals(1087).symbol =  'may23_B.sf_convert_n.y';
    
xcp.signals(1088).symbol =  'may23_B.writeData';
    
xcp.signals(1089).symbol =  'may23_B.DataTypeConversion1_du';
    
xcp.signals(1090).symbol =  'may23_B.DataTypeConversion2_i0';
    
xcp.signals(1091).symbol =  'may23_B.status';
    
xcp.signals(1092).symbol =  'may23_B.Memory_oh';
    
xcp.signals(1093).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o1';
    
xcp.signals(1094).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o2';
    
xcp.signals(1095).symbol =  'may23_B.sf_MATLABFunction1_c.mode';
    
xcp.signals(1096).symbol =  'may23_B.Memory_o';
    
xcp.signals(1097).symbol =  'may23_B.Memory1_ew';
    
xcp.signals(1098).symbol =  'may23_B.Memory2_p';
    
xcp.signals(1099).symbol =  'may23_B.RateTransition_ep';
    
xcp.signals(1100).symbol =  'may23_B.RateTransition1_p';
    
xcp.signals(1101).symbol =  'may23_B.RateTransition2_j';
    
xcp.signals(1102).symbol =  'may23_B.FixPtSum1_j';
    
xcp.signals(1103).symbol =  'may23_B.FixPtSwitch_e';
    
xcp.signals(1104).symbol =  'may23_B.filteredVels';
    
xcp.signals(1105).symbol =  'may23_B.outVals';
    
xcp.signals(1106).symbol =  'may23_B.FixPtRelationalOperator';
    
xcp.signals(1107).symbol =  'may23_B.Uk1';
    
xcp.signals(1108).symbol =  'may23_B.ByteReversal_h';
    
xcp.signals(1109).symbol =  'may23_B.ByteReversal1_l';
    
xcp.signals(1110).symbol =  'may23_B.ByteReversal2';
    
xcp.signals(1111).symbol =  'may23_B.Pack_b';
    
xcp.signals(1112).symbol =  'may23_B.Switch_n';
    
xcp.signals(1113).symbol =  'may23_ConstB.Width_c';
    
xcp.signals(1114).symbol =  'may23_B.ByteReversal';
    
xcp.signals(1115).symbol =  'may23_B.ByteReversal1_h';
    
xcp.signals(1116).symbol =  'may23_B.ByteReversal2_j';
    
xcp.signals(1117).symbol =  'may23_B.Pack';
    
xcp.signals(1118).symbol =  'may23_B.Switch_a';
    
xcp.signals(1119).symbol =  'may23_ConstB.Width_i';
    
xcp.signals(1120).symbol =  'may23_B.FixPtRelationalOperator_n';
    
xcp.signals(1121).symbol =  'may23_B.Uk1_o';
    
xcp.signals(1122).symbol =  'may23_B.y_h';
    
xcp.signals(1123).symbol =  'may23_B.DataTypeConversion_g5';
    
xcp.signals(1124).symbol =  'may23_B.DPRAMReadValue';
    
xcp.signals(1125).symbol =  'may23_B.UnitDelay';
    
xcp.signals(1126).symbol =  'may23_B.UnitDelay1';
    
xcp.signals(1127).symbol =  'may23_B.UnitDelay2';
    
xcp.signals(1128).symbol =  'may23_B.UnitDelay3';
    
xcp.signals(1129).symbol =  'may23_B.FixPtSum1_l';
    
xcp.signals(1130).symbol =  'may23_B.FixPtSwitch_f';
    
xcp.signals(1131).symbol =  'may23_B.Output_d';
    
xcp.signals(1132).symbol =  'may23_B.FixPtSum1_c';
    
xcp.signals(1133).symbol =  'may23_B.FixPtSwitch_i';
    
xcp.signals(1134).symbol =  'may23_B.sf_parsestatusregister.allOK';
    
xcp.signals(1135).symbol =  'may23_B.sf_parsestatusregister.ampStatus';
    
xcp.signals(1136).symbol =  'may23_B.sf_parsestatusregister.servoEnabled';
    
xcp.signals(1137).symbol =  'may23_B.sf_parsestatusregister.faultFound';
    
xcp.signals(1138).symbol =  'may23_B.sf_parsestatusregister.currentLimitEnabled';
    
xcp.signals(1139).symbol =  'may23_B.sf_parsestatusregister.eStopOut';
    
xcp.signals(1140).symbol =  'may23_B.sf_parsestatusregister.motorOn';
    
xcp.signals(1141).symbol =  'may23_B.A1M1Convert';
    
xcp.signals(1142).symbol =  'may23_B.DataTypeConversion1_jv';
    
xcp.signals(1143).symbol =  'may23_B.Statusword_d';
    
xcp.signals(1144).symbol =  'may23_B.statusregister_n';
    
xcp.signals(1145).symbol =  'may23_B.primaryposition_n';
    
xcp.signals(1146).symbol =  'may23_B.secondaryposition_k';
    
xcp.signals(1147).symbol =  'may23_B.primaryvelocity_j';
    
xcp.signals(1148).symbol =  'may23_B.torque_f';
    
xcp.signals(1149).symbol =  'may23_B.digitalinputs';
    
xcp.signals(1150).symbol =  'may23_B.actualmodeofoperation_h';
    
xcp.signals(1151).symbol =  'may23_B.Compare_jc';
    
xcp.signals(1152).symbol =  'may23_B.sf_ReadEMCY.triggerCountRead';
    
xcp.signals(1153).symbol =  'may23_B.sf_ReadEMCY.emcyReadTrigger';
    
xcp.signals(1154).symbol =  'may23_B.sf_ReadEMCY.countOverwriteTrigger';
    
xcp.signals(1155).symbol =  'may23_B.sf_ReadEMCY.emcyValPump';
    
xcp.signals(1156).symbol =  'may23_B.sf_faultmonitor.triggerFaultRead';
    
xcp.signals(1157).symbol =  'may23_B.sf_passemcy.EMCYMsg';
    
xcp.signals(1158).symbol =  'may23_B.driveID_p';
    
xcp.signals(1159).symbol =  'may23_B.DataTypeConversion_lz';
    
xcp.signals(1160).symbol =  'may23_B.LinkAngle_b';
    
xcp.signals(1161).symbol =  'may23_B.PrimaryLinkAngle_h';
    
xcp.signals(1162).symbol =  'may23_B.PrimaryLinkVel_b';
    
xcp.signals(1163).symbol =  'may23_B.torque_l0';
    
xcp.signals(1164).symbol =  'may23_B.digitalInputs_o';
    
xcp.signals(1165).symbol =  'may23_B.digitalDiagnostics_a';
    
xcp.signals(1166).symbol =  'may23_B.calibrationButton_n';
    
xcp.signals(1167).symbol =  'may23_B.epGripSensor_i';
    
xcp.signals(1168).symbol =  'may23_B.L2select_k';
    
xcp.signals(1169).symbol =  'may23_B.L2select1_p';
    
xcp.signals(1170).symbol =  'may23_B.L2select2_l';
    
xcp.signals(1171).symbol =  'may23_B.L2select3_a';
    
xcp.signals(1172).symbol =  'may23_B.L2select4_g';
    
xcp.signals(1173).symbol =  'may23_B.L2select5_o';
    
xcp.signals(1174).symbol =  'may23_B.sf_parsestatusregister1.allOK';
    
xcp.signals(1175).symbol =  'may23_B.sf_parsestatusregister1.ampStatus';
    
xcp.signals(1176).symbol =  'may23_B.sf_parsestatusregister1.servoEnabled';
    
xcp.signals(1177).symbol =  'may23_B.sf_parsestatusregister1.faultFound';
    
xcp.signals(1178).symbol =  'may23_B.sf_parsestatusregister1.currentLimitEnabled';
    
xcp.signals(1179).symbol =  'may23_B.sf_parsestatusregister1.eStopOut';
    
xcp.signals(1180).symbol =  'may23_B.sf_parsestatusregister1.motorOn';
    
xcp.signals(1181).symbol =  'may23_B.A1M2Convert';
    
xcp.signals(1182).symbol =  'may23_B.DataTypeConversion_ch';
    
xcp.signals(1183).symbol =  'may23_B.Statusword_n';
    
xcp.signals(1184).symbol =  'may23_B.statusregister_h';
    
xcp.signals(1185).symbol =  'may23_B.primaryposition_o';
    
xcp.signals(1186).symbol =  'may23_B.secondaryposition_e';
    
xcp.signals(1187).symbol =  'may23_B.primaryvelocity_jy';
    
xcp.signals(1188).symbol =  'may23_B.torque_m';
    
xcp.signals(1189).symbol =  'may23_B.digitalinputs_n';
    
xcp.signals(1190).symbol =  'may23_B.actualmodeofoperation_hn';
    
xcp.signals(1191).symbol =  'may23_B.Compare_fs';
    
xcp.signals(1192).symbol =  'may23_B.sf_ReadEMCY_h.triggerCountRead';
    
xcp.signals(1193).symbol =  'may23_B.sf_ReadEMCY_h.emcyReadTrigger';
    
xcp.signals(1194).symbol =  'may23_B.sf_ReadEMCY_h.countOverwriteTrigger';
    
xcp.signals(1195).symbol =  'may23_B.sf_ReadEMCY_h.emcyValPump';
    
xcp.signals(1196).symbol =  'may23_B.sf_faultmonitor_m.triggerFaultRead';
    
xcp.signals(1197).symbol =  'may23_B.sf_passemcy_b.EMCYMsg';
    
xcp.signals(1198).symbol =  'may23_B.driveID_o';
    
xcp.signals(1199).symbol =  'may23_B.DataTypeConversion_bu';
    
xcp.signals(1200).symbol =  'may23_B.LinkAngle_a';
    
xcp.signals(1201).symbol =  'may23_B.PrimaryLinkAngle_f';
    
xcp.signals(1202).symbol =  'may23_B.PrimaryLinkVel_d';
    
xcp.signals(1203).symbol =  'may23_B.torque_l';
    
xcp.signals(1204).symbol =  'may23_B.digitalInputs_p';
    
xcp.signals(1205).symbol =  'may23_B.digitalDiagnostics_b';
    
xcp.signals(1206).symbol =  'may23_B.L2select_p';
    
xcp.signals(1207).symbol =  'may23_B.L2select1_pl';
    
xcp.signals(1208).symbol =  'may23_B.L2select2_mv';
    
xcp.signals(1209).symbol =  'may23_B.L2select3_i';
    
xcp.signals(1210).symbol =  'may23_B.L2select4_k';
    
xcp.signals(1211).symbol =  'may23_B.L2select5_j';
    
xcp.signals(1212).symbol =  'may23_B.sf_MATLABFunction_mr.out_err_code';
    
xcp.signals(1213).symbol =  'may23_B.sf_converter.uint32Out';
    
xcp.signals(1214).symbol =  'may23_B.sf_converter.int32Out';
    
xcp.signals(1215).symbol =  'may23_B.sf_converter.doubleOut';
    
xcp.signals(1216).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o1_p';
    
xcp.signals(1217).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o2_ee';
    
xcp.signals(1218).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o3_a';
    
xcp.signals(1219).symbol =  'may23_B.sf_MATLABFunction_j.out_err_code';
    
xcp.signals(1220).symbol =  'may23_B.sf_converter_e.uint32Out';
    
xcp.signals(1221).symbol =  'may23_B.sf_converter_e.int32Out';
    
xcp.signals(1222).symbol =  'may23_B.sf_converter_e.doubleOut';
    
xcp.signals(1223).symbol =  'may23_B.DataTypeConversion_bj';
    
xcp.signals(1224).symbol =  'may23_B.DataTypeConversion1_j1';
    
xcp.signals(1225).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o1_oc';
    
xcp.signals(1226).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o2_c';
    
xcp.signals(1227).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o3_b';
    
xcp.signals(1228).symbol =  'may23_B.sf_MATLABFunction_e.out_err_code';
    
xcp.signals(1229).symbol =  'may23_B.sf_converter_a.uint32Out';
    
xcp.signals(1230).symbol =  'may23_B.sf_converter_a.int32Out';
    
xcp.signals(1231).symbol =  'may23_B.sf_converter_a.doubleOut';
    
xcp.signals(1232).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o1_e';
    
xcp.signals(1233).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o2_e';
    
xcp.signals(1234).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o3_py';
    
xcp.signals(1235).symbol =  'may23_B.sf_parsestatusregister1_g.allOK';
    
xcp.signals(1236).symbol =  'may23_B.sf_parsestatusregister1_g.ampStatus';
    
xcp.signals(1237).symbol =  'may23_B.sf_parsestatusregister1_g.servoEnabled';
    
xcp.signals(1238).symbol =  'may23_B.sf_parsestatusregister1_g.faultFound';
    
xcp.signals(1239).symbol =  'may23_B.sf_parsestatusregister1_g.currentLimitEnabled';
    
xcp.signals(1240).symbol =  'may23_B.sf_parsestatusregister1_g.eStopOut';
    
xcp.signals(1241).symbol =  'may23_B.sf_parsestatusregister1_g.motorOn';
    
xcp.signals(1242).symbol =  'may23_B.A2M1Convert';
    
xcp.signals(1243).symbol =  'may23_B.DataTypeConversion_mme';
    
xcp.signals(1244).symbol =  'may23_B.Statusword';
    
xcp.signals(1245).symbol =  'may23_B.BKINPDOReceiveElmoDrive_o2';
    
xcp.signals(1246).symbol =  'may23_B.primaryposition';
    
xcp.signals(1247).symbol =  'may23_B.secondaryposition';
    
xcp.signals(1248).symbol =  'may23_B.primaryvelocity';
    
xcp.signals(1249).symbol =  'may23_B.torque_b';
    
xcp.signals(1250).symbol =  'may23_B.digitalinput';
    
xcp.signals(1251).symbol =  'may23_B.actualmodeofoperation';
    
xcp.signals(1252).symbol =  'may23_B.Compare_ew';
    
xcp.signals(1253).symbol =  'may23_B.sf_ReadEMCY_b.triggerCountRead';
    
xcp.signals(1254).symbol =  'may23_B.sf_ReadEMCY_b.emcyReadTrigger';
    
xcp.signals(1255).symbol =  'may23_B.sf_ReadEMCY_b.countOverwriteTrigger';
    
xcp.signals(1256).symbol =  'may23_B.sf_ReadEMCY_b.emcyValPump';
    
xcp.signals(1257).symbol =  'may23_B.sf_faultmonitor_f.triggerFaultRead';
    
xcp.signals(1258).symbol =  'may23_B.sf_passemcy_c.EMCYMsg';
    
xcp.signals(1259).symbol =  'may23_B.driveID_d';
    
xcp.signals(1260).symbol =  'may23_B.DataTypeConversion_pw';
    
xcp.signals(1261).symbol =  'may23_B.LinkAngle_i';
    
xcp.signals(1262).symbol =  'may23_B.PrimaryLinkAngle_j';
    
xcp.signals(1263).symbol =  'may23_B.PrimaryLinkVel_k';
    
xcp.signals(1264).symbol =  'may23_B.torque_h';
    
xcp.signals(1265).symbol =  'may23_B.digitalInputs_g';
    
xcp.signals(1266).symbol =  'may23_B.digitalDiagnostics_p';
    
xcp.signals(1267).symbol =  'may23_B.calibrationButton';
    
xcp.signals(1268).symbol =  'may23_B.epGripSensor';
    
xcp.signals(1269).symbol =  'may23_B.offsetrads';
    
xcp.signals(1270).symbol =  'may23_B.encorient';
    
xcp.signals(1271).symbol =  'may23_B.L2select2';
    
xcp.signals(1272).symbol =  'may23_B.L2select3';
    
xcp.signals(1273).symbol =  'may23_B.L2select4';
    
xcp.signals(1274).symbol =  'may23_B.L2select5';
    
xcp.signals(1275).symbol =  'may23_B.sf_parsestatusregister1_d.allOK';
    
xcp.signals(1276).symbol =  'may23_B.sf_parsestatusregister1_d.ampStatus';
    
xcp.signals(1277).symbol =  'may23_B.sf_parsestatusregister1_d.servoEnabled';
    
xcp.signals(1278).symbol =  'may23_B.sf_parsestatusregister1_d.faultFound';
    
xcp.signals(1279).symbol =  'may23_B.sf_parsestatusregister1_d.currentLimitEnabled';
    
xcp.signals(1280).symbol =  'may23_B.sf_parsestatusregister1_d.eStopOut';
    
xcp.signals(1281).symbol =  'may23_B.sf_parsestatusregister1_d.motorOn';
    
xcp.signals(1282).symbol =  'may23_B.A2M2Convert';
    
xcp.signals(1283).symbol =  'may23_B.DataTypeConversion_ex';
    
xcp.signals(1284).symbol =  'may23_B.statusword';
    
xcp.signals(1285).symbol =  'may23_B.statusregister';
    
xcp.signals(1286).symbol =  'may23_B.positionprimary';
    
xcp.signals(1287).symbol =  'may23_B.positionsecondary';
    
xcp.signals(1288).symbol =  'may23_B.velocityprimary';
    
xcp.signals(1289).symbol =  'may23_B.torque_i';
    
xcp.signals(1290).symbol =  'may23_B.digitalinput_o';
    
xcp.signals(1291).symbol =  'may23_B.actualmodeofoperation_c';
    
xcp.signals(1292).symbol =  'may23_B.Compare_c';
    
xcp.signals(1293).symbol =  'may23_B.sf_ReadEMCY_o.triggerCountRead';
    
xcp.signals(1294).symbol =  'may23_B.sf_ReadEMCY_o.emcyReadTrigger';
    
xcp.signals(1295).symbol =  'may23_B.sf_ReadEMCY_o.countOverwriteTrigger';
    
xcp.signals(1296).symbol =  'may23_B.sf_ReadEMCY_o.emcyValPump';
    
xcp.signals(1297).symbol =  'may23_B.sf_faultmonitor_h.triggerFaultRead';
    
xcp.signals(1298).symbol =  'may23_B.sf_passemcy_e.EMCYMsg';
    
xcp.signals(1299).symbol =  'may23_B.driveID';
    
xcp.signals(1300).symbol =  'may23_B.DataTypeConversion_mm';
    
xcp.signals(1301).symbol =  'may23_B.LinkAngle';
    
xcp.signals(1302).symbol =  'may23_B.PrimaryLinkAngle';
    
xcp.signals(1303).symbol =  'may23_B.PrimaryLinkVel';
    
xcp.signals(1304).symbol =  'may23_B.torque';
    
xcp.signals(1305).symbol =  'may23_B.digitalInputs';
    
xcp.signals(1306).symbol =  'may23_B.digitalDiagnostics';
    
xcp.signals(1307).symbol =  'may23_B.L2select';
    
xcp.signals(1308).symbol =  'may23_B.L2select1';
    
xcp.signals(1309).symbol =  'may23_B.L2select2_m';
    
xcp.signals(1310).symbol =  'may23_B.L2select3_l';
    
xcp.signals(1311).symbol =  'may23_B.L2select4_o';
    
xcp.signals(1312).symbol =  'may23_B.L2select5_k';
    
xcp.signals(1313).symbol =  'may23_B.sf_MATLABFunction_f1.out_err_code';
    
xcp.signals(1314).symbol =  'may23_B.sf_converter_f.uint32Out';
    
xcp.signals(1315).symbol =  'may23_B.sf_converter_f.int32Out';
    
xcp.signals(1316).symbol =  'may23_B.sf_converter_f.doubleOut';
    
xcp.signals(1317).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o1_g';
    
xcp.signals(1318).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o2_g';
    
xcp.signals(1319).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o3_p';
    
xcp.signals(1320).symbol =  'may23_B.sf_converter_ai.uint32Out';
    
xcp.signals(1321).symbol =  'may23_B.sf_converter_ai.int32Out';
    
xcp.signals(1322).symbol =  'may23_B.sf_converter_ai.doubleOut';
    
xcp.signals(1323).symbol =  'may23_B.DataTypeConversion_a';
    
xcp.signals(1324).symbol =  'may23_B.DataTypeConversion1_e';
    
xcp.signals(1325).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o1_o';
    
xcp.signals(1326).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o2_n';
    
xcp.signals(1327).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o3_h';
    
xcp.signals(1328).symbol =  'may23_B.sf_MATLABFunction_g3.out_err_code';
    
xcp.signals(1329).symbol =  'may23_B.sf_converter_c.uint32Out';
    
xcp.signals(1330).symbol =  'may23_B.sf_converter_c.int32Out';
    
xcp.signals(1331).symbol =  'may23_B.sf_converter_c.doubleOut';
    
xcp.signals(1332).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o1';
    
xcp.signals(1333).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o2';
    
xcp.signals(1334).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload1_o3';
    
xcp.signals(1335).symbol =  'may23_B.Output_c';
    
xcp.signals(1336).symbol =  'may23_B.DataTypeConversion_c';
    
xcp.signals(1337).symbol =  'may23_B.DataTypeConversion1_g';
    
xcp.signals(1338).symbol =  'may23_B.DataTypeConversion2_o';
    
xcp.signals(1339).symbol =  'may23_B.Read_h';
    
xcp.signals(1340).symbol =  'may23_B.DataTypeConversion_n3';
    
xcp.signals(1341).symbol =  'may23_B.DataTypeConversion1_o3';
    
xcp.signals(1342).symbol =  'may23_B.FixPtSum1_g';
    
xcp.signals(1343).symbol =  'may23_B.FixPtSwitch_o';
    
xcp.signals(1344).symbol =  'may23_B.Switch_d';
    
xcp.signals(1345).symbol =  'may23_B.Switch_mm';
    
xcp.signals(1346).symbol =  'may23_B.sf_MATLABFunction_k.prime_out';
    
xcp.signals(1347).symbol =  'may23_B.sf_MATLABFunction_k.sec_out';
    
xcp.signals(1348).symbol =  'may23_B.sf_MATLABFunction_gi.out_err_code';
    
xcp.signals(1349).symbol =  'may23_B.DataTypeConversion_ol';
    
xcp.signals(1350).symbol =  'may23_B.DataTypeConversion1_p';
    
xcp.signals(1351).symbol =  'may23_B.DataTypeConversion2_i';
    
xcp.signals(1352).symbol =  'may23_B.Memory_f';
    
xcp.signals(1353).symbol =  'may23_B.RateTransition_kr';
    
xcp.signals(1354).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o1_d';
    
xcp.signals(1355).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o2_lu';
    
xcp.signals(1356).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o3_cf';
    
xcp.signals(1357).symbol =  'may23_B.sf_MATLABFunction_b1.out_err_code';
    
xcp.signals(1358).symbol =  'may23_B.DataTypeConversion_lg';
    
xcp.signals(1359).symbol =  'may23_B.Memory_gu';
    
xcp.signals(1360).symbol =  'may23_B.RateTransition_lt';
    
xcp.signals(1361).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o1_ko';
    
xcp.signals(1362).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o2_h';
    
xcp.signals(1363).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o3_p';
    
xcp.signals(1364).symbol =  'may23_B.DataTypeConversion_ll';
    
xcp.signals(1365).symbol =  'may23_B.DataTypeConversion1_m3';
    
xcp.signals(1366).symbol =  'may23_B.Memory_es';
    
xcp.signals(1367).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o1_p';
    
xcp.signals(1368).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o2_p';
    
xcp.signals(1369).symbol =  'may23_B.Switch_p';
    
xcp.signals(1370).symbol =  'may23_B.Switch_pj';
    
xcp.signals(1371).symbol =  'may23_B.sf_MATLABFunction_m0.prime_out';
    
xcp.signals(1372).symbol =  'may23_B.sf_MATLABFunction_m0.sec_out';
    
xcp.signals(1373).symbol =  'may23_B.sf_MATLABFunction_lu.out_err_code';
    
xcp.signals(1374).symbol =  'may23_B.DataTypeConversion_mx';
    
xcp.signals(1375).symbol =  'may23_B.DataTypeConversion1_nb';
    
xcp.signals(1376).symbol =  'may23_B.DataTypeConversion2_g';
    
xcp.signals(1377).symbol =  'may23_B.Memory_c4';
    
xcp.signals(1378).symbol =  'may23_B.RateTransition_n';
    
xcp.signals(1379).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o1_k';
    
xcp.signals(1380).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o2_i';
    
xcp.signals(1381).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o3_nd';
    
xcp.signals(1382).symbol =  'may23_B.sf_MATLABFunction_hz.out_err_code';
    
xcp.signals(1383).symbol =  'may23_B.DataTypeConversion_l';
    
xcp.signals(1384).symbol =  'may23_B.Memory_iv';
    
xcp.signals(1385).symbol =  'may23_B.RateTransition_h';
    
xcp.signals(1386).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o1_a';
    
xcp.signals(1387).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o2_bg';
    
xcp.signals(1388).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o3_ea';
    
xcp.signals(1389).symbol =  'may23_B.DataTypeConversion_pa3';
    
xcp.signals(1390).symbol =  'may23_B.DataTypeConversion1_m';
    
xcp.signals(1391).symbol =  'may23_B.Memory_ju';
    
xcp.signals(1392).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o1_o';
    
xcp.signals(1393).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o2_m';
    
xcp.signals(1394).symbol =  'may23_B.Switch_l';
    
xcp.signals(1395).symbol =  'may23_B.Switch_g3';
    
xcp.signals(1396).symbol =  'may23_B.sf_MATLABFunction_o.prime_out';
    
xcp.signals(1397).symbol =  'may23_B.sf_MATLABFunction_o.sec_out';
    
xcp.signals(1398).symbol =  'may23_B.sf_MATLABFunction_hm.out_err_code';
    
xcp.signals(1399).symbol =  'may23_B.DataTypeConversion_k';
    
xcp.signals(1400).symbol =  'may23_B.DataTypeConversion1_n';
    
xcp.signals(1401).symbol =  'may23_B.DataTypeConversion2_b';
    
xcp.signals(1402).symbol =  'may23_B.Memory_c';
    
xcp.signals(1403).symbol =  'may23_B.RateTransition_m';
    
xcp.signals(1404).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o1_n';
    
xcp.signals(1405).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o2_l';
    
xcp.signals(1406).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o3_h';
    
xcp.signals(1407).symbol =  'may23_B.sf_MATLABFunction_m2.out_err_code';
    
xcp.signals(1408).symbol =  'may23_B.DataTypeConversion_n';
    
xcp.signals(1409).symbol =  'may23_B.Memory_g3';
    
xcp.signals(1410).symbol =  'may23_B.RateTransition_gq';
    
xcp.signals(1411).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o1_m';
    
xcp.signals(1412).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o2_k';
    
xcp.signals(1413).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o3_e5';
    
xcp.signals(1414).symbol =  'may23_B.DataTypeConversion_if';
    
xcp.signals(1415).symbol =  'may23_B.DataTypeConversion1_l';
    
xcp.signals(1416).symbol =  'may23_B.Memory_e';
    
xcp.signals(1417).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o1_f2';
    
xcp.signals(1418).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o2_b';
    
xcp.signals(1419).symbol =  'may23_B.Switch_j';
    
xcp.signals(1420).symbol =  'may23_B.Switch_mq';
    
xcp.signals(1421).symbol =  'may23_B.sf_MATLABFunction_ac.prime_out';
    
xcp.signals(1422).symbol =  'may23_B.sf_MATLABFunction_ac.sec_out';
    
xcp.signals(1423).symbol =  'may23_B.sf_MATLABFunction_hj.out_err_code';
    
xcp.signals(1424).symbol =  'may23_B.DataTypeConversion_b5';
    
xcp.signals(1425).symbol =  'may23_B.DataTypeConversion1_my';
    
xcp.signals(1426).symbol =  'may23_B.DataTypeConversion2_ht';
    
xcp.signals(1427).symbol =  'may23_B.Memory_gv';
    
xcp.signals(1428).symbol =  'may23_B.RateTransition_l';
    
xcp.signals(1429).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o1';
    
xcp.signals(1430).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o2_p';
    
xcp.signals(1431).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o3_l';
    
xcp.signals(1432).symbol =  'may23_B.sf_MATLABFunction_lj.out_err_code';
    
xcp.signals(1433).symbol =  'may23_B.DataTypeConversion_p1';
    
xcp.signals(1434).symbol =  'may23_B.Memory_ds';
    
xcp.signals(1435).symbol =  'may23_B.RateTransition_g';
    
xcp.signals(1436).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o1_n3';
    
xcp.signals(1437).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o2_a';
    
xcp.signals(1438).symbol =  'may23_B.BKINEtherCATAsyncSDOUpload_o3_e';
    
xcp.signals(1439).symbol =  'may23_B.DataTypeConversion_j';
    
xcp.signals(1440).symbol =  'may23_B.DataTypeConversion1_gy';
    
xcp.signals(1441).symbol =  'may23_B.Memory_g';
    
xcp.signals(1442).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o1_h';
    
xcp.signals(1443).symbol =  'may23_B.BKINEtherCATAsyncSDODownload_o2_h';
    
xcp.signals(1444).symbol =  'may23_B.FixPtSum1_lg';
    
xcp.signals(1445).symbol =  'may23_B.FixPtSwitch_ey';
         
xcp.parameters(1).symbol = 'may23_P.GUIControl_tp_table_rows';
xcp.parameters(1).size   =  1;       
xcp.parameters(1).dtname = 'real_T'; 
xcp.parameters(2).baseaddr = '&may23_P.GUIControl_tp_table_rows';     
         
xcp.parameters(2).symbol = 'may23_P.KINARM_EP_Apply_Loads_up_duration';
xcp.parameters(2).size   =  1;       
xcp.parameters(2).dtname = 'real_T'; 
xcp.parameters(3).baseaddr = '&may23_P.KINARM_EP_Apply_Loads_up_duration';     
         
xcp.parameters(3).symbol = 'may23_P.KINARM_EP_Apply_Loads_down_duration';
xcp.parameters(3).size   =  1;       
xcp.parameters(3).dtname = 'real_T'; 
xcp.parameters(4).baseaddr = '&may23_P.KINARM_EP_Apply_Loads_down_duration';     
         
xcp.parameters(4).symbol = 'may23_P.KINARM_EP_Apply_Loads_max_force';
xcp.parameters(4).size   =  1;       
xcp.parameters(4).dtname = 'real_T'; 
xcp.parameters(5).baseaddr = '&may23_P.KINARM_EP_Apply_Loads_max_force';     
         
xcp.parameters(5).symbol = 'may23_P.KINARM_Exo_Apply_Loads_up_duration';
xcp.parameters(5).size   =  1;       
xcp.parameters(5).dtname = 'real_T'; 
xcp.parameters(6).baseaddr = '&may23_P.KINARM_Exo_Apply_Loads_up_duration';     
         
xcp.parameters(6).symbol = 'may23_P.KINARM_Exo_Apply_Loads_down_duration';
xcp.parameters(6).size   =  1;       
xcp.parameters(6).dtname = 'real_T'; 
xcp.parameters(7).baseaddr = '&may23_P.KINARM_Exo_Apply_Loads_down_duration';     
         
xcp.parameters(7).symbol = 'may23_P.KINARM_Exo_Apply_Loads_max_torque';
xcp.parameters(7).size   =  1;       
xcp.parameters(7).dtname = 'real_T'; 
xcp.parameters(8).baseaddr = '&may23_P.KINARM_Exo_Apply_Loads_max_torque';     
         
xcp.parameters(8).symbol = 'may23_P.KINARM_Exo_Apply_Loads_limit_motors';
xcp.parameters(8).size   =  1;       
xcp.parameters(8).dtname = 'real_T'; 
xcp.parameters(9).baseaddr = '&may23_P.KINARM_Exo_Apply_Loads_limit_motors';     
         
xcp.parameters(9).symbol = 'may23_P.KINARM_HandInBarrier_use_dominant_hand';
xcp.parameters(9).size   =  1;       
xcp.parameters(9).dtname = 'real_T'; 
xcp.parameters(10).baseaddr = '&may23_P.KINARM_HandInBarrier_use_dominant_hand';     
         
xcp.parameters(10).symbol = 'may23_P.KINARM_HandInBarrier_target_type';
xcp.parameters(10).size   =  1;       
xcp.parameters(10).dtname = 'real_T'; 
xcp.parameters(11).baseaddr = '&may23_P.KINARM_HandInBarrier_target_type';     
         
xcp.parameters(11).symbol = 'may23_P.KINARM_HandInBarrier_num_states';
xcp.parameters(11).size   =  1;       
xcp.parameters(11).dtname = 'real_T'; 
xcp.parameters(12).baseaddr = '&may23_P.KINARM_HandInBarrier_num_states';     
         
xcp.parameters(12).symbol = 'may23_P.KINARM_HandInBarrier_attribcol1';
xcp.parameters(12).size   =  3;       
xcp.parameters(12).dtname = 'real_T'; 
xcp.parameters(13).baseaddr = '&may23_P.KINARM_HandInBarrier_attribcol1[0]';     
         
xcp.parameters(13).symbol = 'may23_P.KINARM_HandInTarget_use_dominant_hand';
xcp.parameters(13).size   =  1;       
xcp.parameters(13).dtname = 'real_T'; 
xcp.parameters(14).baseaddr = '&may23_P.KINARM_HandInTarget_use_dominant_hand';     
         
xcp.parameters(14).symbol = 'may23_P.KINARM_HandInTarget_target_type';
xcp.parameters(14).size   =  1;       
xcp.parameters(14).dtname = 'real_T'; 
xcp.parameters(15).baseaddr = '&may23_P.KINARM_HandInTarget_target_type';     
         
xcp.parameters(15).symbol = 'may23_P.KINARM_HandInTarget_num_states';
xcp.parameters(15).size   =  1;       
xcp.parameters(15).dtname = 'real_T'; 
xcp.parameters(16).baseaddr = '&may23_P.KINARM_HandInTarget_num_states';     
         
xcp.parameters(16).symbol = 'may23_P.KINARM_HandInTarget_attribcol1';
xcp.parameters(16).size   =  1;       
xcp.parameters(16).dtname = 'real_T'; 
xcp.parameters(17).baseaddr = '&may23_P.KINARM_HandInTarget_attribcol1';     
         
xcp.parameters(17).symbol = 'may23_P.Process_Video_CMD_video_delay';
xcp.parameters(17).size   =  1;       
xcp.parameters(17).dtname = 'real_T'; 
xcp.parameters(18).baseaddr = '&may23_P.Process_Video_CMD_video_delay';     
         
xcp.parameters(18).symbol = 'may23_P.PuckInBarrier_target_type';
xcp.parameters(18).size   =  1;       
xcp.parameters(18).dtname = 'real_T'; 
xcp.parameters(19).baseaddr = '&may23_P.PuckInBarrier_target_type';     
         
xcp.parameters(19).symbol = 'may23_P.PuckInBarrier_num_states';
xcp.parameters(19).size   =  1;       
xcp.parameters(19).dtname = 'real_T'; 
xcp.parameters(20).baseaddr = '&may23_P.PuckInBarrier_num_states';     
         
xcp.parameters(20).symbol = 'may23_P.PuckInBarrier_attribcol1';
xcp.parameters(20).size   =  3;       
xcp.parameters(20).dtname = 'real_T'; 
xcp.parameters(21).baseaddr = '&may23_P.PuckInBarrier_attribcol1[0]';     
         
xcp.parameters(21).symbol = 'may23_P.PuckInTarget_target_type';
xcp.parameters(21).size   =  1;       
xcp.parameters(21).dtname = 'real_T'; 
xcp.parameters(22).baseaddr = '&may23_P.PuckInTarget_target_type';     
         
xcp.parameters(22).symbol = 'may23_P.PuckInTarget_num_states';
xcp.parameters(22).size   =  1;       
xcp.parameters(22).dtname = 'real_T'; 
xcp.parameters(23).baseaddr = '&may23_P.PuckInTarget_num_states';     
         
xcp.parameters(23).symbol = 'may23_P.PuckInTarget_attribcol1';
xcp.parameters(23).size   =  1;       
xcp.parameters(23).dtname = 'real_T'; 
xcp.parameters(24).baseaddr = '&may23_P.PuckInTarget_attribcol1';     
         
xcp.parameters(24).symbol = 'may23_P.Show_Barrier_target_type';
xcp.parameters(24).size   =  1;       
xcp.parameters(24).dtname = 'real_T'; 
xcp.parameters(25).baseaddr = '&may23_P.Show_Barrier_target_type';     
         
xcp.parameters(25).symbol = 'may23_P.Show_Barrier_num_states';
xcp.parameters(25).size   =  1;       
xcp.parameters(25).dtname = 'real_T'; 
xcp.parameters(26).baseaddr = '&may23_P.Show_Barrier_num_states';     
         
xcp.parameters(26).symbol = 'may23_P.Show_Barrier_attribcol1';
xcp.parameters(26).size   =  6;       
xcp.parameters(26).dtname = 'real_T'; 
xcp.parameters(27).baseaddr = '&may23_P.Show_Barrier_attribcol1[0]';     
         
xcp.parameters(27).symbol = 'may23_P.Show_Barrier_attribcol2';
xcp.parameters(27).size   =  6;       
xcp.parameters(27).dtname = 'real_T'; 
xcp.parameters(28).baseaddr = '&may23_P.Show_Barrier_attribcol2[0]';     
         
xcp.parameters(28).symbol = 'may23_P.Show_Barrier_attribcol3';
xcp.parameters(28).size   =  6;       
xcp.parameters(28).dtname = 'real_T'; 
xcp.parameters(29).baseaddr = '&may23_P.Show_Barrier_attribcol3[0]';     
         
xcp.parameters(29).symbol = 'may23_P.Show_Barrier_opacity';
xcp.parameters(29).size   =  1;       
xcp.parameters(29).dtname = 'real_T'; 
xcp.parameters(30).baseaddr = '&may23_P.Show_Barrier_opacity';     
         
xcp.parameters(30).symbol = 'may23_P.Show_Barrier_target_display';
xcp.parameters(30).size   =  1;       
xcp.parameters(30).dtname = 'real_T'; 
xcp.parameters(31).baseaddr = '&may23_P.Show_Barrier_target_display';     
         
xcp.parameters(31).symbol = 'may23_P.Show_Cursor_target_type';
xcp.parameters(31).size   =  1;       
xcp.parameters(31).dtname = 'real_T'; 
xcp.parameters(32).baseaddr = '&may23_P.Show_Cursor_target_type';     
         
xcp.parameters(32).symbol = 'may23_P.Show_Cursor_num_states';
xcp.parameters(32).size   =  1;       
xcp.parameters(32).dtname = 'real_T'; 
xcp.parameters(33).baseaddr = '&may23_P.Show_Cursor_num_states';     
         
xcp.parameters(33).symbol = 'may23_P.Show_Cursor_attribcol1';
xcp.parameters(33).size   =  4;       
xcp.parameters(33).dtname = 'real_T'; 
xcp.parameters(34).baseaddr = '&may23_P.Show_Cursor_attribcol1[0]';     
         
xcp.parameters(34).symbol = 'may23_P.Show_Cursor_attribcol2';
xcp.parameters(34).size   =  4;       
xcp.parameters(34).dtname = 'real_T'; 
xcp.parameters(35).baseaddr = '&may23_P.Show_Cursor_attribcol2[0]';     
         
xcp.parameters(35).symbol = 'may23_P.Show_Cursor_attribcol3';
xcp.parameters(35).size   =  4;       
xcp.parameters(35).dtname = 'real_T'; 
xcp.parameters(36).baseaddr = '&may23_P.Show_Cursor_attribcol3[0]';     
         
xcp.parameters(36).symbol = 'may23_P.Show_Cursor_opacity';
xcp.parameters(36).size   =  1;       
xcp.parameters(36).dtname = 'real_T'; 
xcp.parameters(37).baseaddr = '&may23_P.Show_Cursor_opacity';     
         
xcp.parameters(37).symbol = 'may23_P.Show_Cursor_target_display';
xcp.parameters(37).size   =  1;       
xcp.parameters(37).dtname = 'real_T'; 
xcp.parameters(38).baseaddr = '&may23_P.Show_Cursor_target_display';     
         
xcp.parameters(38).symbol = 'may23_P.Show_Goal_target_type';
xcp.parameters(38).size   =  1;       
xcp.parameters(38).dtname = 'real_T'; 
xcp.parameters(39).baseaddr = '&may23_P.Show_Goal_target_type';     
         
xcp.parameters(39).symbol = 'may23_P.Show_Goal_num_states';
xcp.parameters(39).size   =  1;       
xcp.parameters(39).dtname = 'real_T'; 
xcp.parameters(40).baseaddr = '&may23_P.Show_Goal_num_states';     
         
xcp.parameters(40).symbol = 'may23_P.Show_Goal_attribcol1';
xcp.parameters(40).size   =  4;       
xcp.parameters(40).dtname = 'real_T'; 
xcp.parameters(41).baseaddr = '&may23_P.Show_Goal_attribcol1[0]';     
         
xcp.parameters(41).symbol = 'may23_P.Show_Goal_attribcol2';
xcp.parameters(41).size   =  4;       
xcp.parameters(41).dtname = 'real_T'; 
xcp.parameters(42).baseaddr = '&may23_P.Show_Goal_attribcol2[0]';     
         
xcp.parameters(42).symbol = 'may23_P.Show_Goal_attribcol3';
xcp.parameters(42).size   =  4;       
xcp.parameters(42).dtname = 'real_T'; 
xcp.parameters(43).baseaddr = '&may23_P.Show_Goal_attribcol3[0]';     
         
xcp.parameters(43).symbol = 'may23_P.Show_Goal_opacity';
xcp.parameters(43).size   =  1;       
xcp.parameters(43).dtname = 'real_T'; 
xcp.parameters(44).baseaddr = '&may23_P.Show_Goal_opacity';     
         
xcp.parameters(44).symbol = 'may23_P.Show_Goal_target_display';
xcp.parameters(44).size   =  1;       
xcp.parameters(44).dtname = 'real_T'; 
xcp.parameters(45).baseaddr = '&may23_P.Show_Goal_target_display';     
         
xcp.parameters(45).symbol = 'may23_P.Show_Preshot_Area_target_type';
xcp.parameters(45).size   =  1;       
xcp.parameters(45).dtname = 'real_T'; 
xcp.parameters(46).baseaddr = '&may23_P.Show_Preshot_Area_target_type';     
         
xcp.parameters(46).symbol = 'may23_P.Show_Preshot_Area_num_states';
xcp.parameters(46).size   =  1;       
xcp.parameters(46).dtname = 'real_T'; 
xcp.parameters(47).baseaddr = '&may23_P.Show_Preshot_Area_num_states';     
         
xcp.parameters(47).symbol = 'may23_P.Show_Preshot_Area_attribcol1';
xcp.parameters(47).size   =  4;       
xcp.parameters(47).dtname = 'real_T'; 
xcp.parameters(48).baseaddr = '&may23_P.Show_Preshot_Area_attribcol1[0]';     
         
xcp.parameters(48).symbol = 'may23_P.Show_Preshot_Area_attribcol2';
xcp.parameters(48).size   =  4;       
xcp.parameters(48).dtname = 'real_T'; 
xcp.parameters(49).baseaddr = '&may23_P.Show_Preshot_Area_attribcol2[0]';     
         
xcp.parameters(49).symbol = 'may23_P.Show_Preshot_Area_attribcol3';
xcp.parameters(49).size   =  4;       
xcp.parameters(49).dtname = 'real_T'; 
xcp.parameters(50).baseaddr = '&may23_P.Show_Preshot_Area_attribcol3[0]';     
         
xcp.parameters(50).symbol = 'may23_P.Show_Preshot_Area_opacity';
xcp.parameters(50).size   =  1;       
xcp.parameters(50).dtname = 'real_T'; 
xcp.parameters(51).baseaddr = '&may23_P.Show_Preshot_Area_opacity';     
         
xcp.parameters(51).symbol = 'may23_P.Show_Preshot_Area_target_display';
xcp.parameters(51).size   =  1;       
xcp.parameters(51).dtname = 'real_T'; 
xcp.parameters(52).baseaddr = '&may23_P.Show_Preshot_Area_target_display';     
         
xcp.parameters(52).symbol = 'may23_P.Show_Puck_target_type';
xcp.parameters(52).size   =  1;       
xcp.parameters(52).dtname = 'real_T'; 
xcp.parameters(53).baseaddr = '&may23_P.Show_Puck_target_type';     
         
xcp.parameters(53).symbol = 'may23_P.Show_Puck_num_states';
xcp.parameters(53).size   =  1;       
xcp.parameters(53).dtname = 'real_T'; 
xcp.parameters(54).baseaddr = '&may23_P.Show_Puck_num_states';     
         
xcp.parameters(54).symbol = 'may23_P.Show_Puck_attribcol1';
xcp.parameters(54).size   =  4;       
xcp.parameters(54).dtname = 'real_T'; 
xcp.parameters(55).baseaddr = '&may23_P.Show_Puck_attribcol1[0]';     
         
xcp.parameters(55).symbol = 'may23_P.Show_Puck_attribcol2';
xcp.parameters(55).size   =  4;       
xcp.parameters(55).dtname = 'real_T'; 
xcp.parameters(56).baseaddr = '&may23_P.Show_Puck_attribcol2[0]';     
         
xcp.parameters(56).symbol = 'may23_P.Show_Puck_attribcol3';
xcp.parameters(56).size   =  4;       
xcp.parameters(56).dtname = 'real_T'; 
xcp.parameters(57).baseaddr = '&may23_P.Show_Puck_attribcol3[0]';     
         
xcp.parameters(57).symbol = 'may23_P.Show_Puck_opacity';
xcp.parameters(57).size   =  1;       
xcp.parameters(57).dtname = 'real_T'; 
xcp.parameters(58).baseaddr = '&may23_P.Show_Puck_opacity';     
         
xcp.parameters(58).symbol = 'may23_P.Show_Puck_target_display';
xcp.parameters(58).size   =  1;       
xcp.parameters(58).dtname = 'real_T'; 
xcp.parameters(59).baseaddr = '&may23_P.Show_Puck_target_display';     
         
xcp.parameters(59).symbol = 'may23_P.Show_Start_target_type';
xcp.parameters(59).size   =  1;       
xcp.parameters(59).dtname = 'real_T'; 
xcp.parameters(60).baseaddr = '&may23_P.Show_Start_target_type';     
         
xcp.parameters(60).symbol = 'may23_P.Show_Start_num_states';
xcp.parameters(60).size   =  1;       
xcp.parameters(60).dtname = 'real_T'; 
xcp.parameters(61).baseaddr = '&may23_P.Show_Start_num_states';     
         
xcp.parameters(61).symbol = 'may23_P.Show_Start_attribcol1';
xcp.parameters(61).size   =  4;       
xcp.parameters(61).dtname = 'real_T'; 
xcp.parameters(62).baseaddr = '&may23_P.Show_Start_attribcol1[0]';     
         
xcp.parameters(62).symbol = 'may23_P.Show_Start_attribcol2';
xcp.parameters(62).size   =  4;       
xcp.parameters(62).dtname = 'real_T'; 
xcp.parameters(63).baseaddr = '&may23_P.Show_Start_attribcol2[0]';     
         
xcp.parameters(63).symbol = 'may23_P.Show_Start_attribcol3';
xcp.parameters(63).size   =  4;       
xcp.parameters(63).dtname = 'real_T'; 
xcp.parameters(64).baseaddr = '&may23_P.Show_Start_attribcol3[0]';     
         
xcp.parameters(64).symbol = 'may23_P.Show_Start_opacity';
xcp.parameters(64).size   =  1;       
xcp.parameters(64).dtname = 'real_T'; 
xcp.parameters(65).baseaddr = '&may23_P.Show_Start_opacity';     
         
xcp.parameters(65).symbol = 'may23_P.Show_Start_target_display';
xcp.parameters(65).size   =  1;       
xcp.parameters(65).dtname = 'real_T'; 
xcp.parameters(66).baseaddr = '&may23_P.Show_Start_target_display';     
         
xcp.parameters(66).symbol = 'may23_P.Constant_Value_c';
xcp.parameters(66).size   =  1;       
xcp.parameters(66).dtname = 'real_T'; 
xcp.parameters(67).baseaddr = '&may23_P.Constant_Value_c';     
         
xcp.parameters(67).symbol = 'may23_P.Memory1_InitialCondition_k';
xcp.parameters(67).size   =  1;       
xcp.parameters(67).dtname = 'boolean_T'; 
xcp.parameters(68).baseaddr = '&may23_P.Memory1_InitialCondition_k';     
         
xcp.parameters(68).symbol = 'may23_P.Memory2_InitialCondition_o';
xcp.parameters(68).size   =  1;       
xcp.parameters(68).dtname = 'real_T'; 
xcp.parameters(69).baseaddr = '&may23_P.Memory2_InitialCondition_o';     
         
xcp.parameters(69).symbol = 'may23_P.Memory4_InitialCondition';
xcp.parameters(69).size   =  1;       
xcp.parameters(69).dtname = 'boolean_T'; 
xcp.parameters(70).baseaddr = '&may23_P.Memory4_InitialCondition';     
         
xcp.parameters(70).symbol = 'may23_P.ECATDigDiagnostic_InitialValue';
xcp.parameters(70).size   =  4;       
xcp.parameters(70).dtname = 'uint32_T'; 
xcp.parameters(71).baseaddr = '&may23_P.ECATDigDiagnostic_InitialValue[0]';     
         
xcp.parameters(71).symbol = 'may23_P.ECATStatus_InitialValue';
xcp.parameters(71).size   =  8;       
xcp.parameters(71).dtname = 'real_T'; 
xcp.parameters(72).baseaddr = '&may23_P.ECATStatus_InitialValue[0]';     
         
xcp.parameters(72).symbol = 'may23_P.ECATStatus1_InitialValue';
xcp.parameters(72).size   =  10;       
xcp.parameters(72).dtname = 'real_T'; 
xcp.parameters(73).baseaddr = '&may23_P.ECATStatus1_InitialValue[0]';     
         
xcp.parameters(73).symbol = 'may23_P.ECAThardware_InitialValue';
xcp.parameters(73).size   =  14;       
xcp.parameters(73).dtname = 'real_T'; 
xcp.parameters(74).baseaddr = '&may23_P.ECAThardware_InitialValue[0]';     
         
xcp.parameters(74).symbol = 'may23_P.ZeroDigOut_Value';
xcp.parameters(74).size   =  4;       
xcp.parameters(74).dtname = 'real_T'; 
xcp.parameters(75).baseaddr = '&may23_P.ZeroDigOut_Value[0]';     
         
xcp.parameters(75).symbol = 'may23_P.seconds_remaining_Value';
xcp.parameters(75).size   =  1;       
xcp.parameters(75).dtname = 'real_T'; 
xcp.parameters(76).baseaddr = '&may23_P.seconds_remaining_Value';     
         
xcp.parameters(76).symbol = 'may23_P.Memory_InitialCondition_pk';
xcp.parameters(76).size   =  1;       
xcp.parameters(76).dtname = 'real_T'; 
xcp.parameters(77).baseaddr = '&may23_P.Memory_InitialCondition_pk';     
         
xcp.parameters(77).symbol = 'may23_P.Memory1_InitialCondition_n';
xcp.parameters(77).size   =  1;       
xcp.parameters(77).dtname = 'real_T'; 
xcp.parameters(78).baseaddr = '&may23_P.Memory1_InitialCondition_n';     
         
xcp.parameters(78).symbol = 'may23_P.Constant_Value_d';
xcp.parameters(78).size   =  1;       
xcp.parameters(78).dtname = 'real_T'; 
xcp.parameters(79).baseaddr = '&may23_P.Constant_Value_d';     
         
xcp.parameters(79).symbol = 'may23_P.DisplaySizem_Value';
xcp.parameters(79).size   =  2;       
xcp.parameters(79).dtname = 'real_T'; 
xcp.parameters(80).baseaddr = '&may23_P.DisplaySizem_Value[0]';     
         
xcp.parameters(80).symbol = 'may23_P.DisplaySizepels_Value';
xcp.parameters(80).size   =  2;       
xcp.parameters(80).dtname = 'real_T'; 
xcp.parameters(81).baseaddr = '&may23_P.DisplaySizepels_Value[0]';     
         
xcp.parameters(81).symbol = 'may23_P.DockingPoints_Value';
xcp.parameters(81).size   =  10;       
xcp.parameters(81).dtname = 'real_T'; 
xcp.parameters(82).baseaddr = '&may23_P.DockingPoints_Value[0]';     
         
xcp.parameters(82).symbol = 'may23_P.ELCameraAngle_Value_j';
xcp.parameters(82).size   =  2;       
xcp.parameters(82).dtname = 'real_T'; 
xcp.parameters(83).baseaddr = '&may23_P.ELCameraAngle_Value_j[0]';     
         
xcp.parameters(83).symbol = 'may23_P.ELCameraFocalLength_Value_h';
xcp.parameters(83).size   =  1;       
xcp.parameters(83).dtname = 'real_T'; 
xcp.parameters(84).baseaddr = '&may23_P.ELCameraFocalLength_Value_h';     
         
xcp.parameters(84).symbol = 'may23_P.ELCameraPosition_Value_e';
xcp.parameters(84).size   =  3;       
xcp.parameters(84).dtname = 'real_T'; 
xcp.parameters(85).baseaddr = '&may23_P.ELCameraPosition_Value_e[0]';     
         
xcp.parameters(85).symbol = 'may23_P.ELTrackingAvailable_Value_m';
xcp.parameters(85).size   =  1;       
xcp.parameters(85).dtname = 'real_T'; 
xcp.parameters(86).baseaddr = '&may23_P.ELTrackingAvailable_Value_m';     
         
xcp.parameters(86).symbol = 'may23_P.LibraryPatchVersion_Value';
xcp.parameters(86).size   =  1;       
xcp.parameters(86).dtname = 'real_T'; 
xcp.parameters(87).baseaddr = '&may23_P.LibraryPatchVersion_Value';     
         
xcp.parameters(87).symbol = 'may23_P.LibraryVersion_Value';
xcp.parameters(87).size   =  1;       
xcp.parameters(87).dtname = 'real_T'; 
xcp.parameters(88).baseaddr = '&may23_P.LibraryVersion_Value';     
         
xcp.parameters(88).symbol = 'may23_P.NextTProw_Value';
xcp.parameters(88).size   =  1;       
xcp.parameters(88).dtname = 'real_T'; 
xcp.parameters(89).baseaddr = '&may23_P.NextTProw_Value';     
         
xcp.parameters(89).symbol = 'may23_P.PauseType_Value';
xcp.parameters(89).size   =  1;       
xcp.parameters(89).dtname = 'real_T'; 
xcp.parameters(90).baseaddr = '&may23_P.PauseType_Value';     
         
xcp.parameters(90).symbol = 'may23_P.Repeat_Trial_Flag_Value';
xcp.parameters(90).size   =  1;       
xcp.parameters(90).dtname = 'real_T'; 
xcp.parameters(91).baseaddr = '&may23_P.Repeat_Trial_Flag_Value';     
         
xcp.parameters(91).symbol = 'may23_P.RunTaskClockFlag_Value';
xcp.parameters(91).size   =  1;       
xcp.parameters(91).dtname = 'real_T'; 
xcp.parameters(92).baseaddr = '&may23_P.RunTaskClockFlag_Value';     
         
xcp.parameters(92).symbol = 'may23_P.Seed_Value';
xcp.parameters(92).size   =  1;       
xcp.parameters(92).dtname = 'real_T'; 
xcp.parameters(93).baseaddr = '&may23_P.Seed_Value';     
         
xcp.parameters(93).symbol = 'may23_P.SubjectHeight_Value';
xcp.parameters(93).size   =  1;       
xcp.parameters(93).dtname = 'real_T'; 
xcp.parameters(94).baseaddr = '&may23_P.SubjectHeight_Value';     
         
xcp.parameters(94).symbol = 'may23_P.SubjectWeight_Value';
xcp.parameters(94).size   =  1;       
xcp.parameters(94).dtname = 'real_T'; 
xcp.parameters(95).baseaddr = '&may23_P.SubjectWeight_Value';     
         
xcp.parameters(95).symbol = 'may23_P.TaskVersion_Value';
xcp.parameters(95).size   =  1;       
xcp.parameters(95).dtname = 'real_T'; 
xcp.parameters(96).baseaddr = '&may23_P.TaskVersion_Value';     
         
xcp.parameters(96).symbol = 'may23_P.UseRepeatTrialFlag_Value';
xcp.parameters(96).size   =  1;       
xcp.parameters(96).dtname = 'real_T'; 
xcp.parameters(97).baseaddr = '&may23_P.UseRepeatTrialFlag_Value';     
         
xcp.parameters(97).symbol = 'may23_P.UsecustomTPsequence_Value';
xcp.parameters(97).size   =  1;       
xcp.parameters(97).dtname = 'real_T'; 
xcp.parameters(98).baseaddr = '&may23_P.UsecustomTPsequence_Value';     
         
xcp.parameters(98).symbol = 'may23_P.dlmbuildtime_Value';
xcp.parameters(98).size   =  1;       
xcp.parameters(98).dtname = 'real_T'; 
xcp.parameters(99).baseaddr = '&may23_P.dlmbuildtime_Value';     
         
xcp.parameters(99).symbol = 'may23_P.frame_of_reference_center_Value';
xcp.parameters(99).size   =  2;       
xcp.parameters(99).dtname = 'real_T'; 
xcp.parameters(100).baseaddr = '&may23_P.frame_of_reference_center_Value[0]';     
         
xcp.parameters(100).symbol = 'may23_P.xPCVersion_Value';
xcp.parameters(100).size   =  1;       
xcp.parameters(100).dtname = 'real_T'; 
xcp.parameters(101).baseaddr = '&may23_P.xPCVersion_Value';     
         
xcp.parameters(101).symbol = 'may23_P.Memory_InitialCondition_m';
xcp.parameters(101).size   =  1;       
xcp.parameters(101).dtname = 'real_T'; 
xcp.parameters(102).baseaddr = '&may23_P.Memory_InitialCondition_m';     
         
xcp.parameters(102).symbol = 'may23_P.TorqueLimit2_Value';
xcp.parameters(102).size   =  1;       
xcp.parameters(102).dtname = 'real_T'; 
xcp.parameters(103).baseaddr = '&may23_P.TorqueLimit2_Value';     
         
xcp.parameters(103).symbol = 'may23_P.Switch_Threshold_bf';
xcp.parameters(103).size   =  1;       
xcp.parameters(103).dtname = 'real_T'; 
xcp.parameters(104).baseaddr = '&may23_P.Switch_Threshold_bf';     
         
xcp.parameters(104).symbol = 'may23_P.SelectedStates_Value_b';
xcp.parameters(104).size   =  1;       
xcp.parameters(104).dtname = 'real_T'; 
xcp.parameters(105).baseaddr = '&may23_P.SelectedStates_Value_b';     
         
xcp.parameters(105).symbol = 'may23_P.attribcol2_Value_b';
xcp.parameters(105).size   =  3;       
xcp.parameters(105).dtname = 'real_T'; 
xcp.parameters(106).baseaddr = '&may23_P.attribcol2_Value_b[0]';     
         
xcp.parameters(106).symbol = 'may23_P.attribcol3_Value_o';
xcp.parameters(106).size   =  3;       
xcp.parameters(106).dtname = 'real_T'; 
xcp.parameters(107).baseaddr = '&may23_P.attribcol3_Value_o[0]';     
         
xcp.parameters(107).symbol = 'may23_P.attribcol4_Value_l';
xcp.parameters(107).size   =  3;       
xcp.parameters(107).dtname = 'real_T'; 
xcp.parameters(108).baseaddr = '&may23_P.attribcol4_Value_l[0]';     
         
xcp.parameters(108).symbol = 'may23_P.attribcol5_Value_n';
xcp.parameters(108).size   =  3;       
xcp.parameters(108).dtname = 'real_T'; 
xcp.parameters(109).baseaddr = '&may23_P.attribcol5_Value_n[0]';     
         
xcp.parameters(109).symbol = 'may23_P.Switch_Threshold_b';
xcp.parameters(109).size   =  1;       
xcp.parameters(109).dtname = 'real_T'; 
xcp.parameters(110).baseaddr = '&may23_P.Switch_Threshold_b';     
         
xcp.parameters(110).symbol = 'may23_P.SelectedStates_Value';
xcp.parameters(110).size   =  1;       
xcp.parameters(110).dtname = 'real_T'; 
xcp.parameters(111).baseaddr = '&may23_P.SelectedStates_Value';     
         
xcp.parameters(111).symbol = 'may23_P.attribcol2_Value';
xcp.parameters(111).size   =  1;       
xcp.parameters(111).dtname = 'real_T'; 
xcp.parameters(112).baseaddr = '&may23_P.attribcol2_Value';     
         
xcp.parameters(112).symbol = 'may23_P.attribcol3_Value';
xcp.parameters(112).size   =  1;       
xcp.parameters(112).dtname = 'real_T'; 
xcp.parameters(113).baseaddr = '&may23_P.attribcol3_Value';     
         
xcp.parameters(113).symbol = 'may23_P.attribcol4_Value';
xcp.parameters(113).size   =  1;       
xcp.parameters(113).dtname = 'real_T'; 
xcp.parameters(114).baseaddr = '&may23_P.attribcol4_Value';     
         
xcp.parameters(114).symbol = 'may23_P.attribcol5_Value';
xcp.parameters(114).size   =  1;       
xcp.parameters(114).dtname = 'real_T'; 
xcp.parameters(115).baseaddr = '&may23_P.attribcol5_Value';     
         
xcp.parameters(115).symbol = 'may23_P.Switch_Threshold_j';
xcp.parameters(115).size   =  1;       
xcp.parameters(115).dtname = 'real_T'; 
xcp.parameters(116).baseaddr = '&may23_P.Switch_Threshold_j';     
         
xcp.parameters(116).symbol = 'may23_P.binary_file_names_Value';
xcp.parameters(116).size   =  1;       
xcp.parameters(116).dtname = 'real_T'; 
xcp.parameters(117).baseaddr = '&may23_P.binary_file_names_Value';     
         
xcp.parameters(117).symbol = 'may23_P.binary_files_Value';
xcp.parameters(117).size   =  10;       
xcp.parameters(117).dtname = 'real_T'; 
xcp.parameters(118).baseaddr = '&may23_P.binary_files_Value[0]';     
         
xcp.parameters(118).symbol = 'may23_P.GUI_VCODE_Value';
xcp.parameters(118).size   =  630;       
xcp.parameters(118).dtname = 'real_T'; 
xcp.parameters(119).baseaddr = '&may23_P.GUI_VCODE_Value[0]';     
         
xcp.parameters(119).symbol = 'may23_P.Gain_Gain_g';
xcp.parameters(119).size   =  1;       
xcp.parameters(119).dtname = 'real_T'; 
xcp.parameters(120).baseaddr = '&may23_P.Gain_Gain_g';     
         
xcp.parameters(120).symbol = 'may23_P.Memory_InitialCondition_i';
xcp.parameters(120).size   =  1;       
xcp.parameters(120).dtname = 'real_T'; 
xcp.parameters(121).baseaddr = '&may23_P.Memory_InitialCondition_i';     
         
xcp.parameters(121).symbol = 'may23_P.Receive_P1_i';
xcp.parameters(121).size   =  26;       
xcp.parameters(121).dtname = 'real_T'; 
xcp.parameters(122).baseaddr = '&may23_P.Receive_P1_i[0]';     
         
xcp.parameters(122).symbol = 'may23_P.Receive_P2_g';
xcp.parameters(122).size   =  1;       
xcp.parameters(122).dtname = 'real_T'; 
xcp.parameters(123).baseaddr = '&may23_P.Receive_P2_g';     
         
xcp.parameters(123).symbol = 'may23_P.Receive_P3_b2';
xcp.parameters(123).size   =  1;       
xcp.parameters(123).dtname = 'real_T'; 
xcp.parameters(124).baseaddr = '&may23_P.Receive_P3_b2';     
         
xcp.parameters(124).symbol = 'may23_P.Receive_P4_gy';
xcp.parameters(124).size   =  1;       
xcp.parameters(124).dtname = 'real_T'; 
xcp.parameters(125).baseaddr = '&may23_P.Receive_P4_gy';     
         
xcp.parameters(125).symbol = 'may23_P.Receive_P5_i';
xcp.parameters(125).size   =  11;       
xcp.parameters(125).dtname = 'real_T'; 
xcp.parameters(126).baseaddr = '&may23_P.Receive_P5_i[0]';     
         
xcp.parameters(126).symbol = 'may23_P.Receive_P6_j';
xcp.parameters(126).size   =  1;       
xcp.parameters(126).dtname = 'real_T'; 
xcp.parameters(127).baseaddr = '&may23_P.Receive_P6_j';     
         
xcp.parameters(127).symbol = 'may23_P.Receive_P7_g';
xcp.parameters(127).size   =  1;       
xcp.parameters(127).dtname = 'real_T'; 
xcp.parameters(128).baseaddr = '&may23_P.Receive_P7_g';     
         
xcp.parameters(128).symbol = 'may23_P.Receive_P9_m';
xcp.parameters(128).size   =  1;       
xcp.parameters(128).dtname = 'real_T'; 
xcp.parameters(129).baseaddr = '&may23_P.Receive_P9_m';     
         
xcp.parameters(129).symbol = 'may23_P.Send_P1_k1';
xcp.parameters(129).size   =  26;       
xcp.parameters(129).dtname = 'real_T'; 
xcp.parameters(130).baseaddr = '&may23_P.Send_P1_k1[0]';     
         
xcp.parameters(130).symbol = 'may23_P.Send_P2_i';
xcp.parameters(130).size   =  1;       
xcp.parameters(130).dtname = 'real_T'; 
xcp.parameters(131).baseaddr = '&may23_P.Send_P2_i';     
         
xcp.parameters(131).symbol = 'may23_P.Send_P3_d';
xcp.parameters(131).size   =  11;       
xcp.parameters(131).dtname = 'real_T'; 
xcp.parameters(132).baseaddr = '&may23_P.Send_P3_d[0]';     
         
xcp.parameters(132).symbol = 'may23_P.Send_P4_g';
xcp.parameters(132).size   =  1;       
xcp.parameters(132).dtname = 'real_T'; 
xcp.parameters(133).baseaddr = '&may23_P.Send_P4_g';     
         
xcp.parameters(133).symbol = 'may23_P.Send_P5_ev';
xcp.parameters(133).size   =  1;       
xcp.parameters(133).dtname = 'real_T'; 
xcp.parameters(134).baseaddr = '&may23_P.Send_P5_ev';     
         
xcp.parameters(134).symbol = 'may23_P.Send_P6_l';
xcp.parameters(134).size   =  1;       
xcp.parameters(134).dtname = 'real_T'; 
xcp.parameters(135).baseaddr = '&may23_P.Send_P6_l';     
         
xcp.parameters(135).symbol = 'may23_P.SelectedStates_Value_n';
xcp.parameters(135).size   =  1;       
xcp.parameters(135).dtname = 'real_T'; 
xcp.parameters(136).baseaddr = '&may23_P.SelectedStates_Value_n';     
         
xcp.parameters(136).symbol = 'may23_P.attribcol2_Value_d';
xcp.parameters(136).size   =  3;       
xcp.parameters(136).dtname = 'real_T'; 
xcp.parameters(137).baseaddr = '&may23_P.attribcol2_Value_d[0]';     
         
xcp.parameters(137).symbol = 'may23_P.attribcol3_Value_c';
xcp.parameters(137).size   =  3;       
xcp.parameters(137).dtname = 'real_T'; 
xcp.parameters(138).baseaddr = '&may23_P.attribcol3_Value_c[0]';     
         
xcp.parameters(138).symbol = 'may23_P.attribcol4_Value_lm';
xcp.parameters(138).size   =  3;       
xcp.parameters(138).dtname = 'real_T'; 
xcp.parameters(139).baseaddr = '&may23_P.attribcol4_Value_lm[0]';     
         
xcp.parameters(139).symbol = 'may23_P.attribcol5_Value_j';
xcp.parameters(139).size   =  3;       
xcp.parameters(139).dtname = 'real_T'; 
xcp.parameters(140).baseaddr = '&may23_P.attribcol5_Value_j[0]';     
         
xcp.parameters(140).symbol = 'may23_P.SelectedStates_Value_m';
xcp.parameters(140).size   =  1;       
xcp.parameters(140).dtname = 'real_T'; 
xcp.parameters(141).baseaddr = '&may23_P.SelectedStates_Value_m';     
         
xcp.parameters(141).symbol = 'may23_P.attribcol2_Value_i';
xcp.parameters(141).size   =  1;       
xcp.parameters(141).dtname = 'real_T'; 
xcp.parameters(142).baseaddr = '&may23_P.attribcol2_Value_i';     
         
xcp.parameters(142).symbol = 'may23_P.attribcol3_Value_f';
xcp.parameters(142).size   =  1;       
xcp.parameters(142).dtname = 'real_T'; 
xcp.parameters(143).baseaddr = '&may23_P.attribcol3_Value_f';     
         
xcp.parameters(143).symbol = 'may23_P.attribcol4_Value_la';
xcp.parameters(143).size   =  1;       
xcp.parameters(143).dtname = 'real_T'; 
xcp.parameters(144).baseaddr = '&may23_P.attribcol4_Value_la';     
         
xcp.parameters(144).symbol = 'may23_P.attribcol5_Value_b';
xcp.parameters(144).size   =  1;       
xcp.parameters(144).dtname = 'real_T'; 
xcp.parameters(145).baseaddr = '&may23_P.attribcol5_Value_b';     
         
xcp.parameters(145).symbol = 'may23_P.padder_Value_bi';
xcp.parameters(145).size   =  25;       
xcp.parameters(145).dtname = 'real_T'; 
xcp.parameters(146).baseaddr = '&may23_P.padder_Value_bi[0]';     
         
xcp.parameters(146).symbol = 'may23_P.state4_indices_Value_d';
xcp.parameters(146).size   =  6;       
xcp.parameters(146).dtname = 'real_T'; 
xcp.parameters(147).baseaddr = '&may23_P.state4_indices_Value_d[0]';     
         
xcp.parameters(147).symbol = 'may23_P.state5_indices_Value_p';
xcp.parameters(147).size   =  6;       
xcp.parameters(147).dtname = 'real_T'; 
xcp.parameters(148).baseaddr = '&may23_P.state5_indices_Value_p[0]';     
         
xcp.parameters(148).symbol = 'may23_P.xpos_index_Value_e';
xcp.parameters(148).size   =  1;       
xcp.parameters(148).dtname = 'real_T'; 
xcp.parameters(149).baseaddr = '&may23_P.xpos_index_Value_e';     
         
xcp.parameters(149).symbol = 'may23_P.ypos_index_Value_c';
xcp.parameters(149).size   =  1;       
xcp.parameters(149).dtname = 'real_T'; 
xcp.parameters(150).baseaddr = '&may23_P.ypos_index_Value_c';     
         
xcp.parameters(150).symbol = 'may23_P.padder_Value';
xcp.parameters(150).size   =  35;       
xcp.parameters(150).dtname = 'real_T'; 
xcp.parameters(151).baseaddr = '&may23_P.padder_Value[0]';     
         
xcp.parameters(151).symbol = 'may23_P.state4_indices_Value';
xcp.parameters(151).size   =  4;       
xcp.parameters(151).dtname = 'real_T'; 
xcp.parameters(152).baseaddr = '&may23_P.state4_indices_Value[0]';     
         
xcp.parameters(152).symbol = 'may23_P.state5_indices_Value';
xcp.parameters(152).size   =  4;       
xcp.parameters(152).dtname = 'real_T'; 
xcp.parameters(153).baseaddr = '&may23_P.state5_indices_Value[0]';     
         
xcp.parameters(153).symbol = 'may23_P.xpos_index_Value';
xcp.parameters(153).size   =  1;       
xcp.parameters(153).dtname = 'real_T'; 
xcp.parameters(154).baseaddr = '&may23_P.xpos_index_Value';     
         
xcp.parameters(154).symbol = 'may23_P.ypos_index_Value';
xcp.parameters(154).size   =  1;       
xcp.parameters(154).dtname = 'real_T'; 
xcp.parameters(155).baseaddr = '&may23_P.ypos_index_Value';     
         
xcp.parameters(155).symbol = 'may23_P.padder_Value_a';
xcp.parameters(155).size   =  35;       
xcp.parameters(155).dtname = 'real_T'; 
xcp.parameters(156).baseaddr = '&may23_P.padder_Value_a[0]';     
         
xcp.parameters(156).symbol = 'may23_P.state4_indices_Value_i';
xcp.parameters(156).size   =  4;       
xcp.parameters(156).dtname = 'real_T'; 
xcp.parameters(157).baseaddr = '&may23_P.state4_indices_Value_i[0]';     
         
xcp.parameters(157).symbol = 'may23_P.state5_indices_Value_j';
xcp.parameters(157).size   =  4;       
xcp.parameters(157).dtname = 'real_T'; 
xcp.parameters(158).baseaddr = '&may23_P.state5_indices_Value_j[0]';     
         
xcp.parameters(158).symbol = 'may23_P.xpos_index_Value_p';
xcp.parameters(158).size   =  1;       
xcp.parameters(158).dtname = 'real_T'; 
xcp.parameters(159).baseaddr = '&may23_P.xpos_index_Value_p';     
         
xcp.parameters(159).symbol = 'may23_P.ypos_index_Value_p';
xcp.parameters(159).size   =  1;       
xcp.parameters(159).dtname = 'real_T'; 
xcp.parameters(160).baseaddr = '&may23_P.ypos_index_Value_p';     
         
xcp.parameters(160).symbol = 'may23_P.padder_Value_b';
xcp.parameters(160).size   =  35;       
xcp.parameters(160).dtname = 'real_T'; 
xcp.parameters(161).baseaddr = '&may23_P.padder_Value_b[0]';     
         
xcp.parameters(161).symbol = 'may23_P.state4_indices_Value_k';
xcp.parameters(161).size   =  4;       
xcp.parameters(161).dtname = 'real_T'; 
xcp.parameters(162).baseaddr = '&may23_P.state4_indices_Value_k[0]';     
         
xcp.parameters(162).symbol = 'may23_P.state5_indices_Value_jv';
xcp.parameters(162).size   =  4;       
xcp.parameters(162).dtname = 'real_T'; 
xcp.parameters(163).baseaddr = '&may23_P.state5_indices_Value_jv[0]';     
         
xcp.parameters(163).symbol = 'may23_P.xpos_index_Value_g';
xcp.parameters(163).size   =  1;       
xcp.parameters(163).dtname = 'real_T'; 
xcp.parameters(164).baseaddr = '&may23_P.xpos_index_Value_g';     
         
xcp.parameters(164).symbol = 'may23_P.ypos_index_Value_e';
xcp.parameters(164).size   =  1;       
xcp.parameters(164).dtname = 'real_T'; 
xcp.parameters(165).baseaddr = '&may23_P.ypos_index_Value_e';     
         
xcp.parameters(165).symbol = 'may23_P.padder_Value_l';
xcp.parameters(165).size   =  35;       
xcp.parameters(165).dtname = 'real_T'; 
xcp.parameters(166).baseaddr = '&may23_P.padder_Value_l[0]';     
         
xcp.parameters(166).symbol = 'may23_P.state4_indices_Value_p';
xcp.parameters(166).size   =  4;       
xcp.parameters(166).dtname = 'real_T'; 
xcp.parameters(167).baseaddr = '&may23_P.state4_indices_Value_p[0]';     
         
xcp.parameters(167).symbol = 'may23_P.state5_indices_Value_l';
xcp.parameters(167).size   =  4;       
xcp.parameters(167).dtname = 'real_T'; 
xcp.parameters(168).baseaddr = '&may23_P.state5_indices_Value_l[0]';     
         
xcp.parameters(168).symbol = 'may23_P.xpos_index_Value_l';
xcp.parameters(168).size   =  1;       
xcp.parameters(168).dtname = 'real_T'; 
xcp.parameters(169).baseaddr = '&may23_P.xpos_index_Value_l';     
         
xcp.parameters(169).symbol = 'may23_P.ypos_index_Value_d';
xcp.parameters(169).size   =  1;       
xcp.parameters(169).dtname = 'real_T'; 
xcp.parameters(170).baseaddr = '&may23_P.ypos_index_Value_d';     
         
xcp.parameters(170).symbol = 'may23_P.padder_Value_p';
xcp.parameters(170).size   =  35;       
xcp.parameters(170).dtname = 'real_T'; 
xcp.parameters(171).baseaddr = '&may23_P.padder_Value_p[0]';     
         
xcp.parameters(171).symbol = 'may23_P.state4_indices_Value_l';
xcp.parameters(171).size   =  4;       
xcp.parameters(171).dtname = 'real_T'; 
xcp.parameters(172).baseaddr = '&may23_P.state4_indices_Value_l[0]';     
         
xcp.parameters(172).symbol = 'may23_P.state5_indices_Value_d';
xcp.parameters(172).size   =  4;       
xcp.parameters(172).dtname = 'real_T'; 
xcp.parameters(173).baseaddr = '&may23_P.state5_indices_Value_d[0]';     
         
xcp.parameters(173).symbol = 'may23_P.xpos_index_Value_a';
xcp.parameters(173).size   =  1;       
xcp.parameters(173).dtname = 'real_T'; 
xcp.parameters(174).baseaddr = '&may23_P.xpos_index_Value_a';     
         
xcp.parameters(174).symbol = 'may23_P.ypos_index_Value_f';
xcp.parameters(174).size   =  1;       
xcp.parameters(174).dtname = 'real_T'; 
xcp.parameters(175).baseaddr = '&may23_P.ypos_index_Value_f';     
         
xcp.parameters(175).symbol = 'may23_P.Perturbation_loadcol';
xcp.parameters(175).size   =  3;       
xcp.parameters(175).dtname = 'real_T'; 
xcp.parameters(176).baseaddr = '&may23_P.Perturbation_loadcol[0]';     
         
xcp.parameters(176).symbol = 'may23_P.Memory3_InitialCondition_c';
xcp.parameters(176).size   =  1;       
xcp.parameters(176).dtname = 'real_T'; 
xcp.parameters(177).baseaddr = '&may23_P.Memory3_InitialCondition_c';     
         
xcp.parameters(177).symbol = 'may23_P.Switch_Threshold_e';
xcp.parameters(177).size   =  1;       
xcp.parameters(177).dtname = 'real_T'; 
xcp.parameters(178).baseaddr = '&may23_P.Switch_Threshold_e';     
         
xcp.parameters(178).symbol = 'may23_P.Constant2_Value_e';
xcp.parameters(178).size   =  1;       
xcp.parameters(178).dtname = 'real_T'; 
xcp.parameters(179).baseaddr = '&may23_P.Constant2_Value_e';     
         
xcp.parameters(179).symbol = 'may23_P.PulseGenerator_Amp';
xcp.parameters(179).size   =  1;       
xcp.parameters(179).dtname = 'real_T'; 
xcp.parameters(180).baseaddr = '&may23_P.PulseGenerator_Amp';     
         
xcp.parameters(180).symbol = 'may23_P.PulseGenerator_Period';
xcp.parameters(180).size   =  1;       
xcp.parameters(180).dtname = 'real_T'; 
xcp.parameters(181).baseaddr = '&may23_P.PulseGenerator_Period';     
         
xcp.parameters(181).symbol = 'may23_P.PulseGenerator_Duty';
xcp.parameters(181).size   =  1;       
xcp.parameters(181).dtname = 'real_T'; 
xcp.parameters(182).baseaddr = '&may23_P.PulseGenerator_Duty';     
         
xcp.parameters(182).symbol = 'may23_P.PulseGenerator_PhaseDelay';
xcp.parameters(182).size   =  1;       
xcp.parameters(182).dtname = 'real_T'; 
xcp.parameters(183).baseaddr = '&may23_P.PulseGenerator_PhaseDelay';     
         
xcp.parameters(183).symbol = 'may23_P.NotLoggingAnalogInputs_Value';
xcp.parameters(183).size   =  1;       
xcp.parameters(183).dtname = 'real_T'; 
xcp.parameters(184).baseaddr = '&may23_P.NotLoggingAnalogInputs_Value';     
         
xcp.parameters(184).symbol = 'may23_P.custom_version_Value';
xcp.parameters(184).size   =  1;       
xcp.parameters(184).dtname = 'real_T'; 
xcp.parameters(185).baseaddr = '&may23_P.custom_version_Value';     
         
xcp.parameters(185).symbol = 'may23_P.RateTransition2_InitialCondition_l';
xcp.parameters(185).size   =  1;       
xcp.parameters(185).dtname = 'real_T'; 
xcp.parameters(186).baseaddr = '&may23_P.RateTransition2_InitialCondition_l';     
         
xcp.parameters(186).symbol = 'may23_P.NotLoggingEventCodes_Value';
xcp.parameters(186).size   =  1;       
xcp.parameters(186).dtname = 'real_T'; 
xcp.parameters(187).baseaddr = '&may23_P.NotLoggingEventCodes_Value';     
         
xcp.parameters(187).symbol = 'may23_P.IfRunning_const';
xcp.parameters(187).size   =  1;       
xcp.parameters(187).dtname = 'uint32_T'; 
xcp.parameters(188).baseaddr = '&may23_P.IfRunning_const';     
         
xcp.parameters(188).symbol = 'may23_P.packet_version_Value';
xcp.parameters(188).size   =  1;       
xcp.parameters(188).dtname = 'real_T'; 
xcp.parameters(189).baseaddr = '&may23_P.packet_version_Value';     
         
xcp.parameters(189).symbol = 'may23_P.const_Value';
xcp.parameters(189).size   =  5;       
xcp.parameters(189).dtname = 'real_T'; 
xcp.parameters(190).baseaddr = '&may23_P.const_Value[0]';     
         
xcp.parameters(190).symbol = 'may23_P.Send_P1';
xcp.parameters(190).size   =  26;       
xcp.parameters(190).dtname = 'real_T'; 
xcp.parameters(191).baseaddr = '&may23_P.Send_P1[0]';     
         
xcp.parameters(191).symbol = 'may23_P.Send_P2';
xcp.parameters(191).size   =  1;       
xcp.parameters(191).dtname = 'real_T'; 
xcp.parameters(192).baseaddr = '&may23_P.Send_P2';     
         
xcp.parameters(192).symbol = 'may23_P.Send_P3';
xcp.parameters(192).size   =  11;       
xcp.parameters(192).dtname = 'real_T'; 
xcp.parameters(193).baseaddr = '&may23_P.Send_P3[0]';     
         
xcp.parameters(193).symbol = 'may23_P.Send_P4';
xcp.parameters(193).size   =  1;       
xcp.parameters(193).dtname = 'real_T'; 
xcp.parameters(194).baseaddr = '&may23_P.Send_P4';     
         
xcp.parameters(194).symbol = 'may23_P.Send_P5';
xcp.parameters(194).size   =  1;       
xcp.parameters(194).dtname = 'real_T'; 
xcp.parameters(195).baseaddr = '&may23_P.Send_P5';     
         
xcp.parameters(195).symbol = 'may23_P.Send_P6';
xcp.parameters(195).size   =  1;       
xcp.parameters(195).dtname = 'real_T'; 
xcp.parameters(196).baseaddr = '&may23_P.Send_P6';     
         
xcp.parameters(196).symbol = 'may23_P.max_packet_id_Value';
xcp.parameters(196).size   =  1;       
xcp.parameters(196).dtname = 'uint32_T'; 
xcp.parameters(197).baseaddr = '&may23_P.max_packet_id_Value';     
         
xcp.parameters(197).symbol = 'may23_P.runID_Value';
xcp.parameters(197).size   =  1;       
xcp.parameters(197).dtname = 'real_T'; 
xcp.parameters(198).baseaddr = '&may23_P.runID_Value';     
         
xcp.parameters(198).symbol = 'may23_P.TaskClock_Amp';
xcp.parameters(198).size   =  1;       
xcp.parameters(198).dtname = 'real_T'; 
xcp.parameters(199).baseaddr = '&may23_P.TaskClock_Amp';     
         
xcp.parameters(199).symbol = 'may23_P.TaskClock_Period';
xcp.parameters(199).size   =  1;       
xcp.parameters(199).dtname = 'real_T'; 
xcp.parameters(200).baseaddr = '&may23_P.TaskClock_Period';     
         
xcp.parameters(200).symbol = 'may23_P.TaskClock_Duty';
xcp.parameters(200).size   =  1;       
xcp.parameters(200).dtname = 'real_T'; 
xcp.parameters(201).baseaddr = '&may23_P.TaskClock_Duty';     
         
xcp.parameters(201).symbol = 'may23_P.TaskClock_PhaseDelay';
xcp.parameters(201).size   =  1;       
xcp.parameters(201).dtname = 'real_T'; 
xcp.parameters(202).baseaddr = '&may23_P.TaskClock_PhaseDelay';     
         
xcp.parameters(202).symbol = 'may23_P.RateTransition1_InitialCondition_c';
xcp.parameters(202).size   =  1;       
xcp.parameters(202).dtname = 'real32_T'; 
xcp.parameters(203).baseaddr = '&may23_P.RateTransition1_InitialCondition_c';     
         
xcp.parameters(203).symbol = 'may23_P.ain_offset1_Value';
xcp.parameters(203).size   =  1;       
xcp.parameters(203).dtname = 'real_T'; 
xcp.parameters(204).baseaddr = '&may23_P.ain_offset1_Value';     
         
xcp.parameters(204).symbol = 'may23_P.ain_offset2_Value';
xcp.parameters(204).size   =  1;       
xcp.parameters(204).dtname = 'real_T'; 
xcp.parameters(205).baseaddr = '&may23_P.ain_offset2_Value';     
         
xcp.parameters(205).symbol = 'may23_P.ain_slope1_Value';
xcp.parameters(205).size   =  1;       
xcp.parameters(205).dtname = 'real_T'; 
xcp.parameters(206).baseaddr = '&may23_P.ain_slope1_Value';     
         
xcp.parameters(206).symbol = 'may23_P.ain_slope2_Value';
xcp.parameters(206).size   =  1;       
xcp.parameters(206).dtname = 'real_T'; 
xcp.parameters(207).baseaddr = '&may23_P.ain_slope2_Value';     
         
xcp.parameters(207).symbol = 'may23_P.calibration_matrix1_Value';
xcp.parameters(207).size   =  48;       
xcp.parameters(207).dtname = 'real_T'; 
xcp.parameters(208).baseaddr = '&may23_P.calibration_matrix1_Value[0]';     
         
xcp.parameters(208).symbol = 'may23_P.calibration_matrix2_Value';
xcp.parameters(208).size   =  48;       
xcp.parameters(208).dtname = 'real_T'; 
xcp.parameters(209).baseaddr = '&may23_P.calibration_matrix2_Value[0]';     
         
xcp.parameters(209).symbol = 'may23_P.enable_plate1_Value';
xcp.parameters(209).size   =  1;       
xcp.parameters(209).dtname = 'real_T'; 
xcp.parameters(210).baseaddr = '&may23_P.enable_plate1_Value';     
         
xcp.parameters(210).symbol = 'may23_P.enable_plate2_Value';
xcp.parameters(210).size   =  1;       
xcp.parameters(210).dtname = 'real_T'; 
xcp.parameters(211).baseaddr = '&may23_P.enable_plate2_Value';     
         
xcp.parameters(211).symbol = 'may23_P.gain_Value';
xcp.parameters(211).size   =  1;       
xcp.parameters(211).dtname = 'real_T'; 
xcp.parameters(212).baseaddr = '&may23_P.gain_Value';     
         
xcp.parameters(212).symbol = 'may23_P.orientation1_Value';
xcp.parameters(212).size   =  1;       
xcp.parameters(212).dtname = 'real_T'; 
xcp.parameters(213).baseaddr = '&may23_P.orientation1_Value';     
         
xcp.parameters(213).symbol = 'may23_P.orientation2_Value';
xcp.parameters(213).size   =  1;       
xcp.parameters(213).dtname = 'real_T'; 
xcp.parameters(214).baseaddr = '&may23_P.orientation2_Value';     
         
xcp.parameters(214).symbol = 'may23_P.request_packet_Value';
xcp.parameters(214).size   =  34;       
xcp.parameters(214).dtname = 'int32_T'; 
xcp.parameters(215).baseaddr = '&may23_P.request_packet_Value[0]';     
         
xcp.parameters(215).symbol = 'may23_P.zero_voltage_Value';
xcp.parameters(215).size   =  1;       
xcp.parameters(215).dtname = 'real_T'; 
xcp.parameters(216).baseaddr = '&may23_P.zero_voltage_Value';     
         
xcp.parameters(216).symbol = 'may23_P.ECATDigitalin_InitialValue';
xcp.parameters(216).size   =  8;       
xcp.parameters(216).dtname = 'uint32_T'; 
xcp.parameters(217).baseaddr = '&may23_P.ECATDigitalin_InitialValue[0]';     
         
xcp.parameters(217).symbol = 'may23_P.ECATErrMsgs_InitialValue';
xcp.parameters(217).size   =  20;       
xcp.parameters(217).dtname = 'real_T'; 
xcp.parameters(218).baseaddr = '&may23_P.ECATErrMsgs_InitialValue[0]';     
         
xcp.parameters(218).symbol = 'may23_P.ECATTorquefeedback_InitialValue';
xcp.parameters(218).size   =  10;       
xcp.parameters(218).dtname = 'real_T'; 
xcp.parameters(219).baseaddr = '&may23_P.ECATTorquefeedback_InitialValue[0]';     
         
xcp.parameters(219).symbol = 'may23_P.HWSettings_InitialValue';
xcp.parameters(219).size   =  25;       
xcp.parameters(219).dtname = 'real_T'; 
xcp.parameters(220).baseaddr = '&may23_P.HWSettings_InitialValue[0]';     
         
xcp.parameters(220).symbol = 'may23_P.Kinematics_InitialValue';
xcp.parameters(220).size   =  20;       
xcp.parameters(220).dtname = 'real_T'; 
xcp.parameters(221).baseaddr = '&may23_P.Kinematics_InitialValue[0]';     
         
xcp.parameters(221).symbol = 'may23_P.PrimaryEnc_InitialValue';
xcp.parameters(221).size   =  12;       
xcp.parameters(221).dtname = 'real_T'; 
xcp.parameters(222).baseaddr = '&may23_P.PrimaryEnc_InitialValue[0]';     
         
xcp.parameters(222).symbol = 'may23_P.RobotCalib_InitialValue';
xcp.parameters(222).size   =  16;       
xcp.parameters(222).dtname = 'real_T'; 
xcp.parameters(223).baseaddr = '&may23_P.RobotCalib_InitialValue[0]';     
         
xcp.parameters(223).symbol = 'may23_P.RobotRevision_InitialValue';
xcp.parameters(223).size   =  2;       
xcp.parameters(223).dtname = 'real_T'; 
xcp.parameters(224).baseaddr = '&may23_P.RobotRevision_InitialValue[0]';     
         
xcp.parameters(224).symbol = 'may23_P.ServoUpdate_InitialValue';
xcp.parameters(224).size   =  1;       
xcp.parameters(224).dtname = 'uint32_T'; 
xcp.parameters(225).baseaddr = '&may23_P.ServoUpdate_InitialValue';     
         
xcp.parameters(225).symbol = 'may23_P.Systemstatus_InitialValue';
xcp.parameters(225).size   =  7;       
xcp.parameters(225).dtname = 'uint32_T'; 
xcp.parameters(226).baseaddr = '&may23_P.Systemstatus_InitialValue[0]';     
         
xcp.parameters(226).symbol = 'may23_P.calibbutton_InitialValue';
xcp.parameters(226).size   =  1;       
xcp.parameters(226).dtname = 'uint32_T'; 
xcp.parameters(227).baseaddr = '&may23_P.calibbutton_InitialValue';     
         
xcp.parameters(227).symbol = 'may23_P.delays_InitialValue';
xcp.parameters(227).size   =  4;       
xcp.parameters(227).dtname = 'real_T'; 
xcp.parameters(228).baseaddr = '&may23_P.delays_InitialValue[0]';     
         
xcp.parameters(228).symbol = 'may23_P.hasFTsensors_InitialValue';
xcp.parameters(228).size   =  3;       
xcp.parameters(228).dtname = 'real_T'; 
xcp.parameters(229).baseaddr = '&may23_P.hasFTsensors_InitialValue[0]';     
         
xcp.parameters(229).symbol = 'may23_P.isecat_const';
xcp.parameters(229).size   =  1;       
xcp.parameters(229).dtname = 'real_T'; 
xcp.parameters(230).baseaddr = '&may23_P.isecat_const';     
         
xcp.parameters(230).symbol = 'may23_P.systemtype_Value';
xcp.parameters(230).size   =  1;       
xcp.parameters(230).dtname = 'real_T'; 
xcp.parameters(231).baseaddr = '&may23_P.systemtype_Value';     
         
xcp.parameters(231).symbol = 'may23_P.ELCameraAngle_Value';
xcp.parameters(231).size   =  2;       
xcp.parameters(231).dtname = 'real_T'; 
xcp.parameters(232).baseaddr = '&may23_P.ELCameraAngle_Value[0]';     
         
xcp.parameters(232).symbol = 'may23_P.ELCameraFocalLength_Value';
xcp.parameters(232).size   =  1;       
xcp.parameters(232).dtname = 'real_T'; 
xcp.parameters(233).baseaddr = '&may23_P.ELCameraFocalLength_Value';     
         
xcp.parameters(233).symbol = 'may23_P.ELCameraPosition_Value';
xcp.parameters(233).size   =  3;       
xcp.parameters(233).dtname = 'real_T'; 
xcp.parameters(234).baseaddr = '&may23_P.ELCameraPosition_Value[0]';     
         
xcp.parameters(234).symbol = 'may23_P.ELTrackingAvailable_Value';
xcp.parameters(234).size   =  1;       
xcp.parameters(234).dtname = 'real_T'; 
xcp.parameters(235).baseaddr = '&may23_P.ELTrackingAvailable_Value';     
         
xcp.parameters(235).symbol = 'may23_P.Gain_Gain';
xcp.parameters(235).size   =  1;       
xcp.parameters(235).dtname = 'real_T'; 
xcp.parameters(236).baseaddr = '&may23_P.Gain_Gain';     
         
xcp.parameters(236).symbol = 'may23_P.RateTransition_InitialCondition';
xcp.parameters(236).size   =  1;       
xcp.parameters(236).dtname = 'real_T'; 
xcp.parameters(237).baseaddr = '&may23_P.RateTransition_InitialCondition';     
         
xcp.parameters(237).symbol = 'may23_P.Receive_P1_g';
xcp.parameters(237).size   =  26;       
xcp.parameters(237).dtname = 'real_T'; 
xcp.parameters(238).baseaddr = '&may23_P.Receive_P1_g[0]';     
         
xcp.parameters(238).symbol = 'may23_P.Receive_P2_e';
xcp.parameters(238).size   =  1;       
xcp.parameters(238).dtname = 'real_T'; 
xcp.parameters(239).baseaddr = '&may23_P.Receive_P2_e';     
         
xcp.parameters(239).symbol = 'may23_P.Receive_P3_c';
xcp.parameters(239).size   =  1;       
xcp.parameters(239).dtname = 'real_T'; 
xcp.parameters(240).baseaddr = '&may23_P.Receive_P3_c';     
         
xcp.parameters(240).symbol = 'may23_P.Receive_P4_m';
xcp.parameters(240).size   =  1;       
xcp.parameters(240).dtname = 'real_T'; 
xcp.parameters(241).baseaddr = '&may23_P.Receive_P4_m';     
         
xcp.parameters(241).symbol = 'may23_P.Receive_P5_o';
xcp.parameters(241).size   =  7;       
xcp.parameters(241).dtname = 'real_T'; 
xcp.parameters(242).baseaddr = '&may23_P.Receive_P5_o[0]';     
         
xcp.parameters(242).symbol = 'may23_P.Receive_P6_m';
xcp.parameters(242).size   =  1;       
xcp.parameters(242).dtname = 'real_T'; 
xcp.parameters(243).baseaddr = '&may23_P.Receive_P6_m';     
         
xcp.parameters(243).symbol = 'may23_P.Receive_P7_l';
xcp.parameters(243).size   =  1;       
xcp.parameters(243).dtname = 'real_T'; 
xcp.parameters(244).baseaddr = '&may23_P.Receive_P7_l';     
         
xcp.parameters(244).symbol = 'may23_P.Receive_P9_c';
xcp.parameters(244).size   =  1;       
xcp.parameters(244).dtname = 'real_T'; 
xcp.parameters(245).baseaddr = '&may23_P.Receive_P9_c';     
         
xcp.parameters(245).symbol = 'may23_P.isecat_const_n';
xcp.parameters(245).size   =  1;       
xcp.parameters(245).dtname = 'real_T'; 
xcp.parameters(246).baseaddr = '&may23_P.isecat_const_n';     
         
xcp.parameters(246).symbol = 'may23_P.isecat1_const';
xcp.parameters(246).size   =  1;       
xcp.parameters(246).dtname = 'real_T'; 
xcp.parameters(247).baseaddr = '&may23_P.isecat1_const';     
         
xcp.parameters(247).symbol = 'may23_P.Delay_InitialCondition';
xcp.parameters(247).size   =  1;       
xcp.parameters(247).dtname = 'real_T'; 
xcp.parameters(248).baseaddr = '&may23_P.Delay_InitialCondition';     
         
xcp.parameters(248).symbol = 'may23_P.arm_count_Value';
xcp.parameters(248).size   =  1;       
xcp.parameters(248).dtname = 'real_T'; 
xcp.parameters(249).baseaddr = '&may23_P.arm_count_Value';     
         
xcp.parameters(249).symbol = 'may23_P.fp1_present_Value';
xcp.parameters(249).size   =  1;       
xcp.parameters(249).dtname = 'real_T'; 
xcp.parameters(250).baseaddr = '&may23_P.fp1_present_Value';     
         
xcp.parameters(250).symbol = 'may23_P.fp2_present_Value';
xcp.parameters(250).size   =  1;       
xcp.parameters(250).dtname = 'real_T'; 
xcp.parameters(251).baseaddr = '&may23_P.fp2_present_Value';     
         
xcp.parameters(251).symbol = 'may23_P.gaze_tracker_present_Value';
xcp.parameters(251).size   =  1;       
xcp.parameters(251).dtname = 'real_T'; 
xcp.parameters(252).baseaddr = '&may23_P.gaze_tracker_present_Value';     
         
xcp.parameters(252).symbol = 'may23_P.robot_lift_present_Value';
xcp.parameters(252).size   =  1;       
xcp.parameters(252).dtname = 'real_T'; 
xcp.parameters(253).baseaddr = '&may23_P.robot_lift_present_Value';     
         
xcp.parameters(253).symbol = 'may23_P.CompareToConstant_const';
xcp.parameters(253).size   =  1;       
xcp.parameters(253).dtname = 'real_T'; 
xcp.parameters(254).baseaddr = '&may23_P.CompareToConstant_const';     
         
xcp.parameters(254).symbol = 'may23_P.abs_diff_Value';
xcp.parameters(254).size   =  1;       
xcp.parameters(254).dtname = 'real_T'; 
xcp.parameters(255).baseaddr = '&may23_P.abs_diff_Value';     
         
xcp.parameters(255).symbol = 'may23_P.butterworth_2nd_order_10hz_Value';
xcp.parameters(255).size   =  3;       
xcp.parameters(255).dtname = 'real_T'; 
xcp.parameters(256).baseaddr = '&may23_P.butterworth_2nd_order_10hz_Value[0]';     
         
xcp.parameters(256).symbol = 'may23_P.rel_diff_Value';
xcp.parameters(256).size   =  1;       
xcp.parameters(256).dtname = 'real_T'; 
xcp.parameters(257).baseaddr = '&may23_P.rel_diff_Value';     
         
xcp.parameters(257).symbol = 'may23_P.TaskClock_Amp_l';
xcp.parameters(257).size   =  1;       
xcp.parameters(257).dtname = 'real_T'; 
xcp.parameters(258).baseaddr = '&may23_P.TaskClock_Amp_l';     
         
xcp.parameters(258).symbol = 'may23_P.TaskClock_Period_m';
xcp.parameters(258).size   =  1;       
xcp.parameters(258).dtname = 'real_T'; 
xcp.parameters(259).baseaddr = '&may23_P.TaskClock_Period_m';     
         
xcp.parameters(259).symbol = 'may23_P.TaskClock_Duty_f';
xcp.parameters(259).size   =  1;       
xcp.parameters(259).dtname = 'real_T'; 
xcp.parameters(260).baseaddr = '&may23_P.TaskClock_Duty_f';     
         
xcp.parameters(260).symbol = 'may23_P.TaskClock_PhaseDelay_hb';
xcp.parameters(260).size   =  1;       
xcp.parameters(260).dtname = 'real_T'; 
xcp.parameters(261).baseaddr = '&may23_P.TaskClock_PhaseDelay_hb';     
         
xcp.parameters(261).symbol = 'may23_P.Memory1_InitialCondition_b';
xcp.parameters(261).size   =  1;       
xcp.parameters(261).dtname = 'real_T'; 
xcp.parameters(262).baseaddr = '&may23_P.Memory1_InitialCondition_b';     
         
xcp.parameters(262).symbol = 'may23_P.Memory2_InitialCondition_d';
xcp.parameters(262).size   =  1;       
xcp.parameters(262).dtname = 'real_T'; 
xcp.parameters(263).baseaddr = '&may23_P.Memory2_InitialCondition_d';     
         
xcp.parameters(263).symbol = 'may23_P.Delay_InitialCondition_c';
xcp.parameters(263).size   =  1;       
xcp.parameters(263).dtname = 'real_T'; 
xcp.parameters(264).baseaddr = '&may23_P.Delay_InitialCondition_c';     
         
xcp.parameters(264).symbol = 'may23_P.preview_detail_Value';
xcp.parameters(264).size   =  3;       
xcp.parameters(264).dtname = 'real_T'; 
xcp.parameters(265).baseaddr = '&may23_P.preview_detail_Value[0]';     
         
xcp.parameters(265).symbol = 'may23_P.RunCommandReceive_P1';
xcp.parameters(265).size   =  26;       
xcp.parameters(265).dtname = 'real_T'; 
xcp.parameters(266).baseaddr = '&may23_P.RunCommandReceive_P1[0]';     
         
xcp.parameters(266).symbol = 'may23_P.RunCommandReceive_P2';
xcp.parameters(266).size   =  1;       
xcp.parameters(266).dtname = 'real_T'; 
xcp.parameters(267).baseaddr = '&may23_P.RunCommandReceive_P2';     
         
xcp.parameters(267).symbol = 'may23_P.RunCommandReceive_P3';
xcp.parameters(267).size   =  1;       
xcp.parameters(267).dtname = 'real_T'; 
xcp.parameters(268).baseaddr = '&may23_P.RunCommandReceive_P3';     
         
xcp.parameters(268).symbol = 'may23_P.RunCommandReceive_P4';
xcp.parameters(268).size   =  1;       
xcp.parameters(268).dtname = 'real_T'; 
xcp.parameters(269).baseaddr = '&may23_P.RunCommandReceive_P4';     
         
xcp.parameters(269).symbol = 'may23_P.RunCommandReceive_P5';
xcp.parameters(269).size   =  7;       
xcp.parameters(269).dtname = 'real_T'; 
xcp.parameters(270).baseaddr = '&may23_P.RunCommandReceive_P5[0]';     
         
xcp.parameters(270).symbol = 'may23_P.RunCommandReceive_P6';
xcp.parameters(270).size   =  1;       
xcp.parameters(270).dtname = 'real_T'; 
xcp.parameters(271).baseaddr = '&may23_P.RunCommandReceive_P6';     
         
xcp.parameters(271).symbol = 'may23_P.RunCommandReceive_P7';
xcp.parameters(271).size   =  1;       
xcp.parameters(271).dtname = 'real_T'; 
xcp.parameters(272).baseaddr = '&may23_P.RunCommandReceive_P7';     
         
xcp.parameters(272).symbol = 'may23_P.RunCommandReceive_P9';
xcp.parameters(272).size   =  1;       
xcp.parameters(272).dtname = 'real_T'; 
xcp.parameters(273).baseaddr = '&may23_P.RunCommandReceive_P9';     
         
xcp.parameters(273).symbol = 'may23_P.CompareToConstant_const_g';
xcp.parameters(273).size   =  1;       
xcp.parameters(273).dtname = 'uint32_T'; 
xcp.parameters(274).baseaddr = '&may23_P.CompareToConstant_const_g';     
         
xcp.parameters(274).symbol = 'may23_P.Constant_Value_l';
xcp.parameters(274).size   =  1;       
xcp.parameters(274).dtname = 'real_T'; 
xcp.parameters(275).baseaddr = '&may23_P.Constant_Value_l';     
         
xcp.parameters(275).symbol = 'may23_P.TaskClock_Amp_b';
xcp.parameters(275).size   =  1;       
xcp.parameters(275).dtname = 'real_T'; 
xcp.parameters(276).baseaddr = '&may23_P.TaskClock_Amp_b';     
         
xcp.parameters(276).symbol = 'may23_P.TaskClock_Period_f';
xcp.parameters(276).size   =  1;       
xcp.parameters(276).dtname = 'real_T'; 
xcp.parameters(277).baseaddr = '&may23_P.TaskClock_Period_f';     
         
xcp.parameters(277).symbol = 'may23_P.TaskClock_Duty_p';
xcp.parameters(277).size   =  1;       
xcp.parameters(277).dtname = 'real_T'; 
xcp.parameters(278).baseaddr = '&may23_P.TaskClock_Duty_p';     
         
xcp.parameters(278).symbol = 'may23_P.TaskClock_PhaseDelay_h';
xcp.parameters(278).size   =  1;       
xcp.parameters(278).dtname = 'real_T'; 
xcp.parameters(279).baseaddr = '&may23_P.TaskClock_PhaseDelay_h';     
         
xcp.parameters(279).symbol = 'may23_P.Delay_InitialCondition_g';
xcp.parameters(279).size   =  1;       
xcp.parameters(279).dtname = 'boolean_T'; 
xcp.parameters(280).baseaddr = '&may23_P.Delay_InitialCondition_g';     
         
xcp.parameters(280).symbol = 'may23_P.Delay1_InitialCondition';
xcp.parameters(280).size   =  1;       
xcp.parameters(280).dtname = 'real_T'; 
xcp.parameters(281).baseaddr = '&may23_P.Delay1_InitialCondition';     
         
xcp.parameters(281).symbol = 'may23_P.DetectChange_vinit_m';
xcp.parameters(281).size   =  1;       
xcp.parameters(281).dtname = 'boolean_T'; 
xcp.parameters(282).baseaddr = '&may23_P.DetectChange_vinit_m';     
         
xcp.parameters(282).symbol = 'may23_P.DetectChange1_vinit';
xcp.parameters(282).size   =  1;       
xcp.parameters(282).dtname = 'boolean_T'; 
xcp.parameters(283).baseaddr = '&may23_P.DetectChange1_vinit';     
         
xcp.parameters(283).symbol = 'may23_P.CompareToConstant_const_f';
xcp.parameters(283).size   =  1;       
xcp.parameters(283).dtname = 'uint32_T'; 
xcp.parameters(284).baseaddr = '&may23_P.CompareToConstant_const_f';     
         
xcp.parameters(284).symbol = 'may23_P.TorqueLimit5_Value';
xcp.parameters(284).size   =  1;       
xcp.parameters(284).dtname = 'real_T'; 
xcp.parameters(285).baseaddr = '&may23_P.TorqueLimit5_Value';     
         
xcp.parameters(285).symbol = 'may23_P.Switch1_Threshold_j';
xcp.parameters(285).size   =  1;       
xcp.parameters(285).dtname = 'real_T'; 
xcp.parameters(286).baseaddr = '&may23_P.Switch1_Threshold_j';     
         
xcp.parameters(286).symbol = 'may23_P.Switch_Threshold_g';
xcp.parameters(286).size   =  1;       
xcp.parameters(286).dtname = 'real_T'; 
xcp.parameters(287).baseaddr = '&may23_P.Switch_Threshold_g';     
         
xcp.parameters(287).symbol = 'may23_P.Switch1_Threshold_h';
xcp.parameters(287).size   =  1;       
xcp.parameters(287).dtname = 'real_T'; 
xcp.parameters(288).baseaddr = '&may23_P.Switch1_Threshold_h';     
         
xcp.parameters(288).symbol = 'may23_P.Switch2_Threshold';
xcp.parameters(288).size   =  1;       
xcp.parameters(288).dtname = 'real_T'; 
xcp.parameters(289).baseaddr = '&may23_P.Switch2_Threshold';     
         
xcp.parameters(289).symbol = 'may23_P.Switch3_Threshold';
xcp.parameters(289).size   =  1;       
xcp.parameters(289).dtname = 'real_T'; 
xcp.parameters(290).baseaddr = '&may23_P.Switch3_Threshold';     
         
xcp.parameters(290).symbol = 'may23_P.Switch4_Threshold';
xcp.parameters(290).size   =  1;       
xcp.parameters(290).dtname = 'real_T'; 
xcp.parameters(291).baseaddr = '&may23_P.Switch4_Threshold';     
         
xcp.parameters(291).symbol = 'may23_P.Switch5_Threshold';
xcp.parameters(291).size   =  1;       
xcp.parameters(291).dtname = 'real_T'; 
xcp.parameters(292).baseaddr = '&may23_P.Switch5_Threshold';     
         
xcp.parameters(292).symbol = 'may23_P.Switch6_Threshold';
xcp.parameters(292).size   =  1;       
xcp.parameters(292).dtname = 'real_T'; 
xcp.parameters(293).baseaddr = '&may23_P.Switch6_Threshold';     
         
xcp.parameters(293).symbol = 'may23_P.Switch7_Threshold';
xcp.parameters(293).size   =  1;       
xcp.parameters(293).dtname = 'real_T'; 
xcp.parameters(294).baseaddr = '&may23_P.Switch7_Threshold';     
         
xcp.parameters(294).symbol = 'may23_P.Switch_Threshold_h';
xcp.parameters(294).size   =  1;       
xcp.parameters(294).dtname = 'real_T'; 
xcp.parameters(295).baseaddr = '&may23_P.Switch_Threshold_h';     
         
xcp.parameters(295).symbol = 'may23_P.Switch1_Threshold_b';
xcp.parameters(295).size   =  1;       
xcp.parameters(295).dtname = 'real_T'; 
xcp.parameters(296).baseaddr = '&may23_P.Switch1_Threshold_b';     
         
xcp.parameters(296).symbol = 'may23_P.Switch2_Threshold_p';
xcp.parameters(296).size   =  1;       
xcp.parameters(296).dtname = 'real_T'; 
xcp.parameters(297).baseaddr = '&may23_P.Switch2_Threshold_p';     
         
xcp.parameters(297).symbol = 'may23_P.Switch3_Threshold_g';
xcp.parameters(297).size   =  1;       
xcp.parameters(297).dtname = 'real_T'; 
xcp.parameters(298).baseaddr = '&may23_P.Switch3_Threshold_g';     
         
xcp.parameters(298).symbol = 'may23_P.Switch4_Threshold_h';
xcp.parameters(298).size   =  1;       
xcp.parameters(298).dtname = 'real_T'; 
xcp.parameters(299).baseaddr = '&may23_P.Switch4_Threshold_h';     
         
xcp.parameters(299).symbol = 'may23_P.Switch5_Threshold_j';
xcp.parameters(299).size   =  1;       
xcp.parameters(299).dtname = 'real_T'; 
xcp.parameters(300).baseaddr = '&may23_P.Switch5_Threshold_j';     
         
xcp.parameters(300).symbol = 'may23_P.Switch6_Threshold_o';
xcp.parameters(300).size   =  1;       
xcp.parameters(300).dtname = 'real_T'; 
xcp.parameters(301).baseaddr = '&may23_P.Switch6_Threshold_o';     
         
xcp.parameters(301).symbol = 'may23_P.Switch7_Threshold_l';
xcp.parameters(301).size   =  1;       
xcp.parameters(301).dtname = 'real_T'; 
xcp.parameters(302).baseaddr = '&may23_P.Switch7_Threshold_l';     
         
xcp.parameters(302).symbol = 'may23_P.BARRIER_ROWBarriertargetBarriernone_Value';
xcp.parameters(302).size   =  1;       
xcp.parameters(302).dtname = 'real_T'; 
xcp.parameters(303).baseaddr = '&may23_P.BARRIER_ROWBarriertargetBarriernone_Value';     
         
xcp.parameters(303).symbol = 'may23_P.CURSOR_ROWHandTargetRowtargethandnone_Value';
xcp.parameters(303).size   =  1;       
xcp.parameters(303).dtname = 'real_T'; 
xcp.parameters(304).baseaddr = '&may23_P.CURSOR_ROWHandTargetRowtargethandnone_Value';     
         
xcp.parameters(304).symbol = 'may23_P.GOAL_ROWGoalRowtargetGoalnone_Value';
xcp.parameters(304).size   =  1;       
xcp.parameters(304).dtname = 'real_T'; 
xcp.parameters(305).baseaddr = '&may23_P.GOAL_ROWGoalRowtargetGoalnone_Value';     
         
xcp.parameters(305).symbol = 'may23_P.GOAL_TIMEGoaltimesfloatTimethatpuckhastostayingoaltotriggersucc';
xcp.parameters(305).size   =  1;       
xcp.parameters(305).dtname = 'real_T'; 
xcp.parameters(306).baseaddr = '&may23_P.GOAL_TIMEGoaltimesfloatTimethatpuckhastostayingoaltotriggersucc';     
         
xcp.parameters(306).symbol = 'may23_P.LOAD_ROWLoadRowloadLoadnone_Value';
xcp.parameters(306).size   =  1;       
xcp.parameters(306).dtname = 'real_T'; 
xcp.parameters(307).baseaddr = '&may23_P.LOAD_ROWLoadRowloadLoadnone_Value';     
         
xcp.parameters(307).symbol = 'may23_P.PRESHOT_ROWPreshotAreatargetPreshotAreanone_Value';
xcp.parameters(307).size   =  1;       
xcp.parameters(307).dtname = 'real_T'; 
xcp.parameters(308).baseaddr = '&may23_P.PRESHOT_ROWPreshotAreatargetPreshotAreanone_Value';     
         
xcp.parameters(308).symbol = 'may23_P.PUCK_DAMPINGPuckdampingfloatDampingconstantonpuckbetween0and1no';
xcp.parameters(308).size   =  1;       
xcp.parameters(308).dtname = 'real_T'; 
xcp.parameters(309).baseaddr = '&may23_P.PUCK_DAMPINGPuckdampingfloatDampingconstantonpuckbetween0and1no';     
         
xcp.parameters(309).symbol = 'may23_P.PUCK_ROWPuckTargetRowtargetPucknone_Value';
xcp.parameters(309).size   =  1;       
xcp.parameters(309).dtname = 'real_T'; 
xcp.parameters(310).baseaddr = '&may23_P.PUCK_ROWPuckTargetRowtargetPucknone_Value';     
         
xcp.parameters(310).symbol = 'may23_P.SECONDSTrialdurationsfloatHowlongisthetrialinsecondsnone_Value';
xcp.parameters(310).size   =  1;       
xcp.parameters(310).dtname = 'real_T'; 
xcp.parameters(311).baseaddr = '&may23_P.SECONDSTrialdurationsfloatHowlongisthetrialinsecondsnone_Value';     
         
xcp.parameters(311).symbol = 'may23_P.SHOT_READY_TIMEShotreadytimesfloatTimetoholdinstarttargetduring';
xcp.parameters(311).size   =  1;       
xcp.parameters(311).dtname = 'real_T'; 
xcp.parameters(312).baseaddr = '&may23_P.SHOT_READY_TIMEShotreadytimesfloatTimetoholdinstarttargetduring';     
         
xcp.parameters(312).symbol = 'may23_P.SHOT_SET_TIMEShotsettimesfloatTimetoholdinstarttargetafterpresh';
xcp.parameters(312).size   =  1;       
xcp.parameters(312).dtname = 'real_T'; 
xcp.parameters(313).baseaddr = '&may23_P.SHOT_SET_TIMEShotsettimesfloatTimetoholdinstarttargetafterpresh';     
         
xcp.parameters(313).symbol = 'may23_P.SHOT_TIMEShottimesfloatTimetomakeashotintothegoalnone_Value';
xcp.parameters(313).size   =  1;       
xcp.parameters(313).dtname = 'real_T'; 
xcp.parameters(314).baseaddr = '&may23_P.SHOT_TIMEShottimesfloatTimetomakeashotintothegoalnone_Value';     
         
xcp.parameters(314).symbol = 'may23_P.START_HOLD_TIMEStartholdtimesfloatTimetoholdinstarttargetbefore';
xcp.parameters(314).size   =  1;       
xcp.parameters(314).dtname = 'real_T'; 
xcp.parameters(315).baseaddr = '&may23_P.START_HOLD_TIMEStartholdtimesfloatTimetoholdinstarttargetbefore';     
         
xcp.parameters(315).symbol = 'may23_P.START_ROWStartPositiontargetStartingSpotforPtnone_Value';
xcp.parameters(315).size   =  1;       
xcp.parameters(315).dtname = 'real_T'; 
xcp.parameters(316).baseaddr = '&may23_P.START_ROWStartPositiontargetStartingSpotforPtnone_Value';     
         
xcp.parameters(316).symbol = 'may23_P.E_BEGIN_PRESHOTbeginpreshotroutinenone_Value';
xcp.parameters(316).size   =  1;       
xcp.parameters(316).dtname = 'real_T'; 
xcp.parameters(317).baseaddr = '&may23_P.E_BEGIN_PRESHOTbeginpreshotroutinenone_Value';     
         
xcp.parameters(317).symbol = 'may23_P.E_ENTER_STARTenterstarttargetnone_Value';
xcp.parameters(317).size   =  1;       
xcp.parameters(317).dtname = 'real_T'; 
xcp.parameters(318).baseaddr = '&may23_P.E_ENTER_STARTenterstarttargetnone_Value';     
         
xcp.parameters(318).symbol = 'may23_P.E_FAILUREfailurered_Value';
xcp.parameters(318).size   =  1;       
xcp.parameters(318).dtname = 'real_T'; 
xcp.parameters(319).baseaddr = '&may23_P.E_FAILUREfailurered_Value';     
         
xcp.parameters(319).symbol = 'may23_P.E_HAND_IN_BARRIERhandinbarriernone_Value';
xcp.parameters(319).size   =  1;       
xcp.parameters(319).dtname = 'real_T'; 
xcp.parameters(320).baseaddr = '&may23_P.E_HAND_IN_BARRIERhandinbarriernone_Value';     
         
xcp.parameters(320).symbol = 'may23_P.E_NO_EVENTnaThisevent_codedoesnotsaveaneventinthedatafileitjust';
xcp.parameters(320).size   =  1;       
xcp.parameters(320).dtname = 'real_T'; 
xcp.parameters(321).baseaddr = '&may23_P.E_NO_EVENTnaThisevent_codedoesnotsaveaneventinthedatafileitjust';     
         
xcp.parameters(321).symbol = 'may23_P.E_PUCK_IN_BARRIERpuckinbarriernone_Value';
xcp.parameters(321).size   =  1;       
xcp.parameters(321).dtname = 'real_T'; 
xcp.parameters(322).baseaddr = '&may23_P.E_PUCK_IN_BARRIERpuckinbarriernone_Value';     
         
xcp.parameters(322).symbol = 'may23_P.E_PUCK_IN_GOALpuckingoalnone_Value';
xcp.parameters(322).size   =  1;       
xcp.parameters(322).dtname = 'real_T'; 
xcp.parameters(323).baseaddr = '&may23_P.E_PUCK_IN_GOALpuckingoalnone_Value';     
         
xcp.parameters(323).symbol = 'may23_P.E_PUCK_MISSpuckmissnone_Value';
xcp.parameters(323).size   =  1;       
xcp.parameters(323).dtname = 'real_T'; 
xcp.parameters(324).baseaddr = '&may23_P.E_PUCK_MISSpuckmissnone_Value';     
         
xcp.parameters(324).symbol = 'may23_P.E_SHOT_GOshotgonone_Value';
xcp.parameters(324).size   =  1;       
xcp.parameters(324).dtname = 'real_T'; 
xcp.parameters(325).baseaddr = '&may23_P.E_SHOT_GOshotgonone_Value';     
         
xcp.parameters(325).symbol = 'may23_P.E_SHOT_READYshotreadynone_Value';
xcp.parameters(325).size   =  1;       
xcp.parameters(325).dtname = 'real_T'; 
xcp.parameters(326).baseaddr = '&may23_P.E_SHOT_READYshotreadynone_Value';     
         
xcp.parameters(326).symbol = 'may23_P.E_START_TARGET_ONstarttargetonnone_Value';
xcp.parameters(326).size   =  1;       
xcp.parameters(326).dtname = 'real_T'; 
xcp.parameters(327).baseaddr = '&may23_P.E_START_TARGET_ONstarttargetonnone_Value';     
         
xcp.parameters(327).symbol = 'may23_P.E_SUCCESSsuccessgreen_Value';
xcp.parameters(327).size   =  1;       
xcp.parameters(327).dtname = 'real_T'; 
xcp.parameters(328).baseaddr = '&may23_P.E_SUCCESSsuccessgreen_Value';     
         
xcp.parameters(328).symbol = 'may23_P.E_TIMEOUTtimeoutred_Value';
xcp.parameters(328).size   =  1;       
xcp.parameters(328).dtname = 'real_T'; 
xcp.parameters(329).baseaddr = '&may23_P.E_TIMEOUTtimeoutred_Value';     
         
xcp.parameters(329).symbol = 'may23_P.E_TRIAL_STARTtrialstartnone_Value';
xcp.parameters(329).size   =  1;       
xcp.parameters(329).dtname = 'real_T'; 
xcp.parameters(330).baseaddr = '&may23_P.E_TRIAL_STARTtrialstartnone_Value';     
         
xcp.parameters(330).symbol = 'may23_P.F_BUMPF_BUMPfloatCompletelyarbitraryparameterbasedonwhatfeelsgo';
xcp.parameters(330).size   =  1;       
xcp.parameters(330).dtname = 'real_T'; 
xcp.parameters(331).baseaddr = '&may23_P.F_BUMPF_BUMPfloatCompletelyarbitraryparameterbasedonwhatfeelsgo';     
         
xcp.parameters(331).symbol = 'may23_P.MASS_CIRCLECircletargetmassfloatnone_Value';
xcp.parameters(331).size   =  1;       
xcp.parameters(331).dtname = 'real_T'; 
xcp.parameters(332).baseaddr = '&may23_P.MASS_CIRCLECircletargetmassfloatnone_Value';     
         
xcp.parameters(332).symbol = 'may23_P.MASS_RECTRectangletargetmassfloatnone_Value';
xcp.parameters(332).size   =  1;       
xcp.parameters(332).dtname = 'real_T'; 
xcp.parameters(333).baseaddr = '&may23_P.MASS_RECTRectangletargetmassfloatnone_Value';     
         
xcp.parameters(333).symbol = 'may23_P.PERT_DURPerturbationDurationfloatmsTimethattheperturbationishig';
xcp.parameters(333).size   =  1;       
xcp.parameters(333).dtname = 'real_T'; 
xcp.parameters(334).baseaddr = '&may23_P.PERT_DURPerturbationDurationfloatmsTimethattheperturbationishig';     
         
xcp.parameters(334).symbol = 'may23_P.PERT_RAMPPerturbationRampTimefloatmsTimefortheperturbationtoram';
xcp.parameters(334).size   =  1;       
xcp.parameters(334).dtname = 'real_T'; 
xcp.parameters(335).baseaddr = '&may23_P.PERT_RAMPPerturbationRampTimefloatmsTimefortheperturbationtoram';     
         
xcp.parameters(335).symbol = 'may23_P.FIRST_FILLFirstfillcolorcolourFirstfillcolorforaselectedtargetc';
xcp.parameters(335).size   =  1;       
xcp.parameters(335).dtname = 'real_T'; 
xcp.parameters(336).baseaddr = '&may23_P.FIRST_FILLFirstfillcolorcolourFirstfillcolorforaselectedtargetc';     
         
xcp.parameters(336).symbol = 'may23_P.HEIGHTHeightfloatRectangleheightcmnone_Value';
xcp.parameters(336).size   =  1;       
xcp.parameters(336).dtname = 'real_T'; 
xcp.parameters(337).baseaddr = '&may23_P.HEIGHTHeightfloatRectangleheightcmnone_Value';     
         
xcp.parameters(337).symbol = 'may23_P.RADIUS_LOGlogicalradiusfloatcomputationalradiuscmnone_Value';
xcp.parameters(337).size   =  1;       
xcp.parameters(337).dtname = 'real_T'; 
xcp.parameters(338).baseaddr = '&may23_P.RADIUS_LOGlogicalradiusfloatcomputationalradiuscmnone_Value';     
         
xcp.parameters(338).symbol = 'may23_P.RADIUS_VISradiusvisfloatradiusincmlegacynone_Value';
xcp.parameters(338).size   =  1;       
xcp.parameters(338).dtname = 'real_T'; 
xcp.parameters(339).baseaddr = '&may23_P.RADIUS_VISradiusvisfloatradiusincmlegacynone_Value';     
         
xcp.parameters(339).symbol = 'may23_P.ROTATIONRotationfloatRectangleroationdegreesnone_Value';
xcp.parameters(339).size   =  1;       
xcp.parameters(339).dtname = 'real_T'; 
xcp.parameters(340).baseaddr = '&may23_P.ROTATIONRotationfloatRectangleroationdegreesnone_Value';     
         
xcp.parameters(340).symbol = 'may23_P.SECOND_FILLSecondfillcolorcolourSecondfillcolorforaselectedtarg';
xcp.parameters(340).size   =  1;       
xcp.parameters(340).dtname = 'real_T'; 
xcp.parameters(341).baseaddr = '&may23_P.SECOND_FILLSecondfillcolorcolourSecondfillcolorforaselectedtarg';     
         
xcp.parameters(341).symbol = 'may23_P.STROKE_COLORStrokecolourcolourStrokecolorcolornone_Value';
xcp.parameters(341).size   =  1;       
xcp.parameters(341).dtname = 'real_T'; 
xcp.parameters(342).baseaddr = '&may23_P.STROKE_COLORStrokecolourcolourStrokecolorcolornone_Value';     
         
xcp.parameters(342).symbol = 'may23_P.STROKE_WIDTHWidthofthestrokefloatStrokeweightcmnone_Value';
xcp.parameters(342).size   =  1;       
xcp.parameters(342).dtname = 'real_T'; 
xcp.parameters(343).baseaddr = '&may23_P.STROKE_WIDTHWidthofthestrokefloatStrokeweightcmnone_Value';     
         
xcp.parameters(343).symbol = 'may23_P.THIRD_FILLthirdfillcolorcolourThirdfillcolorforaselectedtargetc';
xcp.parameters(343).size   =  1;       
xcp.parameters(343).dtname = 'real_T'; 
xcp.parameters(344).baseaddr = '&may23_P.THIRD_FILLthirdfillcolorcolourThirdfillcolorforaselectedtargetc';     
         
xcp.parameters(344).symbol = 'may23_P.WIDTHWidthorRadiusfloatRectanglewidthorCircleRadiuscmnone_Value';
xcp.parameters(344).size   =  1;       
xcp.parameters(344).dtname = 'real_T'; 
xcp.parameters(345).baseaddr = '&may23_P.WIDTHWidthorRadiusfloatRectanglewidthorCircleRadiuscmnone_Value';     
         
xcp.parameters(345).symbol = 'may23_P.col_xXfloatXPositioncmofthetargetrelativetolocal00none_Value';
xcp.parameters(345).size   =  1;       
xcp.parameters(345).dtname = 'real_T'; 
xcp.parameters(346).baseaddr = '&may23_P.col_xXfloatXPositioncmofthetargetrelativetolocal00none_Value';     
         
xcp.parameters(346).symbol = 'may23_P.col_yYfloatYPositioncmofthetargetrelativetolocal00none_Value';
xcp.parameters(346).size   =  1;       
xcp.parameters(346).dtname = 'real_T'; 
xcp.parameters(347).baseaddr = '&may23_P.col_yYfloatYPositioncmofthetargetrelativetolocal00none_Value';     
         
xcp.parameters(347).symbol = 'may23_P.INSTRUCTIONS_Value';
xcp.parameters(347).size   =  1;       
xcp.parameters(347).dtname = 'real_T'; 
xcp.parameters(348).baseaddr = '&may23_P.INSTRUCTIONS_Value';     
         
xcp.parameters(348).symbol = 'may23_P.LOAD_FOREITHER_Value';
xcp.parameters(348).size   =  1;       
xcp.parameters(348).dtname = 'real_T'; 
xcp.parameters(349).baseaddr = '&may23_P.LOAD_FOREITHER_Value';     
         
xcp.parameters(349).symbol = 'may23_P.FORCE_MULTIPLIERForcemultiplierfloatnone_Value';
xcp.parameters(349).size   =  1;       
xcp.parameters(349).dtname = 'real_T'; 
xcp.parameters(350).baseaddr = '&may23_P.FORCE_MULTIPLIERForcemultiplierfloatnone_Value';     
         
xcp.parameters(350).symbol = 'may23_P.u000hz_Value';
xcp.parameters(350).size   =  1;       
xcp.parameters(350).dtname = 'real_T'; 
xcp.parameters(351).baseaddr = '&may23_P.u000hz_Value';     
         
xcp.parameters(351).symbol = 'may23_P.RateTransition1_InitialCondition';
xcp.parameters(351).size   =  1;       
xcp.parameters(351).dtname = 'real_T'; 
xcp.parameters(352).baseaddr = '&may23_P.RateTransition1_InitialCondition';     
         
xcp.parameters(352).symbol = 'may23_P.Constant_Value_b';
xcp.parameters(352).size   =  1;       
xcp.parameters(352).dtname = 'real_T'; 
xcp.parameters(353).baseaddr = '&may23_P.Constant_Value_b';     
         
xcp.parameters(353).symbol = 'may23_P.Hand_Feedback_feedback_cntl_src';
xcp.parameters(353).size   =  1;       
xcp.parameters(353).dtname = 'real_T'; 
xcp.parameters(354).baseaddr = '&may23_P.Hand_Feedback_feedback_cntl_src';     
         
xcp.parameters(354).symbol = 'may23_P.WrapToZero_Threshold_my';
xcp.parameters(354).size   =  1;       
xcp.parameters(354).dtname = 'uint32_T'; 
xcp.parameters(355).baseaddr = '&may23_P.WrapToZero_Threshold_my';     
         
xcp.parameters(355).symbol = 'may23_P.Output_InitialCondition_k';
xcp.parameters(355).size   =  1;       
xcp.parameters(355).dtname = 'uint32_T'; 
xcp.parameters(356).baseaddr = '&may23_P.Output_InitialCondition_k';     
         
xcp.parameters(356).symbol = 'may23_P.Constant_Value_bt';
xcp.parameters(356).size   =  400;       
xcp.parameters(356).dtname = 'real32_T'; 
xcp.parameters(357).baseaddr = '&may23_P.Constant_Value_bt[0]';     
         
xcp.parameters(357).symbol = 'may23_P.Constant1_Value';
xcp.parameters(357).size   =  1;       
xcp.parameters(357).dtname = 'real_T'; 
xcp.parameters(358).baseaddr = '&may23_P.Constant1_Value';     
         
xcp.parameters(358).symbol = 'may23_P.MaxFramesPerPacket_Value';
xcp.parameters(358).size   =  1;       
xcp.parameters(358).dtname = 'real_T'; 
xcp.parameters(359).baseaddr = '&may23_P.MaxFramesPerPacket_Value';     
         
xcp.parameters(359).symbol = 'may23_P.t1_InitialCondition';
xcp.parameters(359).size   =  1;       
xcp.parameters(359).dtname = 'real32_T'; 
xcp.parameters(360).baseaddr = '&may23_P.t1_InitialCondition';     
         
xcp.parameters(360).symbol = 'may23_P.t2_InitialCondition';
xcp.parameters(360).size   =  1;       
xcp.parameters(360).dtname = 'real32_T'; 
xcp.parameters(361).baseaddr = '&may23_P.t2_InitialCondition';     
         
xcp.parameters(361).symbol = 'may23_P.Memory1_InitialCondition';
xcp.parameters(361).size   =  1;       
xcp.parameters(361).dtname = 'real_T'; 
xcp.parameters(362).baseaddr = '&may23_P.Memory1_InitialCondition';     
         
xcp.parameters(362).symbol = 'may23_P.Memory2_InitialCondition';
xcp.parameters(362).size   =  1;       
xcp.parameters(362).dtname = 'real_T'; 
xcp.parameters(363).baseaddr = '&may23_P.Memory2_InitialCondition';     
         
xcp.parameters(363).symbol = 'may23_P.Receive_P1';
xcp.parameters(363).size   =  26;       
xcp.parameters(363).dtname = 'real_T'; 
xcp.parameters(364).baseaddr = '&may23_P.Receive_P1[0]';     
         
xcp.parameters(364).symbol = 'may23_P.Receive_P2';
xcp.parameters(364).size   =  1;       
xcp.parameters(364).dtname = 'real_T'; 
xcp.parameters(365).baseaddr = '&may23_P.Receive_P2';     
         
xcp.parameters(365).symbol = 'may23_P.Receive_P3';
xcp.parameters(365).size   =  1;       
xcp.parameters(365).dtname = 'real_T'; 
xcp.parameters(366).baseaddr = '&may23_P.Receive_P3';     
         
xcp.parameters(366).symbol = 'may23_P.Receive_P4';
xcp.parameters(366).size   =  1;       
xcp.parameters(366).dtname = 'real_T'; 
xcp.parameters(367).baseaddr = '&may23_P.Receive_P4';     
         
xcp.parameters(367).symbol = 'may23_P.Receive_P5';
xcp.parameters(367).size   =  11;       
xcp.parameters(367).dtname = 'real_T'; 
xcp.parameters(368).baseaddr = '&may23_P.Receive_P5[0]';     
         
xcp.parameters(368).symbol = 'may23_P.Receive_P6';
xcp.parameters(368).size   =  1;       
xcp.parameters(368).dtname = 'real_T'; 
xcp.parameters(369).baseaddr = '&may23_P.Receive_P6';     
         
xcp.parameters(369).symbol = 'may23_P.Receive_P7';
xcp.parameters(369).size   =  1;       
xcp.parameters(369).dtname = 'real_T'; 
xcp.parameters(370).baseaddr = '&may23_P.Receive_P7';     
         
xcp.parameters(370).symbol = 'may23_P.Receive_P9';
xcp.parameters(370).size   =  1;       
xcp.parameters(370).dtname = 'real_T'; 
xcp.parameters(371).baseaddr = '&may23_P.Receive_P9';     
         
xcp.parameters(371).symbol = 'may23_P.total_packets_sent_Y0';
xcp.parameters(371).size   =  1;       
xcp.parameters(371).dtname = 'uint32_T'; 
xcp.parameters(372).baseaddr = '&may23_P.total_packets_sent_Y0';     
         
xcp.parameters(372).symbol = 'may23_P.Send_P1_d';
xcp.parameters(372).size   =  26;       
xcp.parameters(372).dtname = 'real_T'; 
xcp.parameters(373).baseaddr = '&may23_P.Send_P1_d[0]';     
         
xcp.parameters(373).symbol = 'may23_P.Send_P2_b';
xcp.parameters(373).size   =  1;       
xcp.parameters(373).dtname = 'real_T'; 
xcp.parameters(374).baseaddr = '&may23_P.Send_P2_b';     
         
xcp.parameters(374).symbol = 'may23_P.Send_P3_i';
xcp.parameters(374).size   =  11;       
xcp.parameters(374).dtname = 'real_T'; 
xcp.parameters(375).baseaddr = '&may23_P.Send_P3_i[0]';     
         
xcp.parameters(375).symbol = 'may23_P.Send_P4_a';
xcp.parameters(375).size   =  1;       
xcp.parameters(375).dtname = 'real_T'; 
xcp.parameters(376).baseaddr = '&may23_P.Send_P4_a';     
         
xcp.parameters(376).symbol = 'may23_P.Send_P5_e';
xcp.parameters(376).size   =  1;       
xcp.parameters(376).dtname = 'real_T'; 
xcp.parameters(377).baseaddr = '&may23_P.Send_P5_e';     
         
xcp.parameters(377).symbol = 'may23_P.Send_P6_e';
xcp.parameters(377).size   =  1;       
xcp.parameters(377).dtname = 'real_T'; 
xcp.parameters(378).baseaddr = '&may23_P.Send_P6_e';     
         
xcp.parameters(378).symbol = 'may23_P.RateTransition1_InitialCondition_l';
xcp.parameters(378).size   =  1;       
xcp.parameters(378).dtname = 'boolean_T'; 
xcp.parameters(379).baseaddr = '&may23_P.RateTransition1_InitialCondition_l';     
         
xcp.parameters(379).symbol = 'may23_P.RateTransition2_InitialCondition';
xcp.parameters(379).size   =  1;       
xcp.parameters(379).dtname = 'real_T'; 
xcp.parameters(380).baseaddr = '&may23_P.RateTransition2_InitialCondition';     
         
xcp.parameters(380).symbol = 'may23_P.Receive_P1_d';
xcp.parameters(380).size   =  26;       
xcp.parameters(380).dtname = 'real_T'; 
xcp.parameters(381).baseaddr = '&may23_P.Receive_P1_d[0]';     
         
xcp.parameters(381).symbol = 'may23_P.Receive_P2_p';
xcp.parameters(381).size   =  1;       
xcp.parameters(381).dtname = 'real_T'; 
xcp.parameters(382).baseaddr = '&may23_P.Receive_P2_p';     
         
xcp.parameters(382).symbol = 'may23_P.Receive_P3_g';
xcp.parameters(382).size   =  1;       
xcp.parameters(382).dtname = 'real_T'; 
xcp.parameters(383).baseaddr = '&may23_P.Receive_P3_g';     
         
xcp.parameters(383).symbol = 'may23_P.Receive_P4_g';
xcp.parameters(383).size   =  1;       
xcp.parameters(383).dtname = 'real_T'; 
xcp.parameters(384).baseaddr = '&may23_P.Receive_P4_g';     
         
xcp.parameters(384).symbol = 'may23_P.Receive_P5_a';
xcp.parameters(384).size   =  13;       
xcp.parameters(384).dtname = 'real_T'; 
xcp.parameters(385).baseaddr = '&may23_P.Receive_P5_a[0]';     
         
xcp.parameters(385).symbol = 'may23_P.Receive_P6_k';
xcp.parameters(385).size   =  1;       
xcp.parameters(385).dtname = 'real_T'; 
xcp.parameters(386).baseaddr = '&may23_P.Receive_P6_k';     
         
xcp.parameters(386).symbol = 'may23_P.Receive_P7_n';
xcp.parameters(386).size   =  1;       
xcp.parameters(386).dtname = 'real_T'; 
xcp.parameters(387).baseaddr = '&may23_P.Receive_P7_n';     
         
xcp.parameters(387).symbol = 'may23_P.Receive_P9_l';
xcp.parameters(387).size   =  1;       
xcp.parameters(387).dtname = 'real_T'; 
xcp.parameters(388).baseaddr = '&may23_P.Receive_P9_l';     
         
xcp.parameters(388).symbol = 'may23_P.Receive1_P1';
xcp.parameters(388).size   =  26;       
xcp.parameters(388).dtname = 'real_T'; 
xcp.parameters(389).baseaddr = '&may23_P.Receive1_P1[0]';     
         
xcp.parameters(389).symbol = 'may23_P.Receive1_P2';
xcp.parameters(389).size   =  1;       
xcp.parameters(389).dtname = 'real_T'; 
xcp.parameters(390).baseaddr = '&may23_P.Receive1_P2';     
         
xcp.parameters(390).symbol = 'may23_P.Receive1_P3';
xcp.parameters(390).size   =  1;       
xcp.parameters(390).dtname = 'real_T'; 
xcp.parameters(391).baseaddr = '&may23_P.Receive1_P3';     
         
xcp.parameters(391).symbol = 'may23_P.Receive1_P4';
xcp.parameters(391).size   =  1;       
xcp.parameters(391).dtname = 'real_T'; 
xcp.parameters(392).baseaddr = '&may23_P.Receive1_P4';     
         
xcp.parameters(392).symbol = 'may23_P.Receive1_P5';
xcp.parameters(392).size   =  13;       
xcp.parameters(392).dtname = 'real_T'; 
xcp.parameters(393).baseaddr = '&may23_P.Receive1_P5[0]';     
         
xcp.parameters(393).symbol = 'may23_P.Receive1_P6';
xcp.parameters(393).size   =  1;       
xcp.parameters(393).dtname = 'real_T'; 
xcp.parameters(394).baseaddr = '&may23_P.Receive1_P6';     
         
xcp.parameters(394).symbol = 'may23_P.Receive1_P7';
xcp.parameters(394).size   =  1;       
xcp.parameters(394).dtname = 'real_T'; 
xcp.parameters(395).baseaddr = '&may23_P.Receive1_P7';     
         
xcp.parameters(395).symbol = 'may23_P.Receive1_P9';
xcp.parameters(395).size   =  1;       
xcp.parameters(395).dtname = 'real_T'; 
xcp.parameters(396).baseaddr = '&may23_P.Receive1_P9';     
         
xcp.parameters(396).symbol = 'may23_P.Send_P1_o';
xcp.parameters(396).size   =  26;       
xcp.parameters(396).dtname = 'real_T'; 
xcp.parameters(397).baseaddr = '&may23_P.Send_P1_o[0]';     
         
xcp.parameters(397).symbol = 'may23_P.Send_P2_bb';
xcp.parameters(397).size   =  1;       
xcp.parameters(397).dtname = 'real_T'; 
xcp.parameters(398).baseaddr = '&may23_P.Send_P2_bb';     
         
xcp.parameters(398).symbol = 'may23_P.Send_P3_m';
xcp.parameters(398).size   =  13;       
xcp.parameters(398).dtname = 'real_T'; 
xcp.parameters(399).baseaddr = '&may23_P.Send_P3_m[0]';     
         
xcp.parameters(399).symbol = 'may23_P.Send_P4_f';
xcp.parameters(399).size   =  1;       
xcp.parameters(399).dtname = 'real_T'; 
xcp.parameters(400).baseaddr = '&may23_P.Send_P4_f';     
         
xcp.parameters(400).symbol = 'may23_P.Send_P5_i';
xcp.parameters(400).size   =  1;       
xcp.parameters(400).dtname = 'real_T'; 
xcp.parameters(401).baseaddr = '&may23_P.Send_P5_i';     
         
xcp.parameters(401).symbol = 'may23_P.Send_P6_p';
xcp.parameters(401).size   =  1;       
xcp.parameters(401).dtname = 'real_T'; 
xcp.parameters(402).baseaddr = '&may23_P.Send_P6_p';     
         
xcp.parameters(402).symbol = 'may23_P.Send1_P1';
xcp.parameters(402).size   =  26;       
xcp.parameters(402).dtname = 'real_T'; 
xcp.parameters(403).baseaddr = '&may23_P.Send1_P1[0]';     
         
xcp.parameters(403).symbol = 'may23_P.Send1_P2';
xcp.parameters(403).size   =  1;       
xcp.parameters(403).dtname = 'real_T'; 
xcp.parameters(404).baseaddr = '&may23_P.Send1_P2';     
         
xcp.parameters(404).symbol = 'may23_P.Send1_P3';
xcp.parameters(404).size   =  13;       
xcp.parameters(404).dtname = 'real_T'; 
xcp.parameters(405).baseaddr = '&may23_P.Send1_P3[0]';     
         
xcp.parameters(405).symbol = 'may23_P.Send1_P4';
xcp.parameters(405).size   =  1;       
xcp.parameters(405).dtname = 'real_T'; 
xcp.parameters(406).baseaddr = '&may23_P.Send1_P4';     
         
xcp.parameters(406).symbol = 'may23_P.Send1_P5';
xcp.parameters(406).size   =  1;       
xcp.parameters(406).dtname = 'real_T'; 
xcp.parameters(407).baseaddr = '&may23_P.Send1_P5';     
         
xcp.parameters(407).symbol = 'may23_P.Send1_P6';
xcp.parameters(407).size   =  1;       
xcp.parameters(407).dtname = 'real_T'; 
xcp.parameters(408).baseaddr = '&may23_P.Send1_P6';     
         
xcp.parameters(408).symbol = 'may23_P.Compare_const_i';
xcp.parameters(408).size   =  1;       
xcp.parameters(408).dtname = 'uint32_T'; 
xcp.parameters(409).baseaddr = '&may23_P.Compare_const_i';     
         
xcp.parameters(409).symbol = 'may23_P.Bias_Bias';
xcp.parameters(409).size   =  1;       
xcp.parameters(409).dtname = 'int32_T'; 
xcp.parameters(410).baseaddr = '&may23_P.Bias_Bias';     
         
xcp.parameters(410).symbol = 'may23_P.PCIBusSlot_Value';
xcp.parameters(410).size   =  2;       
xcp.parameters(410).dtname = 'int32_T'; 
xcp.parameters(411).baseaddr = '&may23_P.PCIBusSlot_Value[0]';     
         
xcp.parameters(411).symbol = 'may23_P.activation_Value';
xcp.parameters(411).size   =  2;       
xcp.parameters(411).dtname = 'int32_T'; 
xcp.parameters(412).baseaddr = '&may23_P.activation_Value[0]';     
         
xcp.parameters(412).symbol = 'may23_P.eppartnums_Value';
xcp.parameters(412).size   =  6;       
xcp.parameters(412).dtname = 'real_T'; 
xcp.parameters(413).baseaddr = '&may23_P.eppartnums_Value[0]';     
         
xcp.parameters(413).symbol = 'may23_P.exopartnums_Value';
xcp.parameters(413).size   =  6;       
xcp.parameters(413).dtname = 'real_T'; 
xcp.parameters(414).baseaddr = '&may23_P.exopartnums_Value[0]';     
         
xcp.parameters(414).symbol = 'may23_P.forceprimaryonly_Value';
xcp.parameters(414).size   =  1;       
xcp.parameters(414).dtname = 'real_T'; 
xcp.parameters(415).baseaddr = '&may23_P.forceprimaryonly_Value';     
         
xcp.parameters(415).symbol = 'may23_P.maxerrorstofault_Value';
xcp.parameters(415).size   =  1;       
xcp.parameters(415).dtname = 'real_T'; 
xcp.parameters(416).baseaddr = '&may23_P.maxerrorstofault_Value';     
         
xcp.parameters(416).symbol = 'may23_P.nhppartnums_Value';
xcp.parameters(416).size   =  6;       
xcp.parameters(416).dtname = 'real_T'; 
xcp.parameters(417).baseaddr = '&may23_P.nhppartnums_Value[0]';     
         
xcp.parameters(417).symbol = 'may23_P.Switch_Threshold_bk';
xcp.parameters(417).size   =  1;       
xcp.parameters(417).dtname = 'int32_T'; 
xcp.parameters(418).baseaddr = '&may23_P.Switch_Threshold_bk';     
         
xcp.parameters(418).symbol = 'may23_P.Switch1_Threshold_m';
xcp.parameters(418).size   =  1;       
xcp.parameters(418).dtname = 'int32_T'; 
xcp.parameters(419).baseaddr = '&may23_P.Switch1_Threshold_m';     
         
xcp.parameters(419).symbol = 'may23_P.ispmac_const';
xcp.parameters(419).size   =  1;       
xcp.parameters(419).dtname = 'real_T'; 
xcp.parameters(420).baseaddr = '&may23_P.ispmac_const';     
         
xcp.parameters(420).symbol = 'may23_P.is_running_const';
xcp.parameters(420).size   =  1;       
xcp.parameters(420).dtname = 'uint32_T'; 
xcp.parameters(421).baseaddr = '&may23_P.is_running_const';     
         
xcp.parameters(421).symbol = 'may23_P.ispmac1_const_o';
xcp.parameters(421).size   =  1;       
xcp.parameters(421).dtname = 'real_T'; 
xcp.parameters(422).baseaddr = '&may23_P.ispmac1_const_o';     
         
xcp.parameters(422).symbol = 'may23_P.ispmac1_const';
xcp.parameters(422).size   =  1;       
xcp.parameters(422).dtname = 'real_T'; 
xcp.parameters(423).baseaddr = '&may23_P.ispmac1_const';     
         
xcp.parameters(423).symbol = 'may23_P.updateconstants_Value';
xcp.parameters(423).size   =  1;       
xcp.parameters(423).dtname = 'real_T'; 
xcp.parameters(424).baseaddr = '&may23_P.updateconstants_Value';     
         
xcp.parameters(424).symbol = 'may23_P.DominantArm_Value';
xcp.parameters(424).size   =  1;       
xcp.parameters(424).dtname = 'real_T'; 
xcp.parameters(425).baseaddr = '&may23_P.DominantArm_Value';     
         
xcp.parameters(425).symbol = 'may23_P.is_calibrated_Value';
xcp.parameters(425).size   =  2;       
xcp.parameters(425).dtname = 'real_T'; 
xcp.parameters(426).baseaddr = '&may23_P.is_calibrated_Value[0]';     
         
xcp.parameters(426).symbol = 'may23_P.Subject_Arm_Value';
xcp.parameters(426).size   =  1;       
xcp.parameters(426).dtname = 'real_T'; 
xcp.parameters(427).baseaddr = '&may23_P.Subject_Arm_Value';     
         
xcp.parameters(427).symbol = 'may23_P.butterworth_2nd_order_250hz_Value';
xcp.parameters(427).size   =  3;       
xcp.parameters(427).dtname = 'real_T'; 
xcp.parameters(428).baseaddr = '&may23_P.butterworth_2nd_order_250hz_Value[0]';     
         
xcp.parameters(428).symbol = 'may23_P.Delay_InitialCondition_p';
xcp.parameters(428).size   =  1;       
xcp.parameters(428).dtname = 'real_T'; 
xcp.parameters(429).baseaddr = '&may23_P.Delay_InitialCondition_p';     
         
xcp.parameters(429).symbol = 'may23_P.encoder_err_threshold_Value';
xcp.parameters(429).size   =  1;       
xcp.parameters(429).dtname = 'real_T'; 
xcp.parameters(430).baseaddr = '&may23_P.encoder_err_threshold_Value';     
         
xcp.parameters(430).symbol = 'may23_P.Memory1_InitialCondition_m';
xcp.parameters(430).size   =  1;       
xcp.parameters(430).dtname = 'real_T'; 
xcp.parameters(431).baseaddr = '&may23_P.Memory1_InitialCondition_m';     
         
xcp.parameters(431).symbol = 'may23_P.WrapToZero_Threshold_f';
xcp.parameters(431).size   =  1;       
xcp.parameters(431).dtname = 'uint32_T'; 
xcp.parameters(432).baseaddr = '&may23_P.WrapToZero_Threshold_f';     
         
xcp.parameters(432).symbol = 'may23_P.Output_InitialCondition_a';
xcp.parameters(432).size   =  1;       
xcp.parameters(432).dtname = 'uint32_T'; 
xcp.parameters(433).baseaddr = '&may23_P.Output_InitialCondition_a';     
         
xcp.parameters(433).symbol = 'may23_P.block_defs_Y0';
xcp.parameters(433).size   =  25000;       
xcp.parameters(433).dtname = 'real_T'; 
xcp.parameters(434).baseaddr = '&may23_P.block_defs_Y0[0]';     
         
xcp.parameters(434).symbol = 'may23_P.block_seq_Y0';
xcp.parameters(434).size   =  3000;       
xcp.parameters(434).dtname = 'real_T'; 
xcp.parameters(435).baseaddr = '&may23_P.block_seq_Y0[0]';     
         
xcp.parameters(435).symbol = 'may23_P.tp_table_Y0';
xcp.parameters(435).size   =  5000;       
xcp.parameters(435).dtname = 'real_T'; 
xcp.parameters(436).baseaddr = '&may23_P.tp_table_Y0[0]';     
         
xcp.parameters(436).symbol = 'may23_P.labels_Y0';
xcp.parameters(436).size   =  3200;       
xcp.parameters(436).dtname = 'real_T'; 
xcp.parameters(437).baseaddr = '&may23_P.labels_Y0[0]';     
         
xcp.parameters(437).symbol = 'may23_P.targets_Y0';
xcp.parameters(437).size   =  1600;       
xcp.parameters(437).dtname = 'real_T'; 
xcp.parameters(438).baseaddr = '&may23_P.targets_Y0[0]';     
         
xcp.parameters(438).symbol = 'may23_P.loads_Y0';
xcp.parameters(438).size   =  400;       
xcp.parameters(438).dtname = 'real_T'; 
xcp.parameters(439).baseaddr = '&may23_P.loads_Y0[0]';     
         
xcp.parameters(439).symbol = 'may23_P.twp_Y0';
xcp.parameters(439).size   =  50;       
xcp.parameters(439).dtname = 'real_T'; 
xcp.parameters(440).baseaddr = '&may23_P.twp_Y0[0]';     
         
xcp.parameters(440).symbol = 'may23_P.BlockDefinitions_Value';
xcp.parameters(440).size   =  25000;       
xcp.parameters(440).dtname = 'real_T'; 
xcp.parameters(441).baseaddr = '&may23_P.BlockDefinitions_Value[0]';     
         
xcp.parameters(441).symbol = 'may23_P.BlockSequence_Value';
xcp.parameters(441).size   =  3000;       
xcp.parameters(441).dtname = 'real_T'; 
xcp.parameters(442).baseaddr = '&may23_P.BlockSequence_Value[0]';     
         
xcp.parameters(442).symbol = 'may23_P.LoadTable_Value';
xcp.parameters(442).size   =  400;       
xcp.parameters(442).dtname = 'real_T'; 
xcp.parameters(443).baseaddr = '&may23_P.LoadTable_Value[0]';     
         
xcp.parameters(443).symbol = 'may23_P.TPTable_Value';
xcp.parameters(443).size   =  5000;       
xcp.parameters(443).dtname = 'real_T'; 
xcp.parameters(444).baseaddr = '&may23_P.TPTable_Value[0]';     
         
xcp.parameters(444).symbol = 'may23_P.TargetLabels_Value';
xcp.parameters(444).size   =  3200;       
xcp.parameters(444).dtname = 'real_T'; 
xcp.parameters(445).baseaddr = '&may23_P.TargetLabels_Value[0]';     
         
xcp.parameters(445).symbol = 'may23_P.TargetTable_Value';
xcp.parameters(445).size   =  1600;       
xcp.parameters(445).dtname = 'real_T'; 
xcp.parameters(446).baseaddr = '&may23_P.TargetTable_Value[0]';     
         
xcp.parameters(446).symbol = 'may23_P.Taskwideparam_Value';
xcp.parameters(446).size   =  50;       
xcp.parameters(446).dtname = 'real_T'; 
xcp.parameters(447).baseaddr = '&may23_P.Taskwideparam_Value[0]';     
         
xcp.parameters(447).symbol = 'may23_P.feedback_status_Value';
xcp.parameters(447).size   =  1;       
xcp.parameters(447).dtname = 'real_T'; 
xcp.parameters(448).baseaddr = '&may23_P.feedback_status_Value';     
         
xcp.parameters(448).symbol = 'may23_P.FixPtConstant_Value_gy';
xcp.parameters(448).size   =  1;       
xcp.parameters(448).dtname = 'uint32_T'; 
xcp.parameters(449).baseaddr = '&may23_P.FixPtConstant_Value_gy';     
         
xcp.parameters(449).symbol = 'may23_P.Constant_Value_n';
xcp.parameters(449).size   =  1;       
xcp.parameters(449).dtname = 'uint32_T'; 
xcp.parameters(450).baseaddr = '&may23_P.Constant_Value_n';     
         
xcp.parameters(450).symbol = 'may23_P.Constant_Value';
xcp.parameters(450).size   =  1;       
xcp.parameters(450).dtname = 'real_T'; 
xcp.parameters(451).baseaddr = '&may23_P.Constant_Value';     
         
xcp.parameters(451).symbol = 'may23_P.UnitDelay_InitialCondition';
xcp.parameters(451).size   =  1;       
xcp.parameters(451).dtname = 'real_T'; 
xcp.parameters(452).baseaddr = '&may23_P.UnitDelay_InitialCondition';     
         
xcp.parameters(452).symbol = 'may23_P.WrapToZero_Threshold';
xcp.parameters(452).size   =  1;       
xcp.parameters(452).dtname = 'uint32_T'; 
xcp.parameters(453).baseaddr = '&may23_P.WrapToZero_Threshold';     
         
xcp.parameters(453).symbol = 'may23_P.Output_InitialCondition';
xcp.parameters(453).size   =  1;       
xcp.parameters(453).dtname = 'uint32_T'; 
xcp.parameters(454).baseaddr = '&may23_P.Output_InitialCondition';     
         
xcp.parameters(454).symbol = 'may23_P.enableCalibration_Value';
xcp.parameters(454).size   =  1;       
xcp.parameters(454).dtname = 'real_T'; 
xcp.parameters(455).baseaddr = '&may23_P.enableCalibration_Value';     
         
xcp.parameters(455).symbol = 'may23_P.enableMotors_Value';
xcp.parameters(455).size   =  1;       
xcp.parameters(455).dtname = 'real_T'; 
xcp.parameters(456).baseaddr = '&may23_P.enableMotors_Value';     
         
xcp.parameters(456).symbol = 'may23_P.readTrigger_Value';
xcp.parameters(456).size   =  1;       
xcp.parameters(456).dtname = 'int32_T'; 
xcp.parameters(457).baseaddr = '&may23_P.readTrigger_Value';     
         
xcp.parameters(457).symbol = 'may23_P.Memory2_InitialCondition_h';
xcp.parameters(457).size   =  1;       
xcp.parameters(457).dtname = 'real_T'; 
xcp.parameters(458).baseaddr = '&may23_P.Memory2_InitialCondition_h';     
         
xcp.parameters(458).symbol = 'may23_P.Memory3_InitialCondition';
xcp.parameters(458).size   =  1;       
xcp.parameters(458).dtname = 'real_T'; 
xcp.parameters(459).baseaddr = '&may23_P.Memory3_InitialCondition';     
         
xcp.parameters(459).symbol = 'may23_P.enableCalibration_Value_k';
xcp.parameters(459).size   =  1;       
xcp.parameters(459).dtname = 'real_T'; 
xcp.parameters(460).baseaddr = '&may23_P.enableCalibration_Value_k';     
         
xcp.parameters(460).symbol = 'may23_P.enableMotors_Value_h';
xcp.parameters(460).size   =  1;       
xcp.parameters(460).dtname = 'real_T'; 
xcp.parameters(461).baseaddr = '&may23_P.enableMotors_Value_h';     
         
xcp.parameters(461).symbol = 'may23_P.readTrigger_Value_a';
xcp.parameters(461).size   =  1;       
xcp.parameters(461).dtname = 'int32_T'; 
xcp.parameters(462).baseaddr = '&may23_P.readTrigger_Value_a';     
         
xcp.parameters(462).symbol = 'may23_P.Memory2_InitialCondition_i';
xcp.parameters(462).size   =  1;       
xcp.parameters(462).dtname = 'real_T'; 
xcp.parameters(463).baseaddr = '&may23_P.Memory2_InitialCondition_i';     
         
xcp.parameters(463).symbol = 'may23_P.Memory3_InitialCondition_o';
xcp.parameters(463).size   =  1;       
xcp.parameters(463).dtname = 'real_T'; 
xcp.parameters(464).baseaddr = '&may23_P.Memory3_InitialCondition_o';     
         
xcp.parameters(464).symbol = 'may23_P.WrapToZero_Threshold_d';
xcp.parameters(464).size   =  1;       
xcp.parameters(464).dtname = 'uint32_T'; 
xcp.parameters(465).baseaddr = '&may23_P.WrapToZero_Threshold_d';     
         
xcp.parameters(465).symbol = 'may23_P.Output_InitialCondition_p';
xcp.parameters(465).size   =  1;       
xcp.parameters(465).dtname = 'uint32_T'; 
xcp.parameters(466).baseaddr = '&may23_P.Output_InitialCondition_p';     
         
xcp.parameters(466).symbol = 'may23_P.BKINEtherCATPDOTransmit_P1_k';
xcp.parameters(466).size   =  46;       
xcp.parameters(466).dtname = 'real_T'; 
xcp.parameters(467).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P1_k[0]';     
         
xcp.parameters(467).symbol = 'may23_P.BKINEtherCATPDOTransmit_P2_j';
xcp.parameters(467).size   =  1;       
xcp.parameters(467).dtname = 'real_T'; 
xcp.parameters(468).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P2_j';     
         
xcp.parameters(468).symbol = 'may23_P.BKINEtherCATPDOTransmit_P3_n';
xcp.parameters(468).size   =  1;       
xcp.parameters(468).dtname = 'real_T'; 
xcp.parameters(469).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P3_n';     
         
xcp.parameters(469).symbol = 'may23_P.BKINEtherCATPDOTransmit_P4_ms';
xcp.parameters(469).size   =  1;       
xcp.parameters(469).dtname = 'real_T'; 
xcp.parameters(470).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P4_ms';     
         
xcp.parameters(470).symbol = 'may23_P.BKINEtherCATPDOTransmit_P5_nz';
xcp.parameters(470).size   =  1;       
xcp.parameters(470).dtname = 'real_T'; 
xcp.parameters(471).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P5_nz';     
         
xcp.parameters(471).symbol = 'may23_P.BKINEtherCATPDOTransmit_P6_m';
xcp.parameters(471).size   =  1;       
xcp.parameters(471).dtname = 'real_T'; 
xcp.parameters(472).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P6_m';     
         
xcp.parameters(472).symbol = 'may23_P.BKINEtherCATPDOTransmit_P7_g';
xcp.parameters(472).size   =  1;       
xcp.parameters(472).dtname = 'real_T'; 
xcp.parameters(473).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P7_g';     
         
xcp.parameters(473).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P1_p';
xcp.parameters(473).size   =  46;       
xcp.parameters(473).dtname = 'real_T'; 
xcp.parameters(474).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P1_p[0]';     
         
xcp.parameters(474).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P2_f';
xcp.parameters(474).size   =  1;       
xcp.parameters(474).dtname = 'real_T'; 
xcp.parameters(475).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P2_f';     
         
xcp.parameters(475).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P3_l';
xcp.parameters(475).size   =  1;       
xcp.parameters(475).dtname = 'real_T'; 
xcp.parameters(476).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P3_l';     
         
xcp.parameters(476).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P4_e';
xcp.parameters(476).size   =  1;       
xcp.parameters(476).dtname = 'real_T'; 
xcp.parameters(477).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P4_e';     
         
xcp.parameters(477).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P5_k';
xcp.parameters(477).size   =  1;       
xcp.parameters(477).dtname = 'real_T'; 
xcp.parameters(478).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P5_k';     
         
xcp.parameters(478).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P6_f';
xcp.parameters(478).size   =  1;       
xcp.parameters(478).dtname = 'real_T'; 
xcp.parameters(479).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P6_f';     
         
xcp.parameters(479).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P7_n';
xcp.parameters(479).size   =  1;       
xcp.parameters(479).dtname = 'real_T'; 
xcp.parameters(480).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P7_n';     
         
xcp.parameters(480).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P1';
xcp.parameters(480).size   =  46;       
xcp.parameters(480).dtname = 'real_T'; 
xcp.parameters(481).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P1[0]';     
         
xcp.parameters(481).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P2';
xcp.parameters(481).size   =  1;       
xcp.parameters(481).dtname = 'real_T'; 
xcp.parameters(482).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P2';     
         
xcp.parameters(482).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P3';
xcp.parameters(482).size   =  1;       
xcp.parameters(482).dtname = 'real_T'; 
xcp.parameters(483).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P3';     
         
xcp.parameters(483).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P4';
xcp.parameters(483).size   =  1;       
xcp.parameters(483).dtname = 'real_T'; 
xcp.parameters(484).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P4';     
         
xcp.parameters(484).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P5';
xcp.parameters(484).size   =  1;       
xcp.parameters(484).dtname = 'real_T'; 
xcp.parameters(485).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P5';     
         
xcp.parameters(485).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P6';
xcp.parameters(485).size   =  1;       
xcp.parameters(485).dtname = 'real_T'; 
xcp.parameters(486).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P6';     
         
xcp.parameters(486).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P7';
xcp.parameters(486).size   =  1;       
xcp.parameters(486).dtname = 'real_T'; 
xcp.parameters(487).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P7';     
         
xcp.parameters(487).symbol = 'may23_P.BKINEtherCATPDOTransmit3_P1';
xcp.parameters(487).size   =  46;       
xcp.parameters(487).dtname = 'real_T'; 
xcp.parameters(488).baseaddr = '&may23_P.BKINEtherCATPDOTransmit3_P1[0]';     
         
xcp.parameters(488).symbol = 'may23_P.BKINEtherCATPDOTransmit3_P2';
xcp.parameters(488).size   =  1;       
xcp.parameters(488).dtname = 'real_T'; 
xcp.parameters(489).baseaddr = '&may23_P.BKINEtherCATPDOTransmit3_P2';     
         
xcp.parameters(489).symbol = 'may23_P.BKINEtherCATPDOTransmit3_P3';
xcp.parameters(489).size   =  1;       
xcp.parameters(489).dtname = 'real_T'; 
xcp.parameters(490).baseaddr = '&may23_P.BKINEtherCATPDOTransmit3_P3';     
         
xcp.parameters(490).symbol = 'may23_P.BKINEtherCATPDOTransmit3_P4';
xcp.parameters(490).size   =  1;       
xcp.parameters(490).dtname = 'real_T'; 
xcp.parameters(491).baseaddr = '&may23_P.BKINEtherCATPDOTransmit3_P4';     
         
xcp.parameters(491).symbol = 'may23_P.BKINEtherCATPDOTransmit3_P5';
xcp.parameters(491).size   =  1;       
xcp.parameters(491).dtname = 'real_T'; 
xcp.parameters(492).baseaddr = '&may23_P.BKINEtherCATPDOTransmit3_P5';     
         
xcp.parameters(492).symbol = 'may23_P.BKINEtherCATPDOTransmit3_P6';
xcp.parameters(492).size   =  1;       
xcp.parameters(492).dtname = 'real_T'; 
xcp.parameters(493).baseaddr = '&may23_P.BKINEtherCATPDOTransmit3_P6';     
         
xcp.parameters(493).symbol = 'may23_P.BKINEtherCATPDOTransmit3_P7';
xcp.parameters(493).size   =  1;       
xcp.parameters(493).dtname = 'real_T'; 
xcp.parameters(494).baseaddr = '&may23_P.BKINEtherCATPDOTransmit3_P7';     
         
xcp.parameters(494).symbol = 'may23_P.Constant1_Value_oq';
xcp.parameters(494).size   =  1;       
xcp.parameters(494).dtname = 'uint32_T'; 
xcp.parameters(495).baseaddr = '&may23_P.Constant1_Value_oq';     
         
xcp.parameters(495).symbol = 'may23_P.DetectChange_vinit';
xcp.parameters(495).size   =  1;       
xcp.parameters(495).dtname = 'real_T'; 
xcp.parameters(496).baseaddr = '&may23_P.DetectChange_vinit';     
         
xcp.parameters(496).symbol = 'may23_P.Constant_Value_a';
xcp.parameters(496).size   =  7;       
xcp.parameters(496).dtname = 'real_T'; 
xcp.parameters(497).baseaddr = '&may23_P.Constant_Value_a[0]';     
         
xcp.parameters(497).symbol = 'may23_P.ReceivefromRobot1ForceSensor_P1';
xcp.parameters(497).size   =  26;       
xcp.parameters(497).dtname = 'real_T'; 
xcp.parameters(498).baseaddr = '&may23_P.ReceivefromRobot1ForceSensor_P1[0]';     
         
xcp.parameters(498).symbol = 'may23_P.ReceivefromRobot1ForceSensor_P2';
xcp.parameters(498).size   =  1;       
xcp.parameters(498).dtname = 'real_T'; 
xcp.parameters(499).baseaddr = '&may23_P.ReceivefromRobot1ForceSensor_P2';     
         
xcp.parameters(499).symbol = 'may23_P.ReceivefromRobot1ForceSensor_P3';
xcp.parameters(499).size   =  1;       
xcp.parameters(499).dtname = 'real_T'; 
xcp.parameters(500).baseaddr = '&may23_P.ReceivefromRobot1ForceSensor_P3';     
         
xcp.parameters(500).symbol = 'may23_P.ReceivefromRobot1ForceSensor_P4';
xcp.parameters(500).size   =  1;       
xcp.parameters(500).dtname = 'real_T'; 
xcp.parameters(501).baseaddr = '&may23_P.ReceivefromRobot1ForceSensor_P4';     
         
xcp.parameters(501).symbol = 'may23_P.ReceivefromRobot1ForceSensor_P5';
xcp.parameters(501).size   =  12;       
xcp.parameters(501).dtname = 'real_T'; 
xcp.parameters(502).baseaddr = '&may23_P.ReceivefromRobot1ForceSensor_P5[0]';     
         
xcp.parameters(502).symbol = 'may23_P.ReceivefromRobot1ForceSensor_P6';
xcp.parameters(502).size   =  1;       
xcp.parameters(502).dtname = 'real_T'; 
xcp.parameters(503).baseaddr = '&may23_P.ReceivefromRobot1ForceSensor_P6';     
         
xcp.parameters(503).symbol = 'may23_P.ReceivefromRobot1ForceSensor_P7';
xcp.parameters(503).size   =  1;       
xcp.parameters(503).dtname = 'real_T'; 
xcp.parameters(504).baseaddr = '&may23_P.ReceivefromRobot1ForceSensor_P7';     
         
xcp.parameters(504).symbol = 'may23_P.ReceivefromRobot1ForceSensor_P9';
xcp.parameters(504).size   =  1;       
xcp.parameters(504).dtname = 'real_T'; 
xcp.parameters(505).baseaddr = '&may23_P.ReceivefromRobot1ForceSensor_P9';     
         
xcp.parameters(505).symbol = 'may23_P.Switch_Threshold_f';
xcp.parameters(505).size   =  1;       
xcp.parameters(505).dtname = 'real_T'; 
xcp.parameters(506).baseaddr = '&may23_P.Switch_Threshold_f';     
         
xcp.parameters(506).symbol = 'may23_P.DetectChange_vinit_k';
xcp.parameters(506).size   =  1;       
xcp.parameters(506).dtname = 'real_T'; 
xcp.parameters(507).baseaddr = '&may23_P.DetectChange_vinit_k';     
         
xcp.parameters(507).symbol = 'may23_P.Constant1_Value_k';
xcp.parameters(507).size   =  7;       
xcp.parameters(507).dtname = 'real_T'; 
xcp.parameters(508).baseaddr = '&may23_P.Constant1_Value_k[0]';     
         
xcp.parameters(508).symbol = 'may23_P.ReceivefromRobot2ForceSensor_P1';
xcp.parameters(508).size   =  26;       
xcp.parameters(508).dtname = 'real_T'; 
xcp.parameters(509).baseaddr = '&may23_P.ReceivefromRobot2ForceSensor_P1[0]';     
         
xcp.parameters(509).symbol = 'may23_P.ReceivefromRobot2ForceSensor_P2';
xcp.parameters(509).size   =  1;       
xcp.parameters(509).dtname = 'real_T'; 
xcp.parameters(510).baseaddr = '&may23_P.ReceivefromRobot2ForceSensor_P2';     
         
xcp.parameters(510).symbol = 'may23_P.ReceivefromRobot2ForceSensor_P3';
xcp.parameters(510).size   =  1;       
xcp.parameters(510).dtname = 'real_T'; 
xcp.parameters(511).baseaddr = '&may23_P.ReceivefromRobot2ForceSensor_P3';     
         
xcp.parameters(511).symbol = 'may23_P.ReceivefromRobot2ForceSensor_P4';
xcp.parameters(511).size   =  1;       
xcp.parameters(511).dtname = 'real_T'; 
xcp.parameters(512).baseaddr = '&may23_P.ReceivefromRobot2ForceSensor_P4';     
         
xcp.parameters(512).symbol = 'may23_P.ReceivefromRobot2ForceSensor_P5';
xcp.parameters(512).size   =  12;       
xcp.parameters(512).dtname = 'real_T'; 
xcp.parameters(513).baseaddr = '&may23_P.ReceivefromRobot2ForceSensor_P5[0]';     
         
xcp.parameters(513).symbol = 'may23_P.ReceivefromRobot2ForceSensor_P6';
xcp.parameters(513).size   =  1;       
xcp.parameters(513).dtname = 'real_T'; 
xcp.parameters(514).baseaddr = '&may23_P.ReceivefromRobot2ForceSensor_P6';     
         
xcp.parameters(514).symbol = 'may23_P.ReceivefromRobot2ForceSensor_P7';
xcp.parameters(514).size   =  1;       
xcp.parameters(514).dtname = 'real_T'; 
xcp.parameters(515).baseaddr = '&may23_P.ReceivefromRobot2ForceSensor_P7';     
         
xcp.parameters(515).symbol = 'may23_P.ReceivefromRobot2ForceSensor_P9';
xcp.parameters(515).size   =  1;       
xcp.parameters(515).dtname = 'real_T'; 
xcp.parameters(516).baseaddr = '&may23_P.ReceivefromRobot2ForceSensor_P9';     
         
xcp.parameters(516).symbol = 'may23_P.Switch1_Threshold';
xcp.parameters(516).size   =  1;       
xcp.parameters(516).dtname = 'real_T'; 
xcp.parameters(517).baseaddr = '&may23_P.Switch1_Threshold';     
         
xcp.parameters(517).symbol = 'may23_P.robot_count_Value';
xcp.parameters(517).size   =  1;       
xcp.parameters(517).dtname = 'real_T'; 
xcp.parameters(518).baseaddr = '&may23_P.robot_count_Value';     
         
xcp.parameters(518).symbol = 'may23_P.Constant_Value_mh';
xcp.parameters(518).size   =  10;       
xcp.parameters(518).dtname = 'real_T'; 
xcp.parameters(519).baseaddr = '&may23_P.Constant_Value_mh[0]';     
         
xcp.parameters(519).symbol = 'may23_P.WrapToZero_Threshold_c';
xcp.parameters(519).size   =  1;       
xcp.parameters(519).dtname = 'uint32_T'; 
xcp.parameters(520).baseaddr = '&may23_P.WrapToZero_Threshold_c';     
         
xcp.parameters(520).symbol = 'may23_P.Output_InitialCondition_d';
xcp.parameters(520).size   =  1;       
xcp.parameters(520).dtname = 'uint32_T'; 
xcp.parameters(521).baseaddr = '&may23_P.Output_InitialCondition_d';     
         
xcp.parameters(521).symbol = 'may23_P.EPcalibrationbtn_Y0';
xcp.parameters(521).size   =  1;       
xcp.parameters(521).dtname = 'uint32_T'; 
xcp.parameters(522).baseaddr = '&may23_P.EPcalibrationbtn_Y0';     
         
xcp.parameters(522).symbol = 'may23_P.Statusbits_Y0';
xcp.parameters(522).size   =  7;       
xcp.parameters(522).dtname = 'uint32_T'; 
xcp.parameters(523).baseaddr = '&may23_P.Statusbits_Y0[0]';     
         
xcp.parameters(523).symbol = 'may23_P.Taskcontrolbutton_Y0';
xcp.parameters(523).size   =  1;       
xcp.parameters(523).dtname = 'real_T'; 
xcp.parameters(524).baseaddr = '&may23_P.Taskcontrolbutton_Y0';     
         
xcp.parameters(524).symbol = 'may23_P.Constant_Value_jt';
xcp.parameters(524).size   =  1;       
xcp.parameters(524).dtname = 'uint32_T'; 
xcp.parameters(525).baseaddr = '&may23_P.Constant_Value_jt';     
         
xcp.parameters(525).symbol = 'may23_P.Constant1_Value_pc';
xcp.parameters(525).size   =  7;       
xcp.parameters(525).dtname = 'uint32_T'; 
xcp.parameters(526).baseaddr = '&may23_P.Constant1_Value_pc[0]';     
         
xcp.parameters(526).symbol = 'may23_P.SFunction_P1';
xcp.parameters(526).size   =  14;       
xcp.parameters(526).dtname = 'real_T'; 
xcp.parameters(527).baseaddr = '&may23_P.SFunction_P1[0]';     
         
xcp.parameters(527).symbol = 'may23_P.SFunction_P2';
xcp.parameters(527).size   =  1;       
xcp.parameters(527).dtname = 'real_T'; 
xcp.parameters(528).baseaddr = '&may23_P.SFunction_P2';     
         
xcp.parameters(528).symbol = 'may23_P.SFunction_P3';
xcp.parameters(528).size   =  1;       
xcp.parameters(528).dtname = 'real_T'; 
xcp.parameters(529).baseaddr = '&may23_P.SFunction_P3';     
         
xcp.parameters(529).symbol = 'may23_P.SFunction_P4';
xcp.parameters(529).size   =  1;       
xcp.parameters(529).dtname = 'real_T'; 
xcp.parameters(530).baseaddr = '&may23_P.SFunction_P4';     
         
xcp.parameters(530).symbol = 'may23_P.SFunction_P5';
xcp.parameters(530).size   =  1;       
xcp.parameters(530).dtname = 'real_T'; 
xcp.parameters(531).baseaddr = '&may23_P.SFunction_P5';     
         
xcp.parameters(531).symbol = 'may23_P.SFunction_P6';
xcp.parameters(531).size   =  1;       
xcp.parameters(531).dtname = 'real_T'; 
xcp.parameters(532).baseaddr = '&may23_P.SFunction_P6';     
         
xcp.parameters(532).symbol = 'may23_P.SFunction_P7';
xcp.parameters(532).size   =  1;       
xcp.parameters(532).dtname = 'real_T'; 
xcp.parameters(533).baseaddr = '&may23_P.SFunction_P7';     
         
xcp.parameters(533).symbol = 'may23_P.Constant_Value_mg';
xcp.parameters(533).size   =  4;       
xcp.parameters(533).dtname = 'real_T'; 
xcp.parameters(534).baseaddr = '&may23_P.Constant_Value_mg[0]';     
         
xcp.parameters(534).symbol = 'may23_P.Constant1_Value_h';
xcp.parameters(534).size   =  10;       
xcp.parameters(534).dtname = 'real_T'; 
xcp.parameters(535).baseaddr = '&may23_P.Constant1_Value_h[0]';     
         
xcp.parameters(535).symbol = 'may23_P.Constant2_Value';
xcp.parameters(535).size   =  10;       
xcp.parameters(535).dtname = 'real_T'; 
xcp.parameters(536).baseaddr = '&may23_P.Constant2_Value[0]';     
         
xcp.parameters(536).symbol = 'may23_P.servocounter_Y0';
xcp.parameters(536).size   =  1;       
xcp.parameters(536).dtname = 'uint32_T'; 
xcp.parameters(537).baseaddr = '&may23_P.servocounter_Y0';     
         
xcp.parameters(537).symbol = 'may23_P.EPcalibrationbtn_Y0_f';
xcp.parameters(537).size   =  1;       
xcp.parameters(537).dtname = 'uint32_T'; 
xcp.parameters(538).baseaddr = '&may23_P.EPcalibrationbtn_Y0_f';     
         
xcp.parameters(538).symbol = 'may23_P.Statusbits_Y0_l';
xcp.parameters(538).size   =  7;       
xcp.parameters(538).dtname = 'uint32_T'; 
xcp.parameters(539).baseaddr = '&may23_P.Statusbits_Y0_l[0]';     
         
xcp.parameters(539).symbol = 'may23_P.Constant_Value_h';
xcp.parameters(539).size   =  1;       
xcp.parameters(539).dtname = 'uint32_T'; 
xcp.parameters(540).baseaddr = '&may23_P.Constant_Value_h';     
         
xcp.parameters(540).symbol = 'may23_P.Constant1_Value_nm';
xcp.parameters(540).size   =  7;       
xcp.parameters(540).dtname = 'uint32_T'; 
xcp.parameters(541).baseaddr = '&may23_P.Constant1_Value_nm[0]';     
         
xcp.parameters(541).symbol = 'may23_P.Receive_P1_m';
xcp.parameters(541).size   =  26;       
xcp.parameters(541).dtname = 'real_T'; 
xcp.parameters(542).baseaddr = '&may23_P.Receive_P1_m[0]';     
         
xcp.parameters(542).symbol = 'may23_P.Receive_P2_j';
xcp.parameters(542).size   =  1;       
xcp.parameters(542).dtname = 'real_T'; 
xcp.parameters(543).baseaddr = '&may23_P.Receive_P2_j';     
         
xcp.parameters(543).symbol = 'may23_P.Receive_P3_b';
xcp.parameters(543).size   =  1;       
xcp.parameters(543).dtname = 'real_T'; 
xcp.parameters(544).baseaddr = '&may23_P.Receive_P3_b';     
         
xcp.parameters(544).symbol = 'may23_P.Receive_P4_e';
xcp.parameters(544).size   =  1;       
xcp.parameters(544).dtname = 'real_T'; 
xcp.parameters(545).baseaddr = '&may23_P.Receive_P4_e';     
         
xcp.parameters(545).symbol = 'may23_P.Receive_P5_d';
xcp.parameters(545).size   =  11;       
xcp.parameters(545).dtname = 'real_T'; 
xcp.parameters(546).baseaddr = '&may23_P.Receive_P5_d[0]';     
         
xcp.parameters(546).symbol = 'may23_P.Receive_P6_kp';
xcp.parameters(546).size   =  1;       
xcp.parameters(546).dtname = 'real_T'; 
xcp.parameters(547).baseaddr = '&may23_P.Receive_P6_kp';     
         
xcp.parameters(547).symbol = 'may23_P.Receive_P7_k';
xcp.parameters(547).size   =  1;       
xcp.parameters(547).dtname = 'real_T'; 
xcp.parameters(548).baseaddr = '&may23_P.Receive_P7_k';     
         
xcp.parameters(548).symbol = 'may23_P.Receive_P9_h';
xcp.parameters(548).size   =  1;       
xcp.parameters(548).dtname = 'real_T'; 
xcp.parameters(549).baseaddr = '&may23_P.Receive_P9_h';     
         
xcp.parameters(549).symbol = 'may23_P.Constant_Value_m';
xcp.parameters(549).size   =  4;       
xcp.parameters(549).dtname = 'real_T'; 
xcp.parameters(550).baseaddr = '&may23_P.Constant_Value_m[0]';     
         
xcp.parameters(550).symbol = 'may23_P.Constant1_Value_f';
xcp.parameters(550).size   =  10;       
xcp.parameters(550).dtname = 'real_T'; 
xcp.parameters(551).baseaddr = '&may23_P.Constant1_Value_f[0]';     
         
xcp.parameters(551).symbol = 'may23_P.ArmElbowAngleOffset_Value';
xcp.parameters(551).size   =  1;       
xcp.parameters(551).dtname = 'real_T'; 
xcp.parameters(552).baseaddr = '&may23_P.ArmElbowAngleOffset_Value';     
         
xcp.parameters(552).symbol = 'may23_P.ArmEncoderOrientation1_Value';
xcp.parameters(552).size   =  1;       
xcp.parameters(552).dtname = 'real_T'; 
xcp.parameters(553).baseaddr = '&may23_P.ArmEncoderOrientation1_Value';     
         
xcp.parameters(553).symbol = 'may23_P.ArmEncoderOrientation2_Value';
xcp.parameters(553).size   =  1;       
xcp.parameters(553).dtname = 'real_T'; 
xcp.parameters(554).baseaddr = '&may23_P.ArmEncoderOrientation2_Value';     
         
xcp.parameters(554).symbol = 'may23_P.ArmForceSensorAngleOffset_Value';
xcp.parameters(554).size   =  1;       
xcp.parameters(554).dtname = 'real_T'; 
xcp.parameters(555).baseaddr = '&may23_P.ArmForceSensorAngleOffset_Value';     
         
xcp.parameters(555).symbol = 'may23_P.ArmL1_Value';
xcp.parameters(555).size   =  1;       
xcp.parameters(555).dtname = 'real_T'; 
xcp.parameters(556).baseaddr = '&may23_P.ArmL1_Value';     
         
xcp.parameters(556).symbol = 'may23_P.ArmL2_Value';
xcp.parameters(556).size   =  1;       
xcp.parameters(556).dtname = 'real_T'; 
xcp.parameters(557).baseaddr = '&may23_P.ArmL2_Value';     
         
xcp.parameters(557).symbol = 'may23_P.ArmL2L5Angle_Value';
xcp.parameters(557).size   =  1;       
xcp.parameters(557).dtname = 'real_T'; 
xcp.parameters(558).baseaddr = '&may23_P.ArmL2L5Angle_Value';     
         
xcp.parameters(558).symbol = 'may23_P.ArmL3Error_Value';
xcp.parameters(558).size   =  1;       
xcp.parameters(558).dtname = 'real_T'; 
xcp.parameters(559).baseaddr = '&may23_P.ArmL3Error_Value';     
         
xcp.parameters(559).symbol = 'may23_P.ArmL5_Value';
xcp.parameters(559).size   =  1;       
xcp.parameters(559).dtname = 'real_T'; 
xcp.parameters(560).baseaddr = '&may23_P.ArmL5_Value';     
         
xcp.parameters(560).symbol = 'may23_P.ArmMotor1GearRatio_Value';
xcp.parameters(560).size   =  1;       
xcp.parameters(560).dtname = 'real_T'; 
xcp.parameters(561).baseaddr = '&may23_P.ArmMotor1GearRatio_Value';     
         
xcp.parameters(561).symbol = 'may23_P.ArmMotor1Orientation_Value';
xcp.parameters(561).size   =  1;       
xcp.parameters(561).dtname = 'real_T'; 
xcp.parameters(562).baseaddr = '&may23_P.ArmMotor1Orientation_Value';     
         
xcp.parameters(562).symbol = 'may23_P.ArmMotor2GearRatio_Value';
xcp.parameters(562).size   =  1;       
xcp.parameters(562).dtname = 'real_T'; 
xcp.parameters(563).baseaddr = '&may23_P.ArmMotor2GearRatio_Value';     
         
xcp.parameters(563).symbol = 'may23_P.ArmMotor2Orientation_Value';
xcp.parameters(563).size   =  1;       
xcp.parameters(563).dtname = 'real_T'; 
xcp.parameters(564).baseaddr = '&may23_P.ArmMotor2Orientation_Value';     
         
xcp.parameters(564).symbol = 'may23_P.ArmOrientation_Value';
xcp.parameters(564).size   =  1;       
xcp.parameters(564).dtname = 'real_T'; 
xcp.parameters(565).baseaddr = '&may23_P.ArmOrientation_Value';     
         
xcp.parameters(565).symbol = 'may23_P.ArmPointerOffset_Value';
xcp.parameters(565).size   =  1;       
xcp.parameters(565).dtname = 'real_T'; 
xcp.parameters(566).baseaddr = '&may23_P.ArmPointerOffset_Value';     
         
xcp.parameters(566).symbol = 'may23_P.ArmSecondaryEncoders_Value';
xcp.parameters(566).size   =  1;       
xcp.parameters(566).dtname = 'real_T'; 
xcp.parameters(567).baseaddr = '&may23_P.ArmSecondaryEncoders_Value';     
         
xcp.parameters(567).symbol = 'may23_P.ArmShoulderAngleOffset_Value';
xcp.parameters(567).size   =  1;       
xcp.parameters(567).dtname = 'real_T'; 
xcp.parameters(568).baseaddr = '&may23_P.ArmShoulderAngleOffset_Value';     
         
xcp.parameters(568).symbol = 'may23_P.ArmShoulderX_Value';
xcp.parameters(568).size   =  1;       
xcp.parameters(568).dtname = 'real_T'; 
xcp.parameters(569).baseaddr = '&may23_P.ArmShoulderX_Value';     
         
xcp.parameters(569).symbol = 'may23_P.ArmShoulderY_Value';
xcp.parameters(569).size   =  1;       
xcp.parameters(569).dtname = 'real_T'; 
xcp.parameters(570).baseaddr = '&may23_P.ArmShoulderY_Value';     
         
xcp.parameters(570).symbol = 'may23_P.ArmTorqueConstant_Value';
xcp.parameters(570).size   =  1;       
xcp.parameters(570).dtname = 'real_T'; 
xcp.parameters(571).baseaddr = '&may23_P.ArmTorqueConstant_Value';     
         
xcp.parameters(571).symbol = 'may23_P.Armprimaryencodercounts_Value';
xcp.parameters(571).size   =  1;       
xcp.parameters(571).dtname = 'real_T'; 
xcp.parameters(572).baseaddr = '&may23_P.Armprimaryencodercounts_Value';     
         
xcp.parameters(572).symbol = 'may23_P.Armrobottype_Value';
xcp.parameters(572).size   =  1;       
xcp.parameters(572).dtname = 'real_T'; 
xcp.parameters(573).baseaddr = '&may23_P.Armrobottype_Value';     
         
xcp.parameters(573).symbol = 'may23_P.Armrobotversion_Value';
xcp.parameters(573).size   =  1;       
xcp.parameters(573).dtname = 'real_T'; 
xcp.parameters(574).baseaddr = '&may23_P.Armrobotversion_Value';     
         
xcp.parameters(574).symbol = 'may23_P.Armsecondaryencodercounts_Value';
xcp.parameters(574).size   =  1;       
xcp.parameters(574).dtname = 'real_T'; 
xcp.parameters(575).baseaddr = '&may23_P.Armsecondaryencodercounts_Value';     
         
xcp.parameters(575).symbol = 'may23_P.ArmElbowAngleOffset_Value_g';
xcp.parameters(575).size   =  1;       
xcp.parameters(575).dtname = 'real_T'; 
xcp.parameters(576).baseaddr = '&may23_P.ArmElbowAngleOffset_Value_g';     
         
xcp.parameters(576).symbol = 'may23_P.ArmEncoderOrientation1_Value_b';
xcp.parameters(576).size   =  1;       
xcp.parameters(576).dtname = 'real_T'; 
xcp.parameters(577).baseaddr = '&may23_P.ArmEncoderOrientation1_Value_b';     
         
xcp.parameters(577).symbol = 'may23_P.ArmEncoderOrientation2_Value_m';
xcp.parameters(577).size   =  1;       
xcp.parameters(577).dtname = 'real_T'; 
xcp.parameters(578).baseaddr = '&may23_P.ArmEncoderOrientation2_Value_m';     
         
xcp.parameters(578).symbol = 'may23_P.ArmForceSensorAngleOffset_Value_l';
xcp.parameters(578).size   =  1;       
xcp.parameters(578).dtname = 'real_T'; 
xcp.parameters(579).baseaddr = '&may23_P.ArmForceSensorAngleOffset_Value_l';     
         
xcp.parameters(579).symbol = 'may23_P.ArmL1_Value_f';
xcp.parameters(579).size   =  1;       
xcp.parameters(579).dtname = 'real_T'; 
xcp.parameters(580).baseaddr = '&may23_P.ArmL1_Value_f';     
         
xcp.parameters(580).symbol = 'may23_P.ArmL2_Value_g';
xcp.parameters(580).size   =  1;       
xcp.parameters(580).dtname = 'real_T'; 
xcp.parameters(581).baseaddr = '&may23_P.ArmL2_Value_g';     
         
xcp.parameters(581).symbol = 'may23_P.ArmL2L5Angle_Value_h';
xcp.parameters(581).size   =  1;       
xcp.parameters(581).dtname = 'real_T'; 
xcp.parameters(582).baseaddr = '&may23_P.ArmL2L5Angle_Value_h';     
         
xcp.parameters(582).symbol = 'may23_P.ArmL3Error_Value_g';
xcp.parameters(582).size   =  1;       
xcp.parameters(582).dtname = 'real_T'; 
xcp.parameters(583).baseaddr = '&may23_P.ArmL3Error_Value_g';     
         
xcp.parameters(583).symbol = 'may23_P.ArmL5_Value_j';
xcp.parameters(583).size   =  1;       
xcp.parameters(583).dtname = 'real_T'; 
xcp.parameters(584).baseaddr = '&may23_P.ArmL5_Value_j';     
         
xcp.parameters(584).symbol = 'may23_P.ArmMotor1GearRatio_Value_b';
xcp.parameters(584).size   =  1;       
xcp.parameters(584).dtname = 'real_T'; 
xcp.parameters(585).baseaddr = '&may23_P.ArmMotor1GearRatio_Value_b';     
         
xcp.parameters(585).symbol = 'may23_P.ArmMotor1Orientation_Value_j';
xcp.parameters(585).size   =  1;       
xcp.parameters(585).dtname = 'real_T'; 
xcp.parameters(586).baseaddr = '&may23_P.ArmMotor1Orientation_Value_j';     
         
xcp.parameters(586).symbol = 'may23_P.ArmMotor2GearRatio_Value_a';
xcp.parameters(586).size   =  1;       
xcp.parameters(586).dtname = 'real_T'; 
xcp.parameters(587).baseaddr = '&may23_P.ArmMotor2GearRatio_Value_a';     
         
xcp.parameters(587).symbol = 'may23_P.ArmMotor2Orientation_Value_o';
xcp.parameters(587).size   =  1;       
xcp.parameters(587).dtname = 'real_T'; 
xcp.parameters(588).baseaddr = '&may23_P.ArmMotor2Orientation_Value_o';     
         
xcp.parameters(588).symbol = 'may23_P.ArmOrientation_Value_g';
xcp.parameters(588).size   =  1;       
xcp.parameters(588).dtname = 'real_T'; 
xcp.parameters(589).baseaddr = '&may23_P.ArmOrientation_Value_g';     
         
xcp.parameters(589).symbol = 'may23_P.ArmPointerOffset_Value_g';
xcp.parameters(589).size   =  1;       
xcp.parameters(589).dtname = 'real_T'; 
xcp.parameters(590).baseaddr = '&may23_P.ArmPointerOffset_Value_g';     
         
xcp.parameters(590).symbol = 'may23_P.ArmSecondaryEncoders_Value_f';
xcp.parameters(590).size   =  1;       
xcp.parameters(590).dtname = 'real_T'; 
xcp.parameters(591).baseaddr = '&may23_P.ArmSecondaryEncoders_Value_f';     
         
xcp.parameters(591).symbol = 'may23_P.ArmShoulderAngleOffset_Value_i';
xcp.parameters(591).size   =  1;       
xcp.parameters(591).dtname = 'real_T'; 
xcp.parameters(592).baseaddr = '&may23_P.ArmShoulderAngleOffset_Value_i';     
         
xcp.parameters(592).symbol = 'may23_P.ArmShoulderX_Value_l';
xcp.parameters(592).size   =  1;       
xcp.parameters(592).dtname = 'real_T'; 
xcp.parameters(593).baseaddr = '&may23_P.ArmShoulderX_Value_l';     
         
xcp.parameters(593).symbol = 'may23_P.ArmShoulderY_Value_e';
xcp.parameters(593).size   =  1;       
xcp.parameters(593).dtname = 'real_T'; 
xcp.parameters(594).baseaddr = '&may23_P.ArmShoulderY_Value_e';     
         
xcp.parameters(594).symbol = 'may23_P.ArmTorqueConstant_Value_g';
xcp.parameters(594).size   =  1;       
xcp.parameters(594).dtname = 'real_T'; 
xcp.parameters(595).baseaddr = '&may23_P.ArmTorqueConstant_Value_g';     
         
xcp.parameters(595).symbol = 'may23_P.Armprimaryencodercounts_Value_n';
xcp.parameters(595).size   =  1;       
xcp.parameters(595).dtname = 'real_T'; 
xcp.parameters(596).baseaddr = '&may23_P.Armprimaryencodercounts_Value_n';     
         
xcp.parameters(596).symbol = 'may23_P.Armrobottype_Value_k';
xcp.parameters(596).size   =  1;       
xcp.parameters(596).dtname = 'real_T'; 
xcp.parameters(597).baseaddr = '&may23_P.Armrobottype_Value_k';     
         
xcp.parameters(597).symbol = 'may23_P.Armrobotversion_Value_e';
xcp.parameters(597).size   =  1;       
xcp.parameters(597).dtname = 'real_T'; 
xcp.parameters(598).baseaddr = '&may23_P.Armrobotversion_Value_e';     
         
xcp.parameters(598).symbol = 'may23_P.Armsecondaryencodercounts_Value_p';
xcp.parameters(598).size   =  1;       
xcp.parameters(598).dtname = 'real_T'; 
xcp.parameters(599).baseaddr = '&may23_P.Armsecondaryencodercounts_Value_p';     
         
xcp.parameters(599).symbol = 'may23_P.ArmForceSensors_Value';
xcp.parameters(599).size   =  3;       
xcp.parameters(599).dtname = 'real_T'; 
xcp.parameters(600).baseaddr = '&may23_P.ArmForceSensors_Value[0]';     
         
xcp.parameters(600).symbol = 'may23_P.Ready_Value';
xcp.parameters(600).size   =  1;       
xcp.parameters(600).dtname = 'real_T'; 
xcp.parameters(601).baseaddr = '&may23_P.Ready_Value';     
         
xcp.parameters(601).symbol = 'may23_P.WrapToZero_Threshold_m';
xcp.parameters(601).size   =  1;       
xcp.parameters(601).dtname = 'uint32_T'; 
xcp.parameters(602).baseaddr = '&may23_P.WrapToZero_Threshold_m';     
         
xcp.parameters(602).symbol = 'may23_P.Output_InitialCondition_i';
xcp.parameters(602).size   =  1;       
xcp.parameters(602).dtname = 'uint32_T'; 
xcp.parameters(603).baseaddr = '&may23_P.Output_InitialCondition_i';     
         
xcp.parameters(603).symbol = 'may23_P.GazeFeedbackStatus_Value';
xcp.parameters(603).size   =  1;       
xcp.parameters(603).dtname = 'real_T'; 
xcp.parameters(604).baseaddr = '&may23_P.GazeFeedbackStatus_Value';     
         
xcp.parameters(604).symbol = 'may23_P.HandFeedbackColour_Value';
xcp.parameters(604).size   =  1;       
xcp.parameters(604).dtname = 'real_T'; 
xcp.parameters(605).baseaddr = '&may23_P.HandFeedbackColour_Value';     
         
xcp.parameters(605).symbol = 'may23_P.HandFeedbackFeedForward_Value';
xcp.parameters(605).size   =  1;       
xcp.parameters(605).dtname = 'real_T'; 
xcp.parameters(606).baseaddr = '&may23_P.HandFeedbackFeedForward_Value';     
         
xcp.parameters(606).symbol = 'may23_P.HandFeedbackRadius_Value';
xcp.parameters(606).size   =  1;       
xcp.parameters(606).dtname = 'real_T'; 
xcp.parameters(607).baseaddr = '&may23_P.HandFeedbackRadius_Value';     
         
xcp.parameters(607).symbol = 'may23_P.HandFeedbackSource_Value';
xcp.parameters(607).size   =  1;       
xcp.parameters(607).dtname = 'real_T'; 
xcp.parameters(608).baseaddr = '&may23_P.HandFeedbackSource_Value';     
         
xcp.parameters(608).symbol = 'may23_P.HandFeedbackStatus_Value';
xcp.parameters(608).size   =  1;       
xcp.parameters(608).dtname = 'real_T'; 
xcp.parameters(609).baseaddr = '&may23_P.HandFeedbackStatus_Value';     
         
xcp.parameters(609).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P1_a';
xcp.parameters(609).size   =  42;       
xcp.parameters(609).dtname = 'real_T'; 
xcp.parameters(610).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P1_a[0]';     
         
xcp.parameters(610).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P2_i';
xcp.parameters(610).size   =  1;       
xcp.parameters(610).dtname = 'real_T'; 
xcp.parameters(611).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P2_i';     
         
xcp.parameters(611).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P3_h';
xcp.parameters(611).size   =  1;       
xcp.parameters(611).dtname = 'real_T'; 
xcp.parameters(612).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P3_h';     
         
xcp.parameters(612).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P4_g';
xcp.parameters(612).size   =  1;       
xcp.parameters(612).dtname = 'real_T'; 
xcp.parameters(613).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P4_g';     
         
xcp.parameters(613).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P5_f';
xcp.parameters(613).size   =  1;       
xcp.parameters(613).dtname = 'real_T'; 
xcp.parameters(614).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P5_f';     
         
xcp.parameters(614).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P6_m';
xcp.parameters(614).size   =  1;       
xcp.parameters(614).dtname = 'real_T'; 
xcp.parameters(615).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P6_m';     
         
xcp.parameters(615).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P7_a';
xcp.parameters(615).size   =  1;       
xcp.parameters(615).dtname = 'real_T'; 
xcp.parameters(616).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P7_a';     
         
xcp.parameters(616).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P1_n';
xcp.parameters(616).size   =  42;       
xcp.parameters(616).dtname = 'real_T'; 
xcp.parameters(617).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P1_n[0]';     
         
xcp.parameters(617).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P2_b';
xcp.parameters(617).size   =  1;       
xcp.parameters(617).dtname = 'real_T'; 
xcp.parameters(618).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P2_b';     
         
xcp.parameters(618).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P3_g';
xcp.parameters(618).size   =  1;       
xcp.parameters(618).dtname = 'real_T'; 
xcp.parameters(619).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P3_g';     
         
xcp.parameters(619).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P4_o';
xcp.parameters(619).size   =  1;       
xcp.parameters(619).dtname = 'real_T'; 
xcp.parameters(620).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P4_o';     
         
xcp.parameters(620).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P5_g';
xcp.parameters(620).size   =  1;       
xcp.parameters(620).dtname = 'real_T'; 
xcp.parameters(621).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P5_g';     
         
xcp.parameters(621).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P6_p';
xcp.parameters(621).size   =  1;       
xcp.parameters(621).dtname = 'real_T'; 
xcp.parameters(622).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P6_p';     
         
xcp.parameters(622).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P7_g';
xcp.parameters(622).size   =  1;       
xcp.parameters(622).dtname = 'real_T'; 
xcp.parameters(623).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P7_g';     
         
xcp.parameters(623).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P1_i';
xcp.parameters(623).size   =  42;       
xcp.parameters(623).dtname = 'real_T'; 
xcp.parameters(624).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P1_i[0]';     
         
xcp.parameters(624).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P2_h';
xcp.parameters(624).size   =  1;       
xcp.parameters(624).dtname = 'real_T'; 
xcp.parameters(625).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P2_h';     
         
xcp.parameters(625).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P3_j';
xcp.parameters(625).size   =  1;       
xcp.parameters(625).dtname = 'real_T'; 
xcp.parameters(626).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P3_j';     
         
xcp.parameters(626).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P4_i';
xcp.parameters(626).size   =  1;       
xcp.parameters(626).dtname = 'real_T'; 
xcp.parameters(627).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P4_i';     
         
xcp.parameters(627).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P5_k2';
xcp.parameters(627).size   =  1;       
xcp.parameters(627).dtname = 'real_T'; 
xcp.parameters(628).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P5_k2';     
         
xcp.parameters(628).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P6_n';
xcp.parameters(628).size   =  1;       
xcp.parameters(628).dtname = 'real_T'; 
xcp.parameters(629).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P6_n';     
         
xcp.parameters(629).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P7_h';
xcp.parameters(629).size   =  1;       
xcp.parameters(629).dtname = 'real_T'; 
xcp.parameters(630).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P7_h';     
         
xcp.parameters(630).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P1_i';
xcp.parameters(630).size   =  42;       
xcp.parameters(630).dtname = 'real_T'; 
xcp.parameters(631).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P1_i[0]';     
         
xcp.parameters(631).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P2_f';
xcp.parameters(631).size   =  1;       
xcp.parameters(631).dtname = 'real_T'; 
xcp.parameters(632).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P2_f';     
         
xcp.parameters(632).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P3_o';
xcp.parameters(632).size   =  1;       
xcp.parameters(632).dtname = 'real_T'; 
xcp.parameters(633).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P3_o';     
         
xcp.parameters(633).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P4_m';
xcp.parameters(633).size   =  1;       
xcp.parameters(633).dtname = 'real_T'; 
xcp.parameters(634).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P4_m';     
         
xcp.parameters(634).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P5_j';
xcp.parameters(634).size   =  1;       
xcp.parameters(634).dtname = 'real_T'; 
xcp.parameters(635).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P5_j';     
         
xcp.parameters(635).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P6_b';
xcp.parameters(635).size   =  1;       
xcp.parameters(635).dtname = 'real_T'; 
xcp.parameters(636).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P6_b';     
         
xcp.parameters(636).symbol = 'may23_P.BKINEtherCATPDOTransmit2_P7_j';
xcp.parameters(636).size   =  1;       
xcp.parameters(636).dtname = 'real_T'; 
xcp.parameters(637).baseaddr = '&may23_P.BKINEtherCATPDOTransmit2_P7_j';     
         
xcp.parameters(637).symbol = 'may23_P.FixPtConstant_Value_k';
xcp.parameters(637).size   =  1;       
xcp.parameters(637).dtname = 'uint32_T'; 
xcp.parameters(638).baseaddr = '&may23_P.FixPtConstant_Value_k';     
         
xcp.parameters(638).symbol = 'may23_P.Constant_Value_px';
xcp.parameters(638).size   =  1;       
xcp.parameters(638).dtname = 'uint32_T'; 
xcp.parameters(639).baseaddr = '&may23_P.Constant_Value_px';     
         
xcp.parameters(639).symbol = 'may23_P.FixPtConstant_Value';
xcp.parameters(639).size   =  1;       
xcp.parameters(639).dtname = 'uint32_T'; 
xcp.parameters(640).baseaddr = '&may23_P.FixPtConstant_Value';     
         
xcp.parameters(640).symbol = 'may23_P.Constant_Value_j';
xcp.parameters(640).size   =  1;       
xcp.parameters(640).dtname = 'uint32_T'; 
xcp.parameters(641).baseaddr = '&may23_P.Constant_Value_j';     
         
xcp.parameters(641).symbol = 'may23_P.Compare_const';
xcp.parameters(641).size   =  1;       
xcp.parameters(641).dtname = 'int32_T'; 
xcp.parameters(642).baseaddr = '&may23_P.Compare_const';     
         
xcp.parameters(642).symbol = 'may23_P.MotorIdx_Value';
xcp.parameters(642).size   =  1;       
xcp.parameters(642).dtname = 'real_T'; 
xcp.parameters(643).baseaddr = '&may23_P.MotorIdx_Value';     
         
xcp.parameters(643).symbol = 'may23_P.Memory_InitialCondition_p';
xcp.parameters(643).size   =  1;       
xcp.parameters(643).dtname = 'real_T'; 
xcp.parameters(644).baseaddr = '&may23_P.Memory_InitialCondition_p';     
         
xcp.parameters(644).symbol = 'may23_P.BKINEtherCATPDOTransmit_P1';
xcp.parameters(644).size   =  41;       
xcp.parameters(644).dtname = 'real_T'; 
xcp.parameters(645).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P1[0]';     
         
xcp.parameters(645).symbol = 'may23_P.BKINEtherCATPDOTransmit_P2';
xcp.parameters(645).size   =  1;       
xcp.parameters(645).dtname = 'real_T'; 
xcp.parameters(646).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P2';     
         
xcp.parameters(646).symbol = 'may23_P.BKINEtherCATPDOTransmit_P3';
xcp.parameters(646).size   =  1;       
xcp.parameters(646).dtname = 'real_T'; 
xcp.parameters(647).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P3';     
         
xcp.parameters(647).symbol = 'may23_P.BKINEtherCATPDOTransmit_P4';
xcp.parameters(647).size   =  1;       
xcp.parameters(647).dtname = 'real_T'; 
xcp.parameters(648).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P4';     
         
xcp.parameters(648).symbol = 'may23_P.BKINEtherCATPDOTransmit_P5';
xcp.parameters(648).size   =  1;       
xcp.parameters(648).dtname = 'real_T'; 
xcp.parameters(649).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P5';     
         
xcp.parameters(649).symbol = 'may23_P.BKINEtherCATPDOTransmit_P6';
xcp.parameters(649).size   =  1;       
xcp.parameters(649).dtname = 'real_T'; 
xcp.parameters(650).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P6';     
         
xcp.parameters(650).symbol = 'may23_P.BKINEtherCATPDOTransmit_P7';
xcp.parameters(650).size   =  1;       
xcp.parameters(650).dtname = 'real_T'; 
xcp.parameters(651).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P7';     
         
xcp.parameters(651).symbol = 'may23_P.Compare_const_f';
xcp.parameters(651).size   =  1;       
xcp.parameters(651).dtname = 'int32_T'; 
xcp.parameters(652).baseaddr = '&may23_P.Compare_const_f';     
         
xcp.parameters(652).symbol = 'may23_P.MotorIdx_Value_p';
xcp.parameters(652).size   =  1;       
xcp.parameters(652).dtname = 'real_T'; 
xcp.parameters(653).baseaddr = '&may23_P.MotorIdx_Value_p';     
         
xcp.parameters(653).symbol = 'may23_P.Memory_InitialCondition_ps';
xcp.parameters(653).size   =  1;       
xcp.parameters(653).dtname = 'real_T'; 
xcp.parameters(654).baseaddr = '&may23_P.Memory_InitialCondition_ps';     
         
xcp.parameters(654).symbol = 'may23_P.BKINEtherCATPDOTransmit_P1_j';
xcp.parameters(654).size   =  41;       
xcp.parameters(654).dtname = 'real_T'; 
xcp.parameters(655).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P1_j[0]';     
         
xcp.parameters(655).symbol = 'may23_P.BKINEtherCATPDOTransmit_P2_n';
xcp.parameters(655).size   =  1;       
xcp.parameters(655).dtname = 'real_T'; 
xcp.parameters(656).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P2_n';     
         
xcp.parameters(656).symbol = 'may23_P.BKINEtherCATPDOTransmit_P3_a';
xcp.parameters(656).size   =  1;       
xcp.parameters(656).dtname = 'real_T'; 
xcp.parameters(657).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P3_a';     
         
xcp.parameters(657).symbol = 'may23_P.BKINEtherCATPDOTransmit_P4_m';
xcp.parameters(657).size   =  1;       
xcp.parameters(657).dtname = 'real_T'; 
xcp.parameters(658).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P4_m';     
         
xcp.parameters(658).symbol = 'may23_P.BKINEtherCATPDOTransmit_P5_k';
xcp.parameters(658).size   =  1;       
xcp.parameters(658).dtname = 'real_T'; 
xcp.parameters(659).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P5_k';     
         
xcp.parameters(659).symbol = 'may23_P.BKINEtherCATPDOTransmit_P6_f';
xcp.parameters(659).size   =  1;       
xcp.parameters(659).dtname = 'real_T'; 
xcp.parameters(660).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P6_f';     
         
xcp.parameters(660).symbol = 'may23_P.BKINEtherCATPDOTransmit_P7_j';
xcp.parameters(660).size   =  1;       
xcp.parameters(660).dtname = 'real_T'; 
xcp.parameters(661).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P7_j';     
         
xcp.parameters(661).symbol = 'may23_P.override_grip_Value';
xcp.parameters(661).size   =  1;       
xcp.parameters(661).dtname = 'real_T'; 
xcp.parameters(662).baseaddr = '&may23_P.override_grip_Value';     
         
xcp.parameters(662).symbol = 'may23_P.BKINEtherCATPDOTransmit_P1_c';
xcp.parameters(662).size   =  48;       
xcp.parameters(662).dtname = 'real_T'; 
xcp.parameters(663).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P1_c[0]';     
         
xcp.parameters(663).symbol = 'may23_P.BKINEtherCATPDOTransmit_P2_p';
xcp.parameters(663).size   =  1;       
xcp.parameters(663).dtname = 'real_T'; 
xcp.parameters(664).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P2_p';     
         
xcp.parameters(664).symbol = 'may23_P.BKINEtherCATPDOTransmit_P3_i';
xcp.parameters(664).size   =  1;       
xcp.parameters(664).dtname = 'real_T'; 
xcp.parameters(665).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P3_i';     
         
xcp.parameters(665).symbol = 'may23_P.BKINEtherCATPDOTransmit_P4_n';
xcp.parameters(665).size   =  1;       
xcp.parameters(665).dtname = 'real_T'; 
xcp.parameters(666).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P4_n';     
         
xcp.parameters(666).symbol = 'may23_P.BKINEtherCATPDOTransmit_P5_o';
xcp.parameters(666).size   =  1;       
xcp.parameters(666).dtname = 'real_T'; 
xcp.parameters(667).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P5_o';     
         
xcp.parameters(667).symbol = 'may23_P.BKINEtherCATPDOTransmit_P6_e';
xcp.parameters(667).size   =  1;       
xcp.parameters(667).dtname = 'real_T'; 
xcp.parameters(668).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P6_e';     
         
xcp.parameters(668).symbol = 'may23_P.BKINEtherCATPDOTransmit_P7_p';
xcp.parameters(668).size   =  1;       
xcp.parameters(668).dtname = 'real_T'; 
xcp.parameters(669).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P7_p';     
         
xcp.parameters(669).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P1';
xcp.parameters(669).size   =  48;       
xcp.parameters(669).dtname = 'real_T'; 
xcp.parameters(670).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P1[0]';     
         
xcp.parameters(670).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P2';
xcp.parameters(670).size   =  1;       
xcp.parameters(670).dtname = 'real_T'; 
xcp.parameters(671).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P2';     
         
xcp.parameters(671).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P3';
xcp.parameters(671).size   =  1;       
xcp.parameters(671).dtname = 'real_T'; 
xcp.parameters(672).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P3';     
         
xcp.parameters(672).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P4';
xcp.parameters(672).size   =  1;       
xcp.parameters(672).dtname = 'real_T'; 
xcp.parameters(673).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P4';     
         
xcp.parameters(673).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P5';
xcp.parameters(673).size   =  1;       
xcp.parameters(673).dtname = 'real_T'; 
xcp.parameters(674).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P5';     
         
xcp.parameters(674).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P6';
xcp.parameters(674).size   =  1;       
xcp.parameters(674).dtname = 'real_T'; 
xcp.parameters(675).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P6';     
         
xcp.parameters(675).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P7';
xcp.parameters(675).size   =  1;       
xcp.parameters(675).dtname = 'real_T'; 
xcp.parameters(676).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P7';     
         
xcp.parameters(676).symbol = 'may23_P.Memory_InitialCondition_b';
xcp.parameters(676).size   =  1;       
xcp.parameters(676).dtname = 'int32_T'; 
xcp.parameters(677).baseaddr = '&may23_P.Memory_InitialCondition_b';     
         
xcp.parameters(677).symbol = 'may23_P.Memory1_InitialCondition_a';
xcp.parameters(677).size   =  1;       
xcp.parameters(677).dtname = 'int32_T'; 
xcp.parameters(678).baseaddr = '&may23_P.Memory1_InitialCondition_a';     
         
xcp.parameters(678).symbol = 'may23_P.Memory_InitialCondition_ba';
xcp.parameters(678).size   =  1;       
xcp.parameters(678).dtname = 'int32_T'; 
xcp.parameters(679).baseaddr = '&may23_P.Memory_InitialCondition_ba';     
         
xcp.parameters(679).symbol = 'may23_P.Memory1_InitialCondition_nm';
xcp.parameters(679).size   =  1;       
xcp.parameters(679).dtname = 'int32_T'; 
xcp.parameters(680).baseaddr = '&may23_P.Memory1_InitialCondition_nm';     
         
xcp.parameters(680).symbol = 'may23_P.readAddr_Value';
xcp.parameters(680).size   =  3;       
xcp.parameters(680).dtname = 'real_T'; 
xcp.parameters(681).baseaddr = '&may23_P.readAddr_Value[0]';     
         
xcp.parameters(681).symbol = 'may23_P.Memory_InitialCondition_e';
xcp.parameters(681).size   =  1;       
xcp.parameters(681).dtname = 'int32_T'; 
xcp.parameters(682).baseaddr = '&may23_P.Memory_InitialCondition_e';     
         
xcp.parameters(682).symbol = 'may23_P.writeData_Value';
xcp.parameters(682).size   =  5;       
xcp.parameters(682).dtname = 'real_T'; 
xcp.parameters(683).baseaddr = '&may23_P.writeData_Value[0]';     
         
xcp.parameters(683).symbol = 'may23_P.Memory_InitialCondition_n';
xcp.parameters(683).size   =  1;       
xcp.parameters(683).dtname = 'int32_T'; 
xcp.parameters(684).baseaddr = '&may23_P.Memory_InitialCondition_n';     
         
xcp.parameters(684).symbol = 'may23_P.Memory_InitialCondition_h';
xcp.parameters(684).size   =  1;       
xcp.parameters(684).dtname = 'int32_T'; 
xcp.parameters(685).baseaddr = '&may23_P.Memory_InitialCondition_h';     
         
xcp.parameters(685).symbol = 'may23_P.Memory1_InitialCondition_o';
xcp.parameters(685).size   =  1;       
xcp.parameters(685).dtname = 'real_T'; 
xcp.parameters(686).baseaddr = '&may23_P.Memory1_InitialCondition_o';     
         
xcp.parameters(686).symbol = 'may23_P.Memory2_InitialCondition_j';
xcp.parameters(686).size   =  1;       
xcp.parameters(686).dtname = 'int32_T'; 
xcp.parameters(687).baseaddr = '&may23_P.Memory2_InitialCondition_j';     
         
xcp.parameters(687).symbol = 'may23_P.Compare_const_p';
xcp.parameters(687).size   =  1;       
xcp.parameters(687).dtname = 'int32_T'; 
xcp.parameters(688).baseaddr = '&may23_P.Compare_const_p';     
         
xcp.parameters(688).symbol = 'may23_P.MotorIdx_Value_f';
xcp.parameters(688).size   =  1;       
xcp.parameters(688).dtname = 'real_T'; 
xcp.parameters(689).baseaddr = '&may23_P.MotorIdx_Value_f';     
         
xcp.parameters(689).symbol = 'may23_P.Memory_InitialCondition_d';
xcp.parameters(689).size   =  1;       
xcp.parameters(689).dtname = 'real_T'; 
xcp.parameters(690).baseaddr = '&may23_P.Memory_InitialCondition_d';     
         
xcp.parameters(690).symbol = 'may23_P.BKINEtherCATPDOTransmit_P1_i';
xcp.parameters(690).size   =  41;       
xcp.parameters(690).dtname = 'real_T'; 
xcp.parameters(691).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P1_i[0]';     
         
xcp.parameters(691).symbol = 'may23_P.BKINEtherCATPDOTransmit_P2_c';
xcp.parameters(691).size   =  1;       
xcp.parameters(691).dtname = 'real_T'; 
xcp.parameters(692).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P2_c';     
         
xcp.parameters(692).symbol = 'may23_P.BKINEtherCATPDOTransmit_P3_d';
xcp.parameters(692).size   =  1;       
xcp.parameters(692).dtname = 'real_T'; 
xcp.parameters(693).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P3_d';     
         
xcp.parameters(693).symbol = 'may23_P.BKINEtherCATPDOTransmit_P4_a';
xcp.parameters(693).size   =  1;       
xcp.parameters(693).dtname = 'real_T'; 
xcp.parameters(694).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P4_a';     
         
xcp.parameters(694).symbol = 'may23_P.BKINEtherCATPDOTransmit_P5_n';
xcp.parameters(694).size   =  1;       
xcp.parameters(694).dtname = 'real_T'; 
xcp.parameters(695).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P5_n';     
         
xcp.parameters(695).symbol = 'may23_P.BKINEtherCATPDOTransmit_P6_f4';
xcp.parameters(695).size   =  1;       
xcp.parameters(695).dtname = 'real_T'; 
xcp.parameters(696).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P6_f4';     
         
xcp.parameters(696).symbol = 'may23_P.BKINEtherCATPDOTransmit_P7_p1';
xcp.parameters(696).size   =  1;       
xcp.parameters(696).dtname = 'real_T'; 
xcp.parameters(697).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P7_p1';     
         
xcp.parameters(697).symbol = 'may23_P.Compare_const_d';
xcp.parameters(697).size   =  1;       
xcp.parameters(697).dtname = 'int32_T'; 
xcp.parameters(698).baseaddr = '&may23_P.Compare_const_d';     
         
xcp.parameters(698).symbol = 'may23_P.MotorIdx_Value_b';
xcp.parameters(698).size   =  1;       
xcp.parameters(698).dtname = 'real_T'; 
xcp.parameters(699).baseaddr = '&may23_P.MotorIdx_Value_b';     
         
xcp.parameters(699).symbol = 'may23_P.Memory_InitialCondition_ki';
xcp.parameters(699).size   =  1;       
xcp.parameters(699).dtname = 'real_T'; 
xcp.parameters(700).baseaddr = '&may23_P.Memory_InitialCondition_ki';     
         
xcp.parameters(700).symbol = 'may23_P.BKINEtherCATPDOTransmit_P1_n';
xcp.parameters(700).size   =  41;       
xcp.parameters(700).dtname = 'real_T'; 
xcp.parameters(701).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P1_n[0]';     
         
xcp.parameters(701).symbol = 'may23_P.BKINEtherCATPDOTransmit_P2_k';
xcp.parameters(701).size   =  1;       
xcp.parameters(701).dtname = 'real_T'; 
xcp.parameters(702).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P2_k';     
         
xcp.parameters(702).symbol = 'may23_P.BKINEtherCATPDOTransmit_P3_b';
xcp.parameters(702).size   =  1;       
xcp.parameters(702).dtname = 'real_T'; 
xcp.parameters(703).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P3_b';     
         
xcp.parameters(703).symbol = 'may23_P.BKINEtherCATPDOTransmit_P4_k';
xcp.parameters(703).size   =  1;       
xcp.parameters(703).dtname = 'real_T'; 
xcp.parameters(704).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P4_k';     
         
xcp.parameters(704).symbol = 'may23_P.BKINEtherCATPDOTransmit_P5_a';
xcp.parameters(704).size   =  1;       
xcp.parameters(704).dtname = 'real_T'; 
xcp.parameters(705).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P5_a';     
         
xcp.parameters(705).symbol = 'may23_P.BKINEtherCATPDOTransmit_P6_g';
xcp.parameters(705).size   =  1;       
xcp.parameters(705).dtname = 'real_T'; 
xcp.parameters(706).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P6_g';     
         
xcp.parameters(706).symbol = 'may23_P.BKINEtherCATPDOTransmit_P7_b';
xcp.parameters(706).size   =  1;       
xcp.parameters(706).dtname = 'real_T'; 
xcp.parameters(707).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P7_b';     
         
xcp.parameters(707).symbol = 'may23_P.Memory_InitialCondition_ec';
xcp.parameters(707).size   =  1;       
xcp.parameters(707).dtname = 'int32_T'; 
xcp.parameters(708).baseaddr = '&may23_P.Memory_InitialCondition_ec';     
         
xcp.parameters(708).symbol = 'may23_P.Memory1_InitialCondition_p';
xcp.parameters(708).size   =  1;       
xcp.parameters(708).dtname = 'int32_T'; 
xcp.parameters(709).baseaddr = '&may23_P.Memory1_InitialCondition_p';     
         
xcp.parameters(709).symbol = 'may23_P.Memory_InitialCondition_pu';
xcp.parameters(709).size   =  1;       
xcp.parameters(709).dtname = 'int32_T'; 
xcp.parameters(710).baseaddr = '&may23_P.Memory_InitialCondition_pu';     
         
xcp.parameters(710).symbol = 'may23_P.Memory1_InitialCondition_ai';
xcp.parameters(710).size   =  1;       
xcp.parameters(710).dtname = 'int32_T'; 
xcp.parameters(711).baseaddr = '&may23_P.Memory1_InitialCondition_ai';     
         
xcp.parameters(711).symbol = 'may23_P.readAddr_Value_b';
xcp.parameters(711).size   =  3;       
xcp.parameters(711).dtname = 'real_T'; 
xcp.parameters(712).baseaddr = '&may23_P.readAddr_Value_b[0]';     
         
xcp.parameters(712).symbol = 'may23_P.Memory_InitialCondition_ex';
xcp.parameters(712).size   =  1;       
xcp.parameters(712).dtname = 'int32_T'; 
xcp.parameters(713).baseaddr = '&may23_P.Memory_InitialCondition_ex';     
         
xcp.parameters(713).symbol = 'may23_P.writeData_Value_o';
xcp.parameters(713).size   =  5;       
xcp.parameters(713).dtname = 'real_T'; 
xcp.parameters(714).baseaddr = '&may23_P.writeData_Value_o[0]';     
         
xcp.parameters(714).symbol = 'may23_P.Memory_InitialCondition_o';
xcp.parameters(714).size   =  1;       
xcp.parameters(714).dtname = 'int32_T'; 
xcp.parameters(715).baseaddr = '&may23_P.Memory_InitialCondition_o';     
         
xcp.parameters(715).symbol = 'may23_P.override_grip_Value_p';
xcp.parameters(715).size   =  1;       
xcp.parameters(715).dtname = 'real_T'; 
xcp.parameters(716).baseaddr = '&may23_P.override_grip_Value_p';     
         
xcp.parameters(716).symbol = 'may23_P.BKINEtherCATPDOTransmit_P1_m';
xcp.parameters(716).size   =  48;       
xcp.parameters(716).dtname = 'real_T'; 
xcp.parameters(717).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P1_m[0]';     
         
xcp.parameters(717).symbol = 'may23_P.BKINEtherCATPDOTransmit_P2_g';
xcp.parameters(717).size   =  1;       
xcp.parameters(717).dtname = 'real_T'; 
xcp.parameters(718).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P2_g';     
         
xcp.parameters(718).symbol = 'may23_P.BKINEtherCATPDOTransmit_P3_iv';
xcp.parameters(718).size   =  1;       
xcp.parameters(718).dtname = 'real_T'; 
xcp.parameters(719).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P3_iv';     
         
xcp.parameters(719).symbol = 'may23_P.BKINEtherCATPDOTransmit_P4_j';
xcp.parameters(719).size   =  1;       
xcp.parameters(719).dtname = 'real_T'; 
xcp.parameters(720).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P4_j';     
         
xcp.parameters(720).symbol = 'may23_P.BKINEtherCATPDOTransmit_P5_l';
xcp.parameters(720).size   =  1;       
xcp.parameters(720).dtname = 'real_T'; 
xcp.parameters(721).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P5_l';     
         
xcp.parameters(721).symbol = 'may23_P.BKINEtherCATPDOTransmit_P6_i';
xcp.parameters(721).size   =  1;       
xcp.parameters(721).dtname = 'real_T'; 
xcp.parameters(722).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P6_i';     
         
xcp.parameters(722).symbol = 'may23_P.BKINEtherCATPDOTransmit_P7_a';
xcp.parameters(722).size   =  1;       
xcp.parameters(722).dtname = 'real_T'; 
xcp.parameters(723).baseaddr = '&may23_P.BKINEtherCATPDOTransmit_P7_a';     
         
xcp.parameters(723).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P1_d';
xcp.parameters(723).size   =  48;       
xcp.parameters(723).dtname = 'real_T'; 
xcp.parameters(724).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P1_d[0]';     
         
xcp.parameters(724).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P2_a';
xcp.parameters(724).size   =  1;       
xcp.parameters(724).dtname = 'real_T'; 
xcp.parameters(725).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P2_a';     
         
xcp.parameters(725).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P3_n';
xcp.parameters(725).size   =  1;       
xcp.parameters(725).dtname = 'real_T'; 
xcp.parameters(726).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P3_n';     
         
xcp.parameters(726).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P4_c';
xcp.parameters(726).size   =  1;       
xcp.parameters(726).dtname = 'real_T'; 
xcp.parameters(727).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P4_c';     
         
xcp.parameters(727).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P5_c';
xcp.parameters(727).size   =  1;       
xcp.parameters(727).dtname = 'real_T'; 
xcp.parameters(728).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P5_c';     
         
xcp.parameters(728).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P6_b';
xcp.parameters(728).size   =  1;       
xcp.parameters(728).dtname = 'real_T'; 
xcp.parameters(729).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P6_b';     
         
xcp.parameters(729).symbol = 'may23_P.BKINEtherCATPDOTransmit1_P7_g';
xcp.parameters(729).size   =  1;       
xcp.parameters(729).dtname = 'real_T'; 
xcp.parameters(730).baseaddr = '&may23_P.BKINEtherCATPDOTransmit1_P7_g';     
         
xcp.parameters(730).symbol = 'may23_P.Memory_InitialCondition_lc';
xcp.parameters(730).size   =  1;       
xcp.parameters(730).dtname = 'int32_T'; 
xcp.parameters(731).baseaddr = '&may23_P.Memory_InitialCondition_lc';     
         
xcp.parameters(731).symbol = 'may23_P.Memory1_InitialCondition_e';
xcp.parameters(731).size   =  1;       
xcp.parameters(731).dtname = 'real_T'; 
xcp.parameters(732).baseaddr = '&may23_P.Memory1_InitialCondition_e';     
         
xcp.parameters(732).symbol = 'may23_P.Memory2_InitialCondition_c';
xcp.parameters(732).size   =  1;       
xcp.parameters(732).dtname = 'int32_T'; 
xcp.parameters(733).baseaddr = '&may23_P.Memory2_InitialCondition_c';     
         
xcp.parameters(733).symbol = 'may23_P.FixPtConstant_Value_j';
xcp.parameters(733).size   =  1;       
xcp.parameters(733).dtname = 'uint32_T'; 
xcp.parameters(734).baseaddr = '&may23_P.FixPtConstant_Value_j';     
         
xcp.parameters(734).symbol = 'may23_P.Constant_Value_mv';
xcp.parameters(734).size   =  1;       
xcp.parameters(734).dtname = 'uint32_T'; 
xcp.parameters(735).baseaddr = '&may23_P.Constant_Value_mv';     
         
xcp.parameters(735).symbol = 'may23_P.undorderbutterworth4Khz10hzcutoff_Value';
xcp.parameters(735).size   =  3;       
xcp.parameters(735).dtname = 'real_T'; 
xcp.parameters(736).baseaddr = '&may23_P.undorderbutterworth4Khz10hzcutoff_Value[0]';     
         
xcp.parameters(736).symbol = 'may23_P.Constant_Value_l5';
xcp.parameters(736).size   =  1;       
xcp.parameters(736).dtname = 'uint16_T'; 
xcp.parameters(737).baseaddr = '&may23_P.Constant_Value_l5';     
         
xcp.parameters(737).symbol = 'may23_P.Constant1_Value_ov';
xcp.parameters(737).size   =  1;       
xcp.parameters(737).dtname = 'uint32_T'; 
xcp.parameters(738).baseaddr = '&may23_P.Constant1_Value_ov';     
         
xcp.parameters(738).symbol = 'may23_P.Constant2_Value_i';
xcp.parameters(738).size   =  1;       
xcp.parameters(738).dtname = 'uint16_T'; 
xcp.parameters(739).baseaddr = '&may23_P.Constant2_Value_i';     
         
xcp.parameters(739).symbol = 'may23_P.Constant3_Value';
xcp.parameters(739).size   =  1;       
xcp.parameters(739).dtname = 'uint16_T'; 
xcp.parameters(740).baseaddr = '&may23_P.Constant3_Value';     
         
xcp.parameters(740).symbol = 'may23_P.Send_P1_k';
xcp.parameters(740).size   =  26;       
xcp.parameters(740).dtname = 'real_T'; 
xcp.parameters(741).baseaddr = '&may23_P.Send_P1_k[0]';     
         
xcp.parameters(741).symbol = 'may23_P.Send_P2_k';
xcp.parameters(741).size   =  1;       
xcp.parameters(741).dtname = 'real_T'; 
xcp.parameters(742).baseaddr = '&may23_P.Send_P2_k';     
         
xcp.parameters(742).symbol = 'may23_P.Send_P3_a';
xcp.parameters(742).size   =  12;       
xcp.parameters(742).dtname = 'real_T'; 
xcp.parameters(743).baseaddr = '&may23_P.Send_P3_a[0]';     
         
xcp.parameters(743).symbol = 'may23_P.Send_P4_d';
xcp.parameters(743).size   =  1;       
xcp.parameters(743).dtname = 'real_T'; 
xcp.parameters(744).baseaddr = '&may23_P.Send_P4_d';     
         
xcp.parameters(744).symbol = 'may23_P.Send_P5_c';
xcp.parameters(744).size   =  1;       
xcp.parameters(744).dtname = 'real_T'; 
xcp.parameters(745).baseaddr = '&may23_P.Send_P5_c';     
         
xcp.parameters(745).symbol = 'may23_P.Send_P6_i';
xcp.parameters(745).size   =  1;       
xcp.parameters(745).dtname = 'real_T'; 
xcp.parameters(746).baseaddr = '&may23_P.Send_P6_i';     
         
xcp.parameters(746).symbol = 'may23_P.Switch_Threshold';
xcp.parameters(746).size   =  1;       
xcp.parameters(746).dtname = 'real_T'; 
xcp.parameters(747).baseaddr = '&may23_P.Switch_Threshold';     
         
xcp.parameters(747).symbol = 'may23_P.Constant_Value_g';
xcp.parameters(747).size   =  1;       
xcp.parameters(747).dtname = 'uint16_T'; 
xcp.parameters(748).baseaddr = '&may23_P.Constant_Value_g';     
         
xcp.parameters(748).symbol = 'may23_P.Constant1_Value_m';
xcp.parameters(748).size   =  1;       
xcp.parameters(748).dtname = 'uint32_T'; 
xcp.parameters(749).baseaddr = '&may23_P.Constant1_Value_m';     
         
xcp.parameters(749).symbol = 'may23_P.Constant2_Value_a';
xcp.parameters(749).size   =  1;       
xcp.parameters(749).dtname = 'uint16_T'; 
xcp.parameters(750).baseaddr = '&may23_P.Constant2_Value_a';     
         
xcp.parameters(750).symbol = 'may23_P.Constant3_Value_k';
xcp.parameters(750).size   =  1;       
xcp.parameters(750).dtname = 'uint16_T'; 
xcp.parameters(751).baseaddr = '&may23_P.Constant3_Value_k';     
         
xcp.parameters(751).symbol = 'may23_P.Send_P1_p';
xcp.parameters(751).size   =  26;       
xcp.parameters(751).dtname = 'real_T'; 
xcp.parameters(752).baseaddr = '&may23_P.Send_P1_p[0]';     
         
xcp.parameters(752).symbol = 'may23_P.Send_P2_bu';
xcp.parameters(752).size   =  1;       
xcp.parameters(752).dtname = 'real_T'; 
xcp.parameters(753).baseaddr = '&may23_P.Send_P2_bu';     
         
xcp.parameters(753).symbol = 'may23_P.Send_P3_e';
xcp.parameters(753).size   =  12;       
xcp.parameters(753).dtname = 'real_T'; 
xcp.parameters(754).baseaddr = '&may23_P.Send_P3_e[0]';     
         
xcp.parameters(754).symbol = 'may23_P.Send_P4_m';
xcp.parameters(754).size   =  1;       
xcp.parameters(754).dtname = 'real_T'; 
xcp.parameters(755).baseaddr = '&may23_P.Send_P4_m';     
         
xcp.parameters(755).symbol = 'may23_P.Send_P5_o';
xcp.parameters(755).size   =  1;       
xcp.parameters(755).dtname = 'real_T'; 
xcp.parameters(756).baseaddr = '&may23_P.Send_P5_o';     
         
xcp.parameters(756).symbol = 'may23_P.Send_P6_m';
xcp.parameters(756).size   =  1;       
xcp.parameters(756).dtname = 'real_T'; 
xcp.parameters(757).baseaddr = '&may23_P.Send_P6_m';     
         
xcp.parameters(757).symbol = 'may23_P.Switch_Threshold_k';
xcp.parameters(757).size   =  1;       
xcp.parameters(757).dtname = 'real_T'; 
xcp.parameters(758).baseaddr = '&may23_P.Switch_Threshold_k';     
         
xcp.parameters(758).symbol = 'may23_P.DPRAMReadOffset_Value';
xcp.parameters(758).size   =  1;       
xcp.parameters(758).dtname = 'real_T'; 
xcp.parameters(759).baseaddr = '&may23_P.DPRAMReadOffset_Value';     
         
xcp.parameters(759).symbol = 'may23_P.DPRAMWatchDogoffset_Value';
xcp.parameters(759).size   =  1;       
xcp.parameters(759).dtname = 'real_T'; 
xcp.parameters(760).baseaddr = '&may23_P.DPRAMWatchDogoffset_Value';     
         
xcp.parameters(760).symbol = 'may23_P.DPRAMWriteOffset_Value';
xcp.parameters(760).size   =  1;       
xcp.parameters(760).dtname = 'real_T'; 
xcp.parameters(761).baseaddr = '&may23_P.DPRAMWriteOffset_Value';     
         
xcp.parameters(761).symbol = 'may23_P.DPRAMWriteValue_Value';
xcp.parameters(761).size   =  1;       
xcp.parameters(761).dtname = 'real_T'; 
xcp.parameters(762).baseaddr = '&may23_P.DPRAMWriteValue_Value';     
         
xcp.parameters(762).symbol = 'may23_P.ReadSwitch_Value';
xcp.parameters(762).size   =  1;       
xcp.parameters(762).dtname = 'real_T'; 
xcp.parameters(763).baseaddr = '&may23_P.ReadSwitch_Value';     
         
xcp.parameters(763).symbol = 'may23_P.ReadasUInt32_Value';
xcp.parameters(763).size   =  1;       
xcp.parameters(763).dtname = 'real_T'; 
xcp.parameters(764).baseaddr = '&may23_P.ReadasUInt32_Value';     
         
xcp.parameters(764).symbol = 'may23_P.WriteSwitch_Value';
xcp.parameters(764).size   =  1;       
xcp.parameters(764).dtname = 'real_T'; 
xcp.parameters(765).baseaddr = '&may23_P.WriteSwitch_Value';     
         
xcp.parameters(765).symbol = 'may23_P.DPRAMReadValue_Gain';
xcp.parameters(765).size   =  1;       
xcp.parameters(765).dtname = 'real_T'; 
xcp.parameters(766).baseaddr = '&may23_P.DPRAMReadValue_Gain';     
         
xcp.parameters(766).symbol = 'may23_P.UnitDelay_InitialCondition_c';
xcp.parameters(766).size   =  1;       
xcp.parameters(766).dtname = 'real_T'; 
xcp.parameters(767).baseaddr = '&may23_P.UnitDelay_InitialCondition_c';     
         
xcp.parameters(767).symbol = 'may23_P.UnitDelay1_InitialCondition';
xcp.parameters(767).size   =  1;       
xcp.parameters(767).dtname = 'real_T'; 
xcp.parameters(768).baseaddr = '&may23_P.UnitDelay1_InitialCondition';     
         
xcp.parameters(768).symbol = 'may23_P.UnitDelay2_InitialCondition';
xcp.parameters(768).size   =  1;       
xcp.parameters(768).dtname = 'real_T'; 
xcp.parameters(769).baseaddr = '&may23_P.UnitDelay2_InitialCondition';     
         
xcp.parameters(769).symbol = 'may23_P.UnitDelay3_InitialCondition';
xcp.parameters(769).size   =  1;       
xcp.parameters(769).dtname = 'real_T'; 
xcp.parameters(770).baseaddr = '&may23_P.UnitDelay3_InitialCondition';     
         
xcp.parameters(770).symbol = 'may23_P.FixPtConstant_Value_a';
xcp.parameters(770).size   =  1;       
xcp.parameters(770).dtname = 'uint32_T'; 
xcp.parameters(771).baseaddr = '&may23_P.FixPtConstant_Value_a';     
         
xcp.parameters(771).symbol = 'may23_P.Constant_Value_i';
xcp.parameters(771).size   =  1;       
xcp.parameters(771).dtname = 'uint32_T'; 
xcp.parameters(772).baseaddr = '&may23_P.Constant_Value_i';     
         
xcp.parameters(772).symbol = 'may23_P.WrapToZero_Threshold_h';
xcp.parameters(772).size   =  1;       
xcp.parameters(772).dtname = 'uint32_T'; 
xcp.parameters(773).baseaddr = '&may23_P.WrapToZero_Threshold_h';     
         
xcp.parameters(773).symbol = 'may23_P.Output_InitialCondition_e';
xcp.parameters(773).size   =  1;       
xcp.parameters(773).dtname = 'uint32_T'; 
xcp.parameters(774).baseaddr = '&may23_P.Output_InitialCondition_e';     
         
xcp.parameters(774).symbol = 'may23_P.FixPtConstant_Value_g';
xcp.parameters(774).size   =  1;       
xcp.parameters(774).dtname = 'uint32_T'; 
xcp.parameters(775).baseaddr = '&may23_P.FixPtConstant_Value_g';     
         
xcp.parameters(775).symbol = 'may23_P.Constant_Value_li';
xcp.parameters(775).size   =  1;       
xcp.parameters(775).dtname = 'uint32_T'; 
xcp.parameters(776).baseaddr = '&may23_P.Constant_Value_li';     
         
xcp.parameters(776).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P1';
xcp.parameters(776).size   =  39;       
xcp.parameters(776).dtname = 'real_T'; 
xcp.parameters(777).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P1[0]';     
         
xcp.parameters(777).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P2';
xcp.parameters(777).size   =  1;       
xcp.parameters(777).dtname = 'real_T'; 
xcp.parameters(778).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P2';     
         
xcp.parameters(778).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P3';
xcp.parameters(778).size   =  1;       
xcp.parameters(778).dtname = 'real_T'; 
xcp.parameters(779).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P3';     
         
xcp.parameters(779).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P4';
xcp.parameters(779).size   =  1;       
xcp.parameters(779).dtname = 'real_T'; 
xcp.parameters(780).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P4';     
         
xcp.parameters(780).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P5';
xcp.parameters(780).size   =  1;       
xcp.parameters(780).dtname = 'real_T'; 
xcp.parameters(781).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P5';     
         
xcp.parameters(781).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P6';
xcp.parameters(781).size   =  1;       
xcp.parameters(781).dtname = 'real_T'; 
xcp.parameters(782).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P6';     
         
xcp.parameters(782).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P7';
xcp.parameters(782).size   =  1;       
xcp.parameters(782).dtname = 'real_T'; 
xcp.parameters(783).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P7';     
         
xcp.parameters(783).symbol = 'may23_P.driveID_Value';
xcp.parameters(783).size   =  1;       
xcp.parameters(783).dtname = 'real_T'; 
xcp.parameters(784).baseaddr = '&may23_P.driveID_Value';     
         
xcp.parameters(784).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P1_c';
xcp.parameters(784).size   =  39;       
xcp.parameters(784).dtname = 'real_T'; 
xcp.parameters(785).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P1_c[0]';     
         
xcp.parameters(785).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P2_i';
xcp.parameters(785).size   =  1;       
xcp.parameters(785).dtname = 'real_T'; 
xcp.parameters(786).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P2_i';     
         
xcp.parameters(786).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P3_b';
xcp.parameters(786).size   =  1;       
xcp.parameters(786).dtname = 'real_T'; 
xcp.parameters(787).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P3_b';     
         
xcp.parameters(787).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P4_l';
xcp.parameters(787).size   =  1;       
xcp.parameters(787).dtname = 'real_T'; 
xcp.parameters(788).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P4_l';     
         
xcp.parameters(788).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P5_b';
xcp.parameters(788).size   =  1;       
xcp.parameters(788).dtname = 'real_T'; 
xcp.parameters(789).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P5_b';     
         
xcp.parameters(789).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P6_g';
xcp.parameters(789).size   =  1;       
xcp.parameters(789).dtname = 'real_T'; 
xcp.parameters(790).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P6_g';     
         
xcp.parameters(790).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P7_i';
xcp.parameters(790).size   =  1;       
xcp.parameters(790).dtname = 'real_T'; 
xcp.parameters(791).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P7_i';     
         
xcp.parameters(791).symbol = 'may23_P.driveID_Value_c';
xcp.parameters(791).size   =  1;       
xcp.parameters(791).dtname = 'real_T'; 
xcp.parameters(792).baseaddr = '&may23_P.driveID_Value_c';     
         
xcp.parameters(792).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P1_cm';
xcp.parameters(792).size   =  39;       
xcp.parameters(792).dtname = 'real_T'; 
xcp.parameters(793).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P1_cm[0]';     
         
xcp.parameters(793).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P2_m';
xcp.parameters(793).size   =  1;       
xcp.parameters(793).dtname = 'real_T'; 
xcp.parameters(794).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P2_m';     
         
xcp.parameters(794).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P3_l';
xcp.parameters(794).size   =  1;       
xcp.parameters(794).dtname = 'real_T'; 
xcp.parameters(795).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P3_l';     
         
xcp.parameters(795).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P4_h';
xcp.parameters(795).size   =  1;       
xcp.parameters(795).dtname = 'real_T'; 
xcp.parameters(796).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P4_h';     
         
xcp.parameters(796).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P5_i';
xcp.parameters(796).size   =  1;       
xcp.parameters(796).dtname = 'real_T'; 
xcp.parameters(797).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P5_i';     
         
xcp.parameters(797).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P6_f';
xcp.parameters(797).size   =  1;       
xcp.parameters(797).dtname = 'real_T'; 
xcp.parameters(798).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P6_f';     
         
xcp.parameters(798).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P7_o';
xcp.parameters(798).size   =  1;       
xcp.parameters(798).dtname = 'real_T'; 
xcp.parameters(799).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P7_o';     
         
xcp.parameters(799).symbol = 'may23_P.driveID_Value_i';
xcp.parameters(799).size   =  1;       
xcp.parameters(799).dtname = 'real_T'; 
xcp.parameters(800).baseaddr = '&may23_P.driveID_Value_i';     
         
xcp.parameters(800).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P1_g';
xcp.parameters(800).size   =  39;       
xcp.parameters(800).dtname = 'real_T'; 
xcp.parameters(801).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P1_g[0]';     
         
xcp.parameters(801).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P2_a';
xcp.parameters(801).size   =  1;       
xcp.parameters(801).dtname = 'real_T'; 
xcp.parameters(802).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P2_a';     
         
xcp.parameters(802).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P3_bd';
xcp.parameters(802).size   =  1;       
xcp.parameters(802).dtname = 'real_T'; 
xcp.parameters(803).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P3_bd';     
         
xcp.parameters(803).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P4_p';
xcp.parameters(803).size   =  1;       
xcp.parameters(803).dtname = 'real_T'; 
xcp.parameters(804).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P4_p';     
         
xcp.parameters(804).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P5_f';
xcp.parameters(804).size   =  1;       
xcp.parameters(804).dtname = 'real_T'; 
xcp.parameters(805).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P5_f';     
         
xcp.parameters(805).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P6_fu';
xcp.parameters(805).size   =  1;       
xcp.parameters(805).dtname = 'real_T'; 
xcp.parameters(806).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P6_fu';     
         
xcp.parameters(806).symbol = 'may23_P.BKINPDOReceiveElmoDrive_P7_g';
xcp.parameters(806).size   =  1;       
xcp.parameters(806).dtname = 'real_T'; 
xcp.parameters(807).baseaddr = '&may23_P.BKINPDOReceiveElmoDrive_P7_g';     
         
xcp.parameters(807).symbol = 'may23_P.driveID_Value_n';
xcp.parameters(807).size   =  1;       
xcp.parameters(807).dtname = 'real_T'; 
xcp.parameters(808).baseaddr = '&may23_P.driveID_Value_n';     
         
xcp.parameters(808).symbol = 'may23_P.WrapToZero_Threshold_cm';
xcp.parameters(808).size   =  1;       
xcp.parameters(808).dtname = 'uint16_T'; 
xcp.parameters(809).baseaddr = '&may23_P.WrapToZero_Threshold_cm';     
         
xcp.parameters(809).symbol = 'may23_P.Output_InitialCondition_o';
xcp.parameters(809).size   =  1;       
xcp.parameters(809).dtname = 'uint16_T'; 
xcp.parameters(810).baseaddr = '&may23_P.Output_InitialCondition_o';     
         
xcp.parameters(810).symbol = 'may23_P.FixPtConstant_Value_h';
xcp.parameters(810).size   =  1;       
xcp.parameters(810).dtname = 'uint32_T'; 
xcp.parameters(811).baseaddr = '&may23_P.FixPtConstant_Value_h';     
         
xcp.parameters(811).symbol = 'may23_P.Constant_Value_pz';
xcp.parameters(811).size   =  1;       
xcp.parameters(811).dtname = 'uint32_T'; 
xcp.parameters(812).baseaddr = '&may23_P.Constant_Value_pz';     
         
xcp.parameters(812).symbol = 'may23_P.Constant_Value_pb';
xcp.parameters(812).size   =  1;       
xcp.parameters(812).dtname = 'uint32_T'; 
xcp.parameters(813).baseaddr = '&may23_P.Constant_Value_pb';     
         
xcp.parameters(813).symbol = 'may23_P.Switch_Threshold_h2';
xcp.parameters(813).size   =  1;       
xcp.parameters(813).dtname = 'int32_T'; 
xcp.parameters(814).baseaddr = '&may23_P.Switch_Threshold_h2';     
         
xcp.parameters(814).symbol = 'may23_P.Constant_Value_f';
xcp.parameters(814).size   =  1;       
xcp.parameters(814).dtname = 'uint16_T'; 
xcp.parameters(815).baseaddr = '&may23_P.Constant_Value_f';     
         
xcp.parameters(815).symbol = 'may23_P.Switch_Threshold_p';
xcp.parameters(815).size   =  1;       
xcp.parameters(815).dtname = 'int32_T'; 
xcp.parameters(816).baseaddr = '&may23_P.Switch_Threshold_p';     
         
xcp.parameters(816).symbol = 'may23_P.Constant_Value_l2';
xcp.parameters(816).size   =  1;       
xcp.parameters(816).dtname = 'int32_T'; 
xcp.parameters(817).baseaddr = '&may23_P.Constant_Value_l2';     
         
xcp.parameters(817).symbol = 'may23_P.Constant1_Value_n';
xcp.parameters(817).size   =  1;       
xcp.parameters(817).dtname = 'int32_T'; 
xcp.parameters(818).baseaddr = '&may23_P.Constant1_Value_n';     
         
xcp.parameters(818).symbol = 'may23_P.Memory_InitialCondition_ny';
xcp.parameters(818).size   =  1;       
xcp.parameters(818).dtname = 'uint32_T'; 
xcp.parameters(819).baseaddr = '&may23_P.Memory_InitialCondition_ny';     
         
xcp.parameters(819).symbol = 'may23_P.Constant_Value_k';
xcp.parameters(819).size   =  1;       
xcp.parameters(819).dtname = 'int32_T'; 
xcp.parameters(820).baseaddr = '&may23_P.Constant_Value_k';     
         
xcp.parameters(820).symbol = 'may23_P.Memory_InitialCondition_g';
xcp.parameters(820).size   =  1;       
xcp.parameters(820).dtname = 'int32_T'; 
xcp.parameters(821).baseaddr = '&may23_P.Memory_InitialCondition_g';     
         
xcp.parameters(821).symbol = 'may23_P.Constant_Value_di';
xcp.parameters(821).size   =  1;       
xcp.parameters(821).dtname = 'uint32_T'; 
xcp.parameters(822).baseaddr = '&may23_P.Constant_Value_di';     
         
xcp.parameters(822).symbol = 'may23_P.Constant1_Value_c';
xcp.parameters(822).size   =  1;       
xcp.parameters(822).dtname = 'int32_T'; 
xcp.parameters(823).baseaddr = '&may23_P.Constant1_Value_c';     
         
xcp.parameters(823).symbol = 'may23_P.Memory_InitialCondition';
xcp.parameters(823).size   =  1;       
xcp.parameters(823).dtname = 'real_T'; 
xcp.parameters(824).baseaddr = '&may23_P.Memory_InitialCondition';     
         
xcp.parameters(824).symbol = 'may23_P.Constant_Value_l0';
xcp.parameters(824).size   =  1;       
xcp.parameters(824).dtname = 'uint32_T'; 
xcp.parameters(825).baseaddr = '&may23_P.Constant_Value_l0';     
         
xcp.parameters(825).symbol = 'may23_P.Switch_Threshold_c';
xcp.parameters(825).size   =  1;       
xcp.parameters(825).dtname = 'int32_T'; 
xcp.parameters(826).baseaddr = '&may23_P.Switch_Threshold_c';     
         
xcp.parameters(826).symbol = 'may23_P.Constant_Value_cg';
xcp.parameters(826).size   =  1;       
xcp.parameters(826).dtname = 'uint16_T'; 
xcp.parameters(827).baseaddr = '&may23_P.Constant_Value_cg';     
         
xcp.parameters(827).symbol = 'may23_P.Switch_Threshold_jw';
xcp.parameters(827).size   =  1;       
xcp.parameters(827).dtname = 'int32_T'; 
xcp.parameters(828).baseaddr = '&may23_P.Switch_Threshold_jw';     
         
xcp.parameters(828).symbol = 'may23_P.Constant_Value_p';
xcp.parameters(828).size   =  1;       
xcp.parameters(828).dtname = 'int32_T'; 
xcp.parameters(829).baseaddr = '&may23_P.Constant_Value_p';     
         
xcp.parameters(829).symbol = 'may23_P.Constant1_Value_o';
xcp.parameters(829).size   =  1;       
xcp.parameters(829).dtname = 'int32_T'; 
xcp.parameters(830).baseaddr = '&may23_P.Constant1_Value_o';     
         
xcp.parameters(830).symbol = 'may23_P.Memory_InitialCondition_c';
xcp.parameters(830).size   =  1;       
xcp.parameters(830).dtname = 'uint32_T'; 
xcp.parameters(831).baseaddr = '&may23_P.Memory_InitialCondition_c';     
         
xcp.parameters(831).symbol = 'may23_P.Constant_Value_ka';
xcp.parameters(831).size   =  1;       
xcp.parameters(831).dtname = 'int32_T'; 
xcp.parameters(832).baseaddr = '&may23_P.Constant_Value_ka';     
         
xcp.parameters(832).symbol = 'may23_P.Memory_InitialCondition_ax';
xcp.parameters(832).size   =  1;       
xcp.parameters(832).dtname = 'int32_T'; 
xcp.parameters(833).baseaddr = '&may23_P.Memory_InitialCondition_ax';     
         
xcp.parameters(833).symbol = 'may23_P.Constant_Value_ce';
xcp.parameters(833).size   =  1;       
xcp.parameters(833).dtname = 'uint32_T'; 
xcp.parameters(834).baseaddr = '&may23_P.Constant_Value_ce';     
         
xcp.parameters(834).symbol = 'may23_P.Constant1_Value_i';
xcp.parameters(834).size   =  1;       
xcp.parameters(834).dtname = 'int32_T'; 
xcp.parameters(835).baseaddr = '&may23_P.Constant1_Value_i';     
         
xcp.parameters(835).symbol = 'may23_P.Memory_InitialCondition_k';
xcp.parameters(835).size   =  1;       
xcp.parameters(835).dtname = 'real_T'; 
xcp.parameters(836).baseaddr = '&may23_P.Memory_InitialCondition_k';     
         
xcp.parameters(836).symbol = 'may23_P.Constant_Value_cey';
xcp.parameters(836).size   =  1;       
xcp.parameters(836).dtname = 'uint32_T'; 
xcp.parameters(837).baseaddr = '&may23_P.Constant_Value_cey';     
         
xcp.parameters(837).symbol = 'may23_P.Switch_Threshold_eg';
xcp.parameters(837).size   =  1;       
xcp.parameters(837).dtname = 'int32_T'; 
xcp.parameters(838).baseaddr = '&may23_P.Switch_Threshold_eg';     
         
xcp.parameters(838).symbol = 'may23_P.Constant_Value_cq';
xcp.parameters(838).size   =  1;       
xcp.parameters(838).dtname = 'uint16_T'; 
xcp.parameters(839).baseaddr = '&may23_P.Constant_Value_cq';     
         
xcp.parameters(839).symbol = 'may23_P.Switch_Threshold_l';
xcp.parameters(839).size   =  1;       
xcp.parameters(839).dtname = 'int32_T'; 
xcp.parameters(840).baseaddr = '&may23_P.Switch_Threshold_l';     
         
xcp.parameters(840).symbol = 'may23_P.Constant_Value_mj';
xcp.parameters(840).size   =  1;       
xcp.parameters(840).dtname = 'int32_T'; 
xcp.parameters(841).baseaddr = '&may23_P.Constant_Value_mj';     
         
xcp.parameters(841).symbol = 'may23_P.Constant1_Value_g';
xcp.parameters(841).size   =  1;       
xcp.parameters(841).dtname = 'int32_T'; 
xcp.parameters(842).baseaddr = '&may23_P.Constant1_Value_g';     
         
xcp.parameters(842).symbol = 'may23_P.Memory_InitialCondition_iz';
xcp.parameters(842).size   =  1;       
xcp.parameters(842).dtname = 'uint32_T'; 
xcp.parameters(843).baseaddr = '&may23_P.Memory_InitialCondition_iz';     
         
xcp.parameters(843).symbol = 'may23_P.Constant_Value_k2';
xcp.parameters(843).size   =  1;       
xcp.parameters(843).dtname = 'int32_T'; 
xcp.parameters(844).baseaddr = '&may23_P.Constant_Value_k2';     
         
xcp.parameters(844).symbol = 'may23_P.Memory_InitialCondition_bo';
xcp.parameters(844).size   =  1;       
xcp.parameters(844).dtname = 'int32_T'; 
xcp.parameters(845).baseaddr = '&may23_P.Memory_InitialCondition_bo';     
         
xcp.parameters(845).symbol = 'may23_P.Constant_Value_jo';
xcp.parameters(845).size   =  1;       
xcp.parameters(845).dtname = 'uint32_T'; 
xcp.parameters(846).baseaddr = '&may23_P.Constant_Value_jo';     
         
xcp.parameters(846).symbol = 'may23_P.Constant1_Value_p';
xcp.parameters(846).size   =  1;       
xcp.parameters(846).dtname = 'int32_T'; 
xcp.parameters(847).baseaddr = '&may23_P.Constant1_Value_p';     
         
xcp.parameters(847).symbol = 'may23_P.Memory_InitialCondition_pg';
xcp.parameters(847).size   =  1;       
xcp.parameters(847).dtname = 'real_T'; 
xcp.parameters(848).baseaddr = '&may23_P.Memory_InitialCondition_pg';     
         
xcp.parameters(848).symbol = 'may23_P.Constant_Value_e';
xcp.parameters(848).size   =  1;       
xcp.parameters(848).dtname = 'uint32_T'; 
xcp.parameters(849).baseaddr = '&may23_P.Constant_Value_e';     
         
xcp.parameters(849).symbol = 'may23_P.Switch_Threshold_kt';
xcp.parameters(849).size   =  1;       
xcp.parameters(849).dtname = 'int32_T'; 
xcp.parameters(850).baseaddr = '&may23_P.Switch_Threshold_kt';     
         
xcp.parameters(850).symbol = 'may23_P.Constant_Value_cc';
xcp.parameters(850).size   =  1;       
xcp.parameters(850).dtname = 'uint16_T'; 
xcp.parameters(851).baseaddr = '&may23_P.Constant_Value_cc';     
         
xcp.parameters(851).symbol = 'may23_P.Switch_Threshold_pr';
xcp.parameters(851).size   =  1;       
xcp.parameters(851).dtname = 'int32_T'; 
xcp.parameters(852).baseaddr = '&may23_P.Switch_Threshold_pr';     
         
xcp.parameters(852).symbol = 'may23_P.Constant_Value_de';
xcp.parameters(852).size   =  1;       
xcp.parameters(852).dtname = 'int32_T'; 
xcp.parameters(853).baseaddr = '&may23_P.Constant_Value_de';     
         
xcp.parameters(853).symbol = 'may23_P.Constant1_Value_j';
xcp.parameters(853).size   =  1;       
xcp.parameters(853).dtname = 'int32_T'; 
xcp.parameters(854).baseaddr = '&may23_P.Constant1_Value_j';     
         
xcp.parameters(854).symbol = 'may23_P.Memory_InitialCondition_hd';
xcp.parameters(854).size   =  1;       
xcp.parameters(854).dtname = 'uint32_T'; 
xcp.parameters(855).baseaddr = '&may23_P.Memory_InitialCondition_hd';     
         
xcp.parameters(855).symbol = 'may23_P.Constant_Value_o';
xcp.parameters(855).size   =  1;       
xcp.parameters(855).dtname = 'int32_T'; 
xcp.parameters(856).baseaddr = '&may23_P.Constant_Value_o';     
         
xcp.parameters(856).symbol = 'may23_P.Memory_InitialCondition_l';
xcp.parameters(856).size   =  1;       
xcp.parameters(856).dtname = 'int32_T'; 
xcp.parameters(857).baseaddr = '&may23_P.Memory_InitialCondition_l';     
         
xcp.parameters(857).symbol = 'may23_P.Constant_Value_oz';
xcp.parameters(857).size   =  1;       
xcp.parameters(857).dtname = 'uint32_T'; 
xcp.parameters(858).baseaddr = '&may23_P.Constant_Value_oz';     
         
xcp.parameters(858).symbol = 'may23_P.Constant1_Value_ns';
xcp.parameters(858).size   =  1;       
xcp.parameters(858).dtname = 'int32_T'; 
xcp.parameters(859).baseaddr = '&may23_P.Constant1_Value_ns';     
         
xcp.parameters(859).symbol = 'may23_P.Memory_InitialCondition_a';
xcp.parameters(859).size   =  1;       
xcp.parameters(859).dtname = 'real_T'; 
xcp.parameters(860).baseaddr = '&may23_P.Memory_InitialCondition_a';     
         
xcp.parameters(860).symbol = 'may23_P.FixPtConstant_Value_n';
xcp.parameters(860).size   =  1;       
xcp.parameters(860).dtname = 'uint16_T'; 
xcp.parameters(861).baseaddr = '&may23_P.FixPtConstant_Value_n';     
         
xcp.parameters(861).symbol = 'may23_P.Constant_Value_pq';
xcp.parameters(861).size   =  1;       
xcp.parameters(861).dtname = 'uint16_T'; 
xcp.parameters(862).baseaddr = '&may23_P.Constant_Value_pq';     
         
xcp.parameters(862).symbol = 'may23_P.BKIN_STEP_TIME';
xcp.parameters(862).size   =  1;       
xcp.parameters(862).dtname = 'real_T'; 
xcp.parameters(863).baseaddr = '&may23_P.BKIN_STEP_TIME';     
         
xcp.parameters(863).symbol = 'BARRIER_ROW';
xcp.parameters(863).size   =  1;       
xcp.parameters(863).dtname = 'real_T'; 
xcp.parameters(864).baseaddr = '&BARRIER_ROW';     
         
xcp.parameters(864).symbol = 'CURSOR_ROW';
xcp.parameters(864).size   =  1;       
xcp.parameters(864).dtname = 'real_T'; 
xcp.parameters(865).baseaddr = '&CURSOR_ROW';     
         
xcp.parameters(865).symbol = 'E_BEGIN_PRESHOT';
xcp.parameters(865).size   =  1;       
xcp.parameters(865).dtname = 'real_T'; 
xcp.parameters(866).baseaddr = '&E_BEGIN_PRESHOT';     
         
xcp.parameters(866).symbol = 'E_ENTER_START';
xcp.parameters(866).size   =  1;       
xcp.parameters(866).dtname = 'real_T'; 
xcp.parameters(867).baseaddr = '&E_ENTER_START';     
         
xcp.parameters(867).symbol = 'E_FAILURE';
xcp.parameters(867).size   =  1;       
xcp.parameters(867).dtname = 'real_T'; 
xcp.parameters(868).baseaddr = '&E_FAILURE';     
         
xcp.parameters(868).symbol = 'E_HAND_IN_BARRIER';
xcp.parameters(868).size   =  1;       
xcp.parameters(868).dtname = 'real_T'; 
xcp.parameters(869).baseaddr = '&E_HAND_IN_BARRIER';     
         
xcp.parameters(869).symbol = 'E_NO_EVENT';
xcp.parameters(869).size   =  1;       
xcp.parameters(869).dtname = 'real_T'; 
xcp.parameters(870).baseaddr = '&E_NO_EVENT';     
         
xcp.parameters(870).symbol = 'E_PUCK_IN_BARRIER';
xcp.parameters(870).size   =  1;       
xcp.parameters(870).dtname = 'real_T'; 
xcp.parameters(871).baseaddr = '&E_PUCK_IN_BARRIER';     
         
xcp.parameters(871).symbol = 'E_PUCK_IN_GOAL';
xcp.parameters(871).size   =  1;       
xcp.parameters(871).dtname = 'real_T'; 
xcp.parameters(872).baseaddr = '&E_PUCK_IN_GOAL';     
         
xcp.parameters(872).symbol = 'E_PUCK_MISS';
xcp.parameters(872).size   =  1;       
xcp.parameters(872).dtname = 'real_T'; 
xcp.parameters(873).baseaddr = '&E_PUCK_MISS';     
         
xcp.parameters(873).symbol = 'E_SHOT_GO';
xcp.parameters(873).size   =  1;       
xcp.parameters(873).dtname = 'real_T'; 
xcp.parameters(874).baseaddr = '&E_SHOT_GO';     
         
xcp.parameters(874).symbol = 'E_SHOT_READY';
xcp.parameters(874).size   =  1;       
xcp.parameters(874).dtname = 'real_T'; 
xcp.parameters(875).baseaddr = '&E_SHOT_READY';     
         
xcp.parameters(875).symbol = 'E_START_TARGET_ON';
xcp.parameters(875).size   =  1;       
xcp.parameters(875).dtname = 'real_T'; 
xcp.parameters(876).baseaddr = '&E_START_TARGET_ON';     
         
xcp.parameters(876).symbol = 'E_SUCCESS';
xcp.parameters(876).size   =  1;       
xcp.parameters(876).dtname = 'real_T'; 
xcp.parameters(877).baseaddr = '&E_SUCCESS';     
         
xcp.parameters(877).symbol = 'E_TIMEOUT';
xcp.parameters(877).size   =  1;       
xcp.parameters(877).dtname = 'real_T'; 
xcp.parameters(878).baseaddr = '&E_TIMEOUT';     
         
xcp.parameters(878).symbol = 'E_TRIAL_START';
xcp.parameters(878).size   =  1;       
xcp.parameters(878).dtname = 'real_T'; 
xcp.parameters(879).baseaddr = '&E_TRIAL_START';     
         
xcp.parameters(879).symbol = 'FIRST_FILL';
xcp.parameters(879).size   =  1;       
xcp.parameters(879).dtname = 'real_T'; 
xcp.parameters(880).baseaddr = '&FIRST_FILL';     
         
xcp.parameters(880).symbol = 'FORCE_MULTIPLIER';
xcp.parameters(880).size   =  1;       
xcp.parameters(880).dtname = 'real_T'; 
xcp.parameters(881).baseaddr = '&FORCE_MULTIPLIER';     
         
xcp.parameters(881).symbol = 'F_BUMP';
xcp.parameters(881).size   =  1;       
xcp.parameters(881).dtname = 'real_T'; 
xcp.parameters(882).baseaddr = '&F_BUMP';     
         
xcp.parameters(882).symbol = 'GOAL_ROW';
xcp.parameters(882).size   =  1;       
xcp.parameters(882).dtname = 'real_T'; 
xcp.parameters(883).baseaddr = '&GOAL_ROW';     
         
xcp.parameters(883).symbol = 'GOAL_TIME';
xcp.parameters(883).size   =  1;       
xcp.parameters(883).dtname = 'real_T'; 
xcp.parameters(884).baseaddr = '&GOAL_TIME';     
         
xcp.parameters(884).symbol = 'HEIGHT';
xcp.parameters(884).size   =  1;       
xcp.parameters(884).dtname = 'real_T'; 
xcp.parameters(885).baseaddr = '&HEIGHT';     
         
xcp.parameters(885).symbol = 'LOAD_ROW';
xcp.parameters(885).size   =  1;       
xcp.parameters(885).dtname = 'real_T'; 
xcp.parameters(886).baseaddr = '&LOAD_ROW';     
         
xcp.parameters(886).symbol = 'MASS_CIRCLE';
xcp.parameters(886).size   =  1;       
xcp.parameters(886).dtname = 'real_T'; 
xcp.parameters(887).baseaddr = '&MASS_CIRCLE';     
         
xcp.parameters(887).symbol = 'MASS_RECT';
xcp.parameters(887).size   =  1;       
xcp.parameters(887).dtname = 'real_T'; 
xcp.parameters(888).baseaddr = '&MASS_RECT';     
         
xcp.parameters(888).symbol = 'PERT_DUR';
xcp.parameters(888).size   =  1;       
xcp.parameters(888).dtname = 'real_T'; 
xcp.parameters(889).baseaddr = '&PERT_DUR';     
         
xcp.parameters(889).symbol = 'PERT_RAMP';
xcp.parameters(889).size   =  1;       
xcp.parameters(889).dtname = 'real_T'; 
xcp.parameters(890).baseaddr = '&PERT_RAMP';     
         
xcp.parameters(890).symbol = 'PRESHOT_ROW';
xcp.parameters(890).size   =  1;       
xcp.parameters(890).dtname = 'real_T'; 
xcp.parameters(891).baseaddr = '&PRESHOT_ROW';     
         
xcp.parameters(891).symbol = 'PUCK_DAMPING';
xcp.parameters(891).size   =  1;       
xcp.parameters(891).dtname = 'real_T'; 
xcp.parameters(892).baseaddr = '&PUCK_DAMPING';     
         
xcp.parameters(892).symbol = 'PUCK_ROW';
xcp.parameters(892).size   =  1;       
xcp.parameters(892).dtname = 'real_T'; 
xcp.parameters(893).baseaddr = '&PUCK_ROW';     
         
xcp.parameters(893).symbol = 'RADIUS_LOG';
xcp.parameters(893).size   =  1;       
xcp.parameters(893).dtname = 'real_T'; 
xcp.parameters(894).baseaddr = '&RADIUS_LOG';     
         
xcp.parameters(894).symbol = 'RADIUS_VIS';
xcp.parameters(894).size   =  1;       
xcp.parameters(894).dtname = 'real_T'; 
xcp.parameters(895).baseaddr = '&RADIUS_VIS';     
         
xcp.parameters(895).symbol = 'ROTATION';
xcp.parameters(895).size   =  1;       
xcp.parameters(895).dtname = 'real_T'; 
xcp.parameters(896).baseaddr = '&ROTATION';     
         
xcp.parameters(896).symbol = 'SECONDS';
xcp.parameters(896).size   =  1;       
xcp.parameters(896).dtname = 'real_T'; 
xcp.parameters(897).baseaddr = '&SECONDS';     
         
xcp.parameters(897).symbol = 'SECOND_FILL';
xcp.parameters(897).size   =  1;       
xcp.parameters(897).dtname = 'real_T'; 
xcp.parameters(898).baseaddr = '&SECOND_FILL';     
         
xcp.parameters(898).symbol = 'SHOT_READY_TIME';
xcp.parameters(898).size   =  1;       
xcp.parameters(898).dtname = 'real_T'; 
xcp.parameters(899).baseaddr = '&SHOT_READY_TIME';     
         
xcp.parameters(899).symbol = 'SHOT_SET_TIME';
xcp.parameters(899).size   =  1;       
xcp.parameters(899).dtname = 'real_T'; 
xcp.parameters(900).baseaddr = '&SHOT_SET_TIME';     
         
xcp.parameters(900).symbol = 'SHOT_TIME';
xcp.parameters(900).size   =  1;       
xcp.parameters(900).dtname = 'real_T'; 
xcp.parameters(901).baseaddr = '&SHOT_TIME';     
         
xcp.parameters(901).symbol = 'START_HOLD_TIME';
xcp.parameters(901).size   =  1;       
xcp.parameters(901).dtname = 'real_T'; 
xcp.parameters(902).baseaddr = '&START_HOLD_TIME';     
         
xcp.parameters(902).symbol = 'START_ROW';
xcp.parameters(902).size   =  1;       
xcp.parameters(902).dtname = 'real_T'; 
xcp.parameters(903).baseaddr = '&START_ROW';     
         
xcp.parameters(903).symbol = 'STROKE_COLOR';
xcp.parameters(903).size   =  1;       
xcp.parameters(903).dtname = 'real_T'; 
xcp.parameters(904).baseaddr = '&STROKE_COLOR';     
         
xcp.parameters(904).symbol = 'STROKE_WIDTH';
xcp.parameters(904).size   =  1;       
xcp.parameters(904).dtname = 'real_T'; 
xcp.parameters(905).baseaddr = '&STROKE_WIDTH';     
         
xcp.parameters(905).symbol = 'THIRD_FILL';
xcp.parameters(905).size   =  1;       
xcp.parameters(905).dtname = 'real_T'; 
xcp.parameters(906).baseaddr = '&THIRD_FILL';     
         
xcp.parameters(906).symbol = 'WIDTH';
xcp.parameters(906).size   =  1;       
xcp.parameters(906).dtname = 'real_T'; 
xcp.parameters(907).baseaddr = '&WIDTH';     
         
xcp.parameters(907).symbol = 'col_x';
xcp.parameters(907).size   =  1;       
xcp.parameters(907).dtname = 'real_T'; 
xcp.parameters(908).baseaddr = '&col_x';     
         
xcp.parameters(908).symbol = 'col_y';
xcp.parameters(908).size   =  1;       
xcp.parameters(908).dtname = 'real_T'; 
xcp.parameters(909).baseaddr = '&col_y';     

function n = getNumParameters
n = 908;

function n = getNumSignals
n = 1445;

function n = getNumEvents
n = 4;

function n = getNumModels
n = 1;

