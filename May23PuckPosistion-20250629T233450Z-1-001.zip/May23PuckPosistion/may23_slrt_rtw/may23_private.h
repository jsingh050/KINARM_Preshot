/*
 * may23_private.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "may23".
 *
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_may23_private_h_
#define RTW_HEADER_may23_private_h_
#include <stdio.h>
#include <stdlib.h>
#include <crc32.h>
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#include "may23.h"

/* Used to reverse endianness */
#define SWAP16(x)                      (((x) >> 8) | (((x) & 0xff) << 8))
#define SWAP32(x)                      (SWAP16((x) >> 16) | (SWAP16((x) & 0xffff) << 16))

extern unsigned int xmlecatArr_1_count;
extern unsigned char xmlecatArr_1[];
extern int_T slrtEcatDCM[8];           // From master shift controller
int32_T dcmHwSetIntTimestamp( void );
void dcmCtlExecJob();                  // Master shift control job
extern unsigned int xmlecatArr_0_count;
extern unsigned char xmlecatArr_0[];
extern int_T slrtEcatDCM[8];           // From master shift controller
int32_T dcmHwSetIntTimestamp( void );
void dcmCtlExecJob();                  // Master shift control job
extern void delay_vcodes_Outputs_wrapper(const int32_T *VCode,
  const real_T *VCode_len,
  const real_T *delay_ms,
  const real_T *step_time_ms,
  uint8_T *VCode_out,
  real_T *VCode_len_out,
  real_T *debug_out);
extern const serialfifoptr serialfifoground;
extern const bcmsglist1553 bcmsg1553ground;
extern const bcstatus1553 bcstatground;
extern const bmmsglist1553 bmmsg1553ground;
extern real_T rt_roundd_snf(real_T u);
extern real_T rt_powd_snf(real_T u0, real_T u1);
extern real_T rt_modd_snf(real_T u0, real_T u1);
extern real_T rt_atan2d_snf(real_T u0, real_T u1);
extern real_T rt_remd_snf(real_T u0, real_T u1);
extern const char *getRefMdlPath(const char *refMdl);
extern int getRefMdlSignalNumber(const char *mdlBlock, const char *signalName);
extern void slrtUDPSend(SimStruct *rts);
extern void slrtUDPReceive(SimStruct *rts);
extern void BKINethercatpdorxElmoDrive(SimStruct *rts);
extern void BKINethercatpdotx(SimStruct *rts);
extern void mcc_readmem(SimStruct *rts);
extern void mcc_writemem(SimStruct *rts);
extern void mcc_pollall(SimStruct *rts);
extern void kinarmfromfile(SimStruct *rts);
extern void eyelink_unpack(SimStruct *rts);
extern void mcc_apply_loads(SimStruct *rts);
extern void ich10(SimStruct *rts);
extern void may23_MATLABFunction_a(real_T rtu_orientation, real_T
  rtu_has_secondary, real_T rtu_isEP, B_MATLABFunction_may23_bc_T *localB);
extern void may23_Ramp_Up_Down_Init(B_Ramp_Up_Down_may23_T *localB,
  DW_Ramp_Up_Down_may23_T *localDW);
extern void may23_Ramp_Up_Down(real_T rtu_e_clk, boolean_T rtu_motors_enabled,
  real_T rtu_Run_Status, real_T rtu_up_duration, real_T rtu_down_duration,
  boolean_T rtu_is_ep, B_Ramp_Up_Down_may23_T *localB, DW_Ramp_Up_Down_may23_T
  *localDW, ZCE_Ramp_Up_Down_may23_T *localZCE);
extern void may23_Remove_NaNs_and_Inf(const real_T rtu_in[2], const real_T
  rtu_in_p[2], B_Remove_NaNs_and_Inf_may23_T *localB);
extern void may23_MATLABFunction_br(real_T rtu_motor_status, real_T
  rtu_grip_sensor, real_T rtu_is_ecat, B_MATLABFunction_may23_f_T *localB);
extern void may23_Ramp_Up_Down_l_Init(B_Ramp_Up_Down_may23_g_T *localB,
  DW_Ramp_Up_Down_may23_o_T *localDW);
extern void may23_Ramp_Up_Down_g(real_T rtu_e_clk, real_T rtu_Motors_Disabled,
  real_T rtu_Run_Status, real_T rtu_up_duration, real_T rtu_down_duration,
  real_T rtu_robot_type, B_Ramp_Up_Down_may23_g_T *localB,
  DW_Ramp_Up_Down_may23_o_T *localDW, ZCE_Ramp_Up_Down_may23_m_T *localZCE);
extern void may23_EmbeddedMATLABFunction(const real_T rtu_target[25], real_T
  rtu_state_in, real_T rtu_target_type, real_T rtu_opacity_in, real_T
  rtu_target_display, real_T rtu_x_index, real_T rtu_y_index, real_T
  rtu_num_states, const real_T rtu_stateindices[55],
  B_EmbeddedMATLABFunction_may23_T *localB);
extern void may23_EmbeddedMATLABFunction_m(const real_T rtu_target[25], real_T
  rtu_state_in, real_T rtu_target_type, real_T rtu_opacity_in, real_T
  rtu_target_display, real_T rtu_x_index, real_T rtu_y_index, real_T
  rtu_num_states, const real_T rtu_stateindices[55],
  B_EmbeddedMATLABFunction_may23_d_T *localB);

#endif                                 /* RTW_HEADER_may23_private_h_ */
