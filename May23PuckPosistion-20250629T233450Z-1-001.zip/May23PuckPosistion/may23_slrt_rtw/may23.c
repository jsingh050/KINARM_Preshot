/*
 * may23.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "may23".
 *
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rt_logging_mmi.h"
#include "may23_capi.h"
#include "may23.h"
#include "may23_private.h"

/* Named constants for Chart: '<S4>/Ramp_Up_Down' */
#define may23_IN_Init                  ((uint8_T)1U)
#define may23_IN_NO_ACTIVE_CHILD_hg    ((uint8_T)0U)
#define may23_IN_NotEP                 ((uint8_T)2U)
#define may23_IN_Ramp_Down             ((uint8_T)1U)
#define may23_IN_Ramp_Down2            ((uint8_T)2U)
#define may23_IN_Ramp_Down_Main        ((uint8_T)3U)
#define may23_IN_Ramp_Up               ((uint8_T)1U)
#define may23_IN_Ramp_Up2              ((uint8_T)2U)
#define may23_IN_Ramp_Up_Done          ((uint8_T)3U)
#define may23_IN_Ramp_Up_Main          ((uint8_T)4U)
#define may23_IN_Wait_for_Go           ((uint8_T)3U)
#define may23_event_e_clk              (0)

/* Named constants for Chart: '<S5>/Ramp_Up_Down' */
#define may23_IN_NO_ACTIVE_CHILD_fp    ((uint8_T)0U)
#define may23_IN_Ramp_Down2_o          ((uint8_T)2U)
#define may23_IN_Ramp_Down_c           ((uint8_T)1U)
#define may23_IN_Ramp_Up2_e            ((uint8_T)2U)
#define may23_IN_Ramp_Up_Done_o        ((uint8_T)3U)
#define may23_IN_Ramp_Up_Main_h        ((uint8_T)3U)
#define may23_IN_Ramp_Up_m             ((uint8_T)1U)
#define may23_IN_Wait_for_Go_g         ((uint8_T)4U)
#define may23_event_e_clk_a            (0)

/* Named constants for Chart: '<S329>/monitor_encoders' */
#define may23_IN_ECAT                  ((uint8_T)1U)
#define may23_IN_NO_ACTIVE_CHILD_l     ((uint8_T)0U)
#define may23_IN_PMAC_Sytem            ((uint8_T)2U)
#define may23_IN_init                  ((uint8_T)3U)
#define may23_IN_startup               ((uint8_T)4U)

/* Named constants for Chart: '<S38>/torque_monitor' */
#define may23_IN_CurrentLimited        ((uint8_T)1U)
#define may23_IN_Done_o                ((uint8_T)2U)
#define may23_IN_EpMonitor             ((uint8_T)3U)
#define may23_IN_Err                   ((uint8_T)2U)
#define may23_IN_ErrorFound            ((uint8_T)4U)
#define may23_IN_ExoMonitor            ((uint8_T)5U)
#define may23_IN_Monitoring            ((uint8_T)6U)
#define may23_IN_Pause                 ((uint8_T)3U)
#define may23_IN_Wait_e                ((uint8_T)7U)
#define may23_IN_Waiting_n             ((uint8_T)4U)
#define may23_IN_eStopdown             ((uint8_T)8U)
#define may23_IN_init_h                ((uint8_T)9U)
#define may23_IN_not_holding           ((uint8_T)5U)
#define may23_event_e_clk_p            (0)

/* Named constants for Chart: '<S336>/Task Execution Control Machine' */
#define may23_IN_Finished              ((uint8_T)1U)
#define may23_IN_Finished1             ((uint8_T)2U)
#define may23_IN_InTrial               ((uint8_T)3U)
#define may23_IN_InTrial1              ((uint8_T)4U)
#define may23_IN_Paused                ((uint8_T)1U)
#define may23_IN_Paused1               ((uint8_T)1U)
#define may23_IN_PausedBetweenBlocks   ((uint8_T)5U)
#define may23_IN_PausedBetweenTrials   ((uint8_T)6U)
#define may23_IN_PausedBetweenTrials1  ((uint8_T)7U)
#define may23_IN_Ready                 ((uint8_T)8U)
#define may23_IN_RepeatTrialLater      ((uint8_T)2U)
#define may23_IN_RepeatTrialLater1     ((uint8_T)2U)
#define may23_IN_RepeatTrialNow        ((uint8_T)3U)
#define may23_IN_RepeatTrialNow1       ((uint8_T)3U)
#define may23_IN_Running               ((uint8_T)4U)
#define may23_IN_Running1              ((uint8_T)4U)
#define may23_IN_SkipTrial             ((uint8_T)5U)
#define may23_IN_SkipTrial1            ((uint8_T)5U)
#define may23_event_e_trial_over       (1)

/* Named constants for Chart: '<S396>/Ramp_up_down' */
#define may23_IN_Perturbation          ((uint8_T)1U)
#define may23_IN_off_ramp              ((uint8_T)1U)
#define may23_IN_on_ramp               ((uint8_T)2U)
#define may23_IN_peak                  ((uint8_T)3U)
#define may23_IN_wait_for_trigger      ((uint8_T)2U)
#define may23_event_e_reset            (2)
#define may23_event_e_trigger          (1)

/* Named constants for Chart: '<Root>/Trial_Control' */
#define may23_IN_Fail                  ((uint8_T)1U)
#define may23_IN_Initialize            ((uint8_T)1U)
#define may23_IN_Inter_Trial_State     ((uint8_T)2U)
#define may23_IN_Main_Trial            ((uint8_T)3U)
#define may23_IN_PreshotMove           ((uint8_T)2U)
#define may23_IN_PreshotStart          ((uint8_T)3U)
#define may23_IN_PuckMoving            ((uint8_T)4U)
#define may23_IN_Shot                  ((uint8_T)5U)
#define may23_IN_ShotEnd               ((uint8_T)6U)
#define may23_IN_ShotReady             ((uint8_T)7U)
#define may23_IN_ShotSet               ((uint8_T)8U)
#define may23_IN_StartHold             ((uint8_T)9U)
#define may23_IN_StartOn               ((uint8_T)10U)
#define may23_IN_Success               ((uint8_T)11U)
#define may23_event_e_ExitTrialNow     (1)
#define may23_event_e_Puck_Hit         (3)
#define may23_event_e_Puck_Stopped     (2)

/* Named constants for Chart: '<S21>/Collision Resolution' */
#define may23_IN_Moving_Targets_and_Colliding_Them ((uint8_T)2U)
#define may23_IN_PuckMoving_b          ((uint8_T)1U)
#define may23_IN_PuckStopped           ((uint8_T)2U)
#define may23_IN_ResolveTargetCollision ((uint8_T)3U)
#define may23_IN_StartWithSpeed0       ((uint8_T)4U)
#define may23_IN_WaitForCollision      ((uint8_T)5U)
#define may23_event_e_Trial_Start      (1)

real_T col_x;
real_T col_y;
real_T SECONDS;
real_T E_NO_EVENT;
real_T WIDTH;
real_T HEIGHT;
real_T ROTATION;
real_T FORCE_MULTIPLIER;
real_T LOAD_ROW;
real_T F_BUMP;
real_T MASS_CIRCLE;
real_T MASS_RECT;
real_T PERT_RAMP;
real_T PERT_DUR;
real_T START_ROW;
real_T GOAL_ROW;
real_T RADIUS_LOG;
real_T RADIUS_VIS;
real_T BARRIER_ROW;
real_T PRESHOT_ROW;
real_T START_HOLD_TIME;
real_T SHOT_READY_TIME;
real_T SHOT_SET_TIME;
real_T GOAL_TIME;
real_T FIRST_FILL;
real_T SECOND_FILL;
real_T THIRD_FILL;
real_T PUCK_ROW;
real_T CURSOR_ROW;
real_T E_START_TARGET_ON;
real_T E_ENTER_START;
real_T E_TRIAL_START;
real_T E_BEGIN_PRESHOT;
real_T E_SHOT_READY;
real_T E_SHOT_GO;
real_T E_PUCK_IN_GOAL;
real_T E_HAND_IN_BARRIER;
real_T E_PUCK_IN_BARRIER;
real_T E_SUCCESS;
real_T E_FAILURE;
real_T E_TIMEOUT;
real_T STROKE_COLOR;
real_T STROKE_WIDTH;
real_T PUCK_DAMPING;
real_T E_PUCK_MISS;
real_T SHOT_TIME;
const KinDataStruct may23_rtZKinDataStruct = {
  {
    0.0,                               /* active_arm */

    {
      0.0, 0.0, 0.0, 0.0 }
    ,                                  /* delay_estimates */
    0.0,                               /* servo_counter */
    0.0,                               /* calibration_button_bits */
    0.0,                               /* robot_arm */
    0.0                                /* subject_arm */
  },                                   /* general */

  {
    0.0,                               /* feed_forward */
    0.0,                               /* dex_feed_forward */
    0.0,                               /* arm */
    0.0,                               /* rad */
    0.0,                               /* control */
    0.0                                /* color */
  },                                   /* hand_feedback */

  {
    0.0,                               /* has_gaze */
    0.0,                               /* feedback_control */

    {
      0.0, 0.0 }
    ,                                  /* location */
    0.0,                               /* timestamp */
    0.0,                               /* pupil_area */

    {
      0.0, 0.0, 0.0 }
    ,                                  /* event */

    {
      0.0, 0.0, 0.0 }
    ,                                  /* gaze_vector */

    {
      0.0, 0.0, 0.0 }
    /* pupil_locatoin */
  },                                   /* gaze */

  {
    {
      0.0, 0.0 }
    ,                                  /* link_lengths */
    0.0,                               /* pointer_offset */

    {
      0.0, 0.0 }
    ,                                  /* shoulder_position */
    0.0,                               /* arm_orientation */
    0.0,                               /* shoulder_angle */
    0.0,                               /* elbow_angle */
    0.0,                               /* shoulder_ang_velocity */
    0.0,                               /* elbow_ang_velocity */
    0.0,                               /* shoulder_ang_acceleration */
    0.0,                               /* elbow_ang_acceleration */

    {
      0.0, 0.0 }
    ,                                  /* joint_torque_command */

    {
      0.0, 0.0 }
    ,                                  /* motor_torque_command */

    {
      0.0, 0.0 }
    ,                                  /* link_angles */

    {
      0.0, 0.0 }
    ,                                  /* link_angle_velocities */

    {
      0.0, 0.0 }
    ,                                  /* link_angle_accelerations */

    {
      0.0, 0.0 }
    ,                                  /* hand_position */

    {
      0.0, 0.0 }
    ,                                  /* hand_velocities */

    {
      0.0, 0.0 }
    ,                                  /* hand_accelerations */

    {
      0.0, 0.0 }
    ,                                  /* elbow_position */

    {
      0.0, 0.0 }
    ,                                  /* elbow_cart_velocity */

    {
      0.0, 0.0 }
    ,                                  /* elbow_cart_acceleration */
    0.0,                               /* motor_status */

    {
      0.0, 0.0, 0.0 }
    ,                                  /* fs_force_uvw */

    {
      0.0, 0.0, 0.0 }
    ,                                  /* fs_torque_uvw */

    {
      0.0, 0.0, 0.0 }
    ,                                  /* fs_force_xyz */

    {
      0.0, 0.0, 0.0 }
    ,                                  /* fs_torque_xyz */
    0.0,                               /* fs_timestamp */
    0U,                                /* fs_status */

    {
      0.0, 0.0 }
    ,                                  /* ecat_recorded_torques */

    {
      0.0, 0.0 }
    ,                                  /* ecat_current_limit_enabled */
    0.0                                /* ep_grip_sensor */
  },                                   /* robot1 */

  {
    {
      0.0, 0.0 }
    ,                                  /* link_lengths */
    0.0,                               /* pointer_offset */

    {
      0.0, 0.0 }
    ,                                  /* shoulder_position */
    0.0,                               /* arm_orientation */
    0.0,                               /* shoulder_angle */
    0.0,                               /* elbow_angle */
    0.0,                               /* shoulder_ang_velocity */
    0.0,                               /* elbow_ang_velocity */
    0.0,                               /* shoulder_ang_acceleration */
    0.0,                               /* elbow_ang_acceleration */

    {
      0.0, 0.0 }
    ,                                  /* joint_torque_command */

    {
      0.0, 0.0 }
    ,                                  /* motor_torque_command */

    {
      0.0, 0.0 }
    ,                                  /* link_angles */

    {
      0.0, 0.0 }
    ,                                  /* link_angle_velocities */

    {
      0.0, 0.0 }
    ,                                  /* link_angle_accelerations */

    {
      0.0, 0.0 }
    ,                                  /* hand_position */

    {
      0.0, 0.0 }
    ,                                  /* hand_velocities */

    {
      0.0, 0.0 }
    ,                                  /* hand_accelerations */

    {
      0.0, 0.0 }
    ,                                  /* elbow_position */

    {
      0.0, 0.0 }
    ,                                  /* elbow_cart_velocity */

    {
      0.0, 0.0 }
    ,                                  /* elbow_cart_acceleration */
    0.0,                               /* motor_status */

    {
      0.0, 0.0, 0.0 }
    ,                                  /* fs_force_uvw */

    {
      0.0, 0.0, 0.0 }
    ,                                  /* fs_torque_uvw */

    {
      0.0, 0.0, 0.0 }
    ,                                  /* fs_force_xyz */

    {
      0.0, 0.0, 0.0 }
    ,                                  /* fs_torque_xyz */
    0.0,                               /* fs_timestamp */
    0U,                                /* fs_status */

    {
      0.0, 0.0 }
    ,                                  /* ecat_recorded_torques */

    {
      0.0, 0.0 }
    ,                                  /* ecat_current_limit_enabled */
    0.0                                /* ep_grip_sensor */
  },                                   /* robot2 */

  {
    0U, 0U, 0U, 0U, 0U, 0U, 0U, 0U }
  /* ecat_digital_input */
} ;                                    /* KinDataStruct ground */

/* Block signals (default storage) */
B_may23_T may23_B;

/* Block states (default storage) */
DW_may23_T may23_DW;

/* Previous zero-crossings (trigger) states */
PrevZCX_may23_T may23_PrevZCX;

/* Real-time model */
RT_MODEL_may23_T may23_M_;
RT_MODEL_may23_T *const may23_M = &may23_M_;

/* Forward declaration for local functions */
static uint32_T may23_colourshift(real_T RRRGGGBBB);
static real_T may23_mod(real_T x);

/* Forward declaration for local functions */
static uint32_T may23_colourshift_n(real_T RRRGGGBBB);
static real_T may23_mod_o(real_T x);

/* Forward declaration for local functions */
static void may23_InTrial(void);
static void may23_chartstep_c42_General(void);
static void may23_Success(void);
static void may23_Main_Trial(void);
static void may23_chartstep_c3_may23(void);
static real_T may23_sum(const real_T x[50]);
static real_T may23_check_collision(const real_T cursor_vcode[140], const real_T
  puck_vcode[70], const real_T puck_offset[2]);
static void may23_eject(const real_T cursor_vcode[70], const real_T puck_vcode
  [70], const real_T puck_offset[2], real_T ejected_puck_offset[2]);
static real_T may23_check_collision_g(const real_T cursor_vcode[70], const
  real_T puck_vcode[70], const real_T puck_offset[2]);
static void may23_chartstep_c1_may23(void);
static void may23_chartstep_c8_may23(void);
static void rate_monotonic_scheduler(void);
time_T rt_SimUpdateDiscreteEvents(
  int_T rtmNumSampTimes, void *rtmTimingData, int_T *rtmSampleHitPtr, int_T
  *rtmPerTaskSampleHits )
{
  rtmSampleHitPtr[1] = rtmStepTask(may23_M, 1);
  rtmSampleHitPtr[2] = rtmStepTask(may23_M, 2);
  rtmSampleHitPtr[3] = rtmStepTask(may23_M, 3);
  rtmSampleHitPtr[4] = rtmStepTask(may23_M, 4);
  UNUSED_PARAMETER(rtmNumSampTimes);
  UNUSED_PARAMETER(rtmTimingData);
  UNUSED_PARAMETER(rtmPerTaskSampleHits);
  return(-1);
}

/*
 *   This function updates active task flag for each subrate
 * and rate transition flags for tasks that exchange data.
 * The function assumes rate-monotonic multitasking scheduler.
 * The function must be called at model base rate so that
 * the generated code self-manages all its subrates and rate
 * transition flags.
 */
static void rate_monotonic_scheduler(void)
{
  /* To ensure a deterministic data transfer between two rates,
   * data is transferred at the priority of a fast task and the frequency
   * of the slow task.  The following flags indicate when the data transfer
   * happens.  That is, a rate interaction flag is set true when both rates
   * will run, and false otherwise.
   */

  /* tid 1 shares data with slower tid rates: 2, 3 */
  if (may23_M->Timing.TaskCounters.TID[1] == 0) {
    may23_M->Timing.RateInteraction.TID1_2 = (may23_M->Timing.TaskCounters.TID[2]
      == 0);

    /* update PerTaskSampleHits matrix for non-inline sfcn */
    may23_M->Timing.perTaskSampleHits[7] =
      may23_M->Timing.RateInteraction.TID1_2;
    may23_M->Timing.RateInteraction.TID1_3 = (may23_M->Timing.TaskCounters.TID[3]
      == 0);

    /* update PerTaskSampleHits matrix for non-inline sfcn */
    may23_M->Timing.perTaskSampleHits[8] =
      may23_M->Timing.RateInteraction.TID1_3;
  }

  /* tid 2 shares data with slower tid rate: 3 */
  if (may23_M->Timing.TaskCounters.TID[2] == 0) {
    may23_M->Timing.RateInteraction.TID2_3 = (may23_M->Timing.TaskCounters.TID[3]
      == 0);

    /* update PerTaskSampleHits matrix for non-inline sfcn */
    may23_M->Timing.perTaskSampleHits[13] =
      may23_M->Timing.RateInteraction.TID2_3;
  }

  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (may23_M->Timing.TaskCounters.TID[2])++;
  if ((may23_M->Timing.TaskCounters.TID[2]) > 1) {/* Sample time: [0.0005s, 0.0s] */
    may23_M->Timing.TaskCounters.TID[2] = 0;
  }

  (may23_M->Timing.TaskCounters.TID[3])++;
  if ((may23_M->Timing.TaskCounters.TID[3]) > 3) {/* Sample time: [0.001s, 0.0s] */
    may23_M->Timing.TaskCounters.TID[3] = 0;
  }

  (may23_M->Timing.TaskCounters.TID[4])++;
  if ((may23_M->Timing.TaskCounters.TID[4]) > 399) {/* Sample time: [0.1s, 0.0s] */
    may23_M->Timing.TaskCounters.TID[4] = 0;
  }
}

/*
 * Output and update for atomic system:
 *    '<S321>/MATLAB Function'
 *    '<S321>/MATLAB Function1'
 */
void may23_MATLABFunction_a(real_T rtu_orientation, real_T rtu_has_secondary,
  real_T rtu_isEP, B_MATLABFunction_may23_bc_T *localB)
{
  int32_T isExo;

  /* MATLAB Function 'DataLogging/create_lab_info/Subsystem/MATLAB Function': '<S322>:1' */
  /* '<S322>:1:4' */
  isExo = 1;
  if (rtu_isEP != 0.0) {
    /* '<S322>:1:6' */
    isExo = 0;
  }

  /* '<S322>:1:9' */
  localB->has_high_res_encoders = rtu_has_secondary;

  /* '<S322>:1:11' */
  localB->is_right_arm = 0.0;
  if (((isExo != 0) && (rtu_orientation == 1.0)) || ((rtu_isEP != 0.0) &&
       (rtu_orientation == -1.0))) {
    /* '<S322>:1:12' */
    /* '<S322>:1:13' */
    localB->is_right_arm = 1.0;
  }

  localB->isExo = isExo;
}

real_T rt_powd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T tmp;
  real_T tmp_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else {
    tmp = fabs(u0);
    tmp_0 = fabs(u1);
    if (rtIsInf(u1)) {
      if (tmp == 1.0) {
        y = 1.0;
      } else if (tmp > 1.0) {
        if (u1 > 0.0) {
          y = (rtInf);
        } else {
          y = 0.0;
        }
      } else if (u1 > 0.0) {
        y = 0.0;
      } else {
        y = (rtInf);
      }
    } else if (tmp_0 == 0.0) {
      y = 1.0;
    } else if (tmp_0 == 1.0) {
      if (u1 > 0.0) {
        y = u0;
      } else {
        y = 1.0 / u0;
      }
    } else if (u1 == 2.0) {
      y = u0 * u0;
    } else if ((u1 == 0.5) && (u0 >= 0.0)) {
      y = sqrt(u0);
    } else if ((u0 < 0.0) && (u1 > floor(u1))) {
      y = (rtNaN);
    } else {
      y = pow(u0, u1);
    }
  }

  return y;
}

/*
 * System initialize for trigger system:
 *    '<S4>/Ramp_Up_Down'
 *    '<S4>/Ramp_Up_Down1'
 */
void may23_Ramp_Up_Down_Init(B_Ramp_Up_Down_may23_T *localB,
  DW_Ramp_Up_Down_may23_T *localDW)
{
  localDW->is_Ramp_Down_Main = may23_IN_NO_ACTIVE_CHILD_hg;
  localDW->is_Ramp_Up_Main = may23_IN_NO_ACTIVE_CHILD_hg;
  localDW->temporalCounter_i1 = 0U;
  localDW->is_active_c20_KINARM_EP_loads = 0U;
  localDW->is_c20_KINARM_EP_loads = may23_IN_NO_ACTIVE_CHILD_hg;
  localDW->tick = 0.0;
  localDW->halfUpTicks = 0.0;
  localDW->halfDownTicks = 0.0;
  localB->scaling = 0.0;
}

/*
 * Output and update for trigger system:
 *    '<S4>/Ramp_Up_Down'
 *    '<S4>/Ramp_Up_Down1'
 */
void may23_Ramp_Up_Down(real_T rtu_e_clk, boolean_T rtu_motors_enabled, real_T
  rtu_Run_Status, real_T rtu_up_duration, real_T rtu_down_duration, boolean_T
  rtu_is_ep, B_Ramp_Up_Down_may23_T *localB, DW_Ramp_Up_Down_may23_T *localDW,
  ZCE_Ramp_Up_Down_may23_T *localZCE)
{
  ZCEventType zcEvent;

  /* Chart: '<S4>/Ramp_Up_Down' incorporates:
   *  TriggerPort: '<S356>/e_clk'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Ramp_Up_Down_Trig_ZCE_e,
                     (rtu_e_clk));
  if (zcEvent != NO_ZCEVENT) {
    localB->e_clk = (int8_T)zcEvent;

    /* Gateway: KINARM_EP_Apply_Loads/Ramp_Up_Down */
    if (localDW->temporalCounter_i1 < MAX_uint32_T) {
      localDW->temporalCounter_i1++;
    }

    /* Event: '<S356>:30' */
    localDW->sfEvent = may23_event_e_clk;

    /* During: KINARM_EP_Apply_Loads/Ramp_Up_Down */
    if (localDW->is_active_c20_KINARM_EP_loads == 0U) {
      /* Entry: KINARM_EP_Apply_Loads/Ramp_Up_Down */
      localDW->is_active_c20_KINARM_EP_loads = 1U;

      /* Entry Internal: KINARM_EP_Apply_Loads/Ramp_Up_Down */
      /* Transition: '<S356>:8' */
      localDW->is_c20_KINARM_EP_loads = may23_IN_Init;

      /* Entry 'Init': '<S356>:39' */
      localB->scaling = 0.0;
      localDW->halfUpTicks = rtu_up_duration / 2.0;
      localDW->halfDownTicks = rtu_down_duration / 2.0;
    } else {
      switch (localDW->is_c20_KINARM_EP_loads) {
       case may23_IN_Init:
        /* During 'Init': '<S356>:39' */
        /* Transition: '<S356>:40' */
        if (rtu_is_ep) {
          /* Transition: '<S356>:33' */
          localDW->is_c20_KINARM_EP_loads = may23_IN_Ramp_Down_Main;
          localDW->is_Ramp_Down_Main = may23_IN_Wait_for_Go;

          /* Entry 'Wait_for_Go': '<S356>:1' */
          localB->scaling = 0.0;
        } else {
          /* Transition: '<S356>:34' */
          localDW->is_c20_KINARM_EP_loads = may23_IN_NotEP;

          /* Entry 'NotEP': '<S356>:31' */
          localB->scaling = 0.0;
        }
        break;

       case may23_IN_NotEP:
        /* During 'NotEP': '<S356>:31' */
        break;

       case may23_IN_Ramp_Down_Main:
        /* During 'Ramp_Down_Main': '<S356>:36' */
        switch (localDW->is_Ramp_Down_Main) {
         case may23_IN_Ramp_Down:
          /* During 'Ramp_Down': '<S356>:4' */
          if ((localDW->sfEvent == may23_event_e_clk) &&
              (localDW->temporalCounter_i1 >= (uint32_T)localDW->halfDownTicks))
          {
            /* Transition: '<S356>:18' */
            localDW->is_Ramp_Down_Main = may23_IN_Ramp_Down2;
            localDW->temporalCounter_i1 = 0U;
          } else {
            if (localDW->sfEvent == may23_event_e_clk) {
              localDW->tick++;
              localB->scaling = 1.0 - rt_powd_snf(localDW->tick /
                rtu_down_duration, 2.0) * 2.0;
            }
          }
          break;

         case may23_IN_Ramp_Down2:
          /* During 'Ramp_Down2': '<S356>:6' */
          if ((localDW->sfEvent == may23_event_e_clk) &&
              (localDW->temporalCounter_i1 >= (uint32_T)localDW->halfDownTicks))
          {
            /* Transition: '<S356>:12' */
            localDW->is_Ramp_Down_Main = may23_IN_Wait_for_Go;

            /* Entry 'Wait_for_Go': '<S356>:1' */
            localB->scaling = 0.0;
          } else {
            if (localDW->sfEvent == may23_event_e_clk) {
              localDW->tick++;
              localB->scaling = rt_powd_snf(fabs(localDW->tick /
                rtu_down_duration - 0.5) - 0.5, 2.0) * 2.0;
            }
          }
          break;

         default:
          /* During 'Wait_for_Go': '<S356>:1' */
          if ((rtu_Run_Status > 0.0) && rtu_motors_enabled) {
            /* Transition: '<S356>:9' */
            localDW->is_Ramp_Down_Main = may23_IN_NO_ACTIVE_CHILD_hg;
            localDW->is_c20_KINARM_EP_loads = may23_IN_Ramp_Up_Main;

            /* Entry Internal 'Ramp_Up_Main': '<S356>:7' */
            /* Transition: '<S356>:38' */
            if (rtu_up_duration > 0.0) {
              /* Transition: '<S356>:13' */
              localDW->is_Ramp_Up_Main = may23_IN_Ramp_Up;
              localDW->temporalCounter_i1 = 0U;

              /* Entry 'Ramp_Up': '<S356>:3' */
              localDW->tick = 0.0;
            } else {
              /* Transition: '<S356>:14' */
              localDW->is_Ramp_Up_Main = may23_IN_Ramp_Up_Done;

              /* Entry 'Ramp_Up_Done': '<S356>:2' */
              localB->scaling = 1.0;
            }
          }
          break;
        }
        break;

       default:
        /* During 'Ramp_Up_Main': '<S356>:7' */
        if (!rtu_motors_enabled) {
          /* Transition: '<S356>:19' */
          /* Exit Internal 'Ramp_Up_Main': '<S356>:7' */
          localDW->is_Ramp_Up_Main = may23_IN_NO_ACTIVE_CHILD_hg;
          localDW->is_c20_KINARM_EP_loads = may23_IN_Ramp_Down_Main;
          localDW->is_Ramp_Down_Main = may23_IN_Wait_for_Go;

          /* Entry 'Wait_for_Go': '<S356>:1' */
          localB->scaling = 0.0;
        } else {
          switch (localDW->is_Ramp_Up_Main) {
           case may23_IN_Ramp_Up:
            /* During 'Ramp_Up': '<S356>:3' */
            if ((localDW->sfEvent == may23_event_e_clk) &&
                (localDW->temporalCounter_i1 >= (uint32_T)localDW->halfUpTicks))
            {
              /* Transition: '<S356>:17' */
              localDW->is_Ramp_Up_Main = may23_IN_Ramp_Up2;
              localDW->temporalCounter_i1 = 0U;
            } else {
              if (localDW->sfEvent == may23_event_e_clk) {
                localDW->tick++;
                localB->scaling = rt_powd_snf(localDW->tick / rtu_up_duration,
                  2.0) * 2.0;
              }
            }
            break;

           case may23_IN_Ramp_Up2:
            /* During 'Ramp_Up2': '<S356>:5' */
            if ((localDW->sfEvent == may23_event_e_clk) &&
                (localDW->temporalCounter_i1 >= (uint32_T)localDW->halfUpTicks))
            {
              /* Transition: '<S356>:11' */
              localDW->is_Ramp_Up_Main = may23_IN_Ramp_Up_Done;

              /* Entry 'Ramp_Up_Done': '<S356>:2' */
              localB->scaling = 1.0;
            } else {
              if (localDW->sfEvent == may23_event_e_clk) {
                localDW->tick++;
                localB->scaling = 1.0 - rt_powd_snf(fabs(localDW->tick /
                  rtu_up_duration - 0.5) - 0.5, 2.0) * 2.0;
              }
            }
            break;

           default:
            /* During 'Ramp_Up_Done': '<S356>:2' */
            if (rtu_Run_Status == 0.0) {
              /* Transition: '<S356>:10' */
              if (rtu_down_duration > 0.0) {
                /* Transition: '<S356>:15' */
                localDW->is_Ramp_Up_Main = may23_IN_NO_ACTIVE_CHILD_hg;
                localDW->is_c20_KINARM_EP_loads = may23_IN_Ramp_Down_Main;
                localDW->is_Ramp_Down_Main = may23_IN_Ramp_Down;
                localDW->temporalCounter_i1 = 0U;

                /* Entry 'Ramp_Down': '<S356>:4' */
                localDW->tick = 0.0;
              } else {
                /* Transition: '<S356>:16' */
                localDW->is_Ramp_Up_Main = may23_IN_NO_ACTIVE_CHILD_hg;
                localDW->is_c20_KINARM_EP_loads = may23_IN_Ramp_Down_Main;
                localDW->is_Ramp_Down_Main = may23_IN_Wait_for_Go;

                /* Entry 'Wait_for_Go': '<S356>:1' */
                localB->scaling = 0.0;
              }
            }
            break;
          }
        }
        break;
      }
    }

    localDW->Ramp_Up_Down_SubsysRanBC = 4;
  }
}

/*
 * Output and update for atomic system:
 *    '<S4>/Remove_NaNs_and_Inf'
 *    '<S5>/Remove_NaNs_and_Inf'
 */
void may23_Remove_NaNs_and_Inf(const real_T rtu_in[2], const real_T rtu_in_p[2],
  B_Remove_NaNs_and_Inf_may23_T *localB)
{
  /* SignalConversion generated from: '<S358>/ SFunction ' */
  localB->TmpSignalConversionAtSFunctionInport1[0] = rtu_in[0];
  localB->TmpSignalConversionAtSFunctionInport1[2] = rtu_in_p[0];
  localB->TmpSignalConversionAtSFunctionInport1[1] = rtu_in[1];
  localB->TmpSignalConversionAtSFunctionInport1[3] = rtu_in_p[1];

  /* MATLAB Function 'KINARM_EP_Apply_Loads/Remove_NaNs_and_Inf': '<S358>:1' */
  /* '<S358>:1:5' */
  localB->out[0] = 0.0;
  localB->out[1] = 0.0;
  localB->out[2] = 0.0;
  localB->out[3] = 0.0;

  /* '<S358>:1:7' */
  if ((!rtIsInf(localB->TmpSignalConversionAtSFunctionInport1[0])) && (!rtIsNaN
       (localB->TmpSignalConversionAtSFunctionInport1[0]))) {
    /* '<S358>:1:8' */
    /* '<S358>:1:9' */
    localB->out[0] = localB->TmpSignalConversionAtSFunctionInport1[0];
  }

  /* '<S358>:1:7' */
  if ((!rtIsInf(localB->TmpSignalConversionAtSFunctionInport1[1])) && (!rtIsNaN
       (localB->TmpSignalConversionAtSFunctionInport1[1]))) {
    /* '<S358>:1:8' */
    /* '<S358>:1:9' */
    localB->out[1] = localB->TmpSignalConversionAtSFunctionInport1[1];
  }

  /* '<S358>:1:7' */
  if ((!rtIsInf(localB->TmpSignalConversionAtSFunctionInport1[2])) && (!rtIsNaN
       (localB->TmpSignalConversionAtSFunctionInport1[2]))) {
    /* '<S358>:1:8' */
    /* '<S358>:1:9' */
    localB->out[2] = localB->TmpSignalConversionAtSFunctionInport1[2];
  }

  /* '<S358>:1:7' */
  if ((!rtIsInf(localB->TmpSignalConversionAtSFunctionInport1[3])) && (!rtIsNaN
       (localB->TmpSignalConversionAtSFunctionInport1[3]))) {
    /* '<S358>:1:8' */
    /* '<S358>:1:9' */
    localB->out[3] = localB->TmpSignalConversionAtSFunctionInport1[3];
  }
}

/*
 * Output and update for atomic system:
 *    '<S360>/MATLAB Function'
 *    '<S361>/MATLAB Function'
 */
void may23_MATLABFunction_br(real_T rtu_motor_status, real_T rtu_grip_sensor,
  real_T rtu_is_ecat, B_MATLABFunction_may23_f_T *localB)
{
  boolean_T motors_enabled;

  /* MATLAB Function 'KINARM_EP_Apply_Loads/detect motor state/MATLAB Function': '<S362>:1' */
  if ((rtu_motor_status == 0.0) && ((!(rtu_is_ecat != 0.0)) || (rtu_grip_sensor ==
        1.0))) {
    /* '<S362>:1:4' */
    motors_enabled = true;
  } else {
    motors_enabled = false;
  }

  /* '<S362>:1:4' */
  localB->motors_enabled = motors_enabled;
}

/*
 * System initialize for trigger system:
 *    '<S5>/Ramp_Up_Down'
 *    '<S5>/Ramp_Up_Down1'
 */
void may23_Ramp_Up_Down_l_Init(B_Ramp_Up_Down_may23_g_T *localB,
  DW_Ramp_Up_Down_may23_o_T *localDW)
{
  localDW->is_Ramp_Up_Main = may23_IN_NO_ACTIVE_CHILD_fp;
  localDW->temporalCounter_i1 = 0U;
  localDW->is_active_c39_KINARM_loads = 0U;
  localDW->is_c39_KINARM_loads = may23_IN_NO_ACTIVE_CHILD_fp;
  localDW->tick = 0.0;
  localDW->tickCount = 0.0;
  localB->scaling = 0.0;
}

/*
 * Output and update for trigger system:
 *    '<S5>/Ramp_Up_Down'
 *    '<S5>/Ramp_Up_Down1'
 */
void may23_Ramp_Up_Down_g(real_T rtu_e_clk, real_T rtu_Motors_Disabled, real_T
  rtu_Run_Status, real_T rtu_up_duration, real_T rtu_down_duration, real_T
  rtu_robot_type, B_Ramp_Up_Down_may23_g_T *localB, DW_Ramp_Up_Down_may23_o_T
  *localDW, ZCE_Ramp_Up_Down_may23_m_T *localZCE)
{
  ZCEventType zcEvent;

  /* Chart: '<S5>/Ramp_Up_Down' incorporates:
   *  TriggerPort: '<S364>/e_clk'
   */
  zcEvent = rt_ZCFcn(RISING_ZERO_CROSSING,&localZCE->Ramp_Up_Down_Trig_ZCE,
                     (rtu_e_clk));
  if (zcEvent != NO_ZCEVENT) {
    localB->e_clk = (int8_T)zcEvent;

    /* Gateway: KINARM_Exo_Apply_Loads/Ramp_Up_Down */
    if (localDW->temporalCounter_i1 < MAX_uint32_T) {
      localDW->temporalCounter_i1++;
    }

    /* Event: '<S364>:30' */
    localDW->sfEvent = may23_event_e_clk_a;

    /* During: KINARM_Exo_Apply_Loads/Ramp_Up_Down */
    if (localDW->is_active_c39_KINARM_loads == 0U) {
      /* Entry: KINARM_Exo_Apply_Loads/Ramp_Up_Down */
      localDW->is_active_c39_KINARM_loads = 1U;

      /* Entry Internal: KINARM_Exo_Apply_Loads/Ramp_Up_Down */
      /* Transition: '<S364>:8' */
      localDW->is_c39_KINARM_loads = may23_IN_Wait_for_Go_g;

      /* Entry 'Wait_for_Go': '<S364>:1' */
      localB->scaling = 0.0;
    } else {
      switch (localDW->is_c39_KINARM_loads) {
       case may23_IN_Ramp_Down_c:
        /* During 'Ramp_Down': '<S364>:4' */
        if ((localDW->sfEvent == may23_event_e_clk_a) &&
            (localDW->temporalCounter_i1 >= (uint32_T)localDW->tickCount)) {
          /* Transition: '<S364>:18' */
          localDW->is_c39_KINARM_loads = may23_IN_Ramp_Down2_o;
          localDW->temporalCounter_i1 = 0U;
        } else {
          if (localDW->sfEvent == may23_event_e_clk_a) {
            localDW->tick++;
            localB->scaling = 1.0 - rt_powd_snf(localDW->tick /
              rtu_down_duration, 2.0) * 2.0;
          }
        }
        break;

       case may23_IN_Ramp_Down2_o:
        /* During 'Ramp_Down2': '<S364>:6' */
        if ((localDW->sfEvent == may23_event_e_clk_a) &&
            (localDW->temporalCounter_i1 >= (uint32_T)(rtu_down_duration -
              localDW->tickCount))) {
          /* Transition: '<S364>:12' */
          localDW->is_c39_KINARM_loads = may23_IN_Wait_for_Go_g;

          /* Entry 'Wait_for_Go': '<S364>:1' */
          localB->scaling = 0.0;
        } else {
          if (localDW->sfEvent == may23_event_e_clk_a) {
            localDW->tick++;
            localB->scaling = rt_powd_snf(fabs(localDW->tick / rtu_down_duration
              - 0.5) - 0.5, 2.0) * 2.0;
          }
        }
        break;

       case may23_IN_Ramp_Up_Main_h:
        /* During 'Ramp_Up_Main': '<S364>:7' */
        if (rtu_Motors_Disabled > 0.0) {
          /* Transition: '<S364>:19' */
          /* Exit Internal 'Ramp_Up_Main': '<S364>:7' */
          localDW->is_Ramp_Up_Main = may23_IN_NO_ACTIVE_CHILD_fp;
          localDW->is_c39_KINARM_loads = may23_IN_Wait_for_Go_g;

          /* Entry 'Wait_for_Go': '<S364>:1' */
          localB->scaling = 0.0;
        } else {
          switch (localDW->is_Ramp_Up_Main) {
           case may23_IN_Ramp_Up_m:
            /* During 'Ramp_Up': '<S364>:3' */
            if ((localDW->sfEvent == may23_event_e_clk_a) &&
                (localDW->temporalCounter_i1 >= (uint32_T)localDW->tickCount)) {
              /* Transition: '<S364>:17' */
              localDW->is_Ramp_Up_Main = may23_IN_Ramp_Up2_e;
              localDW->temporalCounter_i1 = 0U;
            } else {
              if (localDW->sfEvent == may23_event_e_clk_a) {
                localDW->tick++;
                localB->scaling = rt_powd_snf(localDW->tick / rtu_up_duration,
                  2.0) * 2.0;
              }
            }
            break;

           case may23_IN_Ramp_Up2_e:
            /* During 'Ramp_Up2': '<S364>:5' */
            if ((localDW->sfEvent == may23_event_e_clk_a) &&
                (localDW->temporalCounter_i1 >= (uint32_T)(rtu_up_duration -
                  localDW->tickCount))) {
              /* Transition: '<S364>:11' */
              localDW->is_Ramp_Up_Main = may23_IN_Ramp_Up_Done_o;

              /* Entry 'Ramp_Up_Done': '<S364>:2' */
              localB->scaling = 1.0;
            } else {
              if (localDW->sfEvent == may23_event_e_clk_a) {
                localDW->tick++;
                localB->scaling = 1.0 - rt_powd_snf(fabs(localDW->tick /
                  rtu_up_duration - 0.5) - 0.5, 2.0) * 2.0;
              }
            }
            break;

           default:
            /* During 'Ramp_Up_Done': '<S364>:2' */
            if (rtu_Run_Status == 0.0) {
              /* Transition: '<S364>:10' */
              if (rtu_down_duration > 0.0) {
                /* Transition: '<S364>:15' */
                localDW->is_Ramp_Up_Main = may23_IN_NO_ACTIVE_CHILD_fp;
                localDW->tickCount = rtu_down_duration / 2.0;
                localDW->is_c39_KINARM_loads = may23_IN_Ramp_Down_c;
                localDW->temporalCounter_i1 = 0U;

                /* Entry 'Ramp_Down': '<S364>:4' */
                localDW->tick = 0.0;
              } else {
                /* Transition: '<S364>:16' */
                localDW->is_Ramp_Up_Main = may23_IN_NO_ACTIVE_CHILD_fp;
                localDW->is_c39_KINARM_loads = may23_IN_Wait_for_Go_g;

                /* Entry 'Wait_for_Go': '<S364>:1' */
                localB->scaling = 0.0;
              }
            }
            break;
          }
        }
        break;

       default:
        /* During 'Wait_for_Go': '<S364>:1' */
        if ((rtu_Run_Status > 0.0) && (rtu_Motors_Disabled == 0.0) &&
            ((rtu_robot_type == 0.0) || (rtu_robot_type == 2.0))) {
          /* Transition: '<S364>:9' */
          if (rtu_up_duration > 0.0) {
            /* Transition: '<S364>:13' */
            localDW->tickCount = rtu_up_duration / 2.0;
            localDW->is_c39_KINARM_loads = may23_IN_Ramp_Up_Main_h;
            localDW->is_Ramp_Up_Main = may23_IN_Ramp_Up_m;
            localDW->temporalCounter_i1 = 0U;

            /* Entry 'Ramp_Up': '<S364>:3' */
            localDW->tick = 0.0;
          } else {
            /* Transition: '<S364>:14' */
            localDW->is_c39_KINARM_loads = may23_IN_Ramp_Up_Main_h;
            localDW->is_Ramp_Up_Main = may23_IN_Ramp_Up_Done_o;

            /* Entry 'Ramp_Up_Done': '<S364>:2' */
            localB->scaling = 1.0;
          }
        }
        break;
      }
    }

    localDW->Ramp_Up_Down_SubsysRanBC = 4;
  }
}

/* Function for MATLAB Function: '<S13>/Embedded MATLAB Function' */
static uint32_T may23_colourshift(real_T RRRGGGBBB)
{
  uint32_T RRGGBBAA;
  int32_T blue;
  uint32_T green;
  real_T r;
  uint32_T q0;
  uint32_T qY;
  uint64_T tmp;
  if (RRRGGGBBB == 1.0E+9) {
    /* '<S389>:1:207' */
    /* '<S389>:1:208' */
    RRGGBBAA = 16777216U;
  } else {
    /* '<S389>:1:212' */
    if (rtIsNaN(RRRGGGBBB) || rtIsInf(RRRGGGBBB)) {
      r = (rtNaN);
    } else if (RRRGGGBBB == 0.0) {
      r = 0.0;
    } else {
      r = fmod(RRRGGGBBB, 1000.0);
      if (r == 0.0) {
        r = 0.0;
      } else {
        if (RRRGGGBBB < 0.0) {
          r += 1000.0;
        }
      }
    }

    r = rt_roundd_snf(r);
    if (r < 4.294967296E+9) {
      if (r >= 0.0) {
        green = (uint32_T)r;
      } else {
        green = 0U;
      }
    } else {
      green = MAX_uint32_T;
    }

    blue = (int32_T)green;

    /* '<S389>:1:213' */
    r = rt_roundd_snf(RRRGGGBBB - (real_T)blue);
    if (r < 4.294967296E+9) {
      if (r >= 0.0) {
        green = (uint32_T)r;
      } else {
        green = 0U;
      }
    } else {
      green = MAX_uint32_T;
    }

    green = (uint32_T)rt_roundd_snf((real_T)(green - green / 1000000U * 1000000U)
      / 1000.0);

    /* '<S389>:1:214' */
    /* '<S389>:1:216' */
    tmp = green * 1000ULL;
    if (tmp > 4294967295ULL) {
      tmp = 4294967295ULL;
    }

    r = rt_roundd_snf(RRRGGGBBB - (real_T)(uint32_T)tmp);
    if (r < 4.294967296E+9) {
      if (r >= 0.0) {
        q0 = (uint32_T)r;
      } else {
        q0 = 0U;
      }
    } else {
      q0 = MAX_uint32_T;
    }

    qY = q0 - blue;
    if (qY > q0) {
      qY = 0U;
    }

    RRGGBBAA = (((uint32_T)rt_roundd_snf((real_T)qY / 1.0E+6) << 16U) + (green <<
      8U)) + blue;
  }

  return RRGGBBAA;
}

/* Function for MATLAB Function: '<S13>/Embedded MATLAB Function' */
static real_T may23_mod(real_T x)
{
  real_T r;
  if (rtIsNaN(x) || rtIsInf(x)) {
    r = (rtNaN);
  } else if (x == 0.0) {
    r = 0.0;
  } else {
    r = fmod(x, 360.0);
    if (r == 0.0) {
      r = 0.0;
    } else {
      if (x < 0.0) {
        r += 360.0;
      }
    }
  }

  return r;
}

/*
 * Output and update for atomic system:
 *    '<S13>/Embedded MATLAB Function'
 *    '<S14>/Embedded MATLAB Function'
 *    '<S16>/Embedded MATLAB Function'
 *    '<S18>/Embedded MATLAB Function'
 */
void may23_EmbeddedMATLABFunction(const real_T rtu_target[25], real_T
  rtu_state_in, real_T rtu_target_type, real_T rtu_opacity_in, real_T
  rtu_target_display, real_T rtu_x_index, real_T rtu_y_index, real_T
  rtu_num_states, const real_T rtu_stateindices[55],
  B_EmbeddedMATLABFunction_may23_T *localB)
{
  real_T opacity;
  real_T stroke_colour_col;
  real_T stroke_width_col;
  int32_T i;

  /* MATLAB Function 'Show_Target/Embedded MATLAB Function': '<S389>:1' */
  /* '<S389>:1:86' */
  /* '<S389>:1:87' */
  if (rtu_opacity_in < 100.0) {
    opacity = rtu_opacity_in;
  } else {
    opacity = 100.0;
  }

  if (!(opacity > 0.0)) {
    opacity = 0.0;
  }

  /* '<S389>:1:89' */
  for (i = 0; i < 70; i++) {
    localB->VCODE[i] = 0.0;
  }

  /* '<S389>:1:92' */
  localB->VCODE[0] = rtu_target_type;

  /* '<S389>:1:95' */
  localB->VCODE[2] = rtu_target[(int32_T)rtu_x_index - 1] * 0.01;

  /* '<S389>:1:96' */
  localB->VCODE[3] = rtu_target[(int32_T)rtu_y_index - 1] * 0.01;
  if ((rtu_state_in <= 0.0) || (rtu_state_in > rtu_num_states)) {
    /* '<S389>:1:101' */
    /* '<S389>:1:102' */
    localB->VCODE[1] = 0.0;
  } else {
    /* '<S389>:1:104' */
    localB->VCODE[1] = rtu_target_display;
  }

  /* '<S389>:1:107' */
  /* '<S389>:1:108' */
  stroke_colour_col = rtu_stateindices[(int32_T)rtu_state_in + 4];

  /* '<S389>:1:109' */
  stroke_width_col = rtu_stateindices[(int32_T)rtu_state_in + 9];
  if (rtu_stateindices[(int32_T)rtu_state_in - 1] == 0.0) {
    /* '<S389>:1:112' */
    /* '<S389>:1:113' */
    localB->VCODE[4] = -2.147483648E+9;
  } else if (rtu_target[(int32_T)rtu_stateindices[(int32_T)rtu_state_in - 1] - 1]
             < 0.0) {
    /* '<S389>:1:114' */
    /* '<S389>:1:115' */
    localB->VCODE[4] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
      rtu_state_in - 1] - 1];
  } else {
    /* '<S389>:1:117' */
    localB->VCODE[4] = may23_colourshift(rtu_target[(int32_T)rtu_stateindices
      [(int32_T)rtu_state_in - 1] - 1]);
  }

  if (stroke_colour_col == 0.0) {
    /* '<S389>:1:121' */
    /* '<S389>:1:122' */
    localB->VCODE[5] = -2.147483648E+9;
  } else if (rtu_target[(int32_T)stroke_colour_col - 1] < 0.0) {
    /* '<S389>:1:123' */
    /* '<S389>:1:124' */
    localB->VCODE[5] = rtu_target[(int32_T)stroke_colour_col - 1];
  } else {
    /* '<S389>:1:126' */
    localB->VCODE[5] = may23_colourshift(rtu_target[(int32_T)stroke_colour_col -
      1]);
  }

  if (stroke_width_col == 0.0) {
    /* '<S389>:1:130' */
    /* '<S389>:1:131' */
    localB->VCODE[6] = 0.0;
  } else if (stroke_width_col < 0.0) {
    /* '<S389>:1:132' */
    /* '<S389>:1:133' */
    localB->VCODE[6] = 0.001;
  } else {
    /* '<S389>:1:135' */
    localB->VCODE[6] = rtu_target[(int32_T)stroke_width_col - 1] * 0.01;
  }

  /* '<S389>:1:139' */
  localB->VCODE[8] = opacity;
  if (rtu_target_type == 1.0) {
    /* '<S389>:1:142' */
    /* '<S389>:1:145' */
    /* '<S389>:1:146' */
    localB->VCODE[9] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
      rtu_state_in + 14] - 1] * 0.01;
  } else if ((rtu_target_type == 2.0) || (rtu_target_type == 3.0)) {
    /* '<S389>:1:148' */
    /* '<S389>:1:151' */
    /* '<S389>:1:152' */
    /* '<S389>:1:153' */
    /* '<S389>:1:155' */
    localB->VCODE[9] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
      rtu_state_in + 14] - 1] * 0.01;

    /* '<S389>:1:156' */
    localB->VCODE[10] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
      rtu_state_in + 19] - 1] * 0.01;
    if (rtu_stateindices[(int32_T)rtu_state_in + 24] == 0.0) {
      /* '<S389>:1:157' */
      /* '<S389>:1:158' */
      localB->VCODE[11] = 0.0;
    } else {
      /* '<S389>:1:160' */
      localB->VCODE[11] = may23_mod(rtu_target[(int32_T)rtu_stateindices
        [(int32_T)rtu_state_in + 24] - 1]) * 3.1415926535897931 / 180.0;
    }
  } else if (rtu_target_type == 4.0) {
    /* '<S389>:1:163' */
    /* '<S389>:1:166' */
    /* '<S389>:1:167' */
    /* '<S389>:1:168' */
    localB->VCODE[9] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
      rtu_state_in + 14] - 1] * 0.01;

    /* '<S389>:1:169' */
    localB->VCODE[10] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
      rtu_state_in + 19] - 1] * 0.01;
  } else {
    if (rtu_target_type == 5.0) {
      /* '<S389>:1:171' */
      /* '<S389>:1:174' */
      /* '<S389>:1:175' */
      /* '<S389>:1:176' */
      /* '<S389>:1:177' */
      /* '<S389>:1:179' */
      localB->VCODE[9] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
        rtu_state_in + 14] - 1] * 0.01;
      if (rtu_stateindices[(int32_T)rtu_state_in + 19] == 0.0) {
        /* '<S389>:1:183' */
        /* '<S389>:1:184' */
        localB->VCODE[10] = 0.8660254037844386 * localB->VCODE[9];
      } else {
        /* '<S389>:1:186' */
        localB->VCODE[10] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
          rtu_state_in + 19] - 1] * 0.01;
      }

      if (rtu_stateindices[(int32_T)rtu_state_in + 24] <= 0.0) {
        /* '<S389>:1:189' */
        /* '<S389>:1:190' */
        localB->VCODE[11] = 0.0;
      } else {
        /* '<S389>:1:192' */
        localB->VCODE[11] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
          rtu_state_in + 24] - 1] * 0.01;
      }

      if (rtu_stateindices[(int32_T)rtu_state_in + 29] == 0.0) {
        /* '<S389>:1:195' */
        /* '<S389>:1:196' */
        localB->VCODE[12] = 0.0;
      } else {
        /* '<S389>:1:198' */
        localB->VCODE[12] = may23_mod(rtu_target[(int32_T)rtu_stateindices
          [(int32_T)rtu_state_in + 29] - 1]) * 3.1415926535897931 / 180.0;
      }
    }
  }
}

/* Function for MATLAB Function: '<S15>/Embedded MATLAB Function' */
static uint32_T may23_colourshift_n(real_T RRRGGGBBB)
{
  uint32_T RRGGBBAA;
  int32_T blue;
  uint32_T green;
  real_T r;
  uint32_T q0;
  uint32_T qY;
  uint64_T tmp;
  if (RRRGGGBBB == 1.0E+9) {
    /* '<S391>:1:207' */
    /* '<S391>:1:208' */
    RRGGBBAA = 16777216U;
  } else {
    /* '<S391>:1:212' */
    if (rtIsNaN(RRRGGGBBB) || rtIsInf(RRRGGGBBB)) {
      r = (rtNaN);
    } else if (RRRGGGBBB == 0.0) {
      r = 0.0;
    } else {
      r = fmod(RRRGGGBBB, 1000.0);
      if (r == 0.0) {
        r = 0.0;
      } else {
        if (RRRGGGBBB < 0.0) {
          r += 1000.0;
        }
      }
    }

    r = rt_roundd_snf(r);
    if (r < 4.294967296E+9) {
      if (r >= 0.0) {
        green = (uint32_T)r;
      } else {
        green = 0U;
      }
    } else {
      green = MAX_uint32_T;
    }

    blue = (int32_T)green;

    /* '<S391>:1:213' */
    r = rt_roundd_snf(RRRGGGBBB - (real_T)blue);
    if (r < 4.294967296E+9) {
      if (r >= 0.0) {
        green = (uint32_T)r;
      } else {
        green = 0U;
      }
    } else {
      green = MAX_uint32_T;
    }

    green = (uint32_T)rt_roundd_snf((real_T)(green - green / 1000000U * 1000000U)
      / 1000.0);

    /* '<S391>:1:214' */
    /* '<S391>:1:216' */
    tmp = green * 1000ULL;
    if (tmp > 4294967295ULL) {
      tmp = 4294967295ULL;
    }

    r = rt_roundd_snf(RRRGGGBBB - (real_T)(uint32_T)tmp);
    if (r < 4.294967296E+9) {
      if (r >= 0.0) {
        q0 = (uint32_T)r;
      } else {
        q0 = 0U;
      }
    } else {
      q0 = MAX_uint32_T;
    }

    qY = q0 - blue;
    if (qY > q0) {
      qY = 0U;
    }

    RRGGBBAA = (((uint32_T)rt_roundd_snf((real_T)qY / 1.0E+6) << 16U) + (green <<
      8U)) + blue;
  }

  return RRGGBBAA;
}

/* Function for MATLAB Function: '<S15>/Embedded MATLAB Function' */
static real_T may23_mod_o(real_T x)
{
  real_T r;
  if (rtIsNaN(x) || rtIsInf(x)) {
    r = (rtNaN);
  } else if (x == 0.0) {
    r = 0.0;
  } else {
    r = fmod(x, 360.0);
    if (r == 0.0) {
      r = 0.0;
    } else {
      if (x < 0.0) {
        r += 360.0;
      }
    }
  }

  return r;
}

/*
 * Output and update for atomic system:
 *    '<S15>/Embedded MATLAB Function'
 *    '<S17>/Embedded MATLAB Function'
 */
void may23_EmbeddedMATLABFunction_m(const real_T rtu_target[25], real_T
  rtu_state_in, real_T rtu_target_type, real_T rtu_opacity_in, real_T
  rtu_target_display, real_T rtu_x_index, real_T rtu_y_index, real_T
  rtu_num_states, const real_T rtu_stateindices[55],
  B_EmbeddedMATLABFunction_may23_d_T *localB)
{
  real_T opacity;
  real_T stroke_colour_col;
  real_T stroke_width_col;
  int32_T i;

  /* MATLAB Function 'Show_Target/Embedded MATLAB Function': '<S391>:1' */
  /* '<S391>:1:86' */
  /* '<S391>:1:87' */
  if (rtu_opacity_in < 100.0) {
    opacity = rtu_opacity_in;
  } else {
    opacity = 100.0;
  }

  if (!(opacity > 0.0)) {
    opacity = 0.0;
  }

  /* '<S391>:1:89' */
  for (i = 0; i < 70; i++) {
    localB->VCODE[i] = 0.0;
  }

  /* '<S391>:1:92' */
  localB->VCODE[0] = rtu_target_type;

  /* '<S391>:1:95' */
  localB->VCODE[2] = rtu_target[(int32_T)rtu_x_index - 1] * 0.01;

  /* '<S391>:1:96' */
  localB->VCODE[3] = rtu_target[(int32_T)rtu_y_index - 1] * 0.01;
  if ((rtu_state_in <= 0.0) || (rtu_state_in > rtu_num_states)) {
    /* '<S391>:1:101' */
    /* '<S391>:1:102' */
    localB->VCODE[1] = 0.0;
  } else {
    /* '<S391>:1:104' */
    localB->VCODE[1] = rtu_target_display;
  }

  /* '<S391>:1:107' */
  /* '<S391>:1:108' */
  stroke_colour_col = rtu_stateindices[(int32_T)rtu_state_in + 4];

  /* '<S391>:1:109' */
  stroke_width_col = rtu_stateindices[(int32_T)rtu_state_in + 9];
  if (rtu_stateindices[(int32_T)rtu_state_in - 1] == 0.0) {
    /* '<S391>:1:112' */
    /* '<S391>:1:113' */
    localB->VCODE[4] = -2.147483648E+9;
  } else if (rtu_target[(int32_T)rtu_stateindices[(int32_T)rtu_state_in - 1] - 1]
             < 0.0) {
    /* '<S391>:1:114' */
    /* '<S391>:1:115' */
    localB->VCODE[4] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
      rtu_state_in - 1] - 1];
  } else {
    /* '<S391>:1:117' */
    localB->VCODE[4] = may23_colourshift_n(rtu_target[(int32_T)rtu_stateindices
      [(int32_T)rtu_state_in - 1] - 1]);
  }

  if (stroke_colour_col == 0.0) {
    /* '<S391>:1:121' */
    /* '<S391>:1:122' */
    localB->VCODE[5] = -2.147483648E+9;
  } else if (rtu_target[(int32_T)stroke_colour_col - 1] < 0.0) {
    /* '<S391>:1:123' */
    /* '<S391>:1:124' */
    localB->VCODE[5] = rtu_target[(int32_T)stroke_colour_col - 1];
  } else {
    /* '<S391>:1:126' */
    localB->VCODE[5] = may23_colourshift_n(rtu_target[(int32_T)stroke_colour_col
      - 1]);
  }

  if (stroke_width_col == 0.0) {
    /* '<S391>:1:130' */
    /* '<S391>:1:131' */
    localB->VCODE[6] = 0.0;
  } else if (stroke_width_col < 0.0) {
    /* '<S391>:1:132' */
    /* '<S391>:1:133' */
    localB->VCODE[6] = 0.001;
  } else {
    /* '<S391>:1:135' */
    localB->VCODE[6] = rtu_target[(int32_T)stroke_width_col - 1] * 0.01;
  }

  /* '<S391>:1:139' */
  localB->VCODE[8] = opacity;
  if (rtu_target_type == 1.0) {
    /* '<S391>:1:142' */
    /* '<S391>:1:145' */
    /* '<S391>:1:146' */
    localB->VCODE[9] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
      rtu_state_in + 14] - 1] * 0.01;
  } else if ((rtu_target_type == 2.0) || (rtu_target_type == 3.0)) {
    /* '<S391>:1:148' */
    /* '<S391>:1:151' */
    /* '<S391>:1:152' */
    /* '<S391>:1:153' */
    /* '<S391>:1:155' */
    localB->VCODE[9] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
      rtu_state_in + 14] - 1] * 0.01;

    /* '<S391>:1:156' */
    localB->VCODE[10] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
      rtu_state_in + 19] - 1] * 0.01;
    if (rtu_stateindices[(int32_T)rtu_state_in + 24] == 0.0) {
      /* '<S391>:1:157' */
      /* '<S391>:1:158' */
      localB->VCODE[11] = 0.0;
    } else {
      /* '<S391>:1:160' */
      localB->VCODE[11] = may23_mod_o(rtu_target[(int32_T)rtu_stateindices
        [(int32_T)rtu_state_in + 24] - 1]) * 3.1415926535897931 / 180.0;
    }
  } else if (rtu_target_type == 4.0) {
    /* '<S391>:1:163' */
    /* '<S391>:1:166' */
    /* '<S391>:1:167' */
    /* '<S391>:1:168' */
    localB->VCODE[9] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
      rtu_state_in + 14] - 1] * 0.01;

    /* '<S391>:1:169' */
    localB->VCODE[10] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
      rtu_state_in + 19] - 1] * 0.01;
  } else {
    if (rtu_target_type == 5.0) {
      /* '<S391>:1:171' */
      /* '<S391>:1:174' */
      /* '<S391>:1:175' */
      /* '<S391>:1:176' */
      /* '<S391>:1:177' */
      /* '<S391>:1:179' */
      localB->VCODE[9] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
        rtu_state_in + 14] - 1] * 0.01;
      if (rtu_stateindices[(int32_T)rtu_state_in + 19] == 0.0) {
        /* '<S391>:1:183' */
        /* '<S391>:1:184' */
        localB->VCODE[10] = 0.8660254037844386 * localB->VCODE[9];
      } else {
        /* '<S391>:1:186' */
        localB->VCODE[10] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
          rtu_state_in + 19] - 1] * 0.01;
      }

      if (rtu_stateindices[(int32_T)rtu_state_in + 24] <= 0.0) {
        /* '<S391>:1:189' */
        /* '<S391>:1:190' */
        localB->VCODE[11] = 0.0;
      } else {
        /* '<S391>:1:192' */
        localB->VCODE[11] = rtu_target[(int32_T)rtu_stateindices[(int32_T)
          rtu_state_in + 24] - 1] * 0.01;
      }

      if (rtu_stateindices[(int32_T)rtu_state_in + 29] == 0.0) {
        /* '<S391>:1:195' */
        /* '<S391>:1:196' */
        localB->VCODE[12] = 0.0;
      } else {
        /* '<S391>:1:198' */
        localB->VCODE[12] = may23_mod_o(rtu_target[(int32_T)rtu_stateindices
          [(int32_T)rtu_state_in + 29] - 1]) * 3.1415926535897931 / 180.0;
      }
    }
  }
}

/* Function for Chart: '<S336>/Task Execution Control Machine' */
static void may23_InTrial(void)
{
  int32_T i;
  boolean_T guard1 = false;
  boolean_T guard2 = false;
  boolean_T guard3 = false;
  int32_T exitg1;

  /* During 'InTrial': '<S345>:8' */
  if (may23_DW.sfEvent_j == may23_event_e_trial_over) {
    /* Transition: '<S345>:37' */
    /* Transition: '<S345>:148' */
    /*  Add the current trial to the repeat list if the
       task is paused and the selected pause type
       is to repeat the trial later, i.e. at the end of
       the block. This occurs independent of the
       repeat trial flag. */
    guard1 = false;
    if ((may23_B.DataTypeConversion1_fy != 1) && (may23_B.PauseType == 3.0)) {
      /* Transition: '<S345>:38' */
      /* Transition: '<S345>:59' */
      guard1 = true;
    } else {
      /* Transition: '<S345>:44' */
      /*  Also add the current trial to the repeat list
         if the repeat trial flag is set and the task is
         running (either normally or until pausing at
         the next trial). */
      if ((may23_B.Product3 > 0.0) && ((may23_B.DataTypeConversion1_fy == 1) ||
           (may23_B.PauseType == 0.0))) {
        /* Transition: '<S345>:43' */
        may23_B.extra_trials[(int32_T)(may23_DW.EXAM - 1.0)]++;
        may23_B.extra_trials[(int32_T)(may23_DW.BLOCK - 1.0)]++;
        guard1 = true;
      } else {
        /* Transition: '<S345>:60' */
        may23_B.repeat_last_trial = 0.0;
      }
    }

    if (guard1) {
      /* Transition: '<S345>:58' */
      /* Transition: '<S345>:46' */
      /*  Add the current trial to the repeat list. */
      may23_DW.repeat_list_length++;
      may23_DW.repeat_list[may23_DW.repeat_list_length - 1U] = may23_B.tp;
      may23_B.repeat_last_trial = 1.0;
    }

    guard1 = false;
    guard2 = false;
    guard3 = false;
    if (may23_DW.trial_in_mini_block >= may23_DW.trial_queue_length) {
      /* Transition: '<S345>:15' */
      /*  If there are any trials to repeat, assign them to the
         trial queue instead of advancing to the next block. */
      if (may23_DW.repeat_list_length > 0U) {
        /* Transition: '<S345>:11' */
        may23_DW.trial_queue_length = may23_DW.repeat_list_length;
        for (i = 0; i < 499; i++) {
          may23_DW.trial_queue[i] = may23_DW.repeat_list[i];
          may23_DW.repeat_list[i] = 0.0;
        }

        may23_DW.repeat_list_length = 0U;
        guard3 = true;
      } else {
        /* Transition: '<S345>:64' */
        do {
          exitg1 = 0;

          /* Transition: '<S345>:26' */
          if (may23_B.DataTypeConversion1_fy == 1) {
            /* Transition: '<S345>:35' */
            /* Transition: '<S345>:55' */
            /* Transition: '<S345>:50' */
            may23_DW.i = 1U;
            may23_DW.temp = (uint32_T)may23_B.BlockSequence[1000];

            /* Transition: '<S345>:27' */
            while ((may23_DW.temp <= may23_B.block_in_set) && (may23_DW.i <
                    may23_B.Width2)) {
              /* Transition: '<S345>:25' */
              may23_DW.i++;
              may23_DW.temp = (uint32_T)(may23_B.BlockSequence[(int32_T)
                may23_DW.i + 999] + (real_T)may23_DW.temp);
            }

            /* Transition: '<S345>:12' */
            /*  Finish if using a task protocol block sequence
               and that sequence has finished. */
            if ((may23_DW.i == may23_B.Width2) && (may23_DW.temp <=
                 may23_B.block_in_set)) {
              /* Transition: '<S345>:42' */
              /* Exit Internal 'InTrial': '<S345>:8' */
              may23_DW.is_InTrial = may23_IN_NO_ACTIVE_CHILD_l;
              may23_DW.is_c42_General = may23_IN_Finished;

              /* Entry 'Finished': '<S345>:4' */
              may23_B.task_status = 4U;
              exitg1 = 1;
            } else {
              /* Transition: '<S345>:32' */
              /*  Make next task protocol block index the next block. */
              may23_DW.block = may23_B.BlockSequence[may23_DW.i - 1U];
              may23_B.block_idx = (uint32_T)may23_B.BlockSequence[(int32_T)
                may23_DW.i + 1999];

              /* Transition: '<S345>:13' */
              /* Transition: '<S345>:49' */
              may23_B.block_in_set++;
              may23_DW.i = 1U;
              may23_B.extra_trials[(int32_T)(may23_DW.BLOCK - 1.0)] = 0.0;

              /* Transition: '<S345>:36' */
              /*  Copy the trial list from the block definitions to the trial queue. */
              while ((may23_DW.i <= may23_B.Subtract_a) && (may23_DW.block > 0.0)
                     && (may23_B.BlockDefinitions[(int32_T)(may23_DW.block - 1.0)
                         + 50 * (int32_T)may23_DW.i] != 0.0)) {
                /* Transition: '<S345>:16' */
                may23_DW.trial_queue[may23_DW.i - 1U] =
                  may23_B.BlockDefinitions[(int32_T)(may23_DW.block - 1.0) + 50 *
                  (int32_T)may23_DW.i];
                may23_DW.i++;
              }

              /* Transition: '<S345>:41' */
              may23_DW.trial_queue_length = may23_DW.i - 1U;
              if (may23_DW.trial_queue_length > 0U) {
                /* Transition: '<S345>:66' */
                may23_B.trial_in_block = 0U;
                guard3 = true;
                exitg1 = 1;
              } else {
                /* Transition: '<S345>:65' */
              }
            }
          } else {
            /* Transition: '<S345>:33' */
            /* Exit Internal 'InTrial': '<S345>:8' */
            may23_DW.is_InTrial = may23_IN_NO_ACTIVE_CHILD_l;
            may23_DW.is_c42_General = may23_IN_PausedBetweenBlocks;

            /* Entry 'PausedBetweenBlocks': '<S345>:5' */
            may23_B.task_status = 3U;
            exitg1 = 1;
          }
        } while (exitg1 == 0);
      }
    } else {
      /* Transition: '<S345>:14' */
      if (may23_B.DataTypeConversion1_fy == 1) {
        /* Transition: '<S345>:29' */
        guard2 = true;
      } else {
        /* Transition: '<S345>:30' */
        guard1 = true;
      }
    }

    if (guard3) {
      /* Transition: '<S345>:17' */
      may23_DW.trial_in_mini_block = 0U;

      /*  Randomize the block if the definition specifies to do so. */
      if (may23_B.BlockDefinitions[(int32_T)(may23_DW.block - 1.0)] == 1.0) {
        /* Transition: '<S345>:18' */
        may23_DW.i = 1U;

        /* Transition: '<S345>:22' */
        /*  Perform list randomization "a la Knuth". */
        while (may23_DW.i <= may23_DW.trial_queue_length) {
          /* Transition: '<S345>:23' */
          may23_DW.swap_index = (uint32_T)(fmod(rand(),
            may23_DW.trial_queue_length) + 1.0);
          may23_DW.temp = (uint32_T)may23_DW.trial_queue[may23_DW.swap_index -
            1U];
          may23_DW.trial_queue[may23_DW.swap_index - 1U] =
            may23_DW.trial_queue[may23_DW.i - 1U];
          may23_DW.trial_queue[may23_DW.i - 1U] = may23_DW.temp;
          may23_DW.i++;
        }

        /* Transition: '<S345>:67' */
      } else {
        /* Transition: '<S345>:19' */
        /* Transition: '<S345>:20' */
      }

      /* Transition: '<S345>:21' */
      if (may23_B.DataTypeConversion1_fy != 1) {
        /* Transition: '<S345>:68' */
        /* Transition: '<S345>:69' */
        guard1 = true;
      } else {
        /* Transition: '<S345>:70' */
        guard2 = true;
      }
    }

    if (guard2) {
      /* Exit Internal 'InTrial': '<S345>:8' */
      may23_DW.is_c42_General = may23_IN_InTrial;

      /* Entry 'InTrial': '<S345>:8' */
      may23_B.trial_in_set++;
      may23_B.trial_in_block++;
      may23_DW.trial_in_mini_block++;
      may23_B.tp = (uint32_T)may23_DW.trial_queue[may23_DW.trial_in_mini_block -
        1U];

      /* Entry Internal 'InTrial': '<S345>:8' */
      /* Transition: '<S345>:47' */
      may23_DW.is_InTrial = may23_IN_Running;

      /* Entry 'Running': '<S345>:1' */
      may23_B.task_status = 2U;
    }

    if (guard1) {
      /* Exit Internal 'InTrial': '<S345>:8' */
      may23_DW.is_InTrial = may23_IN_NO_ACTIVE_CHILD_l;
      may23_DW.is_c42_General = may23_IN_PausedBetweenTrials;

      /* Entry 'PausedBetweenTrials': '<S345>:3' */
      may23_B.task_status = 3U;
    }
  } else {
    switch (may23_DW.is_InTrial) {
     case may23_IN_Paused:
      may23_B.task_status = 3U;

      /* During 'Paused': '<S345>:6' */
      if (may23_B.DataTypeConversion1_fy == 1) {
        /* Transition: '<S345>:54' */
        may23_DW.is_InTrial = may23_IN_Running;

        /* Entry 'Running': '<S345>:1' */
        may23_B.task_status = 2U;
      }
      break;

     case may23_IN_RepeatTrialLater:
      /* During 'RepeatTrialLater': '<S345>:7' */
      break;

     case may23_IN_RepeatTrialNow:
      /* During 'RepeatTrialNow': '<S345>:9' */
      break;

     case may23_IN_Running:
      may23_B.task_status = 2U;

      /* During 'Running': '<S345>:1' */
      if ((may23_B.DataTypeConversion1_fy != 1) && (may23_B.PauseType > 0.0)) {
        /* Transition: '<S345>:53' */
        if (may23_B.PauseType == 1.0) {
          /* Transition: '<S345>:52' */
          may23_DW.is_InTrial = may23_IN_SkipTrial;

          /* Entry 'SkipTrial': '<S345>:2' */
          /* Event: '<S345>:132' */
          may23_DW.e_exit_trialEventCounter++;
        } else {
          /* Transition: '<S345>:61' */
          if (may23_B.PauseType == 2.0) {
            /* Transition: '<S345>:51' */
            may23_DW.is_InTrial = may23_IN_RepeatTrialNow;

            /* Entry 'RepeatTrialNow': '<S345>:9' */
            may23_DW.trial_in_mini_block--;
            may23_B.extra_trials[(int32_T)(may23_DW.EXAM - 1.0)]++;
            may23_B.extra_trials[(int32_T)(may23_DW.BLOCK - 1.0)]++;

            /* Event: '<S345>:132' */
            may23_DW.e_exit_trialEventCounter++;
          } else {
            /* Transition: '<S345>:62' */
            if (may23_B.PauseType == 3.0) {
              /* Transition: '<S345>:48' */
              may23_DW.is_InTrial = may23_IN_RepeatTrialLater;

              /* Entry 'RepeatTrialLater': '<S345>:7' */
              may23_B.extra_trials[(int32_T)(may23_DW.EXAM - 1.0)]++;
              may23_B.extra_trials[(int32_T)(may23_DW.BLOCK - 1.0)]++;

              /* Event: '<S345>:132' */
              may23_DW.e_exit_trialEventCounter++;
            } else {
              /* Transition: '<S345>:63' */
              /* Transition: '<S345>:56' */
              may23_DW.is_InTrial = may23_IN_Paused;

              /* Entry 'Paused': '<S345>:6' */
              may23_B.task_status = 3U;
            }
          }
        }
      }
      break;

     default:
      /* During 'SkipTrial': '<S345>:2' */
      break;
    }
  }
}

/* Function for Chart: '<S336>/Task Execution Control Machine' */
static void may23_chartstep_c42_General(void)
{
  int32_T exitg1;
  int32_T exitg2;

  /* Chart: '<S336>/Task Execution Control Machine' */
  /* During: GUI Control/Task Execution Control Subsystem/Task Execution Control Machine */
  if (may23_DW.is_active_c42_General == 0U) {
    /* Entry: GUI Control/Task Execution Control Subsystem/Task Execution Control Machine */
    may23_DW.is_active_c42_General = 1U;

    /* Entry Internal: GUI Control/Task Execution Control Subsystem/Task Execution Control Machine */
    /* Transition: '<S345>:57' */
    may23_DW.is_c42_General = may23_IN_Ready;

    /* Entry 'Ready': '<S345>:10' */
    may23_B.task_status = 1U;
    may23_B.tp = 0U;
    may23_DW.block = 0.0;
    may23_B.trial_in_block = 0U;
    may23_B.block_in_set = 0U;
    may23_B.trial_in_set = 0U;
    may23_DW.trial_in_mini_block = 0U;
    may23_B.extra_trials[(int32_T)(may23_DW.EXAM - 1.0)] = 0.0;
    may23_B.extra_trials[(int32_T)(may23_DW.BLOCK - 1.0)] = 0.0;
  } else {
    switch (may23_DW.is_c42_General) {
     case may23_IN_Finished:
      may23_B.task_status = 4U;

      /* During 'Finished': '<S345>:4' */
      break;

     case may23_IN_Finished1:
      may23_B.task_status = 4U;

      /* During 'Finished1': '<S345>:171' */
      break;

     case may23_IN_InTrial:
      may23_InTrial();
      break;

     case may23_IN_InTrial1:
      /* During 'InTrial1': '<S345>:149' */
      if (may23_DW.sfEvent_j == may23_event_e_trial_over) {
        /* Transition: '<S345>:169' */
        /* Exit Internal 'InTrial1': '<S345>:149' */
        may23_DW.is_InTrial1 = may23_IN_NO_ACTIVE_CHILD_l;
        may23_DW.is_c42_General = may23_IN_PausedBetweenTrials1;
        may23_DW.temporalCounter_i1_h = 0U;

        /* Entry 'PausedBetweenTrials1': '<S345>:142' */
        may23_B.task_status = 3U;
      } else {
        switch (may23_DW.is_InTrial1) {
         case may23_IN_Paused1:
          may23_B.task_status = 3U;

          /* During 'Paused1': '<S345>:160' */
          if (may23_B.DataTypeConversion1_fy == 1) {
            /* Transition: '<S345>:158' */
            may23_DW.is_InTrial1 = may23_IN_Running1;

            /* Entry 'Running1': '<S345>:162' */
            may23_B.task_status = 2U;
          }
          break;

         case may23_IN_RepeatTrialLater1:
          /* During 'RepeatTrialLater1': '<S345>:156' */
          break;

         case may23_IN_RepeatTrialNow1:
          /* During 'RepeatTrialNow1': '<S345>:163' */
          break;

         case may23_IN_Running1:
          may23_B.task_status = 2U;

          /* During 'Running1': '<S345>:162' */
          if ((may23_B.DataTypeConversion1_fy != 1) && (may23_B.PauseType > 0.0))
          {
            /* Transition: '<S345>:167' */
            if (may23_B.PauseType == 1.0) {
              /* Transition: '<S345>:155' */
              may23_DW.is_InTrial1 = may23_IN_SkipTrial1;

              /* Entry 'SkipTrial1': '<S345>:165' */
              /* Event: '<S345>:132' */
              may23_DW.e_exit_trialEventCounter++;
            } else {
              /* Transition: '<S345>:161' */
              if (may23_B.PauseType == 2.0) {
                /* Transition: '<S345>:159' */
                may23_DW.is_InTrial1 = may23_IN_RepeatTrialNow1;

                /* Entry 'RepeatTrialNow1': '<S345>:163' */
                /* Event: '<S345>:132' */
                may23_DW.e_exit_trialEventCounter++;
              } else {
                /* Transition: '<S345>:151' */
                if (may23_B.PauseType == 3.0) {
                  /* Transition: '<S345>:164' */
                  may23_DW.is_InTrial1 = may23_IN_RepeatTrialLater1;

                  /* Entry 'RepeatTrialLater1': '<S345>:156' */
                  /* Event: '<S345>:132' */
                  may23_DW.e_exit_trialEventCounter++;
                } else {
                  /* Transition: '<S345>:166' */
                  /* Transition: '<S345>:157' */
                  may23_DW.is_InTrial1 = may23_IN_Paused1;

                  /* Entry 'Paused1': '<S345>:160' */
                  may23_B.task_status = 3U;
                }
              }
            }
          }
          break;

         default:
          /* During 'SkipTrial1': '<S345>:165' */
          break;
        }
      }
      break;

     case may23_IN_PausedBetweenBlocks:
      may23_B.task_status = 3U;

      /* During 'PausedBetweenBlocks': '<S345>:5' */
      if (may23_B.DataTypeConversion1_fy == 1) {
        /* Transition: '<S345>:34' */
        if (may23_B.UsecustomTPsequence == 1.0) {
          /* Transition: '<S345>:139' */
          /* Transition: '<S345>:141' */
          may23_DW.is_c42_General = may23_IN_PausedBetweenTrials1;
          may23_DW.temporalCounter_i1_h = 0U;

          /* Entry 'PausedBetweenTrials1': '<S345>:142' */
          may23_B.task_status = 3U;
        } else {
          /* Transition: '<S345>:28' */
          do {
            exitg2 = 0;

            /* Transition: '<S345>:55' */
            /* Transition: '<S345>:50' */
            may23_DW.i = 1U;
            may23_DW.temp = (uint32_T)may23_B.BlockSequence[1000];

            /* Transition: '<S345>:27' */
            while ((may23_DW.temp <= may23_B.block_in_set) && (may23_DW.i <
                    may23_B.Width2)) {
              /* Transition: '<S345>:25' */
              may23_DW.i++;
              may23_DW.temp = (uint32_T)(may23_B.BlockSequence[(int32_T)
                may23_DW.i + 999] + (real_T)may23_DW.temp);
            }

            /* Transition: '<S345>:12' */
            /*  Finish if using a task protocol block sequence
               and that sequence has finished. */
            if ((may23_DW.i == may23_B.Width2) && (may23_DW.temp <=
                 may23_B.block_in_set)) {
              /* Transition: '<S345>:42' */
              may23_DW.is_c42_General = may23_IN_Finished;

              /* Entry 'Finished': '<S345>:4' */
              may23_B.task_status = 4U;
              exitg2 = 1;
            } else {
              /* Transition: '<S345>:32' */
              /*  Make next task protocol block index the next block. */
              may23_DW.block = may23_B.BlockSequence[may23_DW.i - 1U];
              may23_B.block_idx = (uint32_T)may23_B.BlockSequence[(int32_T)
                may23_DW.i + 1999];

              /* Transition: '<S345>:13' */
              /* Transition: '<S345>:49' */
              may23_B.block_in_set++;
              may23_DW.i = 1U;
              may23_B.extra_trials[(int32_T)(may23_DW.BLOCK - 1.0)] = 0.0;

              /* Transition: '<S345>:36' */
              /*  Copy the trial list from the block definitions to the trial queue. */
              while ((may23_DW.i <= may23_B.Subtract_a) && (may23_DW.block > 0.0)
                     && (may23_B.BlockDefinitions[(int32_T)(may23_DW.block - 1.0)
                         + 50 * (int32_T)may23_DW.i] != 0.0)) {
                /* Transition: '<S345>:16' */
                may23_DW.trial_queue[may23_DW.i - 1U] =
                  may23_B.BlockDefinitions[(int32_T)(may23_DW.block - 1.0) + 50 *
                  (int32_T)may23_DW.i];
                may23_DW.i++;
              }

              /* Transition: '<S345>:41' */
              may23_DW.trial_queue_length = may23_DW.i - 1U;
              if (may23_DW.trial_queue_length > 0U) {
                /* Transition: '<S345>:66' */
                may23_B.trial_in_block = 0U;

                /* Transition: '<S345>:17' */
                may23_DW.trial_in_mini_block = 0U;

                /*  Randomize the block if the definition specifies to do so. */
                if (may23_B.BlockDefinitions[(int32_T)(may23_DW.block - 1.0)] ==
                    1.0) {
                  /* Transition: '<S345>:18' */
                  may23_DW.i = 1U;

                  /* Transition: '<S345>:22' */
                  /*  Perform list randomization "a la Knuth". */
                  while (may23_DW.i <= may23_DW.trial_queue_length) {
                    /* Transition: '<S345>:23' */
                    may23_DW.swap_index = (uint32_T)(fmod(rand(),
                      may23_DW.trial_queue_length) + 1.0);
                    may23_DW.temp = (uint32_T)
                      may23_DW.trial_queue[may23_DW.swap_index - 1U];
                    may23_DW.trial_queue[may23_DW.swap_index - 1U] =
                      may23_DW.trial_queue[may23_DW.i - 1U];
                    may23_DW.trial_queue[may23_DW.i - 1U] = may23_DW.temp;
                    may23_DW.i++;
                  }

                  /* Transition: '<S345>:67' */
                } else {
                  /* Transition: '<S345>:19' */
                  /* Transition: '<S345>:20' */
                }

                /* Transition: '<S345>:21' */
                if (may23_B.DataTypeConversion1_fy != 1) {
                  /* Transition: '<S345>:68' */
                  /* Transition: '<S345>:69' */
                  may23_DW.is_c42_General = may23_IN_PausedBetweenTrials;

                  /* Entry 'PausedBetweenTrials': '<S345>:3' */
                  may23_B.task_status = 3U;
                } else {
                  /* Transition: '<S345>:70' */
                  may23_DW.is_c42_General = may23_IN_InTrial;

                  /* Entry 'InTrial': '<S345>:8' */
                  may23_B.trial_in_set++;
                  may23_B.trial_in_block++;
                  may23_DW.trial_in_mini_block++;
                  may23_B.tp = (uint32_T)
                    may23_DW.trial_queue[may23_DW.trial_in_mini_block - 1U];

                  /* Entry Internal 'InTrial': '<S345>:8' */
                  /* Transition: '<S345>:47' */
                  may23_DW.is_InTrial = may23_IN_Running;

                  /* Entry 'Running': '<S345>:1' */
                  may23_B.task_status = 2U;
                }

                exitg2 = 1;
              } else {
                /* Transition: '<S345>:65' */
                /* Transition: '<S345>:26' */
                if (may23_B.DataTypeConversion1_fy == 1) {
                  /* Transition: '<S345>:35' */
                } else {
                  /* Transition: '<S345>:33' */
                  may23_DW.is_c42_General = may23_IN_PausedBetweenBlocks;

                  /* Entry 'PausedBetweenBlocks': '<S345>:5' */
                  may23_B.task_status = 3U;
                  exitg2 = 1;
                }
              }
            }
          } while (exitg2 == 0);
        }
      }
      break;

     case may23_IN_PausedBetweenTrials:
      may23_B.task_status = 3U;

      /* During 'PausedBetweenTrials': '<S345>:3' */
      if (may23_B.DataTypeConversion1_fy == 1) {
        /* Transition: '<S345>:31' */
        may23_DW.is_c42_General = may23_IN_InTrial;

        /* Entry 'InTrial': '<S345>:8' */
        may23_B.trial_in_set++;
        may23_B.trial_in_block++;
        may23_DW.trial_in_mini_block++;
        may23_B.tp = (uint32_T)may23_DW.trial_queue[may23_DW.trial_in_mini_block
          - 1U];

        /* Entry Internal 'InTrial': '<S345>:8' */
        /* Transition: '<S345>:47' */
        may23_DW.is_InTrial = may23_IN_Running;

        /* Entry 'Running': '<S345>:1' */
        may23_B.task_status = 2U;
      }
      break;

     case may23_IN_PausedBetweenTrials1:
      may23_B.task_status = 3U;

      /* During 'PausedBetweenTrials1': '<S345>:142' */
      if (may23_B.tp_out < 1.0) {
        /* Transition: '<S345>:172' */
        may23_DW.is_c42_General = may23_IN_Finished1;

        /* Entry 'Finished1': '<S345>:171' */
        may23_B.task_status = 4U;
      } else {
        if ((may23_DW.temporalCounter_i1_h >= 2) &&
            (may23_B.DataTypeConversion1_fy == 1)) {
          /* Transition: '<S345>:146' */
          may23_DW.is_c42_General = may23_IN_InTrial1;

          /* Entry 'InTrial1': '<S345>:149' */
          may23_B.trial_in_set++;
          may23_B.trial_in_block++;
          may23_B.tp = (uint32_T)may23_B.tp_out;

          /* Entry Internal 'InTrial1': '<S345>:149' */
          /* Transition: '<S345>:154' */
          may23_DW.is_InTrial1 = may23_IN_Running1;

          /* Entry 'Running1': '<S345>:162' */
          may23_B.task_status = 2U;
        }
      }
      break;

     default:
      may23_B.task_status = 1U;

      /* During 'Ready': '<S345>:10' */
      if (may23_B.DataTypeConversion1_fy == 1) {
        /* Transition: '<S345>:40' */
        srand(may23_B.DataTypeConversion3_m);
        if (may23_B.UsecustomTPsequence == 1.0) {
          /* Transition: '<S345>:139' */
          /* Transition: '<S345>:141' */
          may23_DW.is_c42_General = may23_IN_PausedBetweenTrials1;
          may23_DW.temporalCounter_i1_h = 0U;

          /* Entry 'PausedBetweenTrials1': '<S345>:142' */
          may23_B.task_status = 3U;
        } else {
          /* Transition: '<S345>:28' */
          do {
            exitg1 = 0;

            /* Transition: '<S345>:55' */
            /* Transition: '<S345>:50' */
            may23_DW.i = 1U;
            may23_DW.temp = (uint32_T)may23_B.BlockSequence[1000];

            /* Transition: '<S345>:27' */
            while ((may23_DW.temp <= may23_B.block_in_set) && (may23_DW.i <
                    may23_B.Width2)) {
              /* Transition: '<S345>:25' */
              may23_DW.i++;
              may23_DW.temp = (uint32_T)(may23_B.BlockSequence[(int32_T)
                may23_DW.i + 999] + (real_T)may23_DW.temp);
            }

            /* Transition: '<S345>:12' */
            /*  Finish if using a task protocol block sequence
               and that sequence has finished. */
            if ((may23_DW.i == may23_B.Width2) && (may23_DW.temp <=
                 may23_B.block_in_set)) {
              /* Transition: '<S345>:42' */
              may23_DW.is_c42_General = may23_IN_Finished;

              /* Entry 'Finished': '<S345>:4' */
              may23_B.task_status = 4U;
              exitg1 = 1;
            } else {
              /* Transition: '<S345>:32' */
              /*  Make next task protocol block index the next block. */
              may23_DW.block = may23_B.BlockSequence[may23_DW.i - 1U];
              may23_B.block_idx = (uint32_T)may23_B.BlockSequence[(int32_T)
                may23_DW.i + 1999];

              /* Transition: '<S345>:13' */
              /* Transition: '<S345>:49' */
              may23_B.block_in_set++;
              may23_DW.i = 1U;
              may23_B.extra_trials[(int32_T)(may23_DW.BLOCK - 1.0)] = 0.0;

              /* Transition: '<S345>:36' */
              /*  Copy the trial list from the block definitions to the trial queue. */
              while ((may23_DW.i <= may23_B.Subtract_a) && (may23_DW.block > 0.0)
                     && (may23_B.BlockDefinitions[(int32_T)(may23_DW.block - 1.0)
                         + 50 * (int32_T)may23_DW.i] != 0.0)) {
                /* Transition: '<S345>:16' */
                may23_DW.trial_queue[may23_DW.i - 1U] =
                  may23_B.BlockDefinitions[(int32_T)(may23_DW.block - 1.0) + 50 *
                  (int32_T)may23_DW.i];
                may23_DW.i++;
              }

              /* Transition: '<S345>:41' */
              may23_DW.trial_queue_length = may23_DW.i - 1U;
              if (may23_DW.trial_queue_length > 0U) {
                /* Transition: '<S345>:66' */
                may23_B.trial_in_block = 0U;

                /* Transition: '<S345>:17' */
                may23_DW.trial_in_mini_block = 0U;

                /*  Randomize the block if the definition specifies to do so. */
                if (may23_B.BlockDefinitions[(int32_T)(may23_DW.block - 1.0)] ==
                    1.0) {
                  /* Transition: '<S345>:18' */
                  may23_DW.i = 1U;

                  /* Transition: '<S345>:22' */
                  /*  Perform list randomization "a la Knuth". */
                  while (may23_DW.i <= may23_DW.trial_queue_length) {
                    /* Transition: '<S345>:23' */
                    may23_DW.swap_index = (uint32_T)(fmod(rand(),
                      may23_DW.trial_queue_length) + 1.0);
                    may23_DW.temp = (uint32_T)
                      may23_DW.trial_queue[may23_DW.swap_index - 1U];
                    may23_DW.trial_queue[may23_DW.swap_index - 1U] =
                      may23_DW.trial_queue[may23_DW.i - 1U];
                    may23_DW.trial_queue[may23_DW.i - 1U] = may23_DW.temp;
                    may23_DW.i++;
                  }

                  /* Transition: '<S345>:67' */
                } else {
                  /* Transition: '<S345>:19' */
                  /* Transition: '<S345>:20' */
                }

                /* Transition: '<S345>:21' */
                if (may23_B.DataTypeConversion1_fy != 1) {
                  /* Transition: '<S345>:68' */
                  /* Transition: '<S345>:69' */
                  may23_DW.is_c42_General = may23_IN_PausedBetweenTrials;

                  /* Entry 'PausedBetweenTrials': '<S345>:3' */
                  may23_B.task_status = 3U;
                } else {
                  /* Transition: '<S345>:70' */
                  may23_DW.is_c42_General = may23_IN_InTrial;

                  /* Entry 'InTrial': '<S345>:8' */
                  may23_B.trial_in_set++;
                  may23_B.trial_in_block++;
                  may23_DW.trial_in_mini_block++;
                  may23_B.tp = (uint32_T)
                    may23_DW.trial_queue[may23_DW.trial_in_mini_block - 1U];

                  /* Entry Internal 'InTrial': '<S345>:8' */
                  /* Transition: '<S345>:47' */
                  may23_DW.is_InTrial = may23_IN_Running;

                  /* Entry 'Running': '<S345>:1' */
                  may23_B.task_status = 2U;
                }

                exitg1 = 1;
              } else {
                /* Transition: '<S345>:65' */
                /* Transition: '<S345>:26' */
                if (may23_B.DataTypeConversion1_fy == 1) {
                  /* Transition: '<S345>:35' */
                } else {
                  /* Transition: '<S345>:33' */
                  may23_DW.is_c42_General = may23_IN_PausedBetweenBlocks;

                  /* Entry 'PausedBetweenBlocks': '<S345>:5' */
                  may23_B.task_status = 3U;
                  exitg1 = 1;
                }
              }
            }
          } while (exitg1 == 0);
        }
      }
      break;
    }
  }

  /* End of Chart: '<S336>/Task Execution Control Machine' */
}

/* Function for Chart: '<Root>/Trial_Control' */
static void may23_Success(void)
{
  may23_B.puck_state = 0.0;
  may23_B.goal_target_state = 3.0;

  /* During 'Success': '<S20>:249' */
  if (may23_DW.temporalCounter_i1 >= 1200U) {
    /* Transition: '<S20>:252' */
    may23_DW.is_Main_Trial = may23_IN_NO_ACTIVE_CHILD_l;
    may23_B.event_code = E_SUCCESS;
    may23_DW.is_c3_may23 = may23_IN_Inter_Trial_State;
    may23_DW.temporalCounter_i1 = 0U;

    /* Entry 'Inter_Trial_State': '<S20>:1' */
    /* Event: '<S20>:25' */
    may23_DW.e_Trial_EndEventCounter++;
  }
}

/* Function for Chart: '<Root>/Trial_Control' */
static void may23_Main_Trial(void)
{
  /* During 'Main_Trial': '<S20>:3' */
  if (may23_DW.sfEvent_b == may23_event_e_ExitTrialNow) {
    /* Transition: '<S20>:13' */
    /* Exit Internal 'Main_Trial': '<S20>:3' */
    may23_DW.is_Main_Trial = may23_IN_NO_ACTIVE_CHILD_l;
    may23_DW.is_c3_may23 = may23_IN_Inter_Trial_State;
    may23_DW.temporalCounter_i1 = 0U;

    /* Entry 'Inter_Trial_State': '<S20>:1' */
    /* Event: '<S20>:25' */
    may23_DW.e_Trial_EndEventCounter++;
  } else {
    switch (may23_DW.is_Main_Trial) {
     case may23_IN_Fail:
      may23_B.start_target_state = 0.0;
      may23_B.preshot_area_state = 0.0;
      may23_B.cursor_state = 3.0;
      may23_B.puck_state = 0.0;
      may23_B.barrier_target_state = 0.0;
      may23_B.goal_target_state = 0.0;

      /* During 'Fail': '<S20>:241' */
      if (may23_DW.temporalCounter_i1 >= 1200U) {
        /* Transition: '<S20>:243' */
        may23_DW.is_Main_Trial = may23_IN_NO_ACTIVE_CHILD_l;
        may23_B.event_code = E_FAILURE;
        may23_DW.is_c3_may23 = may23_IN_Inter_Trial_State;
        may23_DW.temporalCounter_i1 = 0U;

        /* Entry 'Inter_Trial_State': '<S20>:1' */
        /* Event: '<S20>:25' */
        may23_DW.e_Trial_EndEventCounter++;
      }
      break;

     case may23_IN_PreshotMove:
      /* During 'PreshotMove': '<S20>:246' */
      if (may23_B.ArraySelector[(int32_T)may23_B.start_target_row - 1] == 1.0) {
        /* Transition: '<S20>:235' */
        may23_DW.is_Main_Trial = may23_IN_ShotReady;
        may23_DW.temporalCounter_i1 = 0U;

        /* Entry 'ShotReady': '<S20>:233' */
      } else {
        if (may23_B.ArraySelector[(int32_T)may23_B.preshot_area_row - 1] == 0.0)
        {
          /* Transition: '<S20>:260' */
          may23_B.event_code = E_START_TARGET_ON;
          may23_DW.is_Main_Trial = may23_IN_StartOn;
          may23_DW.temporalCounter_i1 = 0U;

          /* Entry 'StartOn': '<S20>:4' */
          may23_B.start_target_state = 1.0;
          may23_B.preshot_area_state = 0.0;
          may23_B.cursor_state = 1.0;
          may23_B.puck_state = 0.0;
          may23_B.barrier_target_state = 0.0;
          may23_B.goal_target_state = 0.0;
        }
      }
      break;

     case may23_IN_PreshotStart:
      may23_B.preshot_area_state = 1.0;
      may23_B.start_target_state = 2.0;
      may23_B.puck_state = 1.0;
      may23_B.goal_target_state = 1.0;
      may23_B.barrier_target_state = 1.0;

      /* During 'PreshotStart': '<S20>:222' */
      if (may23_B.ArraySelector[(int32_T)may23_B.preshot_area_row - 1] == 0.0) {
        /* Transition: '<S20>:230' */
        may23_B.event_code = E_START_TARGET_ON;
        may23_DW.is_Main_Trial = may23_IN_StartOn;
        may23_DW.temporalCounter_i1 = 0U;

        /* Entry 'StartOn': '<S20>:4' */
        may23_B.start_target_state = 1.0;
        may23_B.preshot_area_state = 0.0;
        may23_B.cursor_state = 1.0;
        may23_B.puck_state = 0.0;
        may23_B.barrier_target_state = 0.0;
        may23_B.goal_target_state = 0.0;
      } else {
        if (may23_B.ArraySelector[(int32_T)may23_B.start_target_row - 1] == 0.0)
        {
          /* Transition: '<S20>:247' */
          may23_B.event_code = E_BEGIN_PRESHOT;
          may23_DW.is_Main_Trial = may23_IN_PreshotMove;

          /* Entry 'PreshotMove': '<S20>:246' */
        }
      }
      break;

     case may23_IN_PuckMoving:
      /* During 'PuckMoving': '<S20>:282' */
      if (may23_DW.sfEvent_b == may23_event_e_Puck_Stopped) {
        /* Transition: '<S20>:279' */
        may23_DW.is_Main_Trial = may23_IN_ShotEnd;
      }
      break;

     case may23_IN_Shot:
      may23_B.start_target_state = 0.0;
      may23_B.cursor_state = 2.0;
      may23_B.puck_state = 2.0;
      may23_B.goal_target_state = 2.0;
      may23_B.barrier_target_state = 2.0;

      /* During 'Shot': '<S20>:239' */
      if (may23_B.ArraySelector_c[(int32_T)may23_B.barrier_target_row - 1] ==
          1.0) {
        /* Transition: '<S20>:267' */
        may23_B.event_code = E_PUCK_IN_BARRIER;
        may23_DW.is_Main_Trial = may23_IN_Fail;
        may23_DW.temporalCounter_i1 = 0U;

        /* Entry 'Fail': '<S20>:241' */
        may23_B.start_target_state = 0.0;
        may23_B.preshot_area_state = 0.0;
        may23_B.cursor_state = 3.0;
        may23_B.puck_state = 0.0;
        may23_B.barrier_target_state = 0.0;
        may23_B.goal_target_state = 0.0;
      } else if (may23_DW.temporalCounter_i1 >= (uint32_T)ceil
                 (may23_DW.shot_time / 0.00025 - 2.5000000000000003E-12)) {
        /* Transition: '<S20>:242' */
        may23_B.event_code = E_TIMEOUT;
        may23_DW.is_Main_Trial = may23_IN_Fail;
        may23_DW.temporalCounter_i1 = 0U;

        /* Entry 'Fail': '<S20>:241' */
        may23_B.start_target_state = 0.0;
        may23_B.preshot_area_state = 0.0;
        may23_B.cursor_state = 3.0;
        may23_B.puck_state = 0.0;
        may23_B.barrier_target_state = 0.0;
        may23_B.goal_target_state = 0.0;
      } else if (may23_B.ArraySelector_b[(int32_T)may23_B.barrier_target_row - 1]
                 == 1.0) {
        /* Transition: '<S20>:248' */
        may23_B.event_code = E_HAND_IN_BARRIER;
        may23_DW.is_Main_Trial = may23_IN_Fail;
        may23_DW.temporalCounter_i1 = 0U;

        /* Entry 'Fail': '<S20>:241' */
        may23_B.start_target_state = 0.0;
        may23_B.preshot_area_state = 0.0;
        may23_B.cursor_state = 3.0;
        may23_B.puck_state = 0.0;
        may23_B.barrier_target_state = 0.0;
        may23_B.goal_target_state = 0.0;
      } else {
        if (may23_DW.sfEvent_b == may23_event_e_Puck_Hit) {
          /* Transition: '<S20>:283' */
          may23_DW.is_Main_Trial = may23_IN_PuckMoving;
        }
      }
      break;

     case may23_IN_ShotEnd:
      /* During 'ShotEnd': '<S20>:278' */
      if (may23_B.ArraySelector_m[(int32_T)may23_B.goal_target_row - 1] == 1.0)
      {
        /* Transition: '<S20>:253' */
        may23_B.event_code = E_PUCK_IN_GOAL;
        may23_DW.is_Main_Trial = may23_IN_Success;
        may23_DW.temporalCounter_i1 = 0U;

        /* Entry 'Success': '<S20>:249' */
        may23_B.puck_state = 0.0;
        may23_B.goal_target_state = 3.0;
      } else {
        if (may23_B.ArraySelector_m[(int32_T)may23_B.goal_target_row - 1] == 0.0)
        {
          /* Transition: '<S20>:280' */
          may23_B.event_code = E_PUCK_MISS;
          may23_DW.is_Main_Trial = may23_IN_Fail;
          may23_DW.temporalCounter_i1 = 0U;

          /* Entry 'Fail': '<S20>:241' */
          may23_B.start_target_state = 0.0;
          may23_B.preshot_area_state = 0.0;
          may23_B.cursor_state = 3.0;
          may23_B.puck_state = 0.0;
          may23_B.barrier_target_state = 0.0;
          may23_B.goal_target_state = 0.0;
        }
      }
      break;

     case may23_IN_ShotReady:
      /* During 'ShotReady': '<S20>:233' */
      if (may23_B.ArraySelector[(int32_T)may23_B.start_target_row - 1] == 0.0) {
        /* Transition: '<S20>:234' */
        may23_DW.is_Main_Trial = may23_IN_PreshotMove;

        /* Entry 'PreshotMove': '<S20>:246' */
      } else {
        if (may23_DW.temporalCounter_i1 >= (uint32_T)ceil
            (may23_DW.shot_ready_time / 0.00025 - 2.5000000000000003E-12)) {
          /* Transition: '<S20>:237' */
          may23_B.event_code = E_SHOT_READY;
          may23_DW.is_Main_Trial = may23_IN_ShotSet;
          may23_DW.temporalCounter_i1 = 0U;

          /* Entry 'ShotSet': '<S20>:236' */
          may23_B.preshot_area_state = 0.0;
          may23_B.start_target_state = 3.0;
        }
      }
      break;

     case may23_IN_ShotSet:
      may23_B.preshot_area_state = 0.0;
      may23_B.start_target_state = 3.0;

      /* During 'ShotSet': '<S20>:236' */
      if (may23_B.ArraySelector[(int32_T)may23_B.start_target_row - 1] == 0.0) {
        /* Transition: '<S20>:238' */
        may23_B.event_code = E_START_TARGET_ON;
        may23_DW.is_Main_Trial = may23_IN_StartOn;
        may23_DW.temporalCounter_i1 = 0U;

        /* Entry 'StartOn': '<S20>:4' */
        may23_B.start_target_state = 1.0;
        may23_B.preshot_area_state = 0.0;
        may23_B.cursor_state = 1.0;
        may23_B.puck_state = 0.0;
        may23_B.barrier_target_state = 0.0;
        may23_B.goal_target_state = 0.0;
      } else {
        if (may23_DW.temporalCounter_i1 >= (uint32_T)ceil(may23_DW.shot_set_time
             / 0.00025 - 2.5000000000000003E-12)) {
          /* Transition: '<S20>:240' */
          may23_B.event_code = E_SHOT_GO;
          may23_DW.is_Main_Trial = may23_IN_Shot;
          may23_DW.temporalCounter_i1 = 0U;

          /* Entry 'Shot': '<S20>:239' */
          may23_B.start_target_state = 0.0;
          may23_B.cursor_state = 2.0;
          may23_B.puck_state = 2.0;
          may23_B.goal_target_state = 2.0;
          may23_B.barrier_target_state = 2.0;
        }
      }
      break;

     case may23_IN_StartHold:
      /* During 'StartHold': '<S20>:181' */
      if (may23_B.ArraySelector[(int32_T)may23_B.start_target_row - 1] == 0.0) {
        /* Transition: '<S20>:175' */
        may23_B.event_code = E_START_TARGET_ON;
        may23_DW.is_Main_Trial = may23_IN_StartOn;
        may23_DW.temporalCounter_i1 = 0U;

        /* Entry 'StartOn': '<S20>:4' */
        may23_B.start_target_state = 1.0;
        may23_B.preshot_area_state = 0.0;
        may23_B.cursor_state = 1.0;
        may23_B.puck_state = 0.0;
        may23_B.barrier_target_state = 0.0;
        may23_B.goal_target_state = 0.0;
      } else {
        if (may23_DW.temporalCounter_i1 >= (uint32_T)ceil
            (may23_DW.start_hold_time / 0.00025 - 2.5000000000000003E-12)) {
          /* Transition: '<S20>:229' */
          may23_B.event_code = E_TRIAL_START;
          may23_DW.is_Main_Trial = may23_IN_PreshotStart;

          /* Entry 'PreshotStart': '<S20>:222' */
          may23_B.preshot_area_state = 1.0;
          may23_B.start_target_state = 2.0;
          may23_B.puck_state = 1.0;
          may23_B.goal_target_state = 1.0;
          may23_B.barrier_target_state = 1.0;

          /* Event: '<S20>:266' */
          may23_DW.e_Trial_StartEventCounter++;
        }
      }
      break;

     case may23_IN_StartOn:
      may23_B.start_target_state = 1.0;
      may23_B.preshot_area_state = 0.0;
      may23_B.cursor_state = 1.0;
      may23_B.puck_state = 0.0;
      may23_B.barrier_target_state = 0.0;
      may23_B.goal_target_state = 0.0;

      /* During 'StartOn': '<S20>:4' */
      if (may23_B.ArraySelector[(int32_T)may23_B.start_target_row - 1] == 1.0) {
        /* Transition: '<S20>:174' */
        may23_B.event_code = E_ENTER_START;
        may23_DW.is_Main_Trial = may23_IN_StartHold;
        may23_DW.temporalCounter_i1 = 0U;

        /* Entry 'StartHold': '<S20>:181' */
      } else {
        if (may23_DW.temporalCounter_i1 >= (uint32_T)ceil
            (may23_DW.trial_duration / 0.00025 - 2.5000000000000003E-12)) {
          /* Transition: '<S20>:7' */
          may23_DW.is_Main_Trial = may23_IN_NO_ACTIVE_CHILD_l;
          may23_B.event_code = E_TIMEOUT;
          may23_DW.is_c3_may23 = may23_IN_Inter_Trial_State;
          may23_DW.temporalCounter_i1 = 0U;

          /* Entry 'Inter_Trial_State': '<S20>:1' */
          /* Event: '<S20>:25' */
          may23_DW.e_Trial_EndEventCounter++;
        }
      }
      break;

     default:
      may23_Success();
      break;
    }
  }
}

/* Function for Chart: '<Root>/Trial_Control' */
static void may23_chartstep_c3_may23(void)
{
  /* Chart: '<Root>/Trial_Control' */
  /* During: Trial_Control */
  if (may23_DW.is_active_c3_may23 == 0U) {
    /* Entry: Trial_Control */
    may23_DW.is_active_c3_may23 = 1U;

    /* Entry Internal: Trial_Control */
    /* Transition: '<S20>:10' */
    may23_DW.is_c3_may23 = may23_IN_Initialize;

    /* Entry 'Initialize': '<S20>:2' */
    may23_B.logging_enable = true;
    may23_B.start_target_row = may23_B.TPSelector[(int32_T)START_ROW - 1];
    may23_B.preshot_area_row = may23_B.TPSelector[(int32_T)PRESHOT_ROW - 1];
    may23_B.cursor_row = may23_B.TPSelector[(int32_T)CURSOR_ROW - 1];
    may23_B.puck_row = may23_B.TPSelector[(int32_T)PUCK_ROW - 1];
    may23_B.barrier_target_row = may23_B.TPSelector[(int32_T)BARRIER_ROW - 1];
    may23_B.goal_target_row = may23_B.TPSelector[(int32_T)GOAL_ROW - 1];
    may23_B.load_row = may23_B.TPSelector[(int32_T)LOAD_ROW - 1];
    may23_DW.trial_duration = may23_B.TPSelector[(int32_T)SECONDS - 1];
    may23_DW.start_hold_time = may23_B.TPSelector[(int32_T)START_HOLD_TIME - 1];
    may23_DW.shot_ready_time = may23_B.TPSelector[(int32_T)SHOT_READY_TIME - 1];
    may23_DW.shot_set_time = may23_B.TPSelector[(int32_T)SHOT_SET_TIME - 1];
    may23_DW.shot_time = may23_B.TPSelector[(int32_T)SHOT_TIME - 1];
    may23_DW.goal_time = may23_B.TPSelector[(int32_T)GOAL_TIME - 1];
  } else {
    switch (may23_DW.is_c3_may23) {
     case may23_IN_Initialize:
      may23_B.logging_enable = true;

      /* During 'Initialize': '<S20>:2' */
      /* Transition: '<S20>:11' */
      may23_B.event_code = E_START_TARGET_ON;
      may23_DW.is_c3_may23 = may23_IN_Main_Trial;

      /* Entry 'Main_Trial': '<S20>:3' */
      may23_DW.is_Main_Trial = may23_IN_StartOn;
      may23_DW.temporalCounter_i1 = 0U;

      /* Entry 'StartOn': '<S20>:4' */
      may23_B.start_target_state = 1.0;
      may23_B.preshot_area_state = 0.0;
      may23_B.cursor_state = 1.0;
      may23_B.puck_state = 0.0;
      may23_B.barrier_target_state = 0.0;
      may23_B.goal_target_state = 0.0;
      break;

     case may23_IN_Inter_Trial_State:
      /* During 'Inter_Trial_State': '<S20>:1' */
      if (may23_DW.temporalCounter_i1 >= 4000U) {
        /* Transition: '<S20>:12' */
        may23_B.event_code = E_START_TARGET_ON;
        may23_DW.is_c3_may23 = may23_IN_Main_Trial;

        /* Entry 'Main_Trial': '<S20>:3' */
        may23_DW.is_Main_Trial = may23_IN_StartOn;
        may23_DW.temporalCounter_i1 = 0U;

        /* Entry 'StartOn': '<S20>:4' */
        may23_B.start_target_state = 1.0;
        may23_B.preshot_area_state = 0.0;
        may23_B.cursor_state = 1.0;
        may23_B.puck_state = 0.0;
        may23_B.barrier_target_state = 0.0;
        may23_B.goal_target_state = 0.0;
      }
      break;

     default:
      may23_Main_Trial();
      break;
    }
  }

  /* End of Chart: '<Root>/Trial_Control' */
}

/* Function for MATLAB Function: '<S337>/MATLAB Function' */
static real_T may23_sum(const real_T x[50])
{
  real_T y;
  int32_T k;
  y = x[0];
  for (k = 0; k < 49; k++) {
    y += x[k + 1];
  }

  return y;
}

/* Function for Chart: '<S21>/Collision Resolution' */
static real_T may23_check_collision(const real_T cursor_vcode[140], const real_T
  puck_vcode[70], const real_T puck_offset[2])
{
  real_T colliding_target;
  real_T delta_loc;
  real_T z1_idx_0;

  /* MATLAB Function 'check_collision': '<S400>:47' */
  /* '<S400>:47:24' */
  /* '<S400>:47:17' */
  /* '<S400>:47:18' */
  /* '<S400>:47:20' */
  colliding_target = 0.0;

  /* '<S400>:47:24' */
  /* '<S400>:47:26' */
  /* '<S400>:47:27' */
  /* '<S400>:47:29' */
  /* '<S400>:47:30' */
  /* '<S400>:47:31' */
  /* '<S400>:47:33' */
  delta_loc = cursor_vcode[4] - (puck_vcode[2] + puck_offset[0]);
  z1_idx_0 = delta_loc * delta_loc;
  delta_loc = cursor_vcode[6] - (puck_vcode[3] + puck_offset[1]);
  delta_loc *= delta_loc;
  if (sqrt(z1_idx_0 + delta_loc) < cursor_vcode[18] + puck_vcode[9]) {
    /* '<S400>:47:38' */
    /* '<S400>:47:39' */
    colliding_target = 1.0;
  }

  return colliding_target;
}

/* Function for Chart: '<S21>/Collision Resolution' */
static void may23_eject(const real_T cursor_vcode[70], const real_T puck_vcode
  [70], const real_T puck_offset[2], real_T ejected_puck_offset[2])
{
  real_T current_puck_distance;
  real_T ejected_puck_distance;
  real_T ejected_puck_offset_0;

  /* MATLAB Function 'eject': '<S400>:322' */
  /* '<S400>:322:6' */
  /* '<S400>:322:7' */
  /* '<S400>:322:10' */
  /* '<S400>:322:11' */
  /* '<S400>:322:13' */
  /* '<S400>:322:14' */
  /* '<S400>:322:15' */
  /* '<S400>:322:17' */
  ejected_puck_offset_0 = (puck_vcode[2] + puck_offset[0]) - cursor_vcode[2];
  current_puck_distance = ejected_puck_offset_0 * ejected_puck_offset_0;
  ejected_puck_offset[0] = ejected_puck_offset_0;
  ejected_puck_offset_0 = (puck_vcode[3] + puck_offset[1]) - cursor_vcode[3];
  ejected_puck_distance = ejected_puck_offset_0 * ejected_puck_offset_0;
  ejected_puck_offset[1] = ejected_puck_offset_0;
  current_puck_distance = sqrt(current_puck_distance + ejected_puck_distance);

  /* '<S400>:322:18' */
  ejected_puck_distance = cursor_vcode[9] + puck_vcode[9];

  /* '<S400>:322:20' */
  /* '<S400>:322:21' */
  /* '<S400>:322:23' */
  ejected_puck_offset_0 = ejected_puck_offset[0];
  ejected_puck_offset_0 = (ejected_puck_offset_0 / current_puck_distance *
    ejected_puck_distance + cursor_vcode[2]) - puck_vcode[2];
  ejected_puck_offset[0] = ejected_puck_offset_0;
  ejected_puck_offset_0 = ejected_puck_offset[1];
  ejected_puck_offset_0 = (ejected_puck_offset_0 / current_puck_distance *
    ejected_puck_distance + cursor_vcode[3]) - puck_vcode[3];
  ejected_puck_offset[1] = ejected_puck_offset_0;
}

/* Function for Chart: '<S21>/Collision Resolution' */
static real_T may23_check_collision_g(const real_T cursor_vcode[70], const
  real_T puck_vcode[70], const real_T puck_offset[2])
{
  real_T colliding_target;
  real_T delta_loc;
  real_T z1_idx_0;

  /* MATLAB Function 'check_collision': '<S400>:47' */
  /* '<S400>:47:17' */
  /* '<S400>:47:18' */
  /* '<S400>:47:20' */
  colliding_target = 0.0;

  /* '<S400>:47:26' */
  /* '<S400>:47:27' */
  /* '<S400>:47:29' */
  /* '<S400>:47:30' */
  /* '<S400>:47:31' */
  /* '<S400>:47:33' */
  delta_loc = cursor_vcode[2] - (puck_vcode[2] + puck_offset[0]);
  z1_idx_0 = delta_loc * delta_loc;
  delta_loc = cursor_vcode[3] - (puck_vcode[3] + puck_offset[1]);
  delta_loc *= delta_loc;
  if (sqrt(z1_idx_0 + delta_loc) < cursor_vcode[9] + puck_vcode[9]) {
    /* '<S400>:47:38' */
    /* '<S400>:47:39' */
    colliding_target = 1.0;
  }

  return colliding_target;
}

/* Function for Chart: '<S21>/Collision Resolution' */
static void may23_chartstep_c1_may23(void)
{
  int32_T i;
  real_T tmp[70];
  real_T tmp_0[2];
  int32_T i_0;
  real_T tmp_1;
  real_T tmp_2;

  /* Chart: '<S21>/Collision Resolution' */
  /* During: subsystem for moving the square (updating velocity and checking collision)/Collision Resolution */
  if (may23_DW.is_active_c1_may23 == 0U) {
    /* Entry: subsystem for moving the square (updating velocity and checking collision)/Collision Resolution */
    may23_DW.is_active_c1_may23 = 1U;

    /* Entry Internal: subsystem for moving the square (updating velocity and checking collision)/Collision Resolution */
    /* Transition: '<S400>:10' */
    may23_DW.is_c1_may23 = may23_IN_Initialize;

    /* Entry 'Initialize': '<S400>:2' */
    may23_B.force_scaling[0] = 0.0;
    may23_B.force_scaling[1] = 0.0;
    may23_B.force_scaling[2] = 0.0;
    may23_B.force_scaling[3] = 0.0;
    for (i = 0; i < 70; i++) {
      may23_B.puck_vcode_output[i] = 0.0;
    }

    may23_DW.puck_velocity[0] = 0.0;
    may23_DW.puck_offset_position[0] = 0.0;
    may23_DW.puck_velocity[1] = 0.0;
    may23_DW.puck_offset_position[1] = 0.0;
    may23_DW.puck_damping = may23_B.TPSelector[(int32_T)PUCK_DAMPING - 1];
  } else if (may23_DW.is_c1_may23 == may23_IN_Initialize) {
    /* During 'Initialize': '<S400>:2' */
    /* Transition: '<S400>:11' */
    may23_DW.is_c1_may23 = may23_IN_Moving_Targets_and_Colliding_Them;

    /* Entry 'Moving_Targets_and_Colliding_Them': '<S400>:3' */
    may23_DW.is_active_UpdatePosition = 1U;

    /* Entry 'UpdatePosition': '<S400>:337' */
    may23_DW.is_active_UpdateVelocity = 1U;

    /* Entry 'UpdateVelocity': '<S400>:349' */
    may23_DW.is_active_CollisionWithHand = 1U;

    /* Entry 'CollisionWithHand': '<S400>:159' */
    may23_DW.is_CollisionWithHand = may23_IN_StartWithSpeed0;

    /* Entry 'StartWithSpeed0': '<S400>:52' */
    may23_DW.puck_velocity[0] = 0.0;
    may23_DW.puck_offset_position[0] = 0.0;
    may23_DW.puck_velocity[1] = 0.0;
    may23_DW.puck_offset_position[1] = 0.0;
  } else {
    /* During 'Moving_Targets_and_Colliding_Them': '<S400>:3' */
    /* During 'UpdatePosition': '<S400>:337' */
    memcpy(&may23_B.puck_vcode_output[0],
           &may23_B.sf_EmbeddedMATLABFunction_a.VCODE[0], 70U * sizeof(real_T));
    may23_DW.puck_offset_position[0] += may23_DW.puck_velocity[0];
    may23_DW.puck_offset_position[1] += may23_DW.puck_velocity[1];
    tmp_1 = may23_B.puck_vcode_output[2] + may23_DW.puck_offset_position[0];
    tmp_2 = may23_B.puck_vcode_output[3] + may23_DW.puck_offset_position[1];
    may23_B.puck_vcode_output[2] = tmp_1;
    may23_B.puck_vcode_output[3] = tmp_2;

    /* During 'UpdateVelocity': '<S400>:349' */
    may23_DW.puck_velocity[0] *= may23_DW.puck_damping;
    may23_DW.puck_velocity[1] *= may23_DW.puck_damping;

    /* During 'CollisionWithHand': '<S400>:159' */
    switch (may23_DW.is_CollisionWithHand) {
     case may23_IN_PuckMoving_b:
      /* During 'PuckMoving': '<S400>:353' */
      tmp_1 = may23_DW.puck_velocity[0] * may23_DW.puck_velocity[0];
      tmp_2 = may23_DW.puck_velocity[1] * may23_DW.puck_velocity[1];
      if (tmp_1 + tmp_2 < 2.2204460492503131E-16) {
        /* Transition: '<S400>:354' */
        may23_DW.is_CollisionWithHand = may23_IN_PuckStopped;

        /* Entry 'PuckStopped': '<S400>:355' */
        /* Event: '<S400>:356' */
        may23_DW.e_Puck_StoppedEventCounter++;
      }
      break;

     case may23_IN_PuckStopped:
      /* During 'PuckStopped': '<S400>:355' */
      if (may23_DW.sfEvent == may23_event_e_Trial_Start) {
        /* Transition: '<S400>:357' */
        may23_DW.is_CollisionWithHand = may23_IN_StartWithSpeed0;

        /* Entry 'StartWithSpeed0': '<S400>:52' */
        may23_DW.puck_velocity[0] = 0.0;
        may23_DW.puck_offset_position[0] = 0.0;
        may23_DW.puck_velocity[1] = 0.0;
        may23_DW.puck_offset_position[1] = 0.0;
      }
      break;

     case may23_IN_ResolveTargetCollision:
      /* During 'ResolveTargetCollision': '<S400>:45' */
      i = (int32_T)may23_DW.target_colliding;
      for (i_0 = 0; i_0 < 70; i_0++) {
        tmp[i_0] = may23_B.hand_vcodes[((i_0 << 1) + i) - 1];
      }

      tmp_1 = may23_check_collision_g(tmp,
        may23_B.sf_EmbeddedMATLABFunction_a.VCODE, may23_DW.puck_offset_position);
      if (!(tmp_1 != 0.0)) {
        /* Transition: '<S400>:49' */
        may23_DW.target_colliding = 0.0;
        may23_DW.is_CollisionWithHand = may23_IN_PuckMoving_b;

        /* Entry 'PuckMoving': '<S400>:353' */
      } else {
        if (may23_DW.sfEvent == may23_event_e_Trial_Start) {
          /* Transition: '<S400>:352' */
          may23_DW.is_CollisionWithHand = may23_IN_StartWithSpeed0;

          /* Entry 'StartWithSpeed0': '<S400>:52' */
          may23_DW.puck_velocity[0] = 0.0;
          may23_DW.puck_offset_position[0] = 0.0;
          may23_DW.puck_velocity[1] = 0.0;
          may23_DW.puck_offset_position[1] = 0.0;
        }
      }
      break;

     case may23_IN_StartWithSpeed0:
      /* During 'StartWithSpeed0': '<S400>:52' */
      /* Transition: '<S400>:53' */
      may23_DW.is_CollisionWithHand = may23_IN_WaitForCollision;

      /* Entry 'WaitForCollision': '<S400>:4' */
      may23_B.force_scaling[0] = 0.0;
      may23_B.force_scaling[1] = 0.0;
      may23_B.force_scaling[2] = 0.0;
      may23_B.force_scaling[3] = 0.0;
      break;

     default:
      /* During 'WaitForCollision': '<S400>:4' */
      if (may23_DW.target_colliding != 0.0) {
        /* Transition: '<S400>:117' */
        may23_DW.is_CollisionWithHand = may23_IN_ResolveTargetCollision;

        /* Entry 'ResolveTargetCollision': '<S400>:45' */
        i = (int32_T)may23_DW.target_colliding;
        for (i_0 = 0; i_0 < 70; i_0++) {
          tmp[i_0] = may23_B.hand_vcodes[((i_0 << 1) + i) - 1];
        }

        tmp_0[0] = may23_DW.puck_offset_position[0];
        may23_DW.prev_vel[0] = may23_DW.puck_velocity[0];
        tmp_0[1] = may23_DW.puck_offset_position[1];
        may23_DW.prev_vel[1] = may23_DW.puck_velocity[1];
        may23_eject(tmp, may23_B.sf_EmbeddedMATLABFunction_a.VCODE, tmp_0,
                    may23_DW.puck_offset_position);
        i = (int32_T)may23_DW.target_colliding;
        tmp_1 = (may23_B.getrectanglemass - may23_B.gethandmass) /
          (may23_B.getrectanglemass + may23_B.gethandmass);
        tmp_2 = 2.0 * may23_B.gethandmass / (may23_B.gethandmass +
          may23_B.getrectanglemass);
        may23_DW.hand_vel[0] = may23_B.hand_vcodes_e[i - 1] / 1000.0;
        may23_DW.puck_velocity[0] = tmp_1 * may23_DW.puck_velocity[0] + tmp_2 *
          may23_DW.hand_vel[0];
        may23_DW.hand_vector[0] = 1.0;
        may23_DW.hand_vel[1] = may23_B.hand_vcodes_e[i + 1] / 1000.0;
        may23_DW.puck_velocity[1] = tmp_1 * may23_DW.puck_velocity[1] + tmp_2 *
          may23_DW.hand_vel[1];
        may23_DW.hand_vector[1] = 2.0;
        may23_B.force_scaling[(int32_T)may23_DW.hand_vector[0] - 1] =
          may23_DW.prev_vel[0] - may23_DW.puck_velocity[0];
        may23_B.force_scaling[(int32_T)may23_DW.hand_vector[1] - 1] =
          may23_DW.prev_vel[1] - may23_DW.puck_velocity[1];

        /* Event: '<S400>:358' */
        may23_DW.e_Puck_HitEventCounter++;
      } else if (may23_DW.sfEvent == may23_event_e_Trial_Start) {
        /* Transition: '<S400>:336' */
        may23_DW.is_CollisionWithHand = may23_IN_StartWithSpeed0;

        /* Entry 'StartWithSpeed0': '<S400>:52' */
        may23_DW.puck_velocity[0] = 0.0;
        may23_DW.puck_offset_position[0] = 0.0;
        may23_DW.puck_velocity[1] = 0.0;
        may23_DW.puck_offset_position[1] = 0.0;
      } else {
        may23_B.force_scaling[0] = 0.0;
        may23_B.force_scaling[1] = 0.0;
        may23_B.force_scaling[2] = 0.0;
        may23_B.force_scaling[3] = 0.0;
        may23_DW.target_colliding = may23_check_collision(may23_B.hand_vcodes,
          may23_B.sf_EmbeddedMATLABFunction_a.VCODE,
          may23_DW.puck_offset_position);
      }
      break;
    }
  }

  /* End of Chart: '<S21>/Collision Resolution' */
}

/* Function for Chart: '<S396>/Ramp_up_down' */
static void may23_chartstep_c8_may23(void)
{
  /* Chart: '<S396>/Ramp_up_down' */
  /* During: Subsystem/Perturbation/Ramp_up_down */
  if (may23_DW.is_active_c8_may23 == 0U) {
    /* Entry: Subsystem/Perturbation/Ramp_up_down */
    may23_DW.is_active_c8_may23 = 1U;

    /* Entry Internal: Subsystem/Perturbation/Ramp_up_down */
    /* Transition: '<S398>:6' */
    may23_DW.is_c8_may23 = may23_IN_wait_for_trigger;

    /* Entry 'wait_for_trigger': '<S398>:1' */
    may23_B.scaling = 0.0;
  } else if (may23_DW.is_c8_may23 == may23_IN_Perturbation) {
    /* During 'Perturbation': '<S398>:5' */
    if (may23_DW.sfEvent_i == may23_event_e_reset) {
      /* Transition: '<S398>:15' */
      /* Exit Internal 'Perturbation': '<S398>:5' */
      may23_DW.is_Perturbation = may23_IN_NO_ACTIVE_CHILD_l;
      may23_DW.is_c8_may23 = may23_IN_wait_for_trigger;

      /* Entry 'wait_for_trigger': '<S398>:1' */
      may23_B.scaling = 0.0;
    } else {
      switch (may23_DW.is_Perturbation) {
       case may23_IN_off_ramp:
        /* During 'off_ramp': '<S398>:2' */
        if ((may23_DW.sfEvent_i == may23_event_e_clk_p) &&
            (may23_DW.temporalCounter_i1_n >= (uint32_T)may23_B.perturbation[2]))
        {
          /* Transition: '<S398>:10' */
          may23_DW.is_Perturbation = may23_IN_NO_ACTIVE_CHILD_l;
          may23_DW.is_c8_may23 = may23_IN_wait_for_trigger;

          /* Entry 'wait_for_trigger': '<S398>:1' */
          may23_B.scaling = 0.0;
        } else {
          if (may23_DW.sfEvent_i == may23_event_e_clk_p) {
            may23_DW.tick++;
            may23_B.scaling = 1.0 - may23_DW.tick / may23_B.perturbation[2];
          }
        }
        break;

       case may23_IN_on_ramp:
        /* During 'on_ramp': '<S398>:3' */
        if ((may23_DW.sfEvent_i == may23_event_e_clk_p) &&
            (may23_DW.temporalCounter_i1_n >= (uint32_T)may23_B.perturbation[0]))
        {
          /* Transition: '<S398>:8' */
          if (may23_B.perturbation[1] > 0.0) {
            /* Transition: '<S398>:12' */
            may23_DW.is_Perturbation = may23_IN_peak;
            may23_DW.temporalCounter_i1_n = 0U;

            /* Entry 'peak': '<S398>:4' */
            may23_B.scaling = 1.0;
          } else {
            /* Transition: '<S398>:16' */
            if (may23_B.perturbation[2] > 0.0) {
              /* Transition: '<S398>:13' */
              may23_DW.is_Perturbation = may23_IN_off_ramp;
              may23_DW.temporalCounter_i1_n = 0U;

              /* Entry 'off_ramp': '<S398>:2' */
              may23_DW.tick = 0.0;
              may23_B.scaling = 1.0;
            } else {
              /* Transition: '<S398>:14' */
              may23_DW.is_Perturbation = may23_IN_NO_ACTIVE_CHILD_l;
              may23_DW.is_c8_may23 = may23_IN_wait_for_trigger;

              /* Entry 'wait_for_trigger': '<S398>:1' */
              may23_B.scaling = 0.0;
            }
          }
        } else {
          if (may23_DW.sfEvent_i == may23_event_e_clk_p) {
            may23_DW.tick++;
            may23_B.scaling = may23_DW.tick / may23_B.perturbation[0];
          }
        }
        break;

       default:
        /* During 'peak': '<S398>:4' */
        if ((may23_DW.sfEvent_i == may23_event_e_clk_p) &&
            (may23_DW.temporalCounter_i1_n >= (uint32_T)may23_B.perturbation[1]))
        {
          /* Transition: '<S398>:9' */
          if (may23_B.perturbation[2] > 0.0) {
            /* Transition: '<S398>:13' */
            may23_DW.is_Perturbation = may23_IN_off_ramp;
            may23_DW.temporalCounter_i1_n = 0U;

            /* Entry 'off_ramp': '<S398>:2' */
            may23_DW.tick = 0.0;
            may23_B.scaling = 1.0;
          } else {
            /* Transition: '<S398>:14' */
            may23_DW.is_Perturbation = may23_IN_NO_ACTIVE_CHILD_l;
            may23_DW.is_c8_may23 = may23_IN_wait_for_trigger;

            /* Entry 'wait_for_trigger': '<S398>:1' */
            may23_B.scaling = 0.0;
          }
        }
        break;
      }
    }
  } else {
    /* During 'wait_for_trigger': '<S398>:1' */
    if (may23_DW.sfEvent_i == may23_event_e_trigger) {
      /* Transition: '<S398>:7' */
      if (may23_B.perturbation[0] > 0.0) {
        /* Transition: '<S398>:11' */
        may23_DW.is_c8_may23 = may23_IN_Perturbation;
        may23_DW.is_Perturbation = may23_IN_on_ramp;
        may23_DW.temporalCounter_i1_n = 0U;

        /* Entry 'on_ramp': '<S398>:3' */
        may23_DW.tick = 0.0;
      } else {
        /* Transition: '<S398>:17' */
        if (may23_B.perturbation[1] > 0.0) {
          /* Transition: '<S398>:12' */
          may23_DW.is_c8_may23 = may23_IN_Perturbation;
          may23_DW.is_Perturbation = may23_IN_peak;
          may23_DW.temporalCounter_i1_n = 0U;

          /* Entry 'peak': '<S398>:4' */
          may23_B.scaling = 1.0;
        } else {
          /* Transition: '<S398>:16' */
          if (may23_B.perturbation[2] > 0.0) {
            /* Transition: '<S398>:13' */
            may23_DW.is_c8_may23 = may23_IN_Perturbation;
            may23_DW.is_Perturbation = may23_IN_off_ramp;
            may23_DW.temporalCounter_i1_n = 0U;

            /* Entry 'off_ramp': '<S398>:2' */
            may23_DW.tick = 0.0;
            may23_B.scaling = 1.0;
          } else {
            /* Transition: '<S398>:14' */
            may23_DW.is_c8_may23 = may23_IN_wait_for_trigger;

            /* Entry 'wait_for_trigger': '<S398>:1' */
            may23_B.scaling = 0.0;
          }
        }
      }
    }
  }

  /* End of Chart: '<S396>/Ramp_up_down' */
}

/* Model output function for TID0 */
static void may23_output0(void)        /* Sample time: [0.0s, 0.0s] */
{
  int32_T inputEventFiredFlag;
  real_T hold_steps;
  real_T x;
  int32_T nz[50];
  int32_T xoffset;
  real32_T ss[2];
  int8_T b_data[4];
  real_T L2ptr_ANG;
  real_T robot_pointer_offset;
  real_T robot_arm_orientation;
  int32_T i;
  real_T tmp[50];
  boolean_T zcEvent;
  int8_T a;
  boolean_T zcEvent_idx_3;
  boolean_T zcEvent_idx_2;
  boolean_T zcEvent_idx_1;
  boolean_T zcEvent_idx_0;
  real_T new_torques_idx_0;
  real_T new_torques_idx_1;
  int8_T c_idx_2;
  int8_T c_idx_1;
  real_T out_of_spec_motors_idx_3;
  real_T out_of_spec_motors_idx_2;
  int8_T c_idx_0;
  ZCEventType zcEvent_idx_1_0;
  ZCEventType zcEvent_idx_0_0;
  uint32_T tmp_0;
  int32_T nz_0;

  {                                    /* Sample time: [0.0s, 0.0s] */
    rate_monotonic_scheduler();
  }

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.UDPSendSubsystem_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.SendControlMachine_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.plate1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.plate2_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.M1AbsEncCalibration_SubsysRanBC_o);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.M2AbsEncCalibration_SubsysRanBC_i);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.Arm1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.M1AbsEncCalibration_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.M2AbsEncCalibration_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.Arm2_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.IfActionSubsystem_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.DataTransferStartSubsystem_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.ReadDPRAM_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.WriteDPRAM_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.read_pmac_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.Datareceive_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.updateconstantssubsystem_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.Datawrite_SubsysRanBC_h);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.update_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.updatesettings_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.Datawrite_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.createKINData_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.EtherCATApplyLoads_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.applypmacloads_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.torque_monitor_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.TaskExecutionControlMachine_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.enable_tables_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.sf_Ramp_Up_Down.Ramp_Up_Down_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.sf_Ramp_Up_Down_g.Ramp_Up_Down_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.Ramp_up_down_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.Trial_Control_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.CollisionResolution_SubsysRanBC);

  /* S-Function (ich10): '<S3>/ICH7' */

  /* Level2 S-Function Block: '<S3>/ICH7' (ich10) */
  {
    SimStruct *rts = may23_M->childSfunctions[40];
    sfcnOutputs(rts,0);
  }

  /* UnitDelay: '<S347>/Delay Input1' */
  may23_B.Uk1_e = may23_DW.DelayInput1_DSTATE_c;

  /* Memory: '<S336>/Delay1' */
  may23_B.Delay1 = may23_DW.Delay1_PreviousInput;

  /* Product: '<S336>/Product3' incorporates:
   *  Constant: '<S3>/Use Repeat Trial Flag'
   */
  may23_B.Product3 = may23_B.Delay1 * may23_P.UseRepeatTrialFlag_Value;

  /* S-Function (slrtUDPReceive): '<S335>/Run Command Receive' */

  /* Level2 S-Function Block: '<S335>/Run Command Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[41];
    sfcnOutputs(rts,0);
  }

  /* DataTypeConversion: '<S335>/Data Type Conversion' */
  may23_B.DataTypeConversion = may23_B.RunCommandReceive_o1;

  /* MATLAB Function: '<S335>/Embedded MATLAB Function' */
  /* MATLAB Function 'GUI Control/Run Command Subsystem/Embedded MATLAB Function': '<S341>:1' */
  if ((may23_B.DataTypeConversion < 2.0) && (may23_DW.u !=
       may23_B.DataTypeConversion)) {
    /* '<S341>:1:18' */
    /* '<S341>:1:19' */
    may23_DW.u = may23_B.DataTypeConversion;
  }

  /* '<S341>:1:22' */
  may23_B.y_o = may23_DW.u;
  if ((may23_B.DataTypeConversion > 1.0) && (may23_B.DataTypeConversion !=
       may23_DW.v)) {
    /* '<S341>:1:26' */
    /* '<S341>:1:27' */
    may23_DW.v = may23_B.DataTypeConversion;
    if (may23_DW.v == 255.0) {
      /* '<S341>:1:28' */
      /* '<S341>:1:29' */
      may23_B.z = 0.0;
    } else {
      /* '<S341>:1:31' */
      may23_B.z = may23_DW.v;
    }
  } else {
    /* '<S341>:1:34' */
    may23_B.z = 0.0;
  }

  /* End of MATLAB Function: '<S335>/Embedded MATLAB Function' */

  /* DataTypeConversion: '<S335>/Data Type Conversion1' */
  hold_steps = floor(may23_B.y_o);
  if (rtIsNaN(hold_steps) || rtIsInf(hold_steps)) {
    hold_steps = 0.0;
  } else {
    hold_steps = fmod(hold_steps, 256.0);
  }

  may23_B.DataTypeConversion1_fy = (uint8_T)(hold_steps < 0.0 ? (int32_T)
    (uint8_T)-(int8_T)(uint8_T)-hold_steps : (int32_T)(uint8_T)hold_steps);

  /* End of DataTypeConversion: '<S335>/Data Type Conversion1' */

  /* Constant: '<S3>/Pause Type' */
  may23_B.PauseType = may23_P.PauseType_Value;

  /* DataTypeConversion: '<S3>/Convert18' incorporates:
   *  Constant: '<S3>/Seed'
   */
  may23_B.Convert18 = may23_P.Seed_Value;

  /* DataTypeConversion: '<S336>/Data Type Conversion3' */
  hold_steps = floor(may23_B.Convert18);
  if (rtIsNaN(hold_steps) || rtIsInf(hold_steps)) {
    hold_steps = 0.0;
  } else {
    hold_steps = fmod(hold_steps, 4.294967296E+9);
  }

  may23_B.DataTypeConversion3_m = hold_steps < 0.0 ? (uint32_T)-(int32_T)
    (uint32_T)-hold_steps : (uint32_T)hold_steps;

  /* End of DataTypeConversion: '<S336>/Data Type Conversion3' */

  /* UnitDelay: '<S350>/Output' */
  may23_B.Output = may23_DW.Output_DSTATE;

  /* RelationalOperator: '<S349>/Compare' incorporates:
   *  Constant: '<S349>/Constant'
   */
  may23_B.Compare_e = (may23_B.Output == may23_P.CompareToConstant_const_f);

  /* Outputs for Enabled SubSystem: '<S340>/enable_tables' incorporates:
   *  EnablePort: '<S351>/Enable'
   */
  if (may23_B.Compare_e) {
    /* Constant: '<S351>/Block Definitions' */
    memcpy(&may23_B.BlockDefinitions[0], &may23_P.BlockDefinitions_Value[0],
           25000U * sizeof(real_T));

    /* Constant: '<S351>/Block Sequence' */
    memcpy(&may23_B.BlockSequence[0], &may23_P.BlockSequence_Value[0], 3000U *
           sizeof(real_T));

    /* Constant: '<S351>/TP Table' */
    memcpy(&may23_B.TPTable[0], &may23_P.TPTable_Value[0], 5000U * sizeof(real_T));

    /* Constant: '<S351>/Target Labels' */
    memcpy(&may23_B.TargetLabels[0], &may23_P.TargetLabels_Value[0], 3200U *
           sizeof(real_T));

    /* Constant: '<S351>/Target Table' */
    memcpy(&may23_B.TargetTable[0], &may23_P.TargetTable_Value[0], 1600U *
           sizeof(real_T));

    /* Constant: '<S351>/Load Table' */
    memcpy(&may23_B.LoadTable[0], &may23_P.LoadTable_Value[0], 400U * sizeof
           (real_T));

    /* Constant: '<S351>/Task wide param' */
    memcpy(&may23_B.Taskwideparam[0], &may23_P.Taskwideparam_Value[0], 50U *
           sizeof(real_T));
    srUpdateBC(may23_DW.enable_tables_SubsysRanBC);
  }

  /* End of Outputs for SubSystem: '<S340>/enable_tables' */

  /* Sum: '<S336>/Subtract' incorporates:
   *  Constant: '<S336>/Constant'
   */
  hold_steps = floor((real_T)may23_ConstB.Width1 - may23_P.Constant_Value_l);
  if (rtIsNaN(hold_steps) || rtIsInf(hold_steps)) {
    hold_steps = 0.0;
  } else {
    hold_steps = fmod(hold_steps, 4.294967296E+9);
  }

  may23_B.Subtract_a = hold_steps < 0.0 ? (uint32_T)-(int32_T)(uint32_T)
    -hold_steps : (uint32_T)hold_steps;

  /* End of Sum: '<S336>/Subtract' */

  /* Constant: '<S3>/Use custom TP sequence' */
  may23_B.UsecustomTPsequence = may23_P.UsecustomTPsequence_Value;

  /* Memory: '<S3>/Memory' */
  may23_B.Memory = may23_DW.Memory_PreviousInput;

  /* MATLAB Function: '<S336>/MATLAB Function' incorporates:
   *  Constant: '<S336>/Constant1'
   */
  hold_steps = may23_B.Memory;

  /* MATLAB Function 'GUI Control/Task Execution Control Subsystem/MATLAB Function': '<S344>:1' */
  if (may23_B.Memory > may23_P.GUIControl_tp_table_rows) {
    /* '<S344>:1:4' */
    /* '<S344>:1:5' */
    hold_steps = -1.0;
  }

  /* '<S344>:1:8' */
  may23_B.tp_out = hold_steps;

  /* End of MATLAB Function: '<S336>/MATLAB Function' */

  /* DiscretePulseGenerator: '<S336>/Task Clock' */
  may23_B.TaskClock = (may23_DW.clockTickCounter < may23_P.TaskClock_Duty_p) &&
    (may23_DW.clockTickCounter >= 0) ? may23_P.TaskClock_Amp_b : 0.0;
  if (may23_DW.clockTickCounter >= may23_P.TaskClock_Period_f - 1.0) {
    may23_DW.clockTickCounter = 0;
  } else {
    may23_DW.clockTickCounter++;
  }

  /* End of DiscretePulseGenerator: '<S336>/Task Clock' */

  /* Product: '<S336>/Product' incorporates:
   *  Constant: '<S3>/Run Task Clock Flag'
   */
  may23_B.Product = may23_P.RunTaskClockFlag_Value * may23_B.TaskClock;

  /* Memory: '<S336>/Delay' */
  may23_B.Delay_h = may23_DW.Delay_PreviousInput;

  /* DataTypeConversion: '<S336>/Data Type Conversion' */
  may23_B.DataTypeConversion_p = may23_B.Delay_h;

  /* Chart: '<S336>/Task Execution Control Machine' incorporates:
   *  TriggerPort: '<S345>/ input events '
   */
  zcEvent_idx_0_0 = rt_ZCFcn(ANY_ZERO_CROSSING,
    &may23_PrevZCX.TaskExecutionControlMachine_Trig_ZCE[0],
    (may23_B.Product));
  zcEvent_idx_1_0 = rt_ZCFcn(ANY_ZERO_CROSSING,
    &may23_PrevZCX.TaskExecutionControlMachine_Trig_ZCE[1],
    (may23_B.DataTypeConversion_p));
  zcEvent = (zcEvent_idx_0_0 != NO_ZCEVENT);
  zcEvent = (zcEvent || (zcEvent_idx_1_0 != NO_ZCEVENT));
  if (zcEvent) {
    may23_B.inputevents_l[0] = (int8_T)zcEvent_idx_0_0;
    may23_B.inputevents_l[1] = (int8_T)zcEvent_idx_1_0;

    /* Gateway: GUI Control/Task Execution Control Subsystem/Task Execution Control Machine */
    inputEventFiredFlag = 0;
    if (may23_B.inputevents_l[0U] != 0) {
      inputEventFiredFlag = 1;
      if (may23_DW.temporalCounter_i1_h < 3U) {
        may23_DW.temporalCounter_i1_h++;
      }

      /* Event: '<S345>:130' */
      may23_DW.sfEvent_j = may23_event_e_clk_p;
      may23_chartstep_c42_General();
    }

    if (may23_B.inputevents_l[1U] != 0) {
      inputEventFiredFlag = 1;

      /* Event: '<S345>:131' */
      may23_DW.sfEvent_j = may23_event_e_trial_over;
      may23_chartstep_c42_General();
    }

    if ((inputEventFiredFlag != 0) && (may23_DW.e_exit_trialEventCounter > 0U))
    {
      may23_B.e_exit_trial = !may23_B.e_exit_trial;
      may23_DW.e_exit_trialEventCounter--;
    }

    may23_DW.TaskExecutionControlMachine_SubsysRanBC = 4;
  }

  /* RelationalOperator: '<S347>/FixPt Relational Operator' */
  may23_B.FixPtRelationalOperator_g = (may23_B.e_exit_trial != may23_B.Uk1_e);

  /* UnitDelay: '<S348>/Delay Input1' */
  may23_B.Uk1_h = may23_DW.DelayInput1_DSTATE_a;

  /* DataTypeConversion: '<S3>/Convert24' */
  may23_B.Convert24 = may23_B.tp;

  /* MinMax: '<S3>/MinMax' incorporates:
   *  Constant: '<S3>/Constant'
   */
  x = may23_B.Convert24;
  hold_steps = may23_P.Constant_Value_d;
  if ((x > hold_steps) || rtIsNaN(hold_steps)) {
    hold_steps = x;
  }

  may23_B.MinMax = hold_steps;

  /* End of MinMax: '<S3>/MinMax' */

  /* Selector: '<S3>/TP Selector' */
  i = (int32_T)may23_B.MinMax;
  for (inputEventFiredFlag = 0; inputEventFiredFlag < 50; inputEventFiredFlag++)
  {
    may23_B.TPSelector[inputEventFiredFlag] = may23_B.TPTable[(100 *
      inputEventFiredFlag + i) - 1];
  }

  /* End of Selector: '<S3>/TP Selector' */

  /* Outputs for Atomic SubSystem: '<S1>/Receive_Gaze' */
  may23_Receive_GazeTID0();

  /* End of Outputs for SubSystem: '<S1>/Receive_Gaze' */

  /* Memory: '<S1>/Memory' */
  may23_B.Memory_d[0] = may23_DW.Memory_PreviousInput_m[0];
  may23_B.Memory_d[1] = may23_DW.Memory_PreviousInput_m[1];
  may23_B.Memory_d[2] = may23_DW.Memory_PreviousInput_m[2];
  may23_B.Memory_d[3] = may23_DW.Memory_PreviousInput_m[3];

  /* DataTypeConversion: '<S3>/Convert20' */
  may23_B.Convert20 = may23_B.task_status;

  /* Memory: '<S9>/Memory' */
  may23_B.Memory_m = may23_DW.Memory_PreviousInput_f;

  /* Gain: '<S9>/Gain' */
  may23_B.Gain = may23_P.Gain_Gain_g * may23_B.Memory_m;

  /* Memory: '<S38>/Memory2' */
  may23_B.Memory2 = may23_DW.Memory2_PreviousInput;

  /* Outputs for Atomic SubSystem: '<S1>/Poll KINARM' */
  may23_PollKINARMTID0();

  /* End of Outputs for SubSystem: '<S1>/Poll KINARM' */

  /* Switch: '<S7>/Switch' incorporates:
   *  Constant: '<S7>/Use_Dominant_Hand?'
   *  Switch: '<S374>/Switch1'
   */
  if (may23_P.KINARM_HandInTarget_use_dominant_hand > may23_P.Switch_Threshold_j)
  {
    /* Switch: '<S374>/Switch' */
    if (may23_B.active_arm > may23_P.Switch_Threshold_h) {
      may23_B.assessment_hand_pos[0] =
        may23_B.sf_splitKINDataarm2.hand_position[0];
      may23_B.assessment_hand_pos[1] =
        may23_B.sf_splitKINDataarm2.hand_position[1];
    } else {
      may23_B.assessment_hand_pos[0] =
        may23_B.sf_splitKINDataarm1.hand_position[0];
      may23_B.assessment_hand_pos[1] =
        may23_B.sf_splitKINDataarm1.hand_position[1];
    }

    /* End of Switch: '<S374>/Switch' */
    may23_B.Switch[0] = may23_B.assessment_hand_pos[0];
    may23_B.Switch[1] = may23_B.assessment_hand_pos[1];
  } else {
    if (may23_B.active_arm > may23_P.Switch1_Threshold_b) {
      /* Switch: '<S374>/Switch1' */
      may23_B.contralateral_hand_pos[0] =
        may23_B.sf_splitKINDataarm1.hand_position[0];
      may23_B.contralateral_hand_pos[1] =
        may23_B.sf_splitKINDataarm1.hand_position[1];
    } else {
      /* Switch: '<S374>/Switch1' */
      may23_B.contralateral_hand_pos[0] =
        may23_B.sf_splitKINDataarm2.hand_position[0];
      may23_B.contralateral_hand_pos[1] =
        may23_B.sf_splitKINDataarm2.hand_position[1];
    }

    may23_B.Switch[0] = may23_B.contralateral_hand_pos[0];
    may23_B.Switch[1] = may23_B.contralateral_hand_pos[1];
  }

  /* End of Switch: '<S7>/Switch' */

  /* MATLAB Function: '<S7>/Embedded MATLAB InsideTarget' */
  may23_EmbeddedMATLABInsideTarget_d();

  /* Selector: '<S7>/Array Selector' incorporates:
   *  Constant: '<S7>/Selected States'
   */
  i = (int32_T)may23_P.SelectedStates_Value;
  for (inputEventFiredFlag = 0; inputEventFiredFlag < 64; inputEventFiredFlag++)
  {
    may23_B.ArraySelector[inputEventFiredFlag] = may23_B.intarget_d[((i - 1) <<
      6) + inputEventFiredFlag];
  }

  /* End of Selector: '<S7>/Array Selector' */

  /* Switch: '<S6>/Switch' incorporates:
   *  Constant: '<S6>/Use_Dominant_Hand?'
   *  Switch: '<S372>/Switch1'
   */
  if (may23_P.KINARM_HandInBarrier_use_dominant_hand >
      may23_P.Switch_Threshold_b) {
    /* Switch: '<S372>/Switch' */
    if (may23_B.active_arm > may23_P.Switch_Threshold_g) {
      may23_B.assessment_hand_pos_f[0] =
        may23_B.sf_splitKINDataarm2.hand_position[0];
      may23_B.assessment_hand_pos_f[1] =
        may23_B.sf_splitKINDataarm2.hand_position[1];
    } else {
      may23_B.assessment_hand_pos_f[0] =
        may23_B.sf_splitKINDataarm1.hand_position[0];
      may23_B.assessment_hand_pos_f[1] =
        may23_B.sf_splitKINDataarm1.hand_position[1];
    }

    /* End of Switch: '<S372>/Switch' */
    may23_B.Switch_i[0] = may23_B.assessment_hand_pos_f[0];
    may23_B.Switch_i[1] = may23_B.assessment_hand_pos_f[1];
  } else {
    if (may23_B.active_arm > may23_P.Switch1_Threshold_h) {
      /* Switch: '<S372>/Switch1' */
      may23_B.contralateral_hand_pos_o[0] =
        may23_B.sf_splitKINDataarm1.hand_position[0];
      may23_B.contralateral_hand_pos_o[1] =
        may23_B.sf_splitKINDataarm1.hand_position[1];
    } else {
      /* Switch: '<S372>/Switch1' */
      may23_B.contralateral_hand_pos_o[0] =
        may23_B.sf_splitKINDataarm2.hand_position[0];
      may23_B.contralateral_hand_pos_o[1] =
        may23_B.sf_splitKINDataarm2.hand_position[1];
    }

    may23_B.Switch_i[0] = may23_B.contralateral_hand_pos_o[0];
    may23_B.Switch_i[1] = may23_B.contralateral_hand_pos_o[1];
  }

  /* End of Switch: '<S6>/Switch' */

  /* MATLAB Function: '<S6>/Embedded MATLAB InsideTarget' */
  may23_EmbeddedMATLABInsideTarget();

  /* Selector: '<S6>/Array Selector' incorporates:
   *  Constant: '<S6>/Selected States'
   */
  i = (int32_T)may23_P.SelectedStates_Value_b;
  for (inputEventFiredFlag = 0; inputEventFiredFlag < 64; inputEventFiredFlag++)
  {
    may23_B.ArraySelector_b[inputEventFiredFlag] = may23_B.intarget_j[((i - 1) <<
      6) + inputEventFiredFlag];
  }

  /* End of Selector: '<S6>/Array Selector' */

  /* Memory: '<Root>/Memory2' */
  memcpy(&may23_B.Memory2_c[0], &may23_DW.Memory2_PreviousInput_c[0], 70U *
         sizeof(real_T));

  /* Selector: '<S12>/Selector' */
  may23_B.Selector[0] = may23_B.Memory2_c[2];
  may23_B.Selector[1] = may23_B.Memory2_c[3];

  /* MATLAB Function: '<S12>/Embedded MATLAB InsideTarget' */
  may23_EmbeddedMATLABInsideTarget_m();

  /* Selector: '<S12>/Array Selector' incorporates:
   *  Constant: '<S12>/Selected States'
   */
  i = (int32_T)may23_P.SelectedStates_Value_m;
  for (inputEventFiredFlag = 0; inputEventFiredFlag < 64; inputEventFiredFlag++)
  {
    may23_B.ArraySelector_m[inputEventFiredFlag] = may23_B.intarget[((i - 1) <<
      6) + inputEventFiredFlag];
  }

  /* End of Selector: '<S12>/Array Selector' */

  /* Selector: '<S10>/Selector' */
  may23_B.Selector_n[0] = may23_B.Memory2_c[2];
  may23_B.Selector_n[1] = may23_B.Memory2_c[3];

  /* MATLAB Function: '<S10>/Embedded MATLAB InsideTarget' */
  may23_EmbeddedMATLABInsideTarget_b();

  /* Selector: '<S10>/Array Selector' incorporates:
   *  Constant: '<S10>/Selected States'
   */
  i = (int32_T)may23_P.SelectedStates_Value_n;
  for (inputEventFiredFlag = 0; inputEventFiredFlag < 64; inputEventFiredFlag++)
  {
    may23_B.ArraySelector_c[inputEventFiredFlag] = may23_B.intarget_g[((i - 1) <<
      6) + inputEventFiredFlag];
  }

  /* End of Selector: '<S10>/Array Selector' */

  /* Selector: '<S11>/Selector' */
  may23_B.Selector_g[0] = may23_B.Memory2_c[2];

  /* DataTypeConversion: '<S3>/Convert9' incorporates:
   *  Constant: '<S3>/Display Size (m)'
   */
  may23_B.Convert9[0] = may23_P.DisplaySizem_Value[0];

  /* Selector: '<S11>/Selector' */
  may23_B.Selector_g[1] = may23_B.Memory2_c[3];

  /* DataTypeConversion: '<S3>/Convert9' incorporates:
   *  Constant: '<S3>/Display Size (m)'
   */
  may23_B.Convert9[1] = may23_P.DisplaySizem_Value[1];

  /* MATLAB Function: '<S11>/MATLAB Function' */
  /* MATLAB Function 'PuckInDisplay/MATLAB Function': '<S387>:1' */
  /* '<S387>:1:4' */
  /* '<S387>:1:5' */
  /* '<S387>:1:7' */
  /* '<S387>:1:8' */
  /* '<S387>:1:10' */
  may23_B.indisplay = 1.0;
  if (may23_B.Selector_g[0] < -may23_B.Convert9[0] / 2.0) {
    /* '<S387>:1:13' */
    /* '<S387>:1:14' */
    may23_B.indisplay = 0.0;
  }

  if (may23_B.Selector_g[0] > may23_B.Convert9[0] / 2.0) {
    /* '<S387>:1:17' */
    /* '<S387>:1:18' */
    may23_B.indisplay = 0.0;
  }

  if (may23_B.Selector_g[1] > may23_B.Convert9[1]) {
    /* '<S387>:1:21' */
    /* '<S387>:1:22' */
    may23_B.indisplay = 0.0;
  }

  if (may23_B.Selector_g[1] < 0.0) {
    /* '<S387>:1:25' */
    /* '<S387>:1:26' */
    may23_B.indisplay = 0.0;
  }

  /* End of MATLAB Function: '<S11>/MATLAB Function' */

  /* RelationalOperator: '<S343>/Compare' incorporates:
   *  Constant: '<S343>/Constant'
   */
  may23_B.Compare = (uint8_T)(may23_B.task_status ==
    may23_P.CompareToConstant_const_g);

  /* Product: '<S336>/Product2' */
  may23_B.Product2 = may23_B.Product * (real_T)may23_B.Compare;

  /* DataTypeConversion: '<S336>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_jo = (may23_B.Product2 != 0.0);

  /* Memory: '<Root>/Memory1' */
  may23_B.Memory1_k = may23_DW.Memory1_PreviousInput_lw;

  /* DataTypeConversion: '<Root>/Data Type Conversion' */
  may23_B.DataTypeConversion_j0 = may23_B.Memory1_k;

  /* Memory: '<Root>/Memory4' */
  may23_B.Memory4 = may23_DW.Memory4_PreviousInput;

  /* DataTypeConversion: '<Root>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_pz = may23_B.Memory4;

  /* Chart: '<Root>/Trial_Control' incorporates:
   *  TriggerPort: '<S20>/input events'
   */
  zcEvent_idx_0 = (((may23_PrevZCX.Trial_Control_Trig_ZCE[0] == POS_ZCSIG) !=
                    (int32_T)may23_B.DataTypeConversion1_jo) &&
                   (may23_PrevZCX.Trial_Control_Trig_ZCE[0] !=
                    UNINITIALIZED_ZCSIG));
  zcEvent_idx_1 = (((may23_PrevZCX.Trial_Control_Trig_ZCE[1] == POS_ZCSIG) !=
                    (int32_T)may23_B.e_exit_trial) &&
                   (may23_PrevZCX.Trial_Control_Trig_ZCE[1] !=
                    UNINITIALIZED_ZCSIG));
  zcEvent_idx_2 = (((may23_PrevZCX.Trial_Control_Trig_ZCE[2] == POS_ZCSIG) !=
                    (int32_T)may23_B.DataTypeConversion_j0) &&
                   (may23_PrevZCX.Trial_Control_Trig_ZCE[2] !=
                    UNINITIALIZED_ZCSIG));
  zcEvent_idx_3 = (((may23_PrevZCX.Trial_Control_Trig_ZCE[3] == POS_ZCSIG) !=
                    (int32_T)may23_B.DataTypeConversion1_pz) &&
                   (may23_PrevZCX.Trial_Control_Trig_ZCE[3] !=
                    UNINITIALIZED_ZCSIG));
  zcEvent = zcEvent_idx_0;
  zcEvent = (zcEvent || zcEvent_idx_1);
  zcEvent = (zcEvent || zcEvent_idx_2);
  zcEvent = (zcEvent || zcEvent_idx_3);
  if (zcEvent) {
    may23_B.inputevents_n[0] = (int8_T)(zcEvent_idx_0 ?
      may23_B.DataTypeConversion1_jo ? RISING_ZCEVENT : FALLING_ZCEVENT :
      NO_ZCEVENT);
    may23_B.inputevents_n[1] = (int8_T)(zcEvent_idx_1 ? may23_B.e_exit_trial ?
      RISING_ZCEVENT : FALLING_ZCEVENT : NO_ZCEVENT);
    may23_B.inputevents_n[2] = (int8_T)(zcEvent_idx_2 ?
      may23_B.DataTypeConversion_j0 ? RISING_ZCEVENT : FALLING_ZCEVENT :
      NO_ZCEVENT);
    may23_B.inputevents_n[3] = (int8_T)(zcEvent_idx_3 ?
      may23_B.DataTypeConversion1_pz ? RISING_ZCEVENT : FALLING_ZCEVENT :
      NO_ZCEVENT);
    may23_DW.presentTicks = may23_M->Timing.clockTick1;
    may23_DW.elapsedTicks = may23_DW.presentTicks - may23_DW.previousTicks;
    may23_DW.previousTicks = may23_DW.presentTicks;
    may23_DW.temporalCounter_i1 += may23_DW.elapsedTicks;

    /* Gateway: Trial_Control */
    inputEventFiredFlag = 0;
    if (may23_B.inputevents_n[0U] == 1) {
      inputEventFiredFlag = 1;

      /* Event: '<S20>:23' */
      may23_DW.sfEvent_b = may23_event_e_clk_p;
      may23_chartstep_c3_may23();
    }

    if (may23_B.inputevents_n[1U] != 0) {
      inputEventFiredFlag = 1;

      /* Event: '<S20>:24' */
      may23_DW.sfEvent_b = may23_event_e_ExitTrialNow;
      may23_chartstep_c3_may23();
    }

    if (may23_B.inputevents_n[2U] != 0) {
      inputEventFiredFlag = 1;

      /* Event: '<S20>:275' */
      may23_DW.sfEvent_b = may23_event_e_Puck_Stopped;
      may23_chartstep_c3_may23();
    }

    if (may23_B.inputevents_n[3U] != 0) {
      inputEventFiredFlag = 1;

      /* Event: '<S20>:284' */
      may23_DW.sfEvent_b = may23_event_e_Puck_Hit;
      may23_chartstep_c3_may23();
    }

    if ((inputEventFiredFlag != 0) && (may23_DW.e_Trial_StartEventCounter > 0U))
    {
      may23_B.e_Trial_Start = !may23_B.e_Trial_Start;
      may23_DW.e_Trial_StartEventCounter--;
    }

    if ((inputEventFiredFlag != 0) && (may23_DW.e_Trial_EndEventCounter > 0U)) {
      may23_B.e_Trial_End = !may23_B.e_Trial_End;
      may23_DW.e_Trial_EndEventCounter--;
    }

    may23_DW.Trial_Control_SubsysRanBC = 4;
  }

  may23_PrevZCX.Trial_Control_Trig_ZCE[0] = may23_B.DataTypeConversion1_jo;
  may23_PrevZCX.Trial_Control_Trig_ZCE[1] = may23_B.e_exit_trial;
  may23_PrevZCX.Trial_Control_Trig_ZCE[2] = may23_B.DataTypeConversion_j0;
  may23_PrevZCX.Trial_Control_Trig_ZCE[3] = may23_B.DataTypeConversion1_pz;

  /* RelationalOperator: '<S348>/FixPt Relational Operator' */
  may23_B.FixPtRelationalOperator_f = (may23_B.e_Trial_End != may23_B.Uk1_h);

  /* DataTypeConversion: '<S336>/Data Type Conversion2' */
  may23_B.DataTypeConversion2 = may23_B.Compare;

  /* DataTypeConversion: '<S3>/Convert16' */
  may23_B.Convert16 = may23_B.DataTypeConversion2;

  /* DataTypeConversion: '<S3>/Convert17' */
  may23_B.Convert17 = may23_B.Product;

  /* DataTypeConversion: '<S3>/Convert19' */
  may23_B.Convert19_e = may23_B.trial_in_set;

  /* DataTypeConversion: '<S3>/Convert21' */
  may23_B.Convert21 = may23_B.block_in_set;

  /* DataTypeConversion: '<S3>/Convert22' */
  may23_B.Convert22 = may23_B.trial_in_block;

  /* DataTypeConversion: '<S3>/Convert23' */
  may23_B.Convert23 = may23_B.block_idx;

  /* DataTypeConversion: '<S3>/Convert25' */
  may23_B.Convert25 = (may23_B.repeat_last_trial != 0.0);

  /* RateTransition generated from: '<S335>/Hold_to_1Khz' */
  if (may23_M->Timing.RateInteraction.TID1_3) {
    may23_B.TmpRTBAtHold_to_1KhzInport2 =
      may23_DW.TmpRTBAtHold_to_1KhzInport2_Buffer0;
  }

  /* End of RateTransition generated from: '<S335>/Hold_to_1Khz' */

  /* MATLAB Function: '<S335>/Hold_to_1Khz' */
  /* MATLAB Function 'GUI Control/Run Command Subsystem/Hold_to_1Khz': '<S342>:1' */
  /* '<S342>:1:17' */
  hold_steps = 0.001 / may23_P.BKIN_STEP_TIME;

  /* '<S342>:1:19' */
  x = 0.0;
  if (may23_B.z != 0.0) {
    /* '<S342>:1:20' */
    /* '<S342>:1:21' */
    x = may23_B.z;
  } else {
    if (may23_B.TmpRTBAtHold_to_1KhzInport2 != 0.0) {
      /* '<S342>:1:22' */
      if (may23_B.TmpRTBAtHold_to_1KhzInport2 != may23_DW.last_sim) {
        /* '<S342>:1:25' */
        /* '<S342>:1:26' */
        x = may23_B.TmpRTBAtHold_to_1KhzInport2;
      }

      /* '<S342>:1:28' */
      may23_DW.last_sim = may23_B.TmpRTBAtHold_to_1KhzInport2;
    }
  }

  if (x != 0.0) {
    /* '<S342>:1:33' */
    if (1.0 > hold_steps) {
      i = -1;
    } else {
      i = (int32_T)hold_steps - 1;
    }

    inputEventFiredFlag = i + 1;

    /* '<S342>:1:34' */
    for (i = 0; i < inputEventFiredFlag; i++) {
      may23_DW.held_value[i] = x;
    }
  }

  /* '<S342>:1:37' */
  may23_B.value = may23_DW.held_value[0];

  /* '<S342>:1:38' */
  for (i = 0; i < 7; i++) {
    hold_steps = may23_DW.held_value[i + 1];
    may23_DW.held_value[i] = hold_steps;
  }

  /* '<S342>:1:39' */
  may23_DW.held_value[7] = 0.0;

  /* End of MATLAB Function: '<S335>/Hold_to_1Khz' */

  /* Selector: '<S336>/Selector1' */
  for (i = 0; i < 500; i++) {
    may23_B.Selector1[i] = may23_B.BlockDefinitions[50 * i];
  }

  /* End of Selector: '<S336>/Selector1' */

  /* Selector: '<S336>/Selector2' */
  memcpy(&may23_B.Selector2[0], &may23_B.BlockSequence[0], 1000U * sizeof(real_T));

  /* DataTypeConversion: '<S3>/Convert10' incorporates:
   *  Constant: '<S3>/Display Size (pels)'
   */
  may23_B.Convert10[0] = may23_P.DisplaySizepels_Value[0];
  may23_B.Convert10[1] = may23_P.DisplaySizepels_Value[1];

  /* DataTypeConversion: '<S3>/Convert11' incorporates:
   *  Constant: '<S3>/Docking Points'
   */
  memcpy(&may23_B.Convert11[0], &may23_P.DockingPoints_Value[0], 10U * sizeof
         (real_T));

  /* DataTypeConversion: '<S3>/Convert12' incorporates:
   *  Constant: '<S3>/EL Camera Focal Length'
   */
  may23_B.Convert12 = may23_P.ELCameraFocalLength_Value_h;

  /* DataTypeConversion: '<S3>/Convert13' incorporates:
   *  Constant: '<S3>/EL Camera Position'
   */
  may23_B.Convert13[0] = may23_P.ELCameraPosition_Value_e[0];
  may23_B.Convert13[1] = may23_P.ELCameraPosition_Value_e[1];
  may23_B.Convert13[2] = may23_P.ELCameraPosition_Value_e[2];

  /* DataTypeConversion: '<S3>/Convert14' incorporates:
   *  Constant: '<S3>/EL Camera Angle'
   */
  may23_B.Convert14[0] = may23_P.ELCameraAngle_Value_j[0];
  may23_B.Convert14[1] = may23_P.ELCameraAngle_Value_j[1];

  /* DataTypeConversion: '<S3>/Convert15' incorporates:
   *  Constant: '<S3>/EL Tracking Available'
   */
  may23_B.Convert15 = may23_P.ELTrackingAvailable_Value_m;

  /* DataTypeConversion: '<S3>/Convert7' incorporates:
   *  Constant: '<S3>/Subject Height'
   */
  may23_B.Convert7 = may23_P.SubjectHeight_Value;

  /* DataTypeConversion: '<S3>/Convert8' incorporates:
   *  Constant: '<S3>/Subject Weight'
   */
  may23_B.Convert8 = may23_P.SubjectWeight_Value;

  /* Constant: '<S3>/frame_of_reference_center' */
  may23_B.frame_of_reference_center[0] =
    may23_P.frame_of_reference_center_Value[0];
  may23_B.frame_of_reference_center[1] =
    may23_P.frame_of_reference_center_Value[1];

  /* Constant: '<S3>/Library Patch Version' */
  may23_B.LibraryPatchVersion = may23_P.LibraryPatchVersion_Value;

  /* Constant: '<S3>/Library Version' */
  may23_B.LibraryVersion = may23_P.LibraryVersion_Value;

  /* Constant: '<S3>/Task Version' */
  may23_B.TaskVersion = may23_P.TaskVersion_Value;

  /* Constant: '<S3>/xPC Version' */
  may23_B.xPCVersion = may23_P.xPCVersion_Value;

  /* Constant: '<S3>/dlm build time' */
  may23_B.dlmbuildtime = may23_P.dlmbuildtime_Value;

  /* Constant: '<S334>/preview_detail' */
  may23_B.preview_detail[0] = may23_P.preview_detail_Value[0];
  may23_B.preview_detail[1] = may23_P.preview_detail_Value[1];
  may23_B.preview_detail[2] = may23_P.preview_detail_Value[2];

  /* MATLAB Function: '<S337>/MATLAB Function' */
  /* MATLAB Function 'GUI Control/Task_progress/MATLAB Function': '<S346>:1' */
  /* '<S346>:1:7' */
  if (!may23_DW.trials_per_block_not_empty) {
    /* '<S346>:1:6' */
    /* '<S346>:1:7' */
    for (i = 0; i < 499; i++) {
      for (inputEventFiredFlag = 0; inputEventFiredFlag < 50;
           inputEventFiredFlag++) {
        may23_B.x[inputEventFiredFlag + 50 * i] = (may23_B.BlockDefinitions[(i +
          1) * 50 + inputEventFiredFlag] != 0.0);
      }
    }

    for (inputEventFiredFlag = 0; inputEventFiredFlag < 50; inputEventFiredFlag
         ++) {
      nz[inputEventFiredFlag] = may23_B.x[inputEventFiredFlag];
    }

    for (inputEventFiredFlag = 0; inputEventFiredFlag < 498; inputEventFiredFlag
         ++) {
      xoffset = (inputEventFiredFlag + 1) * 50;
      for (i = 0; i < 50; i++) {
        nz_0 = nz[i];
        nz_0 += may23_B.x[xoffset + i];
        nz[i] = nz_0;
      }
    }

    may23_DW.trials_per_block_not_empty = true;

    /* '<S346>:1:8' */
    for (i = 0; i < 50; i++) {
      may23_DW.trials_per_block[i] = nz[i];
      tmp[i] = may23_B.BlockSequence[i + 1000] * may23_DW.trials_per_block[i];
    }

    may23_DW.total_trials_saved = may23_sum(tmp);

    /* '<S346>:1:9' */
    may23_DW.total_blocks_saved = may23_sum(&may23_B.BlockSequence[1000]);
  }

  /* '<S346>:1:12' */
  may23_B.total_trials = may23_B.extra_trials[0] + may23_DW.total_trials_saved;

  /* '<S346>:1:13' */
  may23_B.total_blocks = may23_DW.total_blocks_saved;
  if (may23_B.Convert23 > 0U) {
    /* '<S346>:1:15' */
    /* '<S346>:1:16' */
    may23_B.trials_in_block = may23_DW.trials_per_block[(int32_T)
      may23_B.Convert23 - 1] + may23_B.extra_trials[1];
  } else {
    /* '<S346>:1:18' */
    may23_B.trials_in_block = 0.0;
  }

  /* End of MATLAB Function: '<S337>/MATLAB Function' */

  /* DataTypeConversion: '<S337>/Data Type Conversion' */
  hold_steps = floor(may23_B.total_trials);
  if (rtIsNaN(hold_steps) || rtIsInf(hold_steps)) {
    hold_steps = 0.0;
  } else {
    hold_steps = fmod(hold_steps, 4.294967296E+9);
  }

  may23_B.total_trials_in_exam = hold_steps < 0.0 ? (uint32_T)-(int32_T)
    (uint32_T)-hold_steps : (uint32_T)hold_steps;

  /* End of DataTypeConversion: '<S337>/Data Type Conversion' */

  /* DataTypeConversion: '<S337>/Data Type Conversion1' */
  hold_steps = floor(may23_B.trials_in_block);
  if (rtIsNaN(hold_steps) || rtIsInf(hold_steps)) {
    hold_steps = 0.0;
  } else {
    hold_steps = fmod(hold_steps, 4.294967296E+9);
  }

  may23_B.total_trials_in_block = hold_steps < 0.0 ? (uint32_T)-(int32_T)
    (uint32_T)-hold_steps : (uint32_T)hold_steps;

  /* End of DataTypeConversion: '<S337>/Data Type Conversion1' */

  /* DataTypeConversion: '<S337>/Data Type Conversion2' */
  hold_steps = floor(may23_B.total_blocks);
  if (rtIsNaN(hold_steps) || rtIsInf(hold_steps)) {
    hold_steps = 0.0;
  } else {
    hold_steps = fmod(hold_steps, 4.294967296E+9);
  }

  may23_B.total_blocks_in_exam = hold_steps < 0.0 ? (uint32_T)-(int32_T)
    (uint32_T)-hold_steps : (uint32_T)hold_steps;

  /* End of DataTypeConversion: '<S337>/Data Type Conversion2' */

  /* Sum: '<S352>/FixPt Sum1' incorporates:
   *  Constant: '<S352>/FixPt Constant'
   */
  may23_B.FixPtSum1 = may23_B.Output + may23_P.FixPtConstant_Value_k;

  /* Switch: '<S353>/FixPt Switch' incorporates:
   *  Constant: '<S353>/Constant'
   */
  if (may23_B.FixPtSum1 > may23_P.WrapToZero_Threshold_f) {
    may23_B.FixPtSwitch = may23_P.Constant_Value_px;
  } else {
    may23_B.FixPtSwitch = may23_B.FixPtSum1;
  }

  /* End of Switch: '<S353>/FixPt Switch' */

  /* Sum: '<S22>/Subtract' incorporates:
   *  Constant: '<S22>/Not Logging Analog Inputs'
   */
  may23_B.Subtract = may23_ConstB.Width - may23_P.NotLoggingAnalogInputs_Value;

  /* Selector: '<S14>/Selector' */
  i = (int32_T)may23_B.cursor_row;
  for (inputEventFiredFlag = 0; inputEventFiredFlag < 25; inputEventFiredFlag++)
  {
    may23_B.Selector_p[inputEventFiredFlag] = may23_B.TargetTable
      [((inputEventFiredFlag << 6) + i) - 1];
  }

  /* End of Selector: '<S14>/Selector' */

  /* Concatenate: '<S14>/Matrix Concatenation' incorporates:
   *  Constant: '<S14>/state1_indices'
   *  Constant: '<S14>/state2_indices'
   *  Constant: '<S14>/state3_indices'
   *  Constant: '<S14>/state4_indices'
   *  Constant: '<S14>/state5_indices'
   */
  may23_B.MatrixConcatenation1[0] = may23_P.Show_Cursor_attribcol1[0];
  may23_B.MatrixConcatenation1[5] = may23_P.Show_Cursor_attribcol1[1];
  may23_B.MatrixConcatenation1[10] = may23_P.Show_Cursor_attribcol1[2];
  may23_B.MatrixConcatenation1[15] = may23_P.Show_Cursor_attribcol1[3];
  may23_B.MatrixConcatenation1[1] = may23_P.Show_Cursor_attribcol2[0];
  may23_B.MatrixConcatenation1[6] = may23_P.Show_Cursor_attribcol2[1];
  may23_B.MatrixConcatenation1[11] = may23_P.Show_Cursor_attribcol2[2];
  may23_B.MatrixConcatenation1[16] = may23_P.Show_Cursor_attribcol2[3];
  may23_B.MatrixConcatenation1[2] = may23_P.Show_Cursor_attribcol3[0];
  may23_B.MatrixConcatenation1[7] = may23_P.Show_Cursor_attribcol3[1];
  may23_B.MatrixConcatenation1[12] = may23_P.Show_Cursor_attribcol3[2];
  may23_B.MatrixConcatenation1[17] = may23_P.Show_Cursor_attribcol3[3];
  may23_B.MatrixConcatenation1[3] = may23_P.state4_indices_Value[0];
  may23_B.MatrixConcatenation1[8] = may23_P.state4_indices_Value[1];
  may23_B.MatrixConcatenation1[13] = may23_P.state4_indices_Value[2];
  may23_B.MatrixConcatenation1[18] = may23_P.state4_indices_Value[3];
  may23_B.MatrixConcatenation1[4] = may23_P.state5_indices_Value[0];
  may23_B.MatrixConcatenation1[9] = may23_P.state5_indices_Value[1];
  may23_B.MatrixConcatenation1[14] = may23_P.state5_indices_Value[2];
  may23_B.MatrixConcatenation1[19] = may23_P.state5_indices_Value[3];

  /* Constant: '<S14>/padder' */
  memcpy(&may23_B.MatrixConcatenation1[20], &may23_P.padder_Value[0], 35U *
         sizeof(real_T));

  /* MATLAB Function: '<S14>/Embedded MATLAB Function' incorporates:
   *  Constant: '<S14>/Opacity'
   *  Constant: '<S14>/Target_Display'
   *  Constant: '<S14>/Target_Type'
   *  Constant: '<S14>/num_states'
   *  Constant: '<S14>/xpos_index'
   *  Constant: '<S14>/ypos_index'
   */
  may23_EmbeddedMATLABFunction(may23_B.Selector_p, may23_B.cursor_state,
    may23_P.Show_Cursor_target_type, may23_P.Show_Cursor_opacity,
    may23_P.Show_Cursor_target_display, may23_P.xpos_index_Value,
    may23_P.ypos_index_Value, may23_P.Show_Cursor_num_states,
    may23_B.MatrixConcatenation1, &may23_B.sf_EmbeddedMATLABFunction_n);

  /* Reshape: '<S405>/Reshape' */
  memcpy(&may23_B.Reshape[0], &may23_B.sf_EmbeddedMATLABFunction_n.VCODE[0], 70U
         * sizeof(real_T));

  /* Reshape: '<S405>/Reshape1' */
  memcpy(&may23_B.Reshape1[0], &may23_B.sf_EmbeddedMATLABFunction_n.VCODE[0],
         70U * sizeof(real_T));

  /* Concatenate: '<S405>/Matrix Concatenation' */
  for (i = 0; i < 70; i++) {
    may23_B.MatrixConcatenation[i << 1] = may23_B.Reshape[i];
  }

  for (i = 0; i < 70; i++) {
    may23_B.MatrixConcatenation[(i << 1) + 1] = may23_B.Reshape1[i];
  }

  /* End of Concatenate: '<S405>/Matrix Concatenation' */

  /* MATLAB Function: '<S405>/FeedFwdArm' */
  may23_FeedFwdArm();

  /* MATLAB Function: '<S402>/MATLAB Function' incorporates:
   *  Constant: '<S21>/Constant2'
   */
  /* MATLAB Function 'subsystem for moving the square (updating velocity and checking collision)/Hand Feedback/MATLAB Function': '<S406>:1' */
  if (may23_P.Constant2_Value_e == 1.0) {
    /* '<S406>:1:10' */
    /* '<S406>:1:11' */
    memcpy(&may23_B.hand_vcodes[0], &may23_B.VCODES_out[0], 140U * sizeof(real_T));
  } else {
    /* '<S406>:1:13' */
    for (i = 0; i < 70; i++) {
      may23_B.hand_vcodes[i << 1] = may23_B.VCODES_out[(i << 1) + 1];
      may23_B.hand_vcodes[(i << 1) + 1] = may23_B.VCODES_out[i << 1];
    }
  }

  /* End of MATLAB Function: '<S402>/MATLAB Function' */

  /* Selector: '<S17>/Selector' */
  i = (int32_T)may23_B.puck_row;
  for (inputEventFiredFlag = 0; inputEventFiredFlag < 25; inputEventFiredFlag++)
  {
    may23_B.Selector_gx[inputEventFiredFlag] = may23_B.TargetTable
      [((inputEventFiredFlag << 6) + i) - 1];
  }

  /* End of Selector: '<S17>/Selector' */

  /* Concatenate: '<S17>/Matrix Concatenation' incorporates:
   *  Constant: '<S17>/state1_indices'
   *  Constant: '<S17>/state2_indices'
   *  Constant: '<S17>/state3_indices'
   *  Constant: '<S17>/state4_indices'
   *  Constant: '<S17>/state5_indices'
   */
  may23_B.MatrixConcatenation1_a[0] = may23_P.Show_Puck_attribcol1[0];
  may23_B.MatrixConcatenation1_a[5] = may23_P.Show_Puck_attribcol1[1];
  may23_B.MatrixConcatenation1_a[10] = may23_P.Show_Puck_attribcol1[2];
  may23_B.MatrixConcatenation1_a[15] = may23_P.Show_Puck_attribcol1[3];
  may23_B.MatrixConcatenation1_a[1] = may23_P.Show_Puck_attribcol2[0];
  may23_B.MatrixConcatenation1_a[6] = may23_P.Show_Puck_attribcol2[1];
  may23_B.MatrixConcatenation1_a[11] = may23_P.Show_Puck_attribcol2[2];
  may23_B.MatrixConcatenation1_a[16] = may23_P.Show_Puck_attribcol2[3];
  may23_B.MatrixConcatenation1_a[2] = may23_P.Show_Puck_attribcol3[0];
  may23_B.MatrixConcatenation1_a[7] = may23_P.Show_Puck_attribcol3[1];
  may23_B.MatrixConcatenation1_a[12] = may23_P.Show_Puck_attribcol3[2];
  may23_B.MatrixConcatenation1_a[17] = may23_P.Show_Puck_attribcol3[3];
  may23_B.MatrixConcatenation1_a[3] = may23_P.state4_indices_Value_p[0];
  may23_B.MatrixConcatenation1_a[8] = may23_P.state4_indices_Value_p[1];
  may23_B.MatrixConcatenation1_a[13] = may23_P.state4_indices_Value_p[2];
  may23_B.MatrixConcatenation1_a[18] = may23_P.state4_indices_Value_p[3];
  may23_B.MatrixConcatenation1_a[4] = may23_P.state5_indices_Value_l[0];
  may23_B.MatrixConcatenation1_a[9] = may23_P.state5_indices_Value_l[1];
  may23_B.MatrixConcatenation1_a[14] = may23_P.state5_indices_Value_l[2];
  may23_B.MatrixConcatenation1_a[19] = may23_P.state5_indices_Value_l[3];

  /* Constant: '<S17>/padder' */
  memcpy(&may23_B.MatrixConcatenation1_a[20], &may23_P.padder_Value_l[0], 35U *
         sizeof(real_T));

  /* MATLAB Function: '<S17>/Embedded MATLAB Function' incorporates:
   *  Constant: '<S17>/Opacity'
   *  Constant: '<S17>/Target_Display'
   *  Constant: '<S17>/Target_Type'
   *  Constant: '<S17>/num_states'
   *  Constant: '<S17>/xpos_index'
   *  Constant: '<S17>/ypos_index'
   */
  may23_EmbeddedMATLABFunction_m(may23_B.Selector_gx, may23_B.puck_state,
    may23_P.Show_Puck_target_type, may23_P.Show_Puck_opacity,
    may23_P.Show_Puck_target_display, may23_P.xpos_index_Value_l,
    may23_P.ypos_index_Value_d, may23_P.Show_Puck_num_states,
    may23_B.MatrixConcatenation1_a, &may23_B.sf_EmbeddedMATLABFunction_a);

  /* Selector: '<S15>/Selector' */
  i = (int32_T)may23_B.goal_target_row;
  for (inputEventFiredFlag = 0; inputEventFiredFlag < 25; inputEventFiredFlag++)
  {
    may23_B.Selector_c[inputEventFiredFlag] = may23_B.TargetTable
      [((inputEventFiredFlag << 6) + i) - 1];
  }

  /* End of Selector: '<S15>/Selector' */

  /* Concatenate: '<S15>/Matrix Concatenation' incorporates:
   *  Constant: '<S15>/state1_indices'
   *  Constant: '<S15>/state2_indices'
   *  Constant: '<S15>/state3_indices'
   *  Constant: '<S15>/state4_indices'
   *  Constant: '<S15>/state5_indices'
   */
  may23_B.MatrixConcatenation1_g[0] = may23_P.Show_Goal_attribcol1[0];
  may23_B.MatrixConcatenation1_g[5] = may23_P.Show_Goal_attribcol1[1];
  may23_B.MatrixConcatenation1_g[10] = may23_P.Show_Goal_attribcol1[2];
  may23_B.MatrixConcatenation1_g[15] = may23_P.Show_Goal_attribcol1[3];
  may23_B.MatrixConcatenation1_g[1] = may23_P.Show_Goal_attribcol2[0];
  may23_B.MatrixConcatenation1_g[6] = may23_P.Show_Goal_attribcol2[1];
  may23_B.MatrixConcatenation1_g[11] = may23_P.Show_Goal_attribcol2[2];
  may23_B.MatrixConcatenation1_g[16] = may23_P.Show_Goal_attribcol2[3];
  may23_B.MatrixConcatenation1_g[2] = may23_P.Show_Goal_attribcol3[0];
  may23_B.MatrixConcatenation1_g[7] = may23_P.Show_Goal_attribcol3[1];
  may23_B.MatrixConcatenation1_g[12] = may23_P.Show_Goal_attribcol3[2];
  may23_B.MatrixConcatenation1_g[17] = may23_P.Show_Goal_attribcol3[3];
  may23_B.MatrixConcatenation1_g[3] = may23_P.state4_indices_Value_i[0];
  may23_B.MatrixConcatenation1_g[8] = may23_P.state4_indices_Value_i[1];
  may23_B.MatrixConcatenation1_g[13] = may23_P.state4_indices_Value_i[2];
  may23_B.MatrixConcatenation1_g[18] = may23_P.state4_indices_Value_i[3];
  may23_B.MatrixConcatenation1_g[4] = may23_P.state5_indices_Value_j[0];
  may23_B.MatrixConcatenation1_g[9] = may23_P.state5_indices_Value_j[1];
  may23_B.MatrixConcatenation1_g[14] = may23_P.state5_indices_Value_j[2];
  may23_B.MatrixConcatenation1_g[19] = may23_P.state5_indices_Value_j[3];

  /* Constant: '<S15>/padder' */
  memcpy(&may23_B.MatrixConcatenation1_g[20], &may23_P.padder_Value_a[0], 35U *
         sizeof(real_T));

  /* MATLAB Function: '<S15>/Embedded MATLAB Function' incorporates:
   *  Constant: '<S15>/Opacity'
   *  Constant: '<S15>/Target_Display'
   *  Constant: '<S15>/Target_Type'
   *  Constant: '<S15>/num_states'
   *  Constant: '<S15>/xpos_index'
   *  Constant: '<S15>/ypos_index'
   */
  may23_EmbeddedMATLABFunction_m(may23_B.Selector_c, may23_B.goal_target_state,
    may23_P.Show_Goal_target_type, may23_P.Show_Goal_opacity,
    may23_P.Show_Goal_target_display, may23_P.xpos_index_Value_p,
    may23_P.ypos_index_Value_p, may23_P.Show_Goal_num_states,
    may23_B.MatrixConcatenation1_g, &may23_B.sf_EmbeddedMATLABFunction_m);

  /* Selector: '<S21>/get hand mass' */
  may23_B.gethandmass = may23_B.LoadTable[(int32_T)may23_B.load_row + 19];

  /* Selector: '<S21>/get rectangle mass' */
  may23_B.getrectanglemass = may23_B.LoadTable[(int32_T)may23_B.load_row + 39];

  /* Concatenate: '<S401>/Matrix Concatenate1' */
  may23_B.MatrixConcatenate1[0] = may23_B.sf_splitKINDataarm1.hand_velocity[0];
  may23_B.MatrixConcatenate1[2] = may23_B.sf_splitKINDataarm1.hand_velocity[1];
  may23_B.MatrixConcatenate1[1] = may23_B.sf_splitKINDataarm2.hand_velocity[0];
  may23_B.MatrixConcatenate1[3] = may23_B.sf_splitKINDataarm2.hand_velocity[1];

  /* MATLAB Function: '<S401>/MATLAB Function' */
  /* MATLAB Function 'subsystem for moving the square (updating velocity and checking collision)/Get Hand Speed/MATLAB Function': '<S404>:1' */
  if (may23_B.active_arm == 1.0) {
    /* '<S404>:1:10' */
    /* '<S404>:1:11' */
    may23_B.hand_vcodes_e[0] = may23_B.MatrixConcatenate1[0];
    may23_B.hand_vcodes_e[1] = may23_B.MatrixConcatenate1[1];
    may23_B.hand_vcodes_e[2] = may23_B.MatrixConcatenate1[2];
    may23_B.hand_vcodes_e[3] = may23_B.MatrixConcatenate1[3];
  } else {
    /* '<S404>:1:13' */
    may23_B.hand_vcodes_e[0] = may23_B.MatrixConcatenate1[1];
    may23_B.hand_vcodes_e[1] = may23_B.MatrixConcatenate1[0];
    may23_B.hand_vcodes_e[2] = may23_B.MatrixConcatenate1[3];
    may23_B.hand_vcodes_e[3] = may23_B.MatrixConcatenate1[2];
  }

  /* End of MATLAB Function: '<S401>/MATLAB Function' */

  /* DiscretePulseGenerator: '<S21>/Pulse Generator' */
  may23_B.PulseGenerator = (may23_DW.clockTickCounter_d <
    may23_P.PulseGenerator_Duty) && (may23_DW.clockTickCounter_d >= 0) ?
    may23_P.PulseGenerator_Amp : 0.0;
  if (may23_DW.clockTickCounter_d >= may23_P.PulseGenerator_Period - 1.0) {
    may23_DW.clockTickCounter_d = 0;
  } else {
    may23_DW.clockTickCounter_d++;
  }

  /* End of DiscretePulseGenerator: '<S21>/Pulse Generator' */

  /* DataTypeConversion: '<S21>/Data Type Conversion' */
  may23_B.DataTypeConversion_b = may23_B.e_Trial_Start;

  /* Chart: '<S21>/Collision Resolution' incorporates:
   *  TriggerPort: '<S400>/input events'
   */
  zcEvent_idx_0_0 = rt_ZCFcn(ANY_ZERO_CROSSING,
    &may23_PrevZCX.CollisionResolution_Trig_ZCE[0],
    (may23_B.PulseGenerator));
  zcEvent_idx_1_0 = rt_ZCFcn(ANY_ZERO_CROSSING,
    &may23_PrevZCX.CollisionResolution_Trig_ZCE[1],
    (may23_B.DataTypeConversion_b));
  zcEvent = (zcEvent_idx_0_0 != NO_ZCEVENT);
  zcEvent = (zcEvent || (zcEvent_idx_1_0 != NO_ZCEVENT));
  if (zcEvent) {
    may23_B.inputevents[0] = (int8_T)zcEvent_idx_0_0;
    may23_B.inputevents[1] = (int8_T)zcEvent_idx_1_0;

    /* Gateway: subsystem for moving the square (updating velocity and checking collision)/Collision Resolution */
    inputEventFiredFlag = 0;
    if (may23_B.inputevents[0U] == 1) {
      inputEventFiredFlag = 1;

      /* Event: '<S400>:23' */
      may23_DW.sfEvent = may23_event_e_clk_p;
      may23_chartstep_c1_may23();
    }

    if (may23_B.inputevents[1U] != 0) {
      inputEventFiredFlag = 1;

      /* Event: '<S400>:330' */
      may23_DW.sfEvent = may23_event_e_Trial_Start;
      may23_chartstep_c1_may23();
    }

    if ((inputEventFiredFlag != 0) && (may23_DW.e_Puck_StoppedEventCounter > 0U))
    {
      may23_B.e_Puck_Stopped = !may23_B.e_Puck_Stopped;
      may23_DW.e_Puck_StoppedEventCounter--;
    }

    if ((inputEventFiredFlag != 0) && (may23_DW.e_Puck_HitEventCounter > 0U)) {
      may23_B.e_Puck_Hit = !may23_B.e_Puck_Hit;
      may23_DW.e_Puck_HitEventCounter--;
    }

    may23_DW.CollisionResolution_SubsysRanBC = 4;
  }

  /* DataTypeConversion: '<S22>/Analog Data Width' */
  may23_B.AnalogDataWidth[0] = may23_B.Subtract;
  memcpy(&may23_B.AnalogDataWidth[1], &may23_B.puck_vcode_output[0], 70U *
         sizeof(real_T));

  /* RateTransition: '<S22>/Rate Transition' incorporates:
   *  RateTransition: '<S23>/Rate Transition2'
   */
  if (may23_M->Timing.RateInteraction.TID1_3) {
    memcpy(&may23_DW.RateTransition_Buffer[0], &may23_B.AnalogDataWidth[0], 71U *
           sizeof(real_T));
    may23_B.RateTransition2 = may23_DW.RateTransition2_Buffer0;
  }

  /* End of RateTransition: '<S22>/Rate Transition' */

  /* DataStoreRead: '<S1>/read Digital diag' */
  may23_B.readDigitaldiag[0] = may23_DW.ECATDigDiagnostic[0];
  may23_B.readDigitaldiag[1] = may23_DW.ECATDigDiagnostic[1];
  may23_B.readDigitaldiag[2] = may23_DW.ECATDigDiagnostic[2];
  may23_B.readDigitaldiag[3] = may23_DW.ECATDigDiagnostic[3];

  /* MATLAB Function: '<S23>/monitor voltage bits' */
  /* MATLAB Function 'DataLogging/Create Custom Data Subsystem/monitor voltage bits': '<S41>:1' */
  /* '<S41>:1:5' */
  /* '<S41>:1:6' */
  /* '<S41>:1:7' */
  /* '<S41>:1:8' */
  /* '<S41>:1:10' */
  /* '<S41>:1:11' */
  /* '<S41>:1:12' */
  may23_B.voltagesOK = (may23_B.readDigitaldiag[1] >> 16U & 1U) << 1U |
    (may23_B.readDigitaldiag[1] >> 19U & 1U) | (may23_B.readDigitaldiag[3] >>
    19U & 1U) << 2U | (may23_B.readDigitaldiag[3] >> 16U & 1U) << 3U;

  /* DataTypeConversion: '<S23>/Data Type Conversion' */
  may23_B.DataTypeConversion_g = may23_B.voltagesOK;

  /* RateTransition: '<S23>/Rate Transition1' incorporates:
   *  Constant: '<S1>/seconds_remaining'
   */
  may23_B.RateTransition1 = may23_P.seconds_remaining_Value;

  /* DataTypeConversion: '<S24>/Event Codes' */
  may23_B.EventCodes = may23_B.event_code;

  /* Sum: '<S24>/Subtract' incorporates:
   *  Constant: '<S24>/Not Logging Event Codes'
   */
  may23_B.Subtract_i = may23_ConstB.Width_o - may23_P.NotLoggingEventCodes_Value;

  /* DataTypeConversion: '<S24>/Number of Event Codes' */
  may23_B.NumberofEventCodes = may23_B.Subtract_i;

  /* MATLAB Function: '<S44>/MATLAB Function' */
  /* MATLAB Function 'DataLogging/Create KINARM Data Subsystem/select KINData/MATLAB Function': '<S45>:1' */
  /* '<S45>:1:7' */
  memcpy((void *)&ss[0], (void *)&may23_B.status_out[0], (uint32_T)((size_t)2 *
          sizeof(real32_T)));

  /* '<S45>:1:8' */
  may23_B.dd_out[0] = ss[0];
  may23_B.dd_out[1] = ss[1];

  /* Outputs for Atomic SubSystem: '<S1>/Poll Force Plates' */
  may23_PollForcePlatesTID0();

  /* End of Outputs for SubSystem: '<S1>/Poll Force Plates' */

  /* DataTypeConversion: '<S25>/touint' */
  hold_steps = may23_B.sf_splitKINDataarm1.motor_status;
  if (hold_steps < 4.294967296E+9) {
    if (hold_steps >= 0.0) {
      tmp_0 = (uint32_T)hold_steps;
    } else {
      tmp_0 = 0U;
    }
  } else {
    tmp_0 = MAX_uint32_T;
  }

  may23_B.touint[0] = tmp_0;
  hold_steps = may23_B.sf_splitKINDataarm2.motor_status;
  if (hold_steps < 4.294967296E+9) {
    if (hold_steps >= 0.0) {
      tmp_0 = (uint32_T)hold_steps;
    } else {
      tmp_0 = 0U;
    }
  } else {
    tmp_0 = MAX_uint32_T;
  }

  may23_B.touint[1] = tmp_0;
  for (i = 0; i < 6; i++) {
    hold_steps = may23_B.torquefeedback1[i + 4];
    if (hold_steps < 4.294967296E+9) {
      if (hold_steps >= 0.0) {
        tmp_0 = (uint32_T)hold_steps;
      } else {
        tmp_0 = 0U;
      }
    } else {
      tmp_0 = MAX_uint32_T;
    }

    may23_B.touint[i + 2] = tmp_0;
  }

  /* End of DataTypeConversion: '<S25>/touint' */

  /* MATLAB Function: '<S25>/bitfield' */
  /* MATLAB Function 'DataLogging/Create KINARM Data Subsystem/bitfield': '<S42>:1' */
  /* '<S42>:1:5' */
  /* '<S42>:1:6' */
  /* '<S42>:1:8' */
  /* '<S42>:1:11' */
  /* '<S42>:1:13' */
  may23_B.bitfield = ((((((((may23_B.touint[3] & 1U) << 1U) + (may23_B.touint[2]
    & 1U)) + ((may23_B.touint[4] & 1U) << 2U)) + ((may23_B.touint[5] & 1U) << 3U))
                        << 4U) + (((may23_B.touint[1] ^ 3U) & 3U) << 2U)) +
                      ((may23_B.touint[0] ^ 3U) & 3U)) + ((((may23_B.touint[7] &
    1U) << 1U) + (may23_B.touint[6] & 1U)) << 8U);

  /* DataTypeConversion: '<S25>/touint1' */
  may23_B.touint1 = may23_B.bitfield;

  /* RateTransition: '<S25>/Rate Transition' */
  if (may23_M->Timing.RateInteraction.TID1_3) {
    may23_DW.RateTransition_Buffer_d[0] =
      may23_B.sf_splitKINDataarm1.link_angle[0];
    may23_DW.RateTransition_Buffer_d[1] =
      may23_B.sf_splitKINDataarm1.link_angle[1];
    may23_DW.RateTransition_Buffer_d[2] =
      may23_B.sf_splitKINDataarm1.link_velocity[0];
    may23_DW.RateTransition_Buffer_d[3] =
      may23_B.sf_splitKINDataarm1.link_velocity[1];
    may23_DW.RateTransition_Buffer_d[4] =
      may23_B.sf_splitKINDataarm1.link_acceleration[0];
    may23_DW.RateTransition_Buffer_d[5] =
      may23_B.sf_splitKINDataarm1.link_acceleration[1];
    may23_DW.RateTransition_Buffer_d[6] =
      may23_B.sf_splitKINDataarm1.hand_position[0];
    may23_DW.RateTransition_Buffer_d[7] =
      may23_B.sf_splitKINDataarm1.hand_position[1];
    may23_DW.RateTransition_Buffer_d[8] =
      may23_B.sf_splitKINDataarm1.motor_torque_cmd[0];
    may23_DW.RateTransition_Buffer_d[9] =
      may23_B.sf_splitKINDataarm1.motor_torque_cmd[1];
    may23_DW.RateTransition_Buffer_d[10] =
      may23_B.sf_splitKINDataarm1.force_sensor_force_xyz[0];
    may23_DW.RateTransition_Buffer_d[11] =
      may23_B.sf_splitKINDataarm1.force_sensor_force_xyz[1];
    may23_DW.RateTransition_Buffer_d[12] =
      may23_B.sf_splitKINDataarm1.force_sensor_force_xyz[2];
    may23_DW.RateTransition_Buffer_d[13] =
      may23_B.sf_splitKINDataarm1.force_sensor_torque_xyz[0];
    may23_DW.RateTransition_Buffer_d[14] =
      may23_B.sf_splitKINDataarm1.force_sensor_torque_xyz[1];
    may23_DW.RateTransition_Buffer_d[15] =
      may23_B.sf_splitKINDataarm1.force_sensor_torque_xyz[2];
    may23_DW.RateTransition_Buffer_d[16] =
      may23_B.sf_splitKINDataarm1.force_sensor_timestamp;
    may23_DW.RateTransition_Buffer_d[17] = may23_B.dd_out[0];
    may23_DW.RateTransition_Buffer_d[18] = may23_B.torquefeedback1[0];
    may23_DW.RateTransition_Buffer_d[19] = may23_B.torquefeedback1[1];
    may23_DW.RateTransition_Buffer_d[20] =
      may23_B.sf_splitKINDataarm2.link_angle[0];
    may23_DW.RateTransition_Buffer_d[22] =
      may23_B.sf_splitKINDataarm2.link_velocity[0];
    may23_DW.RateTransition_Buffer_d[24] =
      may23_B.sf_splitKINDataarm2.link_acceleration[0];
    may23_DW.RateTransition_Buffer_d[26] =
      may23_B.sf_splitKINDataarm2.hand_position[0];
    may23_DW.RateTransition_Buffer_d[28] =
      may23_B.sf_splitKINDataarm2.motor_torque_cmd[0];
    may23_DW.RateTransition_Buffer_d[21] =
      may23_B.sf_splitKINDataarm2.link_angle[1];
    may23_DW.RateTransition_Buffer_d[23] =
      may23_B.sf_splitKINDataarm2.link_velocity[1];
    may23_DW.RateTransition_Buffer_d[25] =
      may23_B.sf_splitKINDataarm2.link_acceleration[1];
    may23_DW.RateTransition_Buffer_d[27] =
      may23_B.sf_splitKINDataarm2.hand_position[1];
    may23_DW.RateTransition_Buffer_d[29] =
      may23_B.sf_splitKINDataarm2.motor_torque_cmd[1];
    may23_DW.RateTransition_Buffer_d[30] =
      may23_B.sf_splitKINDataarm2.force_sensor_force_xyz[0];
    may23_DW.RateTransition_Buffer_d[33] =
      may23_B.sf_splitKINDataarm2.force_sensor_torque_xyz[0];
    may23_DW.RateTransition_Buffer_d[31] =
      may23_B.sf_splitKINDataarm2.force_sensor_force_xyz[1];
    may23_DW.RateTransition_Buffer_d[34] =
      may23_B.sf_splitKINDataarm2.force_sensor_torque_xyz[1];
    may23_DW.RateTransition_Buffer_d[32] =
      may23_B.sf_splitKINDataarm2.force_sensor_force_xyz[2];
    may23_DW.RateTransition_Buffer_d[35] =
      may23_B.sf_splitKINDataarm2.force_sensor_torque_xyz[2];
    may23_DW.RateTransition_Buffer_d[36] =
      may23_B.sf_splitKINDataarm2.force_sensor_timestamp;
    may23_DW.RateTransition_Buffer_d[37] = may23_B.dd_out[1];
    may23_DW.RateTransition_Buffer_d[38] = may23_B.torquefeedback1[2];
    may23_DW.RateTransition_Buffer_d[39] = may23_B.torquefeedback1[3];
    may23_DW.RateTransition_Buffer_d[40] = may23_B.Convert19[0];
    may23_DW.RateTransition_Buffer_d[41] = may23_B.Convert19[1];
    may23_DW.RateTransition_Buffer_d[42] = may23_B.Convert19[2];
    may23_DW.RateTransition_Buffer_d[43] = may23_B.Convert1_n;
    may23_DW.RateTransition_Buffer_d[44] = may23_B.Convert4[0];
    may23_DW.RateTransition_Buffer_d[45] = may23_B.Convert4[1];
    may23_DW.RateTransition_Buffer_d[46] = may23_B.Convert4[2];
    may23_DW.RateTransition_Buffer_d[47] = may23_B.pupil_GLOBAL[0];
    may23_DW.RateTransition_Buffer_d[48] = may23_B.pupil_GLOBAL[1];
    may23_DW.RateTransition_Buffer_d[49] = may23_B.pupil_GLOBAL[2];
    may23_DW.RateTransition_Buffer_d[50] = may23_B.RateTransition_i[0];
    may23_DW.RateTransition_Buffer_d[51] = may23_B.RateTransition_i[1];
    may23_DW.RateTransition_Buffer_d[52] = may23_B.RateTransition_i[2];
    memcpy(&may23_DW.RateTransition_Buffer_d[53], &may23_B.Convert19_h[0], 14U *
           sizeof(real_T));
    may23_DW.RateTransition_Buffer_d[67] = may23_B.touint1;
    may23_DW.RateTransition_Buffer_d[68] = may23_B.sf_split_primary.link_angles
      [0];
    may23_DW.RateTransition_Buffer_d[69] = may23_B.sf_split_primary.link_angles
      [1];
    may23_DW.RateTransition_Buffer_d[70] =
      may23_B.sf_split_primary1.link_angles[0];
    may23_DW.RateTransition_Buffer_d[71] =
      may23_B.sf_split_primary1.link_angles[1];
  }

  /* End of RateTransition: '<S25>/Rate Transition' */

  /* DataTypeConversion: '<S26>/Button Status' */
  may23_B.ButtonStatus = may23_B.calibrationButtonBits;

  /* DataTypeConversion: '<S26>/Current Block Index' */
  may23_B.CurrentBlockIndex = may23_B.Convert23;

  /* DataTypeConversion: '<S26>/Current Block Number in Set' */
  may23_B.CurrentBlockNumberinSet = may23_B.Convert21;

  /* DataTypeConversion: '<S26>/Current TP Index' */
  may23_B.CurrentTPIndex = may23_B.Convert24;

  /* DataTypeConversion: '<S26>/Current Trial Number in Block' */
  may23_B.CurrentTrialNumberinBlock = may23_B.Convert22;

  /* DataTypeConversion: '<S26>/Current Trial Number in Set' */
  may23_B.CurrentTrialNumberinSet = may23_B.Convert19_e;

  /* RelationalOperator: '<S47>/Compare' incorporates:
   *  Constant: '<S47>/Constant'
   */
  may23_B.Compare_o = (uint8_T)(may23_B.Convert20 == may23_P.IfRunning_const);

  /* S-Function (slrtUDPReceive): '<S9>/Receive' */

  /* Level2 S-Function Block: '<S9>/Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[42];
    sfcnOutputs(rts,0);
  }

  /* S-Function (xpcbytepacking): '<S9>/Unpack' */

  /* Byte Unpacking: <S9>/Unpack */
  (void)memcpy((uint8_T*)&may23_B.Unpack, (uint8_T*)&may23_B.Receive_o1[0] + 0,
               4);

  /* DataTypeConversion: '<S9>/Convert1' */
  may23_B.Convert1 = may23_B.Unpack;

  /* MATLAB Function: '<S9>/MATLAB Function' */
  /* MATLAB Function 'Process_Video_CMD/MATLAB Function': '<S382>:1' */
  /* '<S382>:1:11' */
  may23_B.last_frame_ack = may23_DW.last_valid_frame_ack;

  /* '<S382>:1:12' */
  may23_B.last_perm_ack = may23_DW.last_perm_frame_ack;
  if (may23_B.Receive_o2 == 8.0) {
    /* '<S382>:1:14' */
    /* '<S382>:1:15' */
    may23_B.last_perm_ack = may23_B.Convert1;

    /* '<S382>:1:16' */
    may23_DW.last_perm_frame_ack = may23_B.Convert1;
  } else {
    if (may23_B.Receive_o2 == 4.0) {
      /* '<S382>:1:17' */
      /* '<S382>:1:21' */
      may23_B.last_frame_ack = may23_B.Convert1;

      /* '<S382>:1:22' */
      may23_DW.last_valid_frame_ack = may23_B.Convert1;

      /* '<S382>:1:23' */
      may23_DW.last_perm_frame_ack = may23_B.Convert1;

      /* '<S382>:1:24' */
      may23_B.last_perm_ack = may23_B.Convert1;
    }
  }

  /* End of MATLAB Function: '<S9>/MATLAB Function' */

  /* DataTypeConversion: '<S26>/Last Frame Acknowledged' */
  may23_B.LastFrameAcknowledged = may23_B.last_frame_ack;

  /* Outputs for Atomic SubSystem: '<S9>/PVC_core' */
  may23_PVC_coreTID0();

  /* End of Outputs for SubSystem: '<S9>/PVC_core' */

  /* DataTypeConversion: '<S9>/Convert' */
  may23_B.Convert = may23_B.RateTransition1_o;

  /* DataTypeConversion: '<S26>/Last Frame Sent' */
  may23_B.LastFrameSent = may23_B.Convert;

  /* DataTypeConversion: '<S26>/Last Frame Sent1' */
  may23_B.LastFrameSent1 = may23_B.Convert25;

  /* Product: '<S26>/Product' */
  may23_B.Product_f = (uint8_T)(may23_B.logging_enable ? (int32_T)
    may23_B.Compare_o : 0);

  /* DataTypeConversion: '<S26>/Logging Enable' */
  may23_B.LoggingEnable = may23_B.Product_f;

  /* DataTypeConversion: '<S26>/Servo update count' */
  may23_B.Servoupdatecount = may23_B.servoCounter;

  /* RateTransition: '<S26>/Rate Transition' */
  may23_B.RateTransition = may23_B.Servoupdatecount;

  /* RateTransition: '<S26>/Rate Transition1' */
  may23_B.RateTransition1_h = may23_B.ButtonStatus;

  /* DataTypeConversion: '<S26>/Run Status' */
  may23_B.RunStatus = may23_B.Convert20;

  /* RateTransition: '<S26>/Rate Transition10' */
  may23_B.RateTransition10 = may23_B.RunStatus;

  /* DataTypeConversion: '<S26>/Task Control Button' */
  may23_B.TaskControlButton = may23_B.value;

  /* RateTransition: '<S26>/Rate Transition11' */
  may23_B.RateTransition11 = may23_B.TaskControlButton;

  /* RateTransition: '<S26>/Rate Transition12' */
  may23_B.RateTransition12 = may23_B.LastFrameSent1;

  /* RateTransition: '<S26>/Rate Transition2' */
  may23_B.RateTransition2_k = may23_B.LastFrameAcknowledged;

  /* RateTransition: '<S26>/Rate Transition3' */
  may23_B.RateTransition3 = may23_B.LastFrameSent;

  /* RateTransition: '<S26>/Rate Transition4' */
  may23_B.RateTransition4 = may23_B.CurrentTrialNumberinSet;

  /* RateTransition: '<S26>/Rate Transition5' */
  may23_B.RateTransition5 = may23_B.CurrentBlockNumberinSet;

  /* RateTransition: '<S26>/Rate Transition6' */
  may23_B.RateTransition6 = may23_B.CurrentTrialNumberinBlock;

  /* RateTransition: '<S26>/Rate Transition7' */
  may23_B.RateTransition7 = may23_B.CurrentBlockIndex;

  /* RateTransition: '<S26>/Rate Transition8' */
  may23_B.RateTransition8 = may23_B.CurrentTPIndex;

  /* RateTransition: '<S26>/Rate Transition9' */
  may23_B.RateTransition9 = may23_B.LoggingEnable;

  /* RateTransition generated from: '<S26>/Timestamp' */
  if (may23_M->Timing.RateInteraction.TID1_3) {
    may23_B.TmpRTBAtTimestampOutport1 =
      may23_DW.TmpRTBAtTimestampOutport1_Buffer0;
  }

  /* End of RateTransition generated from: '<S26>/Timestamp' */

  /* DataTypeConversion: '<S26>/conv' */
  may23_B.conv = may23_ConstB.Width_f;

  /* Outputs for Atomic SubSystem: '<S1>/Network Transfer Subsystem' */
  may23_NetworkTransferSubsystemTID0();

  /* End of Outputs for SubSystem: '<S1>/Network Transfer Subsystem' */

  /* SignalConversion generated from: '<S320>/ SFunction ' incorporates:
   *  MATLAB Function: '<S34>/delta'
   */
  may23_B.TmpSignalConversionAtSFunctionInport1_j[0] =
    may23_B.sf_splitKINDataarm1.link_angle[0];
  may23_B.TmpSignalConversionAtSFunctionInport1_j[1] =
    may23_B.sf_splitKINDataarm1.link_angle[1];
  may23_B.TmpSignalConversionAtSFunctionInport1_j[2] =
    may23_B.sf_splitKINDataarm2.link_angle[0];
  may23_B.TmpSignalConversionAtSFunctionInport1_j[3] =
    may23_B.sf_splitKINDataarm2.link_angle[1];

  /* SignalConversion generated from: '<S320>/ SFunction ' incorporates:
   *  MATLAB Function: '<S34>/delta'
   */
  may23_B.TmpSignalConversionAtSFunctionInport2_n[0] =
    may23_B.sf_split_primary.link_angles[0];
  may23_B.TmpSignalConversionAtSFunctionInport2_n[1] =
    may23_B.sf_split_primary.link_angles[1];
  may23_B.TmpSignalConversionAtSFunctionInport2_n[2] =
    may23_B.sf_split_primary1.link_angles[0];
  may23_B.TmpSignalConversionAtSFunctionInport2_n[3] =
    may23_B.sf_split_primary1.link_angles[1];

  /* MATLAB Function: '<S34>/delta' */
  /* MATLAB Function 'DataLogging/compare encoders/delta': '<S320>:1' */
  /* '<S320>:1:4' */
  may23_B.deltas[0] = may23_B.TmpSignalConversionAtSFunctionInport1_j[0] -
    may23_B.TmpSignalConversionAtSFunctionInport2_n[0];
  may23_B.deltas[1] = may23_B.TmpSignalConversionAtSFunctionInport1_j[1] -
    may23_B.TmpSignalConversionAtSFunctionInport2_n[1];
  may23_B.deltas[2] = may23_B.TmpSignalConversionAtSFunctionInport1_j[2] -
    may23_B.TmpSignalConversionAtSFunctionInport2_n[2];
  may23_B.deltas[3] = may23_B.TmpSignalConversionAtSFunctionInport1_j[3] -
    may23_B.TmpSignalConversionAtSFunctionInport2_n[3];

  /* Delay: '<S34>/Delay' */
  may23_B.Delay = may23_DW.Delay_DSTATE[0];

  /* Product: '<S34>/Product' */
  may23_B.Product_b[0] = may23_B.deltas[0] * may23_B.Delay;
  may23_B.Product_b[1] = may23_B.deltas[1] * may23_B.Delay;
  may23_B.Product_b[2] = may23_B.deltas[2] * may23_B.Delay;
  may23_B.Product_b[3] = may23_B.deltas[3] * may23_B.Delay;

  /* MATLAB Function: '<S360>/MATLAB Function' */
  may23_MATLABFunction_br(may23_B.sf_splitKINDataarm1.motor_status,
    may23_B.torquefeedback1[8], may23_B.isECAT_b, &may23_B.sf_MATLABFunction_b);

  /* Constant: '<S4>/up_duration(ms)' */
  may23_B.up_durationms = may23_P.KINARM_EP_Apply_Loads_up_duration;

  /* Constant: '<S4>/down_duration(ms)' */
  may23_B.down_durationms = may23_P.KINARM_EP_Apply_Loads_down_duration;

  /* DataTypeConversion: '<S4>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_ft = (may23_B.isEP_a != 0.0);

  /* Chart: '<S4>/Ramp_Up_Down' */
  may23_Ramp_Up_Down(may23_B.Convert17,
                     may23_B.sf_MATLABFunction_b.motors_enabled,
                     may23_B.Convert16, may23_B.up_durationms,
                     may23_B.down_durationms, may23_B.DataTypeConversion1_ft,
                     &may23_B.sf_Ramp_Up_Down, &may23_DW.sf_Ramp_Up_Down,
                     &may23_PrevZCX.sf_Ramp_Up_Down);

  /* Constant: '<S5>/up_duration(ms)' */
  may23_B.up_durationms_h = may23_P.KINARM_Exo_Apply_Loads_up_duration;

  /* Constant: '<S5>/down_duration(ms)' */
  may23_B.down_durationms_b = may23_P.KINARM_Exo_Apply_Loads_down_duration;

  /* DataTypeConversion: '<S5>/Data Type Conversion' */
  may23_B.DataTypeConversion_pv = may23_B.robottype_a;

  /* Chart: '<S5>/Ramp_Up_Down' */
  may23_Ramp_Up_Down_g(may23_B.Convert17,
                       may23_B.sf_splitKINDataarm1.motor_status,
                       may23_B.Convert16, may23_B.up_durationms_h,
                       may23_B.down_durationms_b, may23_B.DataTypeConversion_pv,
                       &may23_B.sf_Ramp_Up_Down_g, &may23_DW.sf_Ramp_Up_Down_g,
                       &may23_PrevZCX.sf_Ramp_Up_Down_g);

  /* Sum: '<S38>/AddR1' */
  may23_B.AddR1 = may23_B.sf_Ramp_Up_Down.scaling +
    may23_B.sf_Ramp_Up_Down_g.scaling;

  /* MATLAB Function: '<S361>/MATLAB Function' */
  may23_MATLABFunction_br(may23_B.sf_splitKINDataarm2.motor_status,
    may23_B.torquefeedback1[9], may23_B.isECAT_i, &may23_B.sf_MATLABFunction_gh);

  /* Constant: '<S4>/up_duration(ms)1' */
  may23_B.up_durationms1 = may23_P.KINARM_EP_Apply_Loads_up_duration;

  /* Constant: '<S4>/down_duration(ms)1' */
  may23_B.down_durationms1 = may23_P.KINARM_EP_Apply_Loads_down_duration;

  /* DataTypeConversion: '<S4>/Data Type Conversion' */
  may23_B.DataTypeConversion_gj = (may23_B.isEP_e != 0.0);

  /* Chart: '<S4>/Ramp_Up_Down1' */
  may23_Ramp_Up_Down(may23_B.Convert17,
                     may23_B.sf_MATLABFunction_gh.motors_enabled,
                     may23_B.Convert16, may23_B.up_durationms1,
                     may23_B.down_durationms1, may23_B.DataTypeConversion_gj,
                     &may23_B.sf_Ramp_Up_Down1, &may23_DW.sf_Ramp_Up_Down1,
                     &may23_PrevZCX.sf_Ramp_Up_Down1);

  /* DataTypeConversion: '<S5>/Data Type Conversion1' */
  may23_B.DataTypeConversion1 = may23_B.robottype_j;

  /* Chart: '<S5>/Ramp_Up_Down1' */
  may23_Ramp_Up_Down_g(may23_B.Convert17,
                       may23_B.sf_splitKINDataarm2.motor_status,
                       may23_B.Convert16, may23_B.up_durationms_h,
                       may23_B.down_durationms_b, may23_B.DataTypeConversion1,
                       &may23_B.sf_Ramp_Up_Down1_h, &may23_DW.sf_Ramp_Up_Down1_h,
                       &may23_PrevZCX.sf_Ramp_Up_Down1_h);

  /* Sum: '<S38>/AddR2' */
  may23_B.AddR2 = may23_B.sf_Ramp_Up_Down1.scaling +
    may23_B.sf_Ramp_Up_Down1_h.scaling;

  /* MATLAB Function: '<S38>/current_limits' */
  /* MATLAB Function 'DataLogging/monitor torques/current_limits': '<S326>:1' */
  /* '<S326>:1:3' */
  hold_steps = may23_B.torquefeedback1[4];
  hold_steps += may23_B.torquefeedback1[5];
  hold_steps += may23_B.torquefeedback1[6];
  hold_steps += may23_B.torquefeedback1[7];
  may23_B.robot_limits[0] = may23_B.torquefeedback1[4] +
    may23_B.torquefeedback1[5];
  may23_B.robot_limits[1] = may23_B.torquefeedback1[6] +
    may23_B.torquefeedback1[7];
  may23_B.robot_limits[2] = hold_steps;

  /* RelationalOperator: '<S324>/Compare' incorporates:
   *  Constant: '<S324>/Constant'
   */
  may23_B.Compare_d = (may23_B.systemtype == may23_P.CompareToConstant_const);

  /* Delay: '<S327>/Delay' */
  may23_B.Delay_a[0] = may23_DW.Delay_DSTATE_e[0];

  /* SignalConversion generated from: '<S328>/ SFunction ' incorporates:
   *  MATLAB Function: '<S38>/filter'
   */
  may23_B.TmpSignalConversionAtSFunctionInport1[0] = may23_B.Delay_a[0];

  /* Delay: '<S327>/Delay' */
  may23_B.Delay_a[1] = may23_DW.Delay_DSTATE_e[1];

  /* SignalConversion generated from: '<S328>/ SFunction ' incorporates:
   *  MATLAB Function: '<S38>/filter'
   */
  may23_B.TmpSignalConversionAtSFunctionInport1[1] = may23_B.Delay_a[1];

  /* Delay: '<S327>/Delay' */
  may23_B.Delay_a[2] = may23_DW.Delay_DSTATE_e[2];

  /* SignalConversion generated from: '<S328>/ SFunction ' incorporates:
   *  MATLAB Function: '<S38>/filter'
   */
  may23_B.TmpSignalConversionAtSFunctionInport1[2] = may23_B.Delay_a[2];

  /* Delay: '<S327>/Delay' */
  may23_B.Delay_a[3] = may23_DW.Delay_DSTATE_e[3];

  /* SignalConversion generated from: '<S328>/ SFunction ' incorporates:
   *  MATLAB Function: '<S38>/filter'
   */
  may23_B.TmpSignalConversionAtSFunctionInport1[3] = may23_B.Delay_a[3];
  may23_B.TmpSignalConversionAtSFunctionInport1[4] = may23_B.torquefeedback1[0];
  may23_B.TmpSignalConversionAtSFunctionInport1[5] = may23_B.torquefeedback1[1];
  may23_B.TmpSignalConversionAtSFunctionInport1[6] = may23_B.torquefeedback1[2];
  may23_B.TmpSignalConversionAtSFunctionInport1[7] = may23_B.torquefeedback1[3];

  /* MATLAB Function: '<S38>/filter' incorporates:
   *  Constant: '<S38>/butterworth_2nd_order_10hz'
   */
  /* MATLAB Function 'DataLogging/monitor torques/filter': '<S328>:1' */
  /* '<S328>:1:20' */
  /* '<S328>:1:1' */
  /* '<S328>:1:18' */
  for (inputEventFiredFlag = 0; inputEventFiredFlag < 8; inputEventFiredFlag++)
  {
    /* '<S328>:1:18' */
    /* '<S328>:1:19' */
    /* '<S328>:1:20' */
    /* '<S328>:1:41' */
    hold_steps = may23_DW.rawVelocities[inputEventFiredFlag + 8];

    /* '<S328>:1:42' */
    x = may23_DW.rawVelocities[inputEventFiredFlag + 16];

    /* '<S328>:1:43' */
    out_of_spec_motors_idx_2 =
      may23_B.TmpSignalConversionAtSFunctionInport1[inputEventFiredFlag] /
      may23_P.butterworth_2nd_order_10hz_Value[0];

    /* '<S328>:1:21' */
    /* '<S328>:1:41' */
    out_of_spec_motors_idx_3 = may23_DW.filtVelocities[inputEventFiredFlag + 8];

    /* '<S328>:1:42' */
    L2ptr_ANG = may23_DW.filtVelocities[inputEventFiredFlag + 16];

    /* '<S328>:1:43' */
    may23_DW.rawVelocities[inputEventFiredFlag] = hold_steps;
    may23_DW.filtVelocities[inputEventFiredFlag] = out_of_spec_motors_idx_3;
    may23_DW.rawVelocities[inputEventFiredFlag + 8] = x;
    may23_DW.filtVelocities[inputEventFiredFlag + 8] = L2ptr_ANG;
    may23_DW.rawVelocities[inputEventFiredFlag + 16] = out_of_spec_motors_idx_2;
    may23_DW.filtVelocities[inputEventFiredFlag + 16] = 0.0;

    /* '<S328>:1:22' */
    /* '<S328>:1:29' */
    hold_steps = (((may23_DW.rawVelocities[inputEventFiredFlag + 8] * 2.0 +
                    may23_DW.rawVelocities[inputEventFiredFlag]) +
                   may23_DW.rawVelocities[inputEventFiredFlag + 16]) +
                  may23_DW.filtVelocities[inputEventFiredFlag] *
                  may23_P.butterworth_2nd_order_10hz_Value[1]) +
      may23_DW.filtVelocities[inputEventFiredFlag + 8] *
      may23_P.butterworth_2nd_order_10hz_Value[2];
    if (rtIsNaN(hold_steps) || rtIsInf(hold_steps)) {
      /* '<S328>:1:35' */
      /* '<S328>:1:36' */
      hold_steps = 0.0;
    }

    may23_DW.filtVelocities[inputEventFiredFlag + 16] = hold_steps;

    /* '<S328>:1:23' */
    may23_B.filteredVals[inputEventFiredFlag] =
      may23_DW.filtVelocities[inputEventFiredFlag + 16];
  }

  /* DataStoreRead: '<S38>/Data Store Read' */
  memcpy(&may23_B.DataStoreRead[0], &may23_DW.ECATHardware[0], 14U * sizeof
         (real_T));

  /* Product: '<S38>/Product' incorporates:
   *  Constant: '<S38>/abs_diff'
   */
  /* MATLAB Function 'DataLogging/monitor torques/MATLAB Function': '<S325>:1' */
  /* '<S325>:1:4' */
  may23_B.Product_n[0] = may23_B.DataStoreRead[0] * may23_B.DataStoreRead[4] *
    may23_P.abs_diff_Value;

  /* MATLAB Function: '<S38>/MATLAB Function' */
  hold_steps = may23_B.filteredVals[0] - may23_B.filteredVals[4];

  /* Product: '<S38>/Product' incorporates:
   *  Constant: '<S38>/abs_diff'
   */
  may23_B.Product_n[1] = may23_B.DataStoreRead[1] * may23_B.DataStoreRead[5] *
    may23_P.abs_diff_Value;

  /* MATLAB Function: '<S38>/MATLAB Function' */
  x = may23_B.filteredVals[1] - may23_B.filteredVals[5];

  /* Product: '<S38>/Product' incorporates:
   *  Constant: '<S38>/abs_diff'
   */
  may23_B.Product_n[2] = may23_B.DataStoreRead[2] * may23_B.DataStoreRead[6] *
    may23_P.abs_diff_Value;

  /* MATLAB Function: '<S38>/MATLAB Function' */
  out_of_spec_motors_idx_2 = may23_B.filteredVals[2] - may23_B.filteredVals[6];

  /* Product: '<S38>/Product' incorporates:
   *  Constant: '<S38>/abs_diff'
   */
  may23_B.Product_n[3] = may23_B.DataStoreRead[3] * may23_B.DataStoreRead[7] *
    may23_P.abs_diff_Value;

  /* MATLAB Function: '<S38>/MATLAB Function' incorporates:
   *  Constant: '<S38>/rel_diff'
   */
  out_of_spec_motors_idx_3 = may23_B.filteredVals[3] - may23_B.filteredVals[7];
  may23_B.abs_diff[0] = fabs(hold_steps);
  may23_B.abs_diff[1] = fabs(x);
  may23_B.abs_diff[2] = fabs(out_of_spec_motors_idx_2);
  may23_B.abs_diff[3] = fabs(out_of_spec_motors_idx_3);

  /* '<S325>:1:5' */
  may23_B.rel_diff[0] = may23_B.abs_diff[0] / may23_B.filteredVals[0];
  may23_B.rel_diff[1] = may23_B.abs_diff[1] / may23_B.filteredVals[1];
  may23_B.rel_diff[2] = may23_B.abs_diff[2] / may23_B.filteredVals[2];
  may23_B.rel_diff[3] = may23_B.abs_diff[3] / may23_B.filteredVals[3];

  /* '<S325>:1:6' */
  zcEvent_idx_0 = (rtIsInf(may23_B.rel_diff[0]) || rtIsNaN(may23_B.rel_diff[0]));
  zcEvent_idx_1 = (rtIsInf(may23_B.rel_diff[1]) || rtIsNaN(may23_B.rel_diff[1]));
  zcEvent_idx_2 = (rtIsInf(may23_B.rel_diff[2]) || rtIsNaN(may23_B.rel_diff[2]));
  zcEvent_idx_3 = (rtIsInf(may23_B.rel_diff[3]) || rtIsNaN(may23_B.rel_diff[3]));
  inputEventFiredFlag = 0;
  if (zcEvent_idx_0) {
    inputEventFiredFlag = 1;
  }

  if (zcEvent_idx_1) {
    inputEventFiredFlag++;
  }

  if (zcEvent_idx_2) {
    inputEventFiredFlag++;
  }

  if (zcEvent_idx_3) {
    inputEventFiredFlag++;
  }

  xoffset = inputEventFiredFlag;
  inputEventFiredFlag = 0;
  if (zcEvent_idx_0) {
    b_data[0] = 1;
    inputEventFiredFlag = 1;
  }

  if (zcEvent_idx_1) {
    b_data[inputEventFiredFlag] = 2;
    inputEventFiredFlag++;
  }

  if (zcEvent_idx_2) {
    b_data[inputEventFiredFlag] = 3;
    inputEventFiredFlag++;
  }

  if (zcEvent_idx_3) {
    b_data[inputEventFiredFlag] = 4;
  }

  /* '<S325>:1:6' */
  for (i = 0; i < xoffset; i++) {
    may23_B.rel_diff[b_data[i] - 1] = 0.0;
  }

  /* '<S325>:1:8' */
  hold_steps = (may23_B.abs_diff[0] >= may23_B.Product_n[0]) +
    (may23_B.rel_diff[0] >= may23_P.rel_diff_Value);
  x = (may23_B.abs_diff[1] >= may23_B.Product_n[1]) + (may23_B.rel_diff[1] >=
    may23_P.rel_diff_Value);
  out_of_spec_motors_idx_2 = (may23_B.abs_diff[2] >= may23_B.Product_n[2]) +
    (may23_B.rel_diff[2] >= may23_P.rel_diff_Value);
  out_of_spec_motors_idx_3 = (may23_B.abs_diff[3] >= may23_B.Product_n[3]) +
    (may23_B.rel_diff[3] >= may23_P.rel_diff_Value);

  /* '<S325>:1:9' */
  zcEvent = (hold_steps == 2.0);
  zcEvent_idx_0 = (out_of_spec_motors_idx_2 == 2.0);
  zcEvent_idx_1 = (x == 2.0);
  zcEvent_idx_2 = (out_of_spec_motors_idx_3 == 2.0);
  may23_B.robot_failures[0] = (zcEvent + zcEvent_idx_1 > 0);
  may23_B.robot_failures[1] = (zcEvent_idx_0 + zcEvent_idx_2 > 0);

  /* '<S325>:1:10' */
  /* '<S325>:1:11' */
  a = (int8_T)(hold_steps == 2.0);
  c_idx_0 = a;
  a = (int8_T)(x == 2.0);
  c_idx_1 = (int8_T)((uint32_T)a << 1U);
  a = (int8_T)(out_of_spec_motors_idx_2 == 2.0);
  c_idx_2 = (int8_T)((uint32_T)a << 2U);
  a = (int8_T)(out_of_spec_motors_idx_3 == 2.0);
  a = (int8_T)((uint32_T)a << 3U);
  may23_B.torque_err_bitfield = c_idx_0;
  may23_B.torque_err_bitfield += (real_T)c_idx_1;
  may23_B.torque_err_bitfield += (real_T)c_idx_2;
  may23_B.torque_err_bitfield += (real_T)a;

  /* Delay: '<S38>/Delay' */
  may23_B.Delay_l = may23_DW.Delay_DSTATE_m[0];

  /* DiscretePulseGenerator: '<S38>/Task Clock' */
  may23_B.TaskClock_h = (may23_DW.clockTickCounter_c < may23_P.TaskClock_Duty_f)
    && (may23_DW.clockTickCounter_c >= 0) ? may23_P.TaskClock_Amp_l : 0.0;
  if (may23_DW.clockTickCounter_c >= may23_P.TaskClock_Period_m - 1.0) {
    may23_DW.clockTickCounter_c = 0;
  } else {
    may23_DW.clockTickCounter_c++;
  }

  /* End of DiscretePulseGenerator: '<S38>/Task Clock' */

  /* Chart: '<S38>/torque_monitor' incorporates:
   *  TriggerPort: '<S330>/e_clk'
   */
  zcEvent_idx_0_0 = rt_ZCFcn(RISING_ZERO_CROSSING,
    &may23_PrevZCX.torque_monitor_Trig_ZCE,
    (may23_B.TaskClock_h));
  if (zcEvent_idx_0_0 != NO_ZCEVENT) {
    may23_B.e_clk = (int8_T)zcEvent_idx_0_0;

    /* SignalConversion generated from: '<S330>/ SFunction ' */
    may23_B.TmpSignalConversionAtSFunctionInport2[0] = may23_B.AddR1;
    may23_B.TmpSignalConversionAtSFunctionInport2[1] = may23_B.AddR2;

    /* Gateway: DataLogging/monitor torques/torque_monitor */
    if (may23_DW.temporalCounter_i1_c < 1023U) {
      may23_DW.temporalCounter_i1_c++;
    }

    if (may23_DW.temporalCounter_i2 < 1023U) {
      may23_DW.temporalCounter_i2++;
    }

    /* Event: '<S330>:14' */
    may23_DW.sfEvent_bs = may23_event_e_clk_p;

    /* During: DataLogging/monitor torques/torque_monitor */
    if (may23_DW.is_active_c108_General == 0U) {
      /* Entry: DataLogging/monitor torques/torque_monitor */
      may23_DW.is_active_c108_General = 1U;

      /* Entry Internal: DataLogging/monitor torques/torque_monitor */
      /* Transition: '<S330>:8' */
      may23_DW.is_c108_General = may23_IN_init_h;

      /* Entry 'init': '<S330>:7' */
      may23_B.command_multiplier = 1.0;
      may23_B.stop_vel_mode = 0.0;
      may23_B.robot_err_bits_out = 0.0;
    } else {
      switch (may23_DW.is_c108_General) {
       case may23_IN_CurrentLimited:
        /* During 'CurrentLimited': '<S330>:82' */
        if (may23_B.robot_limits[2] == 0.0) {
          /* Transition: '<S330>:85' */
          /* Transition: '<S330>:87' */
          may23_DW.is_c108_General = may23_IN_Wait_e;
          may23_DW.temporalCounter_i1_c = 0U;
        }
        break;

       case may23_IN_Done_o:
        /* During 'Done': '<S330>:11' */
        break;

       case may23_IN_EpMonitor:
        /* During 'EpMonitor': '<S330>:17' */
        /* During 'Robot1': '<S330>:23' */
        switch (may23_DW.is_Robot1) {
         case may23_IN_CurrentLimited:
          /* During 'CurrentLimited': '<S330>:49' */
          if (may23_B.robot_limits[0] == 0.0) {
            /* Transition: '<S330>:52' */
            may23_DW.is_Robot1 = may23_IN_Pause;
            may23_DW.temporalCounter_i1_c = 0U;
          }
          break;

         case may23_IN_Err:
          /* During 'Err': '<S330>:29' */
          break;

         case may23_IN_Pause:
          /* During 'Pause': '<S330>:51' */
          if ((may23_DW.sfEvent_bs == may23_event_e_clk_p) &&
              (may23_DW.temporalCounter_i1_c >= 1000)) {
            /* Transition: '<S330>:56' */
            may23_DW.is_Robot1 = may23_IN_not_holding;
          }
          break;

         case may23_IN_Waiting_n:
          /* During 'Waiting': '<S330>:24' */
          if ((may23_B.torquefeedback1[8] == 0.0) ||
              (may23_B.TmpSignalConversionAtSFunctionInport2[0] != 1.0)) {
            /* Transition: '<S330>:27' */
            may23_DW.is_Robot1 = may23_IN_not_holding;
          } else {
            /* Transition: '<S330>:48' */
            if (may23_B.robot_limits[0] != 0.0) {
              /* Transition: '<S330>:50' */
              may23_DW.is_Robot1 = may23_IN_CurrentLimited;
            } else {
              if (may23_B.robot_failures[0]) {
                /* Transition: '<S330>:30' */
                may23_B.robot_err_bits_out = may23_B.torque_err_bitfield;
                may23_DW.is_Robot1 = may23_IN_Err;

                /* Entry 'Err': '<S330>:29' */
                may23_B.command_multiplier = 0.0;
                may23_B.stop_vel_mode = 1.0;
              }
            }
          }
          break;

         default:
          /* During 'not_holding': '<S330>:26' */
          if ((may23_B.torquefeedback1[8] == 1.0) &&
              (may23_B.TmpSignalConversionAtSFunctionInport2[0] == 1.0)) {
            /* Transition: '<S330>:28' */
            may23_DW.is_Robot1 = may23_IN_Waiting_n;
          }
          break;
        }

        /* During 'Robot2': '<S330>:60' */
        switch (may23_DW.is_Robot2) {
         case may23_IN_CurrentLimited:
          /* During 'CurrentLimited': '<S330>:74' */
          if (may23_B.robot_limits[1] == 0.0) {
            /* Transition: '<S330>:76' */
            may23_DW.is_Robot2 = may23_IN_Pause;
            may23_DW.temporalCounter_i2 = 0U;
          }
          break;

         case may23_IN_Err:
          /* During 'Err': '<S330>:62' */
          break;

         case may23_IN_Pause:
          /* During 'Pause': '<S330>:70' */
          if ((may23_DW.sfEvent_bs == may23_event_e_clk_p) &&
              (may23_DW.temporalCounter_i2 >= 1000)) {
            /* Transition: '<S330>:73' */
            may23_DW.is_Robot2 = may23_IN_not_holding;
          }
          break;

         case may23_IN_Waiting_n:
          /* During 'Waiting': '<S330>:59' */
          if ((may23_B.torquefeedback1[9] == 0.0) ||
              (may23_B.TmpSignalConversionAtSFunctionInport2[1] != 1.0)) {
            /* Transition: '<S330>:65' */
            may23_DW.is_Robot2 = may23_IN_not_holding;
          } else {
            /* Transition: '<S330>:77' */
            if (may23_B.robot_limits[1] != 0.0) {
              /* Transition: '<S330>:67' */
              may23_DW.is_Robot2 = may23_IN_CurrentLimited;
            } else {
              if (may23_B.robot_failures[1]) {
                /* Transition: '<S330>:66' */
                may23_B.robot_err_bits_out = may23_B.torque_err_bitfield;
                may23_DW.is_Robot2 = may23_IN_Err;

                /* Entry 'Err': '<S330>:62' */
                may23_B.command_multiplier = 0.0;
                may23_B.stop_vel_mode = 1.0;
              }
            }
          }
          break;

         default:
          /* During 'not_holding': '<S330>:61' */
          if ((may23_B.torquefeedback1[9] == 1.0) &&
              (may23_B.TmpSignalConversionAtSFunctionInport2[1] == 1.0)) {
            /* Transition: '<S330>:64' */
            may23_DW.is_Robot2 = may23_IN_Waiting_n;
          }
          break;
        }
        break;

       case may23_IN_ErrorFound:
        /* During 'ErrorFound': '<S330>:15' */
        break;

       case may23_IN_ExoMonitor:
        /* During 'ExoMonitor': '<S330>:19' */
        if ((may23_B.TmpSignalConversionAtSFunctionInport2[0] != 1.0) ||
            (may23_B.TmpSignalConversionAtSFunctionInport2[1] != 1.0)) {
          /* Transition: '<S330>:41' */
          may23_DW.is_c108_General = may23_IN_eStopdown;
        } else {
          /* Transition: '<S330>:81' */
          if (may23_B.robot_failures[0] || may23_B.robot_failures[1]) {
            /* Transition: '<S330>:16' */
            may23_B.robot_err_bits_out = may23_B.torque_err_bitfield;
            may23_DW.is_c108_General = may23_IN_ErrorFound;

            /* Entry 'ErrorFound': '<S330>:15' */
            may23_B.command_multiplier = 0.0;
          } else {
            if (may23_B.robot_limits[2] != 0.0) {
              /* Transition: '<S330>:83' */
              may23_DW.is_c108_General = may23_IN_CurrentLimited;
            }
          }
        }
        break;

       case may23_IN_Monitoring:
        /* During 'Monitoring': '<S330>:12' */
        if (may23_B.isEP_a == 1.0) {
          /* Transition: '<S330>:18' */
          may23_DW.is_c108_General = may23_IN_EpMonitor;

          /* Entry Internal 'EpMonitor': '<S330>:17' */
          may23_DW.is_active_Robot1 = 1U;

          /* Entry Internal 'Robot1': '<S330>:23' */
          /* Transition: '<S330>:25' */
          may23_DW.is_Robot1 = may23_IN_Waiting_n;
          may23_DW.is_active_Robot2 = 1U;

          /* Entry Internal 'Robot2': '<S330>:60' */
          /* Transition: '<S330>:63' */
          may23_DW.is_Robot2 = may23_IN_Waiting_n;
        } else {
          /* Transition: '<S330>:20' */
          may23_DW.is_c108_General = may23_IN_ExoMonitor;
        }
        break;

       case may23_IN_Wait_e:
        /* During 'Wait': '<S330>:86' */
        if ((may23_DW.sfEvent_bs == may23_event_e_clk_p) &&
            (may23_DW.temporalCounter_i1_c >= 1000)) {
          /* Transition: '<S330>:88' */
          may23_DW.is_c108_General = may23_IN_eStopdown;
        }
        break;

       case may23_IN_eStopdown:
        /* During 'eStopdown': '<S330>:40' */
        if ((may23_B.TmpSignalConversionAtSFunctionInport2[0] == 1.0) &&
            (may23_B.TmpSignalConversionAtSFunctionInport2[1] == 1.0)) {
          /* Transition: '<S330>:42' */
          may23_DW.is_c108_General = may23_IN_ExoMonitor;
        }
        break;

       default:
        /* During 'init': '<S330>:7' */
        if (!may23_B.Compare_d) {
          /* Transition: '<S330>:9' */
          may23_DW.is_c108_General = may23_IN_Done_o;
        } else {
          if (may23_B.Delay_l == 1.0) {
            /* Transition: '<S330>:13' */
            may23_DW.is_c108_General = may23_IN_Monitoring;
          }
        }
        break;
      }
    }

    may23_DW.torque_monitor_SubsysRanBC = 4;
  }

  /* RateTransition: '<S1>/Rate Transition' incorporates:
   *  Constant: '<S23>/custom_version'
   */
  if (may23_M->Timing.RateInteraction.TID1_3) {
    may23_DW.RateTransition_Buffer_j[0] = may23_ConstB.Width_g;
    may23_DW.RateTransition_Buffer_j[1] = may23_P.custom_version_Value;
    may23_DW.RateTransition_Buffer_j[2] = may23_B.DataTypeConversion_f[0];
    may23_DW.RateTransition_Buffer_j[3] = may23_B.DataTypeConversion_f[1];
    may23_DW.RateTransition_Buffer_j[4] = may23_B.DataTypeConversion_f[2];
    may23_DW.RateTransition_Buffer_j[5] = may23_B.DataTypeConversion_f[3];
    for (i = 0; i < 6; i++) {
      may23_DW.RateTransition_Buffer_j[i + 6] = may23_B.newMessage[i];
    }

    may23_DW.RateTransition_Buffer_j[12] = may23_B.Product_b[0];
    may23_DW.RateTransition_Buffer_j[13] = may23_B.Product_b[1];
    may23_DW.RateTransition_Buffer_j[14] = may23_B.Product_b[2];
    may23_DW.RateTransition_Buffer_j[15] = may23_B.Product_b[3];
    may23_DW.RateTransition_Buffer_j[16] = may23_B.RateTransition1;
    may23_DW.RateTransition_Buffer_j[17] = may23_B.RateTransition2;
    may23_DW.RateTransition_Buffer_j[18] = may23_B.robot_err_bits_out;
    may23_DW.RateTransition_Buffer_j[19] = may23_B.DataTypeConversion_g;

    /* RateTransition: '<S1>/Rate Transition1' incorporates:
     *  Constant: '<S23>/custom_version'
     *  Constant: '<S26>/packet_version'
     */
    may23_DW.RateTransition1_Buffer[0] = may23_B.TmpRTBAtTimestampOutport1;
    may23_DW.RateTransition1_Buffer[1] = may23_P.packet_version_Value;
    may23_DW.RateTransition1_Buffer[2] = may23_B.conv;
    may23_DW.RateTransition1_Buffer[3] = may23_B.RateTransition10;
    may23_DW.RateTransition1_Buffer[4] = may23_B.RateTransition9;
    may23_DW.RateTransition1_Buffer[5] = may23_B.RateTransition8;
    may23_DW.RateTransition1_Buffer[6] = may23_B.RateTransition7;
    may23_DW.RateTransition1_Buffer[7] = may23_B.RateTransition6;
    may23_DW.RateTransition1_Buffer[8] = may23_B.RateTransition5;
    may23_DW.RateTransition1_Buffer[9] = may23_B.RateTransition4;
    may23_DW.RateTransition1_Buffer[10] = may23_B.RateTransition12;
    may23_DW.RateTransition1_Buffer[11] = may23_B.RateTransition3;
    may23_DW.RateTransition1_Buffer[12] = may23_B.RateTransition2_k;
    may23_DW.RateTransition1_Buffer[13] = may23_B.RateTransition1_h;
    may23_DW.RateTransition1_Buffer[14] = may23_B.RateTransition;
    may23_DW.RateTransition1_Buffer[15] = may23_B.RateTransition11;

    /* RateTransition: '<S1>/Rate Transition2' */
    may23_DW.RateTransition2_Buffer[0] = may23_B.NumberofEventCodes;
    may23_DW.RateTransition2_Buffer[1] = may23_B.EventCodes;
  }

  /* End of RateTransition: '<S1>/Rate Transition' */

  /* Memory: '<S19>/Memory3' */
  may23_B.Memory3[0] = may23_DW.Memory3_PreviousInput[0];
  may23_B.Memory3[1] = may23_DW.Memory3_PreviousInput[1];
  may23_B.Memory3[2] = may23_DW.Memory3_PreviousInput[2];
  may23_B.Memory3[3] = may23_DW.Memory3_PreviousInput[3];

  /* DataTypeConversion: '<S396>/Data Type Conversion' */
  memcpy(&may23_B.DataTypeConversion_bl[0], &may23_B.LoadTable[0], 400U * sizeof
         (real_T));

  /* MATLAB Function: '<S396>/Select Perturbation Times' incorporates:
   *  Constant: '<S396>/load_table_column_indices'
   */
  /* MATLAB Function 'Subsystem/Perturbation/Select Perturbation Times': '<S399>:1' */
  /* '<S399>:1:6' */
  hold_steps = 0.0;

  /* '<S399>:1:7' */
  x = 0.0;

  /* '<S399>:1:8' */
  out_of_spec_motors_idx_2 = 0.0;
  if ((may23_B.load_row > 0.0) && (may23_B.load_row <= 20.0)) {
    /* '<S399>:1:10' */
    if (may23_P.Perturbation_loadcol[0] > 0.0) {
      /* '<S399>:1:11' */
      /* '<S399>:1:12' */
      hold_steps = may23_B.DataTypeConversion_bl[(((int32_T)
        may23_P.Perturbation_loadcol[0] - 1) * 20 + (int32_T)may23_B.load_row) -
        1];
    }

    if (may23_P.Perturbation_loadcol[1] > 0.0) {
      /* '<S399>:1:14' */
      /* '<S399>:1:15' */
      x = may23_B.DataTypeConversion_bl[(((int32_T)may23_P.Perturbation_loadcol
        [1] - 1) * 20 + (int32_T)may23_B.load_row) - 1];
    }

    if (may23_P.Perturbation_loadcol[2] > 0.0) {
      /* '<S399>:1:17' */
      /* '<S399>:1:18' */
      out_of_spec_motors_idx_2 = may23_B.DataTypeConversion_bl[(((int32_T)
        may23_P.Perturbation_loadcol[2] - 1) * 20 + (int32_T)may23_B.load_row) -
        1];
    }
  }

  /* '<S399>:1:22' */
  may23_B.perturbation[0] = hold_steps;
  may23_B.perturbation[1] = x;
  may23_B.perturbation[2] = out_of_spec_motors_idx_2;

  /* End of MATLAB Function: '<S396>/Select Perturbation Times' */

  /* DataTypeConversion: '<S396>/Data Type Conversion2' */
  hold_steps = floor(may23_B.Convert17);
  if (rtIsNaN(hold_steps) || rtIsInf(hold_steps)) {
    hold_steps = 0.0;
  } else {
    hold_steps = fmod(hold_steps, 256.0);
  }

  may23_B.DataTypeConversion2_gv = (uint8_T)(hold_steps < 0.0 ? (int32_T)
    (uint8_T)-(int8_T)(uint8_T)-hold_steps : (int32_T)(uint8_T)hold_steps);

  /* End of DataTypeConversion: '<S396>/Data Type Conversion2' */

  /* MATLAB Function: '<S21>/MATLAB Function' incorporates:
   *  Constant: '<S21>/Constant2'
   */
  /* MATLAB Function 'subsystem for moving the square (updating velocity and checking collision)/MATLAB Function': '<S403>:1' */
  if (may23_P.Constant2_Value_e == 1.0) {
    /* '<S403>:1:4' */
    /* '<S403>:1:5' */
    may23_B.force_vector[0] = may23_B.force_scaling[0];
    may23_B.force_vector[1] = may23_B.force_scaling[1];
    may23_B.force_vector[2] = may23_B.force_scaling[2];
    may23_B.force_vector[3] = may23_B.force_scaling[3];
  } else {
    /* '<S403>:1:7' */
    may23_B.force_vector[0] = may23_B.force_scaling[2];
    may23_B.force_vector[1] = may23_B.force_scaling[3];
    may23_B.force_vector[2] = may23_B.force_scaling[0];
    may23_B.force_vector[3] = may23_B.force_scaling[1];
  }

  /* End of MATLAB Function: '<S21>/MATLAB Function' */

  /* Abs: '<S19>/Abs' */
  may23_B.Abs[0] = fabs(may23_B.force_vector[0]);
  may23_B.Abs[1] = fabs(may23_B.force_vector[1]);
  may23_B.Abs[2] = fabs(may23_B.force_vector[2]);
  may23_B.Abs[3] = fabs(may23_B.force_vector[3]);

  /* Sum: '<S19>/Sum of Elements' */
  hold_steps = may23_B.Abs[0];
  hold_steps += may23_B.Abs[1];
  hold_steps += may23_B.Abs[2];
  hold_steps += may23_B.Abs[3];
  may23_B.SumofElements = hold_steps;

  /* RelationalOperator: '<S395>/Compare' incorporates:
   *  Constant: '<S395>/Constant'
   */
  may23_B.Compare_j = (uint8_T)(may23_B.SumofElements !=
    may23_P.Constant_Value_b);

  /* SignalConversion generated from: '<S398>/ input events ' */
  may23_B.HiddenBuf_InsertedFor_Ramp_up_down_at_inport_3[0] =
    may23_B.DataTypeConversion2_gv;
  may23_B.HiddenBuf_InsertedFor_Ramp_up_down_at_inport_3[1] = may23_B.Compare_j;
  may23_B.HiddenBuf_InsertedFor_Ramp_up_down_at_inport_3[2] = ((uint8_T)0U);

  /* Chart: '<S396>/Ramp_up_down' incorporates:
   *  TriggerPort: '<S398>/ input events '
   */
  zcEvent_idx_2 = (((may23_B.HiddenBuf_InsertedFor_Ramp_up_down_at_inport_3[0] >
                     0) != (may23_PrevZCX.Ramp_up_down_Trig_ZCE[0] == POS_ZCSIG))
                   && (may23_PrevZCX.Ramp_up_down_Trig_ZCE[0] !=
                       UNINITIALIZED_ZCSIG));
  zcEvent = zcEvent_idx_2;
  zcEvent_idx_0 = zcEvent_idx_2;
  zcEvent_idx_2 = (((may23_B.HiddenBuf_InsertedFor_Ramp_up_down_at_inport_3[1] >
                     0) != (may23_PrevZCX.Ramp_up_down_Trig_ZCE[1] == POS_ZCSIG))
                   && (may23_PrevZCX.Ramp_up_down_Trig_ZCE[1] !=
                       UNINITIALIZED_ZCSIG));
  zcEvent = (zcEvent || zcEvent_idx_2);
  zcEvent_idx_1 = zcEvent_idx_2;
  zcEvent_idx_2 = (((may23_B.HiddenBuf_InsertedFor_Ramp_up_down_at_inport_3[2] >
                     0) != (may23_PrevZCX.Ramp_up_down_Trig_ZCE[2] == POS_ZCSIG))
                   && (may23_PrevZCX.Ramp_up_down_Trig_ZCE[2] !=
                       UNINITIALIZED_ZCSIG));
  zcEvent = (zcEvent || zcEvent_idx_2);
  if (zcEvent) {
    may23_B.inputevents_c[0] = (int8_T)(zcEvent_idx_0 ?
      may23_B.HiddenBuf_InsertedFor_Ramp_up_down_at_inport_3[0] > 0 ?
      RISING_ZCEVENT : FALLING_ZCEVENT : NO_ZCEVENT);
    may23_B.inputevents_c[1] = (int8_T)(zcEvent_idx_1 ?
      may23_B.HiddenBuf_InsertedFor_Ramp_up_down_at_inport_3[1] > 0 ?
      RISING_ZCEVENT : FALLING_ZCEVENT : NO_ZCEVENT);
    may23_B.inputevents_c[2] = (int8_T)(zcEvent_idx_2 ?
      may23_B.HiddenBuf_InsertedFor_Ramp_up_down_at_inport_3[2] > 0 ?
      RISING_ZCEVENT : FALLING_ZCEVENT : NO_ZCEVENT);

    /* Gateway: Subsystem/Perturbation/Ramp_up_down */
    if (may23_B.inputevents_c[0U] == 1) {
      if (may23_DW.temporalCounter_i1_n < MAX_uint32_T) {
        may23_DW.temporalCounter_i1_n++;
      }

      /* Event: '<S398>:26' */
      may23_DW.sfEvent_i = may23_event_e_clk_p;
      may23_chartstep_c8_may23();
    }

    if (may23_B.inputevents_c[1U] != 0) {
      /* Event: '<S398>:27' */
      may23_DW.sfEvent_i = may23_event_e_trigger;
      may23_chartstep_c8_may23();
    }

    if (may23_B.inputevents_c[2U] != 0) {
      /* Event: '<S398>:28' */
      may23_DW.sfEvent_i = may23_event_e_reset;
      may23_chartstep_c8_may23();
    }

    may23_DW.Ramp_up_down_SubsysRanBC = 4;
  }

  may23_PrevZCX.Ramp_up_down_Trig_ZCE[0] = (ZCSigState)
    (may23_B.HiddenBuf_InsertedFor_Ramp_up_down_at_inport_3[0] > 0);
  may23_PrevZCX.Ramp_up_down_Trig_ZCE[1] = (ZCSigState)
    (may23_B.HiddenBuf_InsertedFor_Ramp_up_down_at_inport_3[1] > 0);
  may23_PrevZCX.Ramp_up_down_Trig_ZCE[2] = (ZCSigState)
    (may23_B.HiddenBuf_InsertedFor_Ramp_up_down_at_inport_3[2] > 0);

  /* Switch: '<S19>/Switch' */
  if (may23_B.scaling > may23_P.Switch_Threshold_e) {
    may23_B.Switch_k[0] = may23_B.Memory3[0];
    may23_B.Switch_k[1] = may23_B.Memory3[1];
    may23_B.Switch_k[2] = may23_B.Memory3[2];
    may23_B.Switch_k[3] = may23_B.Memory3[3];
  } else {
    may23_B.Switch_k[0] = may23_B.force_vector[0];
    may23_B.Switch_k[1] = may23_B.force_vector[1];
    may23_B.Switch_k[2] = may23_B.force_vector[2];
    may23_B.Switch_k[3] = may23_B.force_vector[3];
  }

  /* End of Switch: '<S19>/Switch' */

  /* Product: '<S19>/Product' */
  may23_B.Product_br[0] = may23_B.Taskwideparam[0] * may23_B.Switch_k[0] *
    may23_B.scaling;
  may23_B.Product_br[1] = may23_B.Taskwideparam[0] * may23_B.Switch_k[1] *
    may23_B.scaling;
  may23_B.Product_br[2] = may23_B.Taskwideparam[0] * may23_B.Switch_k[2] *
    may23_B.scaling;
  may23_B.Product_br[3] = may23_B.Taskwideparam[0] * may23_B.Switch_k[3] *
    may23_B.scaling;

  /* MATLAB Function: '<S2>/Forces_to_Torques' */
  /* MATLAB Function 'Forces_to_Torques/Forces_to_Torques': '<S333>:1' */
  /* '<S333>:1:13' */
  may23_B.joint_loads_i[0] = 0.0;
  may23_B.joint_loads_i[1] = 0.0;
  may23_B.joint_loads_i[2] = 0.0;
  may23_B.joint_loads_i[3] = 0.0;

  /* '<S333>:1:15' */
  /* '<S333>:1:16' */
  hold_steps = may23_B.Product_br[0];

  /* '<S333>:1:17' */
  x = may23_B.Product_br[1];

  /* '<S333>:1:18' */
  /* '<S333>:1:19' */
  /* '<S333>:1:20' */
  /* '<S333>:1:21' */
  /* '<S333>:1:22' */
  /* '<S333>:1:24' */
  out_of_spec_motors_idx_3 = may23_B.kinarm_data[18] + may23_B.kinarm_data[21];

  /* '<S333>:1:25' */
  L2ptr_ANG = (may23_B.kinarm_data[18] + may23_B.kinarm_data[21]) +
    1.5707963267948966;
  if (!(may23_B.kinarm_data[15] == 1.0)) {
    /* '<S333>:1:30' */
    hold_steps = -hold_steps;
  } else {
    /* '<S333>:1:26' */
  }

  /* '<S333>:1:33' */
  /* '<S333>:1:34' */
  out_of_spec_motors_idx_3 = (may23_B.kinarm_data[3] * sin
    (out_of_spec_motors_idx_3) + may23_B.kinarm_data[6] * sin(L2ptr_ANG)) *
    -hold_steps + (may23_B.kinarm_data[3] * cos(out_of_spec_motors_idx_3) +
                   may23_B.kinarm_data[6] * cos(L2ptr_ANG)) * x;

  /* '<S333>:1:35' */
  may23_B.joint_loads_i[0] = (-hold_steps * may23_B.kinarm_data[0] * sin
    (may23_B.kinarm_data[18]) + x * may23_B.kinarm_data[0] * cos
    (may23_B.kinarm_data[18])) + out_of_spec_motors_idx_3;

  /* '<S333>:1:36' */
  may23_B.joint_loads_i[1] = out_of_spec_motors_idx_3;

  /* '<S333>:1:15' */
  /* '<S333>:1:16' */
  hold_steps = may23_B.Product_br[2];

  /* '<S333>:1:17' */
  x = may23_B.Product_br[3];

  /* '<S333>:1:18' */
  /* '<S333>:1:19' */
  /* '<S333>:1:20' */
  /* '<S333>:1:21' */
  /* '<S333>:1:22' */
  /* '<S333>:1:24' */
  out_of_spec_motors_idx_3 = may23_B.kinarm_data[19] + may23_B.kinarm_data[22];

  /* '<S333>:1:25' */
  L2ptr_ANG = (may23_B.kinarm_data[19] + may23_B.kinarm_data[22]) +
    1.5707963267948966;
  if (!(may23_B.kinarm_data[16] == 1.0)) {
    /* '<S333>:1:30' */
    hold_steps = -hold_steps;
  } else {
    /* '<S333>:1:26' */
  }

  /* '<S333>:1:33' */
  /* '<S333>:1:34' */
  out_of_spec_motors_idx_3 = (may23_B.kinarm_data[4] * sin
    (out_of_spec_motors_idx_3) + may23_B.kinarm_data[7] * sin(L2ptr_ANG)) *
    -hold_steps + (may23_B.kinarm_data[4] * cos(out_of_spec_motors_idx_3) +
                   may23_B.kinarm_data[7] * cos(L2ptr_ANG)) * x;

  /* '<S333>:1:35' */
  may23_B.joint_loads_i[2] = (-hold_steps * may23_B.kinarm_data[1] * sin
    (may23_B.kinarm_data[19]) + x * may23_B.kinarm_data[1] * cos
    (may23_B.kinarm_data[19])) + out_of_spec_motors_idx_3;

  /* '<S333>:1:36' */
  may23_B.joint_loads_i[3] = out_of_spec_motors_idx_3;

  /* End of MATLAB Function: '<S2>/Forces_to_Torques' */

  /* Reshape: '<S5>/Reshape' */
  /* MATLAB Function 'KINARM_Exo_Apply_Loads/Remove_NaNs_and_Inf1': '<S367>:1' */
  /* '<S367>:1:5' */
  /* '<S367>:1:7' */
  may23_B.Reshape_p[0] = may23_B.joint_loads_i[0];

  /* MATLAB Function: '<S5>/Remove_NaNs_and_Inf1' */
  may23_B.out[0] = 0.0;

  /* '<S367>:1:7' */
  if ((!rtIsInf(may23_B.Reshape_p[0])) && (!rtIsNaN(may23_B.Reshape_p[0]))) {
    /* '<S367>:1:8' */
    /* '<S367>:1:9' */
    may23_B.out[0] = may23_B.Reshape_p[0];
  }

  /* Reshape: '<S5>/Reshape' */
  may23_B.Reshape_p[1] = may23_B.joint_loads_i[1];

  /* MATLAB Function: '<S5>/Remove_NaNs_and_Inf1' */
  may23_B.out[1] = 0.0;

  /* '<S367>:1:7' */
  if ((!rtIsInf(may23_B.Reshape_p[1])) && (!rtIsNaN(may23_B.Reshape_p[1]))) {
    /* '<S367>:1:8' */
    /* '<S367>:1:9' */
    may23_B.out[1] = may23_B.Reshape_p[1];
  }

  /* Reshape: '<S5>/Reshape' */
  may23_B.Reshape_p[2] = may23_B.joint_loads_i[2];

  /* MATLAB Function: '<S5>/Remove_NaNs_and_Inf1' */
  may23_B.out[2] = 0.0;

  /* '<S367>:1:7' */
  if ((!rtIsInf(may23_B.Reshape_p[2])) && (!rtIsNaN(may23_B.Reshape_p[2]))) {
    /* '<S367>:1:8' */
    /* '<S367>:1:9' */
    may23_B.out[2] = may23_B.Reshape_p[2];
  }

  /* Reshape: '<S5>/Reshape' */
  may23_B.Reshape_p[3] = may23_B.joint_loads_i[3];

  /* MATLAB Function: '<S5>/Remove_NaNs_and_Inf1' */
  may23_B.out[3] = 0.0;

  /* '<S367>:1:7' */
  if ((!rtIsInf(may23_B.Reshape_p[3])) && (!rtIsNaN(may23_B.Reshape_p[3]))) {
    /* '<S367>:1:8' */
    /* '<S367>:1:9' */
    may23_B.out[3] = may23_B.Reshape_p[3];
  }

  /* Switch: '<S5>/Switch' incorporates:
   *  Constant: '<S5>/Torque Limit'
   *  Constant: '<S5>/Torque Limit1'
   *  Constant: '<S5>/Torque Limit2'
   */
  if (may23_P.KINARM_Exo_Apply_Loads_limit_motors >= may23_P.Switch_Threshold_bf)
  {
    may23_B.Switch_h = may23_P.TorqueLimit2_Value;
  } else {
    may23_B.Switch_h = may23_P.KINARM_Exo_Apply_Loads_max_torque;
  }

  /* End of Switch: '<S5>/Switch' */

  /* MATLAB Function: '<S5>/Torque_Cap' */
  /* MATLAB Function 'KINARM_Exo_Apply_Loads/Torque_Cap': '<S368>:1' */
  if (may23_B.Switch_h == -1.0) {
    /* '<S368>:1:5' */
    /* '<S368>:1:6' */
    may23_B.y[0] = may23_B.out[0];
    may23_B.y[1] = may23_B.out[1];
    may23_B.y[2] = may23_B.out[2];
    may23_B.y[3] = may23_B.out[3];
  } else {
    /* '<S368>:1:11' */
    x = may23_B.out[0];
    hold_steps = may23_B.Switch_h;
    if ((x < hold_steps) || rtIsNaN(hold_steps)) {
      hold_steps = x;
    }

    x = -may23_B.Switch_h;
    if ((hold_steps > x) || rtIsNaN(x)) {
      x = hold_steps;
    }

    may23_B.y[0] = x;

    /* '<S368>:1:12' */
    x = may23_B.out[1];
    hold_steps = may23_B.Switch_h;
    if ((x < hold_steps) || rtIsNaN(hold_steps)) {
      hold_steps = x;
    }

    x = -may23_B.Switch_h;
    if ((hold_steps > x) || rtIsNaN(x)) {
      x = hold_steps;
    }

    may23_B.y[1] = x;

    /* '<S368>:1:13' */
    x = may23_B.out[2];
    hold_steps = may23_B.Switch_h;
    if ((x < hold_steps) || rtIsNaN(hold_steps)) {
      hold_steps = x;
    }

    x = -may23_B.Switch_h;
    if ((hold_steps > x) || rtIsNaN(x)) {
      x = hold_steps;
    }

    may23_B.y[2] = x;

    /* '<S368>:1:14' */
    x = may23_B.out[3];
    hold_steps = may23_B.Switch_h;
    if ((x < hold_steps) || rtIsNaN(hold_steps)) {
      hold_steps = x;
    }

    x = -may23_B.Switch_h;
    if ((hold_steps > x) || rtIsNaN(x)) {
      x = hold_steps;
    }

    may23_B.y[3] = x;
  }

  /* End of MATLAB Function: '<S5>/Torque_Cap' */

  /* Product: '<S5>/Product' */
  may23_B.Product_i[0] = may23_B.y[0] * may23_B.sf_Ramp_Up_Down_g.scaling;
  may23_B.Product_i[1] = may23_B.y[1] * may23_B.sf_Ramp_Up_Down_g.scaling;

  /* Product: '<S5>/Product1' */
  may23_B.Product1[0] = may23_B.y[2] * may23_B.sf_Ramp_Up_Down1_h.scaling;
  may23_B.Product1[1] = may23_B.y[3] * may23_B.sf_Ramp_Up_Down1_h.scaling;

  /* MATLAB Function: '<S5>/Remove_NaNs_and_Inf' */
  may23_Remove_NaNs_and_Inf(may23_B.Product_i, may23_B.Product1,
    &may23_B.sf_Remove_NaNs_and_Inf_d);

  /* Switch: '<S369>/Switch1' incorporates:
   *  Constant: '<S369>/Torque Limit3'
   *  Constant: '<S369>/Torque Limit4'
   *  Constant: '<S369>/Torque Limit5'
   */
  if (may23_P.KINARM_Exo_Apply_Loads_limit_motors >= may23_P.Switch1_Threshold_j)
  {
    may23_B.Switch1 = may23_P.KINARM_Exo_Apply_Loads_max_torque;
  } else {
    may23_B.Switch1 = may23_P.TorqueLimit5_Value;
  }

  /* End of Switch: '<S369>/Switch1' */

  /* SignalConversion generated from: '<S370>/ SFunction ' incorporates:
   *  MATLAB Function: '<S369>/clip_motor_torque'
   */
  may23_B.TmpSignalConversionAtSFunctionInport3_h[0] = may23_B.ArmOrientation_f;
  may23_B.TmpSignalConversionAtSFunctionInport3_h[1] = may23_B.ArmOrientation_m;

  /* MATLAB Function: '<S369>/clip_motor_torque' */
  /* MATLAB Function 'KINARM_Exo_Apply_Loads/clip motor torques/clip_motor_torque': '<S370>:1' */
  /* '<S370>:1:2' */
  may23_B.clipped_torques[0] = may23_B.sf_Remove_NaNs_and_Inf_d.out[0];
  may23_B.clipped_torques[1] = may23_B.sf_Remove_NaNs_and_Inf_d.out[1];
  may23_B.clipped_torques[2] = may23_B.sf_Remove_NaNs_and_Inf_d.out[2];
  may23_B.clipped_torques[3] = may23_B.sf_Remove_NaNs_and_Inf_d.out[3];
  if (may23_B.Switch1 >= 0.0) {
    /* '<S370>:1:4' */
    /* '<S370>:1:5' */
    /* '<S370>:1:13' */
    hold_steps = (may23_B.sf_Remove_NaNs_and_Inf_d.out[0] -
                  may23_B.sf_Remove_NaNs_and_Inf_d.out[1]) *
      may23_B.TmpSignalConversionAtSFunctionInport3_h[0];

    /* '<S370>:1:14' */
    x = may23_B.sf_Remove_NaNs_and_Inf_d.out[1] *
      may23_B.TmpSignalConversionAtSFunctionInport3_h[0];
    if (fabs(hold_steps) > may23_B.Switch1) {
      /* '<S370>:1:16' */
      /* '<S370>:1:17' */
      if (hold_steps < 0.0) {
        out_of_spec_motors_idx_2 = -1.0;
      } else if (hold_steps > 0.0) {
        out_of_spec_motors_idx_2 = 1.0;
      } else if (hold_steps == 0.0) {
        out_of_spec_motors_idx_2 = 0.0;
      } else {
        out_of_spec_motors_idx_2 = (rtNaN);
      }

      hold_steps = may23_B.Switch1 * out_of_spec_motors_idx_2;
    }

    if (fabs(x) > may23_B.Switch1) {
      /* '<S370>:1:20' */
      /* '<S370>:1:21' */
      if (x < 0.0) {
        out_of_spec_motors_idx_2 = -1.0;
      } else if (x > 0.0) {
        out_of_spec_motors_idx_2 = 1.0;
      } else if (x == 0.0) {
        out_of_spec_motors_idx_2 = 0.0;
      } else {
        out_of_spec_motors_idx_2 = (rtNaN);
      }

      x = may23_B.Switch1 * out_of_spec_motors_idx_2;
    }

    /* '<S370>:1:25' */
    new_torques_idx_1 = x / may23_B.TmpSignalConversionAtSFunctionInport3_h[0];

    /* '<S370>:1:26' */
    new_torques_idx_0 = hold_steps /
      may23_B.TmpSignalConversionAtSFunctionInport3_h[0] + new_torques_idx_1;
    may23_B.clipped_torques[0] = new_torques_idx_0;
    may23_B.clipped_torques[1] = new_torques_idx_1;

    /* '<S370>:1:6' */
    /* '<S370>:1:13' */
    hold_steps = (may23_B.sf_Remove_NaNs_and_Inf_d.out[2] -
                  may23_B.sf_Remove_NaNs_and_Inf_d.out[3]) *
      may23_B.TmpSignalConversionAtSFunctionInport3_h[1];

    /* '<S370>:1:14' */
    x = may23_B.sf_Remove_NaNs_and_Inf_d.out[3] *
      may23_B.TmpSignalConversionAtSFunctionInport3_h[1];
    if (fabs(hold_steps) > may23_B.Switch1) {
      /* '<S370>:1:16' */
      /* '<S370>:1:17' */
      if (hold_steps < 0.0) {
        out_of_spec_motors_idx_2 = -1.0;
      } else if (hold_steps > 0.0) {
        out_of_spec_motors_idx_2 = 1.0;
      } else if (hold_steps == 0.0) {
        out_of_spec_motors_idx_2 = 0.0;
      } else {
        out_of_spec_motors_idx_2 = (rtNaN);
      }

      hold_steps = may23_B.Switch1 * out_of_spec_motors_idx_2;
    }

    if (fabs(x) > may23_B.Switch1) {
      /* '<S370>:1:20' */
      /* '<S370>:1:21' */
      if (x < 0.0) {
        out_of_spec_motors_idx_2 = -1.0;
      } else if (x > 0.0) {
        out_of_spec_motors_idx_2 = 1.0;
      } else if (x == 0.0) {
        out_of_spec_motors_idx_2 = 0.0;
      } else {
        out_of_spec_motors_idx_2 = (rtNaN);
      }

      x = may23_B.Switch1 * out_of_spec_motors_idx_2;
    }

    /* '<S370>:1:25' */
    new_torques_idx_1 = x / may23_B.TmpSignalConversionAtSFunctionInport3_h[1];

    /* '<S370>:1:26' */
    new_torques_idx_0 = hold_steps /
      may23_B.TmpSignalConversionAtSFunctionInport3_h[1] + new_torques_idx_1;
    may23_B.clipped_torques[2] = new_torques_idx_0;
    may23_B.clipped_torques[3] = new_torques_idx_1;
  }

  /* Reshape: '<S4>/Reshape' */
  /* MATLAB Function 'KINARM_EP_Apply_Loads/Remove_NaNs_and_Inf1': '<S359>:1' */
  /* '<S359>:1:5' */
  /* '<S359>:1:7' */
  /* MATLAB Function 'KINARM_EP_Apply_Loads/Force_Cap': '<S354>:1' */
  /* '<S354>:1:10' */
  may23_B.Reshape_b[0] = may23_B.Product_br[0];

  /* MATLAB Function: '<S4>/Remove_NaNs_and_Inf1' */
  may23_B.out_p[0] = 0.0;

  /* '<S359>:1:7' */
  if ((!rtIsInf(may23_B.Reshape_b[0])) && (!rtIsNaN(may23_B.Reshape_b[0]))) {
    /* '<S359>:1:8' */
    /* '<S359>:1:9' */
    may23_B.out_p[0] = may23_B.Reshape_b[0];
  }

  /* MATLAB Function: '<S4>/Force_Cap' */
  may23_B.out_m[0] = may23_B.out_p[0];

  /* Reshape: '<S4>/Reshape' */
  may23_B.Reshape_b[1] = may23_B.Product_br[1];

  /* MATLAB Function: '<S4>/Remove_NaNs_and_Inf1' */
  may23_B.out_p[1] = 0.0;

  /* '<S359>:1:7' */
  if ((!rtIsInf(may23_B.Reshape_b[1])) && (!rtIsNaN(may23_B.Reshape_b[1]))) {
    /* '<S359>:1:8' */
    /* '<S359>:1:9' */
    may23_B.out_p[1] = may23_B.Reshape_b[1];
  }

  /* MATLAB Function: '<S4>/Force_Cap' */
  may23_B.out_m[1] = may23_B.out_p[1];

  /* Reshape: '<S4>/Reshape' */
  may23_B.Reshape_b[2] = may23_B.Product_br[2];

  /* MATLAB Function: '<S4>/Remove_NaNs_and_Inf1' */
  may23_B.out_p[2] = 0.0;

  /* '<S359>:1:7' */
  if ((!rtIsInf(may23_B.Reshape_b[2])) && (!rtIsNaN(may23_B.Reshape_b[2]))) {
    /* '<S359>:1:8' */
    /* '<S359>:1:9' */
    may23_B.out_p[2] = may23_B.Reshape_b[2];
  }

  /* MATLAB Function: '<S4>/Force_Cap' */
  may23_B.out_m[2] = may23_B.out_p[2];

  /* Reshape: '<S4>/Reshape' */
  may23_B.Reshape_b[3] = may23_B.Product_br[3];

  /* MATLAB Function: '<S4>/Remove_NaNs_and_Inf1' */
  may23_B.out_p[3] = 0.0;

  /* '<S359>:1:7' */
  if ((!rtIsInf(may23_B.Reshape_b[3])) && (!rtIsNaN(may23_B.Reshape_b[3]))) {
    /* '<S359>:1:8' */
    /* '<S359>:1:9' */
    may23_B.out_p[3] = may23_B.Reshape_b[3];
  }

  /* MATLAB Function: '<S4>/Force_Cap' incorporates:
   *  Constant: '<S4>/Force Limit'
   */
  may23_B.out_m[3] = may23_B.out_p[3];

  /* '<S354>:1:13' */
  x = sqrt(may23_B.out_p[0] * may23_B.out_p[0] + may23_B.out_p[1] *
           may23_B.out_p[1]);

  /* '<S354>:1:14' */
  hold_steps = sqrt(may23_B.out_p[2] * may23_B.out_p[2] + may23_B.out_p[3] *
                    may23_B.out_p[3]);
  if (x > may23_P.KINARM_EP_Apply_Loads_max_force) {
    /* '<S354>:1:18' */
    /* '<S354>:1:19' */
    x = may23_P.KINARM_EP_Apply_Loads_max_force / x;

    /* '<S354>:1:20' */
    may23_B.out_m[0] = may23_B.out_p[0] * x;
    may23_B.out_m[1] = may23_B.out_p[1] * x;
  }

  if (hold_steps > may23_P.KINARM_EP_Apply_Loads_max_force) {
    /* '<S354>:1:24' */
    /* '<S354>:1:25' */
    x = may23_P.KINARM_EP_Apply_Loads_max_force / hold_steps;

    /* '<S354>:1:26' */
    hold_steps = may23_B.out_m[2] * x;
    may23_B.out_m[2] = hold_steps;
    hold_steps = may23_B.out_m[3] * x;
    may23_B.out_m[3] = hold_steps;
  }

  /* BusCreator generated from: '<S4>/Forces_to_Torques' */
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.general.active_arm
    = may23_B.active_arm;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.general.servo_counter
    = may23_B.servoCounter;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.general.calibration_button_bits
    = may23_B.calibrationButtonBits;

  /* BusCreator generated from: '<S4>/Forces_to_Torques' */
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.hand_feedback.dex_feed_forward
    = may23_B.handFF_Dex;

  /* BusCreator generated from: '<S4>/Forces_to_Torques' */
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.link_lengths
    [0] = may23_B.sf_splitKINDataarm1.link_lengths[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.link_lengths
    [1] = may23_B.sf_splitKINDataarm1.link_lengths[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.pointer_offset
    = may23_B.sf_splitKINDataarm1.pointer_offset;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.shoulder_position
    [0] = may23_B.sf_splitKINDataarm1.shoulder_loc[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.shoulder_position
    [1] = may23_B.sf_splitKINDataarm1.shoulder_loc[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.arm_orientation
    = may23_B.sf_splitKINDataarm1.arm_orientation;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.shoulder_angle
    = may23_B.sf_splitKINDataarm1.shoulder_ang;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.elbow_angle
    = may23_B.sf_splitKINDataarm1.elbow_ang;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.shoulder_ang_velocity
    = may23_B.sf_splitKINDataarm1.shoulder_ang_velocity;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.elbow_ang_velocity
    = may23_B.sf_splitKINDataarm1.elbow_ang_velocity;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.shoulder_ang_acceleration
    = may23_B.sf_splitKINDataarm1.shoulder_ang_acceleration;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.elbow_ang_acceleration
    = may23_B.sf_splitKINDataarm1.elbow_ang_acceleration;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.joint_torque_command
    [0] = may23_B.sf_splitKINDataarm1.joint_torque_cmd[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.joint_torque_command
    [1] = may23_B.sf_splitKINDataarm1.joint_torque_cmd[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.motor_torque_command
    [0] = may23_B.sf_splitKINDataarm1.motor_torque_cmd[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.motor_torque_command
    [1] = may23_B.sf_splitKINDataarm1.motor_torque_cmd[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.link_angles
    [0] = may23_B.sf_splitKINDataarm1.link_angle[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.link_angles
    [1] = may23_B.sf_splitKINDataarm1.link_angle[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.link_angle_velocities
    [0] = may23_B.sf_splitKINDataarm1.link_velocity[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.link_angle_velocities
    [1] = may23_B.sf_splitKINDataarm1.link_velocity[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.link_angle_accelerations
    [0] = may23_B.sf_splitKINDataarm1.link_acceleration[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.link_angle_accelerations
    [1] = may23_B.sf_splitKINDataarm1.link_acceleration[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.hand_position
    [0] = may23_B.sf_splitKINDataarm1.hand_position[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.hand_position
    [1] = may23_B.sf_splitKINDataarm1.hand_position[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.hand_velocities
    [0] = may23_B.sf_splitKINDataarm1.hand_velocity[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.hand_velocities
    [1] = may23_B.sf_splitKINDataarm1.hand_velocity[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.hand_accelerations
    [0] = may23_B.sf_splitKINDataarm1.hand_acceleration[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.hand_accelerations
    [1] = may23_B.sf_splitKINDataarm1.hand_acceleration[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.elbow_position
    [0] = may23_B.sf_splitKINDataarm1.elbow_position[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.elbow_position
    [1] = may23_B.sf_splitKINDataarm1.elbow_position[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.elbow_cart_velocity
    [0] = may23_B.sf_splitKINDataarm1.elbow_velocity[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.elbow_cart_velocity
    [1] = may23_B.sf_splitKINDataarm1.elbow_velocity[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.elbow_cart_acceleration
    [0] = may23_B.sf_splitKINDataarm1.elbow_acceleration[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.elbow_cart_acceleration
    [1] = may23_B.sf_splitKINDataarm1.elbow_acceleration[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.motor_status
    = may23_B.sf_splitKINDataarm1.motor_status;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_force_uvw
    [0] = may23_B.sf_splitKINDataarm1.force_sensor_force_uvw[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_force_uvw
    [1] = may23_B.sf_splitKINDataarm1.force_sensor_force_uvw[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_force_uvw
    [2] = may23_B.sf_splitKINDataarm1.force_sensor_force_uvw[2];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_torque_uvw
    [0] = may23_B.sf_splitKINDataarm1.force_sensor_torque_uvw[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_torque_uvw
    [1] = may23_B.sf_splitKINDataarm1.force_sensor_torque_uvw[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_torque_uvw
    [2] = may23_B.sf_splitKINDataarm1.force_sensor_torque_uvw[2];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_force_xyz
    [0] = may23_B.sf_splitKINDataarm1.force_sensor_force_xyz[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_force_xyz
    [1] = may23_B.sf_splitKINDataarm1.force_sensor_force_xyz[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_force_xyz
    [2] = may23_B.sf_splitKINDataarm1.force_sensor_force_xyz[2];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_torque_xyz
    [0] = may23_B.sf_splitKINDataarm1.force_sensor_torque_xyz[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_torque_xyz
    [1] = may23_B.sf_splitKINDataarm1.force_sensor_torque_xyz[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_torque_xyz
    [2] = may23_B.sf_splitKINDataarm1.force_sensor_torque_xyz[2];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_timestamp
    = may23_B.sf_splitKINDataarm1.force_sensor_timestamp;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.fs_status
    = may23_B.status_out[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.ecat_recorded_torques
    [0] = may23_B.torquefeedback1[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.ecat_recorded_torques
    [1] = may23_B.torquefeedback1[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.ecat_current_limit_enabled
    [0] = may23_B.torquefeedback1[4];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.ecat_current_limit_enabled
    [1] = may23_B.torquefeedback1[5];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.ep_grip_sensor
    = may23_B.torquefeedback1[8];

  /* BusCreator generated from: '<S4>/Forces_to_Torques' */
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.pointer_offset
    = may23_B.sf_splitKINDataarm2.pointer_offset;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.arm_orientation
    = may23_B.sf_splitKINDataarm2.arm_orientation;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.shoulder_angle
    = may23_B.sf_splitKINDataarm2.shoulder_ang;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.elbow_angle
    = may23_B.sf_splitKINDataarm2.elbow_ang;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.shoulder_ang_velocity
    = may23_B.sf_splitKINDataarm2.shoulder_ang_velocity;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.elbow_ang_velocity
    = may23_B.sf_splitKINDataarm2.elbow_ang_velocity;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.shoulder_ang_acceleration
    = may23_B.sf_splitKINDataarm2.shoulder_ang_acceleration;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.elbow_ang_acceleration
    = may23_B.sf_splitKINDataarm2.elbow_ang_acceleration;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.link_lengths
    [0] = may23_B.sf_splitKINDataarm2.link_lengths[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.shoulder_position
    [0] = may23_B.sf_splitKINDataarm2.shoulder_loc[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.joint_torque_command
    [0] = may23_B.sf_splitKINDataarm2.joint_torque_cmd[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.motor_torque_command
    [0] = may23_B.sf_splitKINDataarm2.motor_torque_cmd[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.link_angles
    [0] = may23_B.sf_splitKINDataarm2.link_angle[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.link_angle_velocities
    [0] = may23_B.sf_splitKINDataarm2.link_velocity[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.link_angle_accelerations
    [0] = may23_B.sf_splitKINDataarm2.link_acceleration[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.hand_position
    [0] = may23_B.sf_splitKINDataarm2.hand_position[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.hand_velocities
    [0] = may23_B.sf_splitKINDataarm2.hand_velocity[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.hand_accelerations
    [0] = may23_B.sf_splitKINDataarm2.hand_acceleration[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.elbow_position
    [0] = may23_B.sf_splitKINDataarm2.elbow_position[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.elbow_cart_velocity
    [0] = may23_B.sf_splitKINDataarm2.elbow_velocity[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.elbow_cart_acceleration
    [0] = may23_B.sf_splitKINDataarm2.elbow_acceleration[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.link_lengths
    [1] = may23_B.sf_splitKINDataarm2.link_lengths[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.shoulder_position
    [1] = may23_B.sf_splitKINDataarm2.shoulder_loc[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.joint_torque_command
    [1] = may23_B.sf_splitKINDataarm2.joint_torque_cmd[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.motor_torque_command
    [1] = may23_B.sf_splitKINDataarm2.motor_torque_cmd[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.link_angles
    [1] = may23_B.sf_splitKINDataarm2.link_angle[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.link_angle_velocities
    [1] = may23_B.sf_splitKINDataarm2.link_velocity[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.link_angle_accelerations
    [1] = may23_B.sf_splitKINDataarm2.link_acceleration[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.hand_position
    [1] = may23_B.sf_splitKINDataarm2.hand_position[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.hand_velocities
    [1] = may23_B.sf_splitKINDataarm2.hand_velocity[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.hand_accelerations
    [1] = may23_B.sf_splitKINDataarm2.hand_acceleration[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.elbow_position
    [1] = may23_B.sf_splitKINDataarm2.elbow_position[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.elbow_cart_velocity
    [1] = may23_B.sf_splitKINDataarm2.elbow_velocity[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.elbow_cart_acceleration
    [1] = may23_B.sf_splitKINDataarm2.elbow_acceleration[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.motor_status
    = may23_B.sf_splitKINDataarm2.motor_status;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_force_uvw
    [0] = may23_B.sf_splitKINDataarm2.force_sensor_force_uvw[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_torque_uvw
    [0] = may23_B.sf_splitKINDataarm2.force_sensor_torque_uvw[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_force_xyz
    [0] = may23_B.sf_splitKINDataarm2.force_sensor_force_xyz[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_torque_xyz
    [0] = may23_B.sf_splitKINDataarm2.force_sensor_torque_xyz[0];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_force_uvw
    [1] = may23_B.sf_splitKINDataarm2.force_sensor_force_uvw[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_torque_uvw
    [1] = may23_B.sf_splitKINDataarm2.force_sensor_torque_uvw[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_force_xyz
    [1] = may23_B.sf_splitKINDataarm2.force_sensor_force_xyz[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_torque_xyz
    [1] = may23_B.sf_splitKINDataarm2.force_sensor_torque_xyz[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_force_uvw
    [2] = may23_B.sf_splitKINDataarm2.force_sensor_force_uvw[2];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_torque_uvw
    [2] = may23_B.sf_splitKINDataarm2.force_sensor_torque_uvw[2];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_force_xyz
    [2] = may23_B.sf_splitKINDataarm2.force_sensor_force_xyz[2];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_torque_xyz
    [2] = may23_B.sf_splitKINDataarm2.force_sensor_torque_xyz[2];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_timestamp
    = may23_B.sf_splitKINDataarm2.force_sensor_timestamp;
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.fs_status
    = may23_B.status_out[1];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.ecat_recorded_torques
    [0] = may23_B.torquefeedback1[2];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.ecat_recorded_torques
    [1] = may23_B.torquefeedback1[3];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.ecat_current_limit_enabled
    [0] = may23_B.torquefeedback1[6];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.ecat_current_limit_enabled
    [1] = may23_B.torquefeedback1[7];
  may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.ep_grip_sensor
    = may23_B.torquefeedback1[9];

  /* MATLAB Function: '<S4>/Forces_to_Torques' */
  /* MATLAB Function 'KINARM_EP_Apply_Loads/Forces_to_Torques': '<S355>:1' */
  /* '<S355>:1:5' */
  may23_B.joint_loads[0] = 0.0;
  may23_B.joint_loads[1] = 0.0;
  may23_B.joint_loads[2] = 0.0;
  may23_B.joint_loads[3] = 0.0;

  /* '<S355>:1:9' */
  /* '<S355>:1:7' */
  new_torques_idx_0 =
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.link_lengths
    [0];
  new_torques_idx_1 =
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.link_lengths
    [1];
  robot_pointer_offset =
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.pointer_offset;
  robot_arm_orientation =
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.arm_orientation;
  out_of_spec_motors_idx_2 =
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.shoulder_angle;
  L2ptr_ANG =
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot1.elbow_angle;

  /* '<S355>:1:14' */
  hold_steps = may23_B.out_m[0];

  /* '<S355>:1:15' */
  x = may23_B.out_m[1];

  /* '<S355>:1:16' */
  /* '<S355>:1:17' */
  /* '<S355>:1:18' */
  /* '<S355>:1:19' */
  /* '<S355>:1:20' */
  /* '<S355>:1:22' */
  out_of_spec_motors_idx_3 = out_of_spec_motors_idx_2 + L2ptr_ANG;

  /* '<S355>:1:23' */
  L2ptr_ANG = (out_of_spec_motors_idx_2 + L2ptr_ANG) + 1.5707963267948966;
  if (robot_arm_orientation == 1.0) {
    /* '<S355>:1:24' */
    /* '<S355>:1:26' */
    hold_steps = -hold_steps;
  }

  /* '<S355>:1:31' */
  /* '<S355>:1:32' */
  out_of_spec_motors_idx_3 = (new_torques_idx_1 * sin(out_of_spec_motors_idx_3)
    + robot_pointer_offset * sin(L2ptr_ANG)) * -hold_steps + (new_torques_idx_1 *
    cos(out_of_spec_motors_idx_3) + robot_pointer_offset * cos(L2ptr_ANG)) * x;

  /* '<S355>:1:33' */
  may23_B.joint_loads[0] = (-hold_steps * new_torques_idx_0 * sin
    (out_of_spec_motors_idx_2) + x * new_torques_idx_0 * cos
    (out_of_spec_motors_idx_2)) + out_of_spec_motors_idx_3;

  /* '<S355>:1:34' */
  may23_B.joint_loads[1] = out_of_spec_motors_idx_3;

  /* '<S355>:1:7' */
  /* '<S355>:1:9' */
  /* '<S355>:1:10' */
  /* '<S355>:1:11' */
  new_torques_idx_0 =
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.link_lengths
    [0];
  new_torques_idx_1 =
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.link_lengths
    [1];
  robot_pointer_offset =
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.pointer_offset;
  robot_arm_orientation =
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.arm_orientation;
  out_of_spec_motors_idx_2 =
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.shoulder_angle;
  L2ptr_ANG =
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.robot2.elbow_angle;

  /* '<S355>:1:14' */
  hold_steps = may23_B.out_m[2];

  /* '<S355>:1:15' */
  x = may23_B.out_m[3];

  /* '<S355>:1:16' */
  /* '<S355>:1:17' */
  /* '<S355>:1:18' */
  /* '<S355>:1:19' */
  /* '<S355>:1:20' */
  /* '<S355>:1:22' */
  out_of_spec_motors_idx_3 = out_of_spec_motors_idx_2 + L2ptr_ANG;

  /* '<S355>:1:23' */
  L2ptr_ANG = (out_of_spec_motors_idx_2 + L2ptr_ANG) + 1.5707963267948966;
  if (robot_arm_orientation == 1.0) {
    /* '<S355>:1:24' */
    /* '<S355>:1:26' */
    hold_steps = -hold_steps;
  }

  /* '<S355>:1:31' */
  /* '<S355>:1:32' */
  out_of_spec_motors_idx_3 = (new_torques_idx_1 * sin(out_of_spec_motors_idx_3)
    + robot_pointer_offset * sin(L2ptr_ANG)) * -hold_steps + (new_torques_idx_1 *
    cos(out_of_spec_motors_idx_3) + robot_pointer_offset * cos(L2ptr_ANG)) * x;

  /* '<S355>:1:33' */
  may23_B.joint_loads[2] = (-hold_steps * new_torques_idx_0 * sin
    (out_of_spec_motors_idx_2) + x * new_torques_idx_0 * cos
    (out_of_spec_motors_idx_2)) + out_of_spec_motors_idx_3;

  /* '<S355>:1:34' */
  may23_B.joint_loads[3] = out_of_spec_motors_idx_3;

  /* End of MATLAB Function: '<S4>/Forces_to_Torques' */

  /* Product: '<S4>/Product' */
  may23_B.Product_c[0] = may23_B.joint_loads[0] *
    may23_B.sf_Ramp_Up_Down.scaling;
  may23_B.Product_c[1] = may23_B.joint_loads[1] *
    may23_B.sf_Ramp_Up_Down.scaling;

  /* Product: '<S4>/Product1' */
  may23_B.Product1_j[0] = may23_B.joint_loads[2] *
    may23_B.sf_Ramp_Up_Down1.scaling;
  may23_B.Product1_j[1] = may23_B.joint_loads[3] *
    may23_B.sf_Ramp_Up_Down1.scaling;

  /* MATLAB Function: '<S4>/Remove_NaNs_and_Inf' */
  may23_Remove_NaNs_and_Inf(may23_B.Product_c, may23_B.Product1_j,
    &may23_B.sf_Remove_NaNs_and_Inf);

  /* Sum: '<S1>/AddTorques' */
  may23_B.AddTorques[0] = may23_B.clipped_torques[0] +
    may23_B.sf_Remove_NaNs_and_Inf.out[0];
  may23_B.AddTorques[1] = may23_B.clipped_torques[1] +
    may23_B.sf_Remove_NaNs_and_Inf.out[1];
  may23_B.AddTorques[2] = may23_B.clipped_torques[2] +
    may23_B.sf_Remove_NaNs_and_Inf.out[2];
  may23_B.AddTorques[3] = may23_B.clipped_torques[3] +
    may23_B.sf_Remove_NaNs_and_Inf.out[3];

  /* Memory: '<S38>/Memory1' */
  may23_B.Memory1 = may23_DW.Memory1_PreviousInput;

  /* Product: '<S1>/Product' */
  may23_B.Product_g[0] = may23_B.AddTorques[0] * may23_B.Memory1;
  may23_B.Product_g[1] = may23_B.AddTorques[1] * may23_B.Memory1;
  may23_B.Product_g[2] = may23_B.AddTorques[2] * may23_B.Memory1;
  may23_B.Product_g[3] = may23_B.AddTorques[3] * may23_B.Memory1;

  /* Memory: '<S1>/Memory1' */
  may23_B.Memory1_l = may23_DW.Memory1_PreviousInput_l;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.ArmOrientation = may23_DW.Memory2_1_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.M1orientation = may23_DW.Memory2_2_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.M2Orientation = may23_DW.Memory2_3_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.M1GearRatio = may23_DW.Memory2_4_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.M2GearRatio = may23_DW.Memory2_5_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.torqueconstant = may23_DW.Memory2_9_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.ArmOrientation_a = may23_DW.Memory2_18_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.M1orientation_i = may23_DW.Memory2_19_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.M2Orientation_a = may23_DW.Memory2_20_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.M1GearRatio_e = may23_DW.Memory2_21_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.M2GearRatio_n = may23_DW.Memory2_22_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.torqueconstant_b = may23_DW.Memory2_26_PreviousInput;

  /* Outputs for Atomic SubSystem: '<S1>/apply loads' */
  may23_applyloads();

  /* End of Outputs for SubSystem: '<S1>/apply loads' */

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isEP = may23_DW.Memory2_10_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isHumanExo = may23_DW.Memory2_11_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isNHPExo = may23_DW.Memory2_12_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isClassicExo = may23_DW.Memory2_13_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isUTSExo = may23_DW.Memory2_14_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isPMAC = may23_DW.Memory2_15_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isECAT = may23_DW.Memory2_16_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.robotRevision = may23_DW.Memory2_17_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.HasSecondaryEnc = may23_DW.Memory2_23_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.robottype = may23_DW.Memory2_24_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.robotversion = may23_DW.Memory2_25_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isEP_f = may23_DW.Memory2_27_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isHumanExo_k = may23_DW.Memory2_28_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isNHPExo_l = may23_DW.Memory2_29_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isClassicExo_j = may23_DW.Memory2_30_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isUTSExo_n = may23_DW.Memory2_31_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isPMAC_p = may23_DW.Memory2_32_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.isECAT_o = may23_DW.Memory2_33_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.robotRevision_p = may23_DW.Memory2_34_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.HasSecondaryEnc_h = may23_DW.Memory2_6_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.robottype_c = may23_DW.Memory2_7_PreviousInput;

  /* Memory generated from: '<S1>/Memory2' */
  may23_B.robotversion_a = may23_DW.Memory2_8_PreviousInput;

  /* DataStoreRead: '<S38>/Data Store Read1' */
  memcpy(&may23_B.DataStoreRead1[0], &may23_DW.DataReadyStatus[0], 10U * sizeof
         (real_T));

  /* SignalConversion generated from: '<S331>/ SFunction ' incorporates:
   *  MATLAB Function: '<S327>/filter'
   */
  may23_B.TmpSignalConversionAtSFunctionInport1_f[0] =
    may23_B.sf_splitKINDataarm1.motor_torque_cmd[0];
  may23_B.TmpSignalConversionAtSFunctionInport1_f[1] =
    may23_B.sf_splitKINDataarm1.motor_torque_cmd[1];
  may23_B.TmpSignalConversionAtSFunctionInport1_f[2] =
    may23_B.sf_splitKINDataarm2.motor_torque_cmd[0];
  may23_B.TmpSignalConversionAtSFunctionInport1_f[3] =
    may23_B.sf_splitKINDataarm2.motor_torque_cmd[1];

  /* MATLAB Function: '<S327>/filter' incorporates:
   *  Constant: '<S327>/butterworth_2nd_order_250hz'
   */
  /* MATLAB Function 'DataLogging/monitor torques/delay/filter': '<S331>:1' */
  /* '<S331>:1:20' */
  /* '<S331>:1:1' */
  /* '<S331>:1:18' */
  for (inputEventFiredFlag = 0; inputEventFiredFlag < 4; inputEventFiredFlag++)
  {
    /* '<S331>:1:18' */
    /* '<S331>:1:19' */
    /* '<S331>:1:20' */
    /* '<S331>:1:41' */
    hold_steps = may23_DW.rawVelocities_a[inputEventFiredFlag + 4];

    /* '<S331>:1:42' */
    x = may23_DW.rawVelocities_a[inputEventFiredFlag + 8];

    /* '<S331>:1:43' */
    out_of_spec_motors_idx_2 =
      may23_B.TmpSignalConversionAtSFunctionInport1_f[inputEventFiredFlag] /
      may23_P.butterworth_2nd_order_250hz_Value[0];

    /* '<S331>:1:21' */
    /* '<S331>:1:41' */
    out_of_spec_motors_idx_3 = may23_DW.filtVelocities_l[inputEventFiredFlag + 4];

    /* '<S331>:1:42' */
    L2ptr_ANG = may23_DW.filtVelocities_l[inputEventFiredFlag + 8];

    /* '<S331>:1:43' */
    may23_DW.rawVelocities_a[inputEventFiredFlag] = hold_steps;
    may23_DW.filtVelocities_l[inputEventFiredFlag] = out_of_spec_motors_idx_3;
    may23_DW.rawVelocities_a[inputEventFiredFlag + 4] = x;
    may23_DW.filtVelocities_l[inputEventFiredFlag + 4] = L2ptr_ANG;
    may23_DW.rawVelocities_a[inputEventFiredFlag + 8] = out_of_spec_motors_idx_2;
    may23_DW.filtVelocities_l[inputEventFiredFlag + 8] = 0.0;

    /* '<S331>:1:22' */
    /* '<S331>:1:29' */
    hold_steps = (((may23_DW.rawVelocities_a[inputEventFiredFlag + 4] * 2.0 +
                    may23_DW.rawVelocities_a[inputEventFiredFlag]) +
                   may23_DW.rawVelocities_a[inputEventFiredFlag + 8]) +
                  may23_DW.filtVelocities_l[inputEventFiredFlag] *
                  may23_P.butterworth_2nd_order_250hz_Value[1]) +
      may23_DW.filtVelocities_l[inputEventFiredFlag + 4] *
      may23_P.butterworth_2nd_order_250hz_Value[2];
    if (rtIsNaN(hold_steps) || rtIsInf(hold_steps)) {
      /* '<S331>:1:35' */
      /* '<S331>:1:36' */
      hold_steps = 0.0;
    }

    may23_DW.filtVelocities_l[inputEventFiredFlag + 8] = hold_steps;

    /* '<S331>:1:23' */
    may23_B.filteredVals_n[inputEventFiredFlag] =
      may23_DW.filtVelocities_l[inputEventFiredFlag + 8];
  }

  /* Memory: '<S329>/Memory1' */
  may23_B.Memory1_e[0] = may23_DW.Memory1_PreviousInput_k[0];
  may23_B.Memory1_e[1] = may23_DW.Memory1_PreviousInput_k[1];
  may23_B.Memory1_e[2] = may23_DW.Memory1_PreviousInput_k[2];
  may23_B.Memory1_e[3] = may23_DW.Memory1_PreviousInput_k[3];

  /* Constant: '<S329>/encoder_err_threshold' */
  may23_B.encoder_err_threshold = may23_P.encoder_err_threshold_Value;

  /* Chart: '<S329>/monitor_encoders' */
  /* Gateway: DataLogging/monitor torques/monitor_enc_delta/monitor_encoders */
  may23_DW.sfEvent_n = -1;

  /* During: DataLogging/monitor torques/monitor_enc_delta/monitor_encoders */
  if (may23_DW.is_active_c79_General == 0U) {
    /* Entry: DataLogging/monitor torques/monitor_enc_delta/monitor_encoders */
    may23_DW.is_active_c79_General = 1U;

    /* Entry Internal: DataLogging/monitor torques/monitor_enc_delta/monitor_encoders */
    /* Transition: '<S332>:8' */
    if (may23_B.isECAT_b == 0.0) {
      /* Transition: '<S332>:122' */
      may23_DW.is_c79_General = may23_IN_init;

      /* Entry 'init': '<S332>:7' */
    } else {
      /* Transition: '<S332>:125' */
      may23_DW.is_c79_General = may23_IN_startup;

      /* Entry 'startup': '<S332>:124' */
    }
  } else {
    switch (may23_DW.is_c79_General) {
     case may23_IN_ECAT:
      /* During 'ECAT': '<S332>:100' */
      may23_B.torque_multiplier_out = 0.0;
      may23_B.stop_vel_mode_out = 1.0;
      break;

     case may23_IN_PMAC_Sytem:
      /* During 'PMAC_Sytem': '<S332>:11' */
      may23_B.torque_multiplier_out = 0.0;
      break;

     case may23_IN_init:
      /* During 'init': '<S332>:7' */
      hold_steps = fabs(may23_B.Memory1_e[0]);
      zcEvent_idx_0 = (hold_steps > may23_B.encoder_err_threshold);
      hold_steps = fabs(may23_B.Memory1_e[1]);
      zcEvent_idx_1 = (hold_steps > may23_B.encoder_err_threshold);
      hold_steps = fabs(may23_B.Memory1_e[2]);
      zcEvent_idx_2 = (hold_steps > may23_B.encoder_err_threshold);
      hold_steps = fabs(may23_B.Memory1_e[3]);
      zcEvent_idx_3 = (hold_steps > may23_B.encoder_err_threshold);
      inputEventFiredFlag = zcEvent_idx_0;
      inputEventFiredFlag += zcEvent_idx_1;
      inputEventFiredFlag += zcEvent_idx_2;
      inputEventFiredFlag += zcEvent_idx_3;
      if (inputEventFiredFlag > 0) {
        /* Transition: '<S332>:9' */
        may23_DW.is_c79_General = may23_IN_PMAC_Sytem;

        /* Entry 'PMAC_Sytem': '<S332>:11' */
      } else {
        may23_B.torque_multiplier_out = may23_B.command_multiplier;
        may23_B.stop_vel_mode_out = may23_B.stop_vel_mode;
      }
      break;

     default:
      /* During 'startup': '<S332>:124' */
      hold_steps = fabs(may23_B.Memory1_e[0]);
      zcEvent_idx_0 = (hold_steps > may23_B.encoder_err_threshold);
      hold_steps = fabs(may23_B.Memory1_e[1]);
      zcEvent_idx_1 = (hold_steps > may23_B.encoder_err_threshold);
      hold_steps = fabs(may23_B.Memory1_e[2]);
      zcEvent_idx_2 = (hold_steps > may23_B.encoder_err_threshold);
      hold_steps = fabs(may23_B.Memory1_e[3]);
      zcEvent_idx_3 = (hold_steps > may23_B.encoder_err_threshold);
      inputEventFiredFlag = zcEvent_idx_0;
      inputEventFiredFlag += zcEvent_idx_1;
      inputEventFiredFlag += zcEvent_idx_2;
      inputEventFiredFlag += zcEvent_idx_3;
      if (inputEventFiredFlag > 0) {
        /* Transition: '<S332>:101' */
        may23_DW.is_c79_General = may23_IN_ECAT;

        /* Entry 'ECAT': '<S332>:100' */
      } else {
        may23_B.torque_multiplier_out = may23_B.command_multiplier;
        may23_B.stop_vel_mode_out = may23_B.stop_vel_mode;
      }
      break;
    }
  }

  /* End of Chart: '<S329>/monitor_encoders' */

  /* DataStoreRead: '<S34>/Data Store Read1' */
  memcpy(&may23_B.DataStoreRead1_l[0], &may23_DW.DataReadyStatus[0], 10U *
         sizeof(real_T));

  /* DataStoreRead: '<S1>/read status' */
  memcpy(&may23_B.readstatus[0], &may23_DW.ECATStatus[0], sizeof(real_T) << 3U);

  /* MATLAB Function: '<S321>/MATLAB Function' */
  may23_MATLABFunction_a(may23_B.ArmOrientation_f, may23_B.HasSecondaryEnc_n,
    may23_B.isEP_a, &may23_B.sf_MATLABFunction_a);

  /* MATLAB Function: '<S321>/MATLAB Function1' */
  may23_MATLABFunction_a(may23_B.ArmOrientation_m, may23_B.HasSecondaryEnc_c,
    may23_B.isEP_e, &may23_B.sf_MATLABFunction1);

  /* Constant: '<S35>/arm_count' */
  may23_B.robot_count = may23_P.arm_count_Value;

  /* Constant: '<S35>/fp1_present' */
  may23_B.has_force_plate_1 = may23_P.fp1_present_Value;

  /* Constant: '<S35>/fp2_present' */
  may23_B.has_force_plate_2 = may23_P.fp2_present_Value;

  /* Constant: '<S35>/gaze_tracker_present' */
  may23_B.has_gaze_tracker = may23_P.gaze_tracker_present_Value;

  /* Constant: '<S35>/robot_lift_present' */
  may23_B.has_robot_lift = may23_P.robot_lift_present_Value;

  /* MATLAB Function: '<S381>/MATLAB Function' incorporates:
   *  Constant: '<S9>/Constant'
   */
  hold_steps = may23_P.Process_Video_CMD_video_delay;

  /* MATLAB Function 'Process_Video_CMD/Add_requested_Delay/MATLAB Function': '<S384>:1' */
  /* '<S384>:1:4' */
  x = may23_B.handFF_Dex * 1000.0;
  if (may23_P.Process_Video_CMD_video_delay < x) {
    /* '<S384>:1:6' */
    /* '<S384>:1:7' */
    hold_steps = x;
  }

  /* '<S384>:1:10' */
  may23_B.delay = hold_steps - x;
  if (may23_B.delay < 0.0) {
    /* '<S384>:1:12' */
    /* '<S384>:1:13' */
    may23_B.delay = 0.0;
  } else {
    if (may23_B.delay > 50.0) {
      /* '<S384>:1:14' */
      /* '<S384>:1:15' */
      may23_B.delay = 50.0;
    }
  }

  /* End of MATLAB Function: '<S381>/MATLAB Function' */

  /* RateTransition: '<S381>/Rate Transition1' */
  if (may23_M->Timing.RateInteraction.TID1_3) {
    may23_DW.RateTransition1_Buffer_k = may23_B.delay;
  }

  /* End of RateTransition: '<S381>/Rate Transition1' */

  /* Selector: '<S16>/Selector' */
  i = (int32_T)may23_B.preshot_area_row;
  for (inputEventFiredFlag = 0; inputEventFiredFlag < 25; inputEventFiredFlag++)
  {
    may23_B.Selector_f[inputEventFiredFlag] = may23_B.TargetTable
      [((inputEventFiredFlag << 6) + i) - 1];
  }

  /* End of Selector: '<S16>/Selector' */

  /* Concatenate: '<S16>/Matrix Concatenation' incorporates:
   *  Constant: '<S16>/state1_indices'
   *  Constant: '<S16>/state2_indices'
   *  Constant: '<S16>/state3_indices'
   *  Constant: '<S16>/state4_indices'
   *  Constant: '<S16>/state5_indices'
   */
  may23_B.MatrixConcatenation1_e[0] = may23_P.Show_Preshot_Area_attribcol1[0];
  may23_B.MatrixConcatenation1_e[5] = may23_P.Show_Preshot_Area_attribcol1[1];
  may23_B.MatrixConcatenation1_e[10] = may23_P.Show_Preshot_Area_attribcol1[2];
  may23_B.MatrixConcatenation1_e[15] = may23_P.Show_Preshot_Area_attribcol1[3];
  may23_B.MatrixConcatenation1_e[1] = may23_P.Show_Preshot_Area_attribcol2[0];
  may23_B.MatrixConcatenation1_e[6] = may23_P.Show_Preshot_Area_attribcol2[1];
  may23_B.MatrixConcatenation1_e[11] = may23_P.Show_Preshot_Area_attribcol2[2];
  may23_B.MatrixConcatenation1_e[16] = may23_P.Show_Preshot_Area_attribcol2[3];
  may23_B.MatrixConcatenation1_e[2] = may23_P.Show_Preshot_Area_attribcol3[0];
  may23_B.MatrixConcatenation1_e[7] = may23_P.Show_Preshot_Area_attribcol3[1];
  may23_B.MatrixConcatenation1_e[12] = may23_P.Show_Preshot_Area_attribcol3[2];
  may23_B.MatrixConcatenation1_e[17] = may23_P.Show_Preshot_Area_attribcol3[3];
  may23_B.MatrixConcatenation1_e[3] = may23_P.state4_indices_Value_k[0];
  may23_B.MatrixConcatenation1_e[8] = may23_P.state4_indices_Value_k[1];
  may23_B.MatrixConcatenation1_e[13] = may23_P.state4_indices_Value_k[2];
  may23_B.MatrixConcatenation1_e[18] = may23_P.state4_indices_Value_k[3];
  may23_B.MatrixConcatenation1_e[4] = may23_P.state5_indices_Value_jv[0];
  may23_B.MatrixConcatenation1_e[9] = may23_P.state5_indices_Value_jv[1];
  may23_B.MatrixConcatenation1_e[14] = may23_P.state5_indices_Value_jv[2];
  may23_B.MatrixConcatenation1_e[19] = may23_P.state5_indices_Value_jv[3];

  /* Constant: '<S16>/padder' */
  memcpy(&may23_B.MatrixConcatenation1_e[20], &may23_P.padder_Value_b[0], 35U *
         sizeof(real_T));

  /* MATLAB Function: '<S16>/Embedded MATLAB Function' incorporates:
   *  Constant: '<S16>/Opacity'
   *  Constant: '<S16>/Target_Display'
   *  Constant: '<S16>/Target_Type'
   *  Constant: '<S16>/num_states'
   *  Constant: '<S16>/xpos_index'
   *  Constant: '<S16>/ypos_index'
   */
  may23_EmbeddedMATLABFunction(may23_B.Selector_f, may23_B.preshot_area_state,
    may23_P.Show_Preshot_Area_target_type, may23_P.Show_Preshot_Area_opacity,
    may23_P.Show_Preshot_Area_target_display, may23_P.xpos_index_Value_g,
    may23_P.ypos_index_Value_e, may23_P.Show_Preshot_Area_num_states,
    may23_B.MatrixConcatenation1_e, &may23_B.sf_EmbeddedMATLABFunction_e);

  /* Selector: '<S13>/Selector' */
  i = (int32_T)may23_B.barrier_target_row;
  for (inputEventFiredFlag = 0; inputEventFiredFlag < 25; inputEventFiredFlag++)
  {
    may23_B.Selector_i[inputEventFiredFlag] = may23_B.TargetTable
      [((inputEventFiredFlag << 6) + i) - 1];
  }

  /* End of Selector: '<S13>/Selector' */

  /* Concatenate: '<S13>/Matrix Concatenation' incorporates:
   *  Constant: '<S13>/state1_indices'
   *  Constant: '<S13>/state2_indices'
   *  Constant: '<S13>/state3_indices'
   *  Constant: '<S13>/state4_indices'
   *  Constant: '<S13>/state5_indices'
   */
  for (i = 0; i < 6; i++) {
    may23_B.MatrixConcatenation1_k[5 * i] = may23_P.Show_Barrier_attribcol1[i];
  }

  for (i = 0; i < 6; i++) {
    may23_B.MatrixConcatenation1_k[5 * i + 1] =
      may23_P.Show_Barrier_attribcol2[i];
  }

  for (i = 0; i < 6; i++) {
    may23_B.MatrixConcatenation1_k[5 * i + 2] =
      may23_P.Show_Barrier_attribcol3[i];
  }

  for (i = 0; i < 6; i++) {
    may23_B.MatrixConcatenation1_k[5 * i + 3] = may23_P.state4_indices_Value_d[i];
  }

  for (i = 0; i < 6; i++) {
    may23_B.MatrixConcatenation1_k[5 * i + 4] = may23_P.state5_indices_Value_p[i];
  }

  /* End of Concatenate: '<S13>/Matrix Concatenation' */

  /* Constant: '<S13>/padder' */
  memcpy(&may23_B.MatrixConcatenation1_k[30], &may23_P.padder_Value_bi[0], 25U *
         sizeof(real_T));

  /* MATLAB Function: '<S13>/Embedded MATLAB Function' incorporates:
   *  Constant: '<S13>/Opacity'
   *  Constant: '<S13>/Target_Display'
   *  Constant: '<S13>/Target_Type'
   *  Constant: '<S13>/num_states'
   *  Constant: '<S13>/xpos_index'
   *  Constant: '<S13>/ypos_index'
   */
  may23_EmbeddedMATLABFunction(may23_B.Selector_i, may23_B.barrier_target_state,
    may23_P.Show_Barrier_target_type, may23_P.Show_Barrier_opacity,
    may23_P.Show_Barrier_target_display, may23_P.xpos_index_Value_e,
    may23_P.ypos_index_Value_c, may23_P.Show_Barrier_num_states,
    may23_B.MatrixConcatenation1_k, &may23_B.sf_EmbeddedMATLABFunction_p);

  /* Selector: '<S18>/Selector' */
  i = (int32_T)may23_B.start_target_row;
  for (inputEventFiredFlag = 0; inputEventFiredFlag < 25; inputEventFiredFlag++)
  {
    may23_B.Selector_d[inputEventFiredFlag] = may23_B.TargetTable
      [((inputEventFiredFlag << 6) + i) - 1];
  }

  /* End of Selector: '<S18>/Selector' */

  /* Concatenate: '<S18>/Matrix Concatenation' incorporates:
   *  Constant: '<S18>/state1_indices'
   *  Constant: '<S18>/state2_indices'
   *  Constant: '<S18>/state3_indices'
   *  Constant: '<S18>/state4_indices'
   *  Constant: '<S18>/state5_indices'
   */
  may23_B.MatrixConcatenation1_b[0] = may23_P.Show_Start_attribcol1[0];
  may23_B.MatrixConcatenation1_b[5] = may23_P.Show_Start_attribcol1[1];
  may23_B.MatrixConcatenation1_b[10] = may23_P.Show_Start_attribcol1[2];
  may23_B.MatrixConcatenation1_b[15] = may23_P.Show_Start_attribcol1[3];
  may23_B.MatrixConcatenation1_b[1] = may23_P.Show_Start_attribcol2[0];
  may23_B.MatrixConcatenation1_b[6] = may23_P.Show_Start_attribcol2[1];
  may23_B.MatrixConcatenation1_b[11] = may23_P.Show_Start_attribcol2[2];
  may23_B.MatrixConcatenation1_b[16] = may23_P.Show_Start_attribcol2[3];
  may23_B.MatrixConcatenation1_b[2] = may23_P.Show_Start_attribcol3[0];
  may23_B.MatrixConcatenation1_b[7] = may23_P.Show_Start_attribcol3[1];
  may23_B.MatrixConcatenation1_b[12] = may23_P.Show_Start_attribcol3[2];
  may23_B.MatrixConcatenation1_b[17] = may23_P.Show_Start_attribcol3[3];
  may23_B.MatrixConcatenation1_b[3] = may23_P.state4_indices_Value_l[0];
  may23_B.MatrixConcatenation1_b[8] = may23_P.state4_indices_Value_l[1];
  may23_B.MatrixConcatenation1_b[13] = may23_P.state4_indices_Value_l[2];
  may23_B.MatrixConcatenation1_b[18] = may23_P.state4_indices_Value_l[3];
  may23_B.MatrixConcatenation1_b[4] = may23_P.state5_indices_Value_d[0];
  may23_B.MatrixConcatenation1_b[9] = may23_P.state5_indices_Value_d[1];
  may23_B.MatrixConcatenation1_b[14] = may23_P.state5_indices_Value_d[2];
  may23_B.MatrixConcatenation1_b[19] = may23_P.state5_indices_Value_d[3];

  /* Constant: '<S18>/padder' */
  memcpy(&may23_B.MatrixConcatenation1_b[20], &may23_P.padder_Value_p[0], 35U *
         sizeof(real_T));

  /* MATLAB Function: '<S18>/Embedded MATLAB Function' incorporates:
   *  Constant: '<S18>/Opacity'
   *  Constant: '<S18>/Target_Display'
   *  Constant: '<S18>/Target_Type'
   *  Constant: '<S18>/num_states'
   *  Constant: '<S18>/xpos_index'
   *  Constant: '<S18>/ypos_index'
   */
  may23_EmbeddedMATLABFunction(may23_B.Selector_d, may23_B.start_target_state,
    may23_P.Show_Start_target_type, may23_P.Show_Start_opacity,
    may23_P.Show_Start_target_display, may23_P.xpos_index_Value_a,
    may23_P.ypos_index_Value_f, may23_P.Show_Start_num_states,
    may23_B.MatrixConcatenation1_b, &may23_B.sf_EmbeddedMATLABFunction_h);

  /* Concatenate: '<Root>/Matrix Concatenate' */
  for (i = 0; i < 70; i++) {
    may23_B.MatrixConcatenate[7 * i] =
      may23_B.sf_EmbeddedMATLABFunction_e.VCODE[i];
  }

  for (i = 0; i < 70; i++) {
    may23_B.MatrixConcatenate[7 * i + 1] =
      may23_B.sf_EmbeddedMATLABFunction_p.VCODE[i];
  }

  for (i = 0; i < 70; i++) {
    may23_B.MatrixConcatenate[7 * i + 2] =
      may23_B.sf_EmbeddedMATLABFunction_m.VCODE[i];
  }

  for (i = 0; i < 70; i++) {
    may23_B.MatrixConcatenate[7 * i + 3] =
      may23_B.sf_EmbeddedMATLABFunction_h.VCODE[i];
  }

  for (i = 0; i < 70; i++) {
    may23_B.MatrixConcatenate[7 * i + 4] = may23_B.puck_vcode_output[i];
  }

  for (i = 0; i < 70; i++) {
    may23_B.MatrixConcatenate[7 * i + 5] = may23_B.hand_vcodes[i << 1];
    may23_B.MatrixConcatenate[7 * i + 6] = may23_B.hand_vcodes[(i << 1) + 1];
  }

  /* End of Concatenate: '<Root>/Matrix Concatenate' */

  /* RateTransition: '<S9>/Rate Transition2' */
  if (may23_M->Timing.RateInteraction.TID1_3) {
    memcpy(&may23_DW.RateTransition2_Buffer_j[0], &may23_B.MatrixConcatenate[0],
           490U * sizeof(real_T));
  }

  /* End of RateTransition: '<S9>/Rate Transition2' */

  /* Switch: '<S372>/Switch2' */
  if (may23_B.active_arm > may23_P.Switch2_Threshold) {
    may23_B.assessment_hand_vel[0] = may23_B.sf_splitKINDataarm2.hand_velocity[0];
    may23_B.assessment_hand_vel[1] = may23_B.sf_splitKINDataarm2.hand_velocity[1];
  } else {
    may23_B.assessment_hand_vel[0] = may23_B.sf_splitKINDataarm1.hand_velocity[0];
    may23_B.assessment_hand_vel[1] = may23_B.sf_splitKINDataarm1.hand_velocity[1];
  }

  /* End of Switch: '<S372>/Switch2' */

  /* Switch: '<S372>/Switch3' */
  if (may23_B.active_arm > may23_P.Switch3_Threshold) {
    may23_B.contralateral_hand_vel[0] =
      may23_B.sf_splitKINDataarm1.hand_velocity[0];
    may23_B.contralateral_hand_vel[1] =
      may23_B.sf_splitKINDataarm1.hand_velocity[1];
  } else {
    may23_B.contralateral_hand_vel[0] =
      may23_B.sf_splitKINDataarm2.hand_velocity[0];
    may23_B.contralateral_hand_vel[1] =
      may23_B.sf_splitKINDataarm2.hand_velocity[1];
  }

  /* End of Switch: '<S372>/Switch3' */

  /* Switch: '<S372>/Switch4' */
  if (may23_B.active_arm > may23_P.Switch4_Threshold) {
    may23_B.assessment_link_angles[0] = may23_B.sf_splitKINDataarm2.link_angle[0];
    may23_B.assessment_link_angles[1] = may23_B.sf_splitKINDataarm2.link_angle[1];
  } else {
    may23_B.assessment_link_angles[0] = may23_B.sf_splitKINDataarm1.link_angle[0];
    may23_B.assessment_link_angles[1] = may23_B.sf_splitKINDataarm1.link_angle[1];
  }

  /* End of Switch: '<S372>/Switch4' */

  /* Switch: '<S372>/Switch5' */
  if (may23_B.active_arm > may23_P.Switch5_Threshold) {
    may23_B.contralateral_link_angles[0] =
      may23_B.sf_splitKINDataarm1.link_angle[0];
    may23_B.contralateral_link_angles[1] =
      may23_B.sf_splitKINDataarm1.link_angle[1];
  } else {
    may23_B.contralateral_link_angles[0] =
      may23_B.sf_splitKINDataarm2.link_angle[0];
    may23_B.contralateral_link_angles[1] =
      may23_B.sf_splitKINDataarm2.link_angle[1];
  }

  /* End of Switch: '<S372>/Switch5' */

  /* Switch: '<S372>/Switch6' */
  if (may23_B.active_arm > may23_P.Switch6_Threshold) {
    may23_B.assessment_link_vel[0] = may23_B.sf_splitKINDataarm2.link_velocity[0];
    may23_B.assessment_link_vel[1] = may23_B.sf_splitKINDataarm2.link_velocity[1];
  } else {
    may23_B.assessment_link_vel[0] = may23_B.sf_splitKINDataarm1.link_velocity[0];
    may23_B.assessment_link_vel[1] = may23_B.sf_splitKINDataarm1.link_velocity[1];
  }

  /* End of Switch: '<S372>/Switch6' */

  /* Switch: '<S372>/Switch7' */
  if (may23_B.active_arm > may23_P.Switch7_Threshold) {
    may23_B.contralateral_link_vel[0] =
      may23_B.sf_splitKINDataarm1.link_velocity[0];
    may23_B.contralateral_link_vel[1] =
      may23_B.sf_splitKINDataarm1.link_velocity[1];
  } else {
    may23_B.contralateral_link_vel[0] =
      may23_B.sf_splitKINDataarm2.link_velocity[0];
    may23_B.contralateral_link_vel[1] =
      may23_B.sf_splitKINDataarm2.link_velocity[1];
  }

  /* End of Switch: '<S372>/Switch7' */

  /* Switch: '<S374>/Switch2' */
  if (may23_B.active_arm > may23_P.Switch2_Threshold_p) {
    may23_B.assessment_hand_vel_n[0] =
      may23_B.sf_splitKINDataarm2.hand_velocity[0];
    may23_B.assessment_hand_vel_n[1] =
      may23_B.sf_splitKINDataarm2.hand_velocity[1];
  } else {
    may23_B.assessment_hand_vel_n[0] =
      may23_B.sf_splitKINDataarm1.hand_velocity[0];
    may23_B.assessment_hand_vel_n[1] =
      may23_B.sf_splitKINDataarm1.hand_velocity[1];
  }

  /* End of Switch: '<S374>/Switch2' */

  /* Switch: '<S374>/Switch3' */
  if (may23_B.active_arm > may23_P.Switch3_Threshold_g) {
    may23_B.contralateral_hand_vel_d[0] =
      may23_B.sf_splitKINDataarm1.hand_velocity[0];
    may23_B.contralateral_hand_vel_d[1] =
      may23_B.sf_splitKINDataarm1.hand_velocity[1];
  } else {
    may23_B.contralateral_hand_vel_d[0] =
      may23_B.sf_splitKINDataarm2.hand_velocity[0];
    may23_B.contralateral_hand_vel_d[1] =
      may23_B.sf_splitKINDataarm2.hand_velocity[1];
  }

  /* End of Switch: '<S374>/Switch3' */

  /* Switch: '<S374>/Switch4' */
  if (may23_B.active_arm > may23_P.Switch4_Threshold_h) {
    may23_B.assessment_link_angles_m[0] =
      may23_B.sf_splitKINDataarm2.link_angle[0];
    may23_B.assessment_link_angles_m[1] =
      may23_B.sf_splitKINDataarm2.link_angle[1];
  } else {
    may23_B.assessment_link_angles_m[0] =
      may23_B.sf_splitKINDataarm1.link_angle[0];
    may23_B.assessment_link_angles_m[1] =
      may23_B.sf_splitKINDataarm1.link_angle[1];
  }

  /* End of Switch: '<S374>/Switch4' */

  /* Switch: '<S374>/Switch5' */
  if (may23_B.active_arm > may23_P.Switch5_Threshold_j) {
    may23_B.contralateral_link_angles_f[0] =
      may23_B.sf_splitKINDataarm1.link_angle[0];
    may23_B.contralateral_link_angles_f[1] =
      may23_B.sf_splitKINDataarm1.link_angle[1];
  } else {
    may23_B.contralateral_link_angles_f[0] =
      may23_B.sf_splitKINDataarm2.link_angle[0];
    may23_B.contralateral_link_angles_f[1] =
      may23_B.sf_splitKINDataarm2.link_angle[1];
  }

  /* End of Switch: '<S374>/Switch5' */

  /* Switch: '<S374>/Switch6' */
  if (may23_B.active_arm > may23_P.Switch6_Threshold_o) {
    may23_B.assessment_link_vel_n[0] =
      may23_B.sf_splitKINDataarm2.link_velocity[0];
    may23_B.assessment_link_vel_n[1] =
      may23_B.sf_splitKINDataarm2.link_velocity[1];
  } else {
    may23_B.assessment_link_vel_n[0] =
      may23_B.sf_splitKINDataarm1.link_velocity[0];
    may23_B.assessment_link_vel_n[1] =
      may23_B.sf_splitKINDataarm1.link_velocity[1];
  }

  /* End of Switch: '<S374>/Switch6' */

  /* Switch: '<S374>/Switch7' */
  if (may23_B.active_arm > may23_P.Switch7_Threshold_l) {
    may23_B.contralateral_link_vel_a[0] =
      may23_B.sf_splitKINDataarm1.link_velocity[0];
    may23_B.contralateral_link_vel_a[1] =
      may23_B.sf_splitKINDataarm1.link_velocity[1];
  } else {
    may23_B.contralateral_link_vel_a[0] =
      may23_B.sf_splitKINDataarm2.link_velocity[0];
    may23_B.contralateral_link_vel_a[1] =
      may23_B.sf_splitKINDataarm2.link_velocity[1];
  }

  /* End of Switch: '<S374>/Switch7' */

  /* S-Function (scblock): '<S397>/S-Function' */
  /* ok to acquire for <S397>/S-Function */
  may23_DW.SFunction_IWORK.AcquireOK = 1;

  /* Constant: '<Root>/Constant' */
  may23_B.Constant = may23_P.Constant_Value_c;

  /* Constant: '<S8>/binary_file_names' */
  may23_B.binary_file_names = may23_P.binary_file_names_Value;

  /* Constant: '<S8>/binary_files' */
  memcpy(&may23_B.binary_files[0], &may23_P.binary_files_Value[0], 10U * sizeof
         (real_T));

  /* Constant: '<S375>/BARRIER_ROW;Barrier;target;Barrier;;;none;;' */
  may23_B.BARRIER_ROWBarriertargetBarriernone =
    may23_P.BARRIER_ROWBarriertargetBarriernone_Value;

  /* Constant: '<S375>/CURSOR_ROW;Hand Target Row;target;hand ;;;none;;' */
  may23_B.CURSOR_ROWHandTargetRowtargethandnone =
    may23_P.CURSOR_ROWHandTargetRowtargethandnone_Value;

  /* Constant: '<S375>/GOAL_ROW;Goal Row;target;Goal;;;none;;' */
  may23_B.GOAL_ROWGoalRowtargetGoalnone =
    may23_P.GOAL_ROWGoalRowtargetGoalnone_Value;

  /* Constant: '<S375>/GOAL_TIME;Goal time (s);float;Time that puck has to stay in goal to trigger success;;;none;;' */
  may23_B.GOAL_TIMEGoaltimesfloatTimethatpuckhastostayingoaltotriggersucc =
    may23_P.GOAL_TIMEGoaltimesfloatTimethatpuckhastostayingoaltotriggersucc;

  /* Constant: '<S375>/LOAD_ROW;Load Row;load;Load;;;none;;' */
  may23_B.LOAD_ROWLoadRowloadLoadnone =
    may23_P.LOAD_ROWLoadRowloadLoadnone_Value;

  /* Constant: '<S375>/PRESHOT_ROW;Preshot Area;target;Preshot Area ;;;none;;' */
  may23_B.PRESHOT_ROWPreshotAreatargetPreshotAreanone =
    may23_P.PRESHOT_ROWPreshotAreatargetPreshotAreanone_Value;

  /* Constant: '<S375>/PUCK_DAMPING;Puck damping;float;Damping constant on puck (between 0 and 1);;;none;;' */
  may23_B.PUCK_DAMPINGPuckdampingfloatDampingconstantonpuckbetween0and1no =
    may23_P.PUCK_DAMPINGPuckdampingfloatDampingconstantonpuckbetween0and1no;

  /* Constant: '<S375>/PUCK_ROW;Puck Target Row;target;Puck;;;none;;' */
  may23_B.PUCK_ROWPuckTargetRowtargetPucknone =
    may23_P.PUCK_ROWPuckTargetRowtargetPucknone_Value;

  /* Constant: '<S375>/SECONDS;Trial duration (s);float;How long is the trial in seconds.;;;none;;' */
  may23_B.SECONDSTrialdurationsfloatHowlongisthetrialinsecondsnone =
    may23_P.SECONDSTrialdurationsfloatHowlongisthetrialinsecondsnone_Value;

  /* Constant: '<S375>/SHOT_READY_TIME;Shot ready time (s);float;Time to hold in start target during preshot routine to trigger the set state;;;none;;' */
  may23_B.SHOT_READY_TIMEShotreadytimesfloatTimetoholdinstarttargetduring =
    may23_P.SHOT_READY_TIMEShotreadytimesfloatTimetoholdinstarttargetduring;

  /* Constant: '<S375>/SHOT_SET_TIME;Shot set time (s);float;Time to hold in start target after preshot routine to trigger go cue;;;none;;' */
  may23_B.SHOT_SET_TIMEShotsettimesfloatTimetoholdinstarttargetafterpresh =
    may23_P.SHOT_SET_TIMEShotsettimesfloatTimetoholdinstarttargetafterpresh;

  /* Constant: '<S375>/SHOT_TIME;Shot time (s);float;Time to make a shot into the goal;;;none;;' */
  may23_B.SHOT_TIMEShottimesfloatTimetomakeashotintothegoalnone =
    may23_P.SHOT_TIMEShottimesfloatTimetomakeashotintothegoalnone_Value;

  /* Constant: '<S375>/START_HOLD_TIME;Start hold time (s);float;Time to hold in start target before triggering preshot routine;;;none;;' */
  may23_B.START_HOLD_TIMEStartholdtimesfloatTimetoholdinstarttargetbefore =
    may23_P.START_HOLD_TIMEStartholdtimesfloatTimetoholdinstarttargetbefore;

  /* Constant: '<S375>/START_ROW;Start Position;target;Starting Spot for Pt ;;;none;;' */
  may23_B.START_ROWStartPositiontargetStartingSpotforPtnone =
    may23_P.START_ROWStartPositiontargetStartingSpotforPtnone_Value;

  /* Constant: '<S376>/E_BEGIN_PRESHOT;begin preshot routine;;;;;none;;' */
  may23_B.E_BEGIN_PRESHOTbeginpreshotroutinenone =
    may23_P.E_BEGIN_PRESHOTbeginpreshotroutinenone_Value;

  /* Constant: '<S376>/E_ENTER_START;enter start target;;;;;none;;' */
  may23_B.E_ENTER_STARTenterstarttargetnone =
    may23_P.E_ENTER_STARTenterstarttargetnone_Value;

  /* Constant: '<S376>/E_FAILURE;failure;;;;;red;;' */
  may23_B.E_FAILUREfailurered = may23_P.E_FAILUREfailurered_Value;

  /* Constant: '<S376>/E_HAND_IN_BARRIER;hand in barrier;;;;;none;;' */
  may23_B.E_HAND_IN_BARRIERhandinbarriernone =
    may23_P.E_HAND_IN_BARRIERhandinbarriernone_Value;

  /* Constant: '<S376>/E_NO_EVENT;n|a;;This event_code does not save an event in the data file, it just clears the event;;;none;;' */
  may23_B.E_NO_EVENTnaThisevent_codedoesnotsaveaneventinthedatafileitjust =
    may23_P.E_NO_EVENTnaThisevent_codedoesnotsaveaneventinthedatafileitjust;

  /* Constant: '<S376>/E_PUCK_IN_BARRIER;puck in barrier;;;;;none;;' */
  may23_B.E_PUCK_IN_BARRIERpuckinbarriernone =
    may23_P.E_PUCK_IN_BARRIERpuckinbarriernone_Value;

  /* Constant: '<S376>/E_PUCK_IN_GOAL;puck in goal;;;;;none;;' */
  may23_B.E_PUCK_IN_GOALpuckingoalnone =
    may23_P.E_PUCK_IN_GOALpuckingoalnone_Value;

  /* Constant: '<S376>/E_PUCK_MISS;puck miss;;;;;none;;' */
  may23_B.E_PUCK_MISSpuckmissnone = may23_P.E_PUCK_MISSpuckmissnone_Value;

  /* Constant: '<S376>/E_SHOT_GO;shot go;;;;;none;;' */
  may23_B.E_SHOT_GOshotgonone = may23_P.E_SHOT_GOshotgonone_Value;

  /* Constant: '<S376>/E_SHOT_READY;shot ready;;;;;none;;' */
  may23_B.E_SHOT_READYshotreadynone = may23_P.E_SHOT_READYshotreadynone_Value;

  /* Constant: '<S376>/E_START_TARGET_ON;start target on;;;;;none;;' */
  may23_B.E_START_TARGET_ONstarttargetonnone =
    may23_P.E_START_TARGET_ONstarttargetonnone_Value;

  /* Constant: '<S376>/E_SUCCESS;success;;;;;green;;' */
  may23_B.E_SUCCESSsuccessgreen = may23_P.E_SUCCESSsuccessgreen_Value;

  /* Constant: '<S376>/E_TIMEOUT;timeout;;;;;red;;' */
  may23_B.E_TIMEOUTtimeoutred = may23_P.E_TIMEOUTtimeoutred_Value;

  /* Constant: '<S376>/E_TRIAL_START;trial start;;;;;none;;' */
  may23_B.E_TRIAL_STARTtrialstartnone =
    may23_P.E_TRIAL_STARTtrialstartnone_Value;

  /* Constant: '<S377>/F_BUMP;F_BUMP;float;Completely arbitrary parameter based on what feels good...;;;none;;' */
  may23_B.F_BUMPF_BUMPfloatCompletelyarbitraryparameterbasedonwhatfeelsgo =
    may23_P.F_BUMPF_BUMPfloatCompletelyarbitraryparameterbasedonwhatfeelsgo;

  /* Constant: '<S377>/MASS_CIRCLE;Circle target mass;float;;;;none;;' */
  may23_B.MASS_CIRCLECircletargetmassfloatnone =
    may23_P.MASS_CIRCLECircletargetmassfloatnone_Value;

  /* Constant: '<S377>/MASS_RECT;Rectangle target mass;float;;;;none;;' */
  may23_B.MASS_RECTRectangletargetmassfloatnone =
    may23_P.MASS_RECTRectangletargetmassfloatnone_Value;

  /* Constant: '<S377>/PERT_DUR;Perturbation Duration;float;(ms) Time that the perturbation is high for;;;none;;' */
  may23_B.PERT_DURPerturbationDurationfloatmsTimethattheperturbationishig =
    may23_P.PERT_DURPerturbationDurationfloatmsTimethattheperturbationishig;

  /* Constant: '<S377>/PERT_RAMP;Perturbation Ramp Time;float;(ms) Time for the perturbation to ramp up and down;;;none;;' */
  may23_B.PERT_RAMPPerturbationRampTimefloatmsTimefortheperturbationtoram =
    may23_P.PERT_RAMPPerturbationRampTimefloatmsTimefortheperturbationtoram;

  /* Constant: '<S378>/FIRST_FILL;First fill color;colour;First fill color for a selected target (color);;;none;;' */
  may23_B.FIRST_FILLFirstfillcolorcolourFirstfillcolorforaselectedtargetc =
    may23_P.FIRST_FILLFirstfillcolorcolourFirstfillcolorforaselectedtargetc;

  /* Constant: '<S378>/HEIGHT;Height;float;Rectangle height (cm);;;none;;' */
  may23_B.HEIGHTHeightfloatRectangleheightcmnone =
    may23_P.HEIGHTHeightfloatRectangleheightcmnone_Value;

  /* Constant: '<S378>/RADIUS_LOG;logical radius;float;computational radius (cm);;;none;;' */
  may23_B.RADIUS_LOGlogicalradiusfloatcomputationalradiuscmnone =
    may23_P.RADIUS_LOGlogicalradiusfloatcomputationalradiuscmnone_Value;

  /* Constant: '<S378>/RADIUS_VIS;radius vis;float;radius in cm (legacy?);;;none;;' */
  may23_B.RADIUS_VISradiusvisfloatradiusincmlegacynone =
    may23_P.RADIUS_VISradiusvisfloatradiusincmlegacynone_Value;

  /* Constant: '<S378>/ROTATION;Rotation;float;Rectangle roation (degrees);;;none;;' */
  may23_B.ROTATIONRotationfloatRectangleroationdegreesnone =
    may23_P.ROTATIONRotationfloatRectangleroationdegreesnone_Value;

  /* Constant: '<S378>/SECOND_FILL;Second fill color;colour;Second fill color for a selected target (color);;;none;;' */
  may23_B.SECOND_FILLSecondfillcolorcolourSecondfillcolorforaselectedtarg =
    may23_P.SECOND_FILLSecondfillcolorcolourSecondfillcolorforaselectedtarg;

  /* Constant: '<S378>/STROKE_COLOR;Stroke colour;colour;Stroke color (color);;;none;;' */
  may23_B.STROKE_COLORStrokecolourcolourStrokecolorcolornone =
    may23_P.STROKE_COLORStrokecolourcolourStrokecolorcolornone_Value;

  /* Constant: '<S378>/STROKE_WIDTH;Width of the stroke;float;Stroke weight (cm);;;none;;' */
  may23_B.STROKE_WIDTHWidthofthestrokefloatStrokeweightcmnone =
    may23_P.STROKE_WIDTHWidthofthestrokefloatStrokeweightcmnone_Value;

  /* Constant: '<S378>/THIRD_FILL;third fill color;colour;Third fill color for a selected target (color);;;none;;' */
  may23_B.THIRD_FILLthirdfillcolorcolourThirdfillcolorforaselectedtargetc =
    may23_P.THIRD_FILLthirdfillcolorcolourThirdfillcolorforaselectedtargetc;

  /* Constant: '<S378>/col_x;X;float;X Position (cm) of the target relative to  local (0,0);;;none;;' */
  may23_B.col_xXfloatXPositioncmofthetargetrelativetolocal00none =
    may23_P.col_xXfloatXPositioncmofthetargetrelativetolocal00none_Value;

  /* Constant: '<S378>/col_y;Y;float;Y Position (cm) of the target relative to  local (0,0);;;none;;' */
  may23_B.col_yYfloatYPositioncmofthetargetrelativetolocal00none =
    may23_P.col_yYfloatYPositioncmofthetargetrelativetolocal00none_Value;

  /* Constant: '<S378>/WIDTH;Width or Radius;float;Rectangle width or Circle Radius (cm);;;none;;' */
  may23_B.WIDTHWidthorRadiusfloatRectanglewidthorCircleRadiuscmnone =
    may23_P.WIDTHWidthorRadiusfloatRectanglewidthorCircleRadiuscmnone_Value;

  /* Constant: '<S379>/INSTRUCTIONS=' */
  may23_B.INSTRUCTIONS = may23_P.INSTRUCTIONS_Value;

  /* Constant: '<S379>/LOAD_FOR=EITHER' */
  may23_B.LOAD_FOREITHER = may23_P.LOAD_FOREITHER_Value;

  /* Constant: '<S380>/FORCE_MULTIPLIER;Force multiplier;float;;;;none;;' */
  may23_B.FORCE_MULTIPLIERForcemultiplierfloatnone =
    may23_P.FORCE_MULTIPLIERForcemultiplierfloatnone_Value;
}

/* Model update function for TID0 */
static void may23_update0(void)        /* Sample time: [0.0s, 0.0s] */
{
  int_T idxDelay;

  /* Update for UnitDelay: '<S347>/Delay Input1' */
  may23_DW.DelayInput1_DSTATE_c = may23_B.e_exit_trial;

  /* Update for Memory: '<S336>/Delay1' incorporates:
   *  Constant: '<S3>/Repeat_Trial_Flag'
   */
  may23_DW.Delay1_PreviousInput = may23_P.Repeat_Trial_Flag_Value;

  /* Update for UnitDelay: '<S350>/Output' */
  may23_DW.Output_DSTATE = may23_B.FixPtSwitch;

  /* Update for Memory: '<S3>/Memory' incorporates:
   *  Constant: '<S3>/Next TP row'
   */
  may23_DW.Memory_PreviousInput = may23_P.NextTProw_Value;

  /* Update for Memory: '<S336>/Delay' */
  may23_DW.Delay_PreviousInput = may23_B.e_Trial_End;

  /* Update for UnitDelay: '<S348>/Delay Input1' */
  may23_DW.DelayInput1_DSTATE_a = may23_B.e_Trial_End;

  /* Update for Memory: '<S1>/Memory' */
  may23_DW.Memory_PreviousInput_m[0] = may23_B.Product_g[0];
  may23_DW.Memory_PreviousInput_m[1] = may23_B.Product_g[1];
  may23_DW.Memory_PreviousInput_m[2] = may23_B.Product_g[2];
  may23_DW.Memory_PreviousInput_m[3] = may23_B.Product_g[3];

  /* Update for Memory: '<S9>/Memory' incorporates:
   *  Constant: '<S9>/Constant'
   */
  may23_DW.Memory_PreviousInput_f = may23_P.Process_Video_CMD_video_delay;

  /* Update for Memory: '<S38>/Memory2' */
  may23_DW.Memory2_PreviousInput = may23_B.stop_vel_mode_out;

  /* Update for Atomic SubSystem: '<S1>/Poll KINARM' */
  may23_PollKINARM_UpdateTID0();

  /* End of Update for SubSystem: '<S1>/Poll KINARM' */

  /* Update for Memory: '<Root>/Memory2' */
  memcpy(&may23_DW.Memory2_PreviousInput_c[0], &may23_B.puck_vcode_output[0],
         70U * sizeof(real_T));

  /* Update for Memory: '<Root>/Memory1' */
  may23_DW.Memory1_PreviousInput_lw = may23_B.e_Puck_Stopped;

  /* Update for Memory: '<Root>/Memory4' */
  may23_DW.Memory4_PreviousInput = may23_B.e_Puck_Hit;

  /* Update for Atomic SubSystem: '<S1>/Network Transfer Subsystem' */
  may23_NetworkTransferSubsystem_UpdateTID0();

  /* End of Update for SubSystem: '<S1>/Network Transfer Subsystem' */

  /* Update for Delay: '<S34>/Delay' */
  may23_DW.Delay_DSTATE[0] = may23_DW.Delay_DSTATE[1];
  may23_DW.Delay_DSTATE[1] = may23_DW.Delay_DSTATE[2];
  may23_DW.Delay_DSTATE[2] = may23_DW.Delay_DSTATE[3];
  may23_DW.Delay_DSTATE[3] = may23_B.DataStoreRead1_l[0];

  /* Update for Delay: '<S327>/Delay' */
  for (idxDelay = 0; idxDelay < 5; idxDelay++) {
    may23_DW.Delay_DSTATE_e[idxDelay << 2] = may23_DW.Delay_DSTATE_e[(idxDelay +
      1) << 2];
    may23_DW.Delay_DSTATE_e[(idxDelay << 2) + 1] = may23_DW.Delay_DSTATE_e
      [((idxDelay + 1) << 2) + 1];
    may23_DW.Delay_DSTATE_e[(idxDelay << 2) + 2] = may23_DW.Delay_DSTATE_e
      [((idxDelay + 1) << 2) + 2];
    may23_DW.Delay_DSTATE_e[(idxDelay << 2) + 3] = may23_DW.Delay_DSTATE_e
      [((idxDelay + 1) << 2) + 3];
  }

  may23_DW.Delay_DSTATE_e[20] = may23_B.filteredVals_n[0];
  may23_DW.Delay_DSTATE_e[21] = may23_B.filteredVals_n[1];
  may23_DW.Delay_DSTATE_e[22] = may23_B.filteredVals_n[2];
  may23_DW.Delay_DSTATE_e[23] = may23_B.filteredVals_n[3];

  /* End of Update for Delay: '<S327>/Delay' */

  /* Update for Delay: '<S38>/Delay' */
  may23_DW.Delay_DSTATE_m[0] = may23_DW.Delay_DSTATE_m[1];
  may23_DW.Delay_DSTATE_m[1] = may23_DW.Delay_DSTATE_m[2];
  may23_DW.Delay_DSTATE_m[2] = may23_DW.Delay_DSTATE_m[3];
  may23_DW.Delay_DSTATE_m[3] = may23_B.DataStoreRead1[0];

  /* Update for Memory: '<S19>/Memory3' */
  may23_DW.Memory3_PreviousInput[0] = may23_B.Switch_k[0];
  may23_DW.Memory3_PreviousInput[1] = may23_B.Switch_k[1];
  may23_DW.Memory3_PreviousInput[2] = may23_B.Switch_k[2];
  may23_DW.Memory3_PreviousInput[3] = may23_B.Switch_k[3];

  /* Update for Memory: '<S38>/Memory1' */
  may23_DW.Memory1_PreviousInput = may23_B.torque_multiplier_out;

  /* Update for Memory: '<S1>/Memory1' */
  may23_DW.Memory1_PreviousInput_l = may23_B.force_scale;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_1_PreviousInput = may23_B.ArmOrientation_f;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_2_PreviousInput = may23_B.M1orientation_b;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_3_PreviousInput = may23_B.M2Orientation_k;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_4_PreviousInput = may23_B.M1GearRatio_p;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_5_PreviousInput = may23_B.M2GearRatio_i;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_9_PreviousInput = may23_B.torqueconstant_bz;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_18_PreviousInput = may23_B.ArmOrientation_m;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_19_PreviousInput = may23_B.M1orientation_f;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_20_PreviousInput = may23_B.M2Orientation_c;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_21_PreviousInput = may23_B.M1GearRatio_a;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_22_PreviousInput = may23_B.M2GearRatio_ie;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_26_PreviousInput = may23_B.torqueconstant_l;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_10_PreviousInput = may23_B.isEP_a;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_11_PreviousInput = may23_B.isHumanEXO_c;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_12_PreviousInput = may23_B.isNHPEXO_p;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_13_PreviousInput = may23_B.isClassicExo_n;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_14_PreviousInput = may23_B.isUTSEXO_k;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_15_PreviousInput = may23_B.isPMAC_c;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_16_PreviousInput = may23_B.isECAT_b;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_17_PreviousInput = may23_B.Statusread1[0];

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_23_PreviousInput = may23_B.HasSecondaryEnc_c;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_24_PreviousInput = may23_B.robottype_j;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_25_PreviousInput = may23_B.robotversion_f;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_27_PreviousInput = may23_B.isEP_e;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_28_PreviousInput = may23_B.isHumanEXO;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_29_PreviousInput = may23_B.isNHPEXO;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_30_PreviousInput = may23_B.isClassicExo_e;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_31_PreviousInput = may23_B.isUTSEXO;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_32_PreviousInput = may23_B.isPMAC_a;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_33_PreviousInput = may23_B.isECAT_i;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_34_PreviousInput = may23_B.Statusread1_c[1];

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_6_PreviousInput = may23_B.HasSecondaryEnc_n;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_7_PreviousInput = may23_B.robottype_a;

  /* Update for Memory generated from: '<S1>/Memory2' */
  may23_DW.Memory2_8_PreviousInput = may23_B.robotversion_h;

  /* Update for Memory: '<S329>/Memory1' */
  may23_DW.Memory1_PreviousInput_k[0] = may23_B.Product_b[0];
  may23_DW.Memory1_PreviousInput_k[1] = may23_B.Product_b[1];
  may23_DW.Memory1_PreviousInput_k[2] = may23_B.Product_b[2];
  may23_DW.Memory1_PreviousInput_k[3] = may23_B.Product_b[3];

  /* Update absolute time */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++may23_M->Timing.clockTick0)) {
    ++may23_M->Timing.clockTickH0;
  }

  may23_M->Timing.t[0] = may23_M->Timing.clockTick0 * may23_M->Timing.stepSize0
    + may23_M->Timing.clockTickH0 * may23_M->Timing.stepSize0 * 4294967296.0;

  /* Update absolute time */
  /* The "clockTick1" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick1"
   * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick1 and the high bits
   * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++may23_M->Timing.clockTick1)) {
    ++may23_M->Timing.clockTickH1;
  }

  may23_M->Timing.t[1] = may23_M->Timing.clockTick1 * may23_M->Timing.stepSize1
    + may23_M->Timing.clockTickH1 * may23_M->Timing.stepSize1 * 4294967296.0;
}

/* Model output function for TID2 */
static void may23_output2(void)        /* Sample time: [0.0005s, 0.0s] */
{
  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.sendpoll1_SubsysRanBC);

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.sendpoll2_SubsysRanBC);

  /* Outputs for Atomic SubSystem: '<S1>/Network Transfer Subsystem' */
  may23_NetworkTransferSubsystemTID2();

  /* End of Outputs for SubSystem: '<S1>/Network Transfer Subsystem' */

  /* Outputs for Atomic SubSystem: '<S1>/Poll Force Plates' */
  may23_PollForcePlatesTID2();

  /* End of Outputs for SubSystem: '<S1>/Poll Force Plates' */
}

/* Model update function for TID2 */
static void may23_update2(void)        /* Sample time: [0.0005s, 0.0s] */
{
  /* Update absolute time */
  /* The "clockTick2" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick2"
   * and "Timing.stepSize2". Size of "clockTick2" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick2 and the high bits
   * Timing.clockTickH2. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++may23_M->Timing.clockTick2)) {
    ++may23_M->Timing.clockTickH2;
  }

  may23_M->Timing.t[2] = may23_M->Timing.clockTick2 * may23_M->Timing.stepSize2
    + may23_M->Timing.clockTickH2 * may23_M->Timing.stepSize2 * 4294967296.0;
}

/* Model output function for TID3 */
static void may23_output3(void)        /* Sample time: [0.001s, 0.0s] */
{
  int32_T yElIdx;
  int32_T uElOffset1;
  int32_T ntIdx1;
  int32_T uElOffset0;
  int32_T ntIdx0;

  /* Reset subsysRan breadcrumbs */
  srClearBC(may23_DW.Datareceive_SubsysRanBC_n);

  /* Outputs for Atomic SubSystem: '<S1>/Poll KINARM' */
  may23_PollKINARMTID3();

  /* End of Outputs for SubSystem: '<S1>/Poll KINARM' */

  /* RateTransition generated from: '<S335>/Hold_to_1Khz' */
  may23_DW.TmpRTBAtHold_to_1KhzInport2_Buffer0 = may23_B.DataTypeConversion2_h;

  /* RateTransition: '<S22>/Rate Transition' */
  memcpy(&may23_B.RateTransition_e[0], &may23_DW.RateTransition_Buffer[0], 71U *
         sizeof(real_T));

  /* RateTransition: '<S9>/Rate Transition2' */
  memcpy(&may23_B.RateTransition2_p[0], &may23_DW.RateTransition2_Buffer_j[0],
         490U * sizeof(real_T));

  /* PermuteDimensions: '<S9>/invert dim' */
  yElIdx = 0;
  uElOffset1 = 0;
  for (ntIdx1 = 0; ntIdx1 < 7; ntIdx1++) {
    uElOffset0 = uElOffset1;
    for (ntIdx0 = 0; ntIdx0 < 70; ntIdx0++) {
      may23_B.MatrixConcatenate_d[yElIdx] = may23_B.RateTransition2_p[uElOffset0];
      yElIdx++;
      uElOffset0 += 7;
    }

    uElOffset1++;
  }

  /* End of PermuteDimensions: '<S9>/invert dim' */

  /* Constant: '<S9>/GUI_VCODE' */
  memcpy(&may23_B.MatrixConcatenate_d[490], &may23_P.GUI_VCODE_Value[0], 630U *
         sizeof(real_T));

  /* Outputs for Atomic SubSystem: '<S9>/PVC_core' */
  may23_PVC_coreTID3();

  /* End of Outputs for SubSystem: '<S9>/PVC_core' */

  /* RateTransition: '<S23>/Rate Transition2' */
  may23_DW.RateTransition2_Buffer0 = may23_B.vcode_err_id;

  /* RateTransition: '<S25>/Rate Transition' */
  memcpy(&may23_B.RateTransition_k[0], &may23_DW.RateTransition_Buffer_d[0], 72U
         * sizeof(real_T));

  /* UnitDelay: '<S46>/Output' */
  may23_B.Output_h = may23_DW.Output_DSTATE_d;

  /* Sum: '<S48>/FixPt Sum1' incorporates:
   *  Constant: '<S48>/FixPt Constant'
   */
  may23_B.FixPtSum1_h = may23_B.Output_h + may23_P.FixPtConstant_Value_gy;

  /* Switch: '<S49>/FixPt Switch' incorporates:
   *  Constant: '<S49>/Constant'
   */
  if (may23_B.FixPtSum1_h > may23_P.WrapToZero_Threshold_my) {
    may23_B.FixPtSwitch_c = may23_P.Constant_Value_n;
  } else {
    may23_B.FixPtSwitch_c = may23_B.FixPtSum1_h;
  }

  /* End of Switch: '<S49>/FixPt Switch' */

  /* DataTypeConversion: '<S26>/Timestamp' */
  may23_B.Timestamp = may23_B.Output_h;

  /* RateTransition generated from: '<S26>/Timestamp' */
  may23_DW.TmpRTBAtTimestampOutport1_Buffer0 = may23_B.Timestamp;

  /* RateTransition: '<S1>/Rate Transition1' */
  memcpy(&may23_B.RateTransition1_a[0], &may23_DW.RateTransition1_Buffer[0],
         sizeof(real_T) << 4U);

  /* RateTransition: '<S1>/Rate Transition2' */
  may23_B.RateTransition2_h[0] = may23_DW.RateTransition2_Buffer[0];
  may23_B.RateTransition2_h[1] = may23_DW.RateTransition2_Buffer[1];

  /* RateTransition: '<S1>/Rate Transition' */
  memcpy(&may23_B.RateTransition_p[0], &may23_DW.RateTransition_Buffer_j[0], 20U
         * sizeof(real_T));

  /* Outputs for Atomic SubSystem: '<S1>/Network Transfer Subsystem' */
  may23_NetworkTransferSubsystemTID3();

  /* End of Outputs for SubSystem: '<S1>/Network Transfer Subsystem' */

  /* Outputs for Atomic SubSystem: '<S1>/Receive_Gaze' */
  may23_Receive_GazeTID3();

  /* End of Outputs for SubSystem: '<S1>/Receive_Gaze' */

  /* RateTransition: '<S381>/Rate Transition1' */
  may23_B.RateTransition1_c = may23_DW.RateTransition1_Buffer_k;

  /* S-Function (delay_vcodes): '<S381>/S-Function Builder' incorporates:
   *  Constant: '<S381>/1000 hz'
   */
  delay_vcodes_Outputs_wrapper(&may23_B.vis_cmd[0], &may23_B.vis_cmd_len,
    &may23_B.RateTransition1_c, &may23_P.u000hz_Value,
    &may23_B.SFunctionBuilder_o1[0], &may23_B.SFunctionBuilder_o2,
    &may23_B.SFunctionBuilder_o3[0] );

  /* S-Function (slrtUDPSend): '<S9>/Send' */

  /* Level2 S-Function Block: '<S9>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[43];
    sfcnOutputs(rts,3);
  }
}

/* Model update function for TID3 */
static void may23_update3(void)        /* Sample time: [0.001s, 0.0s] */
{
  /* Update for UnitDelay: '<S46>/Output' */
  may23_DW.Output_DSTATE_d = may23_B.FixPtSwitch_c;

  /* Update for Atomic SubSystem: '<S1>/Network Transfer Subsystem' */
  may23_NetworkTransferSubsystem_UpdateTID3();

  /* End of Update for SubSystem: '<S1>/Network Transfer Subsystem' */

  /* Update absolute time */
  /* The "clockTick3" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick3"
   * and "Timing.stepSize3". Size of "clockTick3" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick3 and the high bits
   * Timing.clockTickH3. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++may23_M->Timing.clockTick3)) {
    ++may23_M->Timing.clockTickH3;
  }

  may23_M->Timing.t[3] = may23_M->Timing.clockTick3 * may23_M->Timing.stepSize3
    + may23_M->Timing.clockTickH3 * may23_M->Timing.stepSize3 * 4294967296.0;
}

/* Model output function for TID4 */
static void may23_output4(void)        /* Sample time: [0.1s, 0.0s] */
{
  /* Outputs for Atomic SubSystem: '<S1>/Keep alive' */
  may23_Keepalive();

  /* End of Outputs for SubSystem: '<S1>/Keep alive' */
}

/* Model update function for TID4 */
static void may23_update4(void)        /* Sample time: [0.1s, 0.0s] */
{
  /* Update absolute time */
  /* The "clockTick4" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick4"
   * and "Timing.stepSize4". Size of "clockTick4" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick4 and the high bits
   * Timing.clockTickH4. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++may23_M->Timing.clockTick4)) {
    ++may23_M->Timing.clockTickH4;
  }

  may23_M->Timing.t[4] = may23_M->Timing.clockTick4 * may23_M->Timing.stepSize4
    + may23_M->Timing.clockTickH4 * may23_M->Timing.stepSize4 * 4294967296.0;
}

/* Model output wrapper function for compatibility with a static main program */
static void may23_output(int_T tid)
{
  switch (tid) {
   case 0 :
    may23_output0();
    break;

   case 2 :
    may23_output2();
    break;

   case 3 :
    may23_output3();
    break;

   case 4 :
    may23_output4();
    break;

   default :
    break;
  }
}

/* Model update wrapper function for compatibility with a static main program */
static void may23_update(int_T tid)
{
  switch (tid) {
   case 0 :
    may23_update0();
    break;

   case 2 :
    may23_update2();
    break;

   case 3 :
    may23_update3();
    break;

   case 4 :
    may23_update4();
    break;

   default :
    break;
  }
}

/* Model initialize function */
static void may23_initialize(void)
{
  {
    /* user code (Start function Header) */
    {
      int_T i;
      int_T idx;
      int_T idxSignalStart;
      int_T pdoSignalStringLength;
      char_T pdoListString[MAX_PDO_LIST_STRING_LENGTH];
      char_T pdoSignalString[MAX_PDO_SIGNAL_NAME_LENGTH];
      int_T slaveAddrStringLength;
      char_T slaveAddrListString[MAX_SLAVEADDR_LIST_STRING_LENGTH];
      char_T slaveAddrString[10];
      char_T delimiter = '!';
      g_pdoRxNumberSignals[1] = min(77, MAX_NUMBER_PDO_SIGNALS);
      g_pdoTxNumberSignals[1] = min(19, MAX_NUMBER_PDO_SIGNALS);
      strncpy(pdoListString,
              "!Drive 1 (Elmo Drive).Inputs.Position actual value!592!Drive 1 (Elmo Drive).Inputs.Digital Inputs!624!Drive 1 (Elmo Drive).Inputs.Status word!656!Drive 1 (Elmo Drive).Inputs_1.Mode of operation display!672!Drive 1 (Elmo Drive).Inputs_2.Velocity actual value!688!Drive 1 (Elmo Drive).Inputs_3.Torque actual value!720!Drive 1 (Elmo Drive).Inputs_4.Auxiliary position actual value!736!Drive 1 (Elmo Drive).Inputs_5.Elmo Status Reg!768!Drive 2 (Elmo Drive).Inputs.Position actual value!800!Drive 2 (Elmo Drive).Inputs.Digital Inputs!832!Drive 2 (Elmo Drive).Inputs.Status word!864!Drive 2 (Elmo Drive).Inputs_1.Mode of operation display!880!Drive 2 (Elmo Drive).Inputs_2.Velocity actual value!896!Drive 2 (Elmo Drive).Inputs_3.Torque actual value!928!Drive 2 (Elmo Drive).Inputs_4.Auxiliary position actual value!944!Drive 2 (Elmo Drive).Inputs_5.Elmo Status Reg!976!Drive 3 (Elmo Drive).Inputs.Position actual value!1008!Drive 3 (Elmo Drive).Inputs.Digital Inputs!1040!Drive 3 (Elmo Drive).Inputs.Status word!1072!Drive 3 (Elmo Drive).Inputs_1.Mode of operation display!1088!Drive 3 (Elmo Drive).Inputs_2.Velocity actual value!1104!Drive 3 (Elmo Drive).Inputs_3.Torque actual value!1136!Drive 3 (Elmo Drive).Inputs_4.Auxiliary position actual value!1152!Drive 3 (Elmo Drive).Inputs_5.Elmo Status Reg!1184!Drive 4 (Elmo Drive).Inputs.Position actual value!1216!Drive 4 (Elmo Drive).Inputs.Digital Inputs!1248!Drive 4 (Elmo Drive).Inputs.Status word!1280!Drive 4 (Elmo Drive).Inputs_1.Mode of operation display!1296!Drive 4 (Elmo Drive).Inputs_2.Velocity actual value!1312!Drive 4 (Elmo Drive).Inputs_3.Torque actual value!1344!Drive 4 (Elmo Drive).Inputs_4.Auxiliary position actual value!1360!Drive 4 (Elmo Drive).Inputs_5.Elmo Status Reg!1392!Inputs.Frm0State!12160!Inputs.Frm0WcState!12176!Drive 3 (Elmo Drive).WcState.WcState!12179!Drive 2 (Elmo Drive).WcState.WcState!12179!Drive 1 (Elmo Drive).WcState.WcState!12179!Drive 4 (Elmo Drive).WcState.WcState!12179!Inputs.Frm0InputToggle!12192!Drive 3 (Elmo Drive).WcState.InputToggle!12195!Drive 2 (Elmo Drive).WcState.InputToggle!12195!Drive 1 (Elmo Drive).WcState.InputToggle!12195!Drive 4 (Elmo Drive).WcState.InputToggle!12195!SyncUnits.Drive.<unreferenced>.WcState.WcState!12208!SyncUnits.Drive.Task 2.WcState.WcState!12209!Inputs.SlaveCount!12240!Inputs.DevState!12272!InfoData.ChangeCount!12288!InfoData.DevId!12304!InfoData.AmsNetId!12320!InfoData.CfgSlaveCount!12368!Drive 1 (Elmo Drive).InfoData.State!12384!Drive 1 (Elmo Drive).InfoData.AdsAddr!12400!Drive 1 (Elmo Drive).InfoData.Chn0!12464!Drive 1 (Elmo Drive).InfoData.DcOutputShift!12472!Drive 1 (Elmo Drive).InfoData.DcInputShift!12504!Drive 2 (Elmo Drive).InfoData.State!12536!Drive 2 (Elmo Drive).InfoData.AdsAddr!12552!Drive 2 (Elmo Drive).InfoData.Chn0!12616!Drive 2 (Elmo Drive).InfoData.DcOutputShift!12624!Drive 2 (Elmo Drive).InfoData.DcInputShift!12656!Drive 3 (Elmo Drive).InfoData.State!12688!Drive 3 (Elmo Drive).InfoData.AdsAddr!12704!Drive 3 (Elmo Drive).InfoData.Chn0!12768!Drive 3 (Elmo Drive).InfoData.DcOutputShift!12776!Drive 3 (Elmo Drive).InfoData.DcInputShift!12808!Drive 4 (Elmo Drive).InfoData.State!12840!Drive 4 (Elmo Drive).InfoData.AdsAddr!12856!Drive 4 (Elmo Drive).InfoData.Chn0!12920!Drive 4 (Elmo Drive).InfoData.DcOutputShift!12928!Drive 4 (Elmo Drive).InfoData.DcInputShift!12960!SyncUnits.Drive.<unreferenced>.InfoData.ObjectId!12992!SyncUnits.Drive.<unreferenced>.InfoData.State!13024!SyncUnits.Drive.<unreferenced>.InfoData.SlaveCount!13040!SyncUnits.Drive.Task 2.InfoData.ObjectId!13056!SyncUnits.Drive.Task 2.InfoData.State!13088!SyncUnits.Drive.Task 2.InfoData.SlaveCount!13104!",
              MAX_PDO_LIST_STRING_LENGTH);
      idx = 0;
      for (i = 0 ; i < g_pdoRxNumberSignals[1]; i++ ) {
        idxSignalStart = ++idx;
        while (pdoListString[idx] != delimiter && idx <
               MAX_PDO_LIST_STRING_LENGTH)
          idx++;
        pdoSignalStringLength = min( (idx - idxSignalStart ),
          MAX_PDO_SIGNAL_NAME_LENGTH - 1);
        strncpy(pdoSignalString, pdoListString + idxSignalStart,
                pdoSignalStringLength );
        pdoSignalString[pdoSignalStringLength] = '\0';
        strcpy(g_pdoRxSignalList[1][i], pdoSignalString);
        idxSignalStart = ++idx;
        while (pdoListString[idx] != delimiter && idx <
               MAX_PDO_LIST_STRING_LENGTH)
          idx++;
        pdoSignalStringLength = min( (idx - idxSignalStart ),
          MAX_PDO_SIGNAL_NAME_LENGTH - 1);
        strncpy(pdoSignalString, pdoListString + idxSignalStart,
                pdoSignalStringLength );
        pdoSignalString[pdoSignalStringLength] = '\0';
        g_pdoRxSignalOffset[1][i] = atoi(pdoSignalString);
      }

      strncpy(pdoListString,
              "!Drive 1 (Elmo Drive).Outputs.Target Torque!592!Drive 1 (Elmo Drive).Outputs.Control word!608!Drive 1 (Elmo Drive).Outputs_1.Mode of operation!624!Drive 1 (Elmo Drive).Outputs_2.Digital Outputs!640!Drive 2 (Elmo Drive).Outputs.Target Torque!800!Drive 2 (Elmo Drive).Outputs.Control word!816!Drive 2 (Elmo Drive).Outputs_1.Mode of operation!832!Drive 2 (Elmo Drive).Outputs_2.Digital Outputs!848!Drive 3 (Elmo Drive).Outputs.Target Torque!1008!Drive 3 (Elmo Drive).Outputs.Control word!1024!Drive 3 (Elmo Drive).Outputs_1.Mode of operation!1040!Drive 3 (Elmo Drive).Outputs_2.Digital Outputs!1056!Drive 4 (Elmo Drive).Outputs.Target Torque!1216!Drive 4 (Elmo Drive).Outputs.Control word!1232!Drive 4 (Elmo Drive).Outputs_1.Mode of operation!1248!Drive 4 (Elmo Drive).Outputs_2.Digital Outputs!1264!Outputs.Frm0Ctrl!12160!Outputs.Frm0WcCtrl!12176!Outputs.DevCtrl!12272!",
              MAX_PDO_LIST_STRING_LENGTH);
      idx = 0;
      for (i = 0 ; i < g_pdoTxNumberSignals[1]; i++ ) {
        idxSignalStart = ++idx;
        while (pdoListString[idx] != delimiter && idx <
               MAX_PDO_LIST_STRING_LENGTH)
          idx++;
        pdoSignalStringLength = min( (idx - idxSignalStart ),
          MAX_PDO_SIGNAL_NAME_LENGTH - 1);
        strncpy(pdoSignalString, pdoListString + idxSignalStart,
                pdoSignalStringLength );
        pdoSignalString[pdoSignalStringLength] = '\0';
        strcpy(g_pdoTxSignalList[1][i], pdoSignalString);
        idxSignalStart = ++idx;
        while (pdoListString[idx] != delimiter && idx <
               MAX_PDO_LIST_STRING_LENGTH)
          idx++;
        pdoSignalStringLength = min( (idx - idxSignalStart ),
          MAX_PDO_SIGNAL_NAME_LENGTH - 1);
        strncpy(pdoSignalString, pdoListString + idxSignalStart,
                pdoSignalStringLength );
        pdoSignalString[pdoSignalStringLength] = '\0';
        g_pdoTxSignalOffset[1][i] = atoi(pdoSignalString);
      }

      strncpy(slaveAddrListString, "!1001!1002!1003!1004!",
              MAX_SLAVEADDR_LIST_STRING_LENGTH);
      idx = 0;
      for (i = 0 ; i < 4; i++ ) {
        idxSignalStart = ++idx;
        while (slaveAddrListString[idx] != delimiter && idx <
               MAX_SLAVEADDR_LIST_STRING_LENGTH)
          idx++;
        slaveAddrStringLength = idx - idxSignalStart;
        strncpy(slaveAddrString, slaveAddrListString + idxSignalStart,
                slaveAddrStringLength );
        slaveAddrString[slaveAddrStringLength] = '\0';
        g_ecatSlaveAddressList[1][i] = (int_T)atoi(slaveAddrString);
      }
    }

    {
      int_T i;
      int_T idx;
      int_T idxSignalStart;
      int_T pdoSignalStringLength;
      char_T pdoListString[MAX_PDO_LIST_STRING_LENGTH];
      char_T pdoSignalString[MAX_PDO_SIGNAL_NAME_LENGTH];
      int_T slaveAddrStringLength;
      char_T slaveAddrListString[MAX_SLAVEADDR_LIST_STRING_LENGTH];
      char_T slaveAddrString[10];
      char_T delimiter = '!';
      g_pdoRxNumberSignals[0] = min(47, MAX_NUMBER_PDO_SIGNALS);
      g_pdoTxNumberSignals[0] = min(11, MAX_NUMBER_PDO_SIGNALS);
      strncpy(pdoListString,
              "!Drive 1 (Elmo Drive).Inputs.Position actual value!592!Drive 1 (Elmo Drive).Inputs.Digital Inputs!624!Drive 1 (Elmo Drive).Inputs.Status word!656!Drive 1 (Elmo Drive).Inputs_1.Mode of operation display!672!Drive 1 (Elmo Drive).Inputs_2.Velocity actual value!688!Drive 1 (Elmo Drive).Inputs_3.Torque actual value!720!Drive 1 (Elmo Drive).Inputs_4.Auxiliary position actual value!736!Drive 1 (Elmo Drive).Inputs_5.Elmo Status Reg!768!Drive 2 (Elmo Drive).Inputs.Position actual value!800!Drive 2 (Elmo Drive).Inputs.Digital Inputs!832!Drive 2 (Elmo Drive).Inputs.Status word!864!Drive 2 (Elmo Drive).Inputs_1.Mode of operation display!880!Drive 2 (Elmo Drive).Inputs_2.Velocity actual value!896!Drive 2 (Elmo Drive).Inputs_3.Torque actual value!928!Drive 2 (Elmo Drive).Inputs_4.Auxiliary position actual value!944!Drive 2 (Elmo Drive).Inputs_5.Elmo Status Reg!976!Inputs.Frm0State!12160!Inputs.Frm0WcState!12176!Drive 1 (Elmo Drive).WcState.WcState!12179!Drive 2 (Elmo Drive).WcState.WcState!12179!Inputs.Frm0InputToggle!12192!Drive 1 (Elmo Drive).WcState.InputToggle!12195!Drive 2 (Elmo Drive).WcState.InputToggle!12195!SyncUnits.Drive.<unreferenced>.WcState.WcState!12208!SyncUnits.Drive.Task 2.WcState.WcState!12209!Inputs.SlaveCount!12240!Inputs.DevState!12272!InfoData.ChangeCount!12288!InfoData.DevId!12304!InfoData.AmsNetId!12320!InfoData.CfgSlaveCount!12368!Drive 1 (Elmo Drive).InfoData.State!12384!Drive 1 (Elmo Drive).InfoData.AdsAddr!12400!Drive 1 (Elmo Drive).InfoData.Chn0!12464!Drive 1 (Elmo Drive).InfoData.DcOutputShift!12472!Drive 1 (Elmo Drive).InfoData.DcInputShift!12504!Drive 2 (Elmo Drive).InfoData.State!12536!Drive 2 (Elmo Drive).InfoData.AdsAddr!12552!Drive 2 (Elmo Drive).InfoData.Chn0!12616!Drive 2 (Elmo Drive).InfoData.DcOutputShift!12624!Drive 2 (Elmo Drive).InfoData.DcInputShift!12656!SyncUnits.Drive.<unreferenced>.InfoData.ObjectId!12688!SyncUnits.Drive.<unreferenced>.InfoData.State!12720!SyncUnits.Drive.<unreferenced>.InfoData.SlaveCount!12736!SyncUnits.Drive.Task 2.InfoData.ObjectId!12752!SyncUnits.Drive.Task 2.InfoData.State!12784!SyncUnits.Drive.Task 2.InfoData.SlaveCount!12800!",
              MAX_PDO_LIST_STRING_LENGTH);
      idx = 0;
      for (i = 0 ; i < g_pdoRxNumberSignals[0]; i++ ) {
        idxSignalStart = ++idx;
        while (pdoListString[idx] != delimiter && idx <
               MAX_PDO_LIST_STRING_LENGTH)
          idx++;
        pdoSignalStringLength = min( (idx - idxSignalStart ),
          MAX_PDO_SIGNAL_NAME_LENGTH - 1);
        strncpy(pdoSignalString, pdoListString + idxSignalStart,
                pdoSignalStringLength );
        pdoSignalString[pdoSignalStringLength] = '\0';
        strcpy(g_pdoRxSignalList[0][i], pdoSignalString);
        idxSignalStart = ++idx;
        while (pdoListString[idx] != delimiter && idx <
               MAX_PDO_LIST_STRING_LENGTH)
          idx++;
        pdoSignalStringLength = min( (idx - idxSignalStart ),
          MAX_PDO_SIGNAL_NAME_LENGTH - 1);
        strncpy(pdoSignalString, pdoListString + idxSignalStart,
                pdoSignalStringLength );
        pdoSignalString[pdoSignalStringLength] = '\0';
        g_pdoRxSignalOffset[0][i] = atoi(pdoSignalString);
      }

      strncpy(pdoListString,
              "!Drive 1 (Elmo Drive).Outputs.Target Torque!592!Drive 1 (Elmo Drive).Outputs.Control word!608!Drive 1 (Elmo Drive).Outputs_1.Mode of operation!624!Drive 1 (Elmo Drive).Outputs_2.Digital Outputs!640!Drive 2 (Elmo Drive).Outputs.Target Torque!800!Drive 2 (Elmo Drive).Outputs.Control word!816!Drive 2 (Elmo Drive).Outputs_1.Mode of operation!832!Drive 2 (Elmo Drive).Outputs_2.Digital Outputs!848!Outputs.Frm0Ctrl!12160!Outputs.Frm0WcCtrl!12176!Outputs.DevCtrl!12272!",
              MAX_PDO_LIST_STRING_LENGTH);
      idx = 0;
      for (i = 0 ; i < g_pdoTxNumberSignals[0]; i++ ) {
        idxSignalStart = ++idx;
        while (pdoListString[idx] != delimiter && idx <
               MAX_PDO_LIST_STRING_LENGTH)
          idx++;
        pdoSignalStringLength = min( (idx - idxSignalStart ),
          MAX_PDO_SIGNAL_NAME_LENGTH - 1);
        strncpy(pdoSignalString, pdoListString + idxSignalStart,
                pdoSignalStringLength );
        pdoSignalString[pdoSignalStringLength] = '\0';
        strcpy(g_pdoTxSignalList[0][i], pdoSignalString);
        idxSignalStart = ++idx;
        while (pdoListString[idx] != delimiter && idx <
               MAX_PDO_LIST_STRING_LENGTH)
          idx++;
        pdoSignalStringLength = min( (idx - idxSignalStart ),
          MAX_PDO_SIGNAL_NAME_LENGTH - 1);
        strncpy(pdoSignalString, pdoListString + idxSignalStart,
                pdoSignalStringLength );
        pdoSignalString[pdoSignalStringLength] = '\0';
        g_pdoTxSignalOffset[0][i] = atoi(pdoSignalString);
      }

      strncpy(slaveAddrListString, "!1001!1002!",
              MAX_SLAVEADDR_LIST_STRING_LENGTH);
      idx = 0;
      for (i = 0 ; i < 2; i++ ) {
        idxSignalStart = ++idx;
        while (slaveAddrListString[idx] != delimiter && idx <
               MAX_SLAVEADDR_LIST_STRING_LENGTH)
          idx++;
        slaveAddrStringLength = idx - idxSignalStart;
        strncpy(slaveAddrString, slaveAddrListString + idxSignalStart,
                slaveAddrStringLength );
        slaveAddrString[slaveAddrStringLength] = '\0';
        g_ecatSlaveAddressList[0][i] = (int_T)atoi(slaveAddrString);
      }
    }

    /* Start for S-Function (ich10): '<S3>/ICH7' */
    /* Level2 S-Function Block: '<S3>/ICH7' (ich10) */
    {
      SimStruct *rts = may23_M->childSfunctions[40];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for S-Function (slrtUDPReceive): '<S335>/Run Command Receive' */
    /* Level2 S-Function Block: '<S335>/Run Command Receive' (slrtUDPReceive) */
    {
      SimStruct *rts = may23_M->childSfunctions[41];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for Constant: '<S3>/Pause Type' */
    may23_B.PauseType = may23_P.PauseType_Value;

    /* Start for Enabled SubSystem: '<S340>/enable_tables' */
    /* Start for Constant: '<S351>/Block Definitions' */
    memcpy(&may23_B.BlockDefinitions[0], &may23_P.BlockDefinitions_Value[0],
           25000U * sizeof(real_T));

    /* Start for Constant: '<S351>/Block Sequence' */
    memcpy(&may23_B.BlockSequence[0], &may23_P.BlockSequence_Value[0], 3000U *
           sizeof(real_T));

    /* Start for Constant: '<S351>/Target Table' */
    memcpy(&may23_B.TargetTable[0], &may23_P.TargetTable_Value[0], 1600U *
           sizeof(real_T));

    /* End of Start for SubSystem: '<S340>/enable_tables' */

    /* Start for Constant: '<S3>/Use custom TP sequence' */
    may23_B.UsecustomTPsequence = may23_P.UsecustomTPsequence_Value;

    /* Start for DiscretePulseGenerator: '<S336>/Task Clock' */
    may23_DW.clockTickCounter = 0;

    /* Start for Atomic SubSystem: '<S1>/Receive_Gaze' */
    may23_Receive_Gaze_Start();

    /* End of Start for SubSystem: '<S1>/Receive_Gaze' */

    /* Start for Atomic SubSystem: '<S1>/Poll KINARM' */
    may23_PollKINARM_Start();

    /* End of Start for SubSystem: '<S1>/Poll KINARM' */

    /* Start for RateTransition generated from: '<S335>/Hold_to_1Khz' */
    may23_B.TmpRTBAtHold_to_1KhzInport2 =
      may23_P.TmpRTBAtHold_to_1KhzInport2_InitialCondition;

    /* Start for DiscretePulseGenerator: '<S21>/Pulse Generator' */
    may23_DW.clockTickCounter_d = 0;

    /* Start for RateTransition: '<S23>/Rate Transition2' */
    may23_B.RateTransition2 = may23_P.RateTransition2_InitialCondition_l;

    /* Start for Atomic SubSystem: '<S1>/Poll Force Plates' */
    may23_PollForcePlates_Start();

    /* End of Start for SubSystem: '<S1>/Poll Force Plates' */

    /* Start for S-Function (slrtUDPReceive): '<S9>/Receive' */
    /* Level2 S-Function Block: '<S9>/Receive' (slrtUDPReceive) */
    {
      SimStruct *rts = may23_M->childSfunctions[42];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for Atomic SubSystem: '<S9>/PVC_core' */
    may23_PVC_core_Start();

    /* End of Start for SubSystem: '<S9>/PVC_core' */

    /* Start for RateTransition generated from: '<S26>/Timestamp' */
    may23_B.TmpRTBAtTimestampOutport1 =
      may23_P.TmpRTBAtTimestampOutport1_InitialCondition;

    /* Start for Atomic SubSystem: '<S1>/Network Transfer Subsystem' */
    may23_NetworkTransferSubsystem_Start();

    /* End of Start for SubSystem: '<S1>/Network Transfer Subsystem' */

    /* Start for Constant: '<S4>/up_duration(ms)' */
    may23_B.up_durationms = may23_P.KINARM_EP_Apply_Loads_up_duration;

    /* Start for Constant: '<S4>/down_duration(ms)' */
    may23_B.down_durationms = may23_P.KINARM_EP_Apply_Loads_down_duration;

    /* Start for Constant: '<S5>/up_duration(ms)' */
    may23_B.up_durationms_h = may23_P.KINARM_Exo_Apply_Loads_up_duration;

    /* Start for Constant: '<S5>/down_duration(ms)' */
    may23_B.down_durationms_b = may23_P.KINARM_Exo_Apply_Loads_down_duration;

    /* Start for Constant: '<S4>/up_duration(ms)1' */
    may23_B.up_durationms1 = may23_P.KINARM_EP_Apply_Loads_up_duration;

    /* Start for Constant: '<S4>/down_duration(ms)1' */
    may23_B.down_durationms1 = may23_P.KINARM_EP_Apply_Loads_down_duration;

    /* Start for DiscretePulseGenerator: '<S38>/Task Clock' */
    may23_DW.clockTickCounter_c = 0;

    /* Start for Atomic SubSystem: '<S1>/apply loads' */
    may23_applyloads_Start();

    /* End of Start for SubSystem: '<S1>/apply loads' */

    /* Start for Constant: '<S329>/encoder_err_threshold' */
    may23_B.encoder_err_threshold = may23_P.encoder_err_threshold_Value;

    /* Start for DataStoreMemory: '<S1>/ECAT Dig Diagnostic' */
    may23_DW.ECATDigDiagnostic[0] = may23_P.ECATDigDiagnostic_InitialValue[0];
    may23_DW.ECATDigDiagnostic[1] = may23_P.ECATDigDiagnostic_InitialValue[1];
    may23_DW.ECATDigDiagnostic[2] = may23_P.ECATDigDiagnostic_InitialValue[2];
    may23_DW.ECATDigDiagnostic[3] = may23_P.ECATDigDiagnostic_InitialValue[3];

    /* Start for DataStoreMemory: '<S1>/ECAT Status' */
    memcpy(&may23_DW.ECATStatus[0], &may23_P.ECATStatus_InitialValue[0], sizeof
           (real_T) << 3U);

    /* Start for DataStoreMemory: '<S1>/ECAT Status1' */
    memcpy(&may23_DW.DataReadyStatus[0], &may23_P.ECATStatus1_InitialValue[0],
           10U * sizeof(real_T));

    /* Start for DataStoreMemory: '<S1>/ECAT hardware' */
    memcpy(&may23_DW.ECATHardware[0], &may23_P.ECAThardware_InitialValue[0], 14U
           * sizeof(real_T));

    /* Start for S-Function (scblock): '<S397>/S-Function' */

    /* S-Function Block: <S397>/S-Function (scblock) */
    {
      int i;
      if ((i = rl32eScopeExists(4)) == 0) {
        if ((i = rl32eDefScope(4,2)) != 0) {
          printf("Error creating scope 4\n");
        } else {
          rl32eAddSignal(4, rl32eGetSignalNo("Subsystem/Switch/s1"));
          rl32eAddSignal(4, rl32eGetSignalNo("Subsystem/Switch/s2"));
          rl32eAddSignal(4, rl32eGetSignalNo("Subsystem/Switch/s3"));
          rl32eAddSignal(4, rl32eGetSignalNo("Subsystem/Switch/s4"));
          rl32eSetScope(4, 4, 250);
          rl32eSetScope(4, 5, 0);
          rl32eSetScope(4, 6, 1);
          rl32eSetScope(4, 0, 0);
          rl32eSetScope(4, 3, rl32eGetSignalNo("Subsystem/Switch/s1"));
          rl32eSetScope(4, 1, 0.0);
          rl32eSetScope(4, 2, 0);
          rl32eSetScope(4, 9, 0);
          rl32eSetTargetScope(4, 11, 0.0);
          rl32eSetTargetScope(4, 10, 0.0);
          xpceScopeAcqOK(4, &may23_DW.SFunction_IWORK.AcquireOK);
        }
      }
    }

    /* Start for S-Function (slrtUDPSend): '<S9>/Send' */
    /* Level2 S-Function Block: '<S9>/Send' (slrtUDPSend) */
    {
      SimStruct *rts = may23_M->childSfunctions[43];
      sfcnStart(rts);
      if (ssGetErrorStatus(rts) != (NULL))
        return;
    }

    /* Start for Atomic SubSystem: '<S1>/Keep alive' */
    may23_Keepalive_Start();

    /* End of Start for SubSystem: '<S1>/Keep alive' */

    /* user code (Start function Trailer) */
    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1001 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658983257,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1001 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_d[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_d[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1001 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658983265,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1001 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_m[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_m[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1001 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDODownload(658983277,1*(uint32_T)4,(uint32_T)
              deviceIndex);
            printf("SDO Download. Register device %d, slave addr: %d\n",
                   deviceIndex, 1001);
          }
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_i[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_i[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1002 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658983341,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1002 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_lh[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_lh[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1002 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658983352,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1002 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_h[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_h[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1002 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDODownload(658983361,1*(uint32_T)4,(uint32_T)
              deviceIndex);
            printf("SDO Download. Register device %d, slave addr: %d\n",
                   deviceIndex, 1002);
          }
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_mg[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_mg[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1001 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(35101310,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1001 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_i[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_i[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1002 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658985860,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1002 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_b[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_b[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1001 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDODownload(65898580,1*(uint32_T)4,(uint32_T)
              deviceIndex);
            printf("SDO Download. Register device %d, slave addr: %d\n",
                   deviceIndex, 1001);
          }
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_m[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_m[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1001 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(35081310,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1001 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_c[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_c[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1003 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658983381,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1003 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_jb[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_jb[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1003 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658983393,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1003 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_l[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_l[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1003 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDODownload(658983403,1*(uint32_T)4,(uint32_T)
              deviceIndex);
            printf("SDO Download. Register device %d, slave addr: %d\n",
                   deviceIndex, 1003);
          }
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_h[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_h[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1004 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658983419,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1004 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_e[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_e[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1004 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658983431,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1004 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_j[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_j[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1004 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDODownload(658983441,1*(uint32_T)4,(uint32_T)
              deviceIndex);
            printf("SDO Download. Register device %d, slave addr: %d\n",
                   deviceIndex, 1004);
          }
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_ai[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_ai[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1003 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(35471299,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1003 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_ho[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_ho[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1004 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658985869,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1004 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_h[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_h[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1003 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDODownload(658983537,1*(uint32_T)4,(uint32_T)
              deviceIndex);
            printf("SDO Download. Register device %d, slave addr: %d\n",
                   deviceIndex, 1003);
          }
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDODownload_IWORK[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1003 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(35091299,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1003 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK[7] = 0;
      }
    }

    {
      if (1 == g_firstInitBlockToRunPlusOne - 1 ) {
        switch ((may23_P.activation_Value[0])) {
         case MC_TYPE_SIMULATION:
          {
            printf("Simulation mode requested and enabled.\n");
            break;
          }

         case MC_TYPE_PMAC:
          {
            if (may23_B.BKINEtherCATinit1_o3 == MC_TYPE_PMAC)
              printf("PMAC mode requested and enabled");
            else
              printf("PMAC mode requested, but not enabled.");
            break;
          }

         case MC_TYPE_ETHERCAT:
          {
            if (g_deviceIndex == NO_ETHERCAT && (may23_P.activation_Value[1]) <
                MAX_NUMBER_ECAT_NETWORK_DEVICES)
              printf("The EtherCAT Network device ( = %d) requested is not specified in the code.\n",
                     (may23_P.activation_Value[1]));
            break;
          }

         default:
          printf("Unknown Motion Control type ( = %d) requested.\n",
                 (may23_P.activation_Value[0]));
        }
      }
    }

    {
      if (0 == g_firstInitBlockToRunPlusOne - 1 ) {
        switch ((may23_P.activation_Value[0])) {
         case MC_TYPE_SIMULATION:
          {
            printf("Simulation mode requested and enabled.\n");
            break;
          }

         case MC_TYPE_PMAC:
          {
            if (may23_B.BKINEtherCATinit_o3 == MC_TYPE_PMAC)
              printf("PMAC mode requested and enabled");
            else
              printf("PMAC mode requested, but not enabled.");
            break;
          }

         case MC_TYPE_ETHERCAT:
          {
            if (g_deviceIndex == NO_ETHERCAT && (may23_P.activation_Value[1]) <
                MAX_NUMBER_ECAT_NETWORK_DEVICES)
              printf("The EtherCAT Network device ( = %d) requested is not specified in the code.\n",
                     (may23_P.activation_Value[1]));
            break;
          }

         default:
          printf("Unknown Motion Control type ( = %d) requested.\n",
                 (may23_P.activation_Value[0]));
        }
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1001 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDODownload(658981113,1*(uint32_T)4,(uint32_T)
              deviceIndex);
            printf("SDO Download. Register device %d, slave addr: %d\n",
                   deviceIndex, 1001);
          }
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_f[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_f[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1001 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658981114,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1001 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_j0[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_j0[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1002 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDODownload(658984267,1*(uint32_T)4,(uint32_T)
              deviceIndex);
            printf("SDO Download. Register device %d, slave addr: %d\n",
                   deviceIndex, 1002);
          }
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_p[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_p[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1002 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658984268,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1002 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_lj[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_lj[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1003 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDODownload(658984277,1*(uint32_T)4,(uint32_T)
              deviceIndex);
            printf("SDO Download. Register device %d, slave addr: %d\n",
                   deviceIndex, 1003);
          }
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_a[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_a[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1003 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658984278,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1003 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_g[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_g[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1004 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDODownload(658984287,1*(uint32_T)4,(uint32_T)
              deviceIndex);
            printf("SDO Download. Register device %d, slave addr: %d\n",
                   deviceIndex, 1004);
          }
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_g[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_g[7] = 0;
      }
    }

    {
      int_T deviceIndex;
      int_T i;
      int_T slaveIsInSlaveAddressList;
      deviceIndex = g_deviceIndex;
      if (!xpcIsModelInit()) {
        if (deviceIndex != NO_ETHERCAT) {
          slaveIsInSlaveAddressList = 0;// default value
          for (i = 0; i < MAX_NUMBER_ECAT_SLAVES; i++) {
            if (1004 == g_ecatSlaveAddressList[deviceIndex][i])
              slaveIsInSlaveAddressList = 1;
          }

          if (slaveIsInSlaveAddressList == 0) {
            deviceIndex = NO_ETHERCAT;
          } else {
            registerAsyncSDOUpload(658984288,1*(uint32_T)4,(uint32_T)deviceIndex);
            printf("SDO Upload. Register device %d, slave addr: %d\n",
                   deviceIndex, 1004 );
          }
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK[0] = deviceIndex;
        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK[7] = 0;
      }
    }
  }

  may23_PrevZCX.SendControlMachine_Trig_ZCE[0] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.SendControlMachine_Trig_ZCE[1] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.SendControlMachine_Trig_ZCE[2] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.torque_monitor_Trig_ZCE = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.TaskExecutionControlMachine_Trig_ZCE[0] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.TaskExecutionControlMachine_Trig_ZCE[1] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.Ramp_up_down_Trig_ZCE[0] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.Ramp_up_down_Trig_ZCE[1] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.Ramp_up_down_Trig_ZCE[2] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.Trial_Control_Trig_ZCE[0] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.Trial_Control_Trig_ZCE[1] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.Trial_Control_Trig_ZCE[2] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.Trial_Control_Trig_ZCE[3] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.CollisionResolution_Trig_ZCE[0] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.CollisionResolution_Trig_ZCE[1] = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.sf_Ramp_Up_Down1_h.Ramp_Up_Down_Trig_ZCE = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.sf_Ramp_Up_Down_g.Ramp_Up_Down_Trig_ZCE = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.sf_Ramp_Up_Down1.Ramp_Up_Down_Trig_ZCE_e = UNINITIALIZED_ZCSIG;
  may23_PrevZCX.sf_Ramp_Up_Down.Ramp_Up_Down_Trig_ZCE_e = UNINITIALIZED_ZCSIG;

  {
    int32_T i;

    /* Machine initializer */
    col_x = 1.0;
    col_y = 2.0;
    SECONDS = 1.0;
    E_NO_EVENT = 0.0;
    WIDTH = 3.0;
    HEIGHT = 6.0;
    ROTATION = 7.0;
    FORCE_MULTIPLIER = 1.0;
    LOAD_ROW = 4.0;
    F_BUMP = 1.0;
    MASS_CIRCLE = 2.0;
    MASS_RECT = 3.0;
    PERT_RAMP = 4.0;
    PERT_DUR = 5.0;
    START_ROW = 6.0;
    GOAL_ROW = 8.0;
    RADIUS_LOG = 4.0;
    RADIUS_VIS = 5.0;
    BARRIER_ROW = 5.0;
    PRESHOT_ROW = 7.0;
    START_HOLD_TIME = 9.0;
    SHOT_READY_TIME = 10.0;
    SHOT_SET_TIME = 11.0;
    GOAL_TIME = 13.0;
    FIRST_FILL = 8.0;
    SECOND_FILL = 9.0;
    THIRD_FILL = 10.0;
    PUCK_ROW = 3.0;
    CURSOR_ROW = 2.0;
    E_START_TARGET_ON = 1.0;
    E_ENTER_START = 2.0;
    E_TRIAL_START = 3.0;
    E_BEGIN_PRESHOT = 4.0;
    E_SHOT_READY = 5.0;
    E_SHOT_GO = 6.0;
    E_PUCK_IN_GOAL = 7.0;
    E_HAND_IN_BARRIER = 9.0;
    E_PUCK_IN_BARRIER = 10.0;
    E_SUCCESS = 8.0;
    E_FAILURE = 13.0;
    E_TIMEOUT = 14.0;
    STROKE_COLOR = 11.0;
    STROKE_WIDTH = 12.0;
    PUCK_DAMPING = 14.0;
    E_PUCK_MISS = 11.0;
    SHOT_TIME = 12.0;

    /* InitializeConditions for UnitDelay: '<S347>/Delay Input1' */
    may23_DW.DelayInput1_DSTATE_c = may23_P.DetectChange_vinit_m;

    /* InitializeConditions for Memory: '<S336>/Delay1' */
    may23_DW.Delay1_PreviousInput = may23_P.Delay1_InitialCondition;

    /* InitializeConditions for UnitDelay: '<S350>/Output' */
    may23_DW.Output_DSTATE = may23_P.Output_InitialCondition_a;

    /* InitializeConditions for Memory: '<S3>/Memory' */
    may23_DW.Memory_PreviousInput = may23_P.Memory_InitialCondition_m;

    /* InitializeConditions for Memory: '<S336>/Delay' */
    may23_DW.Delay_PreviousInput = may23_P.Delay_InitialCondition_g;

    /* InitializeConditions for UnitDelay: '<S348>/Delay Input1' */
    may23_DW.DelayInput1_DSTATE_a = may23_P.DetectChange1_vinit;

    /* InitializeConditions for Memory: '<S1>/Memory' */
    may23_DW.Memory_PreviousInput_m[0] = may23_P.Memory_InitialCondition_pk;
    may23_DW.Memory_PreviousInput_m[1] = may23_P.Memory_InitialCondition_pk;
    may23_DW.Memory_PreviousInput_m[2] = may23_P.Memory_InitialCondition_pk;
    may23_DW.Memory_PreviousInput_m[3] = may23_P.Memory_InitialCondition_pk;

    /* InitializeConditions for Memory: '<S9>/Memory' */
    may23_DW.Memory_PreviousInput_f = may23_P.Memory_InitialCondition_i;

    /* InitializeConditions for Memory: '<S38>/Memory2' */
    may23_DW.Memory2_PreviousInput = may23_P.Memory2_InitialCondition_d;

    /* InitializeConditions for Memory: '<Root>/Memory2' */
    for (i = 0; i < 70; i++) {
      may23_DW.Memory2_PreviousInput_c[i] = may23_P.Memory2_InitialCondition_o;
    }

    /* End of InitializeConditions for Memory: '<Root>/Memory2' */

    /* InitializeConditions for Memory: '<Root>/Memory1' */
    may23_DW.Memory1_PreviousInput_lw = may23_P.Memory1_InitialCondition_k;

    /* InitializeConditions for Memory: '<Root>/Memory4' */
    may23_DW.Memory4_PreviousInput = may23_P.Memory4_InitialCondition;

    /* InitializeConditions for RateTransition generated from: '<S335>/Hold_to_1Khz' */
    may23_DW.TmpRTBAtHold_to_1KhzInport2_Buffer0 =
      may23_P.TmpRTBAtHold_to_1KhzInport2_InitialCondition;

    /* InitializeConditions for RateTransition: '<S23>/Rate Transition2' */
    may23_DW.RateTransition2_Buffer0 =
      may23_P.RateTransition2_InitialCondition_l;

    /* InitializeConditions for RateTransition generated from: '<S26>/Timestamp' */
    may23_DW.TmpRTBAtTimestampOutport1_Buffer0 =
      may23_P.TmpRTBAtTimestampOutport1_InitialCondition;

    /* InitializeConditions for Delay: '<S34>/Delay' */
    may23_DW.Delay_DSTATE[0] = may23_P.Delay_InitialCondition;
    may23_DW.Delay_DSTATE[1] = may23_P.Delay_InitialCondition;
    may23_DW.Delay_DSTATE[2] = may23_P.Delay_InitialCondition;
    may23_DW.Delay_DSTATE[3] = may23_P.Delay_InitialCondition;

    /* InitializeConditions for Delay: '<S327>/Delay' */
    for (i = 0; i < 24; i++) {
      may23_DW.Delay_DSTATE_e[i] = may23_P.Delay_InitialCondition_p;
    }

    /* End of InitializeConditions for Delay: '<S327>/Delay' */

    /* InitializeConditions for Memory: '<S38>/Memory1' */
    may23_DW.Memory1_PreviousInput = may23_P.Memory1_InitialCondition_b;

    /* InitializeConditions for Memory: '<S1>/Memory1' */
    may23_DW.Memory1_PreviousInput_l = may23_P.Memory1_InitialCondition_n;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_1_PreviousInput = may23_P.Memory2_1_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_2_PreviousInput = may23_P.Memory2_2_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_3_PreviousInput = may23_P.Memory2_3_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_4_PreviousInput = may23_P.Memory2_4_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_5_PreviousInput = may23_P.Memory2_5_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_9_PreviousInput = may23_P.Memory2_9_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_18_PreviousInput = may23_P.Memory2_18_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_19_PreviousInput = may23_P.Memory2_19_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_20_PreviousInput = may23_P.Memory2_20_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_21_PreviousInput = may23_P.Memory2_21_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_22_PreviousInput = may23_P.Memory2_22_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_26_PreviousInput = may23_P.Memory2_26_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_10_PreviousInput = may23_P.Memory2_10_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_11_PreviousInput = may23_P.Memory2_11_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_12_PreviousInput = may23_P.Memory2_12_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_13_PreviousInput = may23_P.Memory2_13_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_14_PreviousInput = may23_P.Memory2_14_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_15_PreviousInput = may23_P.Memory2_15_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_16_PreviousInput = may23_P.Memory2_16_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_17_PreviousInput = may23_P.Memory2_17_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_23_PreviousInput = may23_P.Memory2_23_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_24_PreviousInput = may23_P.Memory2_24_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_25_PreviousInput = may23_P.Memory2_25_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_27_PreviousInput = may23_P.Memory2_27_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_28_PreviousInput = may23_P.Memory2_28_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_29_PreviousInput = may23_P.Memory2_29_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_30_PreviousInput = may23_P.Memory2_30_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_31_PreviousInput = may23_P.Memory2_31_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_32_PreviousInput = may23_P.Memory2_32_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_33_PreviousInput = may23_P.Memory2_33_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_34_PreviousInput = may23_P.Memory2_34_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_6_PreviousInput = may23_P.Memory2_6_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_7_PreviousInput = may23_P.Memory2_7_InitialCondition;

    /* InitializeConditions for Memory generated from: '<S1>/Memory2' */
    may23_DW.Memory2_8_PreviousInput = may23_P.Memory2_8_InitialCondition;

    /* InitializeConditions for Delay: '<S38>/Delay' */
    may23_DW.Delay_DSTATE_m[0] = may23_P.Delay_InitialCondition_c;

    /* InitializeConditions for Memory: '<S19>/Memory3' */
    may23_DW.Memory3_PreviousInput[0] = may23_P.Memory3_InitialCondition_c;

    /* InitializeConditions for Memory: '<S329>/Memory1' */
    may23_DW.Memory1_PreviousInput_k[0] = may23_P.Memory1_InitialCondition_m;

    /* InitializeConditions for Delay: '<S38>/Delay' */
    may23_DW.Delay_DSTATE_m[1] = may23_P.Delay_InitialCondition_c;

    /* InitializeConditions for Memory: '<S19>/Memory3' */
    may23_DW.Memory3_PreviousInput[1] = may23_P.Memory3_InitialCondition_c;

    /* InitializeConditions for Memory: '<S329>/Memory1' */
    may23_DW.Memory1_PreviousInput_k[1] = may23_P.Memory1_InitialCondition_m;

    /* InitializeConditions for Delay: '<S38>/Delay' */
    may23_DW.Delay_DSTATE_m[2] = may23_P.Delay_InitialCondition_c;

    /* InitializeConditions for Memory: '<S19>/Memory3' */
    may23_DW.Memory3_PreviousInput[2] = may23_P.Memory3_InitialCondition_c;

    /* InitializeConditions for Memory: '<S329>/Memory1' */
    may23_DW.Memory1_PreviousInput_k[2] = may23_P.Memory1_InitialCondition_m;

    /* InitializeConditions for Delay: '<S38>/Delay' */
    may23_DW.Delay_DSTATE_m[3] = may23_P.Delay_InitialCondition_c;

    /* InitializeConditions for Memory: '<S19>/Memory3' */
    may23_DW.Memory3_PreviousInput[3] = may23_P.Memory3_InitialCondition_c;

    /* InitializeConditions for Memory: '<S329>/Memory1' */
    may23_DW.Memory1_PreviousInput_k[3] = may23_P.Memory1_InitialCondition_m;

    /* InitializeConditions for UnitDelay: '<S46>/Output' */
    may23_DW.Output_DSTATE_d = may23_P.Output_InitialCondition_k;

    /* SystemInitialize for MATLAB Function: '<S335>/Embedded MATLAB Function' */
    may23_DW.u = 0.0;
    may23_DW.v = 0.0;

    /* SystemInitialize for MATLAB Function: '<S335>/Hold_to_1Khz' */
    for (i = 0; i < 8; i++) {
      may23_DW.held_value[i] = 0.0;
    }

    may23_DW.last_sim = 0.0;

    /* End of SystemInitialize for MATLAB Function: '<S335>/Hold_to_1Khz' */

    /* SystemInitialize for Enabled SubSystem: '<S340>/enable_tables' */
    /* SystemInitialize for Outport: '<S351>/block_defs' */
    memcpy(&may23_B.BlockDefinitions[0], &may23_P.block_defs_Y0[0], 25000U *
           sizeof(real_T));

    /* SystemInitialize for Outport: '<S351>/block_seq' */
    memcpy(&may23_B.BlockSequence[0], &may23_P.block_seq_Y0[0], 3000U * sizeof
           (real_T));

    /* SystemInitialize for Outport: '<S351>/tp_table' */
    memcpy(&may23_B.TPTable[0], &may23_P.tp_table_Y0[0], 5000U * sizeof(real_T));

    /* SystemInitialize for Outport: '<S351>/labels' */
    memcpy(&may23_B.TargetLabels[0], &may23_P.labels_Y0[0], 3200U * sizeof
           (real_T));

    /* SystemInitialize for Outport: '<S351>/targets' */
    memcpy(&may23_B.TargetTable[0], &may23_P.targets_Y0[0], 1600U * sizeof
           (real_T));

    /* SystemInitialize for Outport: '<S351>/loads' */
    memcpy(&may23_B.LoadTable[0], &may23_P.loads_Y0[0], 400U * sizeof(real_T));

    /* SystemInitialize for Outport: '<S351>/twp' */
    memcpy(&may23_B.Taskwideparam[0], &may23_P.twp_Y0[0], 50U * sizeof(real_T));

    /* End of SystemInitialize for SubSystem: '<S340>/enable_tables' */

    /* SystemInitialize for Chart: '<S336>/Task Execution Control Machine' */
    may23_DW.is_InTrial = may23_IN_NO_ACTIVE_CHILD_l;
    may23_DW.is_InTrial1 = may23_IN_NO_ACTIVE_CHILD_l;
    may23_DW.temporalCounter_i1_h = 0U;
    may23_DW.is_active_c42_General = 0U;
    may23_DW.is_c42_General = may23_IN_NO_ACTIVE_CHILD_l;
    for (i = 0; i < 499; i++) {
      may23_DW.trial_queue[i] = 0.0;
      may23_DW.repeat_list[i] = 0.0;
    }

    may23_DW.repeat_list_length = 0U;
    may23_DW.i = 1U;
    may23_DW.swap_index = 0U;
    may23_DW.temp = 0U;
    may23_DW.trial_queue_length = 499U;
    may23_DW.trial_in_mini_block = 0U;
    may23_DW.EXAM = 1.0;
    may23_DW.BLOCK = 2.0;
    may23_DW.block = 0.0;
    may23_B.task_status = 0U;
    may23_B.tp = 0U;
    may23_B.block_idx = 0U;
    may23_B.trial_in_block = 0U;
    may23_B.block_in_set = 0U;
    may23_B.trial_in_set = 0U;
    may23_B.repeat_last_trial = 0.0;
    may23_B.extra_trials[0] = 0.0;
    may23_B.extra_trials[1] = 0.0;
    may23_DW.e_exit_trialEventCounter = 0U;
    may23_B.e_exit_trial = false;

    /* End of SystemInitialize for Chart: '<S336>/Task Execution Control Machine' */

    /* SystemInitialize for MATLAB Function: '<S337>/MATLAB Function' */
    may23_DW.trials_per_block_not_empty = false;

    /* SystemInitialize for Atomic SubSystem: '<S1>/Network Transfer Subsystem' */
    may23_NetworkTransferSubsystem_Init();

    /* End of SystemInitialize for SubSystem: '<S1>/Network Transfer Subsystem' */

    /* SystemInitialize for Atomic SubSystem: '<S1>/apply loads' */
    may23_applyloads_Init();

    /* End of SystemInitialize for SubSystem: '<S1>/apply loads' */

    /* SystemInitialize for Atomic SubSystem: '<S1>/Poll KINARM' */
    may23_PollKINARM_Init();

    /* End of SystemInitialize for SubSystem: '<S1>/Poll KINARM' */

    /* SystemInitialize for Atomic SubSystem: '<S1>/Receive_Gaze' */
    may23_Receive_Gaze_Init();

    /* End of SystemInitialize for SubSystem: '<S1>/Receive_Gaze' */

    /* SystemInitialize for MATLAB Function: '<S327>/filter' */
    for (i = 0; i < 12; i++) {
      may23_DW.rawVelocities_a[i] = 0.0;
      may23_DW.filtVelocities_l[i] = 0.0;
    }

    /* End of SystemInitialize for MATLAB Function: '<S327>/filter' */

    /* SystemInitialize for MATLAB Function: '<S38>/filter' */
    for (i = 0; i < 24; i++) {
      may23_DW.rawVelocities[i] = 0.0;
      may23_DW.filtVelocities[i] = 0.0;
    }

    /* End of SystemInitialize for MATLAB Function: '<S38>/filter' */

    /* SystemInitialize for Chart: '<S329>/monitor_encoders' */
    may23_DW.sfEvent_n = -1;
    may23_DW.is_active_c79_General = 0U;
    may23_DW.is_c79_General = may23_IN_NO_ACTIVE_CHILD_l;

    /* SystemInitialize for Chart: '<S38>/torque_monitor' */
    may23_DW.is_active_Robot1 = 0U;
    may23_DW.is_Robot1 = may23_IN_NO_ACTIVE_CHILD_l;
    may23_DW.is_active_Robot2 = 0U;
    may23_DW.is_Robot2 = may23_IN_NO_ACTIVE_CHILD_l;
    may23_DW.temporalCounter_i2 = 0U;
    may23_DW.temporalCounter_i1_c = 0U;
    may23_DW.is_active_c108_General = 0U;
    may23_DW.is_c108_General = may23_IN_NO_ACTIVE_CHILD_l;
    may23_B.command_multiplier = 0.0;
    may23_B.stop_vel_mode = 0.0;
    may23_B.robot_err_bits_out = 0.0;

    /* SystemInitialize for Chart: '<S4>/Ramp_Up_Down' */
    may23_Ramp_Up_Down_Init(&may23_B.sf_Ramp_Up_Down, &may23_DW.sf_Ramp_Up_Down);

    /* SystemInitialize for Chart: '<S4>/Ramp_Up_Down1' */
    may23_Ramp_Up_Down_Init(&may23_B.sf_Ramp_Up_Down1,
      &may23_DW.sf_Ramp_Up_Down1);

    /* SystemInitialize for Chart: '<S5>/Ramp_Up_Down' */
    may23_Ramp_Up_Down_l_Init(&may23_B.sf_Ramp_Up_Down_g,
      &may23_DW.sf_Ramp_Up_Down_g);

    /* SystemInitialize for Chart: '<S5>/Ramp_Up_Down1' */
    may23_Ramp_Up_Down_l_Init(&may23_B.sf_Ramp_Up_Down1_h,
      &may23_DW.sf_Ramp_Up_Down1_h);

    /* SystemInitialize for Atomic SubSystem: '<S9>/PVC_core' */
    may23_PVC_core_Init();

    /* End of SystemInitialize for SubSystem: '<S9>/PVC_core' */

    /* SystemInitialize for MATLAB Function: '<S9>/MATLAB Function' */
    may23_DW.last_valid_frame_ack = 0.0;
    may23_DW.last_perm_frame_ack = 0.0;

    /* SystemInitialize for Chart: '<S396>/Ramp_up_down' */
    may23_DW.is_Perturbation = may23_IN_NO_ACTIVE_CHILD_l;
    may23_DW.temporalCounter_i1_n = 0U;
    may23_DW.is_active_c8_may23 = 0U;
    may23_DW.is_c8_may23 = may23_IN_NO_ACTIVE_CHILD_l;
    may23_DW.tick = 0.0;
    may23_B.scaling = 0.0;

    /* SystemInitialize for Chart: '<Root>/Trial_Control' */
    may23_DW.is_Main_Trial = may23_IN_NO_ACTIVE_CHILD_l;
    may23_DW.temporalCounter_i1 = 0U;
    may23_DW.is_active_c3_may23 = 0U;
    may23_DW.is_c3_may23 = may23_IN_NO_ACTIVE_CHILD_l;
    may23_DW.e_Trial_StartEventCounter = 0U;
    may23_B.e_Trial_Start = false;
    may23_DW.e_Trial_EndEventCounter = 0U;
    may23_B.e_Trial_End = false;
    may23_DW.presentTicks = 0U;
    may23_DW.elapsedTicks = 0U;
    may23_DW.previousTicks = 0U;

    /* SystemInitialize for Chart: '<S21>/Collision Resolution' */
    may23_DW.is_active_CollisionWithHand = 0U;
    may23_DW.is_CollisionWithHand = may23_IN_NO_ACTIVE_CHILD_l;
    may23_DW.is_active_UpdatePosition = 0U;
    may23_DW.is_active_UpdateVelocity = 0U;
    may23_DW.is_active_c1_may23 = 0U;
    may23_DW.is_c1_may23 = may23_IN_NO_ACTIVE_CHILD_l;
    may23_DW.e_Puck_StoppedEventCounter = 0U;
    may23_B.e_Puck_Stopped = false;
    may23_DW.e_Puck_HitEventCounter = 0U;
    may23_B.e_Puck_Hit = false;
  }

  /* Enable for Atomic SubSystem: '<S1>/Poll KINARM' */
  may23_PollKINARM_Enable();

  /* End of Enable for SubSystem: '<S1>/Poll KINARM' */

  /* Enable for Chart: '<Root>/Trial_Control' */
  may23_DW.presentTicks = may23_M->Timing.clockTick1;
  may23_DW.previousTicks = may23_DW.presentTicks;
}

/* Model terminate function */
static void may23_terminate(void)
{
  /* Terminate for S-Function (ich10): '<S3>/ICH7' */
  /* Level2 S-Function Block: '<S3>/ICH7' (ich10) */
  {
    SimStruct *rts = may23_M->childSfunctions[40];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (slrtUDPReceive): '<S335>/Run Command Receive' */
  /* Level2 S-Function Block: '<S335>/Run Command Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[41];
    sfcnTerminate(rts);
  }

  /* Terminate for Atomic SubSystem: '<S1>/Receive_Gaze' */
  may23_Receive_Gaze_Term();

  /* End of Terminate for SubSystem: '<S1>/Receive_Gaze' */

  /* Terminate for Atomic SubSystem: '<S1>/Poll KINARM' */
  may23_PollKINARM_Term();

  /* End of Terminate for SubSystem: '<S1>/Poll KINARM' */

  /* Terminate for Atomic SubSystem: '<S1>/Poll Force Plates' */
  may23_PollForcePlates_Term();

  /* End of Terminate for SubSystem: '<S1>/Poll Force Plates' */

  /* Terminate for S-Function (slrtUDPReceive): '<S9>/Receive' */
  /* Level2 S-Function Block: '<S9>/Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[42];
    sfcnTerminate(rts);
  }

  /* Terminate for Atomic SubSystem: '<S1>/Network Transfer Subsystem' */
  may23_NetworkTransferSubsystem_Term();

  /* End of Terminate for SubSystem: '<S1>/Network Transfer Subsystem' */

  /* Terminate for Atomic SubSystem: '<S1>/apply loads' */
  may23_applyloads_Term();

  /* End of Terminate for SubSystem: '<S1>/apply loads' */

  /* Terminate for S-Function (slrtUDPSend): '<S9>/Send' */
  /* Level2 S-Function Block: '<S9>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[43];
    sfcnTerminate(rts);
  }

  /* Terminate for Atomic SubSystem: '<S1>/Keep alive' */
  may23_Keepalive_Term();

  /* End of Terminate for SubSystem: '<S1>/Keep alive' */

  /* user code (Terminate function Trailer) */

  /*------------ S-Function Block: <S66>/BKIN EtherCATinit1 Process Shutdown Network ------------*/
  {
    int_T status;
    if (g_firstInitBlockToRunPlusOne == 1 + 1) {
      releaseNIC( (may23_P.PCIBusSlot_Value[0]), (may23_P.PCIBusSlot_Value[1]),
                 0 );
    }

    if (!xpcIsModelInit()) {
      status = xpcEtherCATstop(1, 1000 /* 1 second timeout */
        );
    }
  }

  /*------------ S-Function Block: <S66>/BKIN EtherCATinit Process Shutdown Network ------------*/
  {
    int_T status;
    if (g_firstInitBlockToRunPlusOne == 0 + 1) {
      releaseNIC( (may23_P.PCIBusSlot_Value[0]), (may23_P.PCIBusSlot_Value[1]),
                 0 );
    }

    if (!xpcIsModelInit()) {
      status = xpcEtherCATstop(0, 1000 /* 1 second timeout */
        );
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  if (tid == 1)
    tid = 0;
  may23_output(tid);
}

void MdlUpdate(int_T tid)
{
  if (tid == 1)
    tid = 0;
  may23_update(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  may23_initialize();
}

void MdlTerminate(void)
{
  may23_terminate();
}

/* Registration function */
RT_MODEL_may23_T *may23(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)may23_M, 0,
                sizeof(RT_MODEL_may23_T));

  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&may23_M->solverInfo, &may23_M->Timing.simTimeStep);
    rtsiSetTPtr(&may23_M->solverInfo, &rtmGetTPtr(may23_M));
    rtsiSetStepSizePtr(&may23_M->solverInfo, &may23_M->Timing.stepSize0);
    rtsiSetErrorStatusPtr(&may23_M->solverInfo, (&rtmGetErrorStatus(may23_M)));
    rtsiSetRTModelPtr(&may23_M->solverInfo, may23_M);
  }

  rtsiSetSimTimeStep(&may23_M->solverInfo, MAJOR_TIME_STEP);
  rtsiSetSolverName(&may23_M->solverInfo,"FixedStepDiscrete");
  may23_M->solverInfoPtr = (&may23_M->solverInfo);

  /* Initialize timing info */
  {
    int_T *mdlTsMap = may23_M->Timing.sampleTimeTaskIDArray;
    int_T i;
    for (i = 0; i < 5; i++) {
      mdlTsMap[i] = i;
    }

    may23_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    may23_M->Timing.sampleTimes = (&may23_M->Timing.sampleTimesArray[0]);
    may23_M->Timing.offsetTimes = (&may23_M->Timing.offsetTimesArray[0]);

    /* task periods */
    may23_M->Timing.sampleTimes[0] = (0.0);
    may23_M->Timing.sampleTimes[1] = (0.00025);
    may23_M->Timing.sampleTimes[2] = (0.0005);
    may23_M->Timing.sampleTimes[3] = (0.001);
    may23_M->Timing.sampleTimes[4] = (0.1);

    /* task offsets */
    may23_M->Timing.offsetTimes[0] = (0.0);
    may23_M->Timing.offsetTimes[1] = (0.0);
    may23_M->Timing.offsetTimes[2] = (0.0);
    may23_M->Timing.offsetTimes[3] = (0.0);
    may23_M->Timing.offsetTimes[4] = (0.0);
  }

  rtmSetTPtr(may23_M, &may23_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits = may23_M->Timing.sampleHitArray;
    int_T *mdlPerTaskSampleHits = may23_M->Timing.perTaskSampleHitsArray;
    may23_M->Timing.perTaskSampleHits = (&mdlPerTaskSampleHits[0]);
    mdlSampleHits[0] = 1;
    may23_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(may23_M, -1);
  may23_M->Timing.stepSize0 = 0.00025;
  may23_M->Timing.stepSize1 = 0.00025;
  may23_M->Timing.stepSize2 = 0.0005;
  may23_M->Timing.stepSize3 = 0.001;
  may23_M->Timing.stepSize4 = 0.1;

  /* Setup for data logging */
  {
    static RTWLogInfo rt_DataLoggingInfo;
    rt_DataLoggingInfo.loggingInterval = NULL;
    may23_M->rtwLogInfo = &rt_DataLoggingInfo;
  }

  /* Setup for data logging */
  {
    rtliSetLogXSignalInfo(may23_M->rtwLogInfo, (NULL));
    rtliSetLogXSignalPtrs(may23_M->rtwLogInfo, (NULL));
    rtliSetLogT(may23_M->rtwLogInfo, "");
    rtliSetLogX(may23_M->rtwLogInfo, "");
    rtliSetLogXFinal(may23_M->rtwLogInfo, "");
    rtliSetLogVarNameModifier(may23_M->rtwLogInfo, "rt_");
    rtliSetLogFormat(may23_M->rtwLogInfo, 0);
    rtliSetLogMaxRows(may23_M->rtwLogInfo, 0);
    rtliSetLogDecimation(may23_M->rtwLogInfo, 1);
    rtliSetLogY(may23_M->rtwLogInfo, "");
    rtliSetLogYSignalInfo(may23_M->rtwLogInfo, (NULL));
    rtliSetLogYSignalPtrs(may23_M->rtwLogInfo, (NULL));
  }

  may23_M->solverInfoPtr = (&may23_M->solverInfo);
  may23_M->Timing.stepSize = (0.00025);
  rtsiSetFixedStepSize(&may23_M->solverInfo, 0.00025);
  rtsiSetSolverMode(&may23_M->solverInfo, SOLVER_MODE_MULTITASKING);

  /* block I/O */
  may23_M->blockIO = ((void *) &may23_B);
  (void) memset(((void *) &may23_B), 0,
                sizeof(B_may23_T));

  {
    int32_T i;
    for (i = 0; i < 50; i++) {
      may23_B.TPSelector[i] = 0.0;
    }

    for (i = 0; i < 64; i++) {
      may23_B.ArraySelector[i] = 0.0;
    }

    for (i = 0; i < 64; i++) {
      may23_B.ArraySelector_b[i] = 0.0;
    }

    for (i = 0; i < 70; i++) {
      may23_B.Memory2_c[i] = 0.0;
    }

    for (i = 0; i < 64; i++) {
      may23_B.ArraySelector_m[i] = 0.0;
    }

    for (i = 0; i < 64; i++) {
      may23_B.ArraySelector_c[i] = 0.0;
    }

    for (i = 0; i < 500; i++) {
      may23_B.Selector1[i] = 0.0;
    }

    for (i = 0; i < 1000; i++) {
      may23_B.Selector2[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.Convert11[i] = 0.0;
    }

    for (i = 0; i < 25; i++) {
      may23_B.Selector_p[i] = 0.0;
    }

    for (i = 0; i < 55; i++) {
      may23_B.MatrixConcatenation1[i] = 0.0;
    }

    for (i = 0; i < 70; i++) {
      may23_B.Reshape[i] = 0.0;
    }

    for (i = 0; i < 70; i++) {
      may23_B.Reshape1[i] = 0.0;
    }

    for (i = 0; i < 140; i++) {
      may23_B.MatrixConcatenation[i] = 0.0;
    }

    for (i = 0; i < 25; i++) {
      may23_B.Selector_gx[i] = 0.0;
    }

    for (i = 0; i < 55; i++) {
      may23_B.MatrixConcatenation1_a[i] = 0.0;
    }

    for (i = 0; i < 25; i++) {
      may23_B.Selector_c[i] = 0.0;
    }

    for (i = 0; i < 55; i++) {
      may23_B.MatrixConcatenation1_g[i] = 0.0;
    }

    for (i = 0; i < 71; i++) {
      may23_B.AnalogDataWidth[i] = 0.0;
    }

    for (i = 0; i < 14; i++) {
      may23_B.DataStoreRead[i] = 0.0;
    }

    for (i = 0; i < 400; i++) {
      may23_B.DataTypeConversion_bl[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.DataStoreRead1[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.DataStoreRead1_l[i] = 0.0;
    }

    for (i = 0; i < 8; i++) {
      may23_B.readstatus[i] = 0.0;
    }

    for (i = 0; i < 25; i++) {
      may23_B.Selector_f[i] = 0.0;
    }

    for (i = 0; i < 55; i++) {
      may23_B.MatrixConcatenation1_e[i] = 0.0;
    }

    for (i = 0; i < 25; i++) {
      may23_B.Selector_i[i] = 0.0;
    }

    for (i = 0; i < 55; i++) {
      may23_B.MatrixConcatenation1_k[i] = 0.0;
    }

    for (i = 0; i < 25; i++) {
      may23_B.Selector_d[i] = 0.0;
    }

    for (i = 0; i < 55; i++) {
      may23_B.MatrixConcatenation1_b[i] = 0.0;
    }

    for (i = 0; i < 490; i++) {
      may23_B.MatrixConcatenate[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.binary_files[i] = 0.0;
    }

    for (i = 0; i < 71; i++) {
      may23_B.RateTransition_e[i] = 0.0;
    }

    for (i = 0; i < 490; i++) {
      may23_B.RateTransition2_p[i] = 0.0;
    }

    for (i = 0; i < 1120; i++) {
      may23_B.MatrixConcatenate_d[i] = 0.0;
    }

    for (i = 0; i < 72; i++) {
      may23_B.RateTransition_k[i] = 0.0;
    }

    for (i = 0; i < 16; i++) {
      may23_B.RateTransition1_a[i] = 0.0;
    }

    for (i = 0; i < 20; i++) {
      may23_B.RateTransition_p[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.SFunctionBuilder_o3[i] = 0.0;
    }

    for (i = 0; i < 140; i++) {
      may23_B.hand_vcodes[i] = 0.0;
    }

    for (i = 0; i < 140; i++) {
      may23_B.VCODES_out[i] = 0.0;
    }

    for (i = 0; i < 70; i++) {
      may23_B.puck_vcode_output[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.TmpSignalConversionAtSFunctionInport3[i] = 0.0;
    }

    for (i = 0; i < 320; i++) {
      may23_B.intarget[i] = 0.0;
    }

    for (i = 0; i < 15; i++) {
      may23_B.TmpSignalConversionAtSFunctionInport3_b[i] = 0.0;
    }

    for (i = 0; i < 320; i++) {
      may23_B.intarget_g[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.TmpSignalConversionAtSFunctionInport3_n[i] = 0.0;
    }

    for (i = 0; i < 320; i++) {
      may23_B.intarget_d[i] = 0.0;
    }

    for (i = 0; i < 15; i++) {
      may23_B.TmpSignalConversionAtSFunctionInport3_f[i] = 0.0;
    }

    for (i = 0; i < 320; i++) {
      may23_B.intarget_j[i] = 0.0;
    }

    for (i = 0; i < 25000; i++) {
      may23_B.BlockDefinitions[i] = 0.0;
    }

    for (i = 0; i < 3000; i++) {
      may23_B.BlockSequence[i] = 0.0;
    }

    for (i = 0; i < 5000; i++) {
      may23_B.TPTable[i] = 0.0;
    }

    for (i = 0; i < 3200; i++) {
      may23_B.TargetLabels[i] = 0.0;
    }

    for (i = 0; i < 1600; i++) {
      may23_B.TargetTable[i] = 0.0;
    }

    for (i = 0; i < 400; i++) {
      may23_B.LoadTable[i] = 0.0;
    }

    for (i = 0; i < 50; i++) {
      may23_B.Taskwideparam[i] = 0.0;
    }

    for (i = 0; i < 8; i++) {
      may23_B.TmpSignalConversionAtSFunctionInport1[i] = 0.0;
    }

    for (i = 0; i < 8; i++) {
      may23_B.filteredVals[i] = 0.0;
    }

    for (i = 0; i < 14; i++) {
      may23_B.DataStoreRead_h[i] = 0.0;
    }

    for (i = 0; i < 8; i++) {
      may23_B.convert[i] = 0.0;
    }

    for (i = 0; i < 20; i++) {
      may23_B.TmpRTBAtDatawriteInport2[i] = 0.0;
    }

    for (i = 0; i < 12; i++) {
      may23_B.TmpRTBAtDatawriteInport3[i] = 0.0;
    }

    for (i = 0; i < 50; i++) {
      may23_B.Selector_i2[i] = 0.0;
    }

    for (i = 0; i < 50; i++) {
      may23_B.Selector1_b[i] = 0.0;
    }

    for (i = 0; i < 50; i++) {
      may23_B.Selector2_e[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      may23_B.Selector1_e[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      may23_B.Selector2_l[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.Dataready[i] = 0.0;
    }

    for (i = 0; i < 16; i++) {
      may23_B.Read[i] = 0.0;
    }

    for (i = 0; i < 25; i++) {
      may23_B.ReadHW[i] = 0.0;
    }

    for (i = 0; i < 20; i++) {
      may23_B.ReadKinematics[i] = 0.0;
    }

    for (i = 0; i < 12; i++) {
      may23_B.Primaryread[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.torquefeedback1[i] = 0.0;
    }

    for (i = 0; i < 20; i++) {
      may23_B.ErrMsgs[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      may23_B.newMessage[i] = 0.0;
    }

    for (i = 0; i < 7; i++) {
      may23_B.TmpSignalConversionAtSFunctionInport10[i] = 0.0;
    }

    for (i = 0; i < 14; i++) {
      may23_B.TmpSignalConversionAtSFunctionInport12[i] = 0.0;
    }

    for (i = 0; i < 150; i++) {
      may23_B.kinarm_data[i] = 0.0;
    }

    for (i = 0; i < 12; i++) {
      may23_B.primary_encoder_data_out[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.Switch_g[i] = 0.0;
    }

    for (i = 0; i < 16; i++) {
      may23_B.DataStore[i] = 0.0;
    }

    for (i = 0; i < 25; i++) {
      may23_B.DataStore1[i] = 0.0;
    }

    for (i = 0; i < 16; i++) {
      may23_B.calibrationsOut[i] = 0.0;
    }

    for (i = 0; i < 25; i++) {
      may23_B.settingsOut[i] = 0.0;
    }

    for (i = 0; i < 20; i++) {
      may23_B.outMem[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.dataReadyStatus[i] = 0.0;
    }

    for (i = 0; i < 20; i++) {
      may23_B.kinematicsOut[i] = 0.0;
    }

    for (i = 0; i < 12; i++) {
      may23_B.kinematicsOutPrimary[i] = 0.0;
    }

    for (i = 0; i < 20; i++) {
      may23_B.outVals[i] = 0.0;
    }

    for (i = 0; i < 20; i++) {
      may23_B.kinematics[i] = 0.0;
    }

    for (i = 0; i < 12; i++) {
      may23_B.primary[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      may23_B.DataTypeConversion_m[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      may23_B.DataTypeConversion1_i[i] = 0.0;
    }

    for (i = 0; i < 20; i++) {
      may23_B.kinematics_l[i] = 0.0;
    }

    for (i = 0; i < 12; i++) {
      may23_B.primary_o[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      may23_B.Conversion1[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      may23_B.Conversion2[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.DataTypeConversion3_d[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.DataTypeConversion4_m[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.robot1DataOut[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.robot2DataOut[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.robot1DataOut_k[i] = 0.0;
    }

    for (i = 0; i < 10; i++) {
      may23_B.robot2DataOut_i[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      may23_B.robot1PrimaryEncDataOut[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      may23_B.robot2PrimaryEncDataOut[i] = 0.0;
    }

    for (i = 0; i < 7; i++) {
      may23_B.Switch_m[i] = 0.0;
    }

    for (i = 0; i < 7; i++) {
      may23_B.Switch1_g[i] = 0.0;
    }

    for (i = 0; i < 14; i++) {
      may23_B.TmpSignalConversionAtSFunctionInport1_a[i] = 0.0;
    }

    for (i = 0; i < 14; i++) {
      may23_B.measures_out[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      may23_B.DataTypeConversion1_o[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      may23_B.DataTypeConversion_e[i] = 0.0;
    }

    for (i = 0; i < 24; i++) {
      may23_B.intAddresses[i] = 0.0;
    }

    for (i = 0; i < 24; i++) {
      may23_B.floatAddresses[i] = 0.0;
    }

    for (i = 0; i < 12; i++) {
      may23_B.errVals[i] = 0.0;
    }

    for (i = 0; i < 12; i++) {
      may23_B.DCErrVals[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.A2M1Convert[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.A2M2Convert[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.R2M2_EMCY_codes[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.R2M1_EMCY_codes[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.writeData[i] = 0.0;
    }

    for (i = 0; i < 20; i++) {
      may23_B.floatSDOValues[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.A1M1Convert[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.A1M2Convert[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.R1M2_EMCY_codes[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.R1M1_EMCY_codes[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.writeData_g[i] = 0.0;
    }

    for (i = 0; i < 20; i++) {
      may23_B.floatSDOValues_d[i] = 0.0;
    }

    for (i = 0; i < 14; i++) {
      may23_B.Convert19_h[i] = 0.0;
    }

    for (i = 0; i < 6; i++) {
      may23_B.DataTypeConversion_nc[i] = 0.0F;
    }

    for (i = 0; i < 6; i++) {
      may23_B.DataTypeConversion1_px[i] = 0.0F;
    }

    for (i = 0; i < 8; i++) {
      may23_B.Reshape_a[i] = 0.0F;
    }

    for (i = 0; i < 13; i++) {
      may23_B.Unpack_o[i] = 0.0F;
    }

    for (i = 0; i < 10; i++) {
      may23_B.DataTypeConversion_g5x[i] = 0.0F;
    }

    for (i = 0; i < 10; i++) {
      may23_B.DataTypeConversion1_pf[i] = 0.0F;
    }

    for (i = 0; i < 10; i++) {
      may23_B.SFunction_o1_j[i] = 0.0F;
    }

    for (i = 0; i < 10; i++) {
      may23_B.SFunction_o2[i] = 0.0F;
    }

    for (i = 0; i < 6; i++) {
      may23_B.SFunction_o5[i] = 0.0F;
    }

    for (i = 0; i < 6; i++) {
      may23_B.SFunction_o6[i] = 0.0F;
    }

    for (i = 0; i < 400; i++) {
      may23_B.RateTransition1_l[i] = 0.0F;
    }

    for (i = 0; i < 410; i++) {
      may23_B.data_out[i] = 0.0F;
    }

    for (i = 0; i < 182; i++) {
      may23_B.DataTypeConversion_i[i] = 0.0F;
    }

    for (i = 0; i < 182; i++) {
      may23_B.t2[i] = 0.0F;
    }

    for (i = 0; i < 182; i++) {
      may23_B.t1[i] = 0.0F;
    }

    for (i = 0; i < 946; i++) {
      may23_B.TmpSignalConversionAtSelectorInport1[i] = 0.0F;
    }

    for (i = 0; i < 400; i++) {
      may23_B.Selector_pl[i] = 0.0F;
    }

    for (i = 0; i < 70; i++) {
      may23_B.sf_EmbeddedMATLABFunction_h.VCODE[i] = 0.0;
    }

    for (i = 0; i < 70; i++) {
      may23_B.sf_EmbeddedMATLABFunction_a.VCODE[i] = 0.0;
    }

    for (i = 0; i < 70; i++) {
      may23_B.sf_EmbeddedMATLABFunction_e.VCODE[i] = 0.0;
    }

    for (i = 0; i < 70; i++) {
      may23_B.sf_EmbeddedMATLABFunction_m.VCODE[i] = 0.0;
    }

    for (i = 0; i < 70; i++) {
      may23_B.sf_EmbeddedMATLABFunction_n.VCODE[i] = 0.0;
    }

    for (i = 0; i < 70; i++) {
      may23_B.sf_EmbeddedMATLABFunction_p.VCODE[i] = 0.0;
    }

    for (i = 0; i < 24; i++) {
      may23_B.sf_setupvalues_o.setupValues[i] = 0.0;
    }

    for (i = 0; i < 12; i++) {
      may23_B.sf_setupvalues_o.encoderValues[i] = 0.0;
    }

    for (i = 0; i < 24; i++) {
      may23_B.sf_setupvalues_p.setupValues[i] = 0.0;
    }

    for (i = 0; i < 12; i++) {
      may23_B.sf_setupvalues_p.encoderValues[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.sf_passemcy_e.EMCYMsg[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.sf_passemcy_c.EMCYMsg[i] = 0.0;
    }

    for (i = 0; i < 24; i++) {
      may23_B.sf_setupvalues_b.setupValues[i] = 0.0;
    }

    for (i = 0; i < 12; i++) {
      may23_B.sf_setupvalues_b.encoderValues[i] = 0.0;
    }

    for (i = 0; i < 24; i++) {
      may23_B.sf_setupvalues.setupValues[i] = 0.0;
    }

    for (i = 0; i < 12; i++) {
      may23_B.sf_setupvalues.encoderValues[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.sf_passemcy_b.EMCYMsg[i] = 0.0;
    }

    for (i = 0; i < 5; i++) {
      may23_B.sf_passemcy.EMCYMsg[i] = 0.0;
    }

    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea =
      may23_rtZKinDataStruct;
    may23_B.Delay1 = 0.0;
    may23_B.Product3 = 0.0;
    may23_B.RunCommandReceive_o2 = 0.0;
    may23_B.DataTypeConversion = 0.0;
    may23_B.PauseType = 0.0;
    may23_B.Convert18 = 0.0;
    may23_B.UsecustomTPsequence = 0.0;
    may23_B.Memory = 0.0;
    may23_B.TaskClock = 0.0;
    may23_B.Product = 0.0;
    may23_B.DataTypeConversion_p = 0.0;
    may23_B.MinMax = 0.0;
    may23_B.Memory_d[0] = 0.0;
    may23_B.Memory_d[1] = 0.0;
    may23_B.Memory_d[2] = 0.0;
    may23_B.Memory_d[3] = 0.0;
    may23_B.Memory_m = 0.0;
    may23_B.Gain = 0.0;
    may23_B.Memory2 = 0.0;
    may23_B.Switch[0] = 0.0;
    may23_B.Switch[1] = 0.0;
    may23_B.Switch_i[0] = 0.0;
    may23_B.Switch_i[1] = 0.0;
    may23_B.Selector[0] = 0.0;
    may23_B.Selector[1] = 0.0;
    may23_B.Selector_n[0] = 0.0;
    may23_B.Selector_n[1] = 0.0;
    may23_B.Selector_g[0] = 0.0;
    may23_B.Selector_g[1] = 0.0;
    may23_B.Convert9[0] = 0.0;
    may23_B.Convert9[1] = 0.0;
    may23_B.Product2 = 0.0;
    may23_B.DataTypeConversion2 = 0.0;
    may23_B.Convert16 = 0.0;
    may23_B.Convert17 = 0.0;
    may23_B.TmpRTBAtHold_to_1KhzInport2 = 0.0;
    may23_B.Convert10[0] = 0.0;
    may23_B.Convert10[1] = 0.0;
    may23_B.Convert12 = 0.0;
    may23_B.Convert13[0] = 0.0;
    may23_B.Convert13[1] = 0.0;
    may23_B.Convert13[2] = 0.0;
    may23_B.Convert14[0] = 0.0;
    may23_B.Convert14[1] = 0.0;
    may23_B.Convert15 = 0.0;
    may23_B.Convert7 = 0.0;
    may23_B.Convert8 = 0.0;
    may23_B.frame_of_reference_center[0] = 0.0;
    may23_B.frame_of_reference_center[1] = 0.0;
    may23_B.LibraryPatchVersion = 0.0;
    may23_B.LibraryVersion = 0.0;
    may23_B.TaskVersion = 0.0;
    may23_B.xPCVersion = 0.0;
    may23_B.dlmbuildtime = 0.0;
    may23_B.preview_detail[0] = 0.0;
    may23_B.preview_detail[1] = 0.0;
    may23_B.preview_detail[2] = 0.0;
    may23_B.Subtract = 0.0;
    may23_B.gethandmass = 0.0;
    may23_B.getrectanglemass = 0.0;
    may23_B.MatrixConcatenate1[0] = 0.0;
    may23_B.MatrixConcatenate1[1] = 0.0;
    may23_B.MatrixConcatenate1[2] = 0.0;
    may23_B.MatrixConcatenate1[3] = 0.0;
    may23_B.PulseGenerator = 0.0;
    may23_B.DataTypeConversion_b = 0.0;
    may23_B.DataTypeConversion_g = 0.0;
    may23_B.RateTransition1 = 0.0;
    may23_B.RateTransition2 = 0.0;
    may23_B.EventCodes = 0.0;
    may23_B.Subtract_i = 0.0;
    may23_B.NumberofEventCodes = 0.0;
    may23_B.touint1 = 0.0;
    may23_B.ButtonStatus = 0.0;
    may23_B.CurrentBlockIndex = 0.0;
    may23_B.CurrentBlockNumberinSet = 0.0;
    may23_B.CurrentTPIndex = 0.0;
    may23_B.CurrentTrialNumberinBlock = 0.0;
    may23_B.CurrentTrialNumberinSet = 0.0;
    may23_B.Receive_o2 = 0.0;
    may23_B.Convert1 = 0.0;
    may23_B.LastFrameAcknowledged = 0.0;
    may23_B.Convert = 0.0;
    may23_B.LastFrameSent = 0.0;
    may23_B.LastFrameSent1 = 0.0;
    may23_B.LoggingEnable = 0.0;
    may23_B.Servoupdatecount = 0.0;
    may23_B.RateTransition = 0.0;
    may23_B.RateTransition1_h = 0.0;
    may23_B.RunStatus = 0.0;
    may23_B.RateTransition10 = 0.0;
    may23_B.TaskControlButton = 0.0;
    may23_B.RateTransition11 = 0.0;
    may23_B.RateTransition12 = 0.0;
    may23_B.RateTransition2_k = 0.0;
    may23_B.RateTransition3 = 0.0;
    may23_B.RateTransition4 = 0.0;
    may23_B.RateTransition5 = 0.0;
    may23_B.RateTransition6 = 0.0;
    may23_B.RateTransition7 = 0.0;
    may23_B.RateTransition8 = 0.0;
    may23_B.RateTransition9 = 0.0;
    may23_B.TmpRTBAtTimestampOutport1 = 0.0;
    may23_B.conv = 0.0;
    may23_B.Delay = 0.0;
    may23_B.Product_b[0] = 0.0;
    may23_B.Product_b[1] = 0.0;
    may23_B.Product_b[2] = 0.0;
    may23_B.Product_b[3] = 0.0;
    may23_B.up_durationms = 0.0;
    may23_B.down_durationms = 0.0;
    may23_B.up_durationms_h = 0.0;
    may23_B.down_durationms_b = 0.0;
    may23_B.DataTypeConversion_pv = 0.0;
    may23_B.AddR1 = 0.0;
    may23_B.up_durationms1 = 0.0;
    may23_B.down_durationms1 = 0.0;
    may23_B.DataTypeConversion1 = 0.0;
    may23_B.AddR2 = 0.0;
    may23_B.Delay_a[0] = 0.0;
    may23_B.Delay_a[1] = 0.0;
    may23_B.Delay_a[2] = 0.0;
    may23_B.Delay_a[3] = 0.0;
    may23_B.Product_n[0] = 0.0;
    may23_B.Product_n[1] = 0.0;
    may23_B.Product_n[2] = 0.0;
    may23_B.Product_n[3] = 0.0;
    may23_B.Delay_l = 0.0;
    may23_B.TaskClock_h = 0.0;
    may23_B.Memory3[0] = 0.0;
    may23_B.Memory3[1] = 0.0;
    may23_B.Memory3[2] = 0.0;
    may23_B.Memory3[3] = 0.0;
    may23_B.Abs[0] = 0.0;
    may23_B.Abs[1] = 0.0;
    may23_B.Abs[2] = 0.0;
    may23_B.Abs[3] = 0.0;
    may23_B.SumofElements = 0.0;
    may23_B.Switch_k[0] = 0.0;
    may23_B.Switch_k[1] = 0.0;
    may23_B.Switch_k[2] = 0.0;
    may23_B.Switch_k[3] = 0.0;
    may23_B.Product_br[0] = 0.0;
    may23_B.Product_br[1] = 0.0;
    may23_B.Product_br[2] = 0.0;
    may23_B.Product_br[3] = 0.0;
    may23_B.Reshape_p[0] = 0.0;
    may23_B.Reshape_p[1] = 0.0;
    may23_B.Reshape_p[2] = 0.0;
    may23_B.Reshape_p[3] = 0.0;
    may23_B.Switch_h = 0.0;
    may23_B.Product_i[0] = 0.0;
    may23_B.Product_i[1] = 0.0;
    may23_B.Product1[0] = 0.0;
    may23_B.Product1[1] = 0.0;
    may23_B.Switch1 = 0.0;
    may23_B.Reshape_b[0] = 0.0;
    may23_B.Reshape_b[1] = 0.0;
    may23_B.Reshape_b[2] = 0.0;
    may23_B.Reshape_b[3] = 0.0;
    may23_B.Product_c[0] = 0.0;
    may23_B.Product_c[1] = 0.0;
    may23_B.Product1_j[0] = 0.0;
    may23_B.Product1_j[1] = 0.0;
    may23_B.AddTorques[0] = 0.0;
    may23_B.AddTorques[1] = 0.0;
    may23_B.AddTorques[2] = 0.0;
    may23_B.AddTorques[3] = 0.0;
    may23_B.Memory1 = 0.0;
    may23_B.Product_g[0] = 0.0;
    may23_B.Product_g[1] = 0.0;
    may23_B.Product_g[2] = 0.0;
    may23_B.Product_g[3] = 0.0;
    may23_B.Memory1_l = 0.0;
    may23_B.ArmOrientation = 0.0;
    may23_B.M1orientation = 0.0;
    may23_B.M2Orientation = 0.0;
    may23_B.M1GearRatio = 0.0;
    may23_B.M2GearRatio = 0.0;
    may23_B.torqueconstant = 0.0;
    may23_B.ArmOrientation_a = 0.0;
    may23_B.M1orientation_i = 0.0;
    may23_B.M2Orientation_a = 0.0;
    may23_B.M1GearRatio_e = 0.0;
    may23_B.M2GearRatio_n = 0.0;
    may23_B.torqueconstant_b = 0.0;
    may23_B.isEP = 0.0;
    may23_B.isHumanExo = 0.0;
    may23_B.isNHPExo = 0.0;
    may23_B.isClassicExo = 0.0;
    may23_B.isUTSExo = 0.0;
    may23_B.isPMAC = 0.0;
    may23_B.isECAT = 0.0;
    may23_B.robotRevision = 0.0;
    may23_B.HasSecondaryEnc = 0.0;
    may23_B.robottype = 0.0;
    may23_B.robotversion = 0.0;
    may23_B.isEP_f = 0.0;
    may23_B.isHumanExo_k = 0.0;
    may23_B.isNHPExo_l = 0.0;
    may23_B.isClassicExo_j = 0.0;
    may23_B.isUTSExo_n = 0.0;
    may23_B.isPMAC_p = 0.0;
    may23_B.isECAT_o = 0.0;
    may23_B.robotRevision_p = 0.0;
    may23_B.HasSecondaryEnc_h = 0.0;
    may23_B.robottype_c = 0.0;
    may23_B.robotversion_a = 0.0;
    may23_B.Memory1_e[0] = 0.0;
    may23_B.Memory1_e[1] = 0.0;
    may23_B.Memory1_e[2] = 0.0;
    may23_B.Memory1_e[3] = 0.0;
    may23_B.encoder_err_threshold = 0.0;
    may23_B.robot_count = 0.0;
    may23_B.has_force_plate_1 = 0.0;
    may23_B.has_force_plate_2 = 0.0;
    may23_B.has_gaze_tracker = 0.0;
    may23_B.has_robot_lift = 0.0;
    may23_B.assessment_hand_vel[0] = 0.0;
    may23_B.assessment_hand_vel[1] = 0.0;
    may23_B.contralateral_hand_vel[0] = 0.0;
    may23_B.contralateral_hand_vel[1] = 0.0;
    may23_B.assessment_link_angles[0] = 0.0;
    may23_B.assessment_link_angles[1] = 0.0;
    may23_B.contralateral_link_angles[0] = 0.0;
    may23_B.contralateral_link_angles[1] = 0.0;
    may23_B.assessment_link_vel[0] = 0.0;
    may23_B.assessment_link_vel[1] = 0.0;
    may23_B.contralateral_link_vel[0] = 0.0;
    may23_B.contralateral_link_vel[1] = 0.0;
    may23_B.assessment_hand_vel_n[0] = 0.0;
    may23_B.assessment_hand_vel_n[1] = 0.0;
    may23_B.contralateral_hand_vel_d[0] = 0.0;
    may23_B.contralateral_hand_vel_d[1] = 0.0;
    may23_B.assessment_link_angles_m[0] = 0.0;
    may23_B.assessment_link_angles_m[1] = 0.0;
    may23_B.contralateral_link_angles_f[0] = 0.0;
    may23_B.contralateral_link_angles_f[1] = 0.0;
    may23_B.assessment_link_vel_n[0] = 0.0;
    may23_B.assessment_link_vel_n[1] = 0.0;
    may23_B.contralateral_link_vel_a[0] = 0.0;
    may23_B.contralateral_link_vel_a[1] = 0.0;
    may23_B.Constant = 0.0;
    may23_B.binary_file_names = 0.0;
    may23_B.BARRIER_ROWBarriertargetBarriernone = 0.0;
    may23_B.CURSOR_ROWHandTargetRowtargethandnone = 0.0;
    may23_B.GOAL_ROWGoalRowtargetGoalnone = 0.0;
    may23_B.GOAL_TIMEGoaltimesfloatTimethatpuckhastostayingoaltotriggersucc =
      0.0;
    may23_B.LOAD_ROWLoadRowloadLoadnone = 0.0;
    may23_B.PRESHOT_ROWPreshotAreatargetPreshotAreanone = 0.0;
    may23_B.PUCK_DAMPINGPuckdampingfloatDampingconstantonpuckbetween0and1no =
      0.0;
    may23_B.PUCK_ROWPuckTargetRowtargetPucknone = 0.0;
    may23_B.SECONDSTrialdurationsfloatHowlongisthetrialinsecondsnone = 0.0;
    may23_B.SHOT_READY_TIMEShotreadytimesfloatTimetoholdinstarttargetduring =
      0.0;
    may23_B.SHOT_SET_TIMEShotsettimesfloatTimetoholdinstarttargetafterpresh =
      0.0;
    may23_B.SHOT_TIMEShottimesfloatTimetomakeashotintothegoalnone = 0.0;
    may23_B.START_HOLD_TIMEStartholdtimesfloatTimetoholdinstarttargetbefore =
      0.0;
    may23_B.START_ROWStartPositiontargetStartingSpotforPtnone = 0.0;
    may23_B.E_BEGIN_PRESHOTbeginpreshotroutinenone = 0.0;
    may23_B.E_ENTER_STARTenterstarttargetnone = 0.0;
    may23_B.E_FAILUREfailurered = 0.0;
    may23_B.E_HAND_IN_BARRIERhandinbarriernone = 0.0;
    may23_B.E_NO_EVENTnaThisevent_codedoesnotsaveaneventinthedatafileitjust =
      0.0;
    may23_B.E_PUCK_IN_BARRIERpuckinbarriernone = 0.0;
    may23_B.E_PUCK_IN_GOALpuckingoalnone = 0.0;
    may23_B.E_PUCK_MISSpuckmissnone = 0.0;
    may23_B.E_SHOT_GOshotgonone = 0.0;
    may23_B.E_SHOT_READYshotreadynone = 0.0;
    may23_B.E_START_TARGET_ONstarttargetonnone = 0.0;
    may23_B.E_SUCCESSsuccessgreen = 0.0;
    may23_B.E_TIMEOUTtimeoutred = 0.0;
    may23_B.E_TRIAL_STARTtrialstartnone = 0.0;
    may23_B.F_BUMPF_BUMPfloatCompletelyarbitraryparameterbasedonwhatfeelsgo =
      0.0;
    may23_B.MASS_CIRCLECircletargetmassfloatnone = 0.0;
    may23_B.MASS_RECTRectangletargetmassfloatnone = 0.0;
    may23_B.PERT_DURPerturbationDurationfloatmsTimethattheperturbationishig =
      0.0;
    may23_B.PERT_RAMPPerturbationRampTimefloatmsTimefortheperturbationtoram =
      0.0;
    may23_B.FIRST_FILLFirstfillcolorcolourFirstfillcolorforaselectedtargetc =
      0.0;
    may23_B.HEIGHTHeightfloatRectangleheightcmnone = 0.0;
    may23_B.RADIUS_LOGlogicalradiusfloatcomputationalradiuscmnone = 0.0;
    may23_B.RADIUS_VISradiusvisfloatradiusincmlegacynone = 0.0;
    may23_B.ROTATIONRotationfloatRectangleroationdegreesnone = 0.0;
    may23_B.SECOND_FILLSecondfillcolorcolourSecondfillcolorforaselectedtarg =
      0.0;
    may23_B.STROKE_COLORStrokecolourcolourStrokecolorcolornone = 0.0;
    may23_B.STROKE_WIDTHWidthofthestrokefloatStrokeweightcmnone = 0.0;
    may23_B.THIRD_FILLthirdfillcolorcolourThirdfillcolorforaselectedtargetc =
      0.0;
    may23_B.col_xXfloatXPositioncmofthetargetrelativetolocal00none = 0.0;
    may23_B.col_yYfloatYPositioncmofthetargetrelativetolocal00none = 0.0;
    may23_B.WIDTHWidthorRadiusfloatRectanglewidthorCircleRadiuscmnone = 0.0;
    may23_B.INSTRUCTIONS = 0.0;
    may23_B.LOAD_FOREITHER = 0.0;
    may23_B.FORCE_MULTIPLIERForcemultiplierfloatnone = 0.0;
    may23_B.Timestamp = 0.0;
    may23_B.RateTransition2_h[0] = 0.0;
    may23_B.RateTransition2_h[1] = 0.0;
    may23_B.RateTransition1_c = 0.0;
    may23_B.SFunctionBuilder_o2 = 0.0;
    may23_B.force_vector[0] = 0.0;
    may23_B.force_vector[1] = 0.0;
    may23_B.force_vector[2] = 0.0;
    may23_B.force_vector[3] = 0.0;
    may23_B.hand_vcodes_e[0] = 0.0;
    may23_B.hand_vcodes_e[1] = 0.0;
    may23_B.hand_vcodes_e[2] = 0.0;
    may23_B.hand_vcodes_e[3] = 0.0;
    may23_B.force_scaling[0] = 0.0;
    may23_B.force_scaling[1] = 0.0;
    may23_B.force_scaling[2] = 0.0;
    may23_B.force_scaling[3] = 0.0;
    may23_B.event_code = 0.0;
    may23_B.cursor_row = 0.0;
    may23_B.cursor_state = 0.0;
    may23_B.puck_row = 0.0;
    may23_B.puck_state = 0.0;
    may23_B.load_row = 0.0;
    may23_B.barrier_target_row = 0.0;
    may23_B.barrier_target_state = 0.0;
    may23_B.start_target_row = 0.0;
    may23_B.start_target_state = 0.0;
    may23_B.goal_target_row = 0.0;
    may23_B.goal_target_state = 0.0;
    may23_B.preshot_area_row = 0.0;
    may23_B.preshot_area_state = 0.0;
    may23_B.perturbation[0] = 0.0;
    may23_B.perturbation[1] = 0.0;
    may23_B.perturbation[2] = 0.0;
    may23_B.scaling = 0.0;
    may23_B.indisplay = 0.0;
    may23_B.RateTransition1_o = 0.0;
    may23_B.Convert_j = 0.0;
    may23_B.vis_cmd_len = 0.0;
    may23_B.vis_cmd_cropped = 0.0;
    may23_B.vcode_err_id = 0.0;
    may23_B.last_frame_ack = 0.0;
    may23_B.last_perm_ack = 0.0;
    may23_B.delay = 0.0;
    may23_B.assessment_hand_pos[0] = 0.0;
    may23_B.assessment_hand_pos[1] = 0.0;
    may23_B.contralateral_hand_pos[0] = 0.0;
    may23_B.contralateral_hand_pos[1] = 0.0;
    may23_B.assessment_hand_pos_f[0] = 0.0;
    may23_B.assessment_hand_pos_f[1] = 0.0;
    may23_B.contralateral_hand_pos_o[0] = 0.0;
    may23_B.contralateral_hand_pos_o[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport3_h[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport3_h[1] = 0.0;
    may23_B.clipped_torques[0] = 0.0;
    may23_B.clipped_torques[1] = 0.0;
    may23_B.clipped_torques[2] = 0.0;
    may23_B.clipped_torques[3] = 0.0;
    may23_B.y[0] = 0.0;
    may23_B.y[1] = 0.0;
    may23_B.y[2] = 0.0;
    may23_B.y[3] = 0.0;
    may23_B.out[0] = 0.0;
    may23_B.out[1] = 0.0;
    may23_B.out[2] = 0.0;
    may23_B.out[3] = 0.0;
    may23_B.out_p[0] = 0.0;
    may23_B.out_p[1] = 0.0;
    may23_B.out_p[2] = 0.0;
    may23_B.out_p[3] = 0.0;
    may23_B.joint_loads[0] = 0.0;
    may23_B.joint_loads[1] = 0.0;
    may23_B.joint_loads[2] = 0.0;
    may23_B.joint_loads[3] = 0.0;
    may23_B.out_m[0] = 0.0;
    may23_B.out_m[1] = 0.0;
    may23_B.out_m[2] = 0.0;
    may23_B.out_m[3] = 0.0;
    may23_B.total_trials = 0.0;
    may23_B.trials_in_block = 0.0;
    may23_B.total_blocks = 0.0;
    may23_B.repeat_last_trial = 0.0;
    may23_B.extra_trials[0] = 0.0;
    may23_B.extra_trials[1] = 0.0;
    may23_B.tp_out = 0.0;
    may23_B.value = 0.0;
    may23_B.y_o = 0.0;
    may23_B.z = 0.0;
    may23_B.joint_loads_i[0] = 0.0;
    may23_B.joint_loads_i[1] = 0.0;
    may23_B.joint_loads_i[2] = 0.0;
    may23_B.joint_loads_i[3] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2[1] = 0.0;
    may23_B.command_multiplier = 0.0;
    may23_B.stop_vel_mode = 0.0;
    may23_B.robot_err_bits_out = 0.0;
    may23_B.torque_multiplier_out = 0.0;
    may23_B.stop_vel_mode_out = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_f[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_f[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_f[2] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_f[3] = 0.0;
    may23_B.filteredVals_n[0] = 0.0;
    may23_B.filteredVals_n[1] = 0.0;
    may23_B.filteredVals_n[2] = 0.0;
    may23_B.filteredVals_n[3] = 0.0;
    may23_B.robot_limits[0] = 0.0;
    may23_B.robot_limits[1] = 0.0;
    may23_B.robot_limits[2] = 0.0;
    may23_B.torque_err_bitfield = 0.0;
    may23_B.abs_diff[0] = 0.0;
    may23_B.abs_diff[1] = 0.0;
    may23_B.abs_diff[2] = 0.0;
    may23_B.abs_diff[3] = 0.0;
    may23_B.rel_diff[0] = 0.0;
    may23_B.rel_diff[1] = 0.0;
    may23_B.rel_diff[2] = 0.0;
    may23_B.rel_diff[3] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_j[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_j[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_j[2] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_j[3] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_n[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_n[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_n[2] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_n[3] = 0.0;
    may23_B.deltas[0] = 0.0;
    may23_B.deltas[1] = 0.0;
    may23_B.deltas[2] = 0.0;
    may23_B.deltas[3] = 0.0;
    may23_B.torques_out[0] = 0.0;
    may23_B.torques_out[1] = 0.0;
    may23_B.torques_out[2] = 0.0;
    may23_B.torques_out[3] = 0.0;
    may23_B.Product_d[0] = 0.0;
    may23_B.Product_d[1] = 0.0;
    may23_B.Product_d[2] = 0.0;
    may23_B.Product_d[3] = 0.0;
    may23_B.DataTypeConversion3[0] = 0.0;
    may23_B.DataTypeConversion3[1] = 0.0;
    may23_B.DataTypeConversion3[2] = 0.0;
    may23_B.DataTypeConversion3[3] = 0.0;
    may23_B.DataTypeConversion4 = 0.0;
    may23_B.DataTypeConversion5 = 0.0;
    may23_B.Convert1_n = 0.0;
    may23_B.DataTypeConversion_p5 = 0.0;
    may23_B.Convert19[0] = 0.0;
    may23_B.Convert19[1] = 0.0;
    may23_B.Convert19[2] = 0.0;
    may23_B.Convert3 = 0.0;
    may23_B.Gain_o[0] = 0.0;
    may23_B.Gain_o[1] = 0.0;
    may23_B.Gain_o[2] = 0.0;
    may23_B.Convert4[0] = 0.0;
    may23_B.Convert4[1] = 0.0;
    may23_B.Convert4[2] = 0.0;
    may23_B.DataTypeConversion1_f[0] = 0.0;
    may23_B.DataTypeConversion1_f[1] = 0.0;
    may23_B.DataTypeConversion1_f[2] = 0.0;
    may23_B.RateTransition_i[0] = 0.0;
    may23_B.RateTransition_i[1] = 0.0;
    may23_B.RateTransition_i[2] = 0.0;
    may23_B.Receive_o2_f = 0.0;
    may23_B.RateTransition1_n[0] = 0.0;
    may23_B.RateTransition1_n[1] = 0.0;
    may23_B.RateTransition1_n[2] = 0.0;
    may23_B.RateTransition2_l = 0.0;
    may23_B.Convert2[0] = 0.0;
    may23_B.Convert2[1] = 0.0;
    may23_B.Convert2[2] = 0.0;
    may23_B.event_data_out[0] = 0.0;
    may23_B.event_data_out[1] = 0.0;
    may23_B.event_data_out[2] = 0.0;
    may23_B.gazeXYCalculated[0] = 0.0;
    may23_B.gazeXYCalculated[1] = 0.0;
    may23_B.pupil_area_GLOBAL = 0.0;
    may23_B.gaze_unit_vector_GLOBAL[0] = 0.0;
    may23_B.gaze_unit_vector_GLOBAL[1] = 0.0;
    may23_B.gaze_unit_vector_GLOBAL[2] = 0.0;
    may23_B.pupil_GLOBAL[0] = 0.0;
    may23_B.pupil_GLOBAL[1] = 0.0;
    may23_B.pupil_GLOBAL[2] = 0.0;
    may23_B.timestamp_out = 0.0;
    may23_B.start_time_out = 0.0;
    may23_B.DataTypeConversion_pn = 0.0;
    may23_B.max_errors_to_fault = 0.0;
    may23_B.systemtype = 0.0;
    may23_B.ReadHasFT[0] = 0.0;
    may23_B.ReadHasFT[1] = 0.0;
    may23_B.ReadHasFT[2] = 0.0;
    may23_B.ArmOrientation_f = 0.0;
    may23_B.M1orientation_b = 0.0;
    may23_B.M2Orientation_k = 0.0;
    may23_B.M1GearRatio_p = 0.0;
    may23_B.M2GearRatio_i = 0.0;
    may23_B.HasSecondaryEnc_n = 0.0;
    may23_B.ArmOrientation_m = 0.0;
    may23_B.M1orientation_f = 0.0;
    may23_B.M2Orientation_c = 0.0;
    may23_B.M1GearRatio_a = 0.0;
    may23_B.M2GearRatio_ie = 0.0;
    may23_B.HasSecondaryEnc_c = 0.0;
    may23_B.shoulderangleoffset = 0.0;
    may23_B.elbowangleoffset = 0.0;
    may23_B.ShoulderX = 0.0;
    may23_B.ShoulderY = 0.0;
    may23_B.L1 = 0.0;
    may23_B.L2 = 0.0;
    may23_B.Pointeroffset = 0.0;
    may23_B.L3Error = 0.0;
    may23_B.robottype_a = 0.0;
    may23_B.torqueconstant_bz = 0.0;
    may23_B.robotversion_h = 0.0;
    may23_B.shoulderangleoffset_j = 0.0;
    may23_B.elbowangleoffset_o = 0.0;
    may23_B.ShoulderX_b = 0.0;
    may23_B.ShoulderY_n = 0.0;
    may23_B.L1_e = 0.0;
    may23_B.L2_j = 0.0;
    may23_B.Pointeroffset_a = 0.0;
    may23_B.L3Error_a = 0.0;
    may23_B.robottype_j = 0.0;
    may23_B.torqueconstant_l = 0.0;
    may23_B.robotversion_f = 0.0;
    may23_B.Statusread1[0] = 0.0;
    may23_B.Statusread1[1] = 0.0;
    may23_B.Statusread1_c[0] = 0.0;
    may23_B.Statusread1_c[1] = 0.0;
    may23_B.active_arm = 0.0;
    may23_B.servoCounter = 0.0;
    may23_B.calibrationButtonBits = 0.0;
    may23_B.handFF_Dex = 0.0;
    may23_B.is_calibrated[0] = 0.0;
    may23_B.is_calibrated[1] = 0.0;
    may23_B.DelayRead[0] = 0.0;
    may23_B.DelayRead[1] = 0.0;
    may23_B.DelayRead[2] = 0.0;
    may23_B.DelayRead[3] = 0.0;
    may23_B.DataTypeConversion_f[0] = 0.0;
    may23_B.DataTypeConversion_f[1] = 0.0;
    may23_B.DataTypeConversion_f[2] = 0.0;
    may23_B.DataTypeConversion_f[3] = 0.0;
    may23_B.DataTypeConversion1_d = 0.0;
    may23_B.sentMessageCount = 0.0;
    may23_B.trigger_calibration[0] = 0.0;
    may23_B.trigger_calibration[1] = 0.0;
    may23_B.DataTypeConversion3_o[0] = 0.0;
    may23_B.DataTypeConversion3_o[1] = 0.0;
    may23_B.DataTypeConversion3_o[2] = 0.0;
    may23_B.DataTypeConversion3_o[3] = 0.0;
    may23_B.DataTypeConversion5_c[0] = 0.0;
    may23_B.DataTypeConversion5_c[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_a[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_a[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_a[2] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_a[3] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport4[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport4[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_ny[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_ny[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport3_c[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport3_c[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport4_m[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport4_m[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_e[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_e[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_p[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_p[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_p[2] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_p[3] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_d[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_d[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_d[2] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_d[3] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport3_m[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport3_m[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport5[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport5[1] = 0.0;
    may23_B.delays[0] = 0.0;
    may23_B.delays[1] = 0.0;
    may23_B.delays[2] = 0.0;
    may23_B.delays[3] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_m[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_m[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_m[2] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_m[3] = 0.0;
    may23_B.filteredVels[0] = 0.0;
    may23_B.filteredVels[1] = 0.0;
    may23_B.filteredVels[2] = 0.0;
    may23_B.filteredVels[3] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_me[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport1_me[1] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_l[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport2_l[1] = 0.0;
    may23_B.swap_order = 0.0;
    may23_B.isEP_e = 0.0;
    may23_B.isHumanEXO = 0.0;
    may23_B.isNHPEXO = 0.0;
    may23_B.isClassicExo_e = 0.0;
    may23_B.isUTSEXO = 0.0;
    may23_B.isPMAC_a = 0.0;
    may23_B.isECAT_i = 0.0;
    may23_B.isEP_a = 0.0;
    may23_B.isHumanEXO_c = 0.0;
    may23_B.isNHPEXO_p = 0.0;
    may23_B.isClassicExo_n = 0.0;
    may23_B.isUTSEXO_k = 0.0;
    may23_B.isPMAC_c = 0.0;
    may23_B.isECAT_b = 0.0;
    may23_B.Receive_o2_l = 0.0;
    may23_B.DataTypeConversion_o[0] = 0.0;
    may23_B.DataTypeConversion_o[1] = 0.0;
    may23_B.DataTypeConversion1_j[0] = 0.0;
    may23_B.DataTypeConversion1_j[1] = 0.0;
    may23_B.DataTypeConversion2_f = 0.0;
    may23_B.DataTypeConversion2_h = 0.0;
    may23_B.UnitDelay = 0.0;
    may23_B.UnitDelay2 = 0.0;
    may23_B.DPRAMReadValue = 0.0;
    may23_B.UnitDelay1 = 0.0;
    may23_B.UnitDelay3 = 0.0;
    may23_B.Conversion7[0] = 0.0;
    may23_B.Conversion7[1] = 0.0;
    may23_B.Conversion7[2] = 0.0;
    may23_B.Conversion7[3] = 0.0;
    may23_B.force_scale = 0.0;
    may23_B.DataTypeConversion1_g = 0.0;
    may23_B.Uk1 = 0.0;
    may23_B.ReceivefromRobot1ForceSensor_o2 = 0.0;
    may23_B.Uk1_o = 0.0;
    may23_B.ReceivefromRobot2ForceSensor_o2 = 0.0;
    may23_B.Memory_k = 0.0;
    may23_B.Memory_j = 0.0;
    may23_B.Memory1_ew = 0.0;
    may23_B.offsetrads = 0.0;
    may23_B.encorient = 0.0;
    may23_B.L2select2 = 0.0;
    may23_B.L2select3 = 0.0;
    may23_B.L2select4 = 0.0;
    may23_B.R2_maxContinuousTorque[0] = 0.0;
    may23_B.R2_maxContinuousTorque[1] = 0.0;
    may23_B.L2select5 = 0.0;
    may23_B.R2_constantsReady = 0.0;
    may23_B.L2select = 0.0;
    may23_B.L2select1 = 0.0;
    may23_B.L2select2_m = 0.0;
    may23_B.L2select3_l = 0.0;
    may23_B.L2select4_o = 0.0;
    may23_B.L2select5_k = 0.0;
    may23_B.R2M1_LinkAngle = 0.0;
    may23_B.R2M2_LinkAngle = 0.0;
    may23_B.R2M2_PrimaryLinkAngle = 0.0;
    may23_B.R2M2_PrimaryLinkVelocity = 0.0;
    may23_B.R2M2_RecordedTorque = 0.0;
    may23_B.R2M2_digitalInputs[0] = 0.0;
    may23_B.R2M2_digitalInputs[1] = 0.0;
    may23_B.R2M2_digitalDiagnostics = 0.0;
    may23_B.R2M1_PrimaryLinkAngle = 0.0;
    may23_B.R2M1_PrimaryLinkVelocity = 0.0;
    may23_B.R2M1_RecordedTorque = 0.0;
    may23_B.R2M1_digitalInputs[0] = 0.0;
    may23_B.R2M1_digitalInputs[1] = 0.0;
    may23_B.R2M1_digitalDiagnostics = 0.0;
    may23_B.R2_calibrationButton = 0.0;
    may23_B.R2_RobotType = 0.0;
    may23_B.R2_absAngleOffset[0] = 0.0;
    may23_B.R2_absAngleOffset[1] = 0.0;
    may23_B.R2_LinkLength[0] = 0.0;
    may23_B.R2_LinkLength[1] = 0.0;
    may23_B.R2_L2CalibPinOffset = 0.0;
    may23_B.R2_maxContinuousTorque_c[0] = 0.0;
    may23_B.R2_maxContinuousTorque_c[1] = 0.0;
    may23_B.R2_gearRatios[0] = 0.0;
    may23_B.R2_gearRatios[1] = 0.0;
    may23_B.R2_isCalibrated = 0.0;
    may23_B.R2_OffsetRads[0] = 0.0;
    may23_B.R2_OffsetRads[1] = 0.0;
    may23_B.R2_OffsetRadsPrimary[0] = 0.0;
    may23_B.R2_OffsetRadsPrimary[1] = 0.0;
    may23_B.R2_RobotRevision = 0.0;
    may23_B.R2_constantsReady_b = 0.0;
    may23_B.R2_hasSecondary = 0.0;
    may23_B.R2_hasFT = 0.0;
    may23_B.R2_robotOrientation = 0.0;
    may23_B.R2_motorOrientation[0] = 0.0;
    may23_B.R2_motorOrientation[1] = 0.0;
    may23_B.R2_encOrientation[0] = 0.0;
    may23_B.R2_encOrientation[1] = 0.0;
    may23_B.R2_encodercounts[0] = 0.0;
    may23_B.R2_encodercounts[1] = 0.0;
    may23_B.R2_FTSensorAngleOffset = 0.0;
    may23_B.R2_calibPinAngle[0] = 0.0;
    may23_B.R2_calibPinAngle[1] = 0.0;
    may23_B.RateTransition1_p = 0.0;
    may23_B.hasSecondary = 0.0;
    may23_B.hasFT = 0.0;
    may23_B.robotOrientation = 0.0;
    may23_B.motorOrientation[0] = 0.0;
    may23_B.motorOrientation[1] = 0.0;
    may23_B.encOrientation[0] = 0.0;
    may23_B.encOrientation[1] = 0.0;
    may23_B.absEnc = 0.0;
    may23_B.encoderCounts[0] = 0.0;
    may23_B.encoderCounts[1] = 0.0;
    may23_B.FTSensorOffset = 0.0;
    may23_B.calibPinAngles[0] = 0.0;
    may23_B.calibPinAngles[1] = 0.0;
    may23_B.absAngOffsets[0] = 0.0;
    may23_B.absAngOffsets[1] = 0.0;
    may23_B.linkLengths[0] = 0.0;
    may23_B.linkLengths[1] = 0.0;
    may23_B.L2CalibPinOffset = 0.0;
    may23_B.continuousTorques[0] = 0.0;
    may23_B.continuousTorques[1] = 0.0;
    may23_B.gearRatios[0] = 0.0;
    may23_B.gearRatios[1] = 0.0;
    may23_B.isCalibrated = 0.0;
    may23_B.offsetRads[0] = 0.0;
    may23_B.offsetRads[1] = 0.0;
    may23_B.offsetRadsPrimary[0] = 0.0;
    may23_B.offsetRadsPrimary[1] = 0.0;
    may23_B.robotRevision_g = 0.0;
    may23_B.constantsReady = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport6[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport6[1] = 0.0;
    may23_B.forceMotorState = 0.0;
    may23_B.status = 0.0;
    may23_B.readAddr[0] = 0.0;
    may23_B.readAddr[1] = 0.0;
    may23_B.readAddr[2] = 0.0;
    may23_B.convert_b = 0.0;
    may23_B.convert1 = 0.0;
    may23_B.convert2 = 0.0;
    may23_B.convert3 = 0.0;
    may23_B.status_f = 0.0;
    may23_B.DataTypeConversion_a = 0.0;
    may23_B.DataTypeConversion1_e = 0.0;
    may23_B.LinkAngle = 0.0;
    may23_B.PrimaryLinkAngle = 0.0;
    may23_B.PrimaryLinkVel = 0.0;
    may23_B.torque = 0.0;
    may23_B.digitalInputs[0] = 0.0;
    may23_B.digitalInputs[1] = 0.0;
    may23_B.digitalDiagnostics = 0.0;
    may23_B.DataTypeConversion_mm = 0.0;
    may23_B.driveID = 0.0;
    may23_B.DataTypeConversion2_ht[0] = 0.0;
    may23_B.DataTypeConversion2_ht[1] = 0.0;
    may23_B.DataTypeConversion2_ht[2] = 0.0;
    may23_B.DataTypeConversion_p1[0] = 0.0;
    may23_B.DataTypeConversion_p1[1] = 0.0;
    may23_B.DataTypeConversion_p1[2] = 0.0;
    may23_B.Memory_g = 0.0;
    may23_B.DataTypeConversion1_gy = 0.0;
    may23_B.LinkAngle_i = 0.0;
    may23_B.PrimaryLinkAngle_j = 0.0;
    may23_B.PrimaryLinkVel_k = 0.0;
    may23_B.torque_h = 0.0;
    may23_B.digitalInputs_g[0] = 0.0;
    may23_B.digitalInputs_g[1] = 0.0;
    may23_B.digitalDiagnostics_p = 0.0;
    may23_B.calibrationButton = 0.0;
    may23_B.DataTypeConversion_pw = 0.0;
    may23_B.driveID_d = 0.0;
    may23_B.DataTypeConversion2_b[0] = 0.0;
    may23_B.DataTypeConversion2_b[1] = 0.0;
    may23_B.DataTypeConversion2_b[2] = 0.0;
    may23_B.DataTypeConversion_n[0] = 0.0;
    may23_B.DataTypeConversion_n[1] = 0.0;
    may23_B.DataTypeConversion_n[2] = 0.0;
    may23_B.Memory_e = 0.0;
    may23_B.DataTypeConversion1_l = 0.0;
    may23_B.Memory_p = 0.0;
    may23_B.Memory_jp = 0.0;
    may23_B.Memory1_g = 0.0;
    may23_B.L2select_k = 0.0;
    may23_B.L2select1_p = 0.0;
    may23_B.L2select2_l = 0.0;
    may23_B.L2select3_a = 0.0;
    may23_B.L2select4_g = 0.0;
    may23_B.R1_maxContinuousTorque[0] = 0.0;
    may23_B.R1_maxContinuousTorque[1] = 0.0;
    may23_B.L2select5_o = 0.0;
    may23_B.R1_constantsReady = 0.0;
    may23_B.L2select_p = 0.0;
    may23_B.L2select1_pl = 0.0;
    may23_B.L2select2_mv = 0.0;
    may23_B.L2select3_i = 0.0;
    may23_B.L2select4_k = 0.0;
    may23_B.L2select5_j = 0.0;
    may23_B.R1M1_LinkAngle = 0.0;
    may23_B.R1M2_LinkAngle = 0.0;
    may23_B.R1M2_PrimaryLinkAngle = 0.0;
    may23_B.R1M2_PrimaryLinkVelocity = 0.0;
    may23_B.R1M2_RecordedTorque = 0.0;
    may23_B.R1M2_digitalInputs[0] = 0.0;
    may23_B.R1M2_digitalInputs[1] = 0.0;
    may23_B.R1M2_digitalDiagnostics = 0.0;
    may23_B.R1M1_PrimaryLinkAngle = 0.0;
    may23_B.R1M1_PrimaryLinkVelocity = 0.0;
    may23_B.R1M1_RecordedTorque = 0.0;
    may23_B.R1M1_digitalInputs[0] = 0.0;
    may23_B.R1M1_digitalInputs[1] = 0.0;
    may23_B.R1M1_digitalDiagnostics = 0.0;
    may23_B.R1_calibrationButton = 0.0;
    may23_B.R1_RobotType = 0.0;
    may23_B.R1_absAngleOffset[0] = 0.0;
    may23_B.R1_absAngleOffset[1] = 0.0;
    may23_B.R1_LinkLength[0] = 0.0;
    may23_B.R1_LinkLength[1] = 0.0;
    may23_B.R1_L2CalibPinOffset = 0.0;
    may23_B.R1_maxContinuousTorque_i[0] = 0.0;
    may23_B.R1_maxContinuousTorque_i[1] = 0.0;
    may23_B.R1_gearRatios[0] = 0.0;
    may23_B.R1_gearRatios[1] = 0.0;
    may23_B.R1_isCalibrated = 0.0;
    may23_B.R1_OffsetRads[0] = 0.0;
    may23_B.R1_OffsetRads[1] = 0.0;
    may23_B.R1_OffsetRadsPrimary[0] = 0.0;
    may23_B.R1_OffsetRadsPrimary[1] = 0.0;
    may23_B.R1_RobotRevision = 0.0;
    may23_B.R1_constantsReady_p = 0.0;
    may23_B.R1_hasSecondary = 0.0;
    may23_B.R1_hasFT = 0.0;
    may23_B.R1_robotOrientation = 0.0;
    may23_B.R1_motorOrientation[0] = 0.0;
    may23_B.R1_motorOrientation[1] = 0.0;
    may23_B.R1_encOrientation[0] = 0.0;
    may23_B.R1_encOrientation[1] = 0.0;
    may23_B.R1_encodercounts[0] = 0.0;
    may23_B.R1_encodercounts[1] = 0.0;
    may23_B.R1_FTSensorAngleOffset = 0.0;
    may23_B.R1_calibPinAngle[0] = 0.0;
    may23_B.R1_calibPinAngle[1] = 0.0;
    may23_B.RateTransition1_i = 0.0;
    may23_B.hasSecondary_l = 0.0;
    may23_B.hasFT_c = 0.0;
    may23_B.robotOrientation_o = 0.0;
    may23_B.motorOrientation_j[0] = 0.0;
    may23_B.motorOrientation_j[1] = 0.0;
    may23_B.encOrientation_m[0] = 0.0;
    may23_B.encOrientation_m[1] = 0.0;
    may23_B.absEnc_m = 0.0;
    may23_B.encoderCounts_j[0] = 0.0;
    may23_B.encoderCounts_j[1] = 0.0;
    may23_B.FTSensorOffset_k = 0.0;
    may23_B.calibPinAngles_i[0] = 0.0;
    may23_B.calibPinAngles_i[1] = 0.0;
    may23_B.absAngOffsets_p[0] = 0.0;
    may23_B.absAngOffsets_p[1] = 0.0;
    may23_B.linkLengths_p[0] = 0.0;
    may23_B.linkLengths_p[1] = 0.0;
    may23_B.L2CalibPinOffset_e = 0.0;
    may23_B.continuousTorques_m[0] = 0.0;
    may23_B.continuousTorques_m[1] = 0.0;
    may23_B.gearRatios_j[0] = 0.0;
    may23_B.gearRatios_j[1] = 0.0;
    may23_B.isCalibrated_j = 0.0;
    may23_B.offsetRads_a[0] = 0.0;
    may23_B.offsetRads_a[1] = 0.0;
    may23_B.offsetRadsPrimary_f[0] = 0.0;
    may23_B.offsetRadsPrimary_f[1] = 0.0;
    may23_B.robotRevision_h = 0.0;
    may23_B.constantsReady_p = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport6_k[0] = 0.0;
    may23_B.TmpSignalConversionAtSFunctionInport6_k[1] = 0.0;
    may23_B.forceMotorState_o = 0.0;
    may23_B.status_d = 0.0;
    may23_B.readAddr_a[0] = 0.0;
    may23_B.readAddr_a[1] = 0.0;
    may23_B.readAddr_a[2] = 0.0;
    may23_B.convert_o = 0.0;
    may23_B.convert1_n = 0.0;
    may23_B.convert2_e = 0.0;
    may23_B.convert3_b = 0.0;
    may23_B.status_n = 0.0;
    may23_B.DataTypeConversion_bj = 0.0;
    may23_B.DataTypeConversion1_j1 = 0.0;
    may23_B.LinkAngle_a = 0.0;
    may23_B.PrimaryLinkAngle_f = 0.0;
    may23_B.PrimaryLinkVel_d = 0.0;
    may23_B.torque_l = 0.0;
    may23_B.digitalInputs_p[0] = 0.0;
    may23_B.digitalInputs_p[1] = 0.0;
    may23_B.digitalDiagnostics_b = 0.0;
    may23_B.DataTypeConversion_bu = 0.0;
    may23_B.driveID_o = 0.0;
    may23_B.DataTypeConversion2_g[0] = 0.0;
    may23_B.DataTypeConversion2_g[1] = 0.0;
    may23_B.DataTypeConversion2_g[2] = 0.0;
    may23_B.DataTypeConversion_l[0] = 0.0;
    may23_B.DataTypeConversion_l[1] = 0.0;
    may23_B.DataTypeConversion_l[2] = 0.0;
    may23_B.Memory_ju = 0.0;
    may23_B.DataTypeConversion1_m = 0.0;
    may23_B.LinkAngle_b = 0.0;
    may23_B.PrimaryLinkAngle_h = 0.0;
    may23_B.PrimaryLinkVel_b = 0.0;
    may23_B.torque_l0 = 0.0;
    may23_B.digitalInputs_o[0] = 0.0;
    may23_B.digitalInputs_o[1] = 0.0;
    may23_B.digitalDiagnostics_a = 0.0;
    may23_B.calibrationButton_n = 0.0;
    may23_B.DataTypeConversion_lz = 0.0;
    may23_B.driveID_p = 0.0;
    may23_B.DataTypeConversion2_i[0] = 0.0;
    may23_B.DataTypeConversion2_i[1] = 0.0;
    may23_B.DataTypeConversion2_i[2] = 0.0;
    may23_B.DataTypeConversion_lg[0] = 0.0;
    may23_B.DataTypeConversion_lg[1] = 0.0;
    may23_B.DataTypeConversion_lg[2] = 0.0;
    may23_B.Memory_es = 0.0;
    may23_B.DataTypeConversion1_m3 = 0.0;
    may23_B.RateTransition_a = 0.0;
    may23_B.RateTransition1_ot = 0.0;
    may23_B.Receive1_o2 = 0.0;
    may23_B.forces[0] = 0.0;
    may23_B.forces[1] = 0.0;
    may23_B.forces[2] = 0.0;
    may23_B.moments[0] = 0.0;
    may23_B.moments[1] = 0.0;
    may23_B.moments[2] = 0.0;
    may23_B.timer = 0.0;
    may23_B.Receive_o2_b = 0.0;
    may23_B.forces_e[0] = 0.0;
    may23_B.forces_e[1] = 0.0;
    may23_B.forces_e[2] = 0.0;
    may23_B.moments_i[0] = 0.0;
    may23_B.moments_i[1] = 0.0;
    may23_B.moments_i[2] = 0.0;
    may23_B.timer_a = 0.0;
    may23_B.Receive_o2_c = 0.0;
    may23_B.RateTransition2_a = 0.0;
    may23_B.TaskClock_e = 0.0;
    may23_B.trigger = 0.0;
    may23_B.Memory1_m = 0.0;
    may23_B.strobe_out = 0.0;
    may23_B.resetUDP = 0.0;
    may23_B.UnitDelay_h = 0.0;
    may23_B.Sum = 0.0;
    may23_B.Width = 0.0;
    may23_B.IdealFramesPerPacket = 0.0;
    may23_B.MinMax_b = 0.0;
    may23_B.MathFunction = 0.0;
    may23_B.Subtract_h = 0.0;
    may23_B.Product_i0 = 0.0;
    may23_B.dd_out[0] = 0.0;
    may23_B.dd_out[1] = 0.0;
    may23_B.DataTypeConversion6[0] = 0.0F;
    may23_B.DataTypeConversion6[1] = 0.0F;
    may23_B.DataTypeConversion6[2] = 0.0F;
    may23_B.DataTypeConversion6[3] = 0.0F;
    may23_B.pupil_X[0] = 0.0F;
    may23_B.pupil_X[1] = 0.0F;
    may23_B.pupilY[0] = 0.0F;
    may23_B.pupilY[1] = 0.0F;
    may23_B.HREFX[0] = 0.0F;
    may23_B.HREFX[1] = 0.0F;
    may23_B.HREFY[0] = 0.0F;
    may23_B.HREFY[1] = 0.0F;
    may23_B.pupilarea[0] = 0.0F;
    may23_B.pupilarea[1] = 0.0F;
    may23_B.gaze_X[0] = 0.0F;
    may23_B.gaze_X[1] = 0.0F;
    may23_B.gaze_Y[0] = 0.0F;
    may23_B.gaze_Y[1] = 0.0F;
    may23_B.resolutionX = 0.0F;
    may23_B.resolutionY = 0.0F;
    may23_B.SelectorLeftEye[0] = 0.0F;
    may23_B.SelectorLeftEye[1] = 0.0F;
    may23_B.SelectorLeftEye[2] = 0.0F;
    may23_B.SelectorLeftEye[3] = 0.0F;
    may23_B.Unpack_o1_n[0] = 0.0F;
    may23_B.Unpack_o1_n[1] = 0.0F;
    may23_B.Unpack_o2[0] = 0.0F;
    may23_B.Unpack_o2[1] = 0.0F;
    may23_B.DataTypeConversion2_n = 0.0F;
    may23_B.SFunction_o4[0] = 0.0F;
    may23_B.SFunction_o4[1] = 0.0F;
    may23_B.SFunction_o4[2] = 0.0F;
    may23_B.SFunction_o4[3] = 0.0F;
    may23_B.SFunction_o10 = 0.0F;
    may23_B.y_h = 0.0F;
    may23_B.DataTypeConversion1_o3 = 0.0F;
    may23_B.Read_h = 0.0F;
    may23_B.DataTypeConversion2_k = 0.0F;
    may23_B.queue_size = 0.0F;
    may23_B.total_timeouts = 0.0F;
    may23_B.sf_Remove_NaNs_and_Inf_d.TmpSignalConversionAtSFunctionInport1[0] =
      0.0;
    may23_B.sf_Remove_NaNs_and_Inf_d.TmpSignalConversionAtSFunctionInport1[1] =
      0.0;
    may23_B.sf_Remove_NaNs_and_Inf_d.TmpSignalConversionAtSFunctionInport1[2] =
      0.0;
    may23_B.sf_Remove_NaNs_and_Inf_d.TmpSignalConversionAtSFunctionInport1[3] =
      0.0;
    may23_B.sf_Remove_NaNs_and_Inf_d.out[0] = 0.0;
    may23_B.sf_Remove_NaNs_and_Inf_d.out[1] = 0.0;
    may23_B.sf_Remove_NaNs_and_Inf_d.out[2] = 0.0;
    may23_B.sf_Remove_NaNs_and_Inf_d.out[3] = 0.0;
    may23_B.sf_Ramp_Up_Down1_h.scaling = 0.0;
    may23_B.sf_Ramp_Up_Down_g.scaling = 0.0;
    may23_B.sf_Remove_NaNs_and_Inf.TmpSignalConversionAtSFunctionInport1[0] =
      0.0;
    may23_B.sf_Remove_NaNs_and_Inf.TmpSignalConversionAtSFunctionInport1[1] =
      0.0;
    may23_B.sf_Remove_NaNs_and_Inf.TmpSignalConversionAtSFunctionInport1[2] =
      0.0;
    may23_B.sf_Remove_NaNs_and_Inf.TmpSignalConversionAtSFunctionInport1[3] =
      0.0;
    may23_B.sf_Remove_NaNs_and_Inf.out[0] = 0.0;
    may23_B.sf_Remove_NaNs_and_Inf.out[1] = 0.0;
    may23_B.sf_Remove_NaNs_and_Inf.out[2] = 0.0;
    may23_B.sf_Remove_NaNs_and_Inf.out[3] = 0.0;
    may23_B.sf_Ramp_Up_Down1.scaling = 0.0;
    may23_B.sf_Ramp_Up_Down.scaling = 0.0;
    may23_B.sf_MATLABFunction1.is_right_arm = 0.0;
    may23_B.sf_MATLABFunction1.isExo = 0.0;
    may23_B.sf_MATLABFunction1.has_high_res_encoders = 0.0;
    may23_B.sf_MATLABFunction_a.is_right_arm = 0.0;
    may23_B.sf_MATLABFunction_a.isExo = 0.0;
    may23_B.sf_MATLABFunction_a.has_high_res_encoders = 0.0;
    may23_B.sf_split_primary1.link_angles[0] = 0.0;
    may23_B.sf_split_primary1.link_angles[1] = 0.0;
    may23_B.sf_split_primary1.link_velocities[0] = 0.0;
    may23_B.sf_split_primary1.link_velocities[1] = 0.0;
    may23_B.sf_split_primary1.link_acceleration[0] = 0.0;
    may23_B.sf_split_primary1.link_acceleration[1] = 0.0;
    may23_B.sf_split_primary.link_angles[0] = 0.0;
    may23_B.sf_split_primary.link_angles[1] = 0.0;
    may23_B.sf_split_primary.link_velocities[0] = 0.0;
    may23_B.sf_split_primary.link_velocities[1] = 0.0;
    may23_B.sf_split_primary.link_acceleration[0] = 0.0;
    may23_B.sf_split_primary.link_acceleration[1] = 0.0;
    may23_B.sf_splitKINDataarm2.link_lengths[0] = 0.0;
    may23_B.sf_splitKINDataarm2.link_lengths[1] = 0.0;
    may23_B.sf_splitKINDataarm2.pointer_offset = 0.0;
    may23_B.sf_splitKINDataarm2.shoulder_loc[0] = 0.0;
    may23_B.sf_splitKINDataarm2.shoulder_loc[1] = 0.0;
    may23_B.sf_splitKINDataarm2.arm_orientation = 0.0;
    may23_B.sf_splitKINDataarm2.shoulder_ang = 0.0;
    may23_B.sf_splitKINDataarm2.elbow_ang = 0.0;
    may23_B.sf_splitKINDataarm2.shoulder_ang_velocity = 0.0;
    may23_B.sf_splitKINDataarm2.elbow_ang_velocity = 0.0;
    may23_B.sf_splitKINDataarm2.shoulder_ang_acceleration = 0.0;
    may23_B.sf_splitKINDataarm2.elbow_ang_acceleration = 0.0;
    may23_B.sf_splitKINDataarm2.joint_torque_cmd[0] = 0.0;
    may23_B.sf_splitKINDataarm2.joint_torque_cmd[1] = 0.0;
    may23_B.sf_splitKINDataarm2.motor_torque_cmd[0] = 0.0;
    may23_B.sf_splitKINDataarm2.motor_torque_cmd[1] = 0.0;
    may23_B.sf_splitKINDataarm2.link_angle[0] = 0.0;
    may23_B.sf_splitKINDataarm2.link_angle[1] = 0.0;
    may23_B.sf_splitKINDataarm2.link_velocity[0] = 0.0;
    may23_B.sf_splitKINDataarm2.link_velocity[1] = 0.0;
    may23_B.sf_splitKINDataarm2.link_acceleration[0] = 0.0;
    may23_B.sf_splitKINDataarm2.link_acceleration[1] = 0.0;
    may23_B.sf_splitKINDataarm2.hand_position[0] = 0.0;
    may23_B.sf_splitKINDataarm2.hand_position[1] = 0.0;
    may23_B.sf_splitKINDataarm2.hand_velocity[0] = 0.0;
    may23_B.sf_splitKINDataarm2.hand_velocity[1] = 0.0;
    may23_B.sf_splitKINDataarm2.hand_acceleration[0] = 0.0;
    may23_B.sf_splitKINDataarm2.hand_acceleration[1] = 0.0;
    may23_B.sf_splitKINDataarm2.elbow_position[0] = 0.0;
    may23_B.sf_splitKINDataarm2.elbow_position[1] = 0.0;
    may23_B.sf_splitKINDataarm2.elbow_velocity[0] = 0.0;
    may23_B.sf_splitKINDataarm2.elbow_velocity[1] = 0.0;
    may23_B.sf_splitKINDataarm2.elbow_acceleration[0] = 0.0;
    may23_B.sf_splitKINDataarm2.elbow_acceleration[1] = 0.0;
    may23_B.sf_splitKINDataarm2.motor_status = 0.0;
    may23_B.sf_splitKINDataarm2.force_sensor_force_uvw[0] = 0.0;
    may23_B.sf_splitKINDataarm2.force_sensor_force_uvw[1] = 0.0;
    may23_B.sf_splitKINDataarm2.force_sensor_force_uvw[2] = 0.0;
    may23_B.sf_splitKINDataarm2.force_sensor_torque_uvw[0] = 0.0;
    may23_B.sf_splitKINDataarm2.force_sensor_torque_uvw[1] = 0.0;
    may23_B.sf_splitKINDataarm2.force_sensor_torque_uvw[2] = 0.0;
    may23_B.sf_splitKINDataarm2.force_sensor_force_xyz[0] = 0.0;
    may23_B.sf_splitKINDataarm2.force_sensor_force_xyz[1] = 0.0;
    may23_B.sf_splitKINDataarm2.force_sensor_force_xyz[2] = 0.0;
    may23_B.sf_splitKINDataarm2.force_sensor_torque_xyz[0] = 0.0;
    may23_B.sf_splitKINDataarm2.force_sensor_torque_xyz[1] = 0.0;
    may23_B.sf_splitKINDataarm2.force_sensor_torque_xyz[2] = 0.0;
    may23_B.sf_splitKINDataarm2.force_sensor_timestamp = 0.0;
    may23_B.sf_splitKINDataarm1.link_lengths[0] = 0.0;
    may23_B.sf_splitKINDataarm1.link_lengths[1] = 0.0;
    may23_B.sf_splitKINDataarm1.pointer_offset = 0.0;
    may23_B.sf_splitKINDataarm1.shoulder_loc[0] = 0.0;
    may23_B.sf_splitKINDataarm1.shoulder_loc[1] = 0.0;
    may23_B.sf_splitKINDataarm1.arm_orientation = 0.0;
    may23_B.sf_splitKINDataarm1.shoulder_ang = 0.0;
    may23_B.sf_splitKINDataarm1.elbow_ang = 0.0;
    may23_B.sf_splitKINDataarm1.shoulder_ang_velocity = 0.0;
    may23_B.sf_splitKINDataarm1.elbow_ang_velocity = 0.0;
    may23_B.sf_splitKINDataarm1.shoulder_ang_acceleration = 0.0;
    may23_B.sf_splitKINDataarm1.elbow_ang_acceleration = 0.0;
    may23_B.sf_splitKINDataarm1.joint_torque_cmd[0] = 0.0;
    may23_B.sf_splitKINDataarm1.joint_torque_cmd[1] = 0.0;
    may23_B.sf_splitKINDataarm1.motor_torque_cmd[0] = 0.0;
    may23_B.sf_splitKINDataarm1.motor_torque_cmd[1] = 0.0;
    may23_B.sf_splitKINDataarm1.link_angle[0] = 0.0;
    may23_B.sf_splitKINDataarm1.link_angle[1] = 0.0;
    may23_B.sf_splitKINDataarm1.link_velocity[0] = 0.0;
    may23_B.sf_splitKINDataarm1.link_velocity[1] = 0.0;
    may23_B.sf_splitKINDataarm1.link_acceleration[0] = 0.0;
    may23_B.sf_splitKINDataarm1.link_acceleration[1] = 0.0;
    may23_B.sf_splitKINDataarm1.hand_position[0] = 0.0;
    may23_B.sf_splitKINDataarm1.hand_position[1] = 0.0;
    may23_B.sf_splitKINDataarm1.hand_velocity[0] = 0.0;
    may23_B.sf_splitKINDataarm1.hand_velocity[1] = 0.0;
    may23_B.sf_splitKINDataarm1.hand_acceleration[0] = 0.0;
    may23_B.sf_splitKINDataarm1.hand_acceleration[1] = 0.0;
    may23_B.sf_splitKINDataarm1.elbow_position[0] = 0.0;
    may23_B.sf_splitKINDataarm1.elbow_position[1] = 0.0;
    may23_B.sf_splitKINDataarm1.elbow_velocity[0] = 0.0;
    may23_B.sf_splitKINDataarm1.elbow_velocity[1] = 0.0;
    may23_B.sf_splitKINDataarm1.elbow_acceleration[0] = 0.0;
    may23_B.sf_splitKINDataarm1.elbow_acceleration[1] = 0.0;
    may23_B.sf_splitKINDataarm1.motor_status = 0.0;
    may23_B.sf_splitKINDataarm1.force_sensor_force_uvw[0] = 0.0;
    may23_B.sf_splitKINDataarm1.force_sensor_force_uvw[1] = 0.0;
    may23_B.sf_splitKINDataarm1.force_sensor_force_uvw[2] = 0.0;
    may23_B.sf_splitKINDataarm1.force_sensor_torque_uvw[0] = 0.0;
    may23_B.sf_splitKINDataarm1.force_sensor_torque_uvw[1] = 0.0;
    may23_B.sf_splitKINDataarm1.force_sensor_torque_uvw[2] = 0.0;
    may23_B.sf_splitKINDataarm1.force_sensor_force_xyz[0] = 0.0;
    may23_B.sf_splitKINDataarm1.force_sensor_force_xyz[1] = 0.0;
    may23_B.sf_splitKINDataarm1.force_sensor_force_xyz[2] = 0.0;
    may23_B.sf_splitKINDataarm1.force_sensor_torque_xyz[0] = 0.0;
    may23_B.sf_splitKINDataarm1.force_sensor_torque_xyz[1] = 0.0;
    may23_B.sf_splitKINDataarm1.force_sensor_torque_xyz[2] = 0.0;
    may23_B.sf_splitKINDataarm1.force_sensor_timestamp = 0.0;
    may23_B.sf_Createtimestamp_o.timestamp_out = 0.0;
    may23_B.sf_Createtimestamp.timestamp_out = 0.0;
    may23_B.sf_size1_b.count = 0.0;
    may23_B.sf_size_l.count = 0.0;
    may23_B.sf_converter_c.doubleOut = 0.0;
    may23_B.sf_values2_a.TmpSignalConversionAtSFunctionInport1[0] = 0.0;
    may23_B.sf_values2_a.TmpSignalConversionAtSFunctionInport1[1] = 0.0;
    may23_B.sf_values2_a.TmpSignalConversionAtSFunctionInport1[2] = 0.0;
    may23_B.sf_values2_a.outVal[0] = 0.0;
    may23_B.sf_values2_a.outVal[1] = 0.0;
    may23_B.sf_values2_a.outVal[2] = 0.0;
    may23_B.sf_values_p.TmpSignalConversionAtSFunctionInport1[0] = 0.0;
    may23_B.sf_values_p.TmpSignalConversionAtSFunctionInport1[1] = 0.0;
    may23_B.sf_values_p.TmpSignalConversionAtSFunctionInport1[2] = 0.0;
    may23_B.sf_values_p.outVal[0] = 0.0;
    may23_B.sf_values_p.outVal[1] = 0.0;
    may23_B.sf_values_p.outVal[2] = 0.0;
    may23_B.sf_converter_ai.doubleOut = 0.0;
    may23_B.sf_converter_f.doubleOut = 0.0;
    may23_B.sf_setupvalues_o.setupValuesCount = 0.0;
    may23_B.sf_setupvalues_o.pollValues[0] = 0.0;
    may23_B.sf_setupvalues_o.pollValues[1] = 0.0;
    may23_B.sf_setupvalues_o.pollValues[2] = 0.0;
    may23_B.sf_setupvalues_o.encoderValuesCount = 0.0;
    may23_B.sf_setupvalues_p.setupValuesCount = 0.0;
    may23_B.sf_setupvalues_p.pollValues[0] = 0.0;
    may23_B.sf_setupvalues_p.pollValues[1] = 0.0;
    may23_B.sf_setupvalues_p.pollValues[2] = 0.0;
    may23_B.sf_setupvalues_p.encoderValuesCount = 0.0;
    may23_B.sf_FindRobottype_i.robotType = 0.0;
    may23_B.sf_Whistlestate_m.isPermFaulted = 0.0;
    may23_B.sf_faultmonitor_h.triggerFaultRead = 0.0;
    may23_B.sf_ReadEMCY_o.emcyValPump[0] = 0.0;
    may23_B.sf_ReadEMCY_o.emcyValPump[1] = 0.0;
    may23_B.sf_ReadEMCY_o.emcyValPump[2] = 0.0;
    may23_B.sf_Whistlestate_l.isPermFaulted = 0.0;
    may23_B.sf_faultmonitor_f.triggerFaultRead = 0.0;
    may23_B.sf_ReadEMCY_b.emcyValPump[0] = 0.0;
    may23_B.sf_ReadEMCY_b.emcyValPump[1] = 0.0;
    may23_B.sf_ReadEMCY_b.emcyValPump[2] = 0.0;
    may23_B.sf_size1.count = 0.0;
    may23_B.sf_size.count = 0.0;
    may23_B.sf_converter_a.doubleOut = 0.0;
    may23_B.sf_values2.TmpSignalConversionAtSFunctionInport1[0] = 0.0;
    may23_B.sf_values2.TmpSignalConversionAtSFunctionInport1[1] = 0.0;
    may23_B.sf_values2.TmpSignalConversionAtSFunctionInport1[2] = 0.0;
    may23_B.sf_values2.outVal[0] = 0.0;
    may23_B.sf_values2.outVal[1] = 0.0;
    may23_B.sf_values2.outVal[2] = 0.0;
    may23_B.sf_values.TmpSignalConversionAtSFunctionInport1[0] = 0.0;
    may23_B.sf_values.TmpSignalConversionAtSFunctionInport1[1] = 0.0;
    may23_B.sf_values.TmpSignalConversionAtSFunctionInport1[2] = 0.0;
    may23_B.sf_values.outVal[0] = 0.0;
    may23_B.sf_values.outVal[1] = 0.0;
    may23_B.sf_values.outVal[2] = 0.0;
    may23_B.sf_converter_e.doubleOut = 0.0;
    may23_B.sf_converter.doubleOut = 0.0;
    may23_B.sf_setupvalues_b.setupValuesCount = 0.0;
    may23_B.sf_setupvalues_b.pollValues[0] = 0.0;
    may23_B.sf_setupvalues_b.pollValues[1] = 0.0;
    may23_B.sf_setupvalues_b.pollValues[2] = 0.0;
    may23_B.sf_setupvalues_b.encoderValuesCount = 0.0;
    may23_B.sf_setupvalues.setupValuesCount = 0.0;
    may23_B.sf_setupvalues.pollValues[0] = 0.0;
    may23_B.sf_setupvalues.pollValues[1] = 0.0;
    may23_B.sf_setupvalues.pollValues[2] = 0.0;
    may23_B.sf_setupvalues.encoderValuesCount = 0.0;
    may23_B.sf_FindRobottype.robotType = 0.0;
    may23_B.sf_Whistlestate_a.isPermFaulted = 0.0;
    may23_B.sf_faultmonitor_m.triggerFaultRead = 0.0;
    may23_B.sf_ReadEMCY_h.emcyValPump[0] = 0.0;
    may23_B.sf_ReadEMCY_h.emcyValPump[1] = 0.0;
    may23_B.sf_ReadEMCY_h.emcyValPump[2] = 0.0;
    may23_B.sf_Whistlestate.isPermFaulted = 0.0;
    may23_B.sf_faultmonitor.triggerFaultRead = 0.0;
    may23_B.sf_ReadEMCY.emcyValPump[0] = 0.0;
    may23_B.sf_ReadEMCY.emcyValPump[1] = 0.0;
    may23_B.sf_ReadEMCY.emcyValPump[2] = 0.0;
    may23_B.Width2 = 1000U;
  }

  /* parameters */
  may23_M->defaultParam = ((real_T *)&may23_P);

  /* states (dwork) */
  may23_M->dwork = ((void *) &may23_DW);
  (void) memset((void *)&may23_DW, 0,
                sizeof(DW_may23_T));
  may23_DW.Delay_DSTATE[0] = 0.0;
  may23_DW.Delay_DSTATE[1] = 0.0;
  may23_DW.Delay_DSTATE[2] = 0.0;
  may23_DW.Delay_DSTATE[3] = 0.0;

  {
    int32_T i;
    for (i = 0; i < 24; i++) {
      may23_DW.Delay_DSTATE_e[i] = 0.0;
    }
  }

  may23_DW.Delay_DSTATE_m[0] = 0.0;
  may23_DW.Delay_DSTATE_m[1] = 0.0;
  may23_DW.Delay_DSTATE_m[2] = 0.0;
  may23_DW.Delay_DSTATE_m[3] = 0.0;
  may23_DW.UnitDelay_DSTATE = 0.0;
  may23_DW.UnitDelay2_DSTATE = 0.0;
  may23_DW.UnitDelay1_DSTATE = 0.0;
  may23_DW.UnitDelay3_DSTATE = 0.0;
  may23_DW.DelayInput1_DSTATE = 0.0;
  may23_DW.DelayInput1_DSTATE_g = 0.0;
  may23_DW.UnitDelay_DSTATE_e = 0.0;
  may23_DW.Delay1_PreviousInput = 0.0;
  may23_DW.Subtract_DWORK1 = 0.0;
  may23_DW.Memory_PreviousInput = 0.0;
  may23_DW.Memory_PreviousInput_m[0] = 0.0;
  may23_DW.Memory_PreviousInput_m[1] = 0.0;
  may23_DW.Memory_PreviousInput_m[2] = 0.0;
  may23_DW.Memory_PreviousInput_m[3] = 0.0;
  may23_DW.Memory_PreviousInput_f = 0.0;
  may23_DW.Memory2_PreviousInput = 0.0;

  {
    int32_T i;
    for (i = 0; i < 70; i++) {
      may23_DW.Memory2_PreviousInput_c[i] = 0.0;
    }
  }

  may23_DW.TmpRTBAtHold_to_1KhzInport2_Buffer0 = 0.0;

  {
    int32_T i;
    for (i = 0; i < 71; i++) {
      may23_DW.RateTransition_Buffer[i] = 0.0;
    }
  }

  may23_DW.RateTransition2_Buffer0 = 0.0;

  {
    int32_T i;
    for (i = 0; i < 72; i++) {
      may23_DW.RateTransition_Buffer_d[i] = 0.0;
    }
  }

  may23_DW.TmpRTBAtTimestampOutport1_Buffer0 = 0.0;

  {
    int32_T i;
    for (i = 0; i < 20; i++) {
      may23_DW.RateTransition_Buffer_j[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 16; i++) {
      may23_DW.RateTransition1_Buffer[i] = 0.0;
    }
  }

  may23_DW.RateTransition2_Buffer[0] = 0.0;
  may23_DW.RateTransition2_Buffer[1] = 0.0;
  may23_DW.Memory3_PreviousInput[0] = 0.0;
  may23_DW.Memory3_PreviousInput[1] = 0.0;
  may23_DW.Memory3_PreviousInput[2] = 0.0;
  may23_DW.Memory3_PreviousInput[3] = 0.0;
  may23_DW.Memory1_PreviousInput = 0.0;
  may23_DW.Memory1_PreviousInput_l = 0.0;
  may23_DW.Memory2_1_PreviousInput = 0.0;
  may23_DW.Memory2_2_PreviousInput = 0.0;
  may23_DW.Memory2_3_PreviousInput = 0.0;
  may23_DW.Memory2_4_PreviousInput = 0.0;
  may23_DW.Memory2_5_PreviousInput = 0.0;
  may23_DW.Memory2_9_PreviousInput = 0.0;
  may23_DW.Memory2_18_PreviousInput = 0.0;
  may23_DW.Memory2_19_PreviousInput = 0.0;
  may23_DW.Memory2_20_PreviousInput = 0.0;
  may23_DW.Memory2_21_PreviousInput = 0.0;
  may23_DW.Memory2_22_PreviousInput = 0.0;
  may23_DW.Memory2_26_PreviousInput = 0.0;
  may23_DW.Memory2_10_PreviousInput = 0.0;
  may23_DW.Memory2_11_PreviousInput = 0.0;
  may23_DW.Memory2_12_PreviousInput = 0.0;
  may23_DW.Memory2_13_PreviousInput = 0.0;
  may23_DW.Memory2_14_PreviousInput = 0.0;
  may23_DW.Memory2_15_PreviousInput = 0.0;
  may23_DW.Memory2_16_PreviousInput = 0.0;
  may23_DW.Memory2_17_PreviousInput = 0.0;
  may23_DW.Memory2_23_PreviousInput = 0.0;
  may23_DW.Memory2_24_PreviousInput = 0.0;
  may23_DW.Memory2_25_PreviousInput = 0.0;
  may23_DW.Memory2_27_PreviousInput = 0.0;
  may23_DW.Memory2_28_PreviousInput = 0.0;
  may23_DW.Memory2_29_PreviousInput = 0.0;
  may23_DW.Memory2_30_PreviousInput = 0.0;
  may23_DW.Memory2_31_PreviousInput = 0.0;
  may23_DW.Memory2_32_PreviousInput = 0.0;
  may23_DW.Memory2_33_PreviousInput = 0.0;
  may23_DW.Memory2_34_PreviousInput = 0.0;
  may23_DW.Memory2_6_PreviousInput = 0.0;
  may23_DW.Memory2_7_PreviousInput = 0.0;
  may23_DW.Memory2_8_PreviousInput = 0.0;
  may23_DW.Memory1_PreviousInput_k[0] = 0.0;
  may23_DW.Memory1_PreviousInput_k[1] = 0.0;
  may23_DW.Memory1_PreviousInput_k[2] = 0.0;
  may23_DW.Memory1_PreviousInput_k[3] = 0.0;

  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      may23_DW.ECATStatus[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 10; i++) {
      may23_DW.DataReadyStatus[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 14; i++) {
      may23_DW.ECATHardware[i] = 0.0;
    }
  }

  may23_DW.RateTransition1_Buffer_k = 0.0;

  {
    int32_T i;
    for (i = 0; i < 490; i++) {
      may23_DW.RateTransition2_Buffer_j[i] = 0.0;
    }
  }

  may23_DW.hand_vector[0] = 0.0;
  may23_DW.hand_vector[1] = 0.0;
  may23_DW.prev_vel[0] = 0.0;
  may23_DW.prev_vel[1] = 0.0;
  may23_DW.target_colliding = 0.0;
  may23_DW.hand_vel[0] = 0.0;
  may23_DW.hand_vel[1] = 0.0;
  may23_DW.rect_offset_position = 0.0;
  may23_DW.barrier_colliding = 0.0;
  may23_DW.check_collision_barrier1 = 0.0;
  may23_DW.barrier_vel = 0.0;
  may23_DW.force_scaling_barrier = 0.0;
  may23_DW.hand_offset_position = 0.0;
  may23_DW.prev_hand_vel = 0.0;
  may23_DW.rect_left = 0.0;
  may23_DW.rect_bottom = 0.0;
  may23_DW.goal_right = 0.0;
  may23_DW.rect_right = 0.0;
  may23_DW.goal_bottom = 0.0;
  may23_DW.goal_left = 0.0;
  may23_DW.new_hand_posistion_c = 0.0;
  may23_DW.puck_offset_position[0] = 0.0;
  may23_DW.puck_offset_position[1] = 0.0;
  may23_DW.puck_velocity[0] = 0.0;
  may23_DW.puck_velocity[1] = 0.0;
  may23_DW.puck_damping = 0.0;
  may23_DW.trial_duration = 0.0;
  may23_DW.start_hold_time = 0.0;
  may23_DW.shot_set_time = 0.0;
  may23_DW.shot_ready_time = 0.0;
  may23_DW.goal_time = 0.0;
  may23_DW.shot_time = 0.0;
  may23_DW.tick = 0.0;
  may23_DW.RateTransition1_Buffer0 = 0.0;
  may23_DW.last_valid_frame_ack = 0.0;
  may23_DW.last_perm_frame_ack = 0.0;

  {
    int32_T i;
    for (i = 0; i < 50; i++) {
      may23_DW.trials_per_block[i] = 0.0;
    }
  }

  may23_DW.total_trials_saved = 0.0;
  may23_DW.total_blocks_saved = 0.0;

  {
    int32_T i;
    for (i = 0; i < 499; i++) {
      may23_DW.trial_queue[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 499; i++) {
      may23_DW.repeat_list[i] = 0.0;
    }
  }

  may23_DW.EXAM = 0.0;
  may23_DW.BLOCK = 0.0;
  may23_DW.block = 0.0;

  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      may23_DW.held_value[i] = 0.0;
    }
  }

  may23_DW.last_sim = 0.0;
  may23_DW.u = 0.0;
  may23_DW.v = 0.0;

  {
    int32_T i;
    for (i = 0; i < 24; i++) {
      may23_DW.rawVelocities[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 24; i++) {
      may23_DW.filtVelocities[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 12; i++) {
      may23_DW.rawVelocities_a[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 12; i++) {
      may23_DW.filtVelocities_l[i] = 0.0;
    }
  }

  may23_DW.isWorking = 0.0;
  may23_DW.RateTransition_Buffer0[0] = 0.0;
  may23_DW.RateTransition_Buffer0[1] = 0.0;
  may23_DW.RateTransition_Buffer0[2] = 0.0;
  may23_DW.RateTransition1_Buffer_j[0] = 0.0;
  may23_DW.RateTransition1_Buffer_j[1] = 0.0;
  may23_DW.RateTransition1_Buffer_j[2] = 0.0;
  may23_DW.RateTransition2_Buffer_f = 0.0;
  may23_DW.start_time = 0.0;
  may23_DW.last_time = 0.0;
  may23_DW.BKINEtherCATinit1_DWORK2 = 0.0;
  may23_DW.BKINEtherCATinit1_DWORK4 = 0.0;
  may23_DW.BKINEtherCATinit_DWORK2 = 0.0;
  may23_DW.BKINEtherCATinit_DWORK4 = 0.0;

  {
    int32_T i;
    for (i = 0; i < 20; i++) {
      may23_DW.TmpRTBAtDatawriteInport2_Buffer0[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 12; i++) {
      may23_DW.TmpRTBAtDatawriteInport3_Buffer0[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 20; i++) {
      may23_DW.ECATErrMsgs[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 10; i++) {
      may23_DW.ECATExtraData[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 25; i++) {
      may23_DW.HardwareSettings[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 20; i++) {
      may23_DW.Kinematics[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 12; i++) {
      may23_DW.PrimaryEncoderData[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 16; i++) {
      may23_DW.RobotCalibrations[i] = 0.0;
    }
  }

  may23_DW.RobotRevision[0] = 0.0;
  may23_DW.RobotRevision[1] = 0.0;
  may23_DW.DelayEstimates[0] = 0.0;
  may23_DW.DelayEstimates[1] = 0.0;
  may23_DW.DelayEstimates[2] = 0.0;
  may23_DW.DelayEstimates[3] = 0.0;
  may23_DW.ArmForceSensors[0] = 0.0;
  may23_DW.ArmForceSensors[1] = 0.0;
  may23_DW.ArmForceSensors[2] = 0.0;

  {
    int32_T i;
    for (i = 0; i < 20; i++) {
      may23_DW.lastECATMessages[i] = 0.0;
    }
  }

  may23_DW.outCount = 0.0;

  {
    int32_T i;
    for (i = 0; i < 300; i++) {
      may23_DW.memoryBuffer[i] = 0.0;
    }
  }

  may23_DW.waitingMsgCount = 0.0;
  may23_DW.sentCount = 0.0;
  may23_DW.was_calibrated[0] = 0.0;
  may23_DW.was_calibrated[1] = 0.0;
  may23_DW.was_calibrated[2] = 0.0;
  may23_DW.was_calibrated[3] = 0.0;

  {
    int32_T i;
    for (i = 0; i < 8; i++) {
      may23_DW.stored_offsets[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 12; i++) {
      may23_DW.rawVelocities_k[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 12; i++) {
      may23_DW.filtVelocities_d[i] = 0.0;
    }
  }

  may23_DW.r1Sho[0] = 0.0;
  may23_DW.r1Sho[1] = 0.0;
  may23_DW.r1Sho[2] = 0.0;
  may23_DW.r1Sho[3] = 0.0;
  may23_DW.r1Elb[0] = 0.0;
  may23_DW.r1Elb[1] = 0.0;
  may23_DW.r1Elb[2] = 0.0;
  may23_DW.r1Elb[3] = 0.0;
  may23_DW.r2Sho[0] = 0.0;
  may23_DW.r2Sho[1] = 0.0;
  may23_DW.r2Sho[2] = 0.0;
  may23_DW.r2Sho[3] = 0.0;
  may23_DW.r2Elb[0] = 0.0;
  may23_DW.r2Elb[1] = 0.0;
  may23_DW.r2Elb[2] = 0.0;
  may23_DW.r2Elb[3] = 0.0;
  may23_DW.last_tick[0] = 0.0;
  may23_DW.last_tick[1] = 0.0;
  may23_DW.last_tick[2] = 0.0;
  may23_DW.last_tick[3] = 0.0;

  {
    int32_T i;
    for (i = 0; i < 5; i++) {
      may23_DW.servoValuesR1[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 5; i++) {
      may23_DW.servoValuesR2[i] = 0.0;
    }
  }

  may23_DW.no_update_count = 0.0;

  {
    int32_T i;
    for (i = 0; i < 12; i++) {
      may23_DW.latchedErrors[i] = 0.0;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 12; i++) {
      may23_DW.latchedDCErrors[i] = 0.0;
    }
  }

  may23_DW.Memory_PreviousInput_c = 0.0;
  may23_DW.Memory_PreviousInput_g = 0.0;
  may23_DW.Memory1_PreviousInput_n = 0.0;
  may23_DW.Memory2_PreviousInput_g[0] = 0.0;
  may23_DW.Memory2_PreviousInput_g[1] = 0.0;
  may23_DW.Memory3_PreviousInput_k = 0.0;
  may23_DW.lastRunningState = 0.0;
  may23_DW.faultResetCycles = 0.0;
  may23_DW.valueCount = 0.0;
  may23_DW.Memory_PreviousInput_h = 0.0;
  may23_DW.Memory_PreviousInput_fh = 0.0;
  may23_DW.Memory_PreviousInput_k = 0.0;
  may23_DW.Memory_PreviousInput_d = 0.0;
  may23_DW.Memory1_PreviousInput_j = 0.0;
  may23_DW.Memory2_PreviousInput_j[0] = 0.0;
  may23_DW.Memory2_PreviousInput_j[1] = 0.0;
  may23_DW.Memory3_PreviousInput_h = 0.0;
  may23_DW.lastRunningState_o = 0.0;
  may23_DW.faultResetCycles_i = 0.0;
  may23_DW.valueCount_a = 0.0;
  may23_DW.Memory_PreviousInput_e = 0.0;
  may23_DW.Memory_PreviousInput_h4 = 0.0;
  may23_DW.RateTransition_Buffer_l = 0.0;
  may23_DW.RateTransition1_Buffer_kz = 0.0;
  may23_DW.RateTransition2_Buffer0_i = 0.0;
  may23_DW.Memory2_PreviousInput_b = 0.0;
  may23_DW.Memory1_PreviousInput_c = 0.0;
  may23_DW.counter = 0.0;
  may23_DW.packet_queue_sz = 0.0;
  may23_DW.outstanding_packet_index = 0.0;
  may23_DW.BKINEtherCATinit1_RWORK.EXECRATIO = 0.0;
  may23_DW.BKINEtherCATinit_RWORK.EXECRATIO = 0.0;

  {
    int32_T i;
    for (i = 0; i < 400; i++) {
      may23_DW.RateTransition1_Buffer0_i[i] = 0.0F;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 20500000; i++) {
      may23_DW.packet_queue[i] = 0.0F;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 182; i++) {
      may23_DW.t2_PreviousInput[i] = 0.0F;
    }
  }

  {
    int32_T i;
    for (i = 0; i < 182; i++) {
      may23_DW.t1_PreviousInput[i] = 0.0F;
    }
  }

  may23_DW.sf_Ramp_Up_Down1_h.tick = 0.0;
  may23_DW.sf_Ramp_Up_Down1_h.tickCount = 0.0;
  may23_DW.sf_Ramp_Up_Down_g.tick = 0.0;
  may23_DW.sf_Ramp_Up_Down_g.tickCount = 0.0;
  may23_DW.sf_Ramp_Up_Down1.tick = 0.0;
  may23_DW.sf_Ramp_Up_Down1.halfUpTicks = 0.0;
  may23_DW.sf_Ramp_Up_Down1.halfDownTicks = 0.0;
  may23_DW.sf_Ramp_Up_Down.tick = 0.0;
  may23_DW.sf_Ramp_Up_Down.halfUpTicks = 0.0;
  may23_DW.sf_Ramp_Up_Down.halfDownTicks = 0.0;
  may23_DW.sf_AbsEncodermachine_n.encoderIdx = 0.0;
  may23_DW.sf_AbsEncodermachine_j.encoderIdx = 0.0;
  may23_DW.sf_faultmonitor_h.preOpCounter = 0.0;
  may23_DW.sf_ReadEMCY_o.currReadIdx = 0.0;
  may23_DW.sf_ReadEMCY_o.valuesToRead = 0.0;
  may23_DW.sf_faultmonitor_f.preOpCounter = 0.0;
  may23_DW.sf_ReadEMCY_b.currReadIdx = 0.0;
  may23_DW.sf_ReadEMCY_b.valuesToRead = 0.0;
  may23_DW.sf_AbsEncodermachine_l.encoderIdx = 0.0;
  may23_DW.sf_AbsEncodermachine.encoderIdx = 0.0;
  may23_DW.sf_faultmonitor_m.preOpCounter = 0.0;
  may23_DW.sf_ReadEMCY_h.currReadIdx = 0.0;
  may23_DW.sf_ReadEMCY_h.valuesToRead = 0.0;
  may23_DW.sf_faultmonitor.preOpCounter = 0.0;
  may23_DW.sf_ReadEMCY.currReadIdx = 0.0;
  may23_DW.sf_ReadEMCY.valuesToRead = 0.0;

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  may23_InitializeDataMapInfo();

  /* child S-Function registration */
  {
    RTWSfcnInfo *sfcnInfo = &may23_M->NonInlinedSFcns.sfcnInfo;
    may23_M->sfcnInfo = (sfcnInfo);
    rtssSetErrorStatusPtr(sfcnInfo, (&rtmGetErrorStatus(may23_M)));
    rtssSetNumRootSampTimesPtr(sfcnInfo, &may23_M->Sizes.numSampTimes);
    may23_M->NonInlinedSFcns.taskTimePtrs[0] = &(rtmGetTPtr(may23_M)[0]);
    may23_M->NonInlinedSFcns.taskTimePtrs[1] = &(rtmGetTPtr(may23_M)[1]);
    may23_M->NonInlinedSFcns.taskTimePtrs[2] = &(rtmGetTPtr(may23_M)[2]);
    may23_M->NonInlinedSFcns.taskTimePtrs[3] = &(rtmGetTPtr(may23_M)[3]);
    may23_M->NonInlinedSFcns.taskTimePtrs[4] = &(rtmGetTPtr(may23_M)[4]);
    rtssSetTPtrPtr(sfcnInfo,may23_M->NonInlinedSFcns.taskTimePtrs);
    rtssSetTStartPtr(sfcnInfo, &rtmGetTStart(may23_M));
    rtssSetTFinalPtr(sfcnInfo, &rtmGetTFinal(may23_M));
    rtssSetTimeOfLastOutputPtr(sfcnInfo, &rtmGetTimeOfLastOutput(may23_M));
    rtssSetStepSizePtr(sfcnInfo, &may23_M->Timing.stepSize);
    rtssSetStopRequestedPtr(sfcnInfo, &rtmGetStopRequested(may23_M));
    rtssSetDerivCacheNeedsResetPtr(sfcnInfo, &may23_M->derivCacheNeedsReset);
    rtssSetZCCacheNeedsResetPtr(sfcnInfo, &may23_M->zCCacheNeedsReset);
    rtssSetContTimeOutputInconsistentWithStateAtMajorStepPtr(sfcnInfo,
      &may23_M->CTOutputIncnstWithState);
    rtssSetSampleHitsPtr(sfcnInfo, &may23_M->Timing.sampleHits);
    rtssSetPerTaskSampleHitsPtr(sfcnInfo, &may23_M->Timing.perTaskSampleHits);
    rtssSetSimModePtr(sfcnInfo, &may23_M->simMode);
    rtssSetSolverInfoPtr(sfcnInfo, &may23_M->solverInfoPtr);
  }

  may23_M->Sizes.numSFcns = (44);

  /* register each child */
  {
    (void) memset((void *)&may23_M->NonInlinedSFcns.childSFunctions[0], 0,
                  44*sizeof(SimStruct));
    may23_M->childSfunctions = (&may23_M->NonInlinedSFcns.childSFunctionPtrs[0]);

    {
      int_T i;
      for (i = 0; i < 44; i++) {
        may23_M->childSfunctions[i] = (&may23_M->
          NonInlinedSFcns.childSFunctions[i]);
      }
    }

    /* Level2 S-Function Block: may23/<S27>/Send (slrtUDPSend) */
    {
      SimStruct *rts = may23_M->childSfunctions[0];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn0.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn0.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn0.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[0]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[0]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[0]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[0]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[0]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[0]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[0]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn0.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn0.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn0.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, may23_B.Pack_i);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 40);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, (real_T*)&may23_ConstB.Width_j);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Send");
      ssSetPath(rts, "may23/DataLogging/Keep alive/Send");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn0.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.Send_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.Send_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.Send_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.Send_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.Send_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.Send_P6_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.Send_IWORK_d[0]);
      ssSetPWork(rts, (void **) &may23_DW.Send_PWORK_bz);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn0.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn0.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Send_IWORK_d[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.Send_PWORK_bz);
      }

      /* registration */
      slrtUDPSend(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.1);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 4;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 40);
      ssSetInputPortDataType(rts, 0, SS_UINT8);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetInputPortUnit(rts, 0, 0);
      ssSetInputPortIsContinuousQuantity(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }

    /* Level2 S-Function Block: may23/<S53>/Send (slrtUDPSend) */
    {
      SimStruct *rts = may23_M->childSfunctions[1];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn1.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn1.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn1.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[1]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[1]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[1]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[1]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[1]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[1]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[1]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn1.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn1.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn1.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, may23_B.Pack_c);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1640);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, (real_T*)&may23_ConstB.Width_g1);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Send");
      ssSetPath(rts,
                "may23/DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Send");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn1.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.Send_P1_Size_k);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.Send_P2_Size_j);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.Send_P3_Size_c);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.Send_P4_Size_n);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.Send_P5_Size_o);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.Send_P6_Size_a);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.Send_IWORK_n[0]);
      ssSetPWork(rts, (void **) &may23_DW.Send_PWORK_b);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn1.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn1.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Send_IWORK_n[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.Send_PWORK_b);
      }

      /* registration */
      slrtUDPSend(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 1640);
      ssSetInputPortDataType(rts, 0, SS_UINT8);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetInputPortUnit(rts, 0, 0);
      ssSetInputPortIsContinuousQuantity(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }

    /* Level2 S-Function Block: may23/<S52>/Receive (slrtUDPReceive) */
    {
      SimStruct *rts = may23_M->childSfunctions[2];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn2.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn2.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn2.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[2]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[2]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[2]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[2]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[2]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[2]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[2]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn2.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn2.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn2.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 21);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *) may23_B.Receive_o1_m));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *) &may23_B.Receive_o2_c));
        }
      }

      /* path info */
      ssSetModelName(rts, "Receive");
      ssSetPath(rts,
                "may23/DataLogging/Network Transfer Subsystem/UDP Receiver/Receive");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn2.params;
        ssSetSFcnParamsCount(rts, 9);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.Receive_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.Receive_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.Receive_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.Receive_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.Receive_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.Receive_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)may23_P.Receive_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)may23_P.Receive_P8_Size);
        ssSetSFcnParam(rts, 8, (mxArray*)may23_P.Receive_P9_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.Receive_IWORK_l[0]);
      ssSetPWork(rts, (void **) &may23_DW.Receive_PWORK_co[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn2.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn2.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Receive_IWORK_l[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 2);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.Receive_PWORK_co[0]);
      }

      /* registration */
      slrtUDPReceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S60>/Receive (slrtUDPReceive) */
    {
      SimStruct *rts = may23_M->childSfunctions[3];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn3.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn3.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn3.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[3]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[3]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[3]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[3]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[3]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[3]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[3]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn3.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn3.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn3.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 64);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *) may23_B.Receive_o1_p));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *) &may23_B.Receive_o2_b));
        }
      }

      /* path info */
      ssSetModelName(rts, "Receive");
      ssSetPath(rts, "may23/DataLogging/Poll Force Plates/plate1/Receive");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn3.params;
        ssSetSFcnParamsCount(rts, 9);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.Receive_P1_Size_h);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.Receive_P2_Size_l);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.Receive_P3_Size_p);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.Receive_P4_Size_k);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.Receive_P5_Size_n);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.Receive_P6_Size_b);
        ssSetSFcnParam(rts, 6, (mxArray*)may23_P.Receive_P7_Size_b);
        ssSetSFcnParam(rts, 7, (mxArray*)may23_P.Receive_P8_Size_i);
        ssSetSFcnParam(rts, 8, (mxArray*)may23_P.Receive_P9_Size_k);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.Receive_IWORK_k[0]);
      ssSetPWork(rts, (void **) &may23_DW.Receive_PWORK_c[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn3.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn3.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Receive_IWORK_k[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 2);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.Receive_PWORK_c[0]);
      }

      /* registration */
      slrtUDPReceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S61>/Receive1 (slrtUDPReceive) */
    {
      SimStruct *rts = may23_M->childSfunctions[4];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn4.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn4.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn4.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[4]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[4]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[4]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[4]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[4]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[4]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[4]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn4.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn4.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn4.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 64);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *) may23_B.Receive1_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *) &may23_B.Receive1_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "Receive1");
      ssSetPath(rts, "may23/DataLogging/Poll Force Plates/plate2/Receive1");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn4.params;
        ssSetSFcnParamsCount(rts, 9);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.Receive1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.Receive1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.Receive1_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.Receive1_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.Receive1_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.Receive1_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)may23_P.Receive1_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)may23_P.Receive1_P8_Size);
        ssSetSFcnParam(rts, 8, (mxArray*)may23_P.Receive1_P9_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.Receive1_IWORK[0]);
      ssSetPWork(rts, (void **) &may23_DW.Receive1_PWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn4.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn4.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Receive1_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 2);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.Receive1_PWORK[0]);
      }

      /* registration */
      slrtUDPReceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S62>/Send (slrtUDPSend) */
    {
      SimStruct *rts = may23_M->childSfunctions[5];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn5.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn5.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn5.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[5]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[5]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[5]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[5]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[5]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[5]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[5]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn5.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn5.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn5.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, may23_B.Convert1_a);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 34);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, (real_T*)&may23_ConstB.Width_h);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Send");
      ssSetPath(rts, "may23/DataLogging/Poll Force Plates/send poll 1/Send");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn5.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.Send_P1_Size_ki);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.Send_P2_Size_o);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.Send_P3_Size_a);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.Send_P4_Size_e);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.Send_P5_Size_j);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.Send_P6_Size_k);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.Send_IWORK_bh[0]);
      ssSetPWork(rts, (void **) &may23_DW.Send_PWORK_c);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn5.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn5.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Send_IWORK_bh[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.Send_PWORK_c);
      }

      /* registration */
      slrtUDPSend(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 34);
      ssSetInputPortDataType(rts, 0, SS_UINT8);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetInputPortUnit(rts, 0, 0);
      ssSetInputPortIsContinuousQuantity(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }

    /* Level2 S-Function Block: may23/<S63>/Send1 (slrtUDPSend) */
    {
      SimStruct *rts = may23_M->childSfunctions[6];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn6.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn6.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn6.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[6]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[6]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[6]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[6]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[6]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[6]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[6]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn6.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn6.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn6.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, may23_B.Convert1_a);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 34);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, (real_T*)&may23_ConstB.Width_gf);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Send1");
      ssSetPath(rts, "may23/DataLogging/Poll Force Plates/send poll 2/Send1");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn6.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.Send1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.Send1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.Send1_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.Send1_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.Send1_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.Send1_P6_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.Send1_IWORK[0]);
      ssSetPWork(rts, (void **) &may23_DW.Send1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn6.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn6.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Send1_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.Send1_PWORK);
      }

      /* registration */
      slrtUDPSend(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0005);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 2;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 34);
      ssSetInputPortDataType(rts, 0, SS_UINT8);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetInputPortUnit(rts, 0, 0);
      ssSetInputPortIsContinuousQuantity(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }

    /* Level2 S-Function Block: may23/<S102>/BKIN PDO Receive ElmoDrive (BKINethercatpdorxElmoDrive) */
    {
      SimStruct *rts = may23_M->childSfunctions[7];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn7.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn7.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn7.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[7]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[7]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[7]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[7]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[7]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[7]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[7]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn7.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 8);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn7.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        ssSetOutputPortUnit(rts, 4, 0);
        ssSetOutputPortUnit(rts, 5, 0);
        ssSetOutputPortUnit(rts, 6, 0);
        ssSetOutputPortUnit(rts, 7, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn7.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 4, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 5, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 6, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 7, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((uint16_T *) &may23_B.Statusword_d));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((uint32_T *) &may23_B.statusregister_n));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidth(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((int32_T *) &may23_B.primaryposition_n));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidth(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((int32_T *)
            &may23_B.secondaryposition_k));
        }

        /* port 4 */
        {
          _ssSetOutputPortNumDimensions(rts, 4, 1);
          ssSetOutputPortWidth(rts, 4, 1);
          ssSetOutputPortSignal(rts, 4, ((int32_T *) &may23_B.primaryvelocity_j));
        }

        /* port 5 */
        {
          _ssSetOutputPortNumDimensions(rts, 5, 1);
          ssSetOutputPortWidth(rts, 5, 1);
          ssSetOutputPortSignal(rts, 5, ((int16_T *) &may23_B.torque_f));
        }

        /* port 6 */
        {
          _ssSetOutputPortNumDimensions(rts, 6, 1);
          ssSetOutputPortWidth(rts, 6, 1);
          ssSetOutputPortSignal(rts, 6, ((int32_T *) &may23_B.digitalinputs));
        }

        /* port 7 */
        {
          _ssSetOutputPortNumDimensions(rts, 7, 1);
          ssSetOutputPortWidth(rts, 7, 1);
          ssSetOutputPortSignal(rts, 7, ((int8_T *)
            &may23_B.actualmodeofoperation_h));
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN PDO Receive ElmoDrive");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn7.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.BKINPDOReceiveElmoDrive_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.BKINPDOReceiveElmoDrive_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.BKINPDOReceiveElmoDrive_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.BKINPDOReceiveElmoDrive_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.BKINPDOReceiveElmoDrive_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.BKINPDOReceiveElmoDrive_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)may23_P.BKINPDOReceiveElmoDrive_P7_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINPDOReceiveElmoDrive_IWORK_b[0]);
      ssSetPWork(rts, (void **) &may23_DW.BKINPDOReceiveElmoDrive_PWORK_e);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn7.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn7.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 7);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINPDOReceiveElmoDrive_IWORK_b[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.BKINPDOReceiveElmoDrive_PWORK_e);
      }

      /* registration */
      BKINethercatpdorxElmoDrive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 1);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 5, 1);
      _ssSetOutputPortConnected(rts, 6, 1);
      _ssSetOutputPortConnected(rts, 7, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);
      _ssSetOutputPortBeingMerged(rts, 5, 0);
      _ssSetOutputPortBeingMerged(rts, 6, 0);
      _ssSetOutputPortBeingMerged(rts, 7, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S87>/BKIN EtherCAT PDO Transmit  (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[8];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn8.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn8.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn8.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[8]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[8]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[8]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[8]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[8]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[8]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[8]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn8.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn8.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn8.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.sf_Whistlestate.ControlWord);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit ");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/BKIN EtherCAT PDO Transmit ");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn8.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.BKINEtherCATPDOTransmit_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.BKINEtherCATPDOTransmit_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.BKINEtherCATPDOTransmit_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.BKINEtherCATPDOTransmit_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.BKINEtherCATPDOTransmit_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.BKINEtherCATPDOTransmit_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)may23_P.BKINEtherCATPDOTransmit_P7_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit_IWORK_b[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn8.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn8.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit_IWORK_b[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S122>/BKIN PDO Receive ElmoDrive (BKINethercatpdorxElmoDrive) */
    {
      SimStruct *rts = may23_M->childSfunctions[9];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn9.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn9.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn9.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[9]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[9]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[9]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[9]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[9]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[9]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[9]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn9.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 8);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn9.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        ssSetOutputPortUnit(rts, 4, 0);
        ssSetOutputPortUnit(rts, 5, 0);
        ssSetOutputPortUnit(rts, 6, 0);
        ssSetOutputPortUnit(rts, 7, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn9.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 4, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 5, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 6, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 7, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((uint16_T *) &may23_B.Statusword_n));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((uint32_T *) &may23_B.statusregister_h));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidth(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((int32_T *) &may23_B.primaryposition_o));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidth(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((int32_T *)
            &may23_B.secondaryposition_e));
        }

        /* port 4 */
        {
          _ssSetOutputPortNumDimensions(rts, 4, 1);
          ssSetOutputPortWidth(rts, 4, 1);
          ssSetOutputPortSignal(rts, 4, ((int32_T *) &may23_B.primaryvelocity_jy));
        }

        /* port 5 */
        {
          _ssSetOutputPortNumDimensions(rts, 5, 1);
          ssSetOutputPortWidth(rts, 5, 1);
          ssSetOutputPortSignal(rts, 5, ((int16_T *) &may23_B.torque_m));
        }

        /* port 6 */
        {
          _ssSetOutputPortNumDimensions(rts, 6, 1);
          ssSetOutputPortWidth(rts, 6, 1);
          ssSetOutputPortSignal(rts, 6, ((int32_T *) &may23_B.digitalinputs_n));
        }

        /* port 7 */
        {
          _ssSetOutputPortNumDimensions(rts, 7, 1);
          ssSetOutputPortWidth(rts, 7, 1);
          ssSetOutputPortSignal(rts, 7, ((int8_T *)
            &may23_B.actualmodeofoperation_hn));
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN PDO Receive ElmoDrive");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn9.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P1_Size_o);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P2_Size_i);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P3_Size_j);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P4_Size_m);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P5_Size_p);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P6_Size_d);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P7_Size_k);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINPDOReceiveElmoDrive_IWORK_a[0]);
      ssSetPWork(rts, (void **) &may23_DW.BKINPDOReceiveElmoDrive_PWORK_f);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn9.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn9.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 7);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINPDOReceiveElmoDrive_IWORK_a[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.BKINPDOReceiveElmoDrive_PWORK_f);
      }

      /* registration */
      BKINethercatpdorxElmoDrive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 1);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 5, 1);
      _ssSetOutputPortConnected(rts, 6, 1);
      _ssSetOutputPortConnected(rts, 7, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);
      _ssSetOutputPortBeingMerged(rts, 5, 0);
      _ssSetOutputPortBeingMerged(rts, 6, 0);
      _ssSetOutputPortBeingMerged(rts, 7, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S88>/BKIN EtherCAT PDO Transmit  (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[10];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn10.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn10.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn10.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[10]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[10]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[10]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[10]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[10]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[10]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[10]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn10.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn10.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn10.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.sf_Whistlestate_a.ControlWord);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit ");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/BKIN EtherCAT PDO Transmit ");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn10.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P1_Size_h);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P2_Size_a);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P3_Size_o);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P4_Size_g);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P5_Size_h);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P6_Size_h);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P7_Size_e);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit_IWORK_o[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn10.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn10.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit_IWORK_o[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S89>/BKIN EtherCAT PDO Transmit  (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[11];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn11.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn11.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn11.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[11]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[11]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[11]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[11]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[11]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[11]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[11]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn11.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn11.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn11.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.sf_MATLABFunction1_k.mode);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit ");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit ");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn11.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P1_Size_e);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P2_Size_e);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P3_Size_h);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P4_Size_k);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P5_Size_n);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P6_Size_hz);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P7_Size_m);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit_IWORK_k[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn11.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn11.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit_IWORK_k[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S89>/BKIN EtherCAT PDO Transmit 1 (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[12];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn12.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn12.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn12.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[12]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[12]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[12]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[12]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[12]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[12]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[12]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn12.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn12.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn12.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.sf_MATLABFunction1_k.mode);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit 1");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit 1");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn12.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P7_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit1_IWORK_o[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn12.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn12.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit1_IWORK_o[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S177>/BKIN PDO Receive ElmoDrive (BKINethercatpdorxElmoDrive) */
    {
      SimStruct *rts = may23_M->childSfunctions[13];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn13.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn13.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn13.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[13]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[13]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[13]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[13]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[13]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[13]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[13]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn13.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 8);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn13.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        ssSetOutputPortUnit(rts, 4, 0);
        ssSetOutputPortUnit(rts, 5, 0);
        ssSetOutputPortUnit(rts, 6, 0);
        ssSetOutputPortUnit(rts, 7, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn13.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 4, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 5, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 6, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 7, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((uint16_T *) &may23_B.Statusword));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((uint32_T *)
            &may23_B.BKINPDOReceiveElmoDrive_o2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidth(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((int32_T *) &may23_B.primaryposition));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidth(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((int32_T *) &may23_B.secondaryposition));
        }

        /* port 4 */
        {
          _ssSetOutputPortNumDimensions(rts, 4, 1);
          ssSetOutputPortWidth(rts, 4, 1);
          ssSetOutputPortSignal(rts, 4, ((int32_T *) &may23_B.primaryvelocity));
        }

        /* port 5 */
        {
          _ssSetOutputPortNumDimensions(rts, 5, 1);
          ssSetOutputPortWidth(rts, 5, 1);
          ssSetOutputPortSignal(rts, 5, ((int16_T *) &may23_B.torque_b));
        }

        /* port 6 */
        {
          _ssSetOutputPortNumDimensions(rts, 6, 1);
          ssSetOutputPortWidth(rts, 6, 1);
          ssSetOutputPortSignal(rts, 6, ((int32_T *) &may23_B.digitalinput));
        }

        /* port 7 */
        {
          _ssSetOutputPortNumDimensions(rts, 7, 1);
          ssSetOutputPortWidth(rts, 7, 1);
          ssSetOutputPortSignal(rts, 7, ((int8_T *)
            &may23_B.actualmodeofoperation));
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN PDO Receive ElmoDrive");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn13.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P1_Size_a);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P2_Size_i4);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P3_Size_b);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P4_Size_d);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P5_Size_d);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P6_Size_f);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P7_Size_b);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINPDOReceiveElmoDrive_IWORK[0]);
      ssSetPWork(rts, (void **) &may23_DW.BKINPDOReceiveElmoDrive_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn13.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn13.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 7);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINPDOReceiveElmoDrive_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.BKINPDOReceiveElmoDrive_PWORK);
      }

      /* registration */
      BKINethercatpdorxElmoDrive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 1);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 5, 1);
      _ssSetOutputPortConnected(rts, 6, 1);
      _ssSetOutputPortConnected(rts, 7, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);
      _ssSetOutputPortBeingMerged(rts, 5, 0);
      _ssSetOutputPortBeingMerged(rts, 6, 0);
      _ssSetOutputPortBeingMerged(rts, 7, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S162>/BKIN EtherCAT PDO Transmit  (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[14];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn14.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn14.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn14.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[14]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[14]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[14]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[14]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[14]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[14]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[14]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn14.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn14.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn14.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.sf_Whistlestate_l.ControlWord);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit ");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/BKIN EtherCAT PDO Transmit ");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn14.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P1_Size_o);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P2_Size_n);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P3_Size_k);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P4_Size_j);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P5_Size_j);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P6_Size_g);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P7_Size_d);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit_IWORK_p[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn14.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn14.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit_IWORK_p[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S197>/BKIN PDO Receive ElmoDrive (BKINethercatpdorxElmoDrive) */
    {
      SimStruct *rts = may23_M->childSfunctions[15];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn15.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn15.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn15.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[15]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[15]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[15]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[15]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[15]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[15]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[15]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn15.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 8);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn15.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        ssSetOutputPortUnit(rts, 4, 0);
        ssSetOutputPortUnit(rts, 5, 0);
        ssSetOutputPortUnit(rts, 6, 0);
        ssSetOutputPortUnit(rts, 7, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn15.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 4, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 5, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 6, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 7, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((uint16_T *) &may23_B.statusword));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((uint32_T *) &may23_B.statusregister));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidth(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((int32_T *) &may23_B.positionprimary));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidth(rts, 3, 1);
          ssSetOutputPortSignal(rts, 3, ((int32_T *) &may23_B.positionsecondary));
        }

        /* port 4 */
        {
          _ssSetOutputPortNumDimensions(rts, 4, 1);
          ssSetOutputPortWidth(rts, 4, 1);
          ssSetOutputPortSignal(rts, 4, ((int32_T *) &may23_B.velocityprimary));
        }

        /* port 5 */
        {
          _ssSetOutputPortNumDimensions(rts, 5, 1);
          ssSetOutputPortWidth(rts, 5, 1);
          ssSetOutputPortSignal(rts, 5, ((int16_T *) &may23_B.torque_i));
        }

        /* port 6 */
        {
          _ssSetOutputPortNumDimensions(rts, 6, 1);
          ssSetOutputPortWidth(rts, 6, 1);
          ssSetOutputPortSignal(rts, 6, ((int32_T *) &may23_B.digitalinput_o));
        }

        /* port 7 */
        {
          _ssSetOutputPortNumDimensions(rts, 7, 1);
          ssSetOutputPortWidth(rts, 7, 1);
          ssSetOutputPortSignal(rts, 7, ((int8_T *)
            &may23_B.actualmodeofoperation_c));
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN PDO Receive ElmoDrive");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn15.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P1_Size_oe);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P2_Size_b);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P3_Size_e);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P4_Size_k);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P5_Size_o);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P6_Size_o);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINPDOReceiveElmoDrive_P7_Size_a);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINPDOReceiveElmoDrive_IWORK_i[0]);
      ssSetPWork(rts, (void **) &may23_DW.BKINPDOReceiveElmoDrive_PWORK_k);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn15.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn15.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 7);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINPDOReceiveElmoDrive_IWORK_i[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.BKINPDOReceiveElmoDrive_PWORK_k);
      }

      /* registration */
      BKINethercatpdorxElmoDrive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 1);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 5, 1);
      _ssSetOutputPortConnected(rts, 6, 1);
      _ssSetOutputPortConnected(rts, 7, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);
      _ssSetOutputPortBeingMerged(rts, 5, 0);
      _ssSetOutputPortBeingMerged(rts, 6, 0);
      _ssSetOutputPortBeingMerged(rts, 7, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S163>/BKIN EtherCAT PDO Transmit  (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[16];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn16.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn16.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn16.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[16]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[16]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[16]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[16]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[16]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[16]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[16]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn16.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn16.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn16.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.sf_Whistlestate_m.ControlWord);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit ");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/BKIN EtherCAT PDO Transmit ");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn16.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P1_Size_j);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P2_Size_p);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P3_Size_l);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P4_Size_ki);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P5_Size_o);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P6_Size_d);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P7_Size_b);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit_IWORK_e[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn16.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn16.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit_IWORK_e[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S170>/BKIN EtherCAT PDO Transmit  (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[17];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn17.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn17.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn17.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[17]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[17]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[17]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[17]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[17]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[17]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[17]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn17.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn17.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn17.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.sf_MATLABFunction1_c.mode);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit ");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit ");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn17.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P1_Size_p);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P2_Size_k);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P3_Size_p);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P4_Size_m);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P5_Size_i);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P6_Size_g5);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P7_Size_g);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit_IWORK_c[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn17.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn17.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit_IWORK_c[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S170>/BKIN EtherCAT PDO Transmit 1 (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[18];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn18.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn18.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn18.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[18]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[18]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[18]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[18]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[18]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[18]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[18]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn18.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn18.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn18.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.sf_MATLABFunction1_c.mode);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit 1");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit 1");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn18.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P1_Size_j);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P2_Size_n);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P3_Size_c);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P4_Size_b);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P5_Size_g);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P6_Size_h);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P7_Size_f);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit1_IWORK_p[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn18.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn18.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit1_IWORK_p[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S257>/Send (slrtUDPSend) */
    {
      SimStruct *rts = may23_M->childSfunctions[19];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn19.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn19.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn19.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[19]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[19]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[19]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[19]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[19]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[19]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[19]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn19.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn19.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn19.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, may23_B.Pack_b);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 8);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, (real_T*)&may23_ConstB.Width_c);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Send");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Send");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn19.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.Send_P1_Size_b);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.Send_P2_Size_a);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.Send_P3_Size_ab);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.Send_P4_Size_j);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.Send_P5_Size_e);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.Send_P6_Size_e);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.Send_IWORK_b[0]);
      ssSetPWork(rts, (void **) &may23_DW.Send_PWORK_mg);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn19.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn19.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Send_IWORK_b[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.Send_PWORK_mg);
      }

      /* registration */
      slrtUDPSend(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 8);
      ssSetInputPortDataType(rts, 0, SS_UINT8);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetInputPortUnit(rts, 0, 0);
      ssSetInputPortIsContinuousQuantity(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }

    /* Level2 S-Function Block: may23/<S259>/Send (slrtUDPSend) */
    {
      SimStruct *rts = may23_M->childSfunctions[20];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn20.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn20.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn20.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[20]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[20]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[20]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[20]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[20]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[20]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[20]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn20.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn20.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn20.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, may23_B.Pack);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 8);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, (real_T*)&may23_ConstB.Width_i);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Send");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Send");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn20.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.Send_P1_Size_g);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.Send_P2_Size_i);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.Send_P3_Size_ak);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.Send_P4_Size_m);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.Send_P5_Size_f);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.Send_P6_Size_b);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.Send_IWORK_a[0]);
      ssSetPWork(rts, (void **) &may23_DW.Send_PWORK_m);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn20.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn20.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Send_IWORK_a[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.Send_PWORK_m);
      }

      /* registration */
      slrtUDPSend(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 8);
      ssSetInputPortDataType(rts, 0, SS_UINT8);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetInputPortUnit(rts, 0, 0);
      ssSetInputPortIsContinuousQuantity(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }

    /* Level2 S-Function Block: may23/<S252>/Receive from Robot 1 Force Sensor (slrtUDPReceive) */
    {
      SimStruct *rts = may23_M->childSfunctions[21];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn21.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn21.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn21.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[21]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[21]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[21]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[21]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[21]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[21]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[21]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn21.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn21.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn21.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 36);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *)
            may23_B.ReceivefromRobot1ForceSensor_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &may23_B.ReceivefromRobot1ForceSensor_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "Receive from Robot 1 Force Sensor");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Receive from Robot 1 Force Sensor");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn21.params;
        ssSetSFcnParamsCount(rts, 9);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.ReceivefromRobot1ForceSensor_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.ReceivefromRobot1ForceSensor_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.ReceivefromRobot1ForceSensor_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.ReceivefromRobot1ForceSensor_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.ReceivefromRobot1ForceSensor_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.ReceivefromRobot1ForceSensor_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.ReceivefromRobot1ForceSensor_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)
                       may23_P.ReceivefromRobot1ForceSensor_P8_Size);
        ssSetSFcnParam(rts, 8, (mxArray*)
                       may23_P.ReceivefromRobot1ForceSensor_P9_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.ReceivefromRobot1ForceSensor_IWORK[0]);
      ssSetPWork(rts, (void **) &may23_DW.ReceivefromRobot1ForceSensor_PWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn21.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn21.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.ReceivefromRobot1ForceSensor_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 2);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.ReceivefromRobot1ForceSensor_PWORK[0]);
      }

      /* registration */
      slrtUDPReceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S253>/Receive from Robot 2 Force Sensor (slrtUDPReceive) */
    {
      SimStruct *rts = may23_M->childSfunctions[22];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn22.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn22.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn22.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[22]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[22]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[22]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[22]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[22]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[22]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[22]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn22.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn22.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn22.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 36);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *)
            may23_B.ReceivefromRobot2ForceSensor_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &may23_B.ReceivefromRobot2ForceSensor_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "Receive from Robot 2 Force Sensor");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Receive from Robot 2 Force Sensor");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn22.params;
        ssSetSFcnParamsCount(rts, 9);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.ReceivefromRobot2ForceSensor_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.ReceivefromRobot2ForceSensor_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.ReceivefromRobot2ForceSensor_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.ReceivefromRobot2ForceSensor_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.ReceivefromRobot2ForceSensor_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.ReceivefromRobot2ForceSensor_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.ReceivefromRobot2ForceSensor_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)
                       may23_P.ReceivefromRobot2ForceSensor_P8_Size);
        ssSetSFcnParam(rts, 8, (mxArray*)
                       may23_P.ReceivefromRobot2ForceSensor_P9_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.ReceivefromRobot2ForceSensor_IWORK[0]);
      ssSetPWork(rts, (void **) &may23_DW.ReceivefromRobot2ForceSensor_PWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn22.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn22.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.ReceivefromRobot2ForceSensor_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 2);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.ReceivefromRobot2ForceSensor_PWORK[0]);
      }

      /* registration */
      slrtUDPReceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S269>/Read (mcc_readmem) */
    {
      SimStruct *rts = may23_M->childSfunctions[23];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn23.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn23.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn23.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[23]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[23]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[23]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[23]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[23]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[23]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[23]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn23.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn23.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn23.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          uint32_T const **sfcnUPtrs = (uint32_T const **)
            &may23_M->NonInlinedSFcns.Sfcn23.UPtrs0;
          sfcnUPtrs[0] = &may23_B.DataTypeConversion_c;
          sfcnUPtrs[1] = &may23_B.DataTypeConversion2_o;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 2);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn23.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn23.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn23.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((real32_T *) &may23_B.Read_h));
        }
      }

      /* path info */
      ssSetModelName(rts, "Read");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Read DPRAM/Read");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* work vectors */
      ssSetPWork(rts, (void **) &may23_DW.Read_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn23.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn23.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Read_PWORK);
      }

      /* registration */
      mcc_readmem(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S271>/Write (mcc_writemem) */
    {
      SimStruct *rts = may23_M->childSfunctions[24];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn24.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn24.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn24.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[24]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[24]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[24]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[24]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[24]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[24]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[24]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn24.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn24.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn24.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          uint32_T const **sfcnUPtrs = (uint32_T const **)
            &may23_M->NonInlinedSFcns.Sfcn24.UPtrs0;
          sfcnUPtrs[0] = &may23_B.DataTypeConversion_n3;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }

        /* port 1 */
        {
          real32_T const **sfcnUPtrs = (real32_T const **)
            &may23_M->NonInlinedSFcns.Sfcn24.UPtrs1;
          sfcnUPtrs[0] = &may23_B.DataTypeConversion1_o3;
          ssSetInputPortSignalPtrs(rts, 1, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Write");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Write DPRAM/Write");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* work vectors */
      ssSetPWork(rts, (void **) &may23_DW.Write_PWORK_n);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn24.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn24.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Write_PWORK_n);
      }

      /* registration */
      mcc_writemem(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }

    /* Level2 S-Function Block: may23/<S262>/S-Function (mcc_pollall) */
    {
      SimStruct *rts = may23_M->childSfunctions[25];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn25.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn25.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn25.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[25]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[25]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[25]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[25]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[25]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[25]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[25]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 3);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn25.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn25.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        ssSetInputPortUnit(rts, 2, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn25.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);
        ssSetInputPortIsContinuousQuantity(rts, 2, 0);

        /* port 0 */
        {
          real32_T const **sfcnUPtrs = (real32_T const **)
            &may23_M->NonInlinedSFcns.Sfcn25.UPtrs0;

          {
            int_T i1;
            const real32_T *u0 = may23_B.DataTypeConversion_g5x;
            for (i1=0; i1 < 10; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }

          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 10);
        }

        /* port 1 */
        {
          real32_T const **sfcnUPtrs = (real32_T const **)
            &may23_M->NonInlinedSFcns.Sfcn25.UPtrs1;

          {
            int_T i1;
            const real32_T *u1 = may23_B.DataTypeConversion1_pf;
            for (i1=0; i1 < 10; i1++) {
              sfcnUPtrs[i1] = &u1[i1];
            }
          }

          ssSetInputPortSignalPtrs(rts, 1, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 10);
        }

        /* port 2 */
        {
          real32_T const **sfcnUPtrs = (real32_T const **)
            &may23_M->NonInlinedSFcns.Sfcn25.UPtrs2;
          sfcnUPtrs[0] = &may23_B.DataTypeConversion2_n;
          ssSetInputPortSignalPtrs(rts, 2, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidth(rts, 2, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn25.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 10);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn25.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        ssSetOutputPortUnit(rts, 4, 0);
        ssSetOutputPortUnit(rts, 5, 0);
        ssSetOutputPortUnit(rts, 6, 0);
        ssSetOutputPortUnit(rts, 7, 0);
        ssSetOutputPortUnit(rts, 8, 0);
        ssSetOutputPortUnit(rts, 9, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn25.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 4, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 5, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 6, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 7, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 8, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 9, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 10);
          ssSetOutputPortSignal(rts, 0, ((real32_T *) may23_B.SFunction_o1_j));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 10);
          ssSetOutputPortSignal(rts, 1, ((real32_T *) may23_B.SFunction_o2));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidth(rts, 2, 2);
          ssSetOutputPortSignal(rts, 2, ((uint32_T *) may23_B.SFunction_o3));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidth(rts, 3, 4);
          ssSetOutputPortSignal(rts, 3, ((real32_T *) may23_B.SFunction_o4));
        }

        /* port 4 */
        {
          _ssSetOutputPortNumDimensions(rts, 4, 1);
          ssSetOutputPortWidth(rts, 4, 6);
          ssSetOutputPortSignal(rts, 4, ((real32_T *) may23_B.SFunction_o5));
        }

        /* port 5 */
        {
          _ssSetOutputPortNumDimensions(rts, 5, 1);
          ssSetOutputPortWidth(rts, 5, 6);
          ssSetOutputPortSignal(rts, 5, ((real32_T *) may23_B.SFunction_o6));
        }

        /* port 6 */
        {
          _ssSetOutputPortNumDimensions(rts, 6, 1);
          ssSetOutputPortWidth(rts, 6, 1);
          ssSetOutputPortSignal(rts, 6, ((uint32_T *) &may23_B.SFunction_o7));
        }

        /* port 7 */
        {
          _ssSetOutputPortNumDimensions(rts, 7, 1);
          ssSetOutputPortWidth(rts, 7, 1);
          ssSetOutputPortSignal(rts, 7, ((uint32_T *) &may23_B.SFunction_o8));
        }

        /* port 8 */
        {
          _ssSetOutputPortNumDimensions(rts, 8, 1);
          ssSetOutputPortWidth(rts, 8, 3);
          ssSetOutputPortSignal(rts, 8, ((uint32_T *) may23_B.SFunction_o9));
        }

        /* port 9 */
        {
          _ssSetOutputPortNumDimensions(rts, 9, 1);
          ssSetOutputPortWidth(rts, 9, 1);
          ssSetOutputPortSignal(rts, 9, ((real32_T *) &may23_B.SFunction_o10));
        }
      }

      /* path info */
      ssSetModelName(rts, "S-Function");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/S-Function");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* work vectors */
      ssSetPWork(rts, (void **) &may23_DW.SFunction_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn25.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn25.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.SFunction_PWORK);
      }

      /* registration */
      mcc_pollall(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 2, 1);
      _ssSetOutputPortConnected(rts, 3, 1);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 5, 1);
      _ssSetOutputPortConnected(rts, 6, 1);
      _ssSetOutputPortConnected(rts, 7, 0);
      _ssSetOutputPortConnected(rts, 8, 1);
      _ssSetOutputPortConnected(rts, 9, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);
      _ssSetOutputPortBeingMerged(rts, 5, 0);
      _ssSetOutputPortBeingMerged(rts, 6, 0);
      _ssSetOutputPortBeingMerged(rts, 7, 0);
      _ssSetOutputPortBeingMerged(rts, 8, 0);
      _ssSetOutputPortBeingMerged(rts, 9, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
    }

    /* Level2 S-Function Block: may23/<S264>/Write (mcc_writemem) */
    {
      SimStruct *rts = may23_M->childSfunctions[26];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn26.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn26.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn26.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[26]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[26]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[26]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[26]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[26]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[26]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[26]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn26.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn26.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn26.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          uint32_T const **sfcnUPtrs = (uint32_T const **)
            &may23_M->NonInlinedSFcns.Sfcn26.UPtrs0;
          sfcnUPtrs[0] = &may23_B.DataTypeConversion_g5;
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }

        /* port 1 */
        {
          real32_T const **sfcnUPtrs = (real32_T const **)
            &may23_M->NonInlinedSFcns.Sfcn26.UPtrs1;
          sfcnUPtrs[0] = &may23_B.y_h;
          ssSetInputPortSignalPtrs(rts, 1, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Write");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Write");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* work vectors */
      ssSetPWork(rts, (void **) &may23_DW.Write_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn26.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn26.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Write_PWORK);
      }

      /* registration */
      mcc_writemem(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }

    /* Level2 S-Function Block: may23/<S276>/S-Function (kinarmfromfile) */
    {
      SimStruct *rts = may23_M->childSfunctions[27];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn27.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn27.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn27.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[27]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[27]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[27]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[27]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[27]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[27]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[27]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn27.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 1);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn27.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn27.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 52);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *) may23_B.SFunction));
        }
      }

      /* path info */
      ssSetModelName(rts, "S-Function");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/bkin_file_source/Data receive/S-Function");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn27.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.SFunction_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.SFunction_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.SFunction_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.SFunction_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.SFunction_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.SFunction_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)may23_P.SFunction_P7_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.SFunction_IWORK_g[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn27.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn27.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.SFunction_IWORK_g[0]);
      }

      /* registration */
      kinarmfromfile(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 3;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S283>/Receive (slrtUDPReceive) */
    {
      SimStruct *rts = may23_M->childSfunctions[28];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn28.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn28.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn28.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[28]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[28]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[28]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[28]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[28]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[28]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[28]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn28.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn28.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn28.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 16);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *) may23_B.Receive_o1_i));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *) &may23_B.Receive_o2_l));
        }
      }

      /* path info */
      ssSetModelName(rts, "Receive");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Receive");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn28.params;
        ssSetSFcnParamsCount(rts, 9);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.Receive_P1_Size_d);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.Receive_P2_Size_c);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.Receive_P3_Size_o);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.Receive_P4_Size_n);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.Receive_P5_Size_p);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.Receive_P6_Size_m);
        ssSetSFcnParam(rts, 6, (mxArray*)may23_P.Receive_P7_Size_k);
        ssSetSFcnParam(rts, 7, (mxArray*)may23_P.Receive_P8_Size_o);
        ssSetSFcnParam(rts, 8, (mxArray*)may23_P.Receive_P9_Size_c);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.Receive_IWORK_c[0]);
      ssSetPWork(rts, (void **) &may23_DW.Receive_PWORK_o[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn28.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn28.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Receive_IWORK_c[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 2);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.Receive_PWORK_o[0]);
      }

      /* registration */
      slrtUDPReceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S81>/BKIN EtherCAT PDO Transmit  (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[29];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn29.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn29.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn29.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[29]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[29]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[29]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[29]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[29]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[29]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[29]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn29.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn29.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn29.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.drive1);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit ");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit ");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn29.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P1_Size_g);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P2_Size_j);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P3_Size_c);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P4_Size_o);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P5_Size_a);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P6_Size_j);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit_P7_Size_h);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit_IWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn29.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn29.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit_IWORK[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S81>/BKIN EtherCAT PDO Transmit 1 (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[30];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn30.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn30.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn30.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[30]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[30]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[30]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[30]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[30]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[30]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[30]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn30.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn30.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn30.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.drive2);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit 1");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 1");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn30.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P1_Size_e);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P2_Size_e);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P3_Size_m);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P4_Size_l);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P5_Size_d);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P6_Size_n);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P7_Size_p);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit1_IWORK_a[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn30.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn30.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit1_IWORK_a[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S81>/BKIN EtherCAT PDO Transmit 2 (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[31];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn31.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn31.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn31.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[31]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[31]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[31]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[31]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[31]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[31]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[31]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn31.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn31.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn31.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.drive3);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit 2");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 2");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn31.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P7_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit2_IWORK_af[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn31.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn31.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit2_IWORK_af[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S81>/BKIN EtherCAT PDO Transmit 3 (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[32];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn32.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn32.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn32.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[32]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[32]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[32]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[32]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[32]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[32]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[32]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn32.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn32.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn32.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.drive4);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit 3");
      ssSetPath(rts,
                "may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 3");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn32.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit3_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit3_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit3_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit3_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit3_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit3_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit3_P7_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit3_IWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn32.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn32.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit3_IWORK[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S31>/S-Function (eyelink_unpack) */
    {
      SimStruct *rts = may23_M->childSfunctions[33];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn33.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn33.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn33.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[33]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[33]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[33]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[33]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[33]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[33]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[33]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn33.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn33.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn33.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          uint8_T const **sfcnUPtrs = (uint8_T const **)
            &may23_M->NonInlinedSFcns.Sfcn33.UPtrs0;

          {
            int_T i1;
            const uint8_T *u0 = may23_B.pack_out;
            for (i1=0; i1 < 512; i1++) {
              sfcnUPtrs[i1] = &u0[i1];
            }
          }

          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 512);
        }

        /* port 1 */
        {
          int32_T const **sfcnUPtrs = (int32_T const **)
            &may23_M->NonInlinedSFcns.Sfcn33.UPtrs1;
          sfcnUPtrs[0] = &may23_B.len_out;
          ssSetInputPortSignalPtrs(rts, 1, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn33.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 18);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn33.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        ssSetOutputPortUnit(rts, 2, 0);
        ssSetOutputPortUnit(rts, 3, 0);
        ssSetOutputPortUnit(rts, 4, 0);
        ssSetOutputPortUnit(rts, 5, 0);
        ssSetOutputPortUnit(rts, 6, 0);
        ssSetOutputPortUnit(rts, 7, 0);
        ssSetOutputPortUnit(rts, 8, 0);
        ssSetOutputPortUnit(rts, 9, 0);
        ssSetOutputPortUnit(rts, 10, 0);
        ssSetOutputPortUnit(rts, 11, 0);
        ssSetOutputPortUnit(rts, 12, 0);
        ssSetOutputPortUnit(rts, 13, 0);
        ssSetOutputPortUnit(rts, 14, 0);
        ssSetOutputPortUnit(rts, 15, 0);
        ssSetOutputPortUnit(rts, 16, 0);
        ssSetOutputPortUnit(rts, 17, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn33.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 2, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 3, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 4, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 5, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 6, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 7, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 8, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 9, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 10, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 11, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 12, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 13, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 14, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 15, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 16, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 17, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((uint32_T *) &may23_B.SFunction_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((int16_T *) &may23_B.SAMPE_TYPE));
        }

        /* port 2 */
        {
          _ssSetOutputPortNumDimensions(rts, 2, 1);
          ssSetOutputPortWidth(rts, 2, 1);
          ssSetOutputPortSignal(rts, 2, ((uint16_T *) &may23_B.ContentFlags));
        }

        /* port 3 */
        {
          _ssSetOutputPortNumDimensions(rts, 3, 1);
          ssSetOutputPortWidth(rts, 3, 2);
          ssSetOutputPortSignal(rts, 3, ((real32_T *) may23_B.pupil_X));
        }

        /* port 4 */
        {
          _ssSetOutputPortNumDimensions(rts, 4, 1);
          ssSetOutputPortWidth(rts, 4, 2);
          ssSetOutputPortSignal(rts, 4, ((real32_T *) may23_B.pupilY));
        }

        /* port 5 */
        {
          _ssSetOutputPortNumDimensions(rts, 5, 1);
          ssSetOutputPortWidth(rts, 5, 2);
          ssSetOutputPortSignal(rts, 5, ((real32_T *) may23_B.HREFX));
        }

        /* port 6 */
        {
          _ssSetOutputPortNumDimensions(rts, 6, 1);
          ssSetOutputPortWidth(rts, 6, 2);
          ssSetOutputPortSignal(rts, 6, ((real32_T *) may23_B.HREFY));
        }

        /* port 7 */
        {
          _ssSetOutputPortNumDimensions(rts, 7, 1);
          ssSetOutputPortWidth(rts, 7, 2);
          ssSetOutputPortSignal(rts, 7, ((real32_T *) may23_B.pupilarea));
        }

        /* port 8 */
        {
          _ssSetOutputPortNumDimensions(rts, 8, 1);
          ssSetOutputPortWidth(rts, 8, 2);
          ssSetOutputPortSignal(rts, 8, ((real32_T *) may23_B.gaze_X));
        }

        /* port 9 */
        {
          _ssSetOutputPortNumDimensions(rts, 9, 1);
          ssSetOutputPortWidth(rts, 9, 2);
          ssSetOutputPortSignal(rts, 9, ((real32_T *) may23_B.gaze_Y));
        }

        /* port 10 */
        {
          _ssSetOutputPortNumDimensions(rts, 10, 1);
          ssSetOutputPortWidth(rts, 10, 1);
          ssSetOutputPortSignal(rts, 10, ((real32_T *) &may23_B.resolutionX));
        }

        /* port 11 */
        {
          _ssSetOutputPortNumDimensions(rts, 11, 1);
          ssSetOutputPortWidth(rts, 11, 1);
          ssSetOutputPortSignal(rts, 11, ((real32_T *) &may23_B.resolutionY));
        }

        /* port 12 */
        {
          _ssSetOutputPortNumDimensions(rts, 12, 1);
          ssSetOutputPortWidth(rts, 12, 1);
          ssSetOutputPortSignal(rts, 12, ((uint16_T *) &may23_B.statusflags));
        }

        /* port 13 */
        {
          _ssSetOutputPortNumDimensions(rts, 13, 1);
          ssSetOutputPortWidth(rts, 13, 1);
          ssSetOutputPortSignal(rts, 13, ((uint16_T *) &may23_B.extrainput));
        }

        /* port 14 */
        {
          _ssSetOutputPortNumDimensions(rts, 14, 1);
          ssSetOutputPortWidth(rts, 14, 1);
          ssSetOutputPortSignal(rts, 14, ((uint16_T *) &may23_B.buttons));
        }

        /* port 15 */
        {
          _ssSetOutputPortNumDimensions(rts, 15, 1);
          ssSetOutputPortWidth(rts, 15, 1);
          ssSetOutputPortSignal(rts, 15, ((int16_T *) &may23_B.htype));
        }

        /* port 16 */
        {
          _ssSetOutputPortNumDimensions(rts, 16, 1);
          ssSetOutputPortWidth(rts, 16, 8);
          ssSetOutputPortSignal(rts, 16, ((int16_T *) may23_B.hdata));
        }

        /* port 17 */
        {
          _ssSetOutputPortNumDimensions(rts, 17, 1);
          ssSetOutputPortWidth(rts, 17, 3);
          ssSetOutputPortSignal(rts, 17, ((uint32_T *) may23_B.SFunction_o18));
        }
      }

      /* path info */
      ssSetModelName(rts, "S-Function");
      ssSetPath(rts, "may23/DataLogging/Receive_Gaze/S-Function");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* registration */
      eyelink_unpack(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortConnected(rts, 2, 0);
      _ssSetOutputPortConnected(rts, 3, 1);
      _ssSetOutputPortConnected(rts, 4, 1);
      _ssSetOutputPortConnected(rts, 5, 1);
      _ssSetOutputPortConnected(rts, 6, 1);
      _ssSetOutputPortConnected(rts, 7, 1);
      _ssSetOutputPortConnected(rts, 8, 1);
      _ssSetOutputPortConnected(rts, 9, 1);
      _ssSetOutputPortConnected(rts, 10, 0);
      _ssSetOutputPortConnected(rts, 11, 0);
      _ssSetOutputPortConnected(rts, 12, 1);
      _ssSetOutputPortConnected(rts, 13, 0);
      _ssSetOutputPortConnected(rts, 14, 0);
      _ssSetOutputPortConnected(rts, 15, 0);
      _ssSetOutputPortConnected(rts, 16, 1);
      _ssSetOutputPortConnected(rts, 17, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 2, 0);
      _ssSetOutputPortBeingMerged(rts, 3, 0);
      _ssSetOutputPortBeingMerged(rts, 4, 0);
      _ssSetOutputPortBeingMerged(rts, 5, 0);
      _ssSetOutputPortBeingMerged(rts, 6, 0);
      _ssSetOutputPortBeingMerged(rts, 7, 0);
      _ssSetOutputPortBeingMerged(rts, 8, 0);
      _ssSetOutputPortBeingMerged(rts, 9, 0);
      _ssSetOutputPortBeingMerged(rts, 10, 0);
      _ssSetOutputPortBeingMerged(rts, 11, 0);
      _ssSetOutputPortBeingMerged(rts, 12, 0);
      _ssSetOutputPortBeingMerged(rts, 13, 0);
      _ssSetOutputPortBeingMerged(rts, 14, 0);
      _ssSetOutputPortBeingMerged(rts, 15, 0);
      _ssSetOutputPortBeingMerged(rts, 16, 0);
      _ssSetOutputPortBeingMerged(rts, 17, 0);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }

    /* Level2 S-Function Block: may23/<S31>/Receive (slrtUDPReceive) */
    {
      SimStruct *rts = may23_M->childSfunctions[34];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn34.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn34.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn34.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[34]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[34]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[34]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[34]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[34]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[34]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[34]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn34.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn34.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn34.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 512);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *) may23_B.Receive_o1_o));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *) &may23_B.Receive_o2_f));
        }
      }

      /* path info */
      ssSetModelName(rts, "Receive");
      ssSetPath(rts, "may23/DataLogging/Receive_Gaze/Receive");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn34.params;
        ssSetSFcnParamsCount(rts, 9);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.Receive_P1_Size_e);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.Receive_P2_Size_j);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.Receive_P3_Size_l);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.Receive_P4_Size_b);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.Receive_P5_Size_j);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.Receive_P6_Size_a);
        ssSetSFcnParam(rts, 6, (mxArray*)may23_P.Receive_P7_Size_i);
        ssSetSFcnParam(rts, 7, (mxArray*)may23_P.Receive_P8_Size_a);
        ssSetSFcnParam(rts, 8, (mxArray*)may23_P.Receive_P9_Size_i);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.Receive_IWORK_g[0]);
      ssSetPWork(rts, (void **) &may23_DW.Receive_PWORK_g[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn34.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn34.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Receive_IWORK_g[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 2);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.Receive_PWORK_g[0]);
      }

      /* registration */
      slrtUDPReceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S317>/BKIN EtherCAT PDO Transmit 1 (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[35];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn35.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn35.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn35.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[35]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[35]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[35]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[35]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[35]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[35]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[35]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn35.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn35.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn35.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.ecatTorques[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit 1");
      ssSetPath(rts,
                "may23/DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 1");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn35.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P1_Size_b);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P2_Size_et);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P3_Size_l);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P4_Size_h);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P5_Size_g0);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P6_Size_e);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P7_Size_o);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit1_IWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn35.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn35.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit1_IWORK[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S317>/BKIN EtherCAT PDO Transmit 2 (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[36];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn36.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn36.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn36.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[36]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[36]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[36]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[36]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[36]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[36]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[36]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn36.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn36.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn36.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.ecatTorques[1]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit 2");
      ssSetPath(rts,
                "may23/DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 2");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn36.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P1_Size_g);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P2_Size_l);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P3_Size_f);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P4_Size_k);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P5_Size_h);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P6_Size_a);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P7_Size_l);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit2_IWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn36.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn36.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit2_IWORK[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S318>/BKIN EtherCAT PDO Transmit 1 (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[37];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn37.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn37.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn37.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[37]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[37]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[37]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[37]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[37]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[37]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[37]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn37.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn37.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn37.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.ecatTorques[2]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit 1");
      ssSetPath(rts,
                "may23/DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 1");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn37.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P1_Size_a);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P2_Size_o);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P3_Size_d);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P4_Size_o);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P5_Size_a);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P6_Size_k);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit1_P7_Size_l);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit1_IWORK_h[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn37.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn37.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit1_IWORK_h[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S318>/BKIN EtherCAT PDO Transmit 2 (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[38];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn38.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn38.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn38.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[38]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[38]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[38]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[38]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[38]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[38]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[38]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 1);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn38.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn38.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn38.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, &may23_B.ecatTorques[3]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "BKIN EtherCAT PDO Transmit 2");
      ssSetPath(rts,
                "may23/DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 2");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn38.params;
        ssSetSFcnParamsCount(rts, 7);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P1_Size_e);
        ssSetSFcnParam(rts, 1, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P2_Size_a);
        ssSetSFcnParam(rts, 2, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P3_Size_d);
        ssSetSFcnParam(rts, 3, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P4_Size_j);
        ssSetSFcnParam(rts, 4, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P5_Size_o);
        ssSetSFcnParam(rts, 5, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P6_Size_n);
        ssSetSFcnParam(rts, 6, (mxArray*)
                       may23_P.BKINEtherCATPDOTransmit2_P7_Size_e);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.BKINEtherCATPDOTransmit2_IWORK_a[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn38.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn38.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 23);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.BKINEtherCATPDOTransmit2_IWORK_a[0]);
      }

      /* registration */
      BKINethercatpdotx(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
    }

    /* Level2 S-Function Block: may23/<S313>/S-Function1 (mcc_apply_loads) */
    {
      SimStruct *rts = may23_M->childSfunctions[39];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn39.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn39.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn39.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[39]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[39]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[39]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[39]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[39]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[39]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[39]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 3);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn39.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn39.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        ssSetInputPortUnit(rts, 2, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn39.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);
        ssSetInputPortIsContinuousQuantity(rts, 2, 0);

        /* port 0 */
        {
          real32_T const **sfcnUPtrs = (real32_T const **)
            &may23_M->NonInlinedSFcns.Sfcn39.UPtrs0;
          sfcnUPtrs[0] = may23_B.DataTypeConversion6;
          sfcnUPtrs[1] = &may23_B.DataTypeConversion6[1];
          sfcnUPtrs[2] = &may23_B.DataTypeConversion6[2];
          sfcnUPtrs[3] = &may23_B.DataTypeConversion6[3];
          ssSetInputPortSignalPtrs(rts, 0, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 4);
        }

        /* port 1 */
        {
          real32_T const **sfcnUPtrs = (real32_T const **)
            &may23_M->NonInlinedSFcns.Sfcn39.UPtrs1;

          {
            int_T i1;
            const real32_T *u1 = may23_B.DataTypeConversion_nc;
            for (i1=0; i1 < 6; i1++) {
              sfcnUPtrs[i1] = &u1[i1];
            }
          }

          ssSetInputPortSignalPtrs(rts, 1, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 6);
        }

        /* port 2 */
        {
          real32_T const **sfcnUPtrs = (real32_T const **)
            &may23_M->NonInlinedSFcns.Sfcn39.UPtrs2;

          {
            int_T i1;
            const real32_T *u2 = may23_B.DataTypeConversion1_px;
            for (i1=0; i1 < 6; i1++) {
              sfcnUPtrs[i1] = &u2[i1];
            }
          }

          ssSetInputPortSignalPtrs(rts, 2, (InputPtrsType)&sfcnUPtrs[0]);
          _ssSetInputPortNumDimensions(rts, 2, 1);
          ssSetInputPortWidth(rts, 2, 6);
        }
      }

      /* path info */
      ssSetModelName(rts, "S-Function1");
      ssSetPath(rts,
                "may23/DataLogging/apply loads/apply pmac loads/S-Function1");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* work vectors */
      ssSetPWork(rts, (void **) &may23_DW.SFunction1_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn39.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn39.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* PWORK */
        ssSetDWorkWidth(rts, 0, 1);
        ssSetDWorkDataType(rts, 0,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.SFunction1_PWORK);
      }

      /* registration */
      mcc_apply_loads(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);
      _ssSetInputPortConnected(rts, 2, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
      ssSetInputPortBufferDstPort(rts, 2, -1);
    }

    /* Level2 S-Function Block: may23/<S3>/ICH7 (ich10) */
    {
      SimStruct *rts = may23_M->childSfunctions[40];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn40.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn40.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn40.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[40]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[40]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[40]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[40]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[40]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[40]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[40]);
      }

      /* path info */
      ssSetModelName(rts, "ICH7");
      ssSetPath(rts, "may23/GUI Control/ICH7");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.ICH7_IWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn40.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn40.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 1);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 5);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.ICH7_IWORK[0]);
      }

      /* registration */
      ich10(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.0);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 0;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S335>/Run Command Receive (slrtUDPReceive) */
    {
      SimStruct *rts = may23_M->childSfunctions[41];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn41.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn41.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn41.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[41]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[41]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[41]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[41]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[41]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[41]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[41]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn41.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn41.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn41.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 1);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *)
            &may23_B.RunCommandReceive_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *)
            &may23_B.RunCommandReceive_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "Run Command Receive");
      ssSetPath(rts,
                "may23/GUI Control/Run Command Subsystem/Run Command Receive");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn41.params;
        ssSetSFcnParamsCount(rts, 9);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.RunCommandReceive_P1_Size);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.RunCommandReceive_P2_Size);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.RunCommandReceive_P3_Size);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.RunCommandReceive_P4_Size);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.RunCommandReceive_P5_Size);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.RunCommandReceive_P6_Size);
        ssSetSFcnParam(rts, 6, (mxArray*)may23_P.RunCommandReceive_P7_Size);
        ssSetSFcnParam(rts, 7, (mxArray*)may23_P.RunCommandReceive_P8_Size);
        ssSetSFcnParam(rts, 8, (mxArray*)may23_P.RunCommandReceive_P9_Size);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.RunCommandReceive_IWORK[0]);
      ssSetPWork(rts, (void **) &may23_DW.RunCommandReceive_PWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn41.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn41.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.RunCommandReceive_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 2);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.RunCommandReceive_PWORK[0]);
      }

      /* registration */
      slrtUDPReceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 0);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S9>/Receive (slrtUDPReceive) */
    {
      SimStruct *rts = may23_M->childSfunctions[42];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn42.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn42.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn42.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[42]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[42]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[42]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[42]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[42]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[42]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[42]);
      }

      /* outputs */
      {
        ssSetPortInfoForOutputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn42.outputPortInfo[0]);
        _ssSetNumOutputPorts(rts, 2);
        _ssSetPortInfo2ForOutputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn42.outputPortUnits[0]);
        ssSetOutputPortUnit(rts, 0, 0);
        ssSetOutputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForOutputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn42.outputPortCoSimAttribute[0]);
        ssSetOutputPortIsContinuousQuantity(rts, 0, 0);
        ssSetOutputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          _ssSetOutputPortNumDimensions(rts, 0, 1);
          ssSetOutputPortWidth(rts, 0, 4);
          ssSetOutputPortSignal(rts, 0, ((uint8_T *) may23_B.Receive_o1));
        }

        /* port 1 */
        {
          _ssSetOutputPortNumDimensions(rts, 1, 1);
          ssSetOutputPortWidth(rts, 1, 1);
          ssSetOutputPortSignal(rts, 1, ((real_T *) &may23_B.Receive_o2));
        }
      }

      /* path info */
      ssSetModelName(rts, "Receive");
      ssSetPath(rts, "may23/Process_Video_CMD/Receive");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn42.params;
        ssSetSFcnParamsCount(rts, 9);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.Receive_P1_Size_k);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.Receive_P2_Size_l1);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.Receive_P3_Size_k);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.Receive_P4_Size_c);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.Receive_P5_Size_g);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.Receive_P6_Size_o);
        ssSetSFcnParam(rts, 6, (mxArray*)may23_P.Receive_P7_Size_c);
        ssSetSFcnParam(rts, 7, (mxArray*)may23_P.Receive_P8_Size_g);
        ssSetSFcnParam(rts, 8, (mxArray*)may23_P.Receive_P9_Size_j);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.Receive_IWORK[0]);
      ssSetPWork(rts, (void **) &may23_DW.Receive_PWORK[0]);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn42.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn42.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 2);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Receive_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 2);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.Receive_PWORK[0]);
      }

      /* registration */
      slrtUDPReceive(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.00025);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 1;

      /* set compiled values of dynamic vector attributes */
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetOutputPortConnected(rts, 0, 1);
      _ssSetOutputPortConnected(rts, 1, 1);
      _ssSetOutputPortBeingMerged(rts, 0, 0);
      _ssSetOutputPortBeingMerged(rts, 1, 0);

      /* Update the BufferDstPort flags for each input port */
    }

    /* Level2 S-Function Block: may23/<S9>/Send (slrtUDPSend) */
    {
      SimStruct *rts = may23_M->childSfunctions[43];

      /* timing info */
      time_T *sfcnPeriod = may23_M->NonInlinedSFcns.Sfcn43.sfcnPeriod;
      time_T *sfcnOffset = may23_M->NonInlinedSFcns.Sfcn43.sfcnOffset;
      int_T *sfcnTsMap = may23_M->NonInlinedSFcns.Sfcn43.sfcnTsMap;
      (void) memset((void*)sfcnPeriod, 0,
                    sizeof(time_T)*1);
      (void) memset((void*)sfcnOffset, 0,
                    sizeof(time_T)*1);
      ssSetSampleTimePtr(rts, &sfcnPeriod[0]);
      ssSetOffsetTimePtr(rts, &sfcnOffset[0]);
      ssSetSampleTimeTaskIDPtr(rts, sfcnTsMap);

      {
        ssSetBlkInfo2Ptr(rts, &may23_M->NonInlinedSFcns.blkInfo2[43]);
      }

      _ssSetBlkInfo2PortInfo2Ptr(rts,
        &may23_M->NonInlinedSFcns.inputOutputPortInfo2[43]);

      /* Set up the mdlInfo pointer */
      ssSetRTWSfcnInfo(rts, may23_M->sfcnInfo);

      /* Allocate memory of model methods 2 */
      {
        ssSetModelMethods2(rts, &may23_M->NonInlinedSFcns.methods2[43]);
      }

      /* Allocate memory of model methods 3 */
      {
        ssSetModelMethods3(rts, &may23_M->NonInlinedSFcns.methods3[43]);
      }

      /* Allocate memory of model methods 4 */
      {
        ssSetModelMethods4(rts, &may23_M->NonInlinedSFcns.methods4[43]);
      }

      /* Allocate memory for states auxilliary information */
      {
        ssSetStatesInfo2(rts, &may23_M->NonInlinedSFcns.statesInfo2[43]);
        ssSetPeriodicStatesInfo(rts,
          &may23_M->NonInlinedSFcns.periodicStatesInfo[43]);
      }

      /* inputs */
      {
        _ssSetNumInputPorts(rts, 2);
        ssSetPortInfoForInputs(rts,
          &may23_M->NonInlinedSFcns.Sfcn43.inputPortInfo[0]);
        _ssSetPortInfo2ForInputUnits(rts,
          &may23_M->NonInlinedSFcns.Sfcn43.inputPortUnits[0]);
        ssSetInputPortUnit(rts, 0, 0);
        ssSetInputPortUnit(rts, 1, 0);
        _ssSetPortInfo2ForInputCoSimAttribute(rts,
          &may23_M->NonInlinedSFcns.Sfcn43.inputPortCoSimAttribute[0]);
        ssSetInputPortIsContinuousQuantity(rts, 0, 0);
        ssSetInputPortIsContinuousQuantity(rts, 1, 0);

        /* port 0 */
        {
          ssSetInputPortRequiredContiguous(rts, 0, 1);
          ssSetInputPortSignal(rts, 0, may23_B.SFunctionBuilder_o1);
          _ssSetInputPortNumDimensions(rts, 0, 1);
          ssSetInputPortWidth(rts, 0, 27240);
        }

        /* port 1 */
        {
          ssSetInputPortRequiredContiguous(rts, 1, 1);
          ssSetInputPortSignal(rts, 1, &may23_B.SFunctionBuilder_o2);
          _ssSetInputPortNumDimensions(rts, 1, 1);
          ssSetInputPortWidth(rts, 1, 1);
        }
      }

      /* path info */
      ssSetModelName(rts, "Send");
      ssSetPath(rts, "may23/Process_Video_CMD/Send");
      ssSetRTModel(rts,may23_M);
      ssSetParentSS(rts, (NULL));
      ssSetRootSS(rts, rts);
      ssSetVersion(rts, SIMSTRUCT_VERSION_LEVEL2);

      /* parameters */
      {
        mxArray **sfcnParams = (mxArray **)
          &may23_M->NonInlinedSFcns.Sfcn43.params;
        ssSetSFcnParamsCount(rts, 6);
        ssSetSFcnParamsPtr(rts, &sfcnParams[0]);
        ssSetSFcnParam(rts, 0, (mxArray*)may23_P.Send_P1_Size_a);
        ssSetSFcnParam(rts, 1, (mxArray*)may23_P.Send_P2_Size_h);
        ssSetSFcnParam(rts, 2, (mxArray*)may23_P.Send_P3_Size_i);
        ssSetSFcnParam(rts, 3, (mxArray*)may23_P.Send_P4_Size_o);
        ssSetSFcnParam(rts, 4, (mxArray*)may23_P.Send_P5_Size_n);
        ssSetSFcnParam(rts, 5, (mxArray*)may23_P.Send_P6_Size_p);
      }

      /* work vectors */
      ssSetIWork(rts, (int_T *) &may23_DW.Send_IWORK[0]);
      ssSetPWork(rts, (void **) &may23_DW.Send_PWORK);

      {
        struct _ssDWorkRecord *dWorkRecord = (struct _ssDWorkRecord *)
          &may23_M->NonInlinedSFcns.Sfcn43.dWork;
        struct _ssDWorkAuxRecord *dWorkAuxRecord = (struct _ssDWorkAuxRecord *)
          &may23_M->NonInlinedSFcns.Sfcn43.dWorkAux;
        ssSetSFcnDWork(rts, dWorkRecord);
        ssSetSFcnDWorkAux(rts, dWorkAuxRecord);
        _ssSetNumDWork(rts, 2);

        /* IWORK */
        ssSetDWorkWidth(rts, 0, 3);
        ssSetDWorkDataType(rts, 0,SS_INTEGER);
        ssSetDWorkComplexSignal(rts, 0, 0);
        ssSetDWork(rts, 0, &may23_DW.Send_IWORK[0]);

        /* PWORK */
        ssSetDWorkWidth(rts, 1, 1);
        ssSetDWorkDataType(rts, 1,SS_POINTER);
        ssSetDWorkComplexSignal(rts, 1, 0);
        ssSetDWork(rts, 1, &may23_DW.Send_PWORK);
      }

      /* registration */
      slrtUDPSend(rts);
      sfcnInitializeSizes(rts);
      sfcnInitializeSampleTimes(rts);

      /* adjust sample time */
      ssSetSampleTime(rts, 0, 0.001);
      ssSetOffsetTime(rts, 0, 0.0);
      sfcnTsMap[0] = 3;

      /* set compiled values of dynamic vector attributes */
      ssSetInputPortWidth(rts, 0, 27240);
      ssSetInputPortDataType(rts, 0, SS_UINT8);
      ssSetInputPortComplexSignal(rts, 0, 0);
      ssSetInputPortFrameData(rts, 0, 0);
      ssSetInputPortUnit(rts, 0, 0);
      ssSetInputPortIsContinuousQuantity(rts, 0, 0);
      ssSetNumNonsampledZCs(rts, 0);

      /* Update connectivity flags for each port */
      _ssSetInputPortConnected(rts, 0, 1);
      _ssSetInputPortConnected(rts, 1, 1);

      /* Update the BufferDstPort flags for each input port */
      ssSetInputPortBufferDstPort(rts, 0, -1);
      ssSetInputPortBufferDstPort(rts, 1, -1);
    }
  }

  /* Initialize Sizes */
  may23_M->Sizes.numContStates = (0);  /* Number of continuous states */
  may23_M->Sizes.numY = (0);           /* Number of model outputs */
  may23_M->Sizes.numU = (0);           /* Number of model inputs */
  may23_M->Sizes.sysDirFeedThru = (0); /* The model is not direct feedthrough */
  may23_M->Sizes.numSampTimes = (5);   /* Number of sample times */
  may23_M->Sizes.numBlocks = (1685);   /* Number of blocks */
  may23_M->Sizes.numBlockIO = (1500);  /* Number of block outputs */
  may23_M->Sizes.numBlockPrms = (81120);/* Sum of parameter "widths" */
  return may23_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
