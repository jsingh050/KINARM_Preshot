/*
 * may23_capi.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "may23".
 *
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "rtw_capi.h"
#ifdef HOST_CAPI_BUILD
#include "may23_capi_host.h"
#define sizeof(s)                      ((size_t)(0xFFFF))
#undef rt_offsetof
#define rt_offsetof(s,el)              ((uint16_T)(0xFFFF))
#define TARGET_CONST
#define TARGET_STRING(s)               (s)
#else                                  /* HOST_CAPI_BUILD */
#include "builtin_typeid_types.h"
#include "may23.h"
#include "may23_capi.h"
#include "may23_private.h"
#ifdef LIGHT_WEIGHT_CAPI
#define TARGET_CONST
#define TARGET_STRING(s)               (NULL)
#else
#define TARGET_CONST                   const
#define TARGET_STRING(s)               (s)
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* Block output signal information */
static const rtwCAPI_Signals rtBlockSignals[] = {
  /* addrMapIndex, sysNum, blockPath,
   * signalName, portNumber, dataTypeIndex, dimIndex, fxpIndex, sTimeIndex
   */
  { 0, 260, TARGET_STRING("Trial_Control/p1"),
    TARGET_STRING(""), 0, 0, 0, 0, 0 },

  { 1, 260, TARGET_STRING("Trial_Control/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 0 },

  { 2, 260, TARGET_STRING("Trial_Control/p3"),
    TARGET_STRING(""), 2, 1, 0, 0, 0 },

  { 3, 260, TARGET_STRING("Trial_Control/p4"),
    TARGET_STRING(""), 3, 1, 0, 0, 0 },

  { 4, 260, TARGET_STRING("Trial_Control/p5"),
    TARGET_STRING(""), 4, 1, 0, 0, 0 },

  { 5, 260, TARGET_STRING("Trial_Control/p6"),
    TARGET_STRING(""), 5, 1, 0, 0, 0 },

  { 6, 260, TARGET_STRING("Trial_Control/p7"),
    TARGET_STRING(""), 6, 1, 0, 0, 0 },

  { 7, 260, TARGET_STRING("Trial_Control/p8"),
    TARGET_STRING(""), 7, 1, 0, 0, 0 },

  { 8, 260, TARGET_STRING("Trial_Control/p9"),
    TARGET_STRING(""), 8, 1, 0, 0, 0 },

  { 9, 260, TARGET_STRING("Trial_Control/p10"),
    TARGET_STRING(""), 9, 1, 0, 0, 0 },

  { 10, 260, TARGET_STRING("Trial_Control/p11"),
    TARGET_STRING(""), 10, 1, 0, 0, 0 },

  { 11, 260, TARGET_STRING("Trial_Control/p12"),
    TARGET_STRING(""), 11, 1, 0, 0, 0 },

  { 12, 260, TARGET_STRING("Trial_Control/p13"),
    TARGET_STRING(""), 12, 1, 0, 0, 0 },

  { 13, 260, TARGET_STRING("Trial_Control/p14"),
    TARGET_STRING(""), 13, 1, 0, 0, 0 },

  { 14, 260, TARGET_STRING("Trial_Control/p15"),
    TARGET_STRING(""), 14, 1, 0, 0, 0 },

  { 15, 260, TARGET_STRING("Trial_Control/p16"),
    TARGET_STRING(""), 15, 0, 0, 0, 0 },

  { 16, 260, TARGET_STRING("Trial_Control/p17"),
    TARGET_STRING(""), 16, 0, 0, 0, 0 },

  { 17, 0, TARGET_STRING("Matrix Concatenate"),
    TARGET_STRING(""), 0, 1, 1, 0, 1 },

  { 18, 0, TARGET_STRING("Constant"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 19, 0, TARGET_STRING("Data Type Conversion"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 20, 0, TARGET_STRING("Data Type Conversion1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 21, 0, TARGET_STRING("Memory1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 22, 0, TARGET_STRING("Memory2"),
    TARGET_STRING(""), 0, 1, 2, 0, 1 },

  { 23, 0, TARGET_STRING("Memory4"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 24, 0, TARGET_STRING("DataLogging/read Digital diag"),
    TARGET_STRING(""), 0, 2, 3, 0, 1 },

  { 25, 0, TARGET_STRING("DataLogging/read status"),
    TARGET_STRING(""), 0, 1, 4, 0, 1 },

  { 26, 0, TARGET_STRING("DataLogging/Memory"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 27, 0, TARGET_STRING("DataLogging/Memory1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 28, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("Arm Orientation"), 0, 1, 0, 0, 1 },

  { 29, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("M1 orientation"), 0, 1, 0, 0, 1 },

  { 30, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("M2 Orientation"), 0, 1, 0, 0, 1 },

  { 31, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("M1 Gear Ratio"), 0, 1, 0, 0, 1 },

  { 32, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("M2 Gear Ratio"), 0, 1, 0, 0, 1 },

  { 33, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("Has Secondary Enc"), 0, 1, 0, 0, 1 },

  { 34, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("robot type"), 0, 1, 0, 0, 1 },

  { 35, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("robot version"), 0, 1, 0, 0, 1 },

  { 36, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("torque constant"), 0, 1, 0, 0, 1 },

  { 37, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isEP"), 0, 1, 0, 0, 1 },

  { 38, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isHumanExo"), 0, 1, 0, 0, 1 },

  { 39, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isNHPExo"), 0, 1, 0, 0, 1 },

  { 40, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isClassicExo"), 0, 1, 0, 0, 1 },

  { 41, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isUTSExo"), 0, 1, 0, 0, 1 },

  { 42, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isPMAC"), 0, 1, 0, 0, 1 },

  { 43, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isECAT"), 0, 1, 0, 0, 1 },

  { 44, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("robotRevision"), 0, 1, 0, 0, 1 },

  { 45, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("Arm Orientation"), 0, 1, 0, 0, 1 },

  { 46, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("M1 orientation"), 0, 1, 0, 0, 1 },

  { 47, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("M2 Orientation"), 0, 1, 0, 0, 1 },

  { 48, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("M1 Gear Ratio"), 0, 1, 0, 0, 1 },

  { 49, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("M2 Gear Ratio"), 0, 1, 0, 0, 1 },

  { 50, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("Has Secondary Enc"), 0, 1, 0, 0, 1 },

  { 51, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("robot type"), 0, 1, 0, 0, 1 },

  { 52, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("robot version"), 0, 1, 0, 0, 1 },

  { 53, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("torque constant"), 0, 1, 0, 0, 1 },

  { 54, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isEP"), 0, 1, 0, 0, 1 },

  { 55, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isHumanExo"), 0, 1, 0, 0, 1 },

  { 56, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isNHPExo"), 0, 1, 0, 0, 1 },

  { 57, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isClassicExo"), 0, 1, 0, 0, 1 },

  { 58, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isUTSExo"), 0, 1, 0, 0, 1 },

  { 59, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isPMAC"), 0, 1, 0, 0, 1 },

  { 60, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("isECAT"), 0, 1, 0, 0, 1 },

  { 61, 0, TARGET_STRING("DataLogging/Memory2"),
    TARGET_STRING("robotRevision"), 0, 1, 0, 0, 1 },

  { 62, 0, TARGET_STRING("DataLogging/Product"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 63, 0, TARGET_STRING("DataLogging/Rate Transition"),
    TARGET_STRING(""), 0, 1, 5, 0, 2 },

  { 64, 0, TARGET_STRING("DataLogging/Rate Transition1"),
    TARGET_STRING(""), 0, 1, 6, 0, 2 },

  { 65, 0, TARGET_STRING("DataLogging/Rate Transition2"),
    TARGET_STRING(""), 0, 1, 7, 0, 2 },

  { 66, 0, TARGET_STRING("DataLogging/AddTorques"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 67, 214, TARGET_STRING("Forces_to_Torques/Forces_to_Torques"),
    TARGET_STRING(""), 0, 1, 8, 0, 1 },

  { 68, 0, TARGET_STRING("GUI Control/Library Patch Version"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 69, 0, TARGET_STRING("GUI Control/Library Version"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 70, 0, TARGET_STRING("GUI Control/Pause Type"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 71, 0, TARGET_STRING("GUI Control/Task Version"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 72, 0, TARGET_STRING("GUI Control/Use custom TP sequence"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 73, 0, TARGET_STRING("GUI Control/dlm build time"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 74, 0, TARGET_STRING("GUI Control/frame_of_reference_center"),
    TARGET_STRING(""), 0, 1, 7, 0, 1 },

  { 75, 0, TARGET_STRING("GUI Control/xPC Version"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 76, 0, TARGET_STRING("GUI Control/Convert10"),
    TARGET_STRING(""), 0, 1, 9, 0, 1 },

  { 77, 0, TARGET_STRING("GUI Control/Convert11"),
    TARGET_STRING(""), 0, 1, 10, 0, 1 },

  { 78, 0, TARGET_STRING("GUI Control/Convert12"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 79, 0, TARGET_STRING("GUI Control/Convert13"),
    TARGET_STRING(""), 0, 1, 11, 0, 1 },

  { 80, 0, TARGET_STRING("GUI Control/Convert14"),
    TARGET_STRING(""), 0, 1, 9, 0, 1 },

  { 81, 0, TARGET_STRING("GUI Control/Convert15"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 82, 0, TARGET_STRING("GUI Control/Convert16"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 83, 0, TARGET_STRING("GUI Control/Convert17"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 84, 0, TARGET_STRING("GUI Control/Convert18"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 85, 0, TARGET_STRING("GUI Control/Convert19"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 86, 0, TARGET_STRING("GUI Control/Convert20"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 87, 0, TARGET_STRING("GUI Control/Convert21"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 88, 0, TARGET_STRING("GUI Control/Convert22"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 89, 0, TARGET_STRING("GUI Control/Convert23"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 90, 0, TARGET_STRING("GUI Control/Convert24"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 91, 0, TARGET_STRING("GUI Control/Convert25"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 92, 0, TARGET_STRING("GUI Control/Convert7"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 93, 0, TARGET_STRING("GUI Control/Convert8"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 94, 0, TARGET_STRING("GUI Control/Convert9"),
    TARGET_STRING(""), 0, 1, 9, 0, 1 },

  { 95, 0, TARGET_STRING("GUI Control/Memory"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 96, 0, TARGET_STRING("GUI Control/MinMax"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 97, 0, TARGET_STRING("GUI Control/TP Selector"),
    TARGET_STRING(""), 0, 1, 12, 0, 1 },

  { 98, 221, TARGET_STRING("KINARM_EP_Apply_Loads/Force_Cap"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 99, 222, TARGET_STRING("KINARM_EP_Apply_Loads/Forces_to_Torques"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 100, 223, TARGET_STRING("KINARM_EP_Apply_Loads/Ramp_Up_Down"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 101, 224, TARGET_STRING("KINARM_EP_Apply_Loads/Ramp_Up_Down1"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 102, 225, TARGET_STRING("KINARM_EP_Apply_Loads/Remove_NaNs_and_Inf"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 103, 226, TARGET_STRING("KINARM_EP_Apply_Loads/Remove_NaNs_and_Inf1"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 104, 0, TARGET_STRING("KINARM_EP_Apply_Loads/down_duration(ms)"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 105, 0, TARGET_STRING("KINARM_EP_Apply_Loads/down_duration(ms)1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 106, 0, TARGET_STRING("KINARM_EP_Apply_Loads/up_duration(ms)"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 107, 0, TARGET_STRING("KINARM_EP_Apply_Loads/up_duration(ms)1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 108, 0, TARGET_STRING("KINARM_EP_Apply_Loads/Data Type Conversion"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 109, 0, TARGET_STRING("KINARM_EP_Apply_Loads/Data Type Conversion1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 110, 0, TARGET_STRING("KINARM_EP_Apply_Loads/Product"),
    TARGET_STRING(""), 0, 1, 7, 0, 1 },

  { 111, 0, TARGET_STRING("KINARM_EP_Apply_Loads/Product1"),
    TARGET_STRING(""), 0, 1, 7, 0, 1 },

  { 112, 0, TARGET_STRING("KINARM_EP_Apply_Loads/Reshape"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 113, 231, TARGET_STRING("KINARM_Exo_Apply_Loads/Ramp_Up_Down"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 114, 232, TARGET_STRING("KINARM_Exo_Apply_Loads/Ramp_Up_Down1"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 115, 233, TARGET_STRING("KINARM_Exo_Apply_Loads/Remove_NaNs_and_Inf"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 116, 234, TARGET_STRING("KINARM_Exo_Apply_Loads/Remove_NaNs_and_Inf1"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 117, 235, TARGET_STRING("KINARM_Exo_Apply_Loads/Torque_Cap"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 118, 0, TARGET_STRING("KINARM_Exo_Apply_Loads/down_duration(ms)"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 119, 0, TARGET_STRING("KINARM_Exo_Apply_Loads/up_duration(ms)"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 120, 0, TARGET_STRING("KINARM_Exo_Apply_Loads/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 121, 0, TARGET_STRING("KINARM_Exo_Apply_Loads/Data Type Conversion1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 122, 0, TARGET_STRING("KINARM_Exo_Apply_Loads/Product"),
    TARGET_STRING(""), 0, 1, 7, 0, 1 },

  { 123, 0, TARGET_STRING("KINARM_Exo_Apply_Loads/Product1"),
    TARGET_STRING(""), 0, 1, 7, 0, 1 },

  { 124, 0, TARGET_STRING("KINARM_Exo_Apply_Loads/Reshape"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 125, 0, TARGET_STRING("KINARM_Exo_Apply_Loads/Switch"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 126, 241, TARGET_STRING("KINARM_HandInBarrier/Embedded MATLAB InsideTarget"),
    TARGET_STRING(""), 0, 1, 13, 0, 1 },

  { 127, 0, TARGET_STRING("KINARM_HandInBarrier/Array Selector"),
    TARGET_STRING(""), 0, 1, 14, 0, 1 },

  { 128, 0, TARGET_STRING("KINARM_HandInBarrier/Switch"),
    TARGET_STRING(""), 0, 1, 9, 0, 1 },

  { 129, 244, TARGET_STRING("KINARM_HandInTarget/Embedded MATLAB InsideTarget"),
    TARGET_STRING(""), 0, 1, 13, 0, 1 },

  { 130, 0, TARGET_STRING("KINARM_HandInTarget/Array Selector"),
    TARGET_STRING(""), 0, 1, 14, 0, 1 },

  { 131, 0, TARGET_STRING("KINARM_HandInTarget/Switch"),
    TARGET_STRING(""), 0, 1, 9, 0, 1 },

  { 132, 0, TARGET_STRING("Parameter Table Defn/binary_file_names"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 133, 0, TARGET_STRING("Parameter Table Defn/binary_files"),
    TARGET_STRING(""), 0, 1, 15, 0, 1 },

  { 134, 246, TARGET_STRING("Process_Video_CMD/MATLAB Function/p1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 135, 246, TARGET_STRING("Process_Video_CMD/MATLAB Function/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 136, 0, TARGET_STRING("Process_Video_CMD/Matrix Concatenate"),
    TARGET_STRING(""), 0, 1, 16, 0, 2 },

  { 137, 0, TARGET_STRING("Process_Video_CMD/GUI_VCODE"),
    TARGET_STRING(""), 0, 1, 17, 0, 2 },

  { 138, 0, TARGET_STRING("Process_Video_CMD/Convert"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 139, 0, TARGET_STRING("Process_Video_CMD/Convert1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 140, 0, TARGET_STRING("Process_Video_CMD/Gain"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 141, 0, TARGET_STRING("Process_Video_CMD/Memory"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 142, 0, TARGET_STRING("Process_Video_CMD/invert dim"),
    TARGET_STRING(""), 0, 1, 18, 0, 2 },

  { 143, 0, TARGET_STRING("Process_Video_CMD/Rate Transition2"),
    TARGET_STRING(""), 0, 1, 1, 0, 2 },

  { 144, 0, TARGET_STRING("Process_Video_CMD/Receive/p1"),
    TARGET_STRING(""), 0, 3, 3, 0, 1 },

  { 145, 0, TARGET_STRING("Process_Video_CMD/Receive/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 146, 0, TARGET_STRING("Process_Video_CMD/Unpack"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 147, 249, TARGET_STRING("PuckInBarrier/Embedded MATLAB InsideTarget"),
    TARGET_STRING(""), 0, 1, 13, 0, 1 },

  { 148, 0, TARGET_STRING("PuckInBarrier/Array Selector"),
    TARGET_STRING(""), 0, 1, 14, 0, 1 },

  { 149, 0, TARGET_STRING("PuckInBarrier/Selector"),
    TARGET_STRING(""), 0, 1, 9, 0, 1 },

  { 150, 250, TARGET_STRING("PuckInDisplay/MATLAB Function"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 151, 0, TARGET_STRING("PuckInDisplay/Selector"),
    TARGET_STRING(""), 0, 1, 9, 0, 1 },

  { 152, 251, TARGET_STRING("PuckInTarget/Embedded MATLAB InsideTarget"),
    TARGET_STRING(""), 0, 1, 13, 0, 1 },

  { 153, 0, TARGET_STRING("PuckInTarget/Array Selector"),
    TARGET_STRING(""), 0, 1, 14, 0, 1 },

  { 154, 0, TARGET_STRING("PuckInTarget/Selector"),
    TARGET_STRING(""), 0, 1, 9, 0, 1 },

  { 155, 252, TARGET_STRING("Show_Barrier/Embedded MATLAB Function"),
    TARGET_STRING(""), 0, 1, 2, 0, 1 },

  { 156, 0, TARGET_STRING("Show_Barrier/Matrix Concatenation"),
    TARGET_STRING(""), 0, 1, 19, 0, 1 },

  { 157, 0, TARGET_STRING("Show_Barrier/Matrix Concatenation1"),
    TARGET_STRING(""), 0, 1, 20, 0, 1 },

  { 158, 0, TARGET_STRING("Show_Barrier/padder"),
    TARGET_STRING(""), 0, 1, 21, 0, 1 },

  { 159, 0, TARGET_STRING("Show_Barrier/Selector"),
    TARGET_STRING(""), 0, 1, 22, 0, 1 },

  { 160, 253, TARGET_STRING("Show_Cursor/Embedded MATLAB Function"),
    TARGET_STRING(""), 0, 1, 2, 0, 1 },

  { 161, 0, TARGET_STRING("Show_Cursor/Matrix Concatenation"),
    TARGET_STRING(""), 0, 1, 23, 0, 1 },

  { 162, 0, TARGET_STRING("Show_Cursor/Matrix Concatenation1"),
    TARGET_STRING(""), 0, 1, 20, 0, 1 },

  { 163, 0, TARGET_STRING("Show_Cursor/padder"),
    TARGET_STRING(""), 0, 1, 24, 0, 1 },

  { 164, 0, TARGET_STRING("Show_Cursor/Selector"),
    TARGET_STRING(""), 0, 1, 22, 0, 1 },

  { 165, 254, TARGET_STRING("Show_Goal/Embedded MATLAB Function"),
    TARGET_STRING(""), 0, 1, 2, 0, 1 },

  { 166, 0, TARGET_STRING("Show_Goal/Matrix Concatenation"),
    TARGET_STRING(""), 0, 1, 23, 0, 1 },

  { 167, 0, TARGET_STRING("Show_Goal/Matrix Concatenation1"),
    TARGET_STRING(""), 0, 1, 20, 0, 1 },

  { 168, 0, TARGET_STRING("Show_Goal/padder"),
    TARGET_STRING(""), 0, 1, 24, 0, 1 },

  { 169, 0, TARGET_STRING("Show_Goal/Selector"),
    TARGET_STRING(""), 0, 1, 22, 0, 1 },

  { 170, 255, TARGET_STRING("Show_Preshot_Area/Embedded MATLAB Function"),
    TARGET_STRING(""), 0, 1, 2, 0, 1 },

  { 171, 0, TARGET_STRING("Show_Preshot_Area/Matrix Concatenation"),
    TARGET_STRING(""), 0, 1, 23, 0, 1 },

  { 172, 0, TARGET_STRING("Show_Preshot_Area/Matrix Concatenation1"),
    TARGET_STRING(""), 0, 1, 20, 0, 1 },

  { 173, 0, TARGET_STRING("Show_Preshot_Area/padder"),
    TARGET_STRING(""), 0, 1, 24, 0, 1 },

  { 174, 0, TARGET_STRING("Show_Preshot_Area/Selector"),
    TARGET_STRING(""), 0, 1, 22, 0, 1 },

  { 175, 256, TARGET_STRING("Show_Puck/Embedded MATLAB Function"),
    TARGET_STRING(""), 0, 1, 2, 0, 1 },

  { 176, 0, TARGET_STRING("Show_Puck/Matrix Concatenation"),
    TARGET_STRING(""), 0, 1, 23, 0, 1 },

  { 177, 0, TARGET_STRING("Show_Puck/Matrix Concatenation1"),
    TARGET_STRING(""), 0, 1, 20, 0, 1 },

  { 178, 0, TARGET_STRING("Show_Puck/padder"),
    TARGET_STRING(""), 0, 1, 24, 0, 1 },

  { 179, 0, TARGET_STRING("Show_Puck/Selector"),
    TARGET_STRING(""), 0, 1, 22, 0, 1 },

  { 180, 257, TARGET_STRING("Show_Start/Embedded MATLAB Function"),
    TARGET_STRING(""), 0, 1, 2, 0, 1 },

  { 181, 0, TARGET_STRING("Show_Start/Matrix Concatenation"),
    TARGET_STRING(""), 0, 1, 23, 0, 1 },

  { 182, 0, TARGET_STRING("Show_Start/Matrix Concatenation1"),
    TARGET_STRING(""), 0, 1, 20, 0, 1 },

  { 183, 0, TARGET_STRING("Show_Start/padder"),
    TARGET_STRING(""), 0, 1, 24, 0, 1 },

  { 184, 0, TARGET_STRING("Show_Start/Selector"),
    TARGET_STRING(""), 0, 1, 22, 0, 1 },

  { 185, 0, TARGET_STRING("Subsystem/Abs"),
    TARGET_STRING(""), 0, 1, 8, 0, 1 },

  { 186, 0, TARGET_STRING("Subsystem/Memory3"),
    TARGET_STRING(""), 0, 1, 8, 0, 1 },

  { 187, 0, TARGET_STRING("Subsystem/Product"),
    TARGET_STRING(""), 0, 1, 8, 0, 1 },

  { 188, 0, TARGET_STRING("Subsystem/Sum of Elements"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 189, 0, TARGET_STRING("Subsystem/Switch"),
    TARGET_STRING(""), 0, 1, 8, 0, 1 },

  { 190, 261, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/Collision Resolution/p1"),
    TARGET_STRING(""), 0, 1, 2, 0, 0 },

  { 191, 261, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/Collision Resolution/p2"),
    TARGET_STRING(""), 1, 1, 8, 0, 0 },

  { 192, 261, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/Collision Resolution/p3"),
    TARGET_STRING(""), 2, 0, 0, 0, 0 },

  { 193, 261, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/Collision Resolution/p4"),
    TARGET_STRING(""), 3, 0, 0, 0, 0 },

  { 194, 265, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/MATLAB Function"),
    TARGET_STRING(""), 0, 1, 8, 0, 1 },

  { 195, 0, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 196, 0, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/Pulse Generator"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 197, 0, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/get hand mass"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 198, 0, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/get rectangle mass"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 199, 0, TARGET_STRING(
    "DataLogging/Create Analog Inputs Subsystem/Analog Data Width"),
    TARGET_STRING(""), 0, 1, 25, 0, 1 },

  { 200, 0, TARGET_STRING(
    "DataLogging/Create Analog Inputs Subsystem/Rate Transition"),
    TARGET_STRING(""), 0, 1, 25, 0, 2 },

  { 201, 0, TARGET_STRING("DataLogging/Create Analog Inputs Subsystem/Subtract"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 202, 0, TARGET_STRING("DataLogging/Create Analog Inputs Subsystem/Width"),
    TARGET_STRING(""), 0, 1, 0, 0, 3 },

  { 203, 1, TARGET_STRING(
    "DataLogging/Create Custom Data Subsystem/monitor voltage bits"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 204, 0, TARGET_STRING(
    "DataLogging/Create Custom Data Subsystem/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 205, 0, TARGET_STRING(
    "DataLogging/Create Custom Data Subsystem/Rate Transition1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 206, 0, TARGET_STRING(
    "DataLogging/Create Custom Data Subsystem/Rate Transition2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 207, 0, TARGET_STRING("DataLogging/Create Custom Data Subsystem/Width"),
    TARGET_STRING(""), 0, 1, 0, 0, 3 },

  { 208, 0, TARGET_STRING("DataLogging/Create Event Codes Subsystem/Event Codes"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 209, 0, TARGET_STRING(
    "DataLogging/Create Event Codes Subsystem/Number of Event Codes"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 210, 0, TARGET_STRING("DataLogging/Create Event Codes Subsystem/Subtract"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 211, 0, TARGET_STRING("DataLogging/Create Event Codes Subsystem/Width"),
    TARGET_STRING(""), 0, 1, 0, 0, 3 },

  { 212, 2, TARGET_STRING("DataLogging/Create KINARM Data Subsystem/bitfield"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 213, 0, TARGET_STRING("DataLogging/Create KINARM Data Subsystem/touint"),
    TARGET_STRING(""), 0, 2, 4, 0, 1 },

  { 214, 0, TARGET_STRING("DataLogging/Create KINARM Data Subsystem/touint1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 215, 0, TARGET_STRING(
    "DataLogging/Create KINARM Data Subsystem/Rate Transition"),
    TARGET_STRING(""), 0, 1, 26, 0, 2 },

  { 216, 0, TARGET_STRING("DataLogging/Create KINARM Data Subsystem/Width"),
    TARGET_STRING(""), 0, 1, 0, 0, 3 },

  { 217, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Button Status"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 218, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Current Block Index"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 219, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Current Block Number in Set"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 220, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Current TP Index"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 221, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Current Trial Number in Block"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 222, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Current Trial Number in Set"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 223, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Last Frame Acknowledged"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 224, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Last Frame Sent"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 225, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Last Frame Sent1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 226, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Logging Enable"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 227, 0, TARGET_STRING("DataLogging/Create Task State Subsystem/Run Status"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 228, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Servo update count"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 229, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Task Control Button"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 230, 0, TARGET_STRING("DataLogging/Create Task State Subsystem/Timestamp"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 231, 0, TARGET_STRING("DataLogging/Create Task State Subsystem/conv"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 232, 0, TARGET_STRING("DataLogging/Create Task State Subsystem/Product"),
    TARGET_STRING(""), 0, 3, 0, 0, 1 },

  { 233, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Rate Transition"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 234, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Rate Transition1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 235, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Rate Transition10"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 236, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Rate Transition11"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 237, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Rate Transition12"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 238, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Rate Transition2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 239, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Rate Transition3"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 240, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Rate Transition4"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 241, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Rate Transition5"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 242, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Rate Transition6"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 243, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Rate Transition7"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 244, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Rate Transition8"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 245, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Rate Transition9"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 246, 0, TARGET_STRING("DataLogging/Create Task State Subsystem/Width"),
    TARGET_STRING(""), 0, 1, 0, 0, 3 },

  { 247, 4, TARGET_STRING("DataLogging/Keep alive/Pack"),
    TARGET_STRING(""), 0, 3, 27, 0, 4 },

  { 248, 4, TARGET_STRING("DataLogging/Keep alive/Width"),
    TARGET_STRING(""), 0, 1, 0, 0, 3 },

  { 249, 6, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Send Control Machine/p1"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 250, 6, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Send Control Machine/p2"),
    TARGET_STRING(""), 1, 4, 28, 0, 0 },

  { 251, 6, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Send Control Machine/p3"),
    TARGET_STRING(""), 2, 4, 0, 0, 0 },

  { 252, 6, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Send Control Machine/p4"),
    TARGET_STRING(""), 3, 4, 0, 0, 0 },

  { 253, 9, TARGET_STRING("DataLogging/Network Transfer Subsystem/max_packet_id"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 254, 9, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Type Conversion2"),
    TARGET_STRING(""), 0, 4, 0, 0, 1 },

  { 255, 9, TARGET_STRING("DataLogging/Network Transfer Subsystem/Queue Size"),
    TARGET_STRING("queue_size"), 0, 5, 0, 0, 1 },

  { 256, 9, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Total Timeouts"),
    TARGET_STRING("timeouts"), 0, 5, 0, 0, 1 },

  { 257, 9, TARGET_STRING("DataLogging/Network Transfer Subsystem/Task Clock"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 258, 9, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Rate Transition1"),
    TARGET_STRING(""), 0, 4, 29, 0, 1 },

  { 259, 16, TARGET_STRING("DataLogging/Poll Force Plates/Convert1"),
    TARGET_STRING(""), 0, 3, 30, 0, 5 },

  { 260, 16, TARGET_STRING("DataLogging/Poll Force Plates/Convert19"),
    TARGET_STRING(""), 0, 1, 31, 0, 1 },

  { 261, 16, TARGET_STRING("DataLogging/Poll Force Plates/Rate Transition"),
    TARGET_STRING(""), 0, 1, 0, 0, 5 },

  { 262, 16, TARGET_STRING("DataLogging/Poll Force Plates/Rate Transition1"),
    TARGET_STRING(""), 0, 1, 0, 0, 5 },

  { 263, 194, TARGET_STRING("DataLogging/Poll KINARM/system type"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 264, 194, TARGET_STRING("DataLogging/Poll KINARM/Read HasFT"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 265, 195, TARGET_STRING("DataLogging/Receive_Gaze/Create timestamp/p1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 266, 195, TARGET_STRING("DataLogging/Receive_Gaze/Create timestamp/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 267, 196, TARGET_STRING(
    "DataLogging/Receive_Gaze/Embedded MATLAB Function1/p1"),
    TARGET_STRING(""), 0, 1, 7, 0, 1 },

  { 268, 196, TARGET_STRING(
    "DataLogging/Receive_Gaze/Embedded MATLAB Function1/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 269, 196, TARGET_STRING(
    "DataLogging/Receive_Gaze/Embedded MATLAB Function1/p3"),
    TARGET_STRING(""), 2, 1, 32, 0, 1 },

  { 270, 196, TARGET_STRING(
    "DataLogging/Receive_Gaze/Embedded MATLAB Function1/p4"),
    TARGET_STRING(""), 3, 1, 32, 0, 1 },

  { 271, 197, TARGET_STRING("DataLogging/Receive_Gaze/clean_packet/p1"),
    TARGET_STRING(""), 0, 3, 33, 0, 1 },

  { 272, 197, TARGET_STRING("DataLogging/Receive_Gaze/clean_packet/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 273, 198, TARGET_STRING("DataLogging/Receive_Gaze/convert to seconds2"),
    TARGET_STRING(""), 0, 1, 32, 0, 2 },

  { 274, 199, TARGET_STRING("DataLogging/Receive_Gaze/Convert1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 275, 199, TARGET_STRING("DataLogging/Receive_Gaze/Convert19"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 276, 199, TARGET_STRING("DataLogging/Receive_Gaze/Convert2"),
    TARGET_STRING(""), 0, 1, 32, 0, 2 },

  { 277, 199, TARGET_STRING("DataLogging/Receive_Gaze/Convert3"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 278, 199, TARGET_STRING("DataLogging/Receive_Gaze/Convert4"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 279, 199, TARGET_STRING("DataLogging/Receive_Gaze/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 280, 199, TARGET_STRING("DataLogging/Receive_Gaze/Data Type Conversion1"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 281, 199, TARGET_STRING("DataLogging/Receive_Gaze/Data Type Conversion3"),
    TARGET_STRING(""), 0, 1, 8, 0, 1 },

  { 282, 199, TARGET_STRING("DataLogging/Receive_Gaze/Data Type Conversion4"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 283, 199, TARGET_STRING("DataLogging/Receive_Gaze/Data Type Conversion5"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 284, 199, TARGET_STRING("DataLogging/Receive_Gaze/convert"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 285, 199, TARGET_STRING("DataLogging/Receive_Gaze/Gain"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 286, 199, TARGET_STRING("DataLogging/Receive_Gaze/Rate Transition"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 287, 199, TARGET_STRING("DataLogging/Receive_Gaze/Rate Transition1"),
    TARGET_STRING(""), 0, 1, 32, 0, 2 },

  { 288, 199, TARGET_STRING("DataLogging/Receive_Gaze/Rate Transition2"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 289, 199, TARGET_STRING("DataLogging/Receive_Gaze/Rate Transition3"),
    TARGET_STRING(""), 0, 2, 0, 0, 2 },

  { 290, 199, TARGET_STRING("DataLogging/Receive_Gaze/Reshape"),
    TARGET_STRING(""), 0, 4, 34, 0, 1 },

  { 291, 199, TARGET_STRING("DataLogging/Receive_Gaze/Selector - Left Eye"),
    TARGET_STRING(""), 0, 4, 8, 0, 1 },

  { 292, 199, TARGET_STRING("DataLogging/Receive_Gaze/Receive/p1"),
    TARGET_STRING(""), 0, 3, 33, 0, 1 },

  { 293, 199, TARGET_STRING("DataLogging/Receive_Gaze/Receive/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 294, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 295, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p2"),
    TARGET_STRING("SAMPE_TYPE"), 1, 6, 0, 0, 1 },

  { 296, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p3"),
    TARGET_STRING("Content Flags"), 2, 7, 0, 0, 1 },

  { 297, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p4"),
    TARGET_STRING("pupil_X"), 3, 4, 7, 0, 1 },

  { 298, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p5"),
    TARGET_STRING("pupil Y"), 4, 4, 7, 0, 1 },

  { 299, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p6"),
    TARGET_STRING("HREF X"), 5, 4, 7, 0, 1 },

  { 300, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p7"),
    TARGET_STRING("HREF Y"), 6, 4, 7, 0, 1 },

  { 301, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p8"),
    TARGET_STRING("pupil area"), 7, 4, 7, 0, 1 },

  { 302, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p9"),
    TARGET_STRING("gaze_X"), 8, 4, 7, 0, 1 },

  { 303, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p10"),
    TARGET_STRING("gaze_Y"), 9, 4, 7, 0, 1 },

  { 304, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p11"),
    TARGET_STRING("resolution X"), 10, 4, 0, 0, 1 },

  { 305, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p12"),
    TARGET_STRING("resolution Y"), 11, 4, 0, 0, 1 },

  { 306, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p13"),
    TARGET_STRING("status flags"), 12, 7, 0, 0, 1 },

  { 307, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p14"),
    TARGET_STRING("extra input"), 13, 7, 0, 0, 1 },

  { 308, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p15"),
    TARGET_STRING("buttons"), 14, 7, 0, 0, 1 },

  { 309, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p16"),
    TARGET_STRING("htype"), 15, 6, 0, 0, 1 },

  { 310, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p17"),
    TARGET_STRING("hdata"), 16, 6, 4, 0, 1 },

  { 311, 199, TARGET_STRING("DataLogging/Receive_Gaze/S-Function/p18"),
    TARGET_STRING(""), 17, 2, 32, 0, 1 },

  { 312, 203, TARGET_STRING("DataLogging/apply loads/verify NaN"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 313, 205, TARGET_STRING("DataLogging/compare encoders/delta"),
    TARGET_STRING(""), 0, 1, 8, 0, 1 },

  { 314, 0, TARGET_STRING("DataLogging/compare encoders/Data Store Read1"),
    TARGET_STRING(""), 0, 1, 15, 0, 1 },

  { 315, 0, TARGET_STRING("DataLogging/compare encoders/Product"),
    TARGET_STRING(""), 0, 1, 8, 0, 1 },

  { 316, 0, TARGET_STRING("DataLogging/compare encoders/Delay"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 317, 0, TARGET_STRING("DataLogging/create_lab_info/arm_count"),
    TARGET_STRING("robot_count"), 0, 1, 0, 0, 1 },

  { 318, 0, TARGET_STRING("DataLogging/create_lab_info/fp1_present"),
    TARGET_STRING("has_force_plate_1"), 0, 1, 0, 0, 1 },

  { 319, 0, TARGET_STRING("DataLogging/create_lab_info/fp2_present"),
    TARGET_STRING("has_force_plate_2"), 0, 1, 0, 0, 1 },

  { 320, 0, TARGET_STRING("DataLogging/create_lab_info/gaze_tracker_present"),
    TARGET_STRING("has_gaze_tracker"), 0, 1, 0, 0, 1 },

  { 321, 0, TARGET_STRING("DataLogging/create_lab_info/robot_lift_present"),
    TARGET_STRING("has_robot_lift"), 0, 1, 0, 0, 1 },

  { 322, 208, TARGET_STRING("DataLogging/monitor torques/MATLAB Function/p1"),
    TARGET_STRING(""), 0, 0, 9, 0, 1 },

  { 323, 208, TARGET_STRING("DataLogging/monitor torques/MATLAB Function/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 324, 208, TARGET_STRING("DataLogging/monitor torques/MATLAB Function/p3"),
    TARGET_STRING("calc"), 2, 1, 3, 0, 1 },

  { 325, 208, TARGET_STRING("DataLogging/monitor torques/MATLAB Function/p4"),
    TARGET_STRING(""), 3, 1, 3, 0, 1 },

  { 326, 209, TARGET_STRING("DataLogging/monitor torques/current_limits"),
    TARGET_STRING(""), 0, 1, 11, 0, 1 },

  { 327, 211, TARGET_STRING("DataLogging/monitor torques/filter"),
    TARGET_STRING(""), 0, 1, 35, 0, 1 },

  { 328, 213, TARGET_STRING("DataLogging/monitor torques/torque_monitor/p1"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 329, 213, TARGET_STRING("DataLogging/monitor torques/torque_monitor/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 0 },

  { 330, 213, TARGET_STRING("DataLogging/monitor torques/torque_monitor/p3"),
    TARGET_STRING(""), 2, 1, 0, 0, 0 },

  { 331, 0, TARGET_STRING("DataLogging/monitor torques/Data Store Read"),
    TARGET_STRING(""), 0, 1, 31, 0, 1 },

  { 332, 0, TARGET_STRING("DataLogging/monitor torques/Data Store Read1"),
    TARGET_STRING(""), 0, 1, 15, 0, 1 },

  { 333, 0, TARGET_STRING("DataLogging/monitor torques/Task Clock"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 334, 0, TARGET_STRING("DataLogging/monitor torques/Memory1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 335, 0, TARGET_STRING("DataLogging/monitor torques/Memory2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 336, 0, TARGET_STRING("DataLogging/monitor torques/Product"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 337, 0, TARGET_STRING("DataLogging/monitor torques/AddR1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 338, 0, TARGET_STRING("DataLogging/monitor torques/AddR2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 339, 0, TARGET_STRING("DataLogging/monitor torques/Delay"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 340, 0, TARGET_STRING("GUI Control/Preview Targets Subsystem/preview_detail"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 341, 215, TARGET_STRING(
    "GUI Control/Run Command Subsystem/Embedded MATLAB Function/p1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 342, 215, TARGET_STRING(
    "GUI Control/Run Command Subsystem/Embedded MATLAB Function/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 343, 216, TARGET_STRING("GUI Control/Run Command Subsystem/Hold_to_1Khz"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 344, 0, TARGET_STRING(
    "GUI Control/Run Command Subsystem/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 345, 0, TARGET_STRING(
    "GUI Control/Run Command Subsystem/Data Type Conversion1"),
    TARGET_STRING(""), 0, 3, 0, 0, 1 },

  { 346, 0, TARGET_STRING(
    "GUI Control/Run Command Subsystem/Run Command Receive/p1"),
    TARGET_STRING(""), 0, 3, 0, 0, 1 },

  { 347, 0, TARGET_STRING(
    "GUI Control/Run Command Subsystem/Run Command Receive/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 348, 217, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/MATLAB Function"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 349, 218, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Task Execution Control Machine/p1"),
    TARGET_STRING(""), 0, 2, 0, 0, 0 },

  { 350, 218, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Task Execution Control Machine/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 0 },

  { 351, 218, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Task Execution Control Machine/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 0 },

  { 352, 218, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Task Execution Control Machine/p4"),
    TARGET_STRING(""), 3, 2, 0, 0, 0 },

  { 353, 218, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Task Execution Control Machine/p5"),
    TARGET_STRING(""), 4, 2, 0, 0, 0 },

  { 354, 218, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Task Execution Control Machine/p6"),
    TARGET_STRING(""), 5, 2, 0, 0, 0 },

  { 355, 218, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Task Execution Control Machine/p7"),
    TARGET_STRING(""), 6, 1, 0, 0, 0 },

  { 356, 218, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Task Execution Control Machine/p8"),
    TARGET_STRING(""), 7, 1, 7, 0, 0 },

  { 357, 218, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Task Execution Control Machine/p9"),
    TARGET_STRING(""), 8, 0, 0, 0, 0 },

  { 358, 0, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 359, 0, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Data Type Conversion1"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 360, 0, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Data Type Conversion2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 361, 0, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Data Type Conversion3"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 362, 0, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Task Clock"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 363, 0, TARGET_STRING("GUI Control/Task Execution Control Subsystem/Delay"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 364, 0, TARGET_STRING("GUI Control/Task Execution Control Subsystem/Delay1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 365, 0, TARGET_STRING("GUI Control/Task Execution Control Subsystem/Product"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 366, 0, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Product2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 367, 0, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Product3"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 368, 0, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Selector1"),
    TARGET_STRING(""), 0, 1, 36, 0, 1 },

  { 369, 0, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Selector2"),
    TARGET_STRING(""), 0, 1, 37, 0, 1 },

  { 370, 0, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Subtract"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 371, 0, TARGET_STRING("GUI Control/Task Execution Control Subsystem/Width1"),
    TARGET_STRING(""), 0, 2, 0, 0, 3 },

  { 372, 0, TARGET_STRING("GUI Control/Task Execution Control Subsystem/Width2"),
    TARGET_STRING(""), 0, 2, 0, 0, 3 },

  { 373, 219, TARGET_STRING("GUI Control/Task_progress/MATLAB Function/p1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 374, 219, TARGET_STRING("GUI Control/Task_progress/MATLAB Function/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 375, 219, TARGET_STRING("GUI Control/Task_progress/MATLAB Function/p3"),
    TARGET_STRING(""), 2, 1, 0, 0, 1 },

  { 376, 0, TARGET_STRING("GUI Control/Task_progress/Data Type Conversion"),
    TARGET_STRING("total_trials_in_exam"), 0, 2, 0, 0, 1 },

  { 377, 0, TARGET_STRING("GUI Control/Task_progress/Data Type Conversion1"),
    TARGET_STRING("total_trials_in_block"), 0, 2, 0, 0, 1 },

  { 378, 0, TARGET_STRING("GUI Control/Task_progress/Data Type Conversion2"),
    TARGET_STRING("total_blocks_in_exam"), 0, 2, 0, 0, 1 },

  { 379, 227, TARGET_STRING(
    "KINARM_EP_Apply_Loads/detect motor state/MATLAB Function"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 380, 228, TARGET_STRING(
    "KINARM_EP_Apply_Loads/detect motor state1/MATLAB Function"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 381, 238, TARGET_STRING(
    "KINARM_Exo_Apply_Loads/clip motor torques/clip_motor_torque"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 382, 0, TARGET_STRING("KINARM_Exo_Apply_Loads/clip motor torques/Switch1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 383, 240, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch"),
    TARGET_STRING("assessment_hand_pos"), 0, 1, 9, 0, 1 },

  { 384, 239, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch1"),
    TARGET_STRING("contralateral_hand_pos"), 0, 1, 9, 0, 1 },

  { 385, 0, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch2"),
    TARGET_STRING("assessment_hand_vel"), 0, 1, 9, 0, 1 },

  { 386, 0, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch3"),
    TARGET_STRING("contralateral_hand_vel"), 0, 1, 9, 0, 1 },

  { 387, 0, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch4"),
    TARGET_STRING("assessment_link_angles"), 0, 1, 9, 0, 1 },

  { 388, 0, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch5"),
    TARGET_STRING("contralateral_link_angles"), 0, 1, 9, 0, 1 },

  { 389, 0, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch6"),
    TARGET_STRING("assessment_link_vel"), 0, 1, 9, 0, 1 },

  { 390, 0, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch7"),
    TARGET_STRING("contralateral_link_vel"), 0, 1, 9, 0, 1 },

  { 391, 243, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch"),
    TARGET_STRING("assessment_hand_pos"), 0, 1, 9, 0, 1 },

  { 392, 242, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch1"),
    TARGET_STRING("contralateral_hand_pos"), 0, 1, 9, 0, 1 },

  { 393, 0, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch2"),
    TARGET_STRING("assessment_hand_vel"), 0, 1, 9, 0, 1 },

  { 394, 0, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch3"),
    TARGET_STRING("contralateral_hand_vel"), 0, 1, 9, 0, 1 },

  { 395, 0, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch4"),
    TARGET_STRING("assessment_link_angles"), 0, 1, 9, 0, 1 },

  { 396, 0, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch5"),
    TARGET_STRING("contralateral_link_angles"), 0, 1, 9, 0, 1 },

  { 397, 0, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch6"),
    TARGET_STRING("assessment_link_vel"), 0, 1, 9, 0, 1 },

  { 398, 0, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch7"),
    TARGET_STRING("contralateral_link_vel"), 0, 1, 9, 0, 1 },

  { 399, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/BARRIER_ROW;Barrier;target;Barrier;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 400, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/CURSOR_ROW;Hand Target Row;target;hand ;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 401, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/GOAL_ROW;Goal Row;target;Goal;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 402, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/GOAL_TIME;Goal time (s);float;Time that puck has to stay in goal to trigger success;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 403, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/LOAD_ROW;Load Row;load;Load;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 404, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/PRESHOT_ROW;Preshot Area;target;Preshot Area ;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 405, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/PUCK_DAMPING;Puck damping;float;Damping constant on puck (between 0 and 1);;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 406, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/PUCK_ROW;Puck Target Row;target;Puck;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 407, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/SECONDS;Trial duration (s);float;How long is the trial in seconds.;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 408, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/SHOT_READY_TIME;Shot ready time (s);float;Time to hold in start target during preshot routine to trigger the set state;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 409, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/SHOT_SET_TIME;Shot set time (s);float;Time to hold in start target after preshot routine to trigger go cue;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 410, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/SHOT_TIME;Shot time (s);float;Time to make a shot into the goal;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 411, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/START_HOLD_TIME;Start hold time (s);float;Time to hold in start target before triggering preshot routine;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 412, 0, TARGET_STRING(
    "Parameter Table Defn/TP_table/START_ROW;Start Position;target;Starting Spot for Pt ;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 413, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_BEGIN_PRESHOT;begin preshot routine;;;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 414, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_ENTER_START;enter start target;;;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 415, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_FAILURE;failure;;;;;red;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 416, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_HAND_IN_BARRIER;hand in barrier;;;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 417, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_NO_EVENT;n|a;;This event_code does not save an event in the data file, it just clears the event;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 418, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_PUCK_IN_BARRIER;puck in barrier;;;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 419, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_PUCK_IN_GOAL;puck in goal;;;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 420, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_PUCK_MISS;puck miss;;;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 421, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_SHOT_GO;shot go;;;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 422, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_SHOT_READY;shot ready;;;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 423, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_START_TARGET_ON;start target on;;;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 424, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_SUCCESS;success;;;;;green;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 425, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_TIMEOUT;timeout;;;;;red;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 426, 0, TARGET_STRING(
    "Parameter Table Defn/events/E_TRIAL_START;trial start;;;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 427, 0, TARGET_STRING(
    "Parameter Table Defn/load_table/F_BUMP;F_BUMP;float;Completely arbitrary parameter based on what feels good...;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 428, 0, TARGET_STRING(
    "Parameter Table Defn/load_table/MASS_CIRCLE;Circle target mass;float;;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 429, 0, TARGET_STRING(
    "Parameter Table Defn/load_table/MASS_RECT;Rectangle target mass;float;;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 430, 0, TARGET_STRING(
    "Parameter Table Defn/load_table/PERT_DUR;Perturbation Duration;float;(ms) Time that the perturbation is high for;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 431, 0, TARGET_STRING(
    "Parameter Table Defn/load_table/PERT_RAMP;Perturbation Ramp Time;float;(ms) Time for the perturbation to ramp up and down;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 432, 0, TARGET_STRING(
    "Parameter Table Defn/target_table/FIRST_FILL;First fill color;colour;First fill color for a selected target (color);;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 433, 0, TARGET_STRING(
    "Parameter Table Defn/target_table/HEIGHT;Height;float;Rectangle height (cm);;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 434, 0, TARGET_STRING(
    "Parameter Table Defn/target_table/RADIUS_LOG;logical radius;float;computational radius (cm);;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 435, 0, TARGET_STRING(
    "Parameter Table Defn/target_table/RADIUS_VIS;radius vis;float;radius in cm (legacy?);;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 436, 0, TARGET_STRING(
    "Parameter Table Defn/target_table/ROTATION;Rotation;float;Rectangle roation (degrees);;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 437, 0, TARGET_STRING(
    "Parameter Table Defn/target_table/SECOND_FILL;Second fill color;colour;Second fill color for a selected target (color);;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 438, 0, TARGET_STRING(
    "Parameter Table Defn/target_table/STROKE_COLOR;Stroke colour;colour;Stroke color (color);;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 439, 0, TARGET_STRING(
    "Parameter Table Defn/target_table/STROKE_WIDTH;Width of the stroke;float;Stroke weight (cm);;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 440, 0, TARGET_STRING(
    "Parameter Table Defn/target_table/THIRD_FILL;third fill color;colour;Third fill color for a selected target (color);;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 441, 0, TARGET_STRING(
    "Parameter Table Defn/target_table/WIDTH;Width or Radius;float;Rectangle width or Circle Radius (cm);;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 442, 0, TARGET_STRING(
    "Parameter Table Defn/target_table/col_x;X;float;X Position (cm) of the target relative to  local (0,0);;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 443, 0, TARGET_STRING(
    "Parameter Table Defn/target_table/col_y;Y;float;Y Position (cm) of the target relative to  local (0,0);;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 444, 0, TARGET_STRING("Parameter Table Defn/task_definition/INSTRUCTIONS="),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 445, 0, TARGET_STRING("Parameter Table Defn/task_definition/LOAD_FOR=EITHER"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 446, 0, TARGET_STRING(
    "Parameter Table Defn/task_wide/FORCE_MULTIPLIER;Force multiplier;float;;;;none;;"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 447, 245, TARGET_STRING(
    "Process_Video_CMD/Add_requested_Delay/MATLAB Function"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 448, 0, TARGET_STRING(
    "Process_Video_CMD/Add_requested_Delay/Rate Transition1"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 449, 0, TARGET_STRING(
    "Process_Video_CMD/Add_requested_Delay/S-Function Builder/p1"),
    TARGET_STRING(""), 0, 3, 38, 0, 2 },

  { 450, 0, TARGET_STRING(
    "Process_Video_CMD/Add_requested_Delay/S-Function Builder/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 2 },

  { 451, 0, TARGET_STRING(
    "Process_Video_CMD/Add_requested_Delay/S-Function Builder/p3"),
    TARGET_STRING(""), 2, 1, 39, 0, 2 },

  { 452, 247, TARGET_STRING("Process_Video_CMD/PVC_core/Pack VCodeFrame2/p1"),
    TARGET_STRING("vis_cmd_out"), 0, 5, 40, 0, 2 },

  { 453, 247, TARGET_STRING("Process_Video_CMD/PVC_core/Pack VCodeFrame2/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 2 },

  { 454, 247, TARGET_STRING("Process_Video_CMD/PVC_core/Pack VCodeFrame2/p3"),
    TARGET_STRING(""), 2, 1, 0, 0, 2 },

  { 455, 247, TARGET_STRING("Process_Video_CMD/PVC_core/Pack VCodeFrame2/p4"),
    TARGET_STRING(""), 3, 2, 0, 0, 2 },

  { 456, 247, TARGET_STRING("Process_Video_CMD/PVC_core/Pack VCodeFrame2/p5"),
    TARGET_STRING(""), 4, 1, 0, 0, 2 },

  { 457, 248, TARGET_STRING("Process_Video_CMD/PVC_core/Convert"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 458, 248, TARGET_STRING("Process_Video_CMD/PVC_core/Rate Transition1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 459, 0, TARGET_STRING("Subsystem/Compare To Zero1/Compare"),
    TARGET_STRING(""), 0, 3, 0, 0, 1 },

  { 460, 258, TARGET_STRING("Subsystem/Perturbation/Ramp_up_down"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 461, 259, TARGET_STRING("Subsystem/Perturbation/Select Perturbation Times"),
    TARGET_STRING(""), 0, 1, 11, 0, 1 },

  { 462, 0, TARGET_STRING("Subsystem/Perturbation/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 41, 0, 1 },

  { 463, 0, TARGET_STRING("Subsystem/Perturbation/Data Type Conversion2"),
    TARGET_STRING(""), 0, 3, 0, 0, 1 },

  { 464, 262, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/Get Hand Speed/MATLAB Function"),
    TARGET_STRING(""), 0, 1, 42, 0, 1 },

  { 465, 0, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/Get Hand Speed/Matrix Concatenate1"),
    TARGET_STRING(""), 0, 1, 42, 0, 1 },

  { 466, 264, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/Hand Feedback/MATLAB Function"),
    TARGET_STRING(""), 0, 1, 43, 0, 1 },

  { 467, 3, TARGET_STRING(
    "DataLogging/Create KINARM Data Subsystem/select KINData/MATLAB Function"),
    TARGET_STRING(""), 0, 1, 7, 0, 1 },

  { 468, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Counter Free-Running/Output"),
    TARGET_STRING(""), 0, 2, 0, 0, 2 },

  { 469, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/If Running/Compare"),
    TARGET_STRING(""), 0, 3, 0, 0, 1 },

  { 470, 5, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Data Type Conversion"),
    TARGET_STRING(""), 0, 4, 44, 0, 2 },

  { 471, 5, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Ideal Frames Per Packet"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 472, 5, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Math Function"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 473, 5, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Packing Subsystem/t-1"),
    TARGET_STRING(""), 0, 4, 44, 0, 2 },

  { 474, 5, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Packing Subsystem/t-2"),
    TARGET_STRING(""), 0, 4, 44, 0, 2 },

  { 475, 5, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Packing Subsystem/MinMax"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 476, 5, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Product"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 477, 5, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Relational Operator"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  { 478, 5, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Selector"),
    TARGET_STRING(""), 0, 4, 29, 0, 2 },

  { 479, 5, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Subtract"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 480, 5, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Width"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 481, 9, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/UDP Receiver/Data Type Conversion"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 482, 9, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/UDP Receiver/Memory1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 483, 9, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/UDP Receiver/Memory2"),
    TARGET_STRING("trigger"), 0, 1, 0, 0, 1 },

  { 484, 9, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/UDP Receiver/Receive/p1"),
    TARGET_STRING(""), 0, 3, 45, 0, 1 },

  { 485, 9, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/UDP Receiver/Receive/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 486, 9, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/UDP Receiver/Unpack"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 487, 7, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Pack"),
    TARGET_STRING(""), 0, 3, 46, 0, 0 },

  { 488, 7, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Width"),
    TARGET_STRING(""), 0, 1, 0, 0, 3 },

  { 489, 8, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/force strobe/force strobe"),
    TARGET_STRING(""), 0, 1, 0, 0, 5 },

  { 490, 9, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/force strobe/Rate Transition1"),
    TARGET_STRING(""), 0, 0, 0, 0, 5 },

  { 491, 9, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/force strobe/Rate Transition2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 492, 10, TARGET_STRING(
    "DataLogging/Poll Force Plates/plate1/parse packet 1/p1"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 493, 10, TARGET_STRING(
    "DataLogging/Poll Force Plates/plate1/parse packet 1/p2"),
    TARGET_STRING(""), 1, 1, 32, 0, 1 },

  { 494, 10, TARGET_STRING(
    "DataLogging/Poll Force Plates/plate1/parse packet 1/p3"),
    TARGET_STRING(""), 2, 1, 0, 0, 1 },

  { 495, 11, TARGET_STRING("DataLogging/Poll Force Plates/plate1/Receive/p1"),
    TARGET_STRING(""), 0, 3, 47, 0, 1 },

  { 496, 11, TARGET_STRING("DataLogging/Poll Force Plates/plate1/Receive/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 497, 12, TARGET_STRING(
    "DataLogging/Poll Force Plates/plate2/parse packet 1/p1"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 498, 12, TARGET_STRING(
    "DataLogging/Poll Force Plates/plate2/parse packet 1/p2"),
    TARGET_STRING(""), 1, 1, 32, 0, 1 },

  { 499, 12, TARGET_STRING(
    "DataLogging/Poll Force Plates/plate2/parse packet 1/p3"),
    TARGET_STRING(""), 2, 1, 0, 0, 1 },

  { 500, 13, TARGET_STRING("DataLogging/Poll Force Plates/plate2/Receive1/p1"),
    TARGET_STRING(""), 0, 3, 47, 0, 1 },

  { 501, 13, TARGET_STRING("DataLogging/Poll Force Plates/plate2/Receive1/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 502, 14, TARGET_STRING("DataLogging/Poll Force Plates/send poll 1/Width"),
    TARGET_STRING(""), 0, 1, 0, 0, 3 },

  { 503, 15, TARGET_STRING("DataLogging/Poll Force Plates/send poll 2/Width"),
    TARGET_STRING(""), 0, 1, 0, 0, 3 },

  { 504, 135, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/latch_errors/p1"),
    TARGET_STRING(""), 0, 1, 48, 0, 1 },

  { 505, 135, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/latch_errors/p2"),
    TARGET_STRING(""), 1, 1, 48, 0, 1 },

  { 506, 136, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/sdo_addrs/p1"),
    TARGET_STRING("intAddrs"), 0, 1, 49, 0, 1 },

  { 507, 136, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/sdo_addrs/p2"),
    TARGET_STRING("floatAddrs"), 1, 1, 49, 0, 1 },

  { 508, 137, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/setState"),
    TARGET_STRING("forceMotorState"), 0, 0, 0, 0, 1 },

  { 509, 194, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Bias"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 510, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/max errors to fault"),
    TARGET_STRING("max_errors_to_fault"), 0, 1, 0, 0, 1 },

  { 511, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 512, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/convert1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 513, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/BKIN EtherCATinit/p1"),
    TARGET_STRING(""), 0, 5, 50, 0, 1 },

  { 514, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/BKIN EtherCATinit/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 515, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/BKIN EtherCATinit/p3"),
    TARGET_STRING(""), 2, 5, 0, 0, 1 },

  { 516, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/BKIN EtherCATinit/p4"),
    TARGET_STRING(""), 3, 5, 45, 0, 1 },

  { 517, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/BKIN EtherCATinit1/p1"),
    TARGET_STRING(""), 0, 5, 50, 0, 1 },

  { 518, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/BKIN EtherCATinit1/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 519, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/BKIN EtherCATinit1/p3"),
    TARGET_STRING(""), 2, 5, 0, 0, 1 },

  { 520, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/BKIN EtherCATinit1/p4"),
    TARGET_STRING(""), 3, 5, 45, 0, 1 },

  { 521, 194, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Switch"),
    TARGET_STRING(""), 0, 5, 4, 0, 1 },

  { 522, 194, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Switch1"),
    TARGET_STRING(""), 0, 5, 45, 0, 1 },

  { 523, 161, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/MATLAB Function/p1"),
    TARGET_STRING(""), 0, 1, 31, 0, 1 },

  { 524, 161, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/MATLAB Function/p2"),
    TARGET_STRING(""), 1, 2, 7, 0, 1 },

  { 525, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Logical Operator"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 526, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Rate Transition"),
    TARGET_STRING(""), 0, 0, 0, 0, 2 },

  { 527, 184, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/Calibration_check"),
    TARGET_STRING(""), 0, 1, 9, 0, 0 },

  { 528, 185, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/Create KINARM Data Array/p1"),
    TARGET_STRING(""), 0, 1, 51, 0, 0 },

  { 529, 185, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/Create KINARM Data Array/p2"),
    TARGET_STRING(""), 1, 1, 52, 0, 0 },

  { 530, 186, TARGET_STRING("DataLogging/Poll KINARM/createKINData/bitpack"),
    TARGET_STRING(""), 0, 2, 8, 0, 0 },

  { 531, 187, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/record errors/p1"),
    TARGET_STRING(""), 0, 1, 53, 0, 0 },

  { 532, 187, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/record errors/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 0 },

  { 533, 188, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/is_calibrated"),
    TARGET_STRING(""), 0, 1, 7, 0, 0 },

  { 534, 188, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/Data Store Read"),
    TARGET_STRING(""), 0, 2, 0, 0, 0 },

  { 535, 188, TARGET_STRING("DataLogging/Poll KINARM/createKINData/Data ready"),
    TARGET_STRING(""), 0, 1, 15, 0, 0 },

  { 536, 188, TARGET_STRING("DataLogging/Poll KINARM/createKINData/Delay Read"),
    TARGET_STRING(""), 0, 1, 3, 0, 0 },

  { 537, 188, TARGET_STRING("DataLogging/Poll KINARM/createKINData/ErrMsgs"),
    TARGET_STRING(""), 0, 1, 54, 0, 0 },

  { 538, 188, TARGET_STRING("DataLogging/Poll KINARM/createKINData/Primary read"),
    TARGET_STRING(""), 0, 1, 48, 0, 0 },

  { 539, 188, TARGET_STRING("DataLogging/Poll KINARM/createKINData/Read"),
    TARGET_STRING(""), 0, 1, 6, 0, 0 },

  { 540, 188, TARGET_STRING("DataLogging/Poll KINARM/createKINData/Read HW"),
    TARGET_STRING(""), 0, 1, 21, 0, 0 },

  { 541, 188, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/Read Kinematics"),
    TARGET_STRING(""), 0, 1, 23, 0, 0 },

  { 542, 188, TARGET_STRING("DataLogging/Poll KINARM/createKINData/Servo Read"),
    TARGET_STRING(""), 0, 2, 0, 0, 0 },

  { 543, 188, TARGET_STRING("DataLogging/Poll KINARM/createKINData/Status read"),
    TARGET_STRING(""), 0, 2, 55, 0, 0 },

  { 544, 188, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/torque feedback1"),
    TARGET_STRING(""), 0, 1, 15, 0, 0 },

  { 545, 188, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 8, 0, 0 },

  { 546, 188, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/Data Type Conversion1"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 547, 194, TARGET_STRING("DataLogging/Poll KINARM/isecat/Compare"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 548, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p1"),
    TARGET_STRING("a1_link_lengths"), 0, 1, 9, 0, 1 },

  { 549, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p2"),
    TARGET_STRING("a1_pointer_offset"), 1, 1, 0, 0, 1 },

  { 550, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p3"),
    TARGET_STRING("a1_shoulder_position"), 2, 1, 9, 0, 1 },

  { 551, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p4"),
    TARGET_STRING("a1_arm_orientation"), 3, 1, 0, 0, 1 },

  { 552, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p5"),
    TARGET_STRING("a1_shoulder_angle"), 4, 1, 0, 0, 1 },

  { 553, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p6"),
    TARGET_STRING("a1_elbow_angle"), 5, 1, 0, 0, 1 },

  { 554, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p7"),
    TARGET_STRING("a1_shoulder_ang_velocity"), 6, 1, 0, 0, 1 },

  { 555, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p8"),
    TARGET_STRING("a1_elbow_ang_velocity"), 7, 1, 0, 0, 1 },

  { 556, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p9"),
    TARGET_STRING("a1_shoulder_ang_acceleration"), 8, 1, 0, 0, 1 },

  { 557, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p10"),
    TARGET_STRING("a1_elbow_ang_acceleration"), 9, 1, 0, 0, 1 },

  { 558, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p11"),
    TARGET_STRING("a1_joint_torque_command"), 10, 1, 9, 0, 1 },

  { 559, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p12"),
    TARGET_STRING("a1_motor_torque_command"), 11, 1, 9, 0, 1 },

  { 560, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p13"),
    TARGET_STRING("a1_link_angles"), 12, 1, 9, 0, 1 },

  { 561, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p14"),
    TARGET_STRING("a1_link_velocities"), 13, 1, 9, 0, 1 },

  { 562, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p15"),
    TARGET_STRING("a1_link_accelerations"), 14, 1, 9, 0, 1 },

  { 563, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p16"),
    TARGET_STRING("a1_hand_position"), 15, 1, 9, 0, 1 },

  { 564, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p17"),
    TARGET_STRING("a1_hand_velocities"), 16, 1, 9, 0, 1 },

  { 565, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p18"),
    TARGET_STRING("a1_hand_accelerations"), 17, 1, 9, 0, 1 },

  { 566, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p19"),
    TARGET_STRING("a1_elbow_position"), 18, 1, 9, 0, 1 },

  { 567, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p20"),
    TARGET_STRING("a1_elbow_cart_velocity"), 19, 1, 9, 0, 1 },

  { 568, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p21"),
    TARGET_STRING("a1_elbow_cart_acceleration"), 20, 1, 9, 0, 1 },

  { 569, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p22"),
    TARGET_STRING("a1_motor_status"), 21, 1, 0, 0, 1 },

  { 570, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p23"),
    TARGET_STRING("a1_force_sensor_force_uvw"), 22, 1, 11, 0, 1 },

  { 571, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p24"),
    TARGET_STRING("a1_force_sensor_torque_uvw"), 23, 1, 11, 0, 1 },

  { 572, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p25"),
    TARGET_STRING("a1_force_sensor_force_xyz"), 24, 1, 11, 0, 1 },

  { 573, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p26"),
    TARGET_STRING("a1_force_sensor_torque_xyz"), 25, 1, 11, 0, 1 },

  { 574, 189, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm1/p27"),
    TARGET_STRING("a1_force_sensor_timestamp"), 26, 1, 0, 0, 1 },

  { 575, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p1"),
    TARGET_STRING("a2_link_lengths"), 0, 1, 9, 0, 1 },

  { 576, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p2"),
    TARGET_STRING("a2_pointer_offset"), 1, 1, 0, 0, 1 },

  { 577, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p3"),
    TARGET_STRING("a2_shoulder_position"), 2, 1, 9, 0, 1 },

  { 578, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p4"),
    TARGET_STRING("a2_arm_orientation"), 3, 1, 0, 0, 1 },

  { 579, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p5"),
    TARGET_STRING("a2_shoulder_angle"), 4, 1, 0, 0, 1 },

  { 580, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p6"),
    TARGET_STRING("a2_elbow_angle"), 5, 1, 0, 0, 1 },

  { 581, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p7"),
    TARGET_STRING("a2_shoulder_ang_velocity"), 6, 1, 0, 0, 1 },

  { 582, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p8"),
    TARGET_STRING("a2_elbow_ang_velocity"), 7, 1, 0, 0, 1 },

  { 583, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p9"),
    TARGET_STRING("a2_shoulder_ang_acceleration"), 8, 1, 0, 0, 1 },

  { 584, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p10"),
    TARGET_STRING("a2_elbow_ang_acceleration"), 9, 1, 0, 0, 1 },

  { 585, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p11"),
    TARGET_STRING("a2_joint_torque_command"), 10, 1, 9, 0, 1 },

  { 586, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p12"),
    TARGET_STRING("a2_motor_torque_command"), 11, 1, 9, 0, 1 },

  { 587, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p13"),
    TARGET_STRING("a2_link_angles"), 12, 1, 9, 0, 1 },

  { 588, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p14"),
    TARGET_STRING("a2_link_velocities"), 13, 1, 9, 0, 1 },

  { 589, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p15"),
    TARGET_STRING("a2_link_accelerations"), 14, 1, 9, 0, 1 },

  { 590, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p16"),
    TARGET_STRING("a2_hand_position"), 15, 1, 9, 0, 1 },

  { 591, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p17"),
    TARGET_STRING("a2_hand_velocities"), 16, 1, 9, 0, 1 },

  { 592, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p18"),
    TARGET_STRING("a2_hand_accelerations"), 17, 1, 9, 0, 1 },

  { 593, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p19"),
    TARGET_STRING("a2_elbow_position"), 18, 1, 9, 0, 1 },

  { 594, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p20"),
    TARGET_STRING("a2_elbow_cart_velocity"), 19, 1, 9, 0, 1 },

  { 595, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p21"),
    TARGET_STRING("a2_elbow_cart_acceleration"), 20, 1, 9, 0, 1 },

  { 596, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p22"),
    TARGET_STRING("a2_motor_status"), 21, 1, 0, 0, 1 },

  { 597, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p23"),
    TARGET_STRING("a2_force_sensor_force_uvw"), 22, 1, 11, 0, 1 },

  { 598, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p24"),
    TARGET_STRING("a2_force_sensor_torque_uvw"), 23, 1, 11, 0, 1 },

  { 599, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p25"),
    TARGET_STRING("a2_force_sensor_force_xyz"), 24, 1, 11, 0, 1 },

  { 600, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p26"),
    TARGET_STRING("a2_force_sensor_torque_xyz"), 25, 1, 11, 0, 1 },

  { 601, 190, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINData arm2/p27"),
    TARGET_STRING("a2_force_sensor_timestamp"), 26, 1, 0, 0, 1 },

  { 602, 191, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINDataGeneral/p1"),
    TARGET_STRING("active_arm"), 0, 1, 0, 0, 1 },

  { 603, 191, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINDataGeneral/p3"),
    TARGET_STRING("servo_counter"), 2, 1, 0, 0, 1 },

  { 604, 191, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINDataGeneral/p4"),
    TARGET_STRING("calibration_button_bits"), 3, 1, 0, 0, 1 },

  { 605, 191, TARGET_STRING(
    "DataLogging/Poll KINARM/make KINData bus/splitKINDataGeneral/p8"),
    TARGET_STRING(""), 7, 1, 0, 0, 1 },

  { 606, 194, TARGET_STRING("DataLogging/Poll KINARM/make KINData bus/Selector"),
    TARGET_STRING(""), 0, 1, 12, 0, 1 },

  { 607, 194, TARGET_STRING("DataLogging/Poll KINARM/make KINData bus/Selector1"),
    TARGET_STRING(""), 0, 1, 12, 0, 1 },

  { 608, 194, TARGET_STRING("DataLogging/Poll KINARM/make KINData bus/Selector2"),
    TARGET_STRING(""), 0, 1, 12, 0, 1 },

  { 609, 192, TARGET_STRING(
    "DataLogging/Poll KINARM/split_primary/split_primary/p1"),
    TARGET_STRING("a1_link_angles"), 0, 1, 9, 0, 1 },

  { 610, 192, TARGET_STRING(
    "DataLogging/Poll KINARM/split_primary/split_primary/p2"),
    TARGET_STRING("a1_link_velocities"), 1, 1, 9, 0, 1 },

  { 611, 192, TARGET_STRING(
    "DataLogging/Poll KINARM/split_primary/split_primary/p3"),
    TARGET_STRING("a1_link_accelerations"), 2, 1, 9, 0, 1 },

  { 612, 193, TARGET_STRING(
    "DataLogging/Poll KINARM/split_primary/split_primary1/p1"),
    TARGET_STRING("a2_link_angles"), 0, 1, 9, 0, 1 },

  { 613, 193, TARGET_STRING(
    "DataLogging/Poll KINARM/split_primary/split_primary1/p2"),
    TARGET_STRING("a2_link_velocities"), 1, 1, 9, 0, 1 },

  { 614, 193, TARGET_STRING(
    "DataLogging/Poll KINARM/split_primary/split_primary1/p3"),
    TARGET_STRING("a2_link_accelerations"), 2, 1, 9, 0, 1 },

  { 615, 194, TARGET_STRING("DataLogging/Poll KINARM/split_primary/Selector1"),
    TARGET_STRING(""), 0, 1, 53, 0, 1 },

  { 616, 194, TARGET_STRING("DataLogging/Poll KINARM/split_primary/Selector2"),
    TARGET_STRING(""), 0, 1, 53, 0, 1 },

  { 617, 200, TARGET_STRING(
    "DataLogging/apply loads/EtherCAT Apply Loads/convert torques"),
    TARGET_STRING(""), 0, 6, 8, 0, 1 },

  { 618, 201, TARGET_STRING(
    "DataLogging/apply loads/EtherCAT Apply Loads/Data Store Read"),
    TARGET_STRING(""), 0, 1, 31, 0, 1 },

  { 619, 202, TARGET_STRING(
    "DataLogging/apply loads/apply pmac loads/Data Type Conversion"),
    TARGET_STRING(""), 0, 4, 50, 0, 1 },

  { 620, 202, TARGET_STRING(
    "DataLogging/apply loads/apply pmac loads/Data Type Conversion1"),
    TARGET_STRING(""), 0, 4, 50, 0, 1 },

  { 621, 202, TARGET_STRING(
    "DataLogging/apply loads/apply pmac loads/Data Type Conversion6"),
    TARGET_STRING(""), 0, 4, 3, 0, 1 },

  { 622, 202, TARGET_STRING("DataLogging/apply loads/apply pmac loads/Product"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 623, 204, TARGET_STRING("DataLogging/apply loads/isecat/Compare"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 624, 204, TARGET_STRING("DataLogging/apply loads/isecat1/Compare"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 625, 206, TARGET_STRING(
    "DataLogging/create_lab_info/Subsystem/MATLAB Function/p1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 626, 206, TARGET_STRING(
    "DataLogging/create_lab_info/Subsystem/MATLAB Function/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 627, 206, TARGET_STRING(
    "DataLogging/create_lab_info/Subsystem/MATLAB Function/p3"),
    TARGET_STRING(""), 2, 1, 0, 0, 1 },

  { 628, 207, TARGET_STRING(
    "DataLogging/create_lab_info/Subsystem/MATLAB Function1/p1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 629, 207, TARGET_STRING(
    "DataLogging/create_lab_info/Subsystem/MATLAB Function1/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 630, 207, TARGET_STRING(
    "DataLogging/create_lab_info/Subsystem/MATLAB Function1/p3"),
    TARGET_STRING(""), 2, 1, 0, 0, 1 },

  { 631, 0, TARGET_STRING(
    "DataLogging/monitor torques/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 632, 210, TARGET_STRING("DataLogging/monitor torques/delay/filter"),
    TARGET_STRING(""), 0, 1, 8, 0, 1 },

  { 633, 0, TARGET_STRING("DataLogging/monitor torques/delay/Delay"),
    TARGET_STRING(""), 0, 1, 8, 0, 1 },

  { 634, 212, TARGET_STRING(
    "DataLogging/monitor torques/monitor_enc_delta/monitor_encoders/p1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 635, 212, TARGET_STRING(
    "DataLogging/monitor torques/monitor_enc_delta/monitor_encoders/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 636, 0, TARGET_STRING(
    "DataLogging/monitor torques/monitor_enc_delta/encoder_err_threshold"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 637, 0, TARGET_STRING(
    "DataLogging/monitor torques/monitor_enc_delta/Memory1"),
    TARGET_STRING(""), 0, 1, 8, 0, 1 },

  { 638, 0, TARGET_STRING(
    "GUI Control/Task Execution Control Subsystem/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 3, 0, 0, 1 },

  { 639, 0, TARGET_STRING(
    "GUI Control/exit_trial_goto/Detect Change/FixPt Relational Operator"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 640, 0, TARGET_STRING(
    "GUI Control/exit_trial_goto/Detect Change/Delay Input1"),
    TARGET_STRING("U(k-1)"), 0, 0, 0, 0, 1 },

  { 641, 0, TARGET_STRING(
    "GUI Control/exit_trial_goto/Detect Change1/FixPt Relational Operator"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 642, 0, TARGET_STRING(
    "GUI Control/exit_trial_goto/Detect Change1/Delay Input1"),
    TARGET_STRING("U(k-1)"), 0, 0, 0, 0, 1 },

  { 643, 0, TARGET_STRING("GUI Control/tables/Compare To Constant/Compare"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 644, 0, TARGET_STRING("GUI Control/tables/Counter Free-Running/Output"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 645, 220, TARGET_STRING("GUI Control/tables/enable_tables/Block Definitions"),
    TARGET_STRING(""), 0, 1, 56, 0, 1 },

  { 646, 220, TARGET_STRING("GUI Control/tables/enable_tables/Block Sequence"),
    TARGET_STRING(""), 0, 1, 57, 0, 1 },

  { 647, 220, TARGET_STRING("GUI Control/tables/enable_tables/Load Table"),
    TARGET_STRING(""), 0, 1, 41, 0, 1 },

  { 648, 220, TARGET_STRING("GUI Control/tables/enable_tables/TP Table"),
    TARGET_STRING(""), 0, 1, 58, 0, 1 },

  { 649, 220, TARGET_STRING("GUI Control/tables/enable_tables/Target Labels"),
    TARGET_STRING(""), 0, 1, 59, 0, 1 },

  { 650, 220, TARGET_STRING("GUI Control/tables/enable_tables/Target Table"),
    TARGET_STRING(""), 0, 1, 60, 0, 1 },

  { 651, 220, TARGET_STRING("GUI Control/tables/enable_tables/Task wide param"),
    TARGET_STRING(""), 0, 1, 61, 0, 1 },

  { 652, 263, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/Hand Feedback/Hand_Feedback/FeedFwdArm"),
    TARGET_STRING(""), 0, 1, 43, 0, 1 },

  { 653, 0, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/Hand Feedback/Hand_Feedback/Matrix Concatenation"),
    TARGET_STRING(""), 0, 1, 43, 0, 1 },

  { 654, 0, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/Hand Feedback/Hand_Feedback/Reshape"),
    TARGET_STRING(""), 0, 1, 2, 0, 1 },

  { 655, 0, TARGET_STRING(
    "subsystem for moving the square (updating velocity and checking collision)/Hand Feedback/Hand_Feedback/Reshape1"),
    TARGET_STRING(""), 0, 1, 2, 0, 1 },

  { 656, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Counter Free-Running/Increment Real World/FixPt Sum1"),
    TARGET_STRING(""), 0, 2, 0, 0, 2 },

  { 657, 0, TARGET_STRING(
    "DataLogging/Create Task State Subsystem/Counter Free-Running/Wrap To Zero/FixPt Switch"),
    TARGET_STRING(""), 0, 2, 0, 0, 2 },

  { 658, 5, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Counter/Sum"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 659, 5, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Counter/Unit Delay"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 660, 7, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Counter Free-Running/Output"),
    TARGET_STRING(""), 0, 2, 0, 0, 0 },

  { 661, 44, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Find Robot type"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 662, 51, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO read machine/p1"),
    TARGET_STRING(""), 0, 5, 32, 0, 1 },

  { 663, 51, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO read machine/p2"),
    TARGET_STRING(""), 1, 5, 23, 0, 1 },

  { 664, 51, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO read machine/p3"),
    TARGET_STRING(""), 2, 1, 23, 0, 1 },

  { 665, 51, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO read machine/p4"),
    TARGET_STRING(""), 3, 5, 0, 0, 1 },

  { 666, 66, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/forceEnableDisable"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 667, 70, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/size"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 668, 71, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/size1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 669, 72, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants/p1"),
    TARGET_STRING("R1_encoder counts"), 0, 1, 9, 0, 1 },

  { 670, 72, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants/p2"),
    TARGET_STRING("R1_FTSensorAngleOffset"), 1, 1, 0, 0, 1 },

  { 671, 72, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants/p3"),
    TARGET_STRING("R1_calibPinAngle"), 2, 1, 9, 0, 1 },

  { 672, 72, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants/p4"),
    TARGET_STRING("R1_absAngleOffset"), 3, 1, 9, 0, 1 },

  { 673, 72, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants/p5"),
    TARGET_STRING("R1_LinkLength"), 4, 1, 9, 0, 1 },

  { 674, 72, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants/p6"),
    TARGET_STRING("R1_L2CalibPinOffset"), 5, 1, 0, 0, 1 },

  { 675, 72, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants/p7"),
    TARGET_STRING(""), 6, 1, 9, 0, 1 },

  { 676, 72, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants/p8"),
    TARGET_STRING("R1_gearRatios"), 7, 1, 9, 0, 1 },

  { 677, 72, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants/p9"),
    TARGET_STRING("R1_isCalibrated"), 8, 1, 0, 0, 1 },

  { 678, 72, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants/p10"),
    TARGET_STRING("R1_OffsetRads"), 9, 1, 9, 0, 1 },

  { 679, 72, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants/p11"),
    TARGET_STRING("R1_OffsetRadsPrimary"), 10, 1, 9, 0, 1 },

  { 680, 72, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants/p12"),
    TARGET_STRING("R1_RobotRevision"), 11, 1, 0, 0, 1 },

  { 681, 72, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants/p13"),
    TARGET_STRING(""), 12, 1, 0, 0, 1 },

  { 682, 73, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants1/p1"),
    TARGET_STRING("R1_hasSecondary"), 0, 1, 0, 0, 1 },

  { 683, 73, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants1/p2"),
    TARGET_STRING("R1_hasFT"), 1, 1, 0, 0, 1 },

  { 684, 73, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants1/p3"),
    TARGET_STRING("R1_robotOrientation"), 2, 1, 0, 0, 1 },

  { 685, 73, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants1/p4"),
    TARGET_STRING("R1_motorOrientation"), 3, 1, 9, 0, 1 },

  { 686, 73, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants1/p5"),
    TARGET_STRING("R1_encOrientation"), 4, 1, 9, 0, 1 },

  { 687, 73, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants1/p6"),
    TARGET_STRING(""), 5, 1, 0, 0, 1 },

  { 688, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/readTrigger"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 689, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M1_LinkAngle"), 0, 1, 0, 0, 1 },

  { 690, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M1_PrimaryLinkAngle"), 0, 1, 0, 0, 1 },

  { 691, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M1_PrimaryLinkVelocity"), 0, 1, 0, 0, 1 },

  { 692, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M1_RecordedTorque"), 0, 1, 0, 0, 1 },

  { 693, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M1_digitalInputs"), 0, 1, 9, 0, 1 },

  { 694, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M1_digitalDiagnostics"), 0, 1, 0, 0, 1 },

  { 695, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1_calibrationButton"), 0, 1, 0, 0, 1 },

  { 696, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1_EPGripSensor"), 0, 0, 0, 0, 1 },

  { 697, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M1_EMCY_codes"), 0, 1, 39, 0, 1 },

  { 698, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M1_CurrentLimitEnabled"), 0, 2, 0, 0, 1 },

  { 699, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M2_LinkAngle"), 0, 1, 0, 0, 1 },

  { 700, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M2_PrimaryLinkAngle"), 0, 1, 0, 0, 1 },

  { 701, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M2_PrimaryLinkVelocity"), 0, 1, 0, 0, 1 },

  { 702, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M2_RecordedTorque"), 0, 1, 0, 0, 1 },

  { 703, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M2_digitalInputs"), 0, 1, 9, 0, 1 },

  { 704, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M2_digitalDiagnostics"), 0, 1, 0, 0, 1 },

  { 705, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M2_EMCY_codes"), 0, 1, 39, 0, 1 },

  { 706, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion"),
    TARGET_STRING("R1M2_CurrentLimitEnabled"), 0, 2, 0, 0, 1 },

  { 707, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_RobotType"), 0, 1, 0, 0, 1 },

  { 708, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_hasSecondary"), 0, 1, 0, 0, 1 },

  { 709, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_hasFT"), 0, 1, 0, 0, 1 },

  { 710, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_robotOrientation"), 0, 1, 0, 0, 1 },

  { 711, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_motorOrientation"), 0, 1, 9, 0, 1 },

  { 712, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_encOrientation"), 0, 1, 9, 0, 1 },

  { 713, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_encoder counts"), 0, 1, 9, 0, 1 },

  { 714, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_FTSensorAngleOffset"), 0, 1, 0, 0, 1 },

  { 715, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_calibPinAngle"), 0, 1, 9, 0, 1 },

  { 716, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_absAngleOffset"), 0, 1, 9, 0, 1 },

  { 717, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_LinkLength"), 0, 1, 9, 0, 1 },

  { 718, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_L2CalibPinOffset"), 0, 1, 0, 0, 1 },

  { 719, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_maxContinuousTorque"), 0, 1, 9, 0, 1 },

  { 720, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_gearRatios"), 0, 1, 9, 0, 1 },

  { 721, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_isCalibrated"), 0, 1, 0, 0, 1 },

  { 722, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_OffsetRads"), 0, 1, 9, 0, 1 },

  { 723, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_OffsetRadsPrimary"), 0, 1, 9, 0, 1 },

  { 724, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_RobotRevision"), 0, 1, 0, 0, 1 },

  { 725, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Signal Conversion1"),
    TARGET_STRING("R1_constantsReady"), 0, 1, 0, 0, 1 },

  { 726, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Memory2"),
    TARGET_STRING("R1_maxContinuousTorque"), 0, 1, 9, 0, 1 },

  { 727, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Memory3"),
    TARGET_STRING("R1_constantsReady"), 0, 1, 0, 0, 1 },

  { 728, 101, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Find Robot type"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 729, 108, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO read machine/p1"),
    TARGET_STRING(""), 0, 5, 32, 0, 1 },

  { 730, 108, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO read machine/p2"),
    TARGET_STRING(""), 1, 5, 23, 0, 1 },

  { 731, 108, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO read machine/p3"),
    TARGET_STRING(""), 2, 1, 23, 0, 1 },

  { 732, 108, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO read machine/p4"),
    TARGET_STRING(""), 3, 5, 0, 0, 1 },

  { 733, 123, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/forceEnableDisable"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 734, 127, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/size"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 735, 128, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/size1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 736, 129, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants/p1"),
    TARGET_STRING("R2_encoder counts"), 0, 1, 9, 0, 1 },

  { 737, 129, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants/p2"),
    TARGET_STRING("R2_FTSensorAngleOffset"), 1, 1, 0, 0, 1 },

  { 738, 129, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants/p3"),
    TARGET_STRING("R2_calibPinAngle"), 2, 1, 9, 0, 1 },

  { 739, 129, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants/p4"),
    TARGET_STRING("R2_absAngleOffset"), 3, 1, 9, 0, 1 },

  { 740, 129, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants/p5"),
    TARGET_STRING("R2_LinkLength"), 4, 1, 9, 0, 1 },

  { 741, 129, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants/p6"),
    TARGET_STRING("R2_L2CalibPinOffset"), 5, 1, 0, 0, 1 },

  { 742, 129, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants/p7"),
    TARGET_STRING(""), 6, 1, 9, 0, 1 },

  { 743, 129, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants/p8"),
    TARGET_STRING("R2_gearRatios"), 7, 1, 9, 0, 1 },

  { 744, 129, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants/p9"),
    TARGET_STRING("R2_isCalibrated"), 8, 1, 0, 0, 1 },

  { 745, 129, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants/p10"),
    TARGET_STRING("R2_OffsetRads"), 9, 1, 9, 0, 1 },

  { 746, 129, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants/p11"),
    TARGET_STRING("R2_OffsetRadsPrimary"), 10, 1, 9, 0, 1 },

  { 747, 129, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants/p12"),
    TARGET_STRING("R2_RobotRevision"), 11, 1, 0, 0, 1 },

  { 748, 129, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants/p13"),
    TARGET_STRING(""), 12, 1, 0, 0, 1 },

  { 749, 130, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants1/p1"),
    TARGET_STRING("R2_hasSecondary"), 0, 1, 0, 0, 1 },

  { 750, 130, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants1/p2"),
    TARGET_STRING("R2_hasFT"), 1, 1, 0, 0, 1 },

  { 751, 130, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants1/p3"),
    TARGET_STRING("R2_robotOrientation"), 2, 1, 0, 0, 1 },

  { 752, 130, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants1/p4"),
    TARGET_STRING("R2_motorOrientation"), 3, 1, 9, 0, 1 },

  { 753, 130, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants1/p5"),
    TARGET_STRING("R2_encOrientation"), 4, 1, 9, 0, 1 },

  { 754, 130, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants1/p6"),
    TARGET_STRING(""), 5, 1, 0, 0, 1 },

  { 755, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/readTrigger"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 756, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M1_LinkAngle"), 0, 1, 0, 0, 1 },

  { 757, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M1_PrimaryLinkAngle"), 0, 1, 0, 0, 1 },

  { 758, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M1_PrimaryLinkVelocity"), 0, 1, 0, 0, 1 },

  { 759, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M1_RecordedTorque"), 0, 1, 0, 0, 1 },

  { 760, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M1_digitalInputs"), 0, 1, 9, 0, 1 },

  { 761, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M1_digitalDiagnostics"), 0, 1, 0, 0, 1 },

  { 762, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2_calibrationButton"), 0, 1, 0, 0, 1 },

  { 763, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2_EPGripSensor"), 0, 0, 0, 0, 1 },

  { 764, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M1_EMCY_codes"), 0, 1, 39, 0, 1 },

  { 765, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M1_CurrentLimitEnabled"), 0, 2, 0, 0, 1 },

  { 766, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M2_LinkAngle"), 0, 1, 0, 0, 1 },

  { 767, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M2_PrimaryLinkAngle"), 0, 1, 0, 0, 1 },

  { 768, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M2_PrimaryLinkVelocity"), 0, 1, 0, 0, 1 },

  { 769, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M2_RecordedTorque"), 0, 1, 0, 0, 1 },

  { 770, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M2_digitalInputs"), 0, 1, 9, 0, 1 },

  { 771, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M2_digitalDiagnostics"), 0, 1, 0, 0, 1 },

  { 772, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M2_EMCY_codes"), 0, 1, 39, 0, 1 },

  { 773, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion"),
    TARGET_STRING("R2M2_CurrentLimitEnabled"), 0, 2, 0, 0, 1 },

  { 774, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_RobotType"), 0, 1, 0, 0, 1 },

  { 775, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_hasSecondary"), 0, 1, 0, 0, 1 },

  { 776, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_hasFT"), 0, 1, 0, 0, 1 },

  { 777, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_robotOrientation"), 0, 1, 0, 0, 1 },

  { 778, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_motorOrientation"), 0, 1, 9, 0, 1 },

  { 779, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_encOrientation"), 0, 1, 9, 0, 1 },

  { 780, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_encoder counts"), 0, 1, 9, 0, 1 },

  { 781, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_FTSensorAngleOffset"), 0, 1, 0, 0, 1 },

  { 782, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_calibPinAngle"), 0, 1, 9, 0, 1 },

  { 783, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_absAngleOffset"), 0, 1, 9, 0, 1 },

  { 784, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_LinkLength"), 0, 1, 9, 0, 1 },

  { 785, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_L2CalibPinOffset"), 0, 1, 0, 0, 1 },

  { 786, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_maxContinuousTorque"), 0, 1, 9, 0, 1 },

  { 787, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_gearRatios"), 0, 1, 9, 0, 1 },

  { 788, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_isCalibrated"), 0, 1, 0, 0, 1 },

  { 789, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_OffsetRads"), 0, 1, 9, 0, 1 },

  { 790, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_OffsetRadsPrimary"), 0, 1, 9, 0, 1 },

  { 791, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_RobotRevision"), 0, 1, 0, 0, 1 },

  { 792, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Signal Conversion1"),
    TARGET_STRING("R2_constantsReady"), 0, 1, 0, 0, 1 },

  { 793, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Memory2"),
    TARGET_STRING("R2_maxContinuousTorque"), 0, 1, 9, 0, 1 },

  { 794, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Memory3"),
    TARGET_STRING("R2_constantsReady"), 0, 1, 0, 0, 1 },

  { 795, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Compare/Compare"),
    TARGET_STRING(""), 0, 3, 0, 0, 1 },

  { 796, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Counter Free-Running/Output"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 797, 132, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/update digital outputs/p1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 798, 132, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/update digital outputs/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 799, 132, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/update digital outputs/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 800, 132, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/update digital outputs/p4"),
    TARGET_STRING(""), 3, 2, 0, 0, 1 },

  { 801, 133, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Init to Bus/master_state"),
    TARGET_STRING("MasterState"), 0, 5, 0, 0, 1 },

  { 802, 134, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Init to Bus/split init/p1"),
    TARGET_STRING("ErrVal"), 0, 5, 0, 0, 1 },

  { 803, 134, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Init to Bus/split init/p2"),
    TARGET_STRING("MasterState"), 1, 5, 0, 0, 1 },

  { 804, 134, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Init to Bus/split init/p3"),
    TARGET_STRING("DCErrVal"), 2, 5, 0, 0, 1 },

  { 805, 134, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Init to Bus/split init/p4"),
    TARGET_STRING("MasterToNetworkClkDiff"), 3, 5, 0, 0, 1 },

  { 806, 134, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Init to Bus/split init/p5"),
    TARGET_STRING("DCInitState"), 4, 5, 0, 0, 1 },

  { 807, 134, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Init to Bus/split init/p6"),
    TARGET_STRING("NetworkToSlaveClkDiff"), 5, 5, 0, 0, 1 },

  { 808, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Init to Bus/convert"),
    TARGET_STRING(""), 0, 1, 4, 0, 1 },

  { 809, 138, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/MATLAB Function"),
    TARGET_STRING(""), 0, 1, 0, 0, 0 },

  { 810, 139, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/convert to bit field"),
    TARGET_STRING(""), 0, 2, 0, 0, 0 },

  { 811, 142, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/create kinematics/p1"),
    TARGET_STRING(""), 0, 1, 5, 0, 0 },

  { 812, 142, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/create kinematics/p2"),
    TARGET_STRING(""), 1, 1, 48, 0, 0 },

  { 813, 142, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/create kinematics/p3"),
    TARGET_STRING(""), 2, 1, 3, 0, 0 },

  { 814, 143, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/create servo counter"),
    TARGET_STRING(""), 0, 2, 0, 0, 0 },

  { 815, 144, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/create servo counter1"),
    TARGET_STRING(""), 0, 1, 62, 0, 0 },

  { 816, 145, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/robottype1"),
    TARGET_STRING(""), 0, 1, 54, 0, 0 },

  { 817, 146, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/update HW settings"),
    TARGET_STRING(""), 0, 1, 22, 0, 0 },

  { 818, 147, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/update calibrations"),
    TARGET_STRING(""), 0, 1, 63, 0, 0 },

  { 819, 148, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/Data Store"),
    TARGET_STRING(""), 0, 1, 6, 0, 0 },

  { 820, 148, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/Data Store1"),
    TARGET_STRING(""), 0, 1, 21, 0, 0 },

  { 821, 148, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/Data Type Conversion"),
    TARGET_STRING(""), 0, 2, 35, 0, 0 },

  { 822, 148, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/Data Type Conversion1"),
    TARGET_STRING(""), 0, 2, 7, 0, 0 },

  { 823, 148, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/Data Type Conversion2"),
    TARGET_STRING(""), 0, 2, 0, 0, 0 },

  { 824, 148, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/Data Type Conversion3"),
    TARGET_STRING(""), 0, 1, 3, 0, 0 },

  { 825, 148, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/Data Type Conversion4"),
    TARGET_STRING(""), 0, 2, 3, 0, 0 },

  { 826, 148, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/Data Type Conversion5"),
    TARGET_STRING(""), 0, 1, 7, 0, 0 },

  { 827, 151, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Create timestamp"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 828, 150, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 50, 0, 1 },

  { 829, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Byte Reversal"),
    TARGET_STRING(""), 0, 5, 50, 0, 1 },

  { 830, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Byte Reversal1"),
    TARGET_STRING(""), 0, 2, 32, 0, 1 },

  { 831, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Receive from Robot 1 Force Sensor/p1"),
    TARGET_STRING(""), 0, 3, 64, 0, 1 },

  { 832, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Receive from Robot 1 Force Sensor/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 833, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Unpack/p1"),
    TARGET_STRING(""), 0, 2, 32, 0, 1 },

  { 834, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Unpack/p2"),
    TARGET_STRING(""), 1, 5, 50, 0, 1 },

  { 835, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Switch"),
    TARGET_STRING(""), 0, 1, 55, 0, 1 },

  { 836, 157, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Create timestamp"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 837, 156, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Type Conversion1"),
    TARGET_STRING(""), 0, 1, 50, 0, 1 },

  { 838, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Byte Reversal"),
    TARGET_STRING(""), 0, 5, 50, 0, 1 },

  { 839, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Byte Reversal1"),
    TARGET_STRING(""), 0, 2, 32, 0, 1 },

  { 840, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Receive from Robot 2 Force Sensor/p1"),
    TARGET_STRING(""), 0, 3, 64, 0, 1 },

  { 841, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Receive from Robot 2 Force Sensor/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 842, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Unpack1/p1"),
    TARGET_STRING(""), 0, 2, 32, 0, 1 },

  { 843, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Unpack1/p2"),
    TARGET_STRING(""), 1, 5, 50, 0, 1 },

  { 844, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Switch1"),
    TARGET_STRING(""), 0, 1, 55, 0, 1 },

  { 845, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/ispmac/Compare"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 846, 166, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Monitor_status"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 847, 167, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Robot_data_builder/p1"),
    TARGET_STRING(""), 0, 1, 15, 0, 1 },

  { 848, 167, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Robot_data_builder/p2"),
    TARGET_STRING(""), 1, 1, 15, 0, 1 },

  { 849, 167, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Robot_data_builder/p3"),
    TARGET_STRING(""), 2, 1, 50, 0, 1 },

  { 850, 167, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Robot_data_builder/p4"),
    TARGET_STRING(""), 3, 1, 50, 0, 1 },

  { 851, 168, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/filter_velocities/p1"),
    TARGET_STRING(""), 0, 1, 15, 0, 1 },

  { 852, 168, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/filter_velocities/p2"),
    TARGET_STRING(""), 1, 1, 15, 0, 1 },

  { 853, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Conversion1"),
    TARGET_STRING(""), 0, 1, 50, 0, 1 },

  { 854, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Conversion2"),
    TARGET_STRING(""), 0, 1, 50, 0, 1 },

  { 855, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Conversion7"),
    TARGET_STRING(""), 0, 1, 3, 0, 1 },

  { 856, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Convert2"),
    TARGET_STRING(""), 0, 2, 32, 0, 1 },

  { 857, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Data Type Conversion"),
    TARGET_STRING(""), 0, 4, 15, 0, 1 },

  { 858, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Data Type Conversion1"),
    TARGET_STRING(""), 0, 4, 15, 0, 1 },

  { 859, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Data Type Conversion2"),
    TARGET_STRING(""), 0, 4, 0, 0, 1 },

  { 860, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Data Type Conversion3"),
    TARGET_STRING(""), 0, 1, 15, 0, 1 },

  { 861, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Data Type Conversion4"),
    TARGET_STRING(""), 0, 1, 15, 0, 1 },

  { 862, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/MinMax"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 863, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/MinMax1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 864, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/S-Function/p1"),
    TARGET_STRING(""), 0, 4, 15, 0, 1 },

  { 865, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/S-Function/p2"),
    TARGET_STRING(""), 1, 4, 15, 0, 1 },

  { 866, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/S-Function/p3"),
    TARGET_STRING(""), 2, 2, 7, 0, 1 },

  { 867, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/S-Function/p4"),
    TARGET_STRING(""), 3, 4, 3, 0, 1 },

  { 868, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/S-Function/p5"),
    TARGET_STRING(""), 4, 4, 50, 0, 1 },

  { 869, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/S-Function/p6"),
    TARGET_STRING(""), 5, 4, 50, 0, 1 },

  { 870, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/S-Function/p7"),
    TARGET_STRING(""), 6, 2, 0, 0, 1 },

  { 871, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/S-Function/p8"),
    TARGET_STRING(""), 7, 2, 0, 0, 1 },

  { 872, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/S-Function/p9"),
    TARGET_STRING(""), 8, 2, 32, 0, 1 },

  { 873, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/S-Function/p10"),
    TARGET_STRING(""), 9, 4, 0, 0, 1 },

  { 874, 170, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/update settings/update status format"),
    TARGET_STRING(""), 0, 2, 65, 0, 0 },

  { 875, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Counter Free-Running/Output"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 876, 172, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Data receive/MATLAB Function/p1"),
    TARGET_STRING(""), 0, 1, 23, 0, 2 },

  { 877, 172, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Data receive/MATLAB Function/p2"),
    TARGET_STRING(""), 1, 1, 48, 0, 2 },

  { 878, 173, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Data receive/Constant"),
    TARGET_STRING(""), 0, 2, 0, 0, 2 },

  { 879, 173, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Data receive/Constant1"),
    TARGET_STRING(""), 0, 2, 55, 0, 2 },

  { 880, 173, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Data receive/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 50, 0, 2 },

  { 881, 173, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Data receive/Data Type Conversion1"),
    TARGET_STRING(""), 0, 1, 50, 0, 2 },

  { 882, 173, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Data receive/Data Type Conversion2"),
    TARGET_STRING(""), 0, 1, 0, 0, 2 },

  { 883, 173, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Data receive/S-Function"),
    TARGET_STRING(""), 0, 3, 66, 0, 2 },

  { 884, 173, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Data receive/Unpack"),
    TARGET_STRING(""), 0, 4, 67, 0, 2 },

  { 885, 176, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Data write/Switch"),
    TARGET_STRING(""), 0, 1, 15, 0, 0 },

  { 886, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/is_running/Compare"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 887, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/ispmac1/Compare"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 888, 177, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/MATLAB Function/p1"),
    TARGET_STRING(""), 0, 1, 23, 0, 1 },

  { 889, 177, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/MATLAB Function/p2"),
    TARGET_STRING(""), 1, 1, 48, 0, 1 },

  { 890, 178, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Constant"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 891, 178, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Constant1"),
    TARGET_STRING(""), 0, 2, 55, 0, 1 },

  { 892, 178, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 7, 0, 1 },

  { 893, 178, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Data Type Conversion1"),
    TARGET_STRING(""), 0, 1, 7, 0, 1 },

  { 894, 178, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Data Type Conversion2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 895, 178, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Receive/p1"),
    TARGET_STRING(""), 0, 3, 6, 0, 1 },

  { 896, 178, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Receive/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 897, 178, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Unpack/p1"),
    TARGET_STRING(""), 0, 4, 7, 0, 1 },

  { 898, 178, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Unpack/p2"),
    TARGET_STRING(""), 1, 4, 7, 0, 1 },

  { 899, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/ispmac1/Compare"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 900, 180, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/decode robot/p1"),
    TARGET_STRING("isEP"), 0, 1, 0, 0, 1 },

  { 901, 180, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/decode robot/p2"),
    TARGET_STRING("isHumanExo"), 1, 1, 0, 0, 1 },

  { 902, 180, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/decode robot/p3"),
    TARGET_STRING("isNHPExo"), 2, 1, 0, 0, 1 },

  { 903, 180, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/decode robot/p4"),
    TARGET_STRING("isClassicExo"), 3, 1, 0, 0, 1 },

  { 904, 180, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/decode robot/p5"),
    TARGET_STRING("isUTSExo"), 4, 1, 0, 0, 1 },

  { 905, 180, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/decode robot/p6"),
    TARGET_STRING("isPMAC"), 5, 1, 0, 0, 1 },

  { 906, 180, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/decode robot/p7"),
    TARGET_STRING("isECAT"), 6, 1, 0, 0, 1 },

  { 907, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm Elbow Angle Offset"),
    TARGET_STRING("elbow angle offset"), 0, 1, 0, 0, 1 },

  { 908, 194, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm L1"),
    TARGET_STRING("L1"), 0, 1, 0, 0, 1 },

  { 909, 194, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm L2"),
    TARGET_STRING("L2"), 0, 1, 0, 0, 1 },

  { 910, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm L3 Error"),
    TARGET_STRING("L3 Error"), 0, 1, 0, 0, 1 },

  { 911, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm Motor1 Gear Ratio"),
    TARGET_STRING("M1 Gear Ratio"), 0, 1, 0, 0, 1 },

  { 912, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm Motor1 Orientation"),
    TARGET_STRING("M1 orientation"), 0, 1, 0, 0, 1 },

  { 913, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm Motor2 Gear Ratio"),
    TARGET_STRING("M2 Gear Ratio"), 0, 1, 0, 0, 1 },

  { 914, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm Motor2 Orientation"),
    TARGET_STRING("M2 Orientation"), 0, 1, 0, 0, 1 },

  { 915, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm Orientation"),
    TARGET_STRING("Arm Orientation"), 0, 1, 0, 0, 1 },

  { 916, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm Pointer Offset"),
    TARGET_STRING("Pointer offset"), 0, 1, 0, 0, 1 },

  { 917, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm Secondary Encoders"),
    TARGET_STRING("Has Secondary Enc"), 0, 1, 0, 0, 1 },

  { 918, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm Shoulder Angle Offset"),
    TARGET_STRING("shoulder angle offset"), 0, 1, 0, 0, 1 },

  { 919, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm Shoulder X"),
    TARGET_STRING("Shoulder X"), 0, 1, 0, 0, 1 },

  { 920, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm Shoulder Y"),
    TARGET_STRING("Shoulder Y"), 0, 1, 0, 0, 1 },

  { 921, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm Torque Constant"),
    TARGET_STRING("torque constant"), 0, 1, 0, 0, 1 },

  { 922, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm robot type"),
    TARGET_STRING("robot type"), 0, 1, 0, 0, 1 },

  { 923, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Arm robot version"),
    TARGET_STRING("robot version"), 0, 1, 0, 0, 1 },

  { 924, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm1/Status read1"),
    TARGET_STRING(""), 0, 1, 7, 0, 1 },

  { 925, 181, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/decode robot/p1"),
    TARGET_STRING("isEP"), 0, 1, 0, 0, 1 },

  { 926, 181, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/decode robot/p2"),
    TARGET_STRING("isHumanExo"), 1, 1, 0, 0, 1 },

  { 927, 181, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/decode robot/p3"),
    TARGET_STRING("isNHPExo"), 2, 1, 0, 0, 1 },

  { 928, 181, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/decode robot/p4"),
    TARGET_STRING("isClassicExo"), 3, 1, 0, 0, 1 },

  { 929, 181, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/decode robot/p5"),
    TARGET_STRING("isUTSExo"), 4, 1, 0, 0, 1 },

  { 930, 181, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/decode robot/p6"),
    TARGET_STRING("isPMAC"), 5, 1, 0, 0, 1 },

  { 931, 181, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/decode robot/p7"),
    TARGET_STRING("isECAT"), 6, 1, 0, 0, 1 },

  { 932, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm Elbow Angle Offset"),
    TARGET_STRING("elbow angle offset"), 0, 1, 0, 0, 1 },

  { 933, 194, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm L1"),
    TARGET_STRING("L1"), 0, 1, 0, 0, 1 },

  { 934, 194, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm L2"),
    TARGET_STRING("L2"), 0, 1, 0, 0, 1 },

  { 935, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm L3 Error"),
    TARGET_STRING("L3 Error"), 0, 1, 0, 0, 1 },

  { 936, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm Motor1 Gear Ratio"),
    TARGET_STRING("M1 Gear Ratio"), 0, 1, 0, 0, 1 },

  { 937, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm Motor1 Orientation"),
    TARGET_STRING("M1 orientation"), 0, 1, 0, 0, 1 },

  { 938, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm Motor2 Gear Ratio"),
    TARGET_STRING("M2 Gear Ratio"), 0, 1, 0, 0, 1 },

  { 939, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm Motor2 Orientation"),
    TARGET_STRING("M2 Orientation"), 0, 1, 0, 0, 1 },

  { 940, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm Orientation"),
    TARGET_STRING("Arm Orientation"), 0, 1, 0, 0, 1 },

  { 941, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm Pointer Offset"),
    TARGET_STRING("Pointer offset"), 0, 1, 0, 0, 1 },

  { 942, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm Secondary Encoders"),
    TARGET_STRING("Has Secondary Enc"), 0, 1, 0, 0, 1 },

  { 943, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm Shoulder Angle Offset"),
    TARGET_STRING("shoulder angle offset"), 0, 1, 0, 0, 1 },

  { 944, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm Shoulder X"),
    TARGET_STRING("Shoulder X"), 0, 1, 0, 0, 1 },

  { 945, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm Shoulder Y"),
    TARGET_STRING("Shoulder Y"), 0, 1, 0, 0, 1 },

  { 946, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm Torque Constant"),
    TARGET_STRING("torque constant"), 0, 1, 0, 0, 1 },

  { 947, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm robot type"),
    TARGET_STRING("robot type"), 0, 1, 0, 0, 1 },

  { 948, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Arm robot version"),
    TARGET_STRING("robot version"), 0, 1, 0, 0, 1 },

  { 949, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/constants/arm2/Status read1"),
    TARGET_STRING(""), 0, 1, 7, 0, 1 },

  { 950, 188, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/Counter Free-Running/Output"),
    TARGET_STRING(""), 0, 2, 0, 0, 0 },

  { 951, 0, TARGET_STRING(
    "GUI Control/tables/Counter Free-Running/Increment Real World/FixPt Sum1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 952, 0, TARGET_STRING(
    "GUI Control/tables/Counter Free-Running/Wrap To Zero/FixPt Switch"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 953, 7, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Counter Free-Running/Increment Real World/FixPt Sum1"),
    TARGET_STRING(""), 0, 2, 0, 0, 0 },

  { 954, 7, TARGET_STRING(
    "DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Counter Free-Running/Wrap To Zero/FixPt Switch"),
    TARGET_STRING(""), 0, 2, 0, 0, 0 },

  { 955, 28, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/Whistle state/p1"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 956, 28, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/Whistle state/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 957, 28, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/Whistle state/p3"),
    TARGET_STRING(""), 2, 1, 0, 0, 1 },

  { 958, 29, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/cleanword"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 959, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/Memory"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 960, 41, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/Whistle state/p1"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 961, 41, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/Whistle state/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 962, 41, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/Whistle state/p3"),
    TARGET_STRING(""), 2, 1, 0, 0, 1 },

  { 963, 42, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/cleanword"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 964, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/Memory"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 965, 43, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/MATLAB Function1"),
    TARGET_STRING(""), 0, 8, 0, 0, 1 },

  { 966, 45, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/AbsEncoder machine/p1"),
    TARGET_STRING(""), 0, 5, 3, 0, 1 },

  { 967, 45, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/AbsEncoder machine/p2"),
    TARGET_STRING(""), 1, 5, 32, 0, 1 },

  { 968, 45, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/AbsEncoder machine/p3"),
    TARGET_STRING(""), 2, 5, 50, 0, 1 },

  { 969, 45, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/AbsEncoder machine/p4"),
    TARGET_STRING(""), 3, 5, 0, 0, 1 },

  { 970, 46, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/set-up values/p1"),
    TARGET_STRING(""), 0, 1, 68, 0, 1 },

  { 971, 46, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/set-up values/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 972, 46, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/set-up values/p3"),
    TARGET_STRING(""), 2, 1, 11, 0, 1 },

  { 973, 46, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/set-up values/p4"),
    TARGET_STRING(""), 3, 1, 69, 0, 1 },

  { 974, 46, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/set-up values/p5"),
    TARGET_STRING(""), 4, 1, 0, 0, 1 },

  { 975, 47, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/Memory"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 976, 47, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/Memory1"),
    TARGET_STRING(""), 0, 5, 7, 0, 1 },

  { 977, 47, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/BKIN EtherCAT Async SDO Download/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 978, 47, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/BKIN EtherCAT Async SDO Download/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 979, 47, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/BKIN EtherCAT Async SDO Upload/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 980, 47, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/BKIN EtherCAT Async SDO Upload/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 981, 47, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/BKIN EtherCAT Async SDO Upload/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 982, 48, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/AbsEncoder machine/p1"),
    TARGET_STRING(""), 0, 5, 3, 0, 1 },

  { 983, 48, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/AbsEncoder machine/p2"),
    TARGET_STRING(""), 1, 5, 32, 0, 1 },

  { 984, 48, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/AbsEncoder machine/p3"),
    TARGET_STRING(""), 2, 5, 50, 0, 1 },

  { 985, 48, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/AbsEncoder machine/p4"),
    TARGET_STRING(""), 3, 5, 0, 0, 1 },

  { 986, 49, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/set-up values/p1"),
    TARGET_STRING(""), 0, 1, 68, 0, 1 },

  { 987, 49, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/set-up values/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 988, 49, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/set-up values/p3"),
    TARGET_STRING(""), 2, 1, 11, 0, 1 },

  { 989, 49, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/set-up values/p4"),
    TARGET_STRING(""), 3, 1, 69, 0, 1 },

  { 990, 49, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/set-up values/p5"),
    TARGET_STRING(""), 4, 1, 0, 0, 1 },

  { 991, 50, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/Memory"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 992, 50, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/Memory1"),
    TARGET_STRING(""), 0, 5, 7, 0, 1 },

  { 993, 50, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/BKIN EtherCAT Async SDO Download/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 994, 50, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/BKIN EtherCAT Async SDO Download/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 995, 50, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/BKIN EtherCAT Async SDO Upload/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 996, 50, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/BKIN EtherCAT Async SDO Upload/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 997, 50, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/BKIN EtherCAT Async SDO Upload/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 998, 58, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/SDO read machine/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 999, 58, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/SDO read machine/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1000, 59, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/values"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1001, 60, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/values2"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1002, 61, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/readAddr"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1003, 61, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Data Type Conversion1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1004, 61, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Data Type Conversion2"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1005, 61, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/convert"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1006, 61, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/convert1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1007, 61, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/convert2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1008, 61, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/convert3"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1009, 61, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/status"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1010, 61, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Memory"),
    TARGET_STRING(""), 0, 5, 7, 0, 1 },

  { 1011, 62, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/MATLAB Function"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1012, 63, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/SDO write machine/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1013, 63, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/SDO write machine/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1014, 64, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/convert"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1015, 65, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/writeData"),
    TARGET_STRING(""), 0, 1, 39, 0, 1 },

  { 1016, 65, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/Data Type Conversion1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1017, 65, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/Data Type Conversion2"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1018, 65, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/status"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1019, 65, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/Memory"),
    TARGET_STRING(""), 0, 5, 7, 0, 1 },

  { 1020, 65, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/BKIN EtherCAT Async SDO Download/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1021, 65, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/BKIN EtherCAT Async SDO Download/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 1022, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Memory"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1023, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Memory1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1024, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Memory2"),
    TARGET_STRING(""), 0, 5, 7, 0, 1 },

  { 1025, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Rate Transition"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1026, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Rate Transition1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1027, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Rate Transition2"),
    TARGET_STRING(""), 0, 5, 7, 0, 1 },

  { 1028, 86, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/Whistle state/p1"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1029, 86, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/Whistle state/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 1030, 86, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/Whistle state/p3"),
    TARGET_STRING(""), 2, 1, 0, 0, 1 },

  { 1031, 87, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/cleanword"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1032, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/Memory"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1033, 99, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/Whistle state/p1"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1034, 99, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/Whistle state/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 1035, 99, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/Whistle state/p3"),
    TARGET_STRING(""), 2, 1, 0, 0, 1 },

  { 1036, 100, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/cleanword"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1037, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/Memory"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1038, 102, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/AbsEncoder machine/p1"),
    TARGET_STRING(""), 0, 5, 3, 0, 1 },

  { 1039, 102, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/AbsEncoder machine/p2"),
    TARGET_STRING(""), 1, 5, 32, 0, 1 },

  { 1040, 102, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/AbsEncoder machine/p3"),
    TARGET_STRING(""), 2, 5, 50, 0, 1 },

  { 1041, 102, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/AbsEncoder machine/p4"),
    TARGET_STRING(""), 3, 5, 0, 0, 1 },

  { 1042, 103, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/set-up values/p1"),
    TARGET_STRING(""), 0, 1, 68, 0, 1 },

  { 1043, 103, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/set-up values/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 1044, 103, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/set-up values/p3"),
    TARGET_STRING(""), 2, 1, 11, 0, 1 },

  { 1045, 103, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/set-up values/p4"),
    TARGET_STRING(""), 3, 1, 69, 0, 1 },

  { 1046, 103, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/set-up values/p5"),
    TARGET_STRING(""), 4, 1, 0, 0, 1 },

  { 1047, 104, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/Memory"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1048, 104, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/Memory1"),
    TARGET_STRING(""), 0, 5, 7, 0, 1 },

  { 1049, 104, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/BKIN EtherCAT Async SDO Download/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1050, 104, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/BKIN EtherCAT Async SDO Download/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 1051, 104, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/BKIN EtherCAT Async SDO Upload/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1052, 104, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/BKIN EtherCAT Async SDO Upload/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1053, 104, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/BKIN EtherCAT Async SDO Upload/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1054, 105, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/AbsEncoder machine/p1"),
    TARGET_STRING(""), 0, 5, 3, 0, 1 },

  { 1055, 105, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/AbsEncoder machine/p2"),
    TARGET_STRING(""), 1, 5, 32, 0, 1 },

  { 1056, 105, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/AbsEncoder machine/p3"),
    TARGET_STRING(""), 2, 5, 50, 0, 1 },

  { 1057, 105, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/AbsEncoder machine/p4"),
    TARGET_STRING(""), 3, 5, 0, 0, 1 },

  { 1058, 106, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/set-up values/p1"),
    TARGET_STRING(""), 0, 1, 68, 0, 1 },

  { 1059, 106, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/set-up values/p2"),
    TARGET_STRING(""), 1, 1, 0, 0, 1 },

  { 1060, 106, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/set-up values/p3"),
    TARGET_STRING(""), 2, 1, 11, 0, 1 },

  { 1061, 106, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/set-up values/p4"),
    TARGET_STRING(""), 3, 1, 69, 0, 1 },

  { 1062, 106, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/set-up values/p5"),
    TARGET_STRING(""), 4, 1, 0, 0, 1 },

  { 1063, 107, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/Memory"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1064, 107, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/Memory1"),
    TARGET_STRING(""), 0, 5, 7, 0, 1 },

  { 1065, 107, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/BKIN EtherCAT Async SDO Download/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1066, 107, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/BKIN EtherCAT Async SDO Download/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 1067, 107, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/BKIN EtherCAT Async SDO Upload/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1068, 107, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/BKIN EtherCAT Async SDO Upload/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1069, 107, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/BKIN EtherCAT Async SDO Upload/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1070, 114, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/SDO read machine/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1071, 114, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/SDO read machine/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1072, 115, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/values"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1073, 116, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/values2"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1074, 117, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/readAddr"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1075, 117, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Conversion1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1076, 117, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Conversion2"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1077, 117, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/convert"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1078, 117, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/convert1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1079, 117, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/convert2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1080, 117, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/convert3"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1081, 117, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/status"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1082, 117, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Memory"),
    TARGET_STRING(""), 0, 5, 7, 0, 1 },

  { 1083, 118, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/MATLAB Function"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1084, 119, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/SDO write machine/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1085, 119, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/SDO write machine/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1086, 120, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/convert"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1087, 121, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/writeData"),
    TARGET_STRING(""), 0, 1, 39, 0, 1 },

  { 1088, 121, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/Data Type Conversion1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1089, 121, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/Data Type Conversion2"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1090, 121, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/status"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1091, 121, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/Memory"),
    TARGET_STRING(""), 0, 5, 7, 0, 1 },

  { 1092, 121, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/BKIN EtherCAT Async SDO Download/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1093, 121, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/BKIN EtherCAT Async SDO Download/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 1094, 122, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/MATLAB Function1"),
    TARGET_STRING(""), 0, 8, 0, 0, 1 },

  { 1095, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Memory"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1096, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Memory1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1097, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Memory2"),
    TARGET_STRING(""), 0, 5, 7, 0, 1 },

  { 1098, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Rate Transition"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1099, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Rate Transition1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1100, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Rate Transition2"),
    TARGET_STRING(""), 0, 5, 7, 0, 1 },

  { 1101, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Counter Free-Running/Increment Real World/FixPt Sum1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1102, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Counter Free-Running/Wrap To Zero/FixPt Switch"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1103, 140, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/create filtered velocities/filter_velocities"),
    TARGET_STRING(""), 0, 1, 8, 0, 0 },

  { 1104, 141, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/update/create filtered velocities/rebuild"),
    TARGET_STRING(""), 0, 1, 23, 0, 0 },

  { 1105, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Detect Change/FixPt Relational Operator"),
    TARGET_STRING(""), 0, 3, 0, 0, 1 },

  { 1106, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Detect Change/Delay Input1"),
    TARGET_STRING("U(k-1)"), 0, 1, 0, 0, 1 },

  { 1107, 154, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Byte Reversal"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1108, 154, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Byte Reversal1"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1109, 154, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Byte Reversal2"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1110, 154, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Pack"),
    TARGET_STRING(""), 0, 3, 4, 0, 1 },

  { 1111, 154, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Switch"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1112, 154, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Width"),
    TARGET_STRING(""), 0, 1, 0, 0, 3 },

  { 1113, 160, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Byte Reversal"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1114, 160, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Byte Reversal1"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1115, 160, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Byte Reversal2"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1116, 160, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Pack"),
    TARGET_STRING(""), 0, 3, 4, 0, 1 },

  { 1117, 160, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Switch"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1118, 160, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Width"),
    TARGET_STRING(""), 0, 1, 0, 0, 3 },

  { 1119, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Detect Change/FixPt Relational Operator"),
    TARGET_STRING(""), 0, 3, 0, 0, 1 },

  { 1120, 162, TARGET_STRING(
    "DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Detect Change/Delay Input1"),
    TARGET_STRING("U(k-1)"), 0, 1, 0, 0, 1 },

  { 1121, 164, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/TypeCast"),
    TARGET_STRING(""), 0, 4, 0, 0, 1 },

  { 1122, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Data Type Conversion"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1123, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/DPRAM Read Value"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1124, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Unit Delay"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1125, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Unit Delay1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1126, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Unit Delay2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1127, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Unit Delay3"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1128, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Counter Free-Running/Increment Real World/FixPt Sum1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1129, 194, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_file_source/Counter Free-Running/Wrap To Zero/FixPt Switch"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1130, 178, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Counter Free-Running/Output"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1131, 188, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/Counter Free-Running/Increment Real World/FixPt Sum1"),
    TARGET_STRING(""), 0, 2, 0, 0, 0 },

  { 1132, 188, TARGET_STRING(
    "DataLogging/Poll KINARM/createKINData/Counter Free-Running/Wrap To Zero/FixPt Switch"),
    TARGET_STRING(""), 0, 2, 0, 0, 0 },

  { 1133, 20, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/parse status register/p1"),
    TARGET_STRING("allOK"), 0, 2, 0, 0, 1 },

  { 1134, 20, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/parse status register/p2"),
    TARGET_STRING("ampStatus"), 1, 2, 0, 0, 1 },

  { 1135, 20, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/parse status register/p3"),
    TARGET_STRING("servoEnabled"), 2, 2, 0, 0, 1 },

  { 1136, 20, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/parse status register/p4"),
    TARGET_STRING("fault"), 3, 2, 0, 0, 1 },

  { 1137, 20, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/parse status register/p5"),
    TARGET_STRING("currentLimitEnabled"), 4, 2, 0, 0, 1 },

  { 1138, 20, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/parse status register/p6"),
    TARGET_STRING("EStop"), 5, 2, 0, 0, 1 },

  { 1139, 20, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/parse status register/p7"),
    TARGET_STRING("motorsOn"), 6, 2, 0, 0, 1 },

  { 1140, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/A1M1Convert"),
    TARGET_STRING(""), 0, 1, 39, 0, 1 },

  { 1141, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/Data Type Conversion1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1142, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive/p1"),
    TARGET_STRING("Status word"), 0, 7, 0, 0, 1 },

  { 1143, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive/p2"),
    TARGET_STRING("status register"), 1, 2, 0, 0, 1 },

  { 1144, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive/p3"),
    TARGET_STRING("primary position"), 2, 5, 0, 0, 1 },

  { 1145, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive/p4"),
    TARGET_STRING("secondary position"), 3, 5, 0, 0, 1 },

  { 1146, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive/p5"),
    TARGET_STRING("primary velocity"), 4, 5, 0, 0, 1 },

  { 1147, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive/p6"),
    TARGET_STRING("torque"), 5, 6, 0, 0, 1 },

  { 1148, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive/p7"),
    TARGET_STRING("digital inputs"), 6, 5, 0, 0, 1 },

  { 1149, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive/p8"),
    TARGET_STRING("actual mode of operation"), 7, 8, 0, 0, 1 },

  { 1150, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/Compare/Compare"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 1151, 21, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1152, 21, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY/p2"),
    TARGET_STRING(""), 1, 5, 7, 0, 1 },

  { 1153, 21, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY/p3"),
    TARGET_STRING(""), 2, 5, 0, 0, 1 },

  { 1154, 21, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY/p4"),
    TARGET_STRING(""), 3, 1, 32, 0, 1 },

  { 1155, 24, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/fault monitor"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1156, 25, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/pass emcy"),
    TARGET_STRING(""), 0, 1, 39, 0, 1 },

  { 1157, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/driveID"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1158, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1159, 27, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/countsToRads/p1"),
    TARGET_STRING("R1M1_LinkAngle"), 0, 1, 0, 0, 1 },

  { 1160, 27, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/countsToRads/p2"),
    TARGET_STRING("R1M1_PrimaryLinkAngle"), 1, 1, 0, 0, 1 },

  { 1161, 27, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/countsToRads/p3"),
    TARGET_STRING("R1M1_PrimaryLinkVelocity"), 2, 1, 0, 0, 1 },

  { 1162, 27, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/countsToRads/p4"),
    TARGET_STRING("R1M1_RecordedTorque"), 3, 1, 0, 0, 1 },

  { 1163, 27, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/countsToRads/p5"),
    TARGET_STRING("R1M1_digitalInputs"), 4, 1, 9, 0, 1 },

  { 1164, 27, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/countsToRads/p6"),
    TARGET_STRING("R1M1_digitalDiagnostics"), 5, 1, 0, 0, 1 },

  { 1165, 27, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/countsToRads/p7"),
    TARGET_STRING("R1_calibrationButton"), 6, 1, 0, 0, 1 },

  { 1166, 27, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/countsToRads/p8"),
    TARGET_STRING("R1_EPGripSensor"), 7, 0, 0, 0, 1 },

  { 1167, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/L2 select"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1168, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/L2 select1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1169, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/L2 select2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1170, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/L2 select3"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1171, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/L2 select4"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1172, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/L2 select5"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1173, 33, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/parse status register1/p1"),
    TARGET_STRING("allOK"), 0, 2, 0, 0, 1 },

  { 1174, 33, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/parse status register1/p2"),
    TARGET_STRING("ampStatus"), 1, 2, 0, 0, 1 },

  { 1175, 33, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/parse status register1/p3"),
    TARGET_STRING("servoEnabled"), 2, 2, 0, 0, 1 },

  { 1176, 33, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/parse status register1/p4"),
    TARGET_STRING("fault"), 3, 2, 0, 0, 1 },

  { 1177, 33, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/parse status register1/p5"),
    TARGET_STRING("currentLimitEnabled"), 4, 2, 0, 0, 1 },

  { 1178, 33, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/parse status register1/p6"),
    TARGET_STRING("EStop"), 5, 2, 0, 0, 1 },

  { 1179, 33, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/parse status register1/p7"),
    TARGET_STRING("motorsOn"), 6, 2, 0, 0, 1 },

  { 1180, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/A1M2Convert"),
    TARGET_STRING(""), 0, 1, 39, 0, 1 },

  { 1181, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/Data Type Conversion"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1182, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive/p1"),
    TARGET_STRING("Status word"), 0, 7, 0, 0, 1 },

  { 1183, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive/p2"),
    TARGET_STRING("status register"), 1, 2, 0, 0, 1 },

  { 1184, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive/p3"),
    TARGET_STRING("primary position"), 2, 5, 0, 0, 1 },

  { 1185, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive/p4"),
    TARGET_STRING("secondary position"), 3, 5, 0, 0, 1 },

  { 1186, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive/p5"),
    TARGET_STRING("primary velocity"), 4, 5, 0, 0, 1 },

  { 1187, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive/p6"),
    TARGET_STRING("torque"), 5, 6, 0, 0, 1 },

  { 1188, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive/p7"),
    TARGET_STRING("digital inputs"), 6, 5, 0, 0, 1 },

  { 1189, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive/p8"),
    TARGET_STRING("actual mode of operation"), 7, 8, 0, 0, 1 },

  { 1190, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/Compare/Compare"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 1191, 34, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1192, 34, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY/p2"),
    TARGET_STRING(""), 1, 5, 7, 0, 1 },

  { 1193, 34, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY/p3"),
    TARGET_STRING(""), 2, 5, 0, 0, 1 },

  { 1194, 34, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY/p4"),
    TARGET_STRING(""), 3, 1, 32, 0, 1 },

  { 1195, 37, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/fault monitor"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1196, 38, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/pass emcy"),
    TARGET_STRING(""), 0, 1, 39, 0, 1 },

  { 1197, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/driveID"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1198, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1199, 40, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/countsToRads/p1"),
    TARGET_STRING("R1M2_LinkAngle"), 0, 1, 0, 0, 1 },

  { 1200, 40, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/countsToRads/p2"),
    TARGET_STRING("R1M2_PrimaryLinkAngle"), 1, 1, 0, 0, 1 },

  { 1201, 40, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/countsToRads/p3"),
    TARGET_STRING("R1M2_PrimaryLinkVelocity"), 2, 1, 0, 0, 1 },

  { 1202, 40, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/countsToRads/p4"),
    TARGET_STRING("R1M2_RecordedTorque"), 3, 1, 0, 0, 1 },

  { 1203, 40, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/countsToRads/p5"),
    TARGET_STRING("R1M2_digitalInputs"), 4, 1, 9, 0, 1 },

  { 1204, 40, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/countsToRads/p6"),
    TARGET_STRING("R1M2_digitalDiagnostics"), 5, 1, 0, 0, 1 },

  { 1205, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/L2 select"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1206, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/L2 select1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1207, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/L2 select2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1208, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/L2 select3"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1209, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/L2 select4"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1210, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/L2 select5"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1211, 52, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 1 SDO/MATLAB Function"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1212, 53, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 1 SDO/converter/p1"),
    TARGET_STRING("uint_32"), 0, 2, 0, 0, 1 },

  { 1213, 53, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 1 SDO/converter/p2"),
    TARGET_STRING("int_32"), 1, 5, 0, 0, 1 },

  { 1214, 53, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 1 SDO/converter/p3"),
    TARGET_STRING("float"), 2, 1, 0, 0, 1 },

  { 1215, 54, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 1 SDO/BKIN EtherCAT Async SDO Upload1/p1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1216, 54, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 1 SDO/BKIN EtherCAT Async SDO Upload1/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1217, 54, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 1 SDO/BKIN EtherCAT Async SDO Upload1/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1218, 55, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 2 SDO/MATLAB Function"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1219, 56, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 2 SDO/converter/p1"),
    TARGET_STRING("uint_32"), 0, 2, 0, 0, 1 },

  { 1220, 56, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 2 SDO/converter/p2"),
    TARGET_STRING("int_32"), 1, 5, 0, 0, 1 },

  { 1221, 56, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 2 SDO/converter/p3"),
    TARGET_STRING("float"), 2, 1, 0, 0, 1 },

  { 1222, 57, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 2 SDO/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1223, 57, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 2 SDO/Data Type Conversion1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1224, 57, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 2 SDO/BKIN EtherCAT Async SDO Upload1/p1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1225, 57, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 2 SDO/BKIN EtherCAT Async SDO Upload1/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1226, 57, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 2 SDO/BKIN EtherCAT Async SDO Upload1/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1227, 67, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Read Drive 1 SDO/MATLAB Function"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1228, 68, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Read Drive 1 SDO/converter/p1"),
    TARGET_STRING("uint_32"), 0, 2, 0, 0, 1 },

  { 1229, 68, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Read Drive 1 SDO/converter/p2"),
    TARGET_STRING("int_32"), 1, 5, 0, 0, 1 },

  { 1230, 68, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Read Drive 1 SDO/converter/p3"),
    TARGET_STRING("float"), 2, 1, 0, 0, 1 },

  { 1231, 69, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Read Drive 1 SDO/BKIN EtherCAT Async SDO Upload1/p1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1232, 69, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Read Drive 1 SDO/BKIN EtherCAT Async SDO Upload1/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1233, 69, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Read Drive 1 SDO/BKIN EtherCAT Async SDO Upload1/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1234, 78, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/parse status register1/p1"),
    TARGET_STRING("allOk"), 0, 2, 0, 0, 1 },

  { 1235, 78, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/parse status register1/p2"),
    TARGET_STRING("ampStatus"), 1, 2, 0, 0, 1 },

  { 1236, 78, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/parse status register1/p3"),
    TARGET_STRING("servoEnabled"), 2, 2, 0, 0, 1 },

  { 1237, 78, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/parse status register1/p4"),
    TARGET_STRING("fault"), 3, 2, 0, 0, 1 },

  { 1238, 78, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/parse status register1/p5"),
    TARGET_STRING("currentLimitEnabled"), 4, 2, 0, 0, 1 },

  { 1239, 78, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/parse status register1/p6"),
    TARGET_STRING("EStop"), 5, 2, 0, 0, 1 },

  { 1240, 78, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/parse status register1/p7"),
    TARGET_STRING("motorsOn"), 6, 2, 0, 0, 1 },

  { 1241, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/A2M1Convert"),
    TARGET_STRING(""), 0, 1, 39, 0, 1 },

  { 1242, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/Data Type Conversion"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1243, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive/p1"),
    TARGET_STRING("Status word"), 0, 7, 0, 0, 1 },

  { 1244, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 1245, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive/p3"),
    TARGET_STRING("primary position"), 2, 5, 0, 0, 1 },

  { 1246, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive/p4"),
    TARGET_STRING("secondary position"), 3, 5, 0, 0, 1 },

  { 1247, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive/p5"),
    TARGET_STRING("primary velocity"), 4, 5, 0, 0, 1 },

  { 1248, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive/p6"),
    TARGET_STRING("torque"), 5, 6, 0, 0, 1 },

  { 1249, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive/p7"),
    TARGET_STRING("digital input"), 6, 5, 0, 0, 1 },

  { 1250, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive/p8"),
    TARGET_STRING("actual mode of operation"), 7, 8, 0, 0, 1 },

  { 1251, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/Compare/Compare"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 1252, 79, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1253, 79, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY/p2"),
    TARGET_STRING(""), 1, 5, 7, 0, 1 },

  { 1254, 79, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY/p3"),
    TARGET_STRING(""), 2, 5, 0, 0, 1 },

  { 1255, 79, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY/p4"),
    TARGET_STRING(""), 3, 1, 32, 0, 1 },

  { 1256, 82, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/fault monitor"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1257, 83, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/pass emcy"),
    TARGET_STRING(""), 0, 1, 39, 0, 1 },

  { 1258, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/driveID"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1259, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1260, 85, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/countsToRads/p1"),
    TARGET_STRING("R2M1_LinkAngle"), 0, 1, 0, 0, 1 },

  { 1261, 85, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/countsToRads/p2"),
    TARGET_STRING("R2M1_PrimaryLinkAngle"), 1, 1, 0, 0, 1 },

  { 1262, 85, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/countsToRads/p3"),
    TARGET_STRING("R2M1_PrimaryLinkVelocity"), 2, 1, 0, 0, 1 },

  { 1263, 85, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/countsToRads/p4"),
    TARGET_STRING("R2M1_RecordedTorque"), 3, 1, 0, 0, 1 },

  { 1264, 85, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/countsToRads/p5"),
    TARGET_STRING("R2M1_digitalInputs"), 4, 1, 9, 0, 1 },

  { 1265, 85, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/countsToRads/p6"),
    TARGET_STRING("R2M1_digitalDiagnostics"), 5, 1, 0, 0, 1 },

  { 1266, 85, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/countsToRads/p7"),
    TARGET_STRING("R2_calibrationButton"), 6, 1, 0, 0, 1 },

  { 1267, 85, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/countsToRads/p8"),
    TARGET_STRING("R2_EPGripSensor"), 7, 0, 0, 0, 1 },

  { 1268, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/L2 select"),
    TARGET_STRING("offset rads"), 0, 1, 0, 0, 1 },

  { 1269, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/L2 select1"),
    TARGET_STRING("enc orient"), 0, 1, 0, 0, 1 },

  { 1270, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/L2 select2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1271, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/L2 select3"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1272, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/L2 select4"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1273, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/L2 select5"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1274, 91, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/parse status register1/p1"),
    TARGET_STRING("allOk"), 0, 2, 0, 0, 1 },

  { 1275, 91, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/parse status register1/p2"),
    TARGET_STRING("ampStatus"), 1, 2, 0, 0, 1 },

  { 1276, 91, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/parse status register1/p3"),
    TARGET_STRING("servoEnabled"), 2, 2, 0, 0, 1 },

  { 1277, 91, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/parse status register1/p4"),
    TARGET_STRING("fault"), 3, 2, 0, 0, 1 },

  { 1278, 91, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/parse status register1/p5"),
    TARGET_STRING("currentLimitEnabled"), 4, 2, 0, 0, 1 },

  { 1279, 91, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/parse status register1/p6"),
    TARGET_STRING("EStop"), 5, 2, 0, 0, 1 },

  { 1280, 91, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/parse status register1/p7"),
    TARGET_STRING("motorsOn"), 6, 2, 0, 0, 1 },

  { 1281, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/A2M2Convert"),
    TARGET_STRING(""), 0, 1, 39, 0, 1 },

  { 1282, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/Data Type Conversion"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1283, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive/p1"),
    TARGET_STRING("status word"), 0, 7, 0, 0, 1 },

  { 1284, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive/p2"),
    TARGET_STRING("status register"), 1, 2, 0, 0, 1 },

  { 1285, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive/p3"),
    TARGET_STRING("position primary"), 2, 5, 0, 0, 1 },

  { 1286, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive/p4"),
    TARGET_STRING("position secondary"), 3, 5, 0, 0, 1 },

  { 1287, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive/p5"),
    TARGET_STRING("velocity primary"), 4, 5, 0, 0, 1 },

  { 1288, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive/p6"),
    TARGET_STRING("torque"), 5, 6, 0, 0, 1 },

  { 1289, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive/p7"),
    TARGET_STRING("digital input"), 6, 5, 0, 0, 1 },

  { 1290, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive/p8"),
    TARGET_STRING("actual mode of operation"), 7, 8, 0, 0, 1 },

  { 1291, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/Compare/Compare"),
    TARGET_STRING(""), 0, 0, 0, 0, 1 },

  { 1292, 92, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1293, 92, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY/p2"),
    TARGET_STRING(""), 1, 5, 7, 0, 1 },

  { 1294, 92, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY/p3"),
    TARGET_STRING(""), 2, 5, 0, 0, 1 },

  { 1295, 92, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY/p4"),
    TARGET_STRING(""), 3, 1, 32, 0, 1 },

  { 1296, 95, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/fault monitor"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1297, 96, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/pass emcy"),
    TARGET_STRING(""), 0, 1, 39, 0, 1 },

  { 1298, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/driveID"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1299, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1300, 98, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/countsToRads/p1"),
    TARGET_STRING("R2M2_LinkAngle"), 0, 1, 0, 0, 1 },

  { 1301, 98, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/countsToRads/p2"),
    TARGET_STRING("R2M2_PrimaryLinkAngle"), 1, 1, 0, 0, 1 },

  { 1302, 98, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/countsToRads/p3"),
    TARGET_STRING("R2M2_PrimaryLinkVelocity"), 2, 1, 0, 0, 1 },

  { 1303, 98, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/countsToRads/p4"),
    TARGET_STRING("R2M2_RecordedTorque"), 3, 1, 0, 0, 1 },

  { 1304, 98, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/countsToRads/p5"),
    TARGET_STRING("R2M2_digitalInputs"), 4, 1, 9, 0, 1 },

  { 1305, 98, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/countsToRads/p6"),
    TARGET_STRING("R2M2_digitalDiagnostics"), 5, 1, 0, 0, 1 },

  { 1306, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/L2 select"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1307, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/L2 select1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1308, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/L2 select2"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1309, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/L2 select3"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1310, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/L2 select4"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1311, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/L2 select5"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1312, 109, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 3 SDO/MATLAB Function"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1313, 110, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 3 SDO/converter/p1"),
    TARGET_STRING("uint_32"), 0, 2, 0, 0, 1 },

  { 1314, 110, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 3 SDO/converter/p2"),
    TARGET_STRING("int_32"), 1, 5, 0, 0, 1 },

  { 1315, 110, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 3 SDO/converter/p3"),
    TARGET_STRING("float"), 2, 1, 0, 0, 1 },

  { 1316, 111, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 3 SDO/BKIN EtherCAT Async SDO Upload1/p1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1317, 111, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 3 SDO/BKIN EtherCAT Async SDO Upload1/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1318, 111, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 3 SDO/BKIN EtherCAT Async SDO Upload1/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1319, 112, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 4 SDO/converter/p1"),
    TARGET_STRING("uint_32"), 0, 2, 0, 0, 1 },

  { 1320, 112, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 4 SDO/converter/p2"),
    TARGET_STRING("int_32"), 1, 5, 0, 0, 1 },

  { 1321, 112, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 4 SDO/converter/p3"),
    TARGET_STRING("float"), 2, 1, 0, 0, 1 },

  { 1322, 113, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 4 SDO/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1323, 113, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 4 SDO/Data Type Conversion1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1324, 113, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 4 SDO/BKIN EtherCAT Async SDO Upload1/p1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1325, 113, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 4 SDO/BKIN EtherCAT Async SDO Upload1/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1326, 113, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 4 SDO/BKIN EtherCAT Async SDO Upload1/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1327, 124, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Read Drive 3 SDO/MATLAB Function"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1328, 125, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Read Drive 3 SDO/converter/p1"),
    TARGET_STRING("uint_32"), 0, 2, 0, 0, 1 },

  { 1329, 125, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Read Drive 3 SDO/converter/p2"),
    TARGET_STRING("int_32"), 1, 5, 0, 0, 1 },

  { 1330, 125, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Read Drive 3 SDO/converter/p3"),
    TARGET_STRING("float"), 2, 1, 0, 0, 1 },

  { 1331, 126, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Read Drive 3 SDO/BKIN EtherCAT Async SDO Upload1/p1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1332, 126, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Read Drive 3 SDO/BKIN EtherCAT Async SDO Upload1/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1333, 126, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Read Drive 3 SDO/BKIN EtherCAT Async SDO Upload1/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1334, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Counter Free-Running/Output"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1335, 163, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Read DPRAM/Data Type Conversion"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1336, 163, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Read DPRAM/Data Type Conversion1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1337, 163, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Read DPRAM/Data Type Conversion2"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1338, 163, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Read DPRAM/Read"),
    TARGET_STRING(""), 0, 4, 0, 0, 1 },

  { 1339, 165, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Write DPRAM/Data Type Conversion"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1340, 165, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Write DPRAM/Data Type Conversion1"),
    TARGET_STRING(""), 0, 4, 0, 0, 1 },

  { 1341, 178, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Counter Free-Running/Increment Real World/FixPt Sum1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1342, 178, TARGET_STRING(
    "DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Counter Free-Running/Wrap To Zero/FixPt Switch"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1343, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/SR_clean/Switch"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1344, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/SW_clean/Switch"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1345, 19, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/Subsystem/MATLAB Function/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1346, 19, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/Subsystem/MATLAB Function/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1347, 22, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/MATLAB Function"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1348, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/Data Type Conversion"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1349, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/Data Type Conversion1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1350, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/Data Type Conversion2"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1351, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/Memory"),
    TARGET_STRING(""), 0, 2, 32, 0, 1 },

  { 1352, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/Rate Transition"),
    TARGET_STRING(""), 0, 2, 32, 0, 1 },

  { 1353, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/BKIN EtherCAT Async SDO Upload/p1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1354, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/BKIN EtherCAT Async SDO Upload/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1355, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/BKIN EtherCAT Async SDO Upload/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1356, 23, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Value/MATLAB Function"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1357, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Value/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1358, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Value/Memory"),
    TARGET_STRING(""), 0, 5, 32, 0, 1 },

  { 1359, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Value/Rate Transition"),
    TARGET_STRING(""), 0, 5, 32, 0, 1 },

  { 1360, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Value/BKIN EtherCAT Async SDO Upload/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1361, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Value/BKIN EtherCAT Async SDO Upload/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1362, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Value/BKIN EtherCAT Async SDO Upload/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1363, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/clear errors/Data Type Conversion"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1364, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/clear errors/Data Type Conversion1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1365, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/clear errors/Memory"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1366, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/clear errors/BKIN EtherCAT Async SDO Download/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1367, 26, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/clear errors/BKIN EtherCAT Async SDO Download/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 1368, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/SR_clean/Switch"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1369, 74, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/SW_clean/Switch"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1370, 32, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/Subsystem/MATLAB Function/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1371, 32, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/Subsystem/MATLAB Function/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1372, 35, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count/MATLAB Function"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1373, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count/Data Type Conversion"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1374, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count/Data Type Conversion1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1375, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count/Data Type Conversion2"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1376, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count/Memory"),
    TARGET_STRING(""), 0, 2, 32, 0, 1 },

  { 1377, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count/Rate Transition"),
    TARGET_STRING(""), 0, 2, 32, 0, 1 },

  { 1378, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count/BKIN EtherCAT Async SDO Upload/p1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1379, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count/BKIN EtherCAT Async SDO Upload/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1380, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count/BKIN EtherCAT Async SDO Upload/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1381, 36, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Value/MATLAB Function"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1382, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Value/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1383, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Value/Memory"),
    TARGET_STRING(""), 0, 5, 32, 0, 1 },

  { 1384, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Value/Rate Transition"),
    TARGET_STRING(""), 0, 5, 32, 0, 1 },

  { 1385, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Value/BKIN EtherCAT Async SDO Upload/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1386, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Value/BKIN EtherCAT Async SDO Upload/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1387, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Value/BKIN EtherCAT Async SDO Upload/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1388, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/clear errors/Data Type Conversion"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1389, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/clear errors/Data Type Conversion1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1390, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/clear errors/Memory"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1391, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/clear errors/BKIN EtherCAT Async SDO Download/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1392, 39, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/clear errors/BKIN EtherCAT Async SDO Download/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 1393, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/SR_clean/Switch"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1394, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/SW_clean/Switch"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1395, 77, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/Subsystem/MATLAB Function/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1396, 77, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/Subsystem/MATLAB Function/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1397, 80, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count/MATLAB Function"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1398, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count/Data Type Conversion"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1399, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count/Data Type Conversion1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1400, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count/Data Type Conversion2"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1401, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count/Memory"),
    TARGET_STRING(""), 0, 2, 32, 0, 1 },

  { 1402, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count/Rate Transition"),
    TARGET_STRING(""), 0, 2, 32, 0, 1 },

  { 1403, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count/BKIN EtherCAT Async SDO Upload/p1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1404, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count/BKIN EtherCAT Async SDO Upload/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1405, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count/BKIN EtherCAT Async SDO Upload/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1406, 81, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Value/MATLAB Function"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1407, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Value/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1408, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Value/Memory"),
    TARGET_STRING(""), 0, 5, 32, 0, 1 },

  { 1409, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Value/Rate Transition"),
    TARGET_STRING(""), 0, 5, 32, 0, 1 },

  { 1410, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Value/BKIN EtherCAT Async SDO Upload/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1411, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Value/BKIN EtherCAT Async SDO Upload/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1412, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Value/BKIN EtherCAT Async SDO Upload/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1413, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/clear errors/Data Type Conversion"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1414, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/clear errors/Data Type Conversion1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1415, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/clear errors/Memory"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1416, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/clear errors/BKIN EtherCAT Async SDO Download/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1417, 84, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/clear errors/BKIN EtherCAT Async SDO Download/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 1418, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/SR_clean/Switch"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1419, 131, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/SW_clean/Switch"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1420, 90, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/Subsystem/MATLAB Function/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1421, 90, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/Subsystem/MATLAB Function/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1422, 93, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count/MATLAB Function"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1423, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count/Data Type Conversion"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1424, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count/Data Type Conversion1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1425, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count/Data Type Conversion2"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1426, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count/Memory"),
    TARGET_STRING(""), 0, 2, 32, 0, 1 },

  { 1427, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count/Rate Transition"),
    TARGET_STRING(""), 0, 2, 32, 0, 1 },

  { 1428, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count/BKIN EtherCAT Async SDO Upload/p1"),
    TARGET_STRING(""), 0, 2, 0, 0, 1 },

  { 1429, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count/BKIN EtherCAT Async SDO Upload/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1430, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count/BKIN EtherCAT Async SDO Upload/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1431, 94, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Value/MATLAB Function"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1432, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Value/Data Type Conversion"),
    TARGET_STRING(""), 0, 1, 32, 0, 1 },

  { 1433, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Value/Memory"),
    TARGET_STRING(""), 0, 5, 32, 0, 1 },

  { 1434, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Value/Rate Transition"),
    TARGET_STRING(""), 0, 5, 32, 0, 1 },

  { 1435, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Value/BKIN EtherCAT Async SDO Upload/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1436, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Value/BKIN EtherCAT Async SDO Upload/p2"),
    TARGET_STRING(""), 1, 5, 0, 0, 1 },

  { 1437, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Value/BKIN EtherCAT Async SDO Upload/p3"),
    TARGET_STRING(""), 2, 2, 0, 0, 1 },

  { 1438, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/clear errors/Data Type Conversion"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1439, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/clear errors/Data Type Conversion1"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1440, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/clear errors/Memory"),
    TARGET_STRING(""), 0, 1, 0, 0, 1 },

  { 1441, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/clear errors/BKIN EtherCAT Async SDO Download/p1"),
    TARGET_STRING(""), 0, 5, 0, 0, 1 },

  { 1442, 97, TARGET_STRING(
    "DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/clear errors/BKIN EtherCAT Async SDO Download/p2"),
    TARGET_STRING(""), 1, 2, 0, 0, 1 },

  { 1443, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Counter Free-Running/Increment Real World/FixPt Sum1"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  { 1444, 169, TARGET_STRING(
    "DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Counter Free-Running/Wrap To Zero/FixPt Switch"),
    TARGET_STRING(""), 0, 7, 0, 0, 1 },

  {
    0, 0, (NULL), (NULL), 0, 0, 0, 0, 0
  }
};

static const rtwCAPI_BlockParameters rtBlockParameters[] = {
  /* addrMapIndex, blockPath,
   * paramName, dataTypeIndex, dimIndex, fixPtIdx
   */
  { 1445, TARGET_STRING("GUI Control"),
    TARGET_STRING("tp_table_rows"), 1, 0, 0 },

  { 1446, TARGET_STRING("KINARM_EP_Apply_Loads"),
    TARGET_STRING("up_duration"), 1, 0, 0 },

  { 1447, TARGET_STRING("KINARM_EP_Apply_Loads"),
    TARGET_STRING("down_duration"), 1, 0, 0 },

  { 1448, TARGET_STRING("KINARM_EP_Apply_Loads"),
    TARGET_STRING("max_force"), 1, 0, 0 },

  { 1449, TARGET_STRING("KINARM_Exo_Apply_Loads"),
    TARGET_STRING("up_duration"), 1, 0, 0 },

  { 1450, TARGET_STRING("KINARM_Exo_Apply_Loads"),
    TARGET_STRING("down_duration"), 1, 0, 0 },

  { 1451, TARGET_STRING("KINARM_Exo_Apply_Loads"),
    TARGET_STRING("max_torque"), 1, 0, 0 },

  { 1452, TARGET_STRING("KINARM_Exo_Apply_Loads"),
    TARGET_STRING("limit_motors"), 1, 0, 0 },

  { 1453, TARGET_STRING("KINARM_HandInBarrier"),
    TARGET_STRING("use_dominant_hand"), 1, 0, 0 },

  { 1454, TARGET_STRING("KINARM_HandInBarrier"),
    TARGET_STRING("target_type"), 1, 0, 0 },

  { 1455, TARGET_STRING("KINARM_HandInBarrier"),
    TARGET_STRING("num_states"), 1, 0, 0 },

  { 1456, TARGET_STRING("KINARM_HandInBarrier"),
    TARGET_STRING("attribcol1"), 1, 70, 0 },

  { 1457, TARGET_STRING("KINARM_HandInTarget"),
    TARGET_STRING("use_dominant_hand"), 1, 0, 0 },

  { 1458, TARGET_STRING("KINARM_HandInTarget"),
    TARGET_STRING("target_type"), 1, 0, 0 },

  { 1459, TARGET_STRING("KINARM_HandInTarget"),
    TARGET_STRING("num_states"), 1, 0, 0 },

  { 1460, TARGET_STRING("KINARM_HandInTarget"),
    TARGET_STRING("attribcol1"), 1, 0, 0 },

  { 1461, TARGET_STRING("Process_Video_CMD"),
    TARGET_STRING("video_delay"), 1, 0, 0 },

  { 1462, TARGET_STRING("PuckInBarrier"),
    TARGET_STRING("target_type"), 1, 0, 0 },

  { 1463, TARGET_STRING("PuckInBarrier"),
    TARGET_STRING("num_states"), 1, 0, 0 },

  { 1464, TARGET_STRING("PuckInBarrier"),
    TARGET_STRING("attribcol1"), 1, 70, 0 },

  { 1465, TARGET_STRING("PuckInTarget"),
    TARGET_STRING("target_type"), 1, 0, 0 },

  { 1466, TARGET_STRING("PuckInTarget"),
    TARGET_STRING("num_states"), 1, 0, 0 },

  { 1467, TARGET_STRING("PuckInTarget"),
    TARGET_STRING("attribcol1"), 1, 0, 0 },

  { 1468, TARGET_STRING("Show_Barrier"),
    TARGET_STRING("target_type"), 1, 0, 0 },

  { 1469, TARGET_STRING("Show_Barrier"),
    TARGET_STRING("num_states"), 1, 0, 0 },

  { 1470, TARGET_STRING("Show_Barrier"),
    TARGET_STRING("attribcol1"), 1, 71, 0 },

  { 1471, TARGET_STRING("Show_Barrier"),
    TARGET_STRING("attribcol2"), 1, 71, 0 },

  { 1472, TARGET_STRING("Show_Barrier"),
    TARGET_STRING("attribcol3"), 1, 71, 0 },

  { 1473, TARGET_STRING("Show_Barrier"),
    TARGET_STRING("opacity"), 1, 0, 0 },

  { 1474, TARGET_STRING("Show_Barrier"),
    TARGET_STRING("target_display"), 1, 0, 0 },

  { 1475, TARGET_STRING("Show_Cursor"),
    TARGET_STRING("target_type"), 1, 0, 0 },

  { 1476, TARGET_STRING("Show_Cursor"),
    TARGET_STRING("num_states"), 1, 0, 0 },

  { 1477, TARGET_STRING("Show_Cursor"),
    TARGET_STRING("attribcol1"), 1, 72, 0 },

  { 1478, TARGET_STRING("Show_Cursor"),
    TARGET_STRING("attribcol2"), 1, 72, 0 },

  { 1479, TARGET_STRING("Show_Cursor"),
    TARGET_STRING("attribcol3"), 1, 72, 0 },

  { 1480, TARGET_STRING("Show_Cursor"),
    TARGET_STRING("opacity"), 1, 0, 0 },

  { 1481, TARGET_STRING("Show_Cursor"),
    TARGET_STRING("target_display"), 1, 0, 0 },

  { 1482, TARGET_STRING("Show_Goal"),
    TARGET_STRING("target_type"), 1, 0, 0 },

  { 1483, TARGET_STRING("Show_Goal"),
    TARGET_STRING("num_states"), 1, 0, 0 },

  { 1484, TARGET_STRING("Show_Goal"),
    TARGET_STRING("attribcol1"), 1, 72, 0 },

  { 1485, TARGET_STRING("Show_Goal"),
    TARGET_STRING("attribcol2"), 1, 72, 0 },

  { 1486, TARGET_STRING("Show_Goal"),
    TARGET_STRING("attribcol3"), 1, 72, 0 },

  { 1487, TARGET_STRING("Show_Goal"),
    TARGET_STRING("opacity"), 1, 0, 0 },

  { 1488, TARGET_STRING("Show_Goal"),
    TARGET_STRING("target_display"), 1, 0, 0 },

  { 1489, TARGET_STRING("Show_Preshot_Area"),
    TARGET_STRING("target_type"), 1, 0, 0 },

  { 1490, TARGET_STRING("Show_Preshot_Area"),
    TARGET_STRING("num_states"), 1, 0, 0 },

  { 1491, TARGET_STRING("Show_Preshot_Area"),
    TARGET_STRING("attribcol1"), 1, 72, 0 },

  { 1492, TARGET_STRING("Show_Preshot_Area"),
    TARGET_STRING("attribcol2"), 1, 72, 0 },

  { 1493, TARGET_STRING("Show_Preshot_Area"),
    TARGET_STRING("attribcol3"), 1, 72, 0 },

  { 1494, TARGET_STRING("Show_Preshot_Area"),
    TARGET_STRING("opacity"), 1, 0, 0 },

  { 1495, TARGET_STRING("Show_Preshot_Area"),
    TARGET_STRING("target_display"), 1, 0, 0 },

  { 1496, TARGET_STRING("Show_Puck"),
    TARGET_STRING("target_type"), 1, 0, 0 },

  { 1497, TARGET_STRING("Show_Puck"),
    TARGET_STRING("num_states"), 1, 0, 0 },

  { 1498, TARGET_STRING("Show_Puck"),
    TARGET_STRING("attribcol1"), 1, 72, 0 },

  { 1499, TARGET_STRING("Show_Puck"),
    TARGET_STRING("attribcol2"), 1, 72, 0 },

  { 1500, TARGET_STRING("Show_Puck"),
    TARGET_STRING("attribcol3"), 1, 72, 0 },

  { 1501, TARGET_STRING("Show_Puck"),
    TARGET_STRING("opacity"), 1, 0, 0 },

  { 1502, TARGET_STRING("Show_Puck"),
    TARGET_STRING("target_display"), 1, 0, 0 },

  { 1503, TARGET_STRING("Show_Start"),
    TARGET_STRING("target_type"), 1, 0, 0 },

  { 1504, TARGET_STRING("Show_Start"),
    TARGET_STRING("num_states"), 1, 0, 0 },

  { 1505, TARGET_STRING("Show_Start"),
    TARGET_STRING("attribcol1"), 1, 72, 0 },

  { 1506, TARGET_STRING("Show_Start"),
    TARGET_STRING("attribcol2"), 1, 72, 0 },

  { 1507, TARGET_STRING("Show_Start"),
    TARGET_STRING("attribcol3"), 1, 72, 0 },

  { 1508, TARGET_STRING("Show_Start"),
    TARGET_STRING("opacity"), 1, 0, 0 },

  { 1509, TARGET_STRING("Show_Start"),
    TARGET_STRING("target_display"), 1, 0, 0 },

  { 1510, TARGET_STRING("Constant"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1511, TARGET_STRING("Memory1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 1512, TARGET_STRING("Memory2"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1513, TARGET_STRING("Memory4"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 1514, TARGET_STRING("DataLogging/ECAT Dig Diagnostic"),
    TARGET_STRING("InitialValue"), 2, 72, 0 },

  { 1515, TARGET_STRING("DataLogging/ECAT Status"),
    TARGET_STRING("InitialValue"), 1, 73, 0 },

  { 1516, TARGET_STRING("DataLogging/ECAT Status1"),
    TARGET_STRING("InitialValue"), 1, 74, 0 },

  { 1517, TARGET_STRING("DataLogging/ECAT hardware"),
    TARGET_STRING("InitialValue"), 1, 75, 0 },

  { 1518, TARGET_STRING("DataLogging/ZeroDigOut"),
    TARGET_STRING("Value"), 1, 72, 0 },

  { 1519, TARGET_STRING("DataLogging/seconds_remaining"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1520, TARGET_STRING("DataLogging/Memory"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1521, TARGET_STRING("DataLogging/Memory1"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1522, TARGET_STRING("GUI Control/Constant"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1523, TARGET_STRING("GUI Control/Display Size (m)"),
    TARGET_STRING("Value"), 1, 76, 0 },

  { 1524, TARGET_STRING("GUI Control/Display Size (pels)"),
    TARGET_STRING("Value"), 1, 76, 0 },

  { 1525, TARGET_STRING("GUI Control/Docking Points"),
    TARGET_STRING("Value"), 1, 10, 0 },

  { 1526, TARGET_STRING("GUI Control/EL Camera Angle"),
    TARGET_STRING("Value"), 1, 76, 0 },

  { 1527, TARGET_STRING("GUI Control/EL Camera Focal Length"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1528, TARGET_STRING("GUI Control/EL Camera Position"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 1529, TARGET_STRING("GUI Control/EL Tracking Available"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1530, TARGET_STRING("GUI Control/Library Patch Version"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1531, TARGET_STRING("GUI Control/Library Version"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1532, TARGET_STRING("GUI Control/Next TP row"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1533, TARGET_STRING("GUI Control/Pause Type"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1534, TARGET_STRING("GUI Control/Repeat_Trial_Flag"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1535, TARGET_STRING("GUI Control/Run Task Clock Flag"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1536, TARGET_STRING("GUI Control/Seed"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1537, TARGET_STRING("GUI Control/Subject Height"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1538, TARGET_STRING("GUI Control/Subject Weight"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1539, TARGET_STRING("GUI Control/Task Version"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1540, TARGET_STRING("GUI Control/Use Repeat Trial Flag"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1541, TARGET_STRING("GUI Control/Use custom TP sequence"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1542, TARGET_STRING("GUI Control/dlm build time"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1543, TARGET_STRING("GUI Control/frame_of_reference_center"),
    TARGET_STRING("Value"), 1, 76, 0 },

  { 1544, TARGET_STRING("GUI Control/xPC Version"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1545, TARGET_STRING("GUI Control/Memory"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1546, TARGET_STRING("KINARM_Exo_Apply_Loads/Torque Limit2"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1547, TARGET_STRING("KINARM_Exo_Apply_Loads/Switch"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1548, TARGET_STRING("KINARM_HandInBarrier/Selected States"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1549, TARGET_STRING("KINARM_HandInBarrier/attribcol2"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 1550, TARGET_STRING("KINARM_HandInBarrier/attribcol3"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 1551, TARGET_STRING("KINARM_HandInBarrier/attribcol4"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 1552, TARGET_STRING("KINARM_HandInBarrier/attribcol5"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 1553, TARGET_STRING("KINARM_HandInBarrier/Switch"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1554, TARGET_STRING("KINARM_HandInTarget/Selected States"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1555, TARGET_STRING("KINARM_HandInTarget/attribcol2"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1556, TARGET_STRING("KINARM_HandInTarget/attribcol3"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1557, TARGET_STRING("KINARM_HandInTarget/attribcol4"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1558, TARGET_STRING("KINARM_HandInTarget/attribcol5"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1559, TARGET_STRING("KINARM_HandInTarget/Switch"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1560, TARGET_STRING("Parameter Table Defn/binary_file_names"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1561, TARGET_STRING("Parameter Table Defn/binary_files"),
    TARGET_STRING("Value"), 1, 74, 0 },

  { 1562, TARGET_STRING("Process_Video_CMD/GUI_VCODE"),
    TARGET_STRING("Value"), 1, 77, 0 },

  { 1563, TARGET_STRING("Process_Video_CMD/Gain"),
    TARGET_STRING("Gain"), 1, 0, 0 },

  { 1564, TARGET_STRING("Process_Video_CMD/Memory"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1565, TARGET_STRING("Process_Video_CMD/Receive"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1566, TARGET_STRING("Process_Video_CMD/Receive"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1567, TARGET_STRING("Process_Video_CMD/Receive"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1568, TARGET_STRING("Process_Video_CMD/Receive"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1569, TARGET_STRING("Process_Video_CMD/Receive"),
    TARGET_STRING("P5"), 1, 79, 0 },

  { 1570, TARGET_STRING("Process_Video_CMD/Receive"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1571, TARGET_STRING("Process_Video_CMD/Receive"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1572, TARGET_STRING("Process_Video_CMD/Receive"),
    TARGET_STRING("P9"), 1, 0, 0 },

  { 1573, TARGET_STRING("Process_Video_CMD/Send"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1574, TARGET_STRING("Process_Video_CMD/Send"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1575, TARGET_STRING("Process_Video_CMD/Send"),
    TARGET_STRING("P3"), 1, 79, 0 },

  { 1576, TARGET_STRING("Process_Video_CMD/Send"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1577, TARGET_STRING("Process_Video_CMD/Send"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 1578, TARGET_STRING("Process_Video_CMD/Send"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1579, TARGET_STRING("PuckInBarrier/Selected States"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1580, TARGET_STRING("PuckInBarrier/attribcol2"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 1581, TARGET_STRING("PuckInBarrier/attribcol3"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 1582, TARGET_STRING("PuckInBarrier/attribcol4"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 1583, TARGET_STRING("PuckInBarrier/attribcol5"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 1584, TARGET_STRING("PuckInTarget/Selected States"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1585, TARGET_STRING("PuckInTarget/attribcol2"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1586, TARGET_STRING("PuckInTarget/attribcol3"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1587, TARGET_STRING("PuckInTarget/attribcol4"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1588, TARGET_STRING("PuckInTarget/attribcol5"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1589, TARGET_STRING("Show_Barrier/padder"),
    TARGET_STRING("Value"), 1, 80, 0 },

  { 1590, TARGET_STRING("Show_Barrier/state4_indices"),
    TARGET_STRING("Value"), 1, 71, 0 },

  { 1591, TARGET_STRING("Show_Barrier/state5_indices"),
    TARGET_STRING("Value"), 1, 71, 0 },

  { 1592, TARGET_STRING("Show_Barrier/xpos_index"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1593, TARGET_STRING("Show_Barrier/ypos_index"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1594, TARGET_STRING("Show_Cursor/padder"),
    TARGET_STRING("Value"), 1, 81, 0 },

  { 1595, TARGET_STRING("Show_Cursor/state4_indices"),
    TARGET_STRING("Value"), 1, 72, 0 },

  { 1596, TARGET_STRING("Show_Cursor/state5_indices"),
    TARGET_STRING("Value"), 1, 72, 0 },

  { 1597, TARGET_STRING("Show_Cursor/xpos_index"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1598, TARGET_STRING("Show_Cursor/ypos_index"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1599, TARGET_STRING("Show_Goal/padder"),
    TARGET_STRING("Value"), 1, 81, 0 },

  { 1600, TARGET_STRING("Show_Goal/state4_indices"),
    TARGET_STRING("Value"), 1, 72, 0 },

  { 1601, TARGET_STRING("Show_Goal/state5_indices"),
    TARGET_STRING("Value"), 1, 72, 0 },

  { 1602, TARGET_STRING("Show_Goal/xpos_index"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1603, TARGET_STRING("Show_Goal/ypos_index"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1604, TARGET_STRING("Show_Preshot_Area/padder"),
    TARGET_STRING("Value"), 1, 81, 0 },

  { 1605, TARGET_STRING("Show_Preshot_Area/state4_indices"),
    TARGET_STRING("Value"), 1, 72, 0 },

  { 1606, TARGET_STRING("Show_Preshot_Area/state5_indices"),
    TARGET_STRING("Value"), 1, 72, 0 },

  { 1607, TARGET_STRING("Show_Preshot_Area/xpos_index"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1608, TARGET_STRING("Show_Preshot_Area/ypos_index"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1609, TARGET_STRING("Show_Puck/padder"),
    TARGET_STRING("Value"), 1, 81, 0 },

  { 1610, TARGET_STRING("Show_Puck/state4_indices"),
    TARGET_STRING("Value"), 1, 72, 0 },

  { 1611, TARGET_STRING("Show_Puck/state5_indices"),
    TARGET_STRING("Value"), 1, 72, 0 },

  { 1612, TARGET_STRING("Show_Puck/xpos_index"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1613, TARGET_STRING("Show_Puck/ypos_index"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1614, TARGET_STRING("Show_Start/padder"),
    TARGET_STRING("Value"), 1, 81, 0 },

  { 1615, TARGET_STRING("Show_Start/state4_indices"),
    TARGET_STRING("Value"), 1, 72, 0 },

  { 1616, TARGET_STRING("Show_Start/state5_indices"),
    TARGET_STRING("Value"), 1, 72, 0 },

  { 1617, TARGET_STRING("Show_Start/xpos_index"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1618, TARGET_STRING("Show_Start/ypos_index"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1619, TARGET_STRING("Subsystem/Perturbation"),
    TARGET_STRING("loadcol"), 1, 70, 0 },

  { 1620, TARGET_STRING("Subsystem/Memory3"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1621, TARGET_STRING("Subsystem/Switch"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1622, TARGET_STRING("subsystem for moving the square (updating velocity and checking collision)/Constant2"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1623, TARGET_STRING("subsystem for moving the square (updating velocity and checking collision)/Pulse Generator"),
    TARGET_STRING("Amplitude"), 1, 0, 0 },

  { 1624, TARGET_STRING("subsystem for moving the square (updating velocity and checking collision)/Pulse Generator"),
    TARGET_STRING("Period"), 1, 0, 0 },

  { 1625, TARGET_STRING("subsystem for moving the square (updating velocity and checking collision)/Pulse Generator"),
    TARGET_STRING("PulseWidth"), 1, 0, 0 },

  { 1626, TARGET_STRING("subsystem for moving the square (updating velocity and checking collision)/Pulse Generator"),
    TARGET_STRING("PhaseDelay"), 1, 0, 0 },

  { 1627, TARGET_STRING("DataLogging/Create Analog Inputs Subsystem/Not Logging Analog Inputs"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1628, TARGET_STRING("DataLogging/Create Custom Data Subsystem/custom_version"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1629, TARGET_STRING("DataLogging/Create Custom Data Subsystem/Rate Transition2"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1630, TARGET_STRING("DataLogging/Create Event Codes Subsystem/Not Logging Event Codes"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1631, TARGET_STRING("DataLogging/Create Task State Subsystem/If Running"),
    TARGET_STRING("const"), 2, 0, 0 },

  { 1632, TARGET_STRING("DataLogging/Create Task State Subsystem/packet_version"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1633, TARGET_STRING("DataLogging/Keep alive/const"),
    TARGET_STRING("Value"), 1, 82, 0 },

  { 1634, TARGET_STRING("DataLogging/Keep alive/Send"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1635, TARGET_STRING("DataLogging/Keep alive/Send"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1636, TARGET_STRING("DataLogging/Keep alive/Send"),
    TARGET_STRING("P3"), 1, 79, 0 },

  { 1637, TARGET_STRING("DataLogging/Keep alive/Send"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1638, TARGET_STRING("DataLogging/Keep alive/Send"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 1639, TARGET_STRING("DataLogging/Keep alive/Send"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1640, TARGET_STRING("DataLogging/Network Transfer Subsystem/max_packet_id"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 1641, TARGET_STRING("DataLogging/Network Transfer Subsystem/runID"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1642, TARGET_STRING("DataLogging/Network Transfer Subsystem/Task Clock"),
    TARGET_STRING("Amplitude"), 1, 0, 0 },

  { 1643, TARGET_STRING("DataLogging/Network Transfer Subsystem/Task Clock"),
    TARGET_STRING("Period"), 1, 0, 0 },

  { 1644, TARGET_STRING("DataLogging/Network Transfer Subsystem/Task Clock"),
    TARGET_STRING("PulseWidth"), 1, 0, 0 },

  { 1645, TARGET_STRING("DataLogging/Network Transfer Subsystem/Task Clock"),
    TARGET_STRING("PhaseDelay"), 1, 0, 0 },

  { 1646, TARGET_STRING("DataLogging/Network Transfer Subsystem/Rate Transition1"),
    TARGET_STRING("InitialCondition"), 4, 0, 0 },

  { 1647, TARGET_STRING("DataLogging/Poll Force Plates/ain_offset1"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1648, TARGET_STRING("DataLogging/Poll Force Plates/ain_offset2"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1649, TARGET_STRING("DataLogging/Poll Force Plates/ain_slope1"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1650, TARGET_STRING("DataLogging/Poll Force Plates/ain_slope2"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1651, TARGET_STRING("DataLogging/Poll Force Plates/calibration_matrix1"),
    TARGET_STRING("Value"), 1, 83, 0 },

  { 1652, TARGET_STRING("DataLogging/Poll Force Plates/calibration_matrix2"),
    TARGET_STRING("Value"), 1, 83, 0 },

  { 1653, TARGET_STRING("DataLogging/Poll Force Plates/enable_plate1"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1654, TARGET_STRING("DataLogging/Poll Force Plates/enable_plate2"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1655, TARGET_STRING("DataLogging/Poll Force Plates/gain"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1656, TARGET_STRING("DataLogging/Poll Force Plates/orientation1"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1657, TARGET_STRING("DataLogging/Poll Force Plates/orientation2"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1658, TARGET_STRING("DataLogging/Poll Force Plates/request_packet"),
    TARGET_STRING("Value"), 5, 84, 0 },

  { 1659, TARGET_STRING("DataLogging/Poll Force Plates/zero_voltage"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1660, TARGET_STRING("DataLogging/Poll KINARM/ECAT Digital in"),
    TARGET_STRING("InitialValue"), 2, 73, 0 },

  { 1661, TARGET_STRING("DataLogging/Poll KINARM/ECAT Err Msgs"),
    TARGET_STRING("InitialValue"), 1, 54, 0 },

  { 1662, TARGET_STRING("DataLogging/Poll KINARM/ECATTorque feedback"),
    TARGET_STRING("InitialValue"), 1, 74, 0 },

  { 1663, TARGET_STRING("DataLogging/Poll KINARM/HW Settings"),
    TARGET_STRING("InitialValue"), 1, 21, 0 },

  { 1664, TARGET_STRING("DataLogging/Poll KINARM/Kinematics"),
    TARGET_STRING("InitialValue"), 1, 23, 0 },

  { 1665, TARGET_STRING("DataLogging/Poll KINARM/PrimaryEnc"),
    TARGET_STRING("InitialValue"), 1, 48, 0 },

  { 1666, TARGET_STRING("DataLogging/Poll KINARM/Robot Calib"),
    TARGET_STRING("InitialValue"), 1, 6, 0 },

  { 1667, TARGET_STRING("DataLogging/Poll KINARM/RobotRevision"),
    TARGET_STRING("InitialValue"), 1, 76, 0 },

  { 1668, TARGET_STRING("DataLogging/Poll KINARM/ServoUpdate"),
    TARGET_STRING("InitialValue"), 2, 0, 0 },

  { 1669, TARGET_STRING("DataLogging/Poll KINARM/System status"),
    TARGET_STRING("InitialValue"), 2, 85, 0 },

  { 1670, TARGET_STRING("DataLogging/Poll KINARM/calib button"),
    TARGET_STRING("InitialValue"), 2, 0, 0 },

  { 1671, TARGET_STRING("DataLogging/Poll KINARM/delays"),
    TARGET_STRING("InitialValue"), 1, 3, 0 },

  { 1672, TARGET_STRING("DataLogging/Poll KINARM/has FT sensors"),
    TARGET_STRING("InitialValue"), 1, 70, 0 },

  { 1673, TARGET_STRING("DataLogging/Poll KINARM/isecat"),
    TARGET_STRING("const"), 1, 0, 0 },

  { 1674, TARGET_STRING("DataLogging/Poll KINARM/system type"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1675, TARGET_STRING("DataLogging/Receive_Gaze/EL Camera Angle"),
    TARGET_STRING("Value"), 1, 76, 0 },

  { 1676, TARGET_STRING("DataLogging/Receive_Gaze/EL Camera Focal Length"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1677, TARGET_STRING("DataLogging/Receive_Gaze/EL Camera Position"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 1678, TARGET_STRING("DataLogging/Receive_Gaze/EL Tracking Available"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1679, TARGET_STRING("DataLogging/Receive_Gaze/Gain"),
    TARGET_STRING("Gain"), 1, 0, 0 },

  { 1680, TARGET_STRING("DataLogging/Receive_Gaze/Rate Transition"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1681, TARGET_STRING("DataLogging/Receive_Gaze/Receive"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1682, TARGET_STRING("DataLogging/Receive_Gaze/Receive"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1683, TARGET_STRING("DataLogging/Receive_Gaze/Receive"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1684, TARGET_STRING("DataLogging/Receive_Gaze/Receive"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1685, TARGET_STRING("DataLogging/Receive_Gaze/Receive"),
    TARGET_STRING("P5"), 1, 85, 0 },

  { 1686, TARGET_STRING("DataLogging/Receive_Gaze/Receive"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1687, TARGET_STRING("DataLogging/Receive_Gaze/Receive"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1688, TARGET_STRING("DataLogging/Receive_Gaze/Receive"),
    TARGET_STRING("P9"), 1, 0, 0 },

  { 1689, TARGET_STRING("DataLogging/apply loads/isecat"),
    TARGET_STRING("const"), 1, 0, 0 },

  { 1690, TARGET_STRING("DataLogging/apply loads/isecat1"),
    TARGET_STRING("const"), 1, 0, 0 },

  { 1691, TARGET_STRING("DataLogging/compare encoders/Delay"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1692, TARGET_STRING("DataLogging/create_lab_info/arm_count"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1693, TARGET_STRING("DataLogging/create_lab_info/fp1_present"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1694, TARGET_STRING("DataLogging/create_lab_info/fp2_present"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1695, TARGET_STRING("DataLogging/create_lab_info/gaze_tracker_present"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1696, TARGET_STRING("DataLogging/create_lab_info/robot_lift_present"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1697, TARGET_STRING("DataLogging/monitor torques/Compare To Constant"),
    TARGET_STRING("const"), 1, 0, 0 },

  { 1698, TARGET_STRING("DataLogging/monitor torques/abs_diff"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1699, TARGET_STRING("DataLogging/monitor torques/butterworth_2nd_order_10hz"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 1700, TARGET_STRING("DataLogging/monitor torques/rel_diff"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1701, TARGET_STRING("DataLogging/monitor torques/Task Clock"),
    TARGET_STRING("Amplitude"), 1, 0, 0 },

  { 1702, TARGET_STRING("DataLogging/monitor torques/Task Clock"),
    TARGET_STRING("Period"), 1, 0, 0 },

  { 1703, TARGET_STRING("DataLogging/monitor torques/Task Clock"),
    TARGET_STRING("PulseWidth"), 1, 0, 0 },

  { 1704, TARGET_STRING("DataLogging/monitor torques/Task Clock"),
    TARGET_STRING("PhaseDelay"), 1, 0, 0 },

  { 1705, TARGET_STRING("DataLogging/monitor torques/Memory1"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1706, TARGET_STRING("DataLogging/monitor torques/Memory2"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1707, TARGET_STRING("DataLogging/monitor torques/Delay"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1708, TARGET_STRING("GUI Control/Preview Targets Subsystem/preview_detail"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 1709, TARGET_STRING("GUI Control/Run Command Subsystem/Run Command Receive"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1710, TARGET_STRING("GUI Control/Run Command Subsystem/Run Command Receive"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1711, TARGET_STRING("GUI Control/Run Command Subsystem/Run Command Receive"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1712, TARGET_STRING("GUI Control/Run Command Subsystem/Run Command Receive"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1713, TARGET_STRING("GUI Control/Run Command Subsystem/Run Command Receive"),
    TARGET_STRING("P5"), 1, 85, 0 },

  { 1714, TARGET_STRING("GUI Control/Run Command Subsystem/Run Command Receive"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1715, TARGET_STRING("GUI Control/Run Command Subsystem/Run Command Receive"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1716, TARGET_STRING("GUI Control/Run Command Subsystem/Run Command Receive"),
    TARGET_STRING("P9"), 1, 0, 0 },

  { 1717, TARGET_STRING("GUI Control/Task Execution Control Subsystem/Compare To Constant"),
    TARGET_STRING("const"), 2, 0, 0 },

  { 1718, TARGET_STRING("GUI Control/Task Execution Control Subsystem/Constant"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1719, TARGET_STRING("GUI Control/Task Execution Control Subsystem/Task Clock"),
    TARGET_STRING("Amplitude"), 1, 0, 0 },

  { 1720, TARGET_STRING("GUI Control/Task Execution Control Subsystem/Task Clock"),
    TARGET_STRING("Period"), 1, 0, 0 },

  { 1721, TARGET_STRING("GUI Control/Task Execution Control Subsystem/Task Clock"),
    TARGET_STRING("PulseWidth"), 1, 0, 0 },

  { 1722, TARGET_STRING("GUI Control/Task Execution Control Subsystem/Task Clock"),
    TARGET_STRING("PhaseDelay"), 1, 0, 0 },

  { 1723, TARGET_STRING("GUI Control/Task Execution Control Subsystem/Delay"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 1724, TARGET_STRING("GUI Control/Task Execution Control Subsystem/Delay1"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1725, TARGET_STRING("GUI Control/exit_trial_goto/Detect Change"),
    TARGET_STRING("vinit"), 0, 0, 0 },

  { 1726, TARGET_STRING("GUI Control/exit_trial_goto/Detect Change1"),
    TARGET_STRING("vinit"), 0, 0, 0 },

  { 1727, TARGET_STRING("GUI Control/tables/Compare To Constant"),
    TARGET_STRING("const"), 2, 0, 0 },

  { 1728, TARGET_STRING("KINARM_Exo_Apply_Loads/clip motor torques/Torque Limit5"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1729, TARGET_STRING("KINARM_Exo_Apply_Loads/clip motor torques/Switch1"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1730, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1731, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch1"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1732, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch2"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1733, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch3"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1734, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch4"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1735, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch5"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1736, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch6"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1737, TARGET_STRING("KINARM_HandInBarrier/kin data split/Switch7"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1738, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1739, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch1"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1740, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch2"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1741, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch3"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1742, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch4"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1743, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch5"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1744, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch6"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1745, TARGET_STRING("KINARM_HandInTarget/kin data split/Switch7"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1746, TARGET_STRING("Parameter Table Defn/TP_table/BARRIER_ROW;Barrier;target;Barrier;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1747, TARGET_STRING("Parameter Table Defn/TP_table/CURSOR_ROW;Hand Target Row;target;hand ;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1748, TARGET_STRING("Parameter Table Defn/TP_table/GOAL_ROW;Goal Row;target;Goal;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1749, TARGET_STRING("Parameter Table Defn/TP_table/GOAL_TIME;Goal time (s);float;Time that puck has to stay in goal to trigger success;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1750, TARGET_STRING("Parameter Table Defn/TP_table/LOAD_ROW;Load Row;load;Load;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1751, TARGET_STRING("Parameter Table Defn/TP_table/PRESHOT_ROW;Preshot Area;target;Preshot Area ;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1752, TARGET_STRING("Parameter Table Defn/TP_table/PUCK_DAMPING;Puck damping;float;Damping constant on puck (between 0 and 1);;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1753, TARGET_STRING("Parameter Table Defn/TP_table/PUCK_ROW;Puck Target Row;target;Puck;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1754, TARGET_STRING("Parameter Table Defn/TP_table/SECONDS;Trial duration (s);float;How long is the trial in seconds.;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1755, TARGET_STRING("Parameter Table Defn/TP_table/SHOT_READY_TIME;Shot ready time (s);float;Time to hold in start target during preshot routine to trigger the set state;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1756, TARGET_STRING("Parameter Table Defn/TP_table/SHOT_SET_TIME;Shot set time (s);float;Time to hold in start target after preshot routine to trigger go cue;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1757, TARGET_STRING("Parameter Table Defn/TP_table/SHOT_TIME;Shot time (s);float;Time to make a shot into the goal;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1758, TARGET_STRING("Parameter Table Defn/TP_table/START_HOLD_TIME;Start hold time (s);float;Time to hold in start target before triggering preshot routine;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1759, TARGET_STRING("Parameter Table Defn/TP_table/START_ROW;Start Position;target;Starting Spot for Pt ;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1760, TARGET_STRING("Parameter Table Defn/events/E_BEGIN_PRESHOT;begin preshot routine;;;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1761, TARGET_STRING("Parameter Table Defn/events/E_ENTER_START;enter start target;;;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1762, TARGET_STRING("Parameter Table Defn/events/E_FAILURE;failure;;;;;red;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1763, TARGET_STRING("Parameter Table Defn/events/E_HAND_IN_BARRIER;hand in barrier;;;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1764, TARGET_STRING("Parameter Table Defn/events/E_NO_EVENT;n|a;;This event_code does not save an event in the data file, it just clears the event;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1765, TARGET_STRING("Parameter Table Defn/events/E_PUCK_IN_BARRIER;puck in barrier;;;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1766, TARGET_STRING("Parameter Table Defn/events/E_PUCK_IN_GOAL;puck in goal;;;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1767, TARGET_STRING("Parameter Table Defn/events/E_PUCK_MISS;puck miss;;;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1768, TARGET_STRING("Parameter Table Defn/events/E_SHOT_GO;shot go;;;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1769, TARGET_STRING("Parameter Table Defn/events/E_SHOT_READY;shot ready;;;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1770, TARGET_STRING("Parameter Table Defn/events/E_START_TARGET_ON;start target on;;;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1771, TARGET_STRING("Parameter Table Defn/events/E_SUCCESS;success;;;;;green;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1772, TARGET_STRING("Parameter Table Defn/events/E_TIMEOUT;timeout;;;;;red;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1773, TARGET_STRING("Parameter Table Defn/events/E_TRIAL_START;trial start;;;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1774, TARGET_STRING("Parameter Table Defn/load_table/F_BUMP;F_BUMP;float;Completely arbitrary parameter based on what feels good...;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1775, TARGET_STRING("Parameter Table Defn/load_table/MASS_CIRCLE;Circle target mass;float;;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1776, TARGET_STRING("Parameter Table Defn/load_table/MASS_RECT;Rectangle target mass;float;;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1777, TARGET_STRING("Parameter Table Defn/load_table/PERT_DUR;Perturbation Duration;float;(ms) Time that the perturbation is high for;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1778, TARGET_STRING("Parameter Table Defn/load_table/PERT_RAMP;Perturbation Ramp Time;float;(ms) Time for the perturbation to ramp up and down;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1779, TARGET_STRING("Parameter Table Defn/target_table/FIRST_FILL;First fill color;colour;First fill color for a selected target (color);;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1780, TARGET_STRING("Parameter Table Defn/target_table/HEIGHT;Height;float;Rectangle height (cm);;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1781, TARGET_STRING("Parameter Table Defn/target_table/RADIUS_LOG;logical radius;float;computational radius (cm);;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1782, TARGET_STRING("Parameter Table Defn/target_table/RADIUS_VIS;radius vis;float;radius in cm (legacy?);;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1783, TARGET_STRING("Parameter Table Defn/target_table/ROTATION;Rotation;float;Rectangle roation (degrees);;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1784, TARGET_STRING("Parameter Table Defn/target_table/SECOND_FILL;Second fill color;colour;Second fill color for a selected target (color);;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1785, TARGET_STRING("Parameter Table Defn/target_table/STROKE_COLOR;Stroke colour;colour;Stroke color (color);;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1786, TARGET_STRING("Parameter Table Defn/target_table/STROKE_WIDTH;Width of the stroke;float;Stroke weight (cm);;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1787, TARGET_STRING("Parameter Table Defn/target_table/THIRD_FILL;third fill color;colour;Third fill color for a selected target (color);;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1788, TARGET_STRING("Parameter Table Defn/target_table/WIDTH;Width or Radius;float;Rectangle width or Circle Radius (cm);;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1789, TARGET_STRING("Parameter Table Defn/target_table/col_x;X;float;X Position (cm) of the target relative to  local (0,0);;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1790, TARGET_STRING("Parameter Table Defn/target_table/col_y;Y;float;Y Position (cm) of the target relative to  local (0,0);;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1791, TARGET_STRING("Parameter Table Defn/task_definition/INSTRUCTIONS="),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1792, TARGET_STRING("Parameter Table Defn/task_definition/LOAD_FOR=EITHER"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1793, TARGET_STRING("Parameter Table Defn/task_wide/FORCE_MULTIPLIER;Force multiplier;float;;;;none;;"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1794, TARGET_STRING("Process_Video_CMD/Add_requested_Delay/1000 hz"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1795, TARGET_STRING("Process_Video_CMD/PVC_core/Rate Transition1"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1796, TARGET_STRING("Subsystem/Compare To Zero1/Constant"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1797, TARGET_STRING("subsystem for moving the square (updating velocity and checking collision)/Hand Feedback/Hand_Feedback"),
    TARGET_STRING("feedback_cntl_src"), 1, 0, 0 },

  { 1798, TARGET_STRING("DataLogging/Create Task State Subsystem/Counter Free-Running/Wrap To Zero"),
    TARGET_STRING("Threshold"), 2, 0, 0 },

  { 1799, TARGET_STRING("DataLogging/Create Task State Subsystem/Counter Free-Running/Output"),
    TARGET_STRING("InitialCondition"), 2, 0, 0 },

  { 1800, TARGET_STRING("DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Constant"),
    TARGET_STRING("Value"), 4, 86, 0 },

  { 1801, TARGET_STRING("DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Constant1"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1802, TARGET_STRING("DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Max Frames Per Packet"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1803, TARGET_STRING("DataLogging/Network Transfer Subsystem/Data Packing Subsystem/t-1"),
    TARGET_STRING("InitialCondition"), 4, 0, 0 },

  { 1804, TARGET_STRING("DataLogging/Network Transfer Subsystem/Data Packing Subsystem/t-2"),
    TARGET_STRING("InitialCondition"), 4, 0, 0 },

  { 1805, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Receiver/Memory1"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1806, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Receiver/Memory2"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1807, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Receiver/Receive"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1808, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Receiver/Receive"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1809, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Receiver/Receive"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1810, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Receiver/Receive"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1811, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Receiver/Receive"),
    TARGET_STRING("P5"), 1, 79, 0 },

  { 1812, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Receiver/Receive"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1813, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Receiver/Receive"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1814, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Receiver/Receive"),
    TARGET_STRING("P9"), 1, 0, 0 },

  { 1815, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Send Subsystem/total_packets_sent"),
    TARGET_STRING("InitialOutput"), 2, 0, 0 },

  { 1816, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Send"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1817, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Send"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1818, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Send"),
    TARGET_STRING("P3"), 1, 79, 0 },

  { 1819, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Send"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1820, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Send"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 1821, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Send"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1822, TARGET_STRING("DataLogging/Network Transfer Subsystem/force strobe/Rate Transition1"),
    TARGET_STRING("InitialCondition"), 0, 0, 0 },

  { 1823, TARGET_STRING("DataLogging/Network Transfer Subsystem/force strobe/Rate Transition2"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1824, TARGET_STRING("DataLogging/Poll Force Plates/plate1/Receive"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1825, TARGET_STRING("DataLogging/Poll Force Plates/plate1/Receive"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1826, TARGET_STRING("DataLogging/Poll Force Plates/plate1/Receive"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1827, TARGET_STRING("DataLogging/Poll Force Plates/plate1/Receive"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1828, TARGET_STRING("DataLogging/Poll Force Plates/plate1/Receive"),
    TARGET_STRING("P5"), 1, 87, 0 },

  { 1829, TARGET_STRING("DataLogging/Poll Force Plates/plate1/Receive"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1830, TARGET_STRING("DataLogging/Poll Force Plates/plate1/Receive"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1831, TARGET_STRING("DataLogging/Poll Force Plates/plate1/Receive"),
    TARGET_STRING("P9"), 1, 0, 0 },

  { 1832, TARGET_STRING("DataLogging/Poll Force Plates/plate2/Receive1"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1833, TARGET_STRING("DataLogging/Poll Force Plates/plate2/Receive1"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1834, TARGET_STRING("DataLogging/Poll Force Plates/plate2/Receive1"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1835, TARGET_STRING("DataLogging/Poll Force Plates/plate2/Receive1"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1836, TARGET_STRING("DataLogging/Poll Force Plates/plate2/Receive1"),
    TARGET_STRING("P5"), 1, 87, 0 },

  { 1837, TARGET_STRING("DataLogging/Poll Force Plates/plate2/Receive1"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1838, TARGET_STRING("DataLogging/Poll Force Plates/plate2/Receive1"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1839, TARGET_STRING("DataLogging/Poll Force Plates/plate2/Receive1"),
    TARGET_STRING("P9"), 1, 0, 0 },

  { 1840, TARGET_STRING("DataLogging/Poll Force Plates/send poll 1/Send"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1841, TARGET_STRING("DataLogging/Poll Force Plates/send poll 1/Send"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1842, TARGET_STRING("DataLogging/Poll Force Plates/send poll 1/Send"),
    TARGET_STRING("P3"), 1, 87, 0 },

  { 1843, TARGET_STRING("DataLogging/Poll Force Plates/send poll 1/Send"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1844, TARGET_STRING("DataLogging/Poll Force Plates/send poll 1/Send"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 1845, TARGET_STRING("DataLogging/Poll Force Plates/send poll 1/Send"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1846, TARGET_STRING("DataLogging/Poll Force Plates/send poll 2/Send1"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1847, TARGET_STRING("DataLogging/Poll Force Plates/send poll 2/Send1"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1848, TARGET_STRING("DataLogging/Poll Force Plates/send poll 2/Send1"),
    TARGET_STRING("P3"), 1, 87, 0 },

  { 1849, TARGET_STRING("DataLogging/Poll Force Plates/send poll 2/Send1"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1850, TARGET_STRING("DataLogging/Poll Force Plates/send poll 2/Send1"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 1851, TARGET_STRING("DataLogging/Poll Force Plates/send poll 2/Send1"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1852, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Compare"),
    TARGET_STRING("const"), 2, 0, 0 },

  { 1853, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Bias"),
    TARGET_STRING("Bias"), 5, 0, 0 },

  { 1854, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/PCI Bus Slot"),
    TARGET_STRING("Value"), 5, 76, 0 },

  { 1855, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/activation"),
    TARGET_STRING("Value"), 5, 76, 0 },

  { 1856, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/ep part nums"),
    TARGET_STRING("Value"), 1, 71, 0 },

  { 1857, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/exo part nums"),
    TARGET_STRING("Value"), 1, 71, 0 },

  { 1858, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/force primary only"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1859, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/max errors to fault"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1860, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/nhp part nums"),
    TARGET_STRING("Value"), 1, 71, 0 },

  { 1861, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Switch"),
    TARGET_STRING("Threshold"), 5, 0, 0 },

  { 1862, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Switch1"),
    TARGET_STRING("Threshold"), 5, 0, 0 },

  { 1863, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/ispmac"),
    TARGET_STRING("const"), 1, 0, 0 },

  { 1864, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/is_running"),
    TARGET_STRING("const"), 2, 0, 0 },

  { 1865, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/ispmac1"),
    TARGET_STRING("const"), 1, 0, 0 },

  { 1866, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/ispmac1"),
    TARGET_STRING("const"), 1, 0, 0 },

  { 1867, TARGET_STRING("DataLogging/Poll KINARM/constants/update constants"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1868, TARGET_STRING("DataLogging/Poll KINARM/createKINData/Dominant Arm"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1869, TARGET_STRING("DataLogging/Poll KINARM/createKINData/is_calibrated"),
    TARGET_STRING("Value"), 1, 76, 0 },

  { 1870, TARGET_STRING("DataLogging/Poll KINARM/make KINData bus/Subject_Arm"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1871, TARGET_STRING("DataLogging/monitor torques/delay/butterworth_2nd_order_250hz"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 1872, TARGET_STRING("DataLogging/monitor torques/delay/Delay"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1873, TARGET_STRING("DataLogging/monitor torques/monitor_enc_delta/encoder_err_threshold"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1874, TARGET_STRING("DataLogging/monitor torques/monitor_enc_delta/Memory1"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1875, TARGET_STRING("GUI Control/tables/Counter Free-Running/Wrap To Zero"),
    TARGET_STRING("Threshold"), 2, 0, 0 },

  { 1876, TARGET_STRING("GUI Control/tables/Counter Free-Running/Output"),
    TARGET_STRING("InitialCondition"), 2, 0, 0 },

  { 1877, TARGET_STRING("GUI Control/tables/enable_tables/block_defs"),
    TARGET_STRING("InitialOutput"), 1, 56, 0 },

  { 1878, TARGET_STRING("GUI Control/tables/enable_tables/block_seq"),
    TARGET_STRING("InitialOutput"), 1, 57, 0 },

  { 1879, TARGET_STRING("GUI Control/tables/enable_tables/tp_table"),
    TARGET_STRING("InitialOutput"), 1, 58, 0 },

  { 1880, TARGET_STRING("GUI Control/tables/enable_tables/labels"),
    TARGET_STRING("InitialOutput"), 1, 59, 0 },

  { 1881, TARGET_STRING("GUI Control/tables/enable_tables/targets"),
    TARGET_STRING("InitialOutput"), 1, 60, 0 },

  { 1882, TARGET_STRING("GUI Control/tables/enable_tables/loads"),
    TARGET_STRING("InitialOutput"), 1, 41, 0 },

  { 1883, TARGET_STRING("GUI Control/tables/enable_tables/twp"),
    TARGET_STRING("InitialOutput"), 1, 61, 0 },

  { 1884, TARGET_STRING("GUI Control/tables/enable_tables/Block Definitions"),
    TARGET_STRING("Value"), 1, 56, 0 },

  { 1885, TARGET_STRING("GUI Control/tables/enable_tables/Block Sequence"),
    TARGET_STRING("Value"), 1, 57, 0 },

  { 1886, TARGET_STRING("GUI Control/tables/enable_tables/Load Table"),
    TARGET_STRING("Value"), 1, 41, 0 },

  { 1887, TARGET_STRING("GUI Control/tables/enable_tables/TP Table"),
    TARGET_STRING("Value"), 1, 58, 0 },

  { 1888, TARGET_STRING("GUI Control/tables/enable_tables/Target Labels"),
    TARGET_STRING("Value"), 1, 59, 0 },

  { 1889, TARGET_STRING("GUI Control/tables/enable_tables/Target Table"),
    TARGET_STRING("Value"), 1, 60, 0 },

  { 1890, TARGET_STRING("GUI Control/tables/enable_tables/Task wide param"),
    TARGET_STRING("Value"), 1, 61, 0 },

  { 1891, TARGET_STRING("subsystem for moving the square (updating velocity and checking collision)/Hand Feedback/Hand_Feedback/feedback_status"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1892, TARGET_STRING("DataLogging/Create Task State Subsystem/Counter Free-Running/Increment Real World/FixPt Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 1893, TARGET_STRING("DataLogging/Create Task State Subsystem/Counter Free-Running/Wrap To Zero/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 1894, TARGET_STRING("DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Counter/Constant"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1895, TARGET_STRING("DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Counter/Unit Delay"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1896, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Counter Free-Running/Wrap To Zero"),
    TARGET_STRING("Threshold"), 2, 0, 0 },

  { 1897, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Counter Free-Running/Output"),
    TARGET_STRING("InitialCondition"), 2, 0, 0 },

  { 1898, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/enableCalibration"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1899, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/enableMotors"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1900, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/readTrigger"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 1901, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Memory2"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1902, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Memory3"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1903, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/enableCalibration"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1904, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/enableMotors"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1905, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/readTrigger"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 1906, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Memory2"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1907, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Memory3"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 1908, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Counter Free-Running/Wrap To Zero"),
    TARGET_STRING("Threshold"), 2, 0, 0 },

  { 1909, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Counter Free-Running/Output"),
    TARGET_STRING("InitialCondition"), 2, 0, 0 },

  { 1910, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P1"), 1, 88, 0 },

  { 1911, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1912, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1913, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1914, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 1915, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1916, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1917, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P1"), 1, 88, 0 },

  { 1918, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1919, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1920, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1921, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 1922, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1923, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1924, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P1"), 1, 88, 0 },

  { 1925, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1926, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1927, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1928, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 1929, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1930, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1931, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 3"),
    TARGET_STRING("P1"), 1, 88, 0 },

  { 1932, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 3"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1933, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 3"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1934, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 3"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1935, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 3"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 1936, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 3"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1937, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/BKIN EtherCAT PDO Transmit 3"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1938, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/update/Constant1"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 1939, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Detect Change"),
    TARGET_STRING("vinit"), 1, 0, 0 },

  { 1940, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Constant"),
    TARGET_STRING("Value"), 1, 85, 0 },

  { 1941, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Receive from Robot 1 Force Sensor"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1942, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Receive from Robot 1 Force Sensor"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1943, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Receive from Robot 1 Force Sensor"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1944, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Receive from Robot 1 Force Sensor"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1945, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Receive from Robot 1 Force Sensor"),
    TARGET_STRING("P5"), 1, 89, 0 },

  { 1946, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Receive from Robot 1 Force Sensor"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1947, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Receive from Robot 1 Force Sensor"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1948, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Receive from Robot 1 Force Sensor"),
    TARGET_STRING("P9"), 1, 0, 0 },

  { 1949, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Switch"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1950, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Detect Change"),
    TARGET_STRING("vinit"), 1, 0, 0 },

  { 1951, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Constant1"),
    TARGET_STRING("Value"), 1, 85, 0 },

  { 1952, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Receive from Robot 2 Force Sensor"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1953, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Receive from Robot 2 Force Sensor"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1954, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Receive from Robot 2 Force Sensor"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1955, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Receive from Robot 2 Force Sensor"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1956, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Receive from Robot 2 Force Sensor"),
    TARGET_STRING("P5"), 1, 89, 0 },

  { 1957, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Receive from Robot 2 Force Sensor"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1958, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Receive from Robot 2 Force Sensor"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1959, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Receive from Robot 2 Force Sensor"),
    TARGET_STRING("P9"), 1, 0, 0 },

  { 1960, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Switch1"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 1961, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/robot_count"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1962, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/update settings/Constant"),
    TARGET_STRING("Value"), 1, 74, 0 },

  { 1963, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Counter Free-Running/Wrap To Zero"),
    TARGET_STRING("Threshold"), 2, 0, 0 },

  { 1964, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Counter Free-Running/Output"),
    TARGET_STRING("InitialCondition"), 2, 0, 0 },

  { 1965, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data receive/EP calibration btn"),
    TARGET_STRING("InitialOutput"), 2, 0, 0 },

  { 1966, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data receive/Status bits"),
    TARGET_STRING("InitialOutput"), 2, 55, 0 },

  { 1967, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data receive/Task control button"),
    TARGET_STRING("InitialOutput"), 1, 0, 0 },

  { 1968, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data receive/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 1969, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data receive/Constant1"),
    TARGET_STRING("Value"), 2, 55, 0 },

  { 1970, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data receive/S-Function"),
    TARGET_STRING("P1"), 1, 75, 0 },

  { 1971, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data receive/S-Function"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1972, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data receive/S-Function"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1973, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data receive/S-Function"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1974, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data receive/S-Function"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 1975, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data receive/S-Function"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1976, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data receive/S-Function"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1977, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data write/Constant"),
    TARGET_STRING("Value"), 1, 3, 0 },

  { 1978, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data write/Constant1"),
    TARGET_STRING("Value"), 1, 74, 0 },

  { 1979, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Data write/Constant2"),
    TARGET_STRING("Value"), 1, 74, 0 },

  { 1980, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/servo counter"),
    TARGET_STRING("InitialOutput"), 2, 0, 0 },

  { 1981, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/EP calibration btn"),
    TARGET_STRING("InitialOutput"), 2, 0, 0 },

  { 1982, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Status bits"),
    TARGET_STRING("InitialOutput"), 2, 55, 0 },

  { 1983, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 1984, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Constant1"),
    TARGET_STRING("Value"), 2, 55, 0 },

  { 1985, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Receive"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 1986, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Receive"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 1987, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Receive"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 1988, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Receive"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 1989, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Receive"),
    TARGET_STRING("P5"), 1, 79, 0 },

  { 1990, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Receive"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 1991, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Receive"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 1992, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Receive"),
    TARGET_STRING("P9"), 1, 0, 0 },

  { 1993, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data write/Constant"),
    TARGET_STRING("Value"), 1, 3, 0 },

  { 1994, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data write/Constant1"),
    TARGET_STRING("Value"), 1, 74, 0 },

  { 1995, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Elbow Angle Offset"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1996, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Encoder Orientation 1"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1997, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Encoder Orientation 2"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1998, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Force Sensor Angle Offset"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 1999, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm L1"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2000, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm L2"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2001, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm L2 L5 Angle"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2002, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm L3 Error"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2003, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm L5"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2004, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Motor1 Gear Ratio"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2005, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Motor1 Orientation"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2006, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Motor2 Gear Ratio"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2007, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Motor2 Orientation"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2008, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Orientation"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2009, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Pointer Offset"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2010, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Secondary Encoders"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2011, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Shoulder Angle Offset"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2012, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Shoulder X"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2013, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Shoulder Y"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2014, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm Torque Constant"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2015, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm primary encoder counts"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2016, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm robot type"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2017, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm robot version"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2018, TARGET_STRING("DataLogging/Poll KINARM/constants/arm1/Arm secondary encoder counts"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2019, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Elbow Angle Offset"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2020, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Encoder Orientation 1"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2021, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Encoder Orientation 2"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2022, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Force Sensor Angle Offset"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2023, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm L1"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2024, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm L2"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2025, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm L2 L5 Angle"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2026, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm L3 Error"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2027, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm L5"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2028, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Motor1 Gear Ratio"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2029, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Motor1 Orientation"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2030, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Motor2 Gear Ratio"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2031, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Motor2 Orientation"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2032, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Orientation"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2033, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Pointer Offset"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2034, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Secondary Encoders"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2035, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Shoulder Angle Offset"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2036, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Shoulder X"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2037, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Shoulder Y"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2038, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm Torque Constant"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2039, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm primary encoder counts"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2040, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm robot type"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2041, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm robot version"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2042, TARGET_STRING("DataLogging/Poll KINARM/constants/arm2/Arm secondary encoder counts"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2043, TARGET_STRING("DataLogging/Poll KINARM/constants/update constants subsystem/Arm Force Sensors"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 2044, TARGET_STRING("DataLogging/Poll KINARM/constants/update constants subsystem/Ready"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2045, TARGET_STRING("DataLogging/Poll KINARM/createKINData/Counter Free-Running/Wrap To Zero"),
    TARGET_STRING("Threshold"), 2, 0, 0 },

  { 2046, TARGET_STRING("DataLogging/Poll KINARM/createKINData/Counter Free-Running/Output"),
    TARGET_STRING("InitialCondition"), 2, 0, 0 },

  { 2047, TARGET_STRING("DataLogging/Poll KINARM/createKINData/hand feedback/Gaze Feedback Status"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2048, TARGET_STRING("DataLogging/Poll KINARM/createKINData/hand feedback/Hand Feedback Colour"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2049, TARGET_STRING("DataLogging/Poll KINARM/createKINData/hand feedback/Hand Feedback Feed Forward"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2050, TARGET_STRING("DataLogging/Poll KINARM/createKINData/hand feedback/Hand Feedback Radius"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2051, TARGET_STRING("DataLogging/Poll KINARM/createKINData/hand feedback/Hand Feedback Source"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2052, TARGET_STRING("DataLogging/Poll KINARM/createKINData/hand feedback/Hand Feedback Status"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2053, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P1"), 1, 90, 0 },

  { 2054, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2055, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2056, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2057, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2058, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2059, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2060, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P1"), 1, 90, 0 },

  { 2061, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2062, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2063, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2064, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2065, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2066, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2067, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P1"), 1, 90, 0 },

  { 2068, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2069, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2070, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2071, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2072, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2073, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2074, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P1"), 1, 90, 0 },

  { 2075, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2076, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2077, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2078, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2079, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2080, TARGET_STRING("DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques/BKIN EtherCAT PDO Transmit 2"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2081, TARGET_STRING("GUI Control/tables/Counter Free-Running/Increment Real World/FixPt Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2082, TARGET_STRING("GUI Control/tables/Counter Free-Running/Wrap To Zero/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2083, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Counter Free-Running/Increment Real World/FixPt Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2084, TARGET_STRING("DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Counter Free-Running/Wrap To Zero/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2085, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/Compare"),
    TARGET_STRING("const"), 5, 0, 0 },

  { 2086, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/MotorIdx"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2087, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/Memory"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2088, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P1"), 1, 91, 0 },

  { 2089, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2090, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2091, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2092, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2093, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2094, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2095, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/Compare"),
    TARGET_STRING("const"), 5, 0, 0 },

  { 2096, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/MotorIdx"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2097, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/Memory"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2098, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P1"), 1, 91, 0 },

  { 2099, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2100, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2101, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2102, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2103, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2104, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2105, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/override_grip"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2106, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P1"), 1, 92, 0 },

  { 2107, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2108, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2109, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2110, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2111, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2112, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2113, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P1"), 1, 92, 0 },

  { 2114, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2115, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2116, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2117, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2118, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2119, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2120, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2121, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/Memory1"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2122, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2123, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/Memory1"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2124, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/readAddr"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 2125, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2126, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/writeData"),
    TARGET_STRING("Value"), 1, 82, 0 },

  { 2127, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2128, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2129, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Memory1"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2130, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Memory2"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2131, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/Compare"),
    TARGET_STRING("const"), 5, 0, 0 },

  { 2132, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/MotorIdx"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2133, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/Memory"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2134, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P1"), 1, 91, 0 },

  { 2135, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2136, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2137, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2138, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2139, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2140, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2141, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/Compare"),
    TARGET_STRING("const"), 5, 0, 0 },

  { 2142, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/MotorIdx"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2143, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/Memory"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2144, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P1"), 1, 91, 0 },

  { 2145, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2146, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2147, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2148, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2149, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2150, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2151, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2152, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/Memory1"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2153, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2154, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/Memory1"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2155, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/readAddr"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 2156, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2157, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/writeData"),
    TARGET_STRING("Value"), 1, 82, 0 },

  { 2158, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2159, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/override_grip"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2160, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P1"), 1, 92, 0 },

  { 2161, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2162, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2163, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2164, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2165, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2166, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit "),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2167, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P1"), 1, 92, 0 },

  { 2168, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2169, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2170, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2171, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2172, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2173, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/BKIN EtherCAT PDO Transmit 1"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2174, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2175, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Memory1"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2176, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Memory2"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2177, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Counter Free-Running/Increment Real World/FixPt Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2178, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Counter Free-Running/Wrap To Zero/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2179, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/update/create filtered velocities/2nd order butterworth, 4Khz, 10hz cutoff"),
    TARGET_STRING("Value"), 1, 70, 0 },

  { 2180, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Constant"),
    TARGET_STRING("Value"), 7, 0, 0 },

  { 2181, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Constant1"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2182, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Constant2"),
    TARGET_STRING("Value"), 7, 0, 0 },

  { 2183, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Constant3"),
    TARGET_STRING("Value"), 7, 0, 0 },

  { 2184, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Send"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 2185, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Send"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2186, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Send"),
    TARGET_STRING("P3"), 1, 89, 0 },

  { 2187, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Send"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2188, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Send"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2189, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Send"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2190, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem/Switch"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 2191, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Constant"),
    TARGET_STRING("Value"), 7, 0, 0 },

  { 2192, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Constant1"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2193, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Constant2"),
    TARGET_STRING("Value"), 7, 0, 0 },

  { 2194, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Constant3"),
    TARGET_STRING("Value"), 7, 0, 0 },

  { 2195, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Send"),
    TARGET_STRING("P1"), 1, 78, 0 },

  { 2196, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Send"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2197, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Send"),
    TARGET_STRING("P3"), 1, 89, 0 },

  { 2198, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Send"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2199, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Send"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2200, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Send"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2201, TARGET_STRING("DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem/Switch"),
    TARGET_STRING("Threshold"), 1, 0, 0 },

  { 2202, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/DPRAM Read Offset"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2203, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/DPRAM WatchDog offset"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2204, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/DPRAM Write Offset"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2205, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/DPRAM Write Value"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2206, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Read Switch"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2207, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Read as UInt32"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2208, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Write Switch"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2209, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/DPRAM Read Value"),
    TARGET_STRING("Gain"), 1, 0, 0 },

  { 2210, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Unit Delay"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2211, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Unit Delay1"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2212, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Unit Delay2"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2213, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Unit Delay3"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2214, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Counter Free-Running/Increment Real World/FixPt Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2215, TARGET_STRING("DataLogging/Poll KINARM/bkin_file_source/Counter Free-Running/Wrap To Zero/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2216, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Counter Free-Running/Wrap To Zero"),
    TARGET_STRING("Threshold"), 2, 0, 0 },

  { 2217, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Counter Free-Running/Output"),
    TARGET_STRING("InitialCondition"), 2, 0, 0 },

  { 2218, TARGET_STRING("DataLogging/Poll KINARM/createKINData/Counter Free-Running/Increment Real World/FixPt Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2219, TARGET_STRING("DataLogging/Poll KINARM/createKINData/Counter Free-Running/Wrap To Zero/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2220, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P1"), 1, 93, 0 },

  { 2221, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2222, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2223, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2224, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2225, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2226, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2227, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/driveID"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2228, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P1"), 1, 93, 0 },

  { 2229, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2230, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2231, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2232, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2233, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2234, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2235, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/driveID"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2236, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P1"), 1, 93, 0 },

  { 2237, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2238, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2239, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2240, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2241, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2242, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2243, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/driveID"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2244, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P1"), 1, 93, 0 },

  { 2245, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P2"), 1, 0, 0 },

  { 2246, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P3"), 1, 0, 0 },

  { 2247, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P4"), 1, 0, 0 },

  { 2248, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P5"), 1, 0, 0 },

  { 2249, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P6"), 1, 0, 0 },

  { 2250, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/BKIN PDO Receive ElmoDrive"),
    TARGET_STRING("P7"), 1, 0, 0 },

  { 2251, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/driveID"),
    TARGET_STRING("Value"), 1, 0, 0 },

  { 2252, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Counter Free-Running/Wrap To Zero"),
    TARGET_STRING("Threshold"), 7, 0, 0 },

  { 2253, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Counter Free-Running/Output"),
    TARGET_STRING("InitialCondition"), 7, 0, 0 },

  { 2254, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Counter Free-Running/Increment Real World/FixPt Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2255, TARGET_STRING("DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Counter Free-Running/Wrap To Zero/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2256, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/SR_clean/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2257, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/SR_clean/Switch"),
    TARGET_STRING("Threshold"), 5, 0, 0 },

  { 2258, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/SW_clean/Constant"),
    TARGET_STRING("Value"), 7, 0, 0 },

  { 2259, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/SW_clean/Switch"),
    TARGET_STRING("Threshold"), 5, 0, 0 },

  { 2260, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/Constant"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2261, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/Constant1"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2262, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/Memory"),
    TARGET_STRING("InitialCondition"), 2, 0, 0 },

  { 2263, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Value/Constant"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2264, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Value/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2265, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/clear errors/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2266, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/clear errors/Constant1"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2267, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/clear errors/Memory"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2268, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/SR_clean/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2269, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/SR_clean/Switch"),
    TARGET_STRING("Threshold"), 5, 0, 0 },

  { 2270, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/SW_clean/Constant"),
    TARGET_STRING("Value"), 7, 0, 0 },

  { 2271, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/SW_clean/Switch"),
    TARGET_STRING("Threshold"), 5, 0, 0 },

  { 2272, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count/Constant"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2273, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count/Constant1"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2274, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count/Memory"),
    TARGET_STRING("InitialCondition"), 2, 0, 0 },

  { 2275, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Value/Constant"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2276, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Value/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2277, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/clear errors/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2278, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/clear errors/Constant1"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2279, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/clear errors/Memory"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2280, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/SR_clean/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2281, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/SR_clean/Switch"),
    TARGET_STRING("Threshold"), 5, 0, 0 },

  { 2282, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/SW_clean/Constant"),
    TARGET_STRING("Value"), 7, 0, 0 },

  { 2283, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/SW_clean/Switch"),
    TARGET_STRING("Threshold"), 5, 0, 0 },

  { 2284, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count/Constant"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2285, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count/Constant1"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2286, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count/Memory"),
    TARGET_STRING("InitialCondition"), 2, 0, 0 },

  { 2287, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Value/Constant"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2288, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Value/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2289, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/clear errors/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2290, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/clear errors/Constant1"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2291, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/clear errors/Memory"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2292, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/SR_clean/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2293, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/SR_clean/Switch"),
    TARGET_STRING("Threshold"), 5, 0, 0 },

  { 2294, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/SW_clean/Constant"),
    TARGET_STRING("Value"), 7, 0, 0 },

  { 2295, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/SW_clean/Switch"),
    TARGET_STRING("Threshold"), 5, 0, 0 },

  { 2296, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count/Constant"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2297, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count/Constant1"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2298, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count/Memory"),
    TARGET_STRING("InitialCondition"), 2, 0, 0 },

  { 2299, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Value/Constant"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2300, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Value/Memory"),
    TARGET_STRING("InitialCondition"), 5, 0, 0 },

  { 2301, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/clear errors/Constant"),
    TARGET_STRING("Value"), 2, 0, 0 },

  { 2302, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/clear errors/Constant1"),
    TARGET_STRING("Value"), 5, 0, 0 },

  { 2303, TARGET_STRING("DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/clear errors/Memory"),
    TARGET_STRING("InitialCondition"), 1, 0, 0 },

  { 2304, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Counter Free-Running/Increment Real World/FixPt Constant"),
    TARGET_STRING("Value"), 7, 0, 0 },

  { 2305, TARGET_STRING("DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Counter Free-Running/Wrap To Zero/Constant"),
    TARGET_STRING("Value"), 7, 0, 0 },

  {
    0, (NULL), (NULL), 0, 0, 0
  }
};

/* Tunable variable parameters */
static const rtwCAPI_ModelParameters rtModelParameters[] = {
  /* addrMapIndex, varName, dataTypeIndex, dimIndex, fixPtIndex */
  { 2306, TARGET_STRING("BKIN_STEP_TIME"), 1, 0, 0 },

  { 2307, TARGET_STRING("BARRIER_ROW"), 1, 0, 0 },

  { 2308, TARGET_STRING("CURSOR_ROW"), 1, 0, 0 },

  { 2309, TARGET_STRING("E_BEGIN_PRESHOT"), 1, 0, 0 },

  { 2310, TARGET_STRING("E_ENTER_START"), 1, 0, 0 },

  { 2311, TARGET_STRING("E_FAILURE"), 1, 0, 0 },

  { 2312, TARGET_STRING("E_HAND_IN_BARRIER"), 1, 0, 0 },

  { 2313, TARGET_STRING("E_NO_EVENT"), 1, 0, 0 },

  { 2314, TARGET_STRING("E_PUCK_IN_BARRIER"), 1, 0, 0 },

  { 2315, TARGET_STRING("E_PUCK_IN_GOAL"), 1, 0, 0 },

  { 2316, TARGET_STRING("E_PUCK_MISS"), 1, 0, 0 },

  { 2317, TARGET_STRING("E_SHOT_GO"), 1, 0, 0 },

  { 2318, TARGET_STRING("E_SHOT_READY"), 1, 0, 0 },

  { 2319, TARGET_STRING("E_START_TARGET_ON"), 1, 0, 0 },

  { 2320, TARGET_STRING("E_SUCCESS"), 1, 0, 0 },

  { 2321, TARGET_STRING("E_TIMEOUT"), 1, 0, 0 },

  { 2322, TARGET_STRING("E_TRIAL_START"), 1, 0, 0 },

  { 2323, TARGET_STRING("FIRST_FILL"), 1, 0, 0 },

  { 2324, TARGET_STRING("FORCE_MULTIPLIER"), 1, 0, 0 },

  { 2325, TARGET_STRING("F_BUMP"), 1, 0, 0 },

  { 2326, TARGET_STRING("GOAL_ROW"), 1, 0, 0 },

  { 2327, TARGET_STRING("GOAL_TIME"), 1, 0, 0 },

  { 2328, TARGET_STRING("HEIGHT"), 1, 0, 0 },

  { 2329, TARGET_STRING("LOAD_ROW"), 1, 0, 0 },

  { 2330, TARGET_STRING("MASS_CIRCLE"), 1, 0, 0 },

  { 2331, TARGET_STRING("MASS_RECT"), 1, 0, 0 },

  { 2332, TARGET_STRING("PERT_DUR"), 1, 0, 0 },

  { 2333, TARGET_STRING("PERT_RAMP"), 1, 0, 0 },

  { 2334, TARGET_STRING("PRESHOT_ROW"), 1, 0, 0 },

  { 2335, TARGET_STRING("PUCK_DAMPING"), 1, 0, 0 },

  { 2336, TARGET_STRING("PUCK_ROW"), 1, 0, 0 },

  { 2337, TARGET_STRING("RADIUS_LOG"), 1, 0, 0 },

  { 2338, TARGET_STRING("RADIUS_VIS"), 1, 0, 0 },

  { 2339, TARGET_STRING("ROTATION"), 1, 0, 0 },

  { 2340, TARGET_STRING("SECONDS"), 1, 0, 0 },

  { 2341, TARGET_STRING("SECOND_FILL"), 1, 0, 0 },

  { 2342, TARGET_STRING("SHOT_READY_TIME"), 1, 0, 0 },

  { 2343, TARGET_STRING("SHOT_SET_TIME"), 1, 0, 0 },

  { 2344, TARGET_STRING("SHOT_TIME"), 1, 0, 0 },

  { 2345, TARGET_STRING("START_HOLD_TIME"), 1, 0, 0 },

  { 2346, TARGET_STRING("START_ROW"), 1, 0, 0 },

  { 2347, TARGET_STRING("STROKE_COLOR"), 1, 0, 0 },

  { 2348, TARGET_STRING("STROKE_WIDTH"), 1, 0, 0 },

  { 2349, TARGET_STRING("THIRD_FILL"), 1, 0, 0 },

  { 2350, TARGET_STRING("WIDTH"), 1, 0, 0 },

  { 2351, TARGET_STRING("col_x"), 1, 0, 0 },

  { 2352, TARGET_STRING("col_y"), 1, 0, 0 },

  { 0, (NULL), 0, 0, 0 }
};

#ifndef HOST_CAPI_BUILD

/* Declare Data Addresses statically */
static void* rtDataAddrMap[] = {
  &may23_B.logging_enable,             /* 0: Signal */
  &may23_B.event_code,                 /* 1: Signal */
  &may23_B.cursor_row,                 /* 2: Signal */
  &may23_B.cursor_state,               /* 3: Signal */
  &may23_B.puck_row,                   /* 4: Signal */
  &may23_B.puck_state,                 /* 5: Signal */
  &may23_B.load_row,                   /* 6: Signal */
  &may23_B.barrier_target_row,         /* 7: Signal */
  &may23_B.barrier_target_state,       /* 8: Signal */
  &may23_B.start_target_row,           /* 9: Signal */
  &may23_B.start_target_state,         /* 10: Signal */
  &may23_B.goal_target_row,            /* 11: Signal */
  &may23_B.goal_target_state,          /* 12: Signal */
  &may23_B.preshot_area_row,           /* 13: Signal */
  &may23_B.preshot_area_state,         /* 14: Signal */
  &may23_B.e_Trial_Start,              /* 15: Signal */
  &may23_B.e_Trial_End,                /* 16: Signal */
  &may23_B.MatrixConcatenate[0],       /* 17: Signal */
  &may23_B.Constant,                   /* 18: Signal */
  &may23_B.DataTypeConversion_j0,      /* 19: Signal */
  &may23_B.DataTypeConversion1_pz,     /* 20: Signal */
  &may23_B.Memory1_k,                  /* 21: Signal */
  &may23_B.Memory2_c[0],               /* 22: Signal */
  &may23_B.Memory4,                    /* 23: Signal */
  &may23_B.readDigitaldiag[0],         /* 24: Signal */
  &may23_B.readstatus[0],              /* 25: Signal */
  &may23_B.Memory_d[0],                /* 26: Signal */
  &may23_B.Memory1_l,                  /* 27: Signal */
  &may23_B.ArmOrientation,             /* 28: Signal */
  &may23_B.M1orientation,              /* 29: Signal */
  &may23_B.M2Orientation,              /* 30: Signal */
  &may23_B.M1GearRatio,                /* 31: Signal */
  &may23_B.M2GearRatio,                /* 32: Signal */
  &may23_B.HasSecondaryEnc_h,          /* 33: Signal */
  &may23_B.robottype_c,                /* 34: Signal */
  &may23_B.robotversion_a,             /* 35: Signal */
  &may23_B.torqueconstant,             /* 36: Signal */
  &may23_B.isEP,                       /* 37: Signal */
  &may23_B.isHumanExo,                 /* 38: Signal */
  &may23_B.isNHPExo,                   /* 39: Signal */
  &may23_B.isClassicExo,               /* 40: Signal */
  &may23_B.isUTSExo,                   /* 41: Signal */
  &may23_B.isPMAC,                     /* 42: Signal */
  &may23_B.isECAT,                     /* 43: Signal */
  &may23_B.robotRevision,              /* 44: Signal */
  &may23_B.ArmOrientation_a,           /* 45: Signal */
  &may23_B.M1orientation_i,            /* 46: Signal */
  &may23_B.M2Orientation_a,            /* 47: Signal */
  &may23_B.M1GearRatio_e,              /* 48: Signal */
  &may23_B.M2GearRatio_n,              /* 49: Signal */
  &may23_B.HasSecondaryEnc,            /* 50: Signal */
  &may23_B.robottype,                  /* 51: Signal */
  &may23_B.robotversion,               /* 52: Signal */
  &may23_B.torqueconstant_b,           /* 53: Signal */
  &may23_B.isEP_f,                     /* 54: Signal */
  &may23_B.isHumanExo_k,               /* 55: Signal */
  &may23_B.isNHPExo_l,                 /* 56: Signal */
  &may23_B.isClassicExo_j,             /* 57: Signal */
  &may23_B.isUTSExo_n,                 /* 58: Signal */
  &may23_B.isPMAC_p,                   /* 59: Signal */
  &may23_B.isECAT_o,                   /* 60: Signal */
  &may23_B.robotRevision_p,            /* 61: Signal */
  &may23_B.Product_g[0],               /* 62: Signal */
  &may23_B.RateTransition_p[0],        /* 63: Signal */
  &may23_B.RateTransition1_a[0],       /* 64: Signal */
  &may23_B.RateTransition2_h[0],       /* 65: Signal */
  &may23_B.AddTorques[0],              /* 66: Signal */
  &may23_B.joint_loads_i[0],           /* 67: Signal */
  &may23_B.LibraryPatchVersion,        /* 68: Signal */
  &may23_B.LibraryVersion,             /* 69: Signal */
  &may23_B.PauseType,                  /* 70: Signal */
  &may23_B.TaskVersion,                /* 71: Signal */
  &may23_B.UsecustomTPsequence,        /* 72: Signal */
  &may23_B.dlmbuildtime,               /* 73: Signal */
  &may23_B.frame_of_reference_center[0],/* 74: Signal */
  &may23_B.xPCVersion,                 /* 75: Signal */
  &may23_B.Convert10[0],               /* 76: Signal */
  &may23_B.Convert11[0],               /* 77: Signal */
  &may23_B.Convert12,                  /* 78: Signal */
  &may23_B.Convert13[0],               /* 79: Signal */
  &may23_B.Convert14[0],               /* 80: Signal */
  &may23_B.Convert15,                  /* 81: Signal */
  &may23_B.Convert16,                  /* 82: Signal */
  &may23_B.Convert17,                  /* 83: Signal */
  &may23_B.Convert18,                  /* 84: Signal */
  &may23_B.Convert19_e,                /* 85: Signal */
  &may23_B.Convert20,                  /* 86: Signal */
  &may23_B.Convert21,                  /* 87: Signal */
  &may23_B.Convert22,                  /* 88: Signal */
  &may23_B.Convert23,                  /* 89: Signal */
  &may23_B.Convert24,                  /* 90: Signal */
  &may23_B.Convert25,                  /* 91: Signal */
  &may23_B.Convert7,                   /* 92: Signal */
  &may23_B.Convert8,                   /* 93: Signal */
  &may23_B.Convert9[0],                /* 94: Signal */
  &may23_B.Memory,                     /* 95: Signal */
  &may23_B.MinMax,                     /* 96: Signal */
  &may23_B.TPSelector[0],              /* 97: Signal */
  &may23_B.out_m[0],                   /* 98: Signal */
  &may23_B.joint_loads[0],             /* 99: Signal */
  &may23_B.sf_Ramp_Up_Down.scaling,    /* 100: Signal */
  &may23_B.sf_Ramp_Up_Down1.scaling,   /* 101: Signal */
  &may23_B.sf_Remove_NaNs_and_Inf.out[0],/* 102: Signal */
  &may23_B.out_p[0],                   /* 103: Signal */
  &may23_B.down_durationms,            /* 104: Signal */
  &may23_B.down_durationms1,           /* 105: Signal */
  &may23_B.up_durationms,              /* 106: Signal */
  &may23_B.up_durationms1,             /* 107: Signal */
  &may23_B.DataTypeConversion_gj,      /* 108: Signal */
  &may23_B.DataTypeConversion1_ft,     /* 109: Signal */
  &may23_B.Product_c[0],               /* 110: Signal */
  &may23_B.Product1_j[0],              /* 111: Signal */
  &may23_B.Reshape_b[0],               /* 112: Signal */
  &may23_B.sf_Ramp_Up_Down_g.scaling,  /* 113: Signal */
  &may23_B.sf_Ramp_Up_Down1_h.scaling, /* 114: Signal */
  &may23_B.sf_Remove_NaNs_and_Inf_d.out[0],/* 115: Signal */
  &may23_B.out[0],                     /* 116: Signal */
  &may23_B.y[0],                       /* 117: Signal */
  &may23_B.down_durationms_b,          /* 118: Signal */
  &may23_B.up_durationms_h,            /* 119: Signal */
  &may23_B.DataTypeConversion_pv,      /* 120: Signal */
  &may23_B.DataTypeConversion1,        /* 121: Signal */
  &may23_B.Product_i[0],               /* 122: Signal */
  &may23_B.Product1[0],                /* 123: Signal */
  &may23_B.Reshape_p[0],               /* 124: Signal */
  &may23_B.Switch_h,                   /* 125: Signal */
  &may23_B.intarget_j[0],              /* 126: Signal */
  &may23_B.ArraySelector_b[0],         /* 127: Signal */
  &may23_B.Switch_i[0],                /* 128: Signal */
  &may23_B.intarget_d[0],              /* 129: Signal */
  &may23_B.ArraySelector[0],           /* 130: Signal */
  &may23_B.Switch[0],                  /* 131: Signal */
  &may23_B.binary_file_names,          /* 132: Signal */
  &may23_B.binary_files[0],            /* 133: Signal */
  &may23_B.last_frame_ack,             /* 134: Signal */
  &may23_B.last_perm_ack,              /* 135: Signal */
  &may23_B.MatrixConcatenate_d[0],     /* 136: Signal */
  ( &may23_B.MatrixConcatenate_d[0] + 490),/* 137: Signal */
  &may23_B.Convert,                    /* 138: Signal */
  &may23_B.Convert1,                   /* 139: Signal */
  &may23_B.Gain,                       /* 140: Signal */
  &may23_B.Memory_m,                   /* 141: Signal */
  &may23_B.MatrixConcatenate_d[0],     /* 142: Signal */
  &may23_B.RateTransition2_p[0],       /* 143: Signal */
  &may23_B.Receive_o1[0],              /* 144: Signal */
  &may23_B.Receive_o2,                 /* 145: Signal */
  &may23_B.Unpack,                     /* 146: Signal */
  &may23_B.intarget_g[0],              /* 147: Signal */
  &may23_B.ArraySelector_c[0],         /* 148: Signal */
  &may23_B.Selector_n[0],              /* 149: Signal */
  &may23_B.indisplay,                  /* 150: Signal */
  &may23_B.Selector_g[0],              /* 151: Signal */
  &may23_B.intarget[0],                /* 152: Signal */
  &may23_B.ArraySelector_m[0],         /* 153: Signal */
  &may23_B.Selector[0],                /* 154: Signal */
  &may23_B.sf_EmbeddedMATLABFunction_p.VCODE[0],/* 155: Signal */
  &may23_B.MatrixConcatenation1_k[0],  /* 156: Signal */
  &may23_B.MatrixConcatenation1_k[0],  /* 157: Signal */
  ( &may23_B.MatrixConcatenation1_k[0] + 30),/* 158: Signal */
  &may23_B.Selector_i[0],              /* 159: Signal */
  &may23_B.sf_EmbeddedMATLABFunction_n.VCODE[0],/* 160: Signal */
  &may23_B.MatrixConcatenation1[0],    /* 161: Signal */
  &may23_B.MatrixConcatenation1[0],    /* 162: Signal */
  ( &may23_B.MatrixConcatenation1[0] + 20),/* 163: Signal */
  &may23_B.Selector_p[0],              /* 164: Signal */
  &may23_B.sf_EmbeddedMATLABFunction_m.VCODE[0],/* 165: Signal */
  &may23_B.MatrixConcatenation1_g[0],  /* 166: Signal */
  &may23_B.MatrixConcatenation1_g[0],  /* 167: Signal */
  ( &may23_B.MatrixConcatenation1_g[0] + 20),/* 168: Signal */
  &may23_B.Selector_c[0],              /* 169: Signal */
  &may23_B.sf_EmbeddedMATLABFunction_e.VCODE[0],/* 170: Signal */
  &may23_B.MatrixConcatenation1_e[0],  /* 171: Signal */
  &may23_B.MatrixConcatenation1_e[0],  /* 172: Signal */
  ( &may23_B.MatrixConcatenation1_e[0] + 20),/* 173: Signal */
  &may23_B.Selector_f[0],              /* 174: Signal */
  &may23_B.sf_EmbeddedMATLABFunction_a.VCODE[0],/* 175: Signal */
  &may23_B.MatrixConcatenation1_a[0],  /* 176: Signal */
  &may23_B.MatrixConcatenation1_a[0],  /* 177: Signal */
  ( &may23_B.MatrixConcatenation1_a[0] + 20),/* 178: Signal */
  &may23_B.Selector_gx[0],             /* 179: Signal */
  &may23_B.sf_EmbeddedMATLABFunction_h.VCODE[0],/* 180: Signal */
  &may23_B.MatrixConcatenation1_b[0],  /* 181: Signal */
  &may23_B.MatrixConcatenation1_b[0],  /* 182: Signal */
  ( &may23_B.MatrixConcatenation1_b[0] + 20),/* 183: Signal */
  &may23_B.Selector_d[0],              /* 184: Signal */
  &may23_B.Abs[0],                     /* 185: Signal */
  &may23_B.Memory3[0],                 /* 186: Signal */
  &may23_B.Product_br[0],              /* 187: Signal */
  &may23_B.SumofElements,              /* 188: Signal */
  &may23_B.Switch_k[0],                /* 189: Signal */
  &may23_B.puck_vcode_output[0],       /* 190: Signal */
  &may23_B.force_scaling[0],           /* 191: Signal */
  &may23_B.e_Puck_Stopped,             /* 192: Signal */
  &may23_B.e_Puck_Hit,                 /* 193: Signal */
  &may23_B.force_vector[0],            /* 194: Signal */
  &may23_B.DataTypeConversion_b,       /* 195: Signal */
  &may23_B.PulseGenerator,             /* 196: Signal */
  &may23_B.gethandmass,                /* 197: Signal */
  &may23_B.getrectanglemass,           /* 198: Signal */
  &may23_B.AnalogDataWidth[0],         /* 199: Signal */
  &may23_B.RateTransition_e[0],        /* 200: Signal */
  &may23_B.Subtract,                   /* 201: Signal */
  (void *) &may23_ConstB.Width,        /* 202: Signal */
  &may23_B.voltagesOK,                 /* 203: Signal */
  &may23_B.DataTypeConversion_g,       /* 204: Signal */
  &may23_B.RateTransition1,            /* 205: Signal */
  &may23_B.RateTransition2,            /* 206: Signal */
  (void *) &may23_ConstB.Width_g,      /* 207: Signal */
  &may23_B.EventCodes,                 /* 208: Signal */
  &may23_B.NumberofEventCodes,         /* 209: Signal */
  &may23_B.Subtract_i,                 /* 210: Signal */
  (void *) &may23_ConstB.Width_o,      /* 211: Signal */
  &may23_B.bitfield,                   /* 212: Signal */
  &may23_B.touint[0],                  /* 213: Signal */
  &may23_B.touint1,                    /* 214: Signal */
  &may23_B.RateTransition_k[0],        /* 215: Signal */
  (void *) &may23_ConstB.Width_m,      /* 216: Signal */
  &may23_B.ButtonStatus,               /* 217: Signal */
  &may23_B.CurrentBlockIndex,          /* 218: Signal */
  &may23_B.CurrentBlockNumberinSet,    /* 219: Signal */
  &may23_B.CurrentTPIndex,             /* 220: Signal */
  &may23_B.CurrentTrialNumberinBlock,  /* 221: Signal */
  &may23_B.CurrentTrialNumberinSet,    /* 222: Signal */
  &may23_B.LastFrameAcknowledged,      /* 223: Signal */
  &may23_B.LastFrameSent,              /* 224: Signal */
  &may23_B.LastFrameSent1,             /* 225: Signal */
  &may23_B.LoggingEnable,              /* 226: Signal */
  &may23_B.RunStatus,                  /* 227: Signal */
  &may23_B.Servoupdatecount,           /* 228: Signal */
  &may23_B.TaskControlButton,          /* 229: Signal */
  &may23_B.Timestamp,                  /* 230: Signal */
  &may23_B.conv,                       /* 231: Signal */
  &may23_B.Product_f,                  /* 232: Signal */
  &may23_B.RateTransition,             /* 233: Signal */
  &may23_B.RateTransition1_h,          /* 234: Signal */
  &may23_B.RateTransition10,           /* 235: Signal */
  &may23_B.RateTransition11,           /* 236: Signal */
  &may23_B.RateTransition12,           /* 237: Signal */
  &may23_B.RateTransition2_k,          /* 238: Signal */
  &may23_B.RateTransition3,            /* 239: Signal */
  &may23_B.RateTransition4,            /* 240: Signal */
  &may23_B.RateTransition5,            /* 241: Signal */
  &may23_B.RateTransition6,            /* 242: Signal */
  &may23_B.RateTransition7,            /* 243: Signal */
  &may23_B.RateTransition8,            /* 244: Signal */
  &may23_B.RateTransition9,            /* 245: Signal */
  (void *) &may23_ConstB.Width_f,      /* 246: Signal */
  &may23_B.Pack_i[0],                  /* 247: Signal */
  (void *) &may23_ConstB.Width_j,      /* 248: Signal */
  &may23_B.resetUDP,                   /* 249: Signal */
  &may23_B.data_out[0],                /* 250: Signal */
  &may23_B.queue_size,                 /* 251: Signal */
  &may23_B.total_timeouts,             /* 252: Signal */
  &may23_B.max_packet_id,              /* 253: Signal */
  &may23_B.DataTypeConversion2_k,      /* 254: Signal */
  &may23_B.queue_size_i,               /* 255: Signal */
  &may23_B.timeouts,                   /* 256: Signal */
  &may23_B.TaskClock_e,                /* 257: Signal */
  &may23_B.RateTransition1_l[0],       /* 258: Signal */
  &may23_B.Convert1_a[0],              /* 259: Signal */
  &may23_B.Convert19_h[0],             /* 260: Signal */
  &may23_B.RateTransition_a,           /* 261: Signal */
  &may23_B.RateTransition1_ot,         /* 262: Signal */
  &may23_B.systemtype,                 /* 263: Signal */
  &may23_B.ReadHasFT[0],               /* 264: Signal */
  &may23_B.timestamp_out,              /* 265: Signal */
  &may23_B.start_time_out,             /* 266: Signal */
  &may23_B.gazeXYCalculated[0],        /* 267: Signal */
  &may23_B.pupil_area_GLOBAL,          /* 268: Signal */
  &may23_B.gaze_unit_vector_GLOBAL[0], /* 269: Signal */
  &may23_B.pupil_GLOBAL[0],            /* 270: Signal */
  &may23_B.pack_out[0],                /* 271: Signal */
  &may23_B.len_out,                    /* 272: Signal */
  &may23_B.event_data_out[0],          /* 273: Signal */
  &may23_B.Convert1_n,                 /* 274: Signal */
  &may23_B.Convert19[0],               /* 275: Signal */
  &may23_B.Convert2[0],                /* 276: Signal */
  &may23_B.Convert3,                   /* 277: Signal */
  &may23_B.Convert4[0],                /* 278: Signal */
  &may23_B.DataTypeConversion_p5,      /* 279: Signal */
  &may23_B.DataTypeConversion1_f[0],   /* 280: Signal */
  &may23_B.DataTypeConversion3[0],     /* 281: Signal */
  &may23_B.DataTypeConversion4,        /* 282: Signal */
  &may23_B.DataTypeConversion5,        /* 283: Signal */
  &may23_B.convert_n,                  /* 284: Signal */
  &may23_B.Gain_o[0],                  /* 285: Signal */
  &may23_B.RateTransition_i[0],        /* 286: Signal */
  &may23_B.RateTransition1_n[0],       /* 287: Signal */
  &may23_B.RateTransition2_l,          /* 288: Signal */
  &may23_B.RateTransition3_c,          /* 289: Signal */
  &may23_B.Reshape_a[0],               /* 290: Signal */
  &may23_B.SelectorLeftEye[0],         /* 291: Signal */
  &may23_B.Receive_o1_o[0],            /* 292: Signal */
  &may23_B.Receive_o2_f,               /* 293: Signal */
  &may23_B.SFunction_o1,               /* 294: Signal */
  &may23_B.SAMPE_TYPE,                 /* 295: Signal */
  &may23_B.ContentFlags,               /* 296: Signal */
  &may23_B.pupil_X[0],                 /* 297: Signal */
  &may23_B.pupilY[0],                  /* 298: Signal */
  &may23_B.HREFX[0],                   /* 299: Signal */
  &may23_B.HREFY[0],                   /* 300: Signal */
  &may23_B.pupilarea[0],               /* 301: Signal */
  &may23_B.gaze_X[0],                  /* 302: Signal */
  &may23_B.gaze_Y[0],                  /* 303: Signal */
  &may23_B.resolutionX,                /* 304: Signal */
  &may23_B.resolutionY,                /* 305: Signal */
  &may23_B.statusflags,                /* 306: Signal */
  &may23_B.extrainput,                 /* 307: Signal */
  &may23_B.buttons,                    /* 308: Signal */
  &may23_B.htype,                      /* 309: Signal */
  &may23_B.hdata[0],                   /* 310: Signal */
  &may23_B.SFunction_o18[0],           /* 311: Signal */
  &may23_B.torques_out[0],             /* 312: Signal */
  &may23_B.deltas[0],                  /* 313: Signal */
  &may23_B.DataStoreRead1_l[0],        /* 314: Signal */
  &may23_B.Product_b[0],               /* 315: Signal */
  &may23_B.Delay,                      /* 316: Signal */
  &may23_B.robot_count,                /* 317: Signal */
  &may23_B.has_force_plate_1,          /* 318: Signal */
  &may23_B.has_force_plate_2,          /* 319: Signal */
  &may23_B.has_gaze_tracker,           /* 320: Signal */
  &may23_B.has_robot_lift,             /* 321: Signal */
  &may23_B.robot_failures[0],          /* 322: Signal */
  &may23_B.torque_err_bitfield,        /* 323: Signal */
  &may23_B.abs_diff[0],                /* 324: Signal */
  &may23_B.rel_diff[0],                /* 325: Signal */
  &may23_B.robot_limits[0],            /* 326: Signal */
  &may23_B.filteredVals[0],            /* 327: Signal */
  &may23_B.command_multiplier,         /* 328: Signal */
  &may23_B.stop_vel_mode,              /* 329: Signal */
  &may23_B.robot_err_bits_out,         /* 330: Signal */
  &may23_B.DataStoreRead[0],           /* 331: Signal */
  &may23_B.DataStoreRead1[0],          /* 332: Signal */
  &may23_B.TaskClock_h,                /* 333: Signal */
  &may23_B.Memory1,                    /* 334: Signal */
  &may23_B.Memory2,                    /* 335: Signal */
  &may23_B.Product_n[0],               /* 336: Signal */
  &may23_B.AddR1,                      /* 337: Signal */
  &may23_B.AddR2,                      /* 338: Signal */
  &may23_B.Delay_l,                    /* 339: Signal */
  &may23_B.preview_detail[0],          /* 340: Signal */
  &may23_B.y_o,                        /* 341: Signal */
  &may23_B.z,                          /* 342: Signal */
  &may23_B.value,                      /* 343: Signal */
  &may23_B.DataTypeConversion,         /* 344: Signal */
  &may23_B.DataTypeConversion1_fy,     /* 345: Signal */
  &may23_B.RunCommandReceive_o1,       /* 346: Signal */
  &may23_B.RunCommandReceive_o2,       /* 347: Signal */
  &may23_B.tp_out,                     /* 348: Signal */
  &may23_B.task_status,                /* 349: Signal */
  &may23_B.tp,                         /* 350: Signal */
  &may23_B.block_idx,                  /* 351: Signal */
  &may23_B.trial_in_block,             /* 352: Signal */
  &may23_B.block_in_set,               /* 353: Signal */
  &may23_B.trial_in_set,               /* 354: Signal */
  &may23_B.repeat_last_trial,          /* 355: Signal */
  &may23_B.extra_trials[0],            /* 356: Signal */
  &may23_B.e_exit_trial,               /* 357: Signal */
  &may23_B.DataTypeConversion_p,       /* 358: Signal */
  &may23_B.DataTypeConversion1_jo,     /* 359: Signal */
  &may23_B.DataTypeConversion2,        /* 360: Signal */
  &may23_B.DataTypeConversion3_m,      /* 361: Signal */
  &may23_B.TaskClock,                  /* 362: Signal */
  &may23_B.Delay_h,                    /* 363: Signal */
  &may23_B.Delay1,                     /* 364: Signal */
  &may23_B.Product,                    /* 365: Signal */
  &may23_B.Product2,                   /* 366: Signal */
  &may23_B.Product3,                   /* 367: Signal */
  &may23_B.Selector1[0],               /* 368: Signal */
  &may23_B.Selector2[0],               /* 369: Signal */
  &may23_B.Subtract_a,                 /* 370: Signal */
  (void *) &may23_ConstB.Width1,       /* 371: Signal */
  &may23_B.Width2,                     /* 372: Signal */
  &may23_B.total_trials,               /* 373: Signal */
  &may23_B.trials_in_block,            /* 374: Signal */
  &may23_B.total_blocks,               /* 375: Signal */
  &may23_B.total_trials_in_exam,       /* 376: Signal */
  &may23_B.total_trials_in_block,      /* 377: Signal */
  &may23_B.total_blocks_in_exam,       /* 378: Signal */
  &may23_B.sf_MATLABFunction_b.motors_enabled,/* 379: Signal */
  &may23_B.sf_MATLABFunction_gh.motors_enabled,/* 380: Signal */
  &may23_B.clipped_torques[0],         /* 381: Signal */
  &may23_B.Switch1,                    /* 382: Signal */
  &may23_B.assessment_hand_pos_f[0],   /* 383: Signal */
  &may23_B.contralateral_hand_pos_o[0],/* 384: Signal */
  &may23_B.assessment_hand_vel[0],     /* 385: Signal */
  &may23_B.contralateral_hand_vel[0],  /* 386: Signal */
  &may23_B.assessment_link_angles[0],  /* 387: Signal */
  &may23_B.contralateral_link_angles[0],/* 388: Signal */
  &may23_B.assessment_link_vel[0],     /* 389: Signal */
  &may23_B.contralateral_link_vel[0],  /* 390: Signal */
  &may23_B.assessment_hand_pos[0],     /* 391: Signal */
  &may23_B.contralateral_hand_pos[0],  /* 392: Signal */
  &may23_B.assessment_hand_vel_n[0],   /* 393: Signal */
  &may23_B.contralateral_hand_vel_d[0],/* 394: Signal */
  &may23_B.assessment_link_angles_m[0],/* 395: Signal */
  &may23_B.contralateral_link_angles_f[0],/* 396: Signal */
  &may23_B.assessment_link_vel_n[0],   /* 397: Signal */
  &may23_B.contralateral_link_vel_a[0],/* 398: Signal */
  &may23_B.BARRIER_ROWBarriertargetBarriernone,/* 399: Signal */
  &may23_B.CURSOR_ROWHandTargetRowtargethandnone,/* 400: Signal */
  &may23_B.GOAL_ROWGoalRowtargetGoalnone,/* 401: Signal */
  &may23_B.GOAL_TIMEGoaltimesfloatTimethatpuckhastostayingoaltotriggersucc,/* 402: Signal */
  &may23_B.LOAD_ROWLoadRowloadLoadnone,/* 403: Signal */
  &may23_B.PRESHOT_ROWPreshotAreatargetPreshotAreanone,/* 404: Signal */
  &may23_B.PUCK_DAMPINGPuckdampingfloatDampingconstantonpuckbetween0and1no,/* 405: Signal */
  &may23_B.PUCK_ROWPuckTargetRowtargetPucknone,/* 406: Signal */
  &may23_B.SECONDSTrialdurationsfloatHowlongisthetrialinsecondsnone,/* 407: Signal */
  &may23_B.SHOT_READY_TIMEShotreadytimesfloatTimetoholdinstarttargetduring,/* 408: Signal */
  &may23_B.SHOT_SET_TIMEShotsettimesfloatTimetoholdinstarttargetafterpresh,/* 409: Signal */
  &may23_B.SHOT_TIMEShottimesfloatTimetomakeashotintothegoalnone,/* 410: Signal */
  &may23_B.START_HOLD_TIMEStartholdtimesfloatTimetoholdinstarttargetbefore,/* 411: Signal */
  &may23_B.START_ROWStartPositiontargetStartingSpotforPtnone,/* 412: Signal */
  &may23_B.E_BEGIN_PRESHOTbeginpreshotroutinenone,/* 413: Signal */
  &may23_B.E_ENTER_STARTenterstarttargetnone,/* 414: Signal */
  &may23_B.E_FAILUREfailurered,        /* 415: Signal */
  &may23_B.E_HAND_IN_BARRIERhandinbarriernone,/* 416: Signal */
  &may23_B.E_NO_EVENTnaThisevent_codedoesnotsaveaneventinthedatafileitjust,/* 417: Signal */
  &may23_B.E_PUCK_IN_BARRIERpuckinbarriernone,/* 418: Signal */
  &may23_B.E_PUCK_IN_GOALpuckingoalnone,/* 419: Signal */
  &may23_B.E_PUCK_MISSpuckmissnone,    /* 420: Signal */
  &may23_B.E_SHOT_GOshotgonone,        /* 421: Signal */
  &may23_B.E_SHOT_READYshotreadynone,  /* 422: Signal */
  &may23_B.E_START_TARGET_ONstarttargetonnone,/* 423: Signal */
  &may23_B.E_SUCCESSsuccessgreen,      /* 424: Signal */
  &may23_B.E_TIMEOUTtimeoutred,        /* 425: Signal */
  &may23_B.E_TRIAL_STARTtrialstartnone,/* 426: Signal */
  &may23_B.F_BUMPF_BUMPfloatCompletelyarbitraryparameterbasedonwhatfeelsgo,/* 427: Signal */
  &may23_B.MASS_CIRCLECircletargetmassfloatnone,/* 428: Signal */
  &may23_B.MASS_RECTRectangletargetmassfloatnone,/* 429: Signal */
  &may23_B.PERT_DURPerturbationDurationfloatmsTimethattheperturbationishig,/* 430: Signal */
  &may23_B.PERT_RAMPPerturbationRampTimefloatmsTimefortheperturbationtoram,/* 431: Signal */
  &may23_B.FIRST_FILLFirstfillcolorcolourFirstfillcolorforaselectedtargetc,/* 432: Signal */
  &may23_B.HEIGHTHeightfloatRectangleheightcmnone,/* 433: Signal */
  &may23_B.RADIUS_LOGlogicalradiusfloatcomputationalradiuscmnone,/* 434: Signal */
  &may23_B.RADIUS_VISradiusvisfloatradiusincmlegacynone,/* 435: Signal */
  &may23_B.ROTATIONRotationfloatRectangleroationdegreesnone,/* 436: Signal */
  &may23_B.SECOND_FILLSecondfillcolorcolourSecondfillcolorforaselectedtarg,/* 437: Signal */
  &may23_B.STROKE_COLORStrokecolourcolourStrokecolorcolornone,/* 438: Signal */
  &may23_B.STROKE_WIDTHWidthofthestrokefloatStrokeweightcmnone,/* 439: Signal */
  &may23_B.THIRD_FILLthirdfillcolorcolourThirdfillcolorforaselectedtargetc,/* 440: Signal */
  &may23_B.WIDTHWidthorRadiusfloatRectanglewidthorCircleRadiuscmnone,/* 441: Signal */
  &may23_B.col_xXfloatXPositioncmofthetargetrelativetolocal00none,/* 442: Signal */
  &may23_B.col_yYfloatYPositioncmofthetargetrelativetolocal00none,/* 443: Signal */
  &may23_B.INSTRUCTIONS,               /* 444: Signal */
  &may23_B.LOAD_FOREITHER,             /* 445: Signal */
  &may23_B.FORCE_MULTIPLIERForcemultiplierfloatnone,/* 446: Signal */
  &may23_B.delay,                      /* 447: Signal */
  &may23_B.RateTransition1_c,          /* 448: Signal */
  &may23_B.SFunctionBuilder_o1[0],     /* 449: Signal */
  &may23_B.SFunctionBuilder_o2,        /* 450: Signal */
  &may23_B.SFunctionBuilder_o3[0],     /* 451: Signal */
  &may23_B.vis_cmd[0],                 /* 452: Signal */
  &may23_B.vis_cmd_len,                /* 453: Signal */
  &may23_B.vis_cmd_cropped,            /* 454: Signal */
  &may23_B.frame_number,               /* 455: Signal */
  &may23_B.vcode_err_id,               /* 456: Signal */
  &may23_B.Convert_j,                  /* 457: Signal */
  &may23_B.RateTransition1_o,          /* 458: Signal */
  &may23_B.Compare_j,                  /* 459: Signal */
  &may23_B.scaling,                    /* 460: Signal */
  &may23_B.perturbation[0],            /* 461: Signal */
  &may23_B.DataTypeConversion_bl[0],   /* 462: Signal */
  &may23_B.DataTypeConversion2_gv,     /* 463: Signal */
  &may23_B.hand_vcodes_e[0],           /* 464: Signal */
  &may23_B.MatrixConcatenate1[0],      /* 465: Signal */
  &may23_B.hand_vcodes[0],             /* 466: Signal */
  &may23_B.dd_out[0],                  /* 467: Signal */
  &may23_B.Output_h,                   /* 468: Signal */
  &may23_B.Compare_o,                  /* 469: Signal */
  &may23_B.DataTypeConversion_i[0],    /* 470: Signal */
  &may23_B.IdealFramesPerPacket,       /* 471: Signal */
  &may23_B.MathFunction,               /* 472: Signal */
  &may23_B.t1[0],                      /* 473: Signal */
  &may23_B.t2[0],                      /* 474: Signal */
  &may23_B.MinMax_b,                   /* 475: Signal */
  &may23_B.Product_i0,                 /* 476: Signal */
  &may23_B.RelationalOperator,         /* 477: Signal */
  &may23_B.Selector_pl[0],             /* 478: Signal */
  &may23_B.Subtract_h,                 /* 479: Signal */
  &may23_B.Width,                      /* 480: Signal */
  &may23_B.DataTypeConversion_pa,      /* 481: Signal */
  &may23_B.Memory1_m,                  /* 482: Signal */
  &may23_B.trigger,                    /* 483: Signal */
  &may23_B.Receive_o1_m[0],            /* 484: Signal */
  &may23_B.Receive_o2_c,               /* 485: Signal */
  &may23_B.Unpack_n,                   /* 486: Signal */
  &may23_B.Pack_c[0],                  /* 487: Signal */
  (void *) &may23_ConstB.Width_g1,     /* 488: Signal */
  &may23_B.strobe_out,                 /* 489: Signal */
  &may23_B.RateTransition1_l1,         /* 490: Signal */
  &may23_B.RateTransition2_a,          /* 491: Signal */
  &may23_B.forces_e[0],                /* 492: Signal */
  &may23_B.moments_i[0],               /* 493: Signal */
  &may23_B.timer_a,                    /* 494: Signal */
  &may23_B.Receive_o1_p[0],            /* 495: Signal */
  &may23_B.Receive_o2_b,               /* 496: Signal */
  &may23_B.forces[0],                  /* 497: Signal */
  &may23_B.moments[0],                 /* 498: Signal */
  &may23_B.timer,                      /* 499: Signal */
  &may23_B.Receive1_o1[0],             /* 500: Signal */
  &may23_B.Receive1_o2,                /* 501: Signal */
  (void *) &may23_ConstB.Width_h,      /* 502: Signal */
  (void *) &may23_ConstB.Width_gf,     /* 503: Signal */
  &may23_B.errVals[0],                 /* 504: Signal */
  &may23_B.DCErrVals[0],               /* 505: Signal */
  &may23_B.intAddresses[0],            /* 506: Signal */
  &may23_B.floatAddresses[0],          /* 507: Signal */
  &may23_B.motorEnableState,           /* 508: Signal */
  &may23_B.Bias,                       /* 509: Signal */
  &may23_B.max_errors_to_fault,        /* 510: Signal */
  &may23_B.DataTypeConversion_pn,      /* 511: Signal */
  &may23_B.convert1_l,                 /* 512: Signal */
  &may23_B.BKINEtherCATinit_o1[0],     /* 513: Signal */
  &may23_B.BKINEtherCATinit_o2,        /* 514: Signal */
  &may23_B.BKINEtherCATinit_o3,        /* 515: Signal */
  &may23_B.BKINEtherCATinit_o4[0],     /* 516: Signal */
  &may23_B.BKINEtherCATinit1_o1[0],    /* 517: Signal */
  &may23_B.BKINEtherCATinit1_o2,       /* 518: Signal */
  &may23_B.BKINEtherCATinit1_o3,       /* 519: Signal */
  &may23_B.BKINEtherCATinit1_o4[0],    /* 520: Signal */
  &may23_B.Switch_f[0],                /* 521: Signal */
  &may23_B.Switch1_b[0],               /* 522: Signal */
  &may23_B.measures_out[0],            /* 523: Signal */
  &may23_B.status_out[0],              /* 524: Signal */
  &may23_B.LogicalOperator,            /* 525: Signal */
  &may23_B.RateTransition_b,           /* 526: Signal */
  &may23_B.trigger_calibration[0],     /* 527: Signal */
  &may23_B.kinarm_data[0],             /* 528: Signal */
  &may23_B.primary_encoder_data_out[0],/* 529: Signal */
  &may23_B.statusInts[0],              /* 530: Signal */
  &may23_B.newMessage[0],              /* 531: Signal */
  &may23_B.sentMessageCount,           /* 532: Signal */
  &may23_B.is_calibrated[0],           /* 533: Signal */
  &may23_B.DataStoreRead_d,            /* 534: Signal */
  &may23_B.Dataready[0],               /* 535: Signal */
  &may23_B.DelayRead[0],               /* 536: Signal */
  &may23_B.ErrMsgs[0],                 /* 537: Signal */
  &may23_B.Primaryread[0],             /* 538: Signal */
  &may23_B.Read[0],                    /* 539: Signal */
  &may23_B.ReadHW[0],                  /* 540: Signal */
  &may23_B.ReadKinematics[0],          /* 541: Signal */
  &may23_B.ServoRead,                  /* 542: Signal */
  &may23_B.Statusread[0],              /* 543: Signal */
  &may23_B.torquefeedback1[0],         /* 544: Signal */
  &may23_B.DataTypeConversion_f[0],    /* 545: Signal */
  &may23_B.DataTypeConversion1_d,      /* 546: Signal */
  &may23_B.Compare_ny,                 /* 547: Signal */
  &may23_B.sf_splitKINDataarm1.link_lengths[0],/* 548: Signal */
  &may23_B.sf_splitKINDataarm1.pointer_offset,/* 549: Signal */
  &may23_B.sf_splitKINDataarm1.shoulder_loc[0],/* 550: Signal */
  &may23_B.sf_splitKINDataarm1.arm_orientation,/* 551: Signal */
  &may23_B.sf_splitKINDataarm1.shoulder_ang,/* 552: Signal */
  &may23_B.sf_splitKINDataarm1.elbow_ang,/* 553: Signal */
  &may23_B.sf_splitKINDataarm1.shoulder_ang_velocity,/* 554: Signal */
  &may23_B.sf_splitKINDataarm1.elbow_ang_velocity,/* 555: Signal */
  &may23_B.sf_splitKINDataarm1.shoulder_ang_acceleration,/* 556: Signal */
  &may23_B.sf_splitKINDataarm1.elbow_ang_acceleration,/* 557: Signal */
  &may23_B.sf_splitKINDataarm1.joint_torque_cmd[0],/* 558: Signal */
  &may23_B.sf_splitKINDataarm1.motor_torque_cmd[0],/* 559: Signal */
  &may23_B.sf_splitKINDataarm1.link_angle[0],/* 560: Signal */
  &may23_B.sf_splitKINDataarm1.link_velocity[0],/* 561: Signal */
  &may23_B.sf_splitKINDataarm1.link_acceleration[0],/* 562: Signal */
  &may23_B.sf_splitKINDataarm1.hand_position[0],/* 563: Signal */
  &may23_B.sf_splitKINDataarm1.hand_velocity[0],/* 564: Signal */
  &may23_B.sf_splitKINDataarm1.hand_acceleration[0],/* 565: Signal */
  &may23_B.sf_splitKINDataarm1.elbow_position[0],/* 566: Signal */
  &may23_B.sf_splitKINDataarm1.elbow_velocity[0],/* 567: Signal */
  &may23_B.sf_splitKINDataarm1.elbow_acceleration[0],/* 568: Signal */
  &may23_B.sf_splitKINDataarm1.motor_status,/* 569: Signal */
  &may23_B.sf_splitKINDataarm1.force_sensor_force_uvw[0],/* 570: Signal */
  &may23_B.sf_splitKINDataarm1.force_sensor_torque_uvw[0],/* 571: Signal */
  &may23_B.sf_splitKINDataarm1.force_sensor_force_xyz[0],/* 572: Signal */
  &may23_B.sf_splitKINDataarm1.force_sensor_torque_xyz[0],/* 573: Signal */
  &may23_B.sf_splitKINDataarm1.force_sensor_timestamp,/* 574: Signal */
  &may23_B.sf_splitKINDataarm2.link_lengths[0],/* 575: Signal */
  &may23_B.sf_splitKINDataarm2.pointer_offset,/* 576: Signal */
  &may23_B.sf_splitKINDataarm2.shoulder_loc[0],/* 577: Signal */
  &may23_B.sf_splitKINDataarm2.arm_orientation,/* 578: Signal */
  &may23_B.sf_splitKINDataarm2.shoulder_ang,/* 579: Signal */
  &may23_B.sf_splitKINDataarm2.elbow_ang,/* 580: Signal */
  &may23_B.sf_splitKINDataarm2.shoulder_ang_velocity,/* 581: Signal */
  &may23_B.sf_splitKINDataarm2.elbow_ang_velocity,/* 582: Signal */
  &may23_B.sf_splitKINDataarm2.shoulder_ang_acceleration,/* 583: Signal */
  &may23_B.sf_splitKINDataarm2.elbow_ang_acceleration,/* 584: Signal */
  &may23_B.sf_splitKINDataarm2.joint_torque_cmd[0],/* 585: Signal */
  &may23_B.sf_splitKINDataarm2.motor_torque_cmd[0],/* 586: Signal */
  &may23_B.sf_splitKINDataarm2.link_angle[0],/* 587: Signal */
  &may23_B.sf_splitKINDataarm2.link_velocity[0],/* 588: Signal */
  &may23_B.sf_splitKINDataarm2.link_acceleration[0],/* 589: Signal */
  &may23_B.sf_splitKINDataarm2.hand_position[0],/* 590: Signal */
  &may23_B.sf_splitKINDataarm2.hand_velocity[0],/* 591: Signal */
  &may23_B.sf_splitKINDataarm2.hand_acceleration[0],/* 592: Signal */
  &may23_B.sf_splitKINDataarm2.elbow_position[0],/* 593: Signal */
  &may23_B.sf_splitKINDataarm2.elbow_velocity[0],/* 594: Signal */
  &may23_B.sf_splitKINDataarm2.elbow_acceleration[0],/* 595: Signal */
  &may23_B.sf_splitKINDataarm2.motor_status,/* 596: Signal */
  &may23_B.sf_splitKINDataarm2.force_sensor_force_uvw[0],/* 597: Signal */
  &may23_B.sf_splitKINDataarm2.force_sensor_torque_uvw[0],/* 598: Signal */
  &may23_B.sf_splitKINDataarm2.force_sensor_force_xyz[0],/* 599: Signal */
  &may23_B.sf_splitKINDataarm2.force_sensor_torque_xyz[0],/* 600: Signal */
  &may23_B.sf_splitKINDataarm2.force_sensor_timestamp,/* 601: Signal */
  &may23_B.active_arm,                 /* 602: Signal */
  &may23_B.servoCounter,               /* 603: Signal */
  &may23_B.calibrationButtonBits,      /* 604: Signal */
  &may23_B.handFF_Dex,                 /* 605: Signal */
  &may23_B.Selector_i2[0],             /* 606: Signal */
  &may23_B.Selector1_b[0],             /* 607: Signal */
  &may23_B.Selector2_e[0],             /* 608: Signal */
  &may23_B.sf_split_primary.link_angles[0],/* 609: Signal */
  &may23_B.sf_split_primary.link_velocities[0],/* 610: Signal */
  &may23_B.sf_split_primary.link_acceleration[0],/* 611: Signal */
  &may23_B.sf_split_primary1.link_angles[0],/* 612: Signal */
  &may23_B.sf_split_primary1.link_velocities[0],/* 613: Signal */
  &may23_B.sf_split_primary1.link_acceleration[0],/* 614: Signal */
  &may23_B.Selector1_e[0],             /* 615: Signal */
  &may23_B.Selector2_l[0],             /* 616: Signal */
  &may23_B.ecatTorques[0],             /* 617: Signal */
  &may23_B.DataStoreRead_h[0],         /* 618: Signal */
  &may23_B.DataTypeConversion_nc[0],   /* 619: Signal */
  &may23_B.DataTypeConversion1_px[0],  /* 620: Signal */
  &may23_B.DataTypeConversion6[0],     /* 621: Signal */
  &may23_B.Product_d[0],               /* 622: Signal */
  &may23_B.Compare_n,                  /* 623: Signal */
  &may23_B.Compare_oi,                 /* 624: Signal */
  &may23_B.sf_MATLABFunction_a.is_right_arm,/* 625: Signal */
  &may23_B.sf_MATLABFunction_a.isExo,  /* 626: Signal */
  &may23_B.sf_MATLABFunction_a.has_high_res_encoders,/* 627: Signal */
  &may23_B.sf_MATLABFunction1.is_right_arm,/* 628: Signal */
  &may23_B.sf_MATLABFunction1.isExo,   /* 629: Signal */
  &may23_B.sf_MATLABFunction1.has_high_res_encoders,/* 630: Signal */
  &may23_B.Compare_d,                  /* 631: Signal */
  &may23_B.filteredVals_n[0],          /* 632: Signal */
  &may23_B.Delay_a[0],                 /* 633: Signal */
  &may23_B.torque_multiplier_out,      /* 634: Signal */
  &may23_B.stop_vel_mode_out,          /* 635: Signal */
  &may23_B.encoder_err_threshold,      /* 636: Signal */
  &may23_B.Memory1_e[0],               /* 637: Signal */
  &may23_B.Compare,                    /* 638: Signal */
  &may23_B.FixPtRelationalOperator_g,  /* 639: Signal */
  &may23_B.Uk1_e,                      /* 640: Signal */
  &may23_B.FixPtRelationalOperator_f,  /* 641: Signal */
  &may23_B.Uk1_h,                      /* 642: Signal */
  &may23_B.Compare_e,                  /* 643: Signal */
  &may23_B.Output,                     /* 644: Signal */
  &may23_B.BlockDefinitions[0],        /* 645: Signal */
  &may23_B.BlockSequence[0],           /* 646: Signal */
  &may23_B.LoadTable[0],               /* 647: Signal */
  &may23_B.TPTable[0],                 /* 648: Signal */
  &may23_B.TargetLabels[0],            /* 649: Signal */
  &may23_B.TargetTable[0],             /* 650: Signal */
  &may23_B.Taskwideparam[0],           /* 651: Signal */
  &may23_B.VCODES_out[0],              /* 652: Signal */
  &may23_B.MatrixConcatenation[0],     /* 653: Signal */
  &may23_B.Reshape[0],                 /* 654: Signal */
  &may23_B.Reshape1[0],                /* 655: Signal */
  &may23_B.FixPtSum1_h,                /* 656: Signal */
  &may23_B.FixPtSwitch_c,              /* 657: Signal */
  &may23_B.Sum,                        /* 658: Signal */
  &may23_B.UnitDelay_h,                /* 659: Signal */
  &may23_B.Output_a,                   /* 660: Signal */
  &may23_B.sf_FindRobottype.robotType, /* 661: Signal */
  &may23_B.SDOCommand_j[0],            /* 662: Signal */
  &may23_B.intSDOValues_m[0],          /* 663: Signal */
  &may23_B.floatSDOValues_d[0],        /* 664: Signal */
  &may23_B.complete_b,                 /* 665: Signal */
  &may23_B.forceMotorState_o,          /* 666: Signal */
  &may23_B.sf_size.count,              /* 667: Signal */
  &may23_B.sf_size1.count,             /* 668: Signal */
  &may23_B.encoderCounts_j[0],         /* 669: Signal */
  &may23_B.FTSensorOffset_k,           /* 670: Signal */
  &may23_B.calibPinAngles_i[0],        /* 671: Signal */
  &may23_B.absAngOffsets_p[0],         /* 672: Signal */
  &may23_B.linkLengths_p[0],           /* 673: Signal */
  &may23_B.L2CalibPinOffset_e,         /* 674: Signal */
  &may23_B.continuousTorques_m[0],     /* 675: Signal */
  &may23_B.gearRatios_j[0],            /* 676: Signal */
  &may23_B.isCalibrated_j,             /* 677: Signal */
  &may23_B.offsetRads_a[0],            /* 678: Signal */
  &may23_B.offsetRadsPrimary_f[0],     /* 679: Signal */
  &may23_B.robotRevision_h,            /* 680: Signal */
  &may23_B.constantsReady_p,           /* 681: Signal */
  &may23_B.hasSecondary_l,             /* 682: Signal */
  &may23_B.hasFT_c,                    /* 683: Signal */
  &may23_B.robotOrientation_o,         /* 684: Signal */
  &may23_B.motorOrientation_j[0],      /* 685: Signal */
  &may23_B.encOrientation_m[0],        /* 686: Signal */
  &may23_B.absEnc_m,                   /* 687: Signal */
  &may23_B.readTrigger_l,              /* 688: Signal */
  &may23_B.R1M1_LinkAngle,             /* 689: Signal */
  &may23_B.R1M1_PrimaryLinkAngle,      /* 690: Signal */
  &may23_B.R1M1_PrimaryLinkVelocity,   /* 691: Signal */
  &may23_B.R1M1_RecordedTorque,        /* 692: Signal */
  &may23_B.R1M1_digitalInputs[0],      /* 693: Signal */
  &may23_B.R1M1_digitalDiagnostics,    /* 694: Signal */
  &may23_B.R1_calibrationButton,       /* 695: Signal */
  &may23_B.R1_EPGripSensor,            /* 696: Signal */
  &may23_B.R1M1_EMCY_codes[0],         /* 697: Signal */
  &may23_B.R1M1_CurrentLimitEnabled,   /* 698: Signal */
  &may23_B.R1M2_LinkAngle,             /* 699: Signal */
  &may23_B.R1M2_PrimaryLinkAngle,      /* 700: Signal */
  &may23_B.R1M2_PrimaryLinkVelocity,   /* 701: Signal */
  &may23_B.R1M2_RecordedTorque,        /* 702: Signal */
  &may23_B.R1M2_digitalInputs[0],      /* 703: Signal */
  &may23_B.R1M2_digitalDiagnostics,    /* 704: Signal */
  &may23_B.R1M2_EMCY_codes[0],         /* 705: Signal */
  &may23_B.R1M2_CurrentLimitEnabled,   /* 706: Signal */
  &may23_B.R1_RobotType,               /* 707: Signal */
  &may23_B.R1_hasSecondary,            /* 708: Signal */
  &may23_B.R1_hasFT,                   /* 709: Signal */
  &may23_B.R1_robotOrientation,        /* 710: Signal */
  &may23_B.R1_motorOrientation[0],     /* 711: Signal */
  &may23_B.R1_encOrientation[0],       /* 712: Signal */
  &may23_B.R1_encodercounts[0],        /* 713: Signal */
  &may23_B.R1_FTSensorAngleOffset,     /* 714: Signal */
  &may23_B.R1_calibPinAngle[0],        /* 715: Signal */
  &may23_B.R1_absAngleOffset[0],       /* 716: Signal */
  &may23_B.R1_LinkLength[0],           /* 717: Signal */
  &may23_B.R1_L2CalibPinOffset,        /* 718: Signal */
  &may23_B.R1_maxContinuousTorque_i[0],/* 719: Signal */
  &may23_B.R1_gearRatios[0],           /* 720: Signal */
  &may23_B.R1_isCalibrated,            /* 721: Signal */
  &may23_B.R1_OffsetRads[0],           /* 722: Signal */
  &may23_B.R1_OffsetRadsPrimary[0],    /* 723: Signal */
  &may23_B.R1_RobotRevision,           /* 724: Signal */
  &may23_B.R1_constantsReady_p,        /* 725: Signal */
  &may23_B.R1_maxContinuousTorque[0],  /* 726: Signal */
  &may23_B.R1_constantsReady,          /* 727: Signal */
  &may23_B.sf_FindRobottype_i.robotType,/* 728: Signal */
  &may23_B.SDOCommand[0],              /* 729: Signal */
  &may23_B.intSDOValues[0],            /* 730: Signal */
  &may23_B.floatSDOValues[0],          /* 731: Signal */
  &may23_B.complete,                   /* 732: Signal */
  &may23_B.forceMotorState,            /* 733: Signal */
  &may23_B.sf_size_l.count,            /* 734: Signal */
  &may23_B.sf_size1_b.count,           /* 735: Signal */
  &may23_B.encoderCounts[0],           /* 736: Signal */
  &may23_B.FTSensorOffset,             /* 737: Signal */
  &may23_B.calibPinAngles[0],          /* 738: Signal */
  &may23_B.absAngOffsets[0],           /* 739: Signal */
  &may23_B.linkLengths[0],             /* 740: Signal */
  &may23_B.L2CalibPinOffset,           /* 741: Signal */
  &may23_B.continuousTorques[0],       /* 742: Signal */
  &may23_B.gearRatios[0],              /* 743: Signal */
  &may23_B.isCalibrated,               /* 744: Signal */
  &may23_B.offsetRads[0],              /* 745: Signal */
  &may23_B.offsetRadsPrimary[0],       /* 746: Signal */
  &may23_B.robotRevision_g,            /* 747: Signal */
  &may23_B.constantsReady,             /* 748: Signal */
  &may23_B.hasSecondary,               /* 749: Signal */
  &may23_B.hasFT,                      /* 750: Signal */
  &may23_B.robotOrientation,           /* 751: Signal */
  &may23_B.motorOrientation[0],        /* 752: Signal */
  &may23_B.encOrientation[0],          /* 753: Signal */
  &may23_B.absEnc,                     /* 754: Signal */
  &may23_B.readTrigger,                /* 755: Signal */
  &may23_B.R2M1_LinkAngle,             /* 756: Signal */
  &may23_B.R2M1_PrimaryLinkAngle,      /* 757: Signal */
  &may23_B.R2M1_PrimaryLinkVelocity,   /* 758: Signal */
  &may23_B.R2M1_RecordedTorque,        /* 759: Signal */
  &may23_B.R2M1_digitalInputs[0],      /* 760: Signal */
  &may23_B.R2M1_digitalDiagnostics,    /* 761: Signal */
  &may23_B.R2_calibrationButton,       /* 762: Signal */
  &may23_B.R2_EPGripSensor,            /* 763: Signal */
  &may23_B.R2M1_EMCY_codes[0],         /* 764: Signal */
  &may23_B.R2M1_CurrentLimitEnabled,   /* 765: Signal */
  &may23_B.R2M2_LinkAngle,             /* 766: Signal */
  &may23_B.R2M2_PrimaryLinkAngle,      /* 767: Signal */
  &may23_B.R2M2_PrimaryLinkVelocity,   /* 768: Signal */
  &may23_B.R2M2_RecordedTorque,        /* 769: Signal */
  &may23_B.R2M2_digitalInputs[0],      /* 770: Signal */
  &may23_B.R2M2_digitalDiagnostics,    /* 771: Signal */
  &may23_B.R2M2_EMCY_codes[0],         /* 772: Signal */
  &may23_B.R2M2_CurrentLimitEnabled,   /* 773: Signal */
  &may23_B.R2_RobotType,               /* 774: Signal */
  &may23_B.R2_hasSecondary,            /* 775: Signal */
  &may23_B.R2_hasFT,                   /* 776: Signal */
  &may23_B.R2_robotOrientation,        /* 777: Signal */
  &may23_B.R2_motorOrientation[0],     /* 778: Signal */
  &may23_B.R2_encOrientation[0],       /* 779: Signal */
  &may23_B.R2_encodercounts[0],        /* 780: Signal */
  &may23_B.R2_FTSensorAngleOffset,     /* 781: Signal */
  &may23_B.R2_calibPinAngle[0],        /* 782: Signal */
  &may23_B.R2_absAngleOffset[0],       /* 783: Signal */
  &may23_B.R2_LinkLength[0],           /* 784: Signal */
  &may23_B.R2_L2CalibPinOffset,        /* 785: Signal */
  &may23_B.R2_maxContinuousTorque_c[0],/* 786: Signal */
  &may23_B.R2_gearRatios[0],           /* 787: Signal */
  &may23_B.R2_isCalibrated,            /* 788: Signal */
  &may23_B.R2_OffsetRads[0],           /* 789: Signal */
  &may23_B.R2_OffsetRadsPrimary[0],    /* 790: Signal */
  &may23_B.R2_RobotRevision,           /* 791: Signal */
  &may23_B.R2_constantsReady_b,        /* 792: Signal */
  &may23_B.R2_maxContinuousTorque[0],  /* 793: Signal */
  &may23_B.R2_constantsReady,          /* 794: Signal */
  &may23_B.Compare_k,                  /* 795: Signal */
  &may23_B.Output_hd,                  /* 796: Signal */
  &may23_B.drive1,                     /* 797: Signal */
  &may23_B.drive2,                     /* 798: Signal */
  &may23_B.drive3,                     /* 799: Signal */
  &may23_B.drive4,                     /* 800: Signal */
  &may23_B.MasterStateOut,             /* 801: Signal */
  &may23_B.errVal,                     /* 802: Signal */
  &may23_B.masterState,                /* 803: Signal */
  &may23_B.DCErrVal,                   /* 804: Signal */
  &may23_B.MasterToNetworkClkDiff,     /* 805: Signal */
  &may23_B.DCInitState,                /* 806: Signal */
  &may23_B.NetworkToSlaveClkDiff,      /* 807: Signal */
  &may23_B.convert[0],                 /* 808: Signal */
  &may23_B.swap_order,                 /* 809: Signal */
  &may23_B.bitField,                   /* 810: Signal */
  &may23_B.kinematicsOut[0],           /* 811: Signal */
  &may23_B.kinematicsOutPrimary[0],    /* 812: Signal */
  &may23_B.delays[0],                  /* 813: Signal */
  &may23_B.servoCounterOut,            /* 814: Signal */
  &may23_B.dataReadyStatus[0],         /* 815: Signal */
  &may23_B.outMem[0],                  /* 816: Signal */
  &may23_B.settingsOut[0],             /* 817: Signal */
  &may23_B.calibrationsOut[0],         /* 818: Signal */
  &may23_B.DataStore[0],               /* 819: Signal */
  &may23_B.DataStore1[0],              /* 820: Signal */
  &may23_B.DataTypeConversion_g0[0],   /* 821: Signal */
  &may23_B.DataTypeConversion1_b[0],   /* 822: Signal */
  &may23_B.DataTypeConversion2_h2,     /* 823: Signal */
  &may23_B.DataTypeConversion3_o[0],   /* 824: Signal */
  &may23_B.DataTypeConversion4_l[0],   /* 825: Signal */
  &may23_B.DataTypeConversion5_c[0],   /* 826: Signal */
  &may23_B.sf_Createtimestamp.timestamp_out,/* 827: Signal */
  &may23_B.DataTypeConversion_e[0],    /* 828: Signal */
  &may23_B.ByteReversal_m[0],          /* 829: Signal */
  &may23_B.ByteReversal1[0],           /* 830: Signal */
  &may23_B.ReceivefromRobot1ForceSensor_o1[0],/* 831: Signal */
  &may23_B.ReceivefromRobot1ForceSensor_o2,/* 832: Signal */
  &may23_B.Unpack_o1[0],               /* 833: Signal */
  &may23_B.Unpack_o2_h[0],             /* 834: Signal */
  &may23_B.Switch_m[0],                /* 835: Signal */
  &may23_B.sf_Createtimestamp_o.timestamp_out,/* 836: Signal */
  &may23_B.DataTypeConversion1_o[0],   /* 837: Signal */
  &may23_B.ByteReversal_c[0],          /* 838: Signal */
  &may23_B.ByteReversal1_f[0],         /* 839: Signal */
  &may23_B.ReceivefromRobot2ForceSensor_o1[0],/* 840: Signal */
  &may23_B.ReceivefromRobot2ForceSensor_o2,/* 841: Signal */
  &may23_B.Unpack1_o1[0],              /* 842: Signal */
  &may23_B.Unpack1_o2[0],              /* 843: Signal */
  &may23_B.Switch1_g[0],               /* 844: Signal */
  &may23_B.Compare_f,                  /* 845: Signal */
  &may23_B.force_scale,                /* 846: Signal */
  &may23_B.robot1DataOut_k[0],         /* 847: Signal */
  &may23_B.robot2DataOut_i[0],         /* 848: Signal */
  &may23_B.robot1PrimaryEncDataOut[0], /* 849: Signal */
  &may23_B.robot2PrimaryEncDataOut[0], /* 850: Signal */
  &may23_B.robot1DataOut[0],           /* 851: Signal */
  &may23_B.robot2DataOut[0],           /* 852: Signal */
  &may23_B.Conversion1[0],             /* 853: Signal */
  &may23_B.Conversion2[0],             /* 854: Signal */
  &may23_B.Conversion7[0],             /* 855: Signal */
  &may23_B.Convert2_o[0],              /* 856: Signal */
  &may23_B.DataTypeConversion_g5x[0],  /* 857: Signal */
  &may23_B.DataTypeConversion1_pf[0],  /* 858: Signal */
  &may23_B.DataTypeConversion2_n,      /* 859: Signal */
  &may23_B.DataTypeConversion3_d[0],   /* 860: Signal */
  &may23_B.DataTypeConversion4_m[0],   /* 861: Signal */
  &may23_B.MinMax_o,                   /* 862: Signal */
  &may23_B.MinMax1,                    /* 863: Signal */
  &may23_B.SFunction_o1_j[0],          /* 864: Signal */
  &may23_B.SFunction_o2[0],            /* 865: Signal */
  &may23_B.SFunction_o3[0],            /* 866: Signal */
  &may23_B.SFunction_o4[0],            /* 867: Signal */
  &may23_B.SFunction_o5[0],            /* 868: Signal */
  &may23_B.SFunction_o6[0],            /* 869: Signal */
  &may23_B.SFunction_o7,               /* 870: Signal */
  &may23_B.SFunction_o8,               /* 871: Signal */
  &may23_B.SFunction_o9[0],            /* 872: Signal */
  &may23_B.SFunction_o10,              /* 873: Signal */
  &may23_B.outStatus[0],               /* 874: Signal */
  &may23_B.Output_n,                   /* 875: Signal */
  &may23_B.kinematics_l[0],            /* 876: Signal */
  &may23_B.primary_o[0],               /* 877: Signal */
  &may23_B.Constant_k,                 /* 878: Signal */
  &may23_B.Constant1_f[0],             /* 879: Signal */
  &may23_B.DataTypeConversion_m[0],    /* 880: Signal */
  &may23_B.DataTypeConversion1_i[0],   /* 881: Signal */
  &may23_B.DataTypeConversion2_h,      /* 882: Signal */
  &may23_B.SFunction[0],               /* 883: Signal */
  &may23_B.Unpack_o[0],                /* 884: Signal */
  &may23_B.Switch_g[0],                /* 885: Signal */
  &may23_B.Compare_h,                  /* 886: Signal */
  &may23_B.Compare_ec,                 /* 887: Signal */
  &may23_B.kinematics[0],              /* 888: Signal */
  &may23_B.primary[0],                 /* 889: Signal */
  &may23_B.Constant_d,                 /* 890: Signal */
  &may23_B.Constant1[0],               /* 891: Signal */
  &may23_B.DataTypeConversion_o[0],    /* 892: Signal */
  &may23_B.DataTypeConversion1_j[0],   /* 893: Signal */
  &may23_B.DataTypeConversion2_f,      /* 894: Signal */
  &may23_B.Receive_o1_i[0],            /* 895: Signal */
  &may23_B.Receive_o2_l,               /* 896: Signal */
  &may23_B.Unpack_o1_n[0],             /* 897: Signal */
  &may23_B.Unpack_o2[0],               /* 898: Signal */
  &may23_B.Compare_e2,                 /* 899: Signal */
  &may23_B.isEP_a,                     /* 900: Signal */
  &may23_B.isHumanEXO_c,               /* 901: Signal */
  &may23_B.isNHPEXO_p,                 /* 902: Signal */
  &may23_B.isClassicExo_n,             /* 903: Signal */
  &may23_B.isUTSEXO_k,                 /* 904: Signal */
  &may23_B.isPMAC_c,                   /* 905: Signal */
  &may23_B.isECAT_b,                   /* 906: Signal */
  &may23_B.elbowangleoffset,           /* 907: Signal */
  &may23_B.L1,                         /* 908: Signal */
  &may23_B.L2,                         /* 909: Signal */
  &may23_B.L3Error,                    /* 910: Signal */
  &may23_B.M1GearRatio_p,              /* 911: Signal */
  &may23_B.M1orientation_b,            /* 912: Signal */
  &may23_B.M2GearRatio_i,              /* 913: Signal */
  &may23_B.M2Orientation_k,            /* 914: Signal */
  &may23_B.ArmOrientation_f,           /* 915: Signal */
  &may23_B.Pointeroffset,              /* 916: Signal */
  &may23_B.HasSecondaryEnc_n,          /* 917: Signal */
  &may23_B.shoulderangleoffset,        /* 918: Signal */
  &may23_B.ShoulderX,                  /* 919: Signal */
  &may23_B.ShoulderY,                  /* 920: Signal */
  &may23_B.torqueconstant_bz,          /* 921: Signal */
  &may23_B.robottype_a,                /* 922: Signal */
  &may23_B.robotversion_h,             /* 923: Signal */
  &may23_B.Statusread1[0],             /* 924: Signal */
  &may23_B.isEP_e,                     /* 925: Signal */
  &may23_B.isHumanEXO,                 /* 926: Signal */
  &may23_B.isNHPEXO,                   /* 927: Signal */
  &may23_B.isClassicExo_e,             /* 928: Signal */
  &may23_B.isUTSEXO,                   /* 929: Signal */
  &may23_B.isPMAC_a,                   /* 930: Signal */
  &may23_B.isECAT_i,                   /* 931: Signal */
  &may23_B.elbowangleoffset_o,         /* 932: Signal */
  &may23_B.L1_e,                       /* 933: Signal */
  &may23_B.L2_j,                       /* 934: Signal */
  &may23_B.L3Error_a,                  /* 935: Signal */
  &may23_B.M1GearRatio_a,              /* 936: Signal */
  &may23_B.M1orientation_f,            /* 937: Signal */
  &may23_B.M2GearRatio_ie,             /* 938: Signal */
  &may23_B.M2Orientation_c,            /* 939: Signal */
  &may23_B.ArmOrientation_m,           /* 940: Signal */
  &may23_B.Pointeroffset_a,            /* 941: Signal */
  &may23_B.HasSecondaryEnc_c,          /* 942: Signal */
  &may23_B.shoulderangleoffset_j,      /* 943: Signal */
  &may23_B.ShoulderX_b,                /* 944: Signal */
  &may23_B.ShoulderY_n,                /* 945: Signal */
  &may23_B.torqueconstant_l,           /* 946: Signal */
  &may23_B.robottype_j,                /* 947: Signal */
  &may23_B.robotversion_f,             /* 948: Signal */
  &may23_B.Statusread1_c[0],           /* 949: Signal */
  &may23_B.Output_o,                   /* 950: Signal */
  &may23_B.FixPtSum1,                  /* 951: Signal */
  &may23_B.FixPtSwitch,                /* 952: Signal */
  &may23_B.FixPtSum1_d,                /* 953: Signal */
  &may23_B.FixPtSwitch_ii,             /* 954: Signal */
  &may23_B.sf_Whistlestate.ControlWord,/* 955: Signal */
  &may23_B.sf_Whistlestate.motorStatus,/* 956: Signal */
  &may23_B.sf_Whistlestate.isPermFaulted,/* 957: Signal */
  &may23_B.sf_cleanword.out_val,       /* 958: Signal */
  &may23_B.Memory_p,                   /* 959: Signal */
  &may23_B.sf_Whistlestate_a.ControlWord,/* 960: Signal */
  &may23_B.sf_Whistlestate_a.motorStatus,/* 961: Signal */
  &may23_B.sf_Whistlestate_a.isPermFaulted,/* 962: Signal */
  &may23_B.sf_cleanword_k.out_val,     /* 963: Signal */
  &may23_B.Memory_jp,                  /* 964: Signal */
  &may23_B.sf_MATLABFunction1_k.mode,  /* 965: Signal */
  &may23_B.sf_AbsEncodermachine.setupData[0],/* 966: Signal */
  &may23_B.sf_AbsEncodermachine.SDORequest[0],/* 967: Signal */
  &may23_B.sf_AbsEncodermachine.encoderOutputs[0],/* 968: Signal */
  &may23_B.sf_AbsEncodermachine.complete,/* 969: Signal */
  &may23_B.sf_setupvalues.setupValues[0],/* 970: Signal */
  &may23_B.sf_setupvalues.setupValuesCount,/* 971: Signal */
  &may23_B.sf_setupvalues.pollValues[0],/* 972: Signal */
  &may23_B.sf_setupvalues.encoderValues[0],/* 973: Signal */
  &may23_B.sf_setupvalues.encoderValuesCount,/* 974: Signal */
  &may23_B.Memory_my,                  /* 975: Signal */
  &may23_B.Memory1_b[0],               /* 976: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o1_l,/* 977: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o2_n,/* 978: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o1_kp,/* 979: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o2_pz,/* 980: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o3_n,/* 981: Signal */
  &may23_B.sf_AbsEncodermachine_l.setupData[0],/* 982: Signal */
  &may23_B.sf_AbsEncodermachine_l.SDORequest[0],/* 983: Signal */
  &may23_B.sf_AbsEncodermachine_l.encoderOutputs[0],/* 984: Signal */
  &may23_B.sf_AbsEncodermachine_l.complete,/* 985: Signal */
  &may23_B.sf_setupvalues_b.setupValues[0],/* 986: Signal */
  &may23_B.sf_setupvalues_b.setupValuesCount,/* 987: Signal */
  &may23_B.sf_setupvalues_b.pollValues[0],/* 988: Signal */
  &may23_B.sf_setupvalues_b.encoderValues[0],/* 989: Signal */
  &may23_B.sf_setupvalues_b.encoderValuesCount,/* 990: Signal */
  &may23_B.Memory_ir,                  /* 991: Signal */
  &may23_B.Memory1_i[0],               /* 992: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o1_h1,/* 993: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o2_b4,/* 994: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o1_g,/* 995: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o2_b,/* 996: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o3_k,/* 997: Signal */
  &may23_B.sf_SDOreadmachine_i.enable, /* 998: Signal */
  &may23_B.sf_SDOreadmachine_i.complete,/* 999: Signal */
  &may23_B.sf_values.outVal[0],        /* 1000: Signal */
  &may23_B.sf_values2.outVal[0],       /* 1001: Signal */
  &may23_B.readAddr_a[0],              /* 1002: Signal */
  &may23_B.DataTypeConversion1_iw,     /* 1003: Signal */
  &may23_B.DataTypeConversion2_h5,     /* 1004: Signal */
  &may23_B.convert_o,                  /* 1005: Signal */
  &may23_B.convert1_n,                 /* 1006: Signal */
  &may23_B.convert2_e,                 /* 1007: Signal */
  &may23_B.convert3_b,                 /* 1008: Signal */
  &may23_B.status_n,                   /* 1009: Signal */
  &may23_B.Memory_g4[0],               /* 1010: Signal */
  &may23_B.sf_MATLABFunction_ae.out_err_code,/* 1011: Signal */
  &may23_B.sf_SDOwritemachine.enable,  /* 1012: Signal */
  &may23_B.sf_SDOwritemachine.complete,/* 1013: Signal */
  &may23_B.sf_convert.y,               /* 1014: Signal */
  &may23_B.writeData_g[0],             /* 1015: Signal */
  &may23_B.DataTypeConversion1_p2,     /* 1016: Signal */
  &may23_B.DataTypeConversion2_a,      /* 1017: Signal */
  &may23_B.status_d,                   /* 1018: Signal */
  &may23_B.Memory_n[0],                /* 1019: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o1_c,/* 1020: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o2_a,/* 1021: Signal */
  &may23_B.Memory_k5,                  /* 1022: Signal */
  &may23_B.Memory1_g,                  /* 1023: Signal */
  &may23_B.Memory2_a[0],               /* 1024: Signal */
  &may23_B.RateTransition_gd,          /* 1025: Signal */
  &may23_B.RateTransition1_i,          /* 1026: Signal */
  &may23_B.RateTransition2_ph[0],      /* 1027: Signal */
  &may23_B.sf_Whistlestate_l.ControlWord,/* 1028: Signal */
  &may23_B.sf_Whistlestate_l.motorStatus,/* 1029: Signal */
  &may23_B.sf_Whistlestate_l.isPermFaulted,/* 1030: Signal */
  &may23_B.sf_cleanword_e.out_val,     /* 1031: Signal */
  &may23_B.Memory_k,                   /* 1032: Signal */
  &may23_B.sf_Whistlestate_m.ControlWord,/* 1033: Signal */
  &may23_B.sf_Whistlestate_m.motorStatus,/* 1034: Signal */
  &may23_B.sf_Whistlestate_m.isPermFaulted,/* 1035: Signal */
  &may23_B.sf_cleanword_i.out_val,     /* 1036: Signal */
  &may23_B.Memory_j,                   /* 1037: Signal */
  &may23_B.sf_AbsEncodermachine_j.setupData[0],/* 1038: Signal */
  &may23_B.sf_AbsEncodermachine_j.SDORequest[0],/* 1039: Signal */
  &may23_B.sf_AbsEncodermachine_j.encoderOutputs[0],/* 1040: Signal */
  &may23_B.sf_AbsEncodermachine_j.complete,/* 1041: Signal */
  &may23_B.sf_setupvalues_p.setupValues[0],/* 1042: Signal */
  &may23_B.sf_setupvalues_p.setupValuesCount,/* 1043: Signal */
  &may23_B.sf_setupvalues_p.pollValues[0],/* 1044: Signal */
  &may23_B.sf_setupvalues_p.encoderValues[0],/* 1045: Signal */
  &may23_B.sf_setupvalues_p.encoderValuesCount,/* 1046: Signal */
  &may23_B.Memory_pj,                  /* 1047: Signal */
  &may23_B.Memory1_lg[0],              /* 1048: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o1_d,/* 1049: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o2_g,/* 1050: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o1_d2,/* 1051: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o2_f,/* 1052: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o3_c,/* 1053: Signal */
  &may23_B.sf_AbsEncodermachine_n.setupData[0],/* 1054: Signal */
  &may23_B.sf_AbsEncodermachine_n.SDORequest[0],/* 1055: Signal */
  &may23_B.sf_AbsEncodermachine_n.encoderOutputs[0],/* 1056: Signal */
  &may23_B.sf_AbsEncodermachine_n.complete,/* 1057: Signal */
  &may23_B.sf_setupvalues_o.setupValues[0],/* 1058: Signal */
  &may23_B.sf_setupvalues_o.setupValuesCount,/* 1059: Signal */
  &may23_B.sf_setupvalues_o.pollValues[0],/* 1060: Signal */
  &may23_B.sf_setupvalues_o.encoderValues[0],/* 1061: Signal */
  &may23_B.sf_setupvalues_o.encoderValuesCount,/* 1062: Signal */
  &may23_B.Memory_i,                   /* 1063: Signal */
  &may23_B.Memory1_n[0],               /* 1064: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o1_f,/* 1065: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o2_f,/* 1066: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o1_k1,/* 1067: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o2,/* 1068: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o3,/* 1069: Signal */
  &may23_B.sf_SDOreadmachine_f.enable, /* 1070: Signal */
  &may23_B.sf_SDOreadmachine_f.complete,/* 1071: Signal */
  &may23_B.sf_values_p.outVal[0],      /* 1072: Signal */
  &may23_B.sf_values2_a.outVal[0],     /* 1073: Signal */
  &may23_B.readAddr[0],                /* 1074: Signal */
  &may23_B.Conversion1_o,              /* 1075: Signal */
  &may23_B.Conversion2_i,              /* 1076: Signal */
  &may23_B.convert_b,                  /* 1077: Signal */
  &may23_B.convert1,                   /* 1078: Signal */
  &may23_B.convert2,                   /* 1079: Signal */
  &may23_B.convert3,                   /* 1080: Signal */
  &may23_B.status_f,                   /* 1081: Signal */
  &may23_B.Memory_ms[0],               /* 1082: Signal */
  &may23_B.sf_MATLABFunction_c.out_err_code,/* 1083: Signal */
  &may23_B.sf_SDOwritemachine_g.enable,/* 1084: Signal */
  &may23_B.sf_SDOwritemachine_g.complete,/* 1085: Signal */
  &may23_B.sf_convert_n.y,             /* 1086: Signal */
  &may23_B.writeData[0],               /* 1087: Signal */
  &may23_B.DataTypeConversion1_du,     /* 1088: Signal */
  &may23_B.DataTypeConversion2_i0,     /* 1089: Signal */
  &may23_B.status,                     /* 1090: Signal */
  &may23_B.Memory_oh[0],               /* 1091: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o1,/* 1092: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o2,/* 1093: Signal */
  &may23_B.sf_MATLABFunction1_c.mode,  /* 1094: Signal */
  &may23_B.Memory_o,                   /* 1095: Signal */
  &may23_B.Memory1_ew,                 /* 1096: Signal */
  &may23_B.Memory2_p[0],               /* 1097: Signal */
  &may23_B.RateTransition_ep,          /* 1098: Signal */
  &may23_B.RateTransition1_p,          /* 1099: Signal */
  &may23_B.RateTransition2_j[0],       /* 1100: Signal */
  &may23_B.FixPtSum1_j,                /* 1101: Signal */
  &may23_B.FixPtSwitch_e,              /* 1102: Signal */
  &may23_B.filteredVels[0],            /* 1103: Signal */
  &may23_B.outVals[0],                 /* 1104: Signal */
  &may23_B.FixPtRelationalOperator,    /* 1105: Signal */
  &may23_B.Uk1,                        /* 1106: Signal */
  &may23_B.ByteReversal_h,             /* 1107: Signal */
  &may23_B.ByteReversal1_l,            /* 1108: Signal */
  &may23_B.ByteReversal2,              /* 1109: Signal */
  &may23_B.Pack_b[0],                  /* 1110: Signal */
  &may23_B.Switch_n,                   /* 1111: Signal */
  (void *) &may23_ConstB.Width_c,      /* 1112: Signal */
  &may23_B.ByteReversal,               /* 1113: Signal */
  &may23_B.ByteReversal1_h,            /* 1114: Signal */
  &may23_B.ByteReversal2_j,            /* 1115: Signal */
  &may23_B.Pack[0],                    /* 1116: Signal */
  &may23_B.Switch_a,                   /* 1117: Signal */
  (void *) &may23_ConstB.Width_i,      /* 1118: Signal */
  &may23_B.FixPtRelationalOperator_n,  /* 1119: Signal */
  &may23_B.Uk1_o,                      /* 1120: Signal */
  &may23_B.y_h,                        /* 1121: Signal */
  &may23_B.DataTypeConversion_g5,      /* 1122: Signal */
  &may23_B.DPRAMReadValue,             /* 1123: Signal */
  &may23_B.UnitDelay,                  /* 1124: Signal */
  &may23_B.UnitDelay1,                 /* 1125: Signal */
  &may23_B.UnitDelay2,                 /* 1126: Signal */
  &may23_B.UnitDelay3,                 /* 1127: Signal */
  &may23_B.FixPtSum1_l,                /* 1128: Signal */
  &may23_B.FixPtSwitch_f,              /* 1129: Signal */
  &may23_B.Output_d,                   /* 1130: Signal */
  &may23_B.FixPtSum1_c,                /* 1131: Signal */
  &may23_B.FixPtSwitch_i,              /* 1132: Signal */
  &may23_B.sf_parsestatusregister.allOK,/* 1133: Signal */
  &may23_B.sf_parsestatusregister.ampStatus,/* 1134: Signal */
  &may23_B.sf_parsestatusregister.servoEnabled,/* 1135: Signal */
  &may23_B.sf_parsestatusregister.faultFound,/* 1136: Signal */
  &may23_B.sf_parsestatusregister.currentLimitEnabled,/* 1137: Signal */
  &may23_B.sf_parsestatusregister.eStopOut,/* 1138: Signal */
  &may23_B.sf_parsestatusregister.motorOn,/* 1139: Signal */
  &may23_B.A1M1Convert[0],             /* 1140: Signal */
  &may23_B.DataTypeConversion1_jv,     /* 1141: Signal */
  &may23_B.Statusword_d,               /* 1142: Signal */
  &may23_B.statusregister_n,           /* 1143: Signal */
  &may23_B.primaryposition_n,          /* 1144: Signal */
  &may23_B.secondaryposition_k,        /* 1145: Signal */
  &may23_B.primaryvelocity_j,          /* 1146: Signal */
  &may23_B.torque_f,                   /* 1147: Signal */
  &may23_B.digitalinputs,              /* 1148: Signal */
  &may23_B.actualmodeofoperation_h,    /* 1149: Signal */
  &may23_B.Compare_jc,                 /* 1150: Signal */
  &may23_B.sf_ReadEMCY.triggerCountRead,/* 1151: Signal */
  &may23_B.sf_ReadEMCY.emcyReadTrigger[0],/* 1152: Signal */
  &may23_B.sf_ReadEMCY.countOverwriteTrigger,/* 1153: Signal */
  &may23_B.sf_ReadEMCY.emcyValPump[0], /* 1154: Signal */
  &may23_B.sf_faultmonitor.triggerFaultRead,/* 1155: Signal */
  &may23_B.sf_passemcy.EMCYMsg[0],     /* 1156: Signal */
  &may23_B.driveID_p,                  /* 1157: Signal */
  &may23_B.DataTypeConversion_lz,      /* 1158: Signal */
  &may23_B.LinkAngle_b,                /* 1159: Signal */
  &may23_B.PrimaryLinkAngle_h,         /* 1160: Signal */
  &may23_B.PrimaryLinkVel_b,           /* 1161: Signal */
  &may23_B.torque_l0,                  /* 1162: Signal */
  &may23_B.digitalInputs_o[0],         /* 1163: Signal */
  &may23_B.digitalDiagnostics_a,       /* 1164: Signal */
  &may23_B.calibrationButton_n,        /* 1165: Signal */
  &may23_B.epGripSensor_i,             /* 1166: Signal */
  &may23_B.L2select_k,                 /* 1167: Signal */
  &may23_B.L2select1_p,                /* 1168: Signal */
  &may23_B.L2select2_l,                /* 1169: Signal */
  &may23_B.L2select3_a,                /* 1170: Signal */
  &may23_B.L2select4_g,                /* 1171: Signal */
  &may23_B.L2select5_o,                /* 1172: Signal */
  &may23_B.sf_parsestatusregister1.allOK,/* 1173: Signal */
  &may23_B.sf_parsestatusregister1.ampStatus,/* 1174: Signal */
  &may23_B.sf_parsestatusregister1.servoEnabled,/* 1175: Signal */
  &may23_B.sf_parsestatusregister1.faultFound,/* 1176: Signal */
  &may23_B.sf_parsestatusregister1.currentLimitEnabled,/* 1177: Signal */
  &may23_B.sf_parsestatusregister1.eStopOut,/* 1178: Signal */
  &may23_B.sf_parsestatusregister1.motorOn,/* 1179: Signal */
  &may23_B.A1M2Convert[0],             /* 1180: Signal */
  &may23_B.DataTypeConversion_ch,      /* 1181: Signal */
  &may23_B.Statusword_n,               /* 1182: Signal */
  &may23_B.statusregister_h,           /* 1183: Signal */
  &may23_B.primaryposition_o,          /* 1184: Signal */
  &may23_B.secondaryposition_e,        /* 1185: Signal */
  &may23_B.primaryvelocity_jy,         /* 1186: Signal */
  &may23_B.torque_m,                   /* 1187: Signal */
  &may23_B.digitalinputs_n,            /* 1188: Signal */
  &may23_B.actualmodeofoperation_hn,   /* 1189: Signal */
  &may23_B.Compare_fs,                 /* 1190: Signal */
  &may23_B.sf_ReadEMCY_h.triggerCountRead,/* 1191: Signal */
  &may23_B.sf_ReadEMCY_h.emcyReadTrigger[0],/* 1192: Signal */
  &may23_B.sf_ReadEMCY_h.countOverwriteTrigger,/* 1193: Signal */
  &may23_B.sf_ReadEMCY_h.emcyValPump[0],/* 1194: Signal */
  &may23_B.sf_faultmonitor_m.triggerFaultRead,/* 1195: Signal */
  &may23_B.sf_passemcy_b.EMCYMsg[0],   /* 1196: Signal */
  &may23_B.driveID_o,                  /* 1197: Signal */
  &may23_B.DataTypeConversion_bu,      /* 1198: Signal */
  &may23_B.LinkAngle_a,                /* 1199: Signal */
  &may23_B.PrimaryLinkAngle_f,         /* 1200: Signal */
  &may23_B.PrimaryLinkVel_d,           /* 1201: Signal */
  &may23_B.torque_l,                   /* 1202: Signal */
  &may23_B.digitalInputs_p[0],         /* 1203: Signal */
  &may23_B.digitalDiagnostics_b,       /* 1204: Signal */
  &may23_B.L2select_p,                 /* 1205: Signal */
  &may23_B.L2select1_pl,               /* 1206: Signal */
  &may23_B.L2select2_mv,               /* 1207: Signal */
  &may23_B.L2select3_i,                /* 1208: Signal */
  &may23_B.L2select4_k,                /* 1209: Signal */
  &may23_B.L2select5_j,                /* 1210: Signal */
  &may23_B.sf_MATLABFunction_mr.out_err_code,/* 1211: Signal */
  &may23_B.sf_converter.uint32Out,     /* 1212: Signal */
  &may23_B.sf_converter.int32Out,      /* 1213: Signal */
  &may23_B.sf_converter.doubleOut,     /* 1214: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o1_p,/* 1215: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o2_ee,/* 1216: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o3_a,/* 1217: Signal */
  &may23_B.sf_MATLABFunction_j.out_err_code,/* 1218: Signal */
  &may23_B.sf_converter_e.uint32Out,   /* 1219: Signal */
  &may23_B.sf_converter_e.int32Out,    /* 1220: Signal */
  &may23_B.sf_converter_e.doubleOut,   /* 1221: Signal */
  &may23_B.DataTypeConversion_bj,      /* 1222: Signal */
  &may23_B.DataTypeConversion1_j1,     /* 1223: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o1_oc,/* 1224: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o2_c,/* 1225: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o3_b,/* 1226: Signal */
  &may23_B.sf_MATLABFunction_e.out_err_code,/* 1227: Signal */
  &may23_B.sf_converter_a.uint32Out,   /* 1228: Signal */
  &may23_B.sf_converter_a.int32Out,    /* 1229: Signal */
  &may23_B.sf_converter_a.doubleOut,   /* 1230: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o1_e,/* 1231: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o2_e,/* 1232: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o3_py,/* 1233: Signal */
  &may23_B.sf_parsestatusregister1_g.allOK,/* 1234: Signal */
  &may23_B.sf_parsestatusregister1_g.ampStatus,/* 1235: Signal */
  &may23_B.sf_parsestatusregister1_g.servoEnabled,/* 1236: Signal */
  &may23_B.sf_parsestatusregister1_g.faultFound,/* 1237: Signal */
  &may23_B.sf_parsestatusregister1_g.currentLimitEnabled,/* 1238: Signal */
  &may23_B.sf_parsestatusregister1_g.eStopOut,/* 1239: Signal */
  &may23_B.sf_parsestatusregister1_g.motorOn,/* 1240: Signal */
  &may23_B.A2M1Convert[0],             /* 1241: Signal */
  &may23_B.DataTypeConversion_mme,     /* 1242: Signal */
  &may23_B.Statusword,                 /* 1243: Signal */
  &may23_B.BKINPDOReceiveElmoDrive_o2, /* 1244: Signal */
  &may23_B.primaryposition,            /* 1245: Signal */
  &may23_B.secondaryposition,          /* 1246: Signal */
  &may23_B.primaryvelocity,            /* 1247: Signal */
  &may23_B.torque_b,                   /* 1248: Signal */
  &may23_B.digitalinput,               /* 1249: Signal */
  &may23_B.actualmodeofoperation,      /* 1250: Signal */
  &may23_B.Compare_ew,                 /* 1251: Signal */
  &may23_B.sf_ReadEMCY_b.triggerCountRead,/* 1252: Signal */
  &may23_B.sf_ReadEMCY_b.emcyReadTrigger[0],/* 1253: Signal */
  &may23_B.sf_ReadEMCY_b.countOverwriteTrigger,/* 1254: Signal */
  &may23_B.sf_ReadEMCY_b.emcyValPump[0],/* 1255: Signal */
  &may23_B.sf_faultmonitor_f.triggerFaultRead,/* 1256: Signal */
  &may23_B.sf_passemcy_c.EMCYMsg[0],   /* 1257: Signal */
  &may23_B.driveID_d,                  /* 1258: Signal */
  &may23_B.DataTypeConversion_pw,      /* 1259: Signal */
  &may23_B.LinkAngle_i,                /* 1260: Signal */
  &may23_B.PrimaryLinkAngle_j,         /* 1261: Signal */
  &may23_B.PrimaryLinkVel_k,           /* 1262: Signal */
  &may23_B.torque_h,                   /* 1263: Signal */
  &may23_B.digitalInputs_g[0],         /* 1264: Signal */
  &may23_B.digitalDiagnostics_p,       /* 1265: Signal */
  &may23_B.calibrationButton,          /* 1266: Signal */
  &may23_B.epGripSensor,               /* 1267: Signal */
  &may23_B.offsetrads,                 /* 1268: Signal */
  &may23_B.encorient,                  /* 1269: Signal */
  &may23_B.L2select2,                  /* 1270: Signal */
  &may23_B.L2select3,                  /* 1271: Signal */
  &may23_B.L2select4,                  /* 1272: Signal */
  &may23_B.L2select5,                  /* 1273: Signal */
  &may23_B.sf_parsestatusregister1_d.allOK,/* 1274: Signal */
  &may23_B.sf_parsestatusregister1_d.ampStatus,/* 1275: Signal */
  &may23_B.sf_parsestatusregister1_d.servoEnabled,/* 1276: Signal */
  &may23_B.sf_parsestatusregister1_d.faultFound,/* 1277: Signal */
  &may23_B.sf_parsestatusregister1_d.currentLimitEnabled,/* 1278: Signal */
  &may23_B.sf_parsestatusregister1_d.eStopOut,/* 1279: Signal */
  &may23_B.sf_parsestatusregister1_d.motorOn,/* 1280: Signal */
  &may23_B.A2M2Convert[0],             /* 1281: Signal */
  &may23_B.DataTypeConversion_ex,      /* 1282: Signal */
  &may23_B.statusword,                 /* 1283: Signal */
  &may23_B.statusregister,             /* 1284: Signal */
  &may23_B.positionprimary,            /* 1285: Signal */
  &may23_B.positionsecondary,          /* 1286: Signal */
  &may23_B.velocityprimary,            /* 1287: Signal */
  &may23_B.torque_i,                   /* 1288: Signal */
  &may23_B.digitalinput_o,             /* 1289: Signal */
  &may23_B.actualmodeofoperation_c,    /* 1290: Signal */
  &may23_B.Compare_c,                  /* 1291: Signal */
  &may23_B.sf_ReadEMCY_o.triggerCountRead,/* 1292: Signal */
  &may23_B.sf_ReadEMCY_o.emcyReadTrigger[0],/* 1293: Signal */
  &may23_B.sf_ReadEMCY_o.countOverwriteTrigger,/* 1294: Signal */
  &may23_B.sf_ReadEMCY_o.emcyValPump[0],/* 1295: Signal */
  &may23_B.sf_faultmonitor_h.triggerFaultRead,/* 1296: Signal */
  &may23_B.sf_passemcy_e.EMCYMsg[0],   /* 1297: Signal */
  &may23_B.driveID,                    /* 1298: Signal */
  &may23_B.DataTypeConversion_mm,      /* 1299: Signal */
  &may23_B.LinkAngle,                  /* 1300: Signal */
  &may23_B.PrimaryLinkAngle,           /* 1301: Signal */
  &may23_B.PrimaryLinkVel,             /* 1302: Signal */
  &may23_B.torque,                     /* 1303: Signal */
  &may23_B.digitalInputs[0],           /* 1304: Signal */
  &may23_B.digitalDiagnostics,         /* 1305: Signal */
  &may23_B.L2select,                   /* 1306: Signal */
  &may23_B.L2select1,                  /* 1307: Signal */
  &may23_B.L2select2_m,                /* 1308: Signal */
  &may23_B.L2select3_l,                /* 1309: Signal */
  &may23_B.L2select4_o,                /* 1310: Signal */
  &may23_B.L2select5_k,                /* 1311: Signal */
  &may23_B.sf_MATLABFunction_f1.out_err_code,/* 1312: Signal */
  &may23_B.sf_converter_f.uint32Out,   /* 1313: Signal */
  &may23_B.sf_converter_f.int32Out,    /* 1314: Signal */
  &may23_B.sf_converter_f.doubleOut,   /* 1315: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o1_g,/* 1316: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o2_g,/* 1317: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o3_p,/* 1318: Signal */
  &may23_B.sf_converter_ai.uint32Out,  /* 1319: Signal */
  &may23_B.sf_converter_ai.int32Out,   /* 1320: Signal */
  &may23_B.sf_converter_ai.doubleOut,  /* 1321: Signal */
  &may23_B.DataTypeConversion_a,       /* 1322: Signal */
  &may23_B.DataTypeConversion1_e,      /* 1323: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o1_o,/* 1324: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o2_n,/* 1325: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o3_h,/* 1326: Signal */
  &may23_B.sf_MATLABFunction_g3.out_err_code,/* 1327: Signal */
  &may23_B.sf_converter_c.uint32Out,   /* 1328: Signal */
  &may23_B.sf_converter_c.int32Out,    /* 1329: Signal */
  &may23_B.sf_converter_c.doubleOut,   /* 1330: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o1,/* 1331: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o2,/* 1332: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload1_o3,/* 1333: Signal */
  &may23_B.Output_c,                   /* 1334: Signal */
  &may23_B.DataTypeConversion_c,       /* 1335: Signal */
  &may23_B.DataTypeConversion1_g,      /* 1336: Signal */
  &may23_B.DataTypeConversion2_o,      /* 1337: Signal */
  &may23_B.Read_h,                     /* 1338: Signal */
  &may23_B.DataTypeConversion_n3,      /* 1339: Signal */
  &may23_B.DataTypeConversion1_o3,     /* 1340: Signal */
  &may23_B.FixPtSum1_g,                /* 1341: Signal */
  &may23_B.FixPtSwitch_o,              /* 1342: Signal */
  &may23_B.Switch_d,                   /* 1343: Signal */
  &may23_B.Switch_mm,                  /* 1344: Signal */
  &may23_B.sf_MATLABFunction_k.prime_out,/* 1345: Signal */
  &may23_B.sf_MATLABFunction_k.sec_out,/* 1346: Signal */
  &may23_B.sf_MATLABFunction_gi.out_err_code,/* 1347: Signal */
  &may23_B.DataTypeConversion_ol,      /* 1348: Signal */
  &may23_B.DataTypeConversion1_p,      /* 1349: Signal */
  &may23_B.DataTypeConversion2_i[0],   /* 1350: Signal */
  &may23_B.Memory_f[0],                /* 1351: Signal */
  &may23_B.RateTransition_kr[0],       /* 1352: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o1_d,/* 1353: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o2_lu,/* 1354: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o3_cf,/* 1355: Signal */
  &may23_B.sf_MATLABFunction_b1.out_err_code,/* 1356: Signal */
  &may23_B.DataTypeConversion_lg[0],   /* 1357: Signal */
  &may23_B.Memory_gu[0],               /* 1358: Signal */
  &may23_B.RateTransition_lt[0],       /* 1359: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o1_ko,/* 1360: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o2_h,/* 1361: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o3_p,/* 1362: Signal */
  &may23_B.DataTypeConversion_ll,      /* 1363: Signal */
  &may23_B.DataTypeConversion1_m3,     /* 1364: Signal */
  &may23_B.Memory_es,                  /* 1365: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o1_p,/* 1366: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o2_p,/* 1367: Signal */
  &may23_B.Switch_p,                   /* 1368: Signal */
  &may23_B.Switch_pj,                  /* 1369: Signal */
  &may23_B.sf_MATLABFunction_m0.prime_out,/* 1370: Signal */
  &may23_B.sf_MATLABFunction_m0.sec_out,/* 1371: Signal */
  &may23_B.sf_MATLABFunction_lu.out_err_code,/* 1372: Signal */
  &may23_B.DataTypeConversion_mx,      /* 1373: Signal */
  &may23_B.DataTypeConversion1_nb,     /* 1374: Signal */
  &may23_B.DataTypeConversion2_g[0],   /* 1375: Signal */
  &may23_B.Memory_c4[0],               /* 1376: Signal */
  &may23_B.RateTransition_n[0],        /* 1377: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o1_k,/* 1378: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o2_i,/* 1379: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o3_nd,/* 1380: Signal */
  &may23_B.sf_MATLABFunction_hz.out_err_code,/* 1381: Signal */
  &may23_B.DataTypeConversion_l[0],    /* 1382: Signal */
  &may23_B.Memory_iv[0],               /* 1383: Signal */
  &may23_B.RateTransition_h[0],        /* 1384: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o1_a,/* 1385: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o2_bg,/* 1386: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o3_ea,/* 1387: Signal */
  &may23_B.DataTypeConversion_pa3,     /* 1388: Signal */
  &may23_B.DataTypeConversion1_m,      /* 1389: Signal */
  &may23_B.Memory_ju,                  /* 1390: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o1_o,/* 1391: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o2_m,/* 1392: Signal */
  &may23_B.Switch_l,                   /* 1393: Signal */
  &may23_B.Switch_g3,                  /* 1394: Signal */
  &may23_B.sf_MATLABFunction_o.prime_out,/* 1395: Signal */
  &may23_B.sf_MATLABFunction_o.sec_out,/* 1396: Signal */
  &may23_B.sf_MATLABFunction_hm.out_err_code,/* 1397: Signal */
  &may23_B.DataTypeConversion_k,       /* 1398: Signal */
  &may23_B.DataTypeConversion1_n,      /* 1399: Signal */
  &may23_B.DataTypeConversion2_b[0],   /* 1400: Signal */
  &may23_B.Memory_c[0],                /* 1401: Signal */
  &may23_B.RateTransition_m[0],        /* 1402: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o1_n,/* 1403: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o2_l,/* 1404: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o3_h,/* 1405: Signal */
  &may23_B.sf_MATLABFunction_m2.out_err_code,/* 1406: Signal */
  &may23_B.DataTypeConversion_n[0],    /* 1407: Signal */
  &may23_B.Memory_g3[0],               /* 1408: Signal */
  &may23_B.RateTransition_gq[0],       /* 1409: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o1_m,/* 1410: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o2_k,/* 1411: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o3_e5,/* 1412: Signal */
  &may23_B.DataTypeConversion_if,      /* 1413: Signal */
  &may23_B.DataTypeConversion1_l,      /* 1414: Signal */
  &may23_B.Memory_e,                   /* 1415: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o1_f2,/* 1416: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o2_b,/* 1417: Signal */
  &may23_B.Switch_j,                   /* 1418: Signal */
  &may23_B.Switch_mq,                  /* 1419: Signal */
  &may23_B.sf_MATLABFunction_ac.prime_out,/* 1420: Signal */
  &may23_B.sf_MATLABFunction_ac.sec_out,/* 1421: Signal */
  &may23_B.sf_MATLABFunction_hj.out_err_code,/* 1422: Signal */
  &may23_B.DataTypeConversion_b5,      /* 1423: Signal */
  &may23_B.DataTypeConversion1_my,     /* 1424: Signal */
  &may23_B.DataTypeConversion2_ht[0],  /* 1425: Signal */
  &may23_B.Memory_gv[0],               /* 1426: Signal */
  &may23_B.RateTransition_l[0],        /* 1427: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o1,/* 1428: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o2_p,/* 1429: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o3_l,/* 1430: Signal */
  &may23_B.sf_MATLABFunction_lj.out_err_code,/* 1431: Signal */
  &may23_B.DataTypeConversion_p1[0],   /* 1432: Signal */
  &may23_B.Memory_ds[0],               /* 1433: Signal */
  &may23_B.RateTransition_g[0],        /* 1434: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o1_n3,/* 1435: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o2_a,/* 1436: Signal */
  &may23_B.BKINEtherCATAsyncSDOUpload_o3_e,/* 1437: Signal */
  &may23_B.DataTypeConversion_j,       /* 1438: Signal */
  &may23_B.DataTypeConversion1_gy,     /* 1439: Signal */
  &may23_B.Memory_g,                   /* 1440: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o1_h,/* 1441: Signal */
  &may23_B.BKINEtherCATAsyncSDODownload_o2_h,/* 1442: Signal */
  &may23_B.FixPtSum1_lg,               /* 1443: Signal */
  &may23_B.FixPtSwitch_ey,             /* 1444: Signal */
  &may23_P.GUIControl_tp_table_rows,   /* 1445: Mask Parameter */
  &may23_P.KINARM_EP_Apply_Loads_up_duration,/* 1446: Mask Parameter */
  &may23_P.KINARM_EP_Apply_Loads_down_duration,/* 1447: Mask Parameter */
  &may23_P.KINARM_EP_Apply_Loads_max_force,/* 1448: Mask Parameter */
  &may23_P.KINARM_Exo_Apply_Loads_up_duration,/* 1449: Mask Parameter */
  &may23_P.KINARM_Exo_Apply_Loads_down_duration,/* 1450: Mask Parameter */
  &may23_P.KINARM_Exo_Apply_Loads_max_torque,/* 1451: Mask Parameter */
  &may23_P.KINARM_Exo_Apply_Loads_limit_motors,/* 1452: Mask Parameter */
  &may23_P.KINARM_HandInBarrier_use_dominant_hand,/* 1453: Mask Parameter */
  &may23_P.KINARM_HandInBarrier_target_type,/* 1454: Mask Parameter */
  &may23_P.KINARM_HandInBarrier_num_states,/* 1455: Mask Parameter */
  &may23_P.KINARM_HandInBarrier_attribcol1[0],/* 1456: Mask Parameter */
  &may23_P.KINARM_HandInTarget_use_dominant_hand,/* 1457: Mask Parameter */
  &may23_P.KINARM_HandInTarget_target_type,/* 1458: Mask Parameter */
  &may23_P.KINARM_HandInTarget_num_states,/* 1459: Mask Parameter */
  &may23_P.KINARM_HandInTarget_attribcol1,/* 1460: Mask Parameter */
  &may23_P.Process_Video_CMD_video_delay,/* 1461: Mask Parameter */
  &may23_P.PuckInBarrier_target_type,  /* 1462: Mask Parameter */
  &may23_P.PuckInBarrier_num_states,   /* 1463: Mask Parameter */
  &may23_P.PuckInBarrier_attribcol1[0],/* 1464: Mask Parameter */
  &may23_P.PuckInTarget_target_type,   /* 1465: Mask Parameter */
  &may23_P.PuckInTarget_num_states,    /* 1466: Mask Parameter */
  &may23_P.PuckInTarget_attribcol1,    /* 1467: Mask Parameter */
  &may23_P.Show_Barrier_target_type,   /* 1468: Mask Parameter */
  &may23_P.Show_Barrier_num_states,    /* 1469: Mask Parameter */
  &may23_P.Show_Barrier_attribcol1[0], /* 1470: Mask Parameter */
  &may23_P.Show_Barrier_attribcol2[0], /* 1471: Mask Parameter */
  &may23_P.Show_Barrier_attribcol3[0], /* 1472: Mask Parameter */
  &may23_P.Show_Barrier_opacity,       /* 1473: Mask Parameter */
  &may23_P.Show_Barrier_target_display,/* 1474: Mask Parameter */
  &may23_P.Show_Cursor_target_type,    /* 1475: Mask Parameter */
  &may23_P.Show_Cursor_num_states,     /* 1476: Mask Parameter */
  &may23_P.Show_Cursor_attribcol1[0],  /* 1477: Mask Parameter */
  &may23_P.Show_Cursor_attribcol2[0],  /* 1478: Mask Parameter */
  &may23_P.Show_Cursor_attribcol3[0],  /* 1479: Mask Parameter */
  &may23_P.Show_Cursor_opacity,        /* 1480: Mask Parameter */
  &may23_P.Show_Cursor_target_display, /* 1481: Mask Parameter */
  &may23_P.Show_Goal_target_type,      /* 1482: Mask Parameter */
  &may23_P.Show_Goal_num_states,       /* 1483: Mask Parameter */
  &may23_P.Show_Goal_attribcol1[0],    /* 1484: Mask Parameter */
  &may23_P.Show_Goal_attribcol2[0],    /* 1485: Mask Parameter */
  &may23_P.Show_Goal_attribcol3[0],    /* 1486: Mask Parameter */
  &may23_P.Show_Goal_opacity,          /* 1487: Mask Parameter */
  &may23_P.Show_Goal_target_display,   /* 1488: Mask Parameter */
  &may23_P.Show_Preshot_Area_target_type,/* 1489: Mask Parameter */
  &may23_P.Show_Preshot_Area_num_states,/* 1490: Mask Parameter */
  &may23_P.Show_Preshot_Area_attribcol1[0],/* 1491: Mask Parameter */
  &may23_P.Show_Preshot_Area_attribcol2[0],/* 1492: Mask Parameter */
  &may23_P.Show_Preshot_Area_attribcol3[0],/* 1493: Mask Parameter */
  &may23_P.Show_Preshot_Area_opacity,  /* 1494: Mask Parameter */
  &may23_P.Show_Preshot_Area_target_display,/* 1495: Mask Parameter */
  &may23_P.Show_Puck_target_type,      /* 1496: Mask Parameter */
  &may23_P.Show_Puck_num_states,       /* 1497: Mask Parameter */
  &may23_P.Show_Puck_attribcol1[0],    /* 1498: Mask Parameter */
  &may23_P.Show_Puck_attribcol2[0],    /* 1499: Mask Parameter */
  &may23_P.Show_Puck_attribcol3[0],    /* 1500: Mask Parameter */
  &may23_P.Show_Puck_opacity,          /* 1501: Mask Parameter */
  &may23_P.Show_Puck_target_display,   /* 1502: Mask Parameter */
  &may23_P.Show_Start_target_type,     /* 1503: Mask Parameter */
  &may23_P.Show_Start_num_states,      /* 1504: Mask Parameter */
  &may23_P.Show_Start_attribcol1[0],   /* 1505: Mask Parameter */
  &may23_P.Show_Start_attribcol2[0],   /* 1506: Mask Parameter */
  &may23_P.Show_Start_attribcol3[0],   /* 1507: Mask Parameter */
  &may23_P.Show_Start_opacity,         /* 1508: Mask Parameter */
  &may23_P.Show_Start_target_display,  /* 1509: Mask Parameter */
  &may23_P.Constant_Value_c,           /* 1510: Block Parameter */
  &may23_P.Memory1_InitialCondition_k, /* 1511: Block Parameter */
  &may23_P.Memory2_InitialCondition_o, /* 1512: Block Parameter */
  &may23_P.Memory4_InitialCondition,   /* 1513: Block Parameter */
  &may23_P.ECATDigDiagnostic_InitialValue[0],/* 1514: Block Parameter */
  &may23_P.ECATStatus_InitialValue[0], /* 1515: Block Parameter */
  &may23_P.ECATStatus1_InitialValue[0],/* 1516: Block Parameter */
  &may23_P.ECAThardware_InitialValue[0],/* 1517: Block Parameter */
  &may23_P.ZeroDigOut_Value[0],        /* 1518: Block Parameter */
  &may23_P.seconds_remaining_Value,    /* 1519: Block Parameter */
  &may23_P.Memory_InitialCondition_pk, /* 1520: Block Parameter */
  &may23_P.Memory1_InitialCondition_n, /* 1521: Block Parameter */
  &may23_P.Constant_Value_d,           /* 1522: Block Parameter */
  &may23_P.DisplaySizem_Value[0],      /* 1523: Block Parameter */
  &may23_P.DisplaySizepels_Value[0],   /* 1524: Block Parameter */
  &may23_P.DockingPoints_Value[0],     /* 1525: Block Parameter */
  &may23_P.ELCameraAngle_Value_j[0],   /* 1526: Block Parameter */
  &may23_P.ELCameraFocalLength_Value_h,/* 1527: Block Parameter */
  &may23_P.ELCameraPosition_Value_e[0],/* 1528: Block Parameter */
  &may23_P.ELTrackingAvailable_Value_m,/* 1529: Block Parameter */
  &may23_P.LibraryPatchVersion_Value,  /* 1530: Block Parameter */
  &may23_P.LibraryVersion_Value,       /* 1531: Block Parameter */
  &may23_P.NextTProw_Value,            /* 1532: Block Parameter */
  &may23_P.PauseType_Value,            /* 1533: Block Parameter */
  &may23_P.Repeat_Trial_Flag_Value,    /* 1534: Block Parameter */
  &may23_P.RunTaskClockFlag_Value,     /* 1535: Block Parameter */
  &may23_P.Seed_Value,                 /* 1536: Block Parameter */
  &may23_P.SubjectHeight_Value,        /* 1537: Block Parameter */
  &may23_P.SubjectWeight_Value,        /* 1538: Block Parameter */
  &may23_P.TaskVersion_Value,          /* 1539: Block Parameter */
  &may23_P.UseRepeatTrialFlag_Value,   /* 1540: Block Parameter */
  &may23_P.UsecustomTPsequence_Value,  /* 1541: Block Parameter */
  &may23_P.dlmbuildtime_Value,         /* 1542: Block Parameter */
  &may23_P.frame_of_reference_center_Value[0],/* 1543: Block Parameter */
  &may23_P.xPCVersion_Value,           /* 1544: Block Parameter */
  &may23_P.Memory_InitialCondition_m,  /* 1545: Block Parameter */
  &may23_P.TorqueLimit2_Value,         /* 1546: Block Parameter */
  &may23_P.Switch_Threshold_bf,        /* 1547: Block Parameter */
  &may23_P.SelectedStates_Value_b,     /* 1548: Block Parameter */
  &may23_P.attribcol2_Value_b[0],      /* 1549: Block Parameter */
  &may23_P.attribcol3_Value_o[0],      /* 1550: Block Parameter */
  &may23_P.attribcol4_Value_l[0],      /* 1551: Block Parameter */
  &may23_P.attribcol5_Value_n[0],      /* 1552: Block Parameter */
  &may23_P.Switch_Threshold_b,         /* 1553: Block Parameter */
  &may23_P.SelectedStates_Value,       /* 1554: Block Parameter */
  &may23_P.attribcol2_Value,           /* 1555: Block Parameter */
  &may23_P.attribcol3_Value,           /* 1556: Block Parameter */
  &may23_P.attribcol4_Value,           /* 1557: Block Parameter */
  &may23_P.attribcol5_Value,           /* 1558: Block Parameter */
  &may23_P.Switch_Threshold_j,         /* 1559: Block Parameter */
  &may23_P.binary_file_names_Value,    /* 1560: Block Parameter */
  &may23_P.binary_files_Value[0],      /* 1561: Block Parameter */
  &may23_P.GUI_VCODE_Value[0],         /* 1562: Block Parameter */
  &may23_P.Gain_Gain_g,                /* 1563: Block Parameter */
  &may23_P.Memory_InitialCondition_i,  /* 1564: Block Parameter */
  &may23_P.Receive_P1_i[0],            /* 1565: Block Parameter */
  &may23_P.Receive_P2_g,               /* 1566: Block Parameter */
  &may23_P.Receive_P3_b2,              /* 1567: Block Parameter */
  &may23_P.Receive_P4_gy,              /* 1568: Block Parameter */
  &may23_P.Receive_P5_i[0],            /* 1569: Block Parameter */
  &may23_P.Receive_P6_j,               /* 1570: Block Parameter */
  &may23_P.Receive_P7_g,               /* 1571: Block Parameter */
  &may23_P.Receive_P9_m,               /* 1572: Block Parameter */
  &may23_P.Send_P1_k1[0],              /* 1573: Block Parameter */
  &may23_P.Send_P2_i,                  /* 1574: Block Parameter */
  &may23_P.Send_P3_d[0],               /* 1575: Block Parameter */
  &may23_P.Send_P4_g,                  /* 1576: Block Parameter */
  &may23_P.Send_P5_ev,                 /* 1577: Block Parameter */
  &may23_P.Send_P6_l,                  /* 1578: Block Parameter */
  &may23_P.SelectedStates_Value_n,     /* 1579: Block Parameter */
  &may23_P.attribcol2_Value_d[0],      /* 1580: Block Parameter */
  &may23_P.attribcol3_Value_c[0],      /* 1581: Block Parameter */
  &may23_P.attribcol4_Value_lm[0],     /* 1582: Block Parameter */
  &may23_P.attribcol5_Value_j[0],      /* 1583: Block Parameter */
  &may23_P.SelectedStates_Value_m,     /* 1584: Block Parameter */
  &may23_P.attribcol2_Value_i,         /* 1585: Block Parameter */
  &may23_P.attribcol3_Value_f,         /* 1586: Block Parameter */
  &may23_P.attribcol4_Value_la,        /* 1587: Block Parameter */
  &may23_P.attribcol5_Value_b,         /* 1588: Block Parameter */
  &may23_P.padder_Value_bi[0],         /* 1589: Block Parameter */
  &may23_P.state4_indices_Value_d[0],  /* 1590: Block Parameter */
  &may23_P.state5_indices_Value_p[0],  /* 1591: Block Parameter */
  &may23_P.xpos_index_Value_e,         /* 1592: Block Parameter */
  &may23_P.ypos_index_Value_c,         /* 1593: Block Parameter */
  &may23_P.padder_Value[0],            /* 1594: Block Parameter */
  &may23_P.state4_indices_Value[0],    /* 1595: Block Parameter */
  &may23_P.state5_indices_Value[0],    /* 1596: Block Parameter */
  &may23_P.xpos_index_Value,           /* 1597: Block Parameter */
  &may23_P.ypos_index_Value,           /* 1598: Block Parameter */
  &may23_P.padder_Value_a[0],          /* 1599: Block Parameter */
  &may23_P.state4_indices_Value_i[0],  /* 1600: Block Parameter */
  &may23_P.state5_indices_Value_j[0],  /* 1601: Block Parameter */
  &may23_P.xpos_index_Value_p,         /* 1602: Block Parameter */
  &may23_P.ypos_index_Value_p,         /* 1603: Block Parameter */
  &may23_P.padder_Value_b[0],          /* 1604: Block Parameter */
  &may23_P.state4_indices_Value_k[0],  /* 1605: Block Parameter */
  &may23_P.state5_indices_Value_jv[0], /* 1606: Block Parameter */
  &may23_P.xpos_index_Value_g,         /* 1607: Block Parameter */
  &may23_P.ypos_index_Value_e,         /* 1608: Block Parameter */
  &may23_P.padder_Value_l[0],          /* 1609: Block Parameter */
  &may23_P.state4_indices_Value_p[0],  /* 1610: Block Parameter */
  &may23_P.state5_indices_Value_l[0],  /* 1611: Block Parameter */
  &may23_P.xpos_index_Value_l,         /* 1612: Block Parameter */
  &may23_P.ypos_index_Value_d,         /* 1613: Block Parameter */
  &may23_P.padder_Value_p[0],          /* 1614: Block Parameter */
  &may23_P.state4_indices_Value_l[0],  /* 1615: Block Parameter */
  &may23_P.state5_indices_Value_d[0],  /* 1616: Block Parameter */
  &may23_P.xpos_index_Value_a,         /* 1617: Block Parameter */
  &may23_P.ypos_index_Value_f,         /* 1618: Block Parameter */
  &may23_P.Perturbation_loadcol[0],    /* 1619: Mask Parameter */
  &may23_P.Memory3_InitialCondition_c, /* 1620: Block Parameter */
  &may23_P.Switch_Threshold_e,         /* 1621: Block Parameter */
  &may23_P.Constant2_Value_e,          /* 1622: Block Parameter */
  &may23_P.PulseGenerator_Amp,         /* 1623: Block Parameter */
  &may23_P.PulseGenerator_Period,      /* 1624: Block Parameter */
  &may23_P.PulseGenerator_Duty,        /* 1625: Block Parameter */
  &may23_P.PulseGenerator_PhaseDelay,  /* 1626: Block Parameter */
  &may23_P.NotLoggingAnalogInputs_Value,/* 1627: Block Parameter */
  &may23_P.custom_version_Value,       /* 1628: Block Parameter */
  &may23_P.RateTransition2_InitialCondition_l,/* 1629: Block Parameter */
  &may23_P.NotLoggingEventCodes_Value, /* 1630: Block Parameter */
  &may23_P.IfRunning_const,            /* 1631: Mask Parameter */
  &may23_P.packet_version_Value,       /* 1632: Block Parameter */
  &may23_P.const_Value[0],             /* 1633: Block Parameter */
  &may23_P.Send_P1[0],                 /* 1634: Block Parameter */
  &may23_P.Send_P2,                    /* 1635: Block Parameter */
  &may23_P.Send_P3[0],                 /* 1636: Block Parameter */
  &may23_P.Send_P4,                    /* 1637: Block Parameter */
  &may23_P.Send_P5,                    /* 1638: Block Parameter */
  &may23_P.Send_P6,                    /* 1639: Block Parameter */
  &may23_P.max_packet_id_Value,        /* 1640: Block Parameter */
  &may23_P.runID_Value,                /* 1641: Block Parameter */
  &may23_P.TaskClock_Amp,              /* 1642: Block Parameter */
  &may23_P.TaskClock_Period,           /* 1643: Block Parameter */
  &may23_P.TaskClock_Duty,             /* 1644: Block Parameter */
  &may23_P.TaskClock_PhaseDelay,       /* 1645: Block Parameter */
  &may23_P.RateTransition1_InitialCondition_c,/* 1646: Block Parameter */
  &may23_P.ain_offset1_Value,          /* 1647: Block Parameter */
  &may23_P.ain_offset2_Value,          /* 1648: Block Parameter */
  &may23_P.ain_slope1_Value,           /* 1649: Block Parameter */
  &may23_P.ain_slope2_Value,           /* 1650: Block Parameter */
  &may23_P.calibration_matrix1_Value[0],/* 1651: Block Parameter */
  &may23_P.calibration_matrix2_Value[0],/* 1652: Block Parameter */
  &may23_P.enable_plate1_Value,        /* 1653: Block Parameter */
  &may23_P.enable_plate2_Value,        /* 1654: Block Parameter */
  &may23_P.gain_Value,                 /* 1655: Block Parameter */
  &may23_P.orientation1_Value,         /* 1656: Block Parameter */
  &may23_P.orientation2_Value,         /* 1657: Block Parameter */
  &may23_P.request_packet_Value[0],    /* 1658: Block Parameter */
  &may23_P.zero_voltage_Value,         /* 1659: Block Parameter */
  &may23_P.ECATDigitalin_InitialValue[0],/* 1660: Block Parameter */
  &may23_P.ECATErrMsgs_InitialValue[0],/* 1661: Block Parameter */
  &may23_P.ECATTorquefeedback_InitialValue[0],/* 1662: Block Parameter */
  &may23_P.HWSettings_InitialValue[0], /* 1663: Block Parameter */
  &may23_P.Kinematics_InitialValue[0], /* 1664: Block Parameter */
  &may23_P.PrimaryEnc_InitialValue[0], /* 1665: Block Parameter */
  &may23_P.RobotCalib_InitialValue[0], /* 1666: Block Parameter */
  &may23_P.RobotRevision_InitialValue[0],/* 1667: Block Parameter */
  &may23_P.ServoUpdate_InitialValue,   /* 1668: Block Parameter */
  &may23_P.Systemstatus_InitialValue[0],/* 1669: Block Parameter */
  &may23_P.calibbutton_InitialValue,   /* 1670: Block Parameter */
  &may23_P.delays_InitialValue[0],     /* 1671: Block Parameter */
  &may23_P.hasFTsensors_InitialValue[0],/* 1672: Block Parameter */
  &may23_P.isecat_const,               /* 1673: Mask Parameter */
  &may23_P.systemtype_Value,           /* 1674: Block Parameter */
  &may23_P.ELCameraAngle_Value[0],     /* 1675: Block Parameter */
  &may23_P.ELCameraFocalLength_Value,  /* 1676: Block Parameter */
  &may23_P.ELCameraPosition_Value[0],  /* 1677: Block Parameter */
  &may23_P.ELTrackingAvailable_Value,  /* 1678: Block Parameter */
  &may23_P.Gain_Gain,                  /* 1679: Block Parameter */
  &may23_P.RateTransition_InitialCondition,/* 1680: Block Parameter */
  &may23_P.Receive_P1_g[0],            /* 1681: Block Parameter */
  &may23_P.Receive_P2_e,               /* 1682: Block Parameter */
  &may23_P.Receive_P3_c,               /* 1683: Block Parameter */
  &may23_P.Receive_P4_m,               /* 1684: Block Parameter */
  &may23_P.Receive_P5_o[0],            /* 1685: Block Parameter */
  &may23_P.Receive_P6_m,               /* 1686: Block Parameter */
  &may23_P.Receive_P7_l,               /* 1687: Block Parameter */
  &may23_P.Receive_P9_c,               /* 1688: Block Parameter */
  &may23_P.isecat_const_n,             /* 1689: Mask Parameter */
  &may23_P.isecat1_const,              /* 1690: Mask Parameter */
  &may23_P.Delay_InitialCondition,     /* 1691: Block Parameter */
  &may23_P.arm_count_Value,            /* 1692: Block Parameter */
  &may23_P.fp1_present_Value,          /* 1693: Block Parameter */
  &may23_P.fp2_present_Value,          /* 1694: Block Parameter */
  &may23_P.gaze_tracker_present_Value, /* 1695: Block Parameter */
  &may23_P.robot_lift_present_Value,   /* 1696: Block Parameter */
  &may23_P.CompareToConstant_const,    /* 1697: Mask Parameter */
  &may23_P.abs_diff_Value,             /* 1698: Block Parameter */
  &may23_P.butterworth_2nd_order_10hz_Value[0],/* 1699: Block Parameter */
  &may23_P.rel_diff_Value,             /* 1700: Block Parameter */
  &may23_P.TaskClock_Amp_l,            /* 1701: Block Parameter */
  &may23_P.TaskClock_Period_m,         /* 1702: Block Parameter */
  &may23_P.TaskClock_Duty_f,           /* 1703: Block Parameter */
  &may23_P.TaskClock_PhaseDelay_hb,    /* 1704: Block Parameter */
  &may23_P.Memory1_InitialCondition_b, /* 1705: Block Parameter */
  &may23_P.Memory2_InitialCondition_d, /* 1706: Block Parameter */
  &may23_P.Delay_InitialCondition_c,   /* 1707: Block Parameter */
  &may23_P.preview_detail_Value[0],    /* 1708: Block Parameter */
  &may23_P.RunCommandReceive_P1[0],    /* 1709: Block Parameter */
  &may23_P.RunCommandReceive_P2,       /* 1710: Block Parameter */
  &may23_P.RunCommandReceive_P3,       /* 1711: Block Parameter */
  &may23_P.RunCommandReceive_P4,       /* 1712: Block Parameter */
  &may23_P.RunCommandReceive_P5[0],    /* 1713: Block Parameter */
  &may23_P.RunCommandReceive_P6,       /* 1714: Block Parameter */
  &may23_P.RunCommandReceive_P7,       /* 1715: Block Parameter */
  &may23_P.RunCommandReceive_P9,       /* 1716: Block Parameter */
  &may23_P.CompareToConstant_const_g,  /* 1717: Mask Parameter */
  &may23_P.Constant_Value_l,           /* 1718: Block Parameter */
  &may23_P.TaskClock_Amp_b,            /* 1719: Block Parameter */
  &may23_P.TaskClock_Period_f,         /* 1720: Block Parameter */
  &may23_P.TaskClock_Duty_p,           /* 1721: Block Parameter */
  &may23_P.TaskClock_PhaseDelay_h,     /* 1722: Block Parameter */
  &may23_P.Delay_InitialCondition_g,   /* 1723: Block Parameter */
  &may23_P.Delay1_InitialCondition,    /* 1724: Block Parameter */
  &may23_P.DetectChange_vinit_m,       /* 1725: Mask Parameter */
  &may23_P.DetectChange1_vinit,        /* 1726: Mask Parameter */
  &may23_P.CompareToConstant_const_f,  /* 1727: Mask Parameter */
  &may23_P.TorqueLimit5_Value,         /* 1728: Block Parameter */
  &may23_P.Switch1_Threshold_j,        /* 1729: Block Parameter */
  &may23_P.Switch_Threshold_g,         /* 1730: Block Parameter */
  &may23_P.Switch1_Threshold_h,        /* 1731: Block Parameter */
  &may23_P.Switch2_Threshold,          /* 1732: Block Parameter */
  &may23_P.Switch3_Threshold,          /* 1733: Block Parameter */
  &may23_P.Switch4_Threshold,          /* 1734: Block Parameter */
  &may23_P.Switch5_Threshold,          /* 1735: Block Parameter */
  &may23_P.Switch6_Threshold,          /* 1736: Block Parameter */
  &may23_P.Switch7_Threshold,          /* 1737: Block Parameter */
  &may23_P.Switch_Threshold_h,         /* 1738: Block Parameter */
  &may23_P.Switch1_Threshold_b,        /* 1739: Block Parameter */
  &may23_P.Switch2_Threshold_p,        /* 1740: Block Parameter */
  &may23_P.Switch3_Threshold_g,        /* 1741: Block Parameter */
  &may23_P.Switch4_Threshold_h,        /* 1742: Block Parameter */
  &may23_P.Switch5_Threshold_j,        /* 1743: Block Parameter */
  &may23_P.Switch6_Threshold_o,        /* 1744: Block Parameter */
  &may23_P.Switch7_Threshold_l,        /* 1745: Block Parameter */
  &may23_P.BARRIER_ROWBarriertargetBarriernone_Value,/* 1746: Block Parameter */
  &may23_P.CURSOR_ROWHandTargetRowtargethandnone_Value,/* 1747: Block Parameter */
  &may23_P.GOAL_ROWGoalRowtargetGoalnone_Value,/* 1748: Block Parameter */
  &may23_P.GOAL_TIMEGoaltimesfloatTimethatpuckhastostayingoaltotriggersucc,/* 1749: Block Parameter */
  &may23_P.LOAD_ROWLoadRowloadLoadnone_Value,/* 1750: Block Parameter */
  &may23_P.PRESHOT_ROWPreshotAreatargetPreshotAreanone_Value,/* 1751: Block Parameter */
  &may23_P.PUCK_DAMPINGPuckdampingfloatDampingconstantonpuckbetween0and1no,/* 1752: Block Parameter */
  &may23_P.PUCK_ROWPuckTargetRowtargetPucknone_Value,/* 1753: Block Parameter */
  &may23_P.SECONDSTrialdurationsfloatHowlongisthetrialinsecondsnone_Value,/* 1754: Block Parameter */
  &may23_P.SHOT_READY_TIMEShotreadytimesfloatTimetoholdinstarttargetduring,/* 1755: Block Parameter */
  &may23_P.SHOT_SET_TIMEShotsettimesfloatTimetoholdinstarttargetafterpresh,/* 1756: Block Parameter */
  &may23_P.SHOT_TIMEShottimesfloatTimetomakeashotintothegoalnone_Value,/* 1757: Block Parameter */
  &may23_P.START_HOLD_TIMEStartholdtimesfloatTimetoholdinstarttargetbefore,/* 1758: Block Parameter */
  &may23_P.START_ROWStartPositiontargetStartingSpotforPtnone_Value,/* 1759: Block Parameter */
  &may23_P.E_BEGIN_PRESHOTbeginpreshotroutinenone_Value,/* 1760: Block Parameter */
  &may23_P.E_ENTER_STARTenterstarttargetnone_Value,/* 1761: Block Parameter */
  &may23_P.E_FAILUREfailurered_Value,  /* 1762: Block Parameter */
  &may23_P.E_HAND_IN_BARRIERhandinbarriernone_Value,/* 1763: Block Parameter */
  &may23_P.E_NO_EVENTnaThisevent_codedoesnotsaveaneventinthedatafileitjust,/* 1764: Block Parameter */
  &may23_P.E_PUCK_IN_BARRIERpuckinbarriernone_Value,/* 1765: Block Parameter */
  &may23_P.E_PUCK_IN_GOALpuckingoalnone_Value,/* 1766: Block Parameter */
  &may23_P.E_PUCK_MISSpuckmissnone_Value,/* 1767: Block Parameter */
  &may23_P.E_SHOT_GOshotgonone_Value,  /* 1768: Block Parameter */
  &may23_P.E_SHOT_READYshotreadynone_Value,/* 1769: Block Parameter */
  &may23_P.E_START_TARGET_ONstarttargetonnone_Value,/* 1770: Block Parameter */
  &may23_P.E_SUCCESSsuccessgreen_Value,/* 1771: Block Parameter */
  &may23_P.E_TIMEOUTtimeoutred_Value,  /* 1772: Block Parameter */
  &may23_P.E_TRIAL_STARTtrialstartnone_Value,/* 1773: Block Parameter */
  &may23_P.F_BUMPF_BUMPfloatCompletelyarbitraryparameterbasedonwhatfeelsgo,/* 1774: Block Parameter */
  &may23_P.MASS_CIRCLECircletargetmassfloatnone_Value,/* 1775: Block Parameter */
  &may23_P.MASS_RECTRectangletargetmassfloatnone_Value,/* 1776: Block Parameter */
  &may23_P.PERT_DURPerturbationDurationfloatmsTimethattheperturbationishig,/* 1777: Block Parameter */
  &may23_P.PERT_RAMPPerturbationRampTimefloatmsTimefortheperturbationtoram,/* 1778: Block Parameter */
  &may23_P.FIRST_FILLFirstfillcolorcolourFirstfillcolorforaselectedtargetc,/* 1779: Block Parameter */
  &may23_P.HEIGHTHeightfloatRectangleheightcmnone_Value,/* 1780: Block Parameter */
  &may23_P.RADIUS_LOGlogicalradiusfloatcomputationalradiuscmnone_Value,/* 1781: Block Parameter */
  &may23_P.RADIUS_VISradiusvisfloatradiusincmlegacynone_Value,/* 1782: Block Parameter */
  &may23_P.ROTATIONRotationfloatRectangleroationdegreesnone_Value,/* 1783: Block Parameter */
  &may23_P.SECOND_FILLSecondfillcolorcolourSecondfillcolorforaselectedtarg,/* 1784: Block Parameter */
  &may23_P.STROKE_COLORStrokecolourcolourStrokecolorcolornone_Value,/* 1785: Block Parameter */
  &may23_P.STROKE_WIDTHWidthofthestrokefloatStrokeweightcmnone_Value,/* 1786: Block Parameter */
  &may23_P.THIRD_FILLthirdfillcolorcolourThirdfillcolorforaselectedtargetc,/* 1787: Block Parameter */
  &may23_P.WIDTHWidthorRadiusfloatRectanglewidthorCircleRadiuscmnone_Value,/* 1788: Block Parameter */
  &may23_P.col_xXfloatXPositioncmofthetargetrelativetolocal00none_Value,/* 1789: Block Parameter */
  &may23_P.col_yYfloatYPositioncmofthetargetrelativetolocal00none_Value,/* 1790: Block Parameter */
  &may23_P.INSTRUCTIONS_Value,         /* 1791: Block Parameter */
  &may23_P.LOAD_FOREITHER_Value,       /* 1792: Block Parameter */
  &may23_P.FORCE_MULTIPLIERForcemultiplierfloatnone_Value,/* 1793: Block Parameter */
  &may23_P.u000hz_Value,               /* 1794: Block Parameter */
  &may23_P.RateTransition1_InitialCondition,/* 1795: Block Parameter */
  &may23_P.Constant_Value_b,           /* 1796: Block Parameter */
  &may23_P.Hand_Feedback_feedback_cntl_src,/* 1797: Mask Parameter */
  &may23_P.WrapToZero_Threshold_my,    /* 1798: Mask Parameter */
  &may23_P.Output_InitialCondition_k,  /* 1799: Block Parameter */
  &may23_P.Constant_Value_bt[0],       /* 1800: Block Parameter */
  &may23_P.Constant1_Value,            /* 1801: Block Parameter */
  &may23_P.MaxFramesPerPacket_Value,   /* 1802: Block Parameter */
  &may23_P.t1_InitialCondition,        /* 1803: Block Parameter */
  &may23_P.t2_InitialCondition,        /* 1804: Block Parameter */
  &may23_P.Memory1_InitialCondition,   /* 1805: Block Parameter */
  &may23_P.Memory2_InitialCondition,   /* 1806: Block Parameter */
  &may23_P.Receive_P1[0],              /* 1807: Block Parameter */
  &may23_P.Receive_P2,                 /* 1808: Block Parameter */
  &may23_P.Receive_P3,                 /* 1809: Block Parameter */
  &may23_P.Receive_P4,                 /* 1810: Block Parameter */
  &may23_P.Receive_P5[0],              /* 1811: Block Parameter */
  &may23_P.Receive_P6,                 /* 1812: Block Parameter */
  &may23_P.Receive_P7,                 /* 1813: Block Parameter */
  &may23_P.Receive_P9,                 /* 1814: Block Parameter */
  &may23_P.total_packets_sent_Y0,      /* 1815: Block Parameter */
  &may23_P.Send_P1_d[0],               /* 1816: Block Parameter */
  &may23_P.Send_P2_b,                  /* 1817: Block Parameter */
  &may23_P.Send_P3_i[0],               /* 1818: Block Parameter */
  &may23_P.Send_P4_a,                  /* 1819: Block Parameter */
  &may23_P.Send_P5_e,                  /* 1820: Block Parameter */
  &may23_P.Send_P6_e,                  /* 1821: Block Parameter */
  &may23_P.RateTransition1_InitialCondition_l,/* 1822: Block Parameter */
  &may23_P.RateTransition2_InitialCondition,/* 1823: Block Parameter */
  &may23_P.Receive_P1_d[0],            /* 1824: Block Parameter */
  &may23_P.Receive_P2_p,               /* 1825: Block Parameter */
  &may23_P.Receive_P3_g,               /* 1826: Block Parameter */
  &may23_P.Receive_P4_g,               /* 1827: Block Parameter */
  &may23_P.Receive_P5_a[0],            /* 1828: Block Parameter */
  &may23_P.Receive_P6_k,               /* 1829: Block Parameter */
  &may23_P.Receive_P7_n,               /* 1830: Block Parameter */
  &may23_P.Receive_P9_l,               /* 1831: Block Parameter */
  &may23_P.Receive1_P1[0],             /* 1832: Block Parameter */
  &may23_P.Receive1_P2,                /* 1833: Block Parameter */
  &may23_P.Receive1_P3,                /* 1834: Block Parameter */
  &may23_P.Receive1_P4,                /* 1835: Block Parameter */
  &may23_P.Receive1_P5[0],             /* 1836: Block Parameter */
  &may23_P.Receive1_P6,                /* 1837: Block Parameter */
  &may23_P.Receive1_P7,                /* 1838: Block Parameter */
  &may23_P.Receive1_P9,                /* 1839: Block Parameter */
  &may23_P.Send_P1_o[0],               /* 1840: Block Parameter */
  &may23_P.Send_P2_bb,                 /* 1841: Block Parameter */
  &may23_P.Send_P3_m[0],               /* 1842: Block Parameter */
  &may23_P.Send_P4_f,                  /* 1843: Block Parameter */
  &may23_P.Send_P5_i,                  /* 1844: Block Parameter */
  &may23_P.Send_P6_p,                  /* 1845: Block Parameter */
  &may23_P.Send1_P1[0],                /* 1846: Block Parameter */
  &may23_P.Send1_P2,                   /* 1847: Block Parameter */
  &may23_P.Send1_P3[0],                /* 1848: Block Parameter */
  &may23_P.Send1_P4,                   /* 1849: Block Parameter */
  &may23_P.Send1_P5,                   /* 1850: Block Parameter */
  &may23_P.Send1_P6,                   /* 1851: Block Parameter */
  &may23_P.Compare_const_i,            /* 1852: Mask Parameter */
  &may23_P.Bias_Bias,                  /* 1853: Block Parameter */
  &may23_P.PCIBusSlot_Value[0],        /* 1854: Block Parameter */
  &may23_P.activation_Value[0],        /* 1855: Block Parameter */
  &may23_P.eppartnums_Value[0],        /* 1856: Block Parameter */
  &may23_P.exopartnums_Value[0],       /* 1857: Block Parameter */
  &may23_P.forceprimaryonly_Value,     /* 1858: Block Parameter */
  &may23_P.maxerrorstofault_Value,     /* 1859: Block Parameter */
  &may23_P.nhppartnums_Value[0],       /* 1860: Block Parameter */
  &may23_P.Switch_Threshold_bk,        /* 1861: Block Parameter */
  &may23_P.Switch1_Threshold_m,        /* 1862: Block Parameter */
  &may23_P.ispmac_const,               /* 1863: Mask Parameter */
  &may23_P.is_running_const,           /* 1864: Mask Parameter */
  &may23_P.ispmac1_const_o,            /* 1865: Mask Parameter */
  &may23_P.ispmac1_const,              /* 1866: Mask Parameter */
  &may23_P.updateconstants_Value,      /* 1867: Block Parameter */
  &may23_P.DominantArm_Value,          /* 1868: Block Parameter */
  &may23_P.is_calibrated_Value[0],     /* 1869: Block Parameter */
  &may23_P.Subject_Arm_Value,          /* 1870: Block Parameter */
  &may23_P.butterworth_2nd_order_250hz_Value[0],/* 1871: Block Parameter */
  &may23_P.Delay_InitialCondition_p,   /* 1872: Block Parameter */
  &may23_P.encoder_err_threshold_Value,/* 1873: Block Parameter */
  &may23_P.Memory1_InitialCondition_m, /* 1874: Block Parameter */
  &may23_P.WrapToZero_Threshold_f,     /* 1875: Mask Parameter */
  &may23_P.Output_InitialCondition_a,  /* 1876: Block Parameter */
  &may23_P.block_defs_Y0[0],           /* 1877: Block Parameter */
  &may23_P.block_seq_Y0[0],            /* 1878: Block Parameter */
  &may23_P.tp_table_Y0[0],             /* 1879: Block Parameter */
  &may23_P.labels_Y0[0],               /* 1880: Block Parameter */
  &may23_P.targets_Y0[0],              /* 1881: Block Parameter */
  &may23_P.loads_Y0[0],                /* 1882: Block Parameter */
  &may23_P.twp_Y0[0],                  /* 1883: Block Parameter */
  &may23_P.BlockDefinitions_Value[0],  /* 1884: Block Parameter */
  &may23_P.BlockSequence_Value[0],     /* 1885: Block Parameter */
  &may23_P.LoadTable_Value[0],         /* 1886: Block Parameter */
  &may23_P.TPTable_Value[0],           /* 1887: Block Parameter */
  &may23_P.TargetLabels_Value[0],      /* 1888: Block Parameter */
  &may23_P.TargetTable_Value[0],       /* 1889: Block Parameter */
  &may23_P.Taskwideparam_Value[0],     /* 1890: Block Parameter */
  &may23_P.feedback_status_Value,      /* 1891: Block Parameter */
  &may23_P.FixPtConstant_Value_gy,     /* 1892: Block Parameter */
  &may23_P.Constant_Value_n,           /* 1893: Block Parameter */
  &may23_P.Constant_Value,             /* 1894: Block Parameter */
  &may23_P.UnitDelay_InitialCondition, /* 1895: Block Parameter */
  &may23_P.WrapToZero_Threshold,       /* 1896: Mask Parameter */
  &may23_P.Output_InitialCondition,    /* 1897: Block Parameter */
  &may23_P.enableCalibration_Value,    /* 1898: Block Parameter */
  &may23_P.enableMotors_Value,         /* 1899: Block Parameter */
  &may23_P.readTrigger_Value,          /* 1900: Block Parameter */
  &may23_P.Memory2_InitialCondition_h, /* 1901: Block Parameter */
  &may23_P.Memory3_InitialCondition,   /* 1902: Block Parameter */
  &may23_P.enableCalibration_Value_k,  /* 1903: Block Parameter */
  &may23_P.enableMotors_Value_h,       /* 1904: Block Parameter */
  &may23_P.readTrigger_Value_a,        /* 1905: Block Parameter */
  &may23_P.Memory2_InitialCondition_i, /* 1906: Block Parameter */
  &may23_P.Memory3_InitialCondition_o, /* 1907: Block Parameter */
  &may23_P.WrapToZero_Threshold_d,     /* 1908: Mask Parameter */
  &may23_P.Output_InitialCondition_p,  /* 1909: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P1_k[0],/* 1910: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P2_j,/* 1911: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P3_n,/* 1912: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P4_ms,/* 1913: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P5_nz,/* 1914: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P6_m,/* 1915: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P7_g,/* 1916: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P1_p[0],/* 1917: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P2_f,/* 1918: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P3_l,/* 1919: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P4_e,/* 1920: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P5_k,/* 1921: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P6_f,/* 1922: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P7_n,/* 1923: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P1[0],/* 1924: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P2,/* 1925: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P3,/* 1926: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P4,/* 1927: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P5,/* 1928: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P6,/* 1929: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P7,/* 1930: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit3_P1[0],/* 1931: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit3_P2,/* 1932: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit3_P3,/* 1933: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit3_P4,/* 1934: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit3_P5,/* 1935: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit3_P6,/* 1936: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit3_P7,/* 1937: Block Parameter */
  &may23_P.Constant1_Value_oq,         /* 1938: Block Parameter */
  &may23_P.DetectChange_vinit,         /* 1939: Mask Parameter */
  &may23_P.Constant_Value_a[0],        /* 1940: Block Parameter */
  &may23_P.ReceivefromRobot1ForceSensor_P1[0],/* 1941: Block Parameter */
  &may23_P.ReceivefromRobot1ForceSensor_P2,/* 1942: Block Parameter */
  &may23_P.ReceivefromRobot1ForceSensor_P3,/* 1943: Block Parameter */
  &may23_P.ReceivefromRobot1ForceSensor_P4,/* 1944: Block Parameter */
  &may23_P.ReceivefromRobot1ForceSensor_P5[0],/* 1945: Block Parameter */
  &may23_P.ReceivefromRobot1ForceSensor_P6,/* 1946: Block Parameter */
  &may23_P.ReceivefromRobot1ForceSensor_P7,/* 1947: Block Parameter */
  &may23_P.ReceivefromRobot1ForceSensor_P9,/* 1948: Block Parameter */
  &may23_P.Switch_Threshold_f,         /* 1949: Block Parameter */
  &may23_P.DetectChange_vinit_k,       /* 1950: Mask Parameter */
  &may23_P.Constant1_Value_k[0],       /* 1951: Block Parameter */
  &may23_P.ReceivefromRobot2ForceSensor_P1[0],/* 1952: Block Parameter */
  &may23_P.ReceivefromRobot2ForceSensor_P2,/* 1953: Block Parameter */
  &may23_P.ReceivefromRobot2ForceSensor_P3,/* 1954: Block Parameter */
  &may23_P.ReceivefromRobot2ForceSensor_P4,/* 1955: Block Parameter */
  &may23_P.ReceivefromRobot2ForceSensor_P5[0],/* 1956: Block Parameter */
  &may23_P.ReceivefromRobot2ForceSensor_P6,/* 1957: Block Parameter */
  &may23_P.ReceivefromRobot2ForceSensor_P7,/* 1958: Block Parameter */
  &may23_P.ReceivefromRobot2ForceSensor_P9,/* 1959: Block Parameter */
  &may23_P.Switch1_Threshold,          /* 1960: Block Parameter */
  &may23_P.robot_count_Value,          /* 1961: Block Parameter */
  &may23_P.Constant_Value_mh[0],       /* 1962: Block Parameter */
  &may23_P.WrapToZero_Threshold_c,     /* 1963: Mask Parameter */
  &may23_P.Output_InitialCondition_d,  /* 1964: Block Parameter */
  &may23_P.EPcalibrationbtn_Y0,        /* 1965: Block Parameter */
  &may23_P.Statusbits_Y0[0],           /* 1966: Block Parameter */
  &may23_P.Taskcontrolbutton_Y0,       /* 1967: Block Parameter */
  &may23_P.Constant_Value_jt,          /* 1968: Block Parameter */
  &may23_P.Constant1_Value_pc[0],      /* 1969: Block Parameter */
  &may23_P.SFunction_P1[0],            /* 1970: Block Parameter */
  &may23_P.SFunction_P2,               /* 1971: Block Parameter */
  &may23_P.SFunction_P3,               /* 1972: Block Parameter */
  &may23_P.SFunction_P4,               /* 1973: Block Parameter */
  &may23_P.SFunction_P5,               /* 1974: Block Parameter */
  &may23_P.SFunction_P6,               /* 1975: Block Parameter */
  &may23_P.SFunction_P7,               /* 1976: Block Parameter */
  &may23_P.Constant_Value_mg[0],       /* 1977: Block Parameter */
  &may23_P.Constant1_Value_h[0],       /* 1978: Block Parameter */
  &may23_P.Constant2_Value[0],         /* 1979: Block Parameter */
  &may23_P.servocounter_Y0,            /* 1980: Block Parameter */
  &may23_P.EPcalibrationbtn_Y0_f,      /* 1981: Block Parameter */
  &may23_P.Statusbits_Y0_l[0],         /* 1982: Block Parameter */
  &may23_P.Constant_Value_h,           /* 1983: Block Parameter */
  &may23_P.Constant1_Value_nm[0],      /* 1984: Block Parameter */
  &may23_P.Receive_P1_m[0],            /* 1985: Block Parameter */
  &may23_P.Receive_P2_j,               /* 1986: Block Parameter */
  &may23_P.Receive_P3_b,               /* 1987: Block Parameter */
  &may23_P.Receive_P4_e,               /* 1988: Block Parameter */
  &may23_P.Receive_P5_d[0],            /* 1989: Block Parameter */
  &may23_P.Receive_P6_kp,              /* 1990: Block Parameter */
  &may23_P.Receive_P7_k,               /* 1991: Block Parameter */
  &may23_P.Receive_P9_h,               /* 1992: Block Parameter */
  &may23_P.Constant_Value_m[0],        /* 1993: Block Parameter */
  &may23_P.Constant1_Value_f[0],       /* 1994: Block Parameter */
  &may23_P.ArmElbowAngleOffset_Value,  /* 1995: Block Parameter */
  &may23_P.ArmEncoderOrientation1_Value,/* 1996: Block Parameter */
  &may23_P.ArmEncoderOrientation2_Value,/* 1997: Block Parameter */
  &may23_P.ArmForceSensorAngleOffset_Value,/* 1998: Block Parameter */
  &may23_P.ArmL1_Value,                /* 1999: Block Parameter */
  &may23_P.ArmL2_Value,                /* 2000: Block Parameter */
  &may23_P.ArmL2L5Angle_Value,         /* 2001: Block Parameter */
  &may23_P.ArmL3Error_Value,           /* 2002: Block Parameter */
  &may23_P.ArmL5_Value,                /* 2003: Block Parameter */
  &may23_P.ArmMotor1GearRatio_Value,   /* 2004: Block Parameter */
  &may23_P.ArmMotor1Orientation_Value, /* 2005: Block Parameter */
  &may23_P.ArmMotor2GearRatio_Value,   /* 2006: Block Parameter */
  &may23_P.ArmMotor2Orientation_Value, /* 2007: Block Parameter */
  &may23_P.ArmOrientation_Value,       /* 2008: Block Parameter */
  &may23_P.ArmPointerOffset_Value,     /* 2009: Block Parameter */
  &may23_P.ArmSecondaryEncoders_Value, /* 2010: Block Parameter */
  &may23_P.ArmShoulderAngleOffset_Value,/* 2011: Block Parameter */
  &may23_P.ArmShoulderX_Value,         /* 2012: Block Parameter */
  &may23_P.ArmShoulderY_Value,         /* 2013: Block Parameter */
  &may23_P.ArmTorqueConstant_Value,    /* 2014: Block Parameter */
  &may23_P.Armprimaryencodercounts_Value,/* 2015: Block Parameter */
  &may23_P.Armrobottype_Value,         /* 2016: Block Parameter */
  &may23_P.Armrobotversion_Value,      /* 2017: Block Parameter */
  &may23_P.Armsecondaryencodercounts_Value,/* 2018: Block Parameter */
  &may23_P.ArmElbowAngleOffset_Value_g,/* 2019: Block Parameter */
  &may23_P.ArmEncoderOrientation1_Value_b,/* 2020: Block Parameter */
  &may23_P.ArmEncoderOrientation2_Value_m,/* 2021: Block Parameter */
  &may23_P.ArmForceSensorAngleOffset_Value_l,/* 2022: Block Parameter */
  &may23_P.ArmL1_Value_f,              /* 2023: Block Parameter */
  &may23_P.ArmL2_Value_g,              /* 2024: Block Parameter */
  &may23_P.ArmL2L5Angle_Value_h,       /* 2025: Block Parameter */
  &may23_P.ArmL3Error_Value_g,         /* 2026: Block Parameter */
  &may23_P.ArmL5_Value_j,              /* 2027: Block Parameter */
  &may23_P.ArmMotor1GearRatio_Value_b, /* 2028: Block Parameter */
  &may23_P.ArmMotor1Orientation_Value_j,/* 2029: Block Parameter */
  &may23_P.ArmMotor2GearRatio_Value_a, /* 2030: Block Parameter */
  &may23_P.ArmMotor2Orientation_Value_o,/* 2031: Block Parameter */
  &may23_P.ArmOrientation_Value_g,     /* 2032: Block Parameter */
  &may23_P.ArmPointerOffset_Value_g,   /* 2033: Block Parameter */
  &may23_P.ArmSecondaryEncoders_Value_f,/* 2034: Block Parameter */
  &may23_P.ArmShoulderAngleOffset_Value_i,/* 2035: Block Parameter */
  &may23_P.ArmShoulderX_Value_l,       /* 2036: Block Parameter */
  &may23_P.ArmShoulderY_Value_e,       /* 2037: Block Parameter */
  &may23_P.ArmTorqueConstant_Value_g,  /* 2038: Block Parameter */
  &may23_P.Armprimaryencodercounts_Value_n,/* 2039: Block Parameter */
  &may23_P.Armrobottype_Value_k,       /* 2040: Block Parameter */
  &may23_P.Armrobotversion_Value_e,    /* 2041: Block Parameter */
  &may23_P.Armsecondaryencodercounts_Value_p,/* 2042: Block Parameter */
  &may23_P.ArmForceSensors_Value[0],   /* 2043: Block Parameter */
  &may23_P.Ready_Value,                /* 2044: Block Parameter */
  &may23_P.WrapToZero_Threshold_m,     /* 2045: Mask Parameter */
  &may23_P.Output_InitialCondition_i,  /* 2046: Block Parameter */
  &may23_P.GazeFeedbackStatus_Value,   /* 2047: Block Parameter */
  &may23_P.HandFeedbackColour_Value,   /* 2048: Block Parameter */
  &may23_P.HandFeedbackFeedForward_Value,/* 2049: Block Parameter */
  &may23_P.HandFeedbackRadius_Value,   /* 2050: Block Parameter */
  &may23_P.HandFeedbackSource_Value,   /* 2051: Block Parameter */
  &may23_P.HandFeedbackStatus_Value,   /* 2052: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P1_a[0],/* 2053: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P2_i,/* 2054: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P3_h,/* 2055: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P4_g,/* 2056: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P5_f,/* 2057: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P6_m,/* 2058: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P7_a,/* 2059: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P1_n[0],/* 2060: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P2_b,/* 2061: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P3_g,/* 2062: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P4_o,/* 2063: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P5_g,/* 2064: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P6_p,/* 2065: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P7_g,/* 2066: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P1_i[0],/* 2067: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P2_h,/* 2068: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P3_j,/* 2069: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P4_i,/* 2070: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P5_k2,/* 2071: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P6_n,/* 2072: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P7_h,/* 2073: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P1_i[0],/* 2074: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P2_f,/* 2075: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P3_o,/* 2076: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P4_m,/* 2077: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P5_j,/* 2078: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P6_b,/* 2079: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit2_P7_j,/* 2080: Block Parameter */
  &may23_P.FixPtConstant_Value_k,      /* 2081: Block Parameter */
  &may23_P.Constant_Value_px,          /* 2082: Block Parameter */
  &may23_P.FixPtConstant_Value,        /* 2083: Block Parameter */
  &may23_P.Constant_Value_j,           /* 2084: Block Parameter */
  &may23_P.Compare_const,              /* 2085: Mask Parameter */
  &may23_P.MotorIdx_Value,             /* 2086: Block Parameter */
  &may23_P.Memory_InitialCondition_p,  /* 2087: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P1[0],/* 2088: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P2, /* 2089: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P3, /* 2090: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P4, /* 2091: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P5, /* 2092: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P6, /* 2093: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P7, /* 2094: Block Parameter */
  &may23_P.Compare_const_f,            /* 2095: Mask Parameter */
  &may23_P.MotorIdx_Value_p,           /* 2096: Block Parameter */
  &may23_P.Memory_InitialCondition_ps, /* 2097: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P1_j[0],/* 2098: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P2_n,/* 2099: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P3_a,/* 2100: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P4_m,/* 2101: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P5_k,/* 2102: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P6_f,/* 2103: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P7_j,/* 2104: Block Parameter */
  &may23_P.override_grip_Value,        /* 2105: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P1_c[0],/* 2106: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P2_p,/* 2107: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P3_i,/* 2108: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P4_n,/* 2109: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P5_o,/* 2110: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P6_e,/* 2111: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P7_p,/* 2112: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P1[0],/* 2113: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P2,/* 2114: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P3,/* 2115: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P4,/* 2116: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P5,/* 2117: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P6,/* 2118: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P7,/* 2119: Block Parameter */
  &may23_P.Memory_InitialCondition_b,  /* 2120: Block Parameter */
  &may23_P.Memory1_InitialCondition_a, /* 2121: Block Parameter */
  &may23_P.Memory_InitialCondition_ba, /* 2122: Block Parameter */
  &may23_P.Memory1_InitialCondition_nm,/* 2123: Block Parameter */
  &may23_P.readAddr_Value[0],          /* 2124: Block Parameter */
  &may23_P.Memory_InitialCondition_e,  /* 2125: Block Parameter */
  &may23_P.writeData_Value[0],         /* 2126: Block Parameter */
  &may23_P.Memory_InitialCondition_n,  /* 2127: Block Parameter */
  &may23_P.Memory_InitialCondition_h,  /* 2128: Block Parameter */
  &may23_P.Memory1_InitialCondition_o, /* 2129: Block Parameter */
  &may23_P.Memory2_InitialCondition_j, /* 2130: Block Parameter */
  &may23_P.Compare_const_p,            /* 2131: Mask Parameter */
  &may23_P.MotorIdx_Value_f,           /* 2132: Block Parameter */
  &may23_P.Memory_InitialCondition_d,  /* 2133: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P1_i[0],/* 2134: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P2_c,/* 2135: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P3_d,/* 2136: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P4_a,/* 2137: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P5_n,/* 2138: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P6_f4,/* 2139: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P7_p1,/* 2140: Block Parameter */
  &may23_P.Compare_const_d,            /* 2141: Mask Parameter */
  &may23_P.MotorIdx_Value_b,           /* 2142: Block Parameter */
  &may23_P.Memory_InitialCondition_ki, /* 2143: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P1_n[0],/* 2144: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P2_k,/* 2145: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P3_b,/* 2146: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P4_k,/* 2147: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P5_a,/* 2148: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P6_g,/* 2149: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P7_b,/* 2150: Block Parameter */
  &may23_P.Memory_InitialCondition_ec, /* 2151: Block Parameter */
  &may23_P.Memory1_InitialCondition_p, /* 2152: Block Parameter */
  &may23_P.Memory_InitialCondition_pu, /* 2153: Block Parameter */
  &may23_P.Memory1_InitialCondition_ai,/* 2154: Block Parameter */
  &may23_P.readAddr_Value_b[0],        /* 2155: Block Parameter */
  &may23_P.Memory_InitialCondition_ex, /* 2156: Block Parameter */
  &may23_P.writeData_Value_o[0],       /* 2157: Block Parameter */
  &may23_P.Memory_InitialCondition_o,  /* 2158: Block Parameter */
  &may23_P.override_grip_Value_p,      /* 2159: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P1_m[0],/* 2160: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P2_g,/* 2161: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P3_iv,/* 2162: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P4_j,/* 2163: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P5_l,/* 2164: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P6_i,/* 2165: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit_P7_a,/* 2166: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P1_d[0],/* 2167: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P2_a,/* 2168: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P3_n,/* 2169: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P4_c,/* 2170: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P5_c,/* 2171: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P6_b,/* 2172: Block Parameter */
  &may23_P.BKINEtherCATPDOTransmit1_P7_g,/* 2173: Block Parameter */
  &may23_P.Memory_InitialCondition_lc, /* 2174: Block Parameter */
  &may23_P.Memory1_InitialCondition_e, /* 2175: Block Parameter */
  &may23_P.Memory2_InitialCondition_c, /* 2176: Block Parameter */
  &may23_P.FixPtConstant_Value_j,      /* 2177: Block Parameter */
  &may23_P.Constant_Value_mv,          /* 2178: Block Parameter */
  &may23_P.undorderbutterworth4Khz10hzcutoff_Value[0],/* 2179: Block Parameter */
  &may23_P.Constant_Value_l5,          /* 2180: Block Parameter */
  &may23_P.Constant1_Value_ov,         /* 2181: Block Parameter */
  &may23_P.Constant2_Value_i,          /* 2182: Block Parameter */
  &may23_P.Constant3_Value,            /* 2183: Block Parameter */
  &may23_P.Send_P1_k[0],               /* 2184: Block Parameter */
  &may23_P.Send_P2_k,                  /* 2185: Block Parameter */
  &may23_P.Send_P3_a[0],               /* 2186: Block Parameter */
  &may23_P.Send_P4_d,                  /* 2187: Block Parameter */
  &may23_P.Send_P5_c,                  /* 2188: Block Parameter */
  &may23_P.Send_P6_i,                  /* 2189: Block Parameter */
  &may23_P.Switch_Threshold,           /* 2190: Block Parameter */
  &may23_P.Constant_Value_g,           /* 2191: Block Parameter */
  &may23_P.Constant1_Value_m,          /* 2192: Block Parameter */
  &may23_P.Constant2_Value_a,          /* 2193: Block Parameter */
  &may23_P.Constant3_Value_k,          /* 2194: Block Parameter */
  &may23_P.Send_P1_p[0],               /* 2195: Block Parameter */
  &may23_P.Send_P2_bu,                 /* 2196: Block Parameter */
  &may23_P.Send_P3_e[0],               /* 2197: Block Parameter */
  &may23_P.Send_P4_m,                  /* 2198: Block Parameter */
  &may23_P.Send_P5_o,                  /* 2199: Block Parameter */
  &may23_P.Send_P6_m,                  /* 2200: Block Parameter */
  &may23_P.Switch_Threshold_k,         /* 2201: Block Parameter */
  &may23_P.DPRAMReadOffset_Value,      /* 2202: Block Parameter */
  &may23_P.DPRAMWatchDogoffset_Value,  /* 2203: Block Parameter */
  &may23_P.DPRAMWriteOffset_Value,     /* 2204: Block Parameter */
  &may23_P.DPRAMWriteValue_Value,      /* 2205: Block Parameter */
  &may23_P.ReadSwitch_Value,           /* 2206: Block Parameter */
  &may23_P.ReadasUInt32_Value,         /* 2207: Block Parameter */
  &may23_P.WriteSwitch_Value,          /* 2208: Block Parameter */
  &may23_P.DPRAMReadValue_Gain,        /* 2209: Block Parameter */
  &may23_P.UnitDelay_InitialCondition_c,/* 2210: Block Parameter */
  &may23_P.UnitDelay1_InitialCondition,/* 2211: Block Parameter */
  &may23_P.UnitDelay2_InitialCondition,/* 2212: Block Parameter */
  &may23_P.UnitDelay3_InitialCondition,/* 2213: Block Parameter */
  &may23_P.FixPtConstant_Value_a,      /* 2214: Block Parameter */
  &may23_P.Constant_Value_i,           /* 2215: Block Parameter */
  &may23_P.WrapToZero_Threshold_h,     /* 2216: Mask Parameter */
  &may23_P.Output_InitialCondition_e,  /* 2217: Block Parameter */
  &may23_P.FixPtConstant_Value_g,      /* 2218: Block Parameter */
  &may23_P.Constant_Value_li,          /* 2219: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P1[0],/* 2220: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P2, /* 2221: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P3, /* 2222: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P4, /* 2223: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P5, /* 2224: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P6, /* 2225: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P7, /* 2226: Block Parameter */
  &may23_P.driveID_Value,              /* 2227: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P1_c[0],/* 2228: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P2_i,/* 2229: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P3_b,/* 2230: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P4_l,/* 2231: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P5_b,/* 2232: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P6_g,/* 2233: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P7_i,/* 2234: Block Parameter */
  &may23_P.driveID_Value_c,            /* 2235: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P1_cm[0],/* 2236: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P2_m,/* 2237: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P3_l,/* 2238: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P4_h,/* 2239: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P5_i,/* 2240: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P6_f,/* 2241: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P7_o,/* 2242: Block Parameter */
  &may23_P.driveID_Value_i,            /* 2243: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P1_g[0],/* 2244: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P2_a,/* 2245: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P3_bd,/* 2246: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P4_p,/* 2247: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P5_f,/* 2248: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P6_fu,/* 2249: Block Parameter */
  &may23_P.BKINPDOReceiveElmoDrive_P7_g,/* 2250: Block Parameter */
  &may23_P.driveID_Value_n,            /* 2251: Block Parameter */
  &may23_P.WrapToZero_Threshold_cm,    /* 2252: Mask Parameter */
  &may23_P.Output_InitialCondition_o,  /* 2253: Block Parameter */
  &may23_P.FixPtConstant_Value_h,      /* 2254: Block Parameter */
  &may23_P.Constant_Value_pz,          /* 2255: Block Parameter */
  &may23_P.Constant_Value_pb,          /* 2256: Block Parameter */
  &may23_P.Switch_Threshold_h2,        /* 2257: Block Parameter */
  &may23_P.Constant_Value_f,           /* 2258: Block Parameter */
  &may23_P.Switch_Threshold_p,         /* 2259: Block Parameter */
  &may23_P.Constant_Value_l2,          /* 2260: Block Parameter */
  &may23_P.Constant1_Value_n,          /* 2261: Block Parameter */
  &may23_P.Memory_InitialCondition_ny, /* 2262: Block Parameter */
  &may23_P.Constant_Value_k,           /* 2263: Block Parameter */
  &may23_P.Memory_InitialCondition_g,  /* 2264: Block Parameter */
  &may23_P.Constant_Value_di,          /* 2265: Block Parameter */
  &may23_P.Constant1_Value_c,          /* 2266: Block Parameter */
  &may23_P.Memory_InitialCondition,    /* 2267: Block Parameter */
  &may23_P.Constant_Value_l0,          /* 2268: Block Parameter */
  &may23_P.Switch_Threshold_c,         /* 2269: Block Parameter */
  &may23_P.Constant_Value_cg,          /* 2270: Block Parameter */
  &may23_P.Switch_Threshold_jw,        /* 2271: Block Parameter */
  &may23_P.Constant_Value_p,           /* 2272: Block Parameter */
  &may23_P.Constant1_Value_o,          /* 2273: Block Parameter */
  &may23_P.Memory_InitialCondition_c,  /* 2274: Block Parameter */
  &may23_P.Constant_Value_ka,          /* 2275: Block Parameter */
  &may23_P.Memory_InitialCondition_ax, /* 2276: Block Parameter */
  &may23_P.Constant_Value_ce,          /* 2277: Block Parameter */
  &may23_P.Constant1_Value_i,          /* 2278: Block Parameter */
  &may23_P.Memory_InitialCondition_k,  /* 2279: Block Parameter */
  &may23_P.Constant_Value_cey,         /* 2280: Block Parameter */
  &may23_P.Switch_Threshold_eg,        /* 2281: Block Parameter */
  &may23_P.Constant_Value_cq,          /* 2282: Block Parameter */
  &may23_P.Switch_Threshold_l,         /* 2283: Block Parameter */
  &may23_P.Constant_Value_mj,          /* 2284: Block Parameter */
  &may23_P.Constant1_Value_g,          /* 2285: Block Parameter */
  &may23_P.Memory_InitialCondition_iz, /* 2286: Block Parameter */
  &may23_P.Constant_Value_k2,          /* 2287: Block Parameter */
  &may23_P.Memory_InitialCondition_bo, /* 2288: Block Parameter */
  &may23_P.Constant_Value_jo,          /* 2289: Block Parameter */
  &may23_P.Constant1_Value_p,          /* 2290: Block Parameter */
  &may23_P.Memory_InitialCondition_pg, /* 2291: Block Parameter */
  &may23_P.Constant_Value_e,           /* 2292: Block Parameter */
  &may23_P.Switch_Threshold_kt,        /* 2293: Block Parameter */
  &may23_P.Constant_Value_cc,          /* 2294: Block Parameter */
  &may23_P.Switch_Threshold_pr,        /* 2295: Block Parameter */
  &may23_P.Constant_Value_de,          /* 2296: Block Parameter */
  &may23_P.Constant1_Value_j,          /* 2297: Block Parameter */
  &may23_P.Memory_InitialCondition_hd, /* 2298: Block Parameter */
  &may23_P.Constant_Value_o,           /* 2299: Block Parameter */
  &may23_P.Memory_InitialCondition_l,  /* 2300: Block Parameter */
  &may23_P.Constant_Value_oz,          /* 2301: Block Parameter */
  &may23_P.Constant1_Value_ns,         /* 2302: Block Parameter */
  &may23_P.Memory_InitialCondition_a,  /* 2303: Block Parameter */
  &may23_P.FixPtConstant_Value_n,      /* 2304: Block Parameter */
  &may23_P.Constant_Value_pq,          /* 2305: Block Parameter */
  &may23_P.BKIN_STEP_TIME,             /* 2306: Model Parameter */
  &BARRIER_ROW,                        /* 2307: Model Parameter */
  &CURSOR_ROW,                         /* 2308: Model Parameter */
  &E_BEGIN_PRESHOT,                    /* 2309: Model Parameter */
  &E_ENTER_START,                      /* 2310: Model Parameter */
  &E_FAILURE,                          /* 2311: Model Parameter */
  &E_HAND_IN_BARRIER,                  /* 2312: Model Parameter */
  &E_NO_EVENT,                         /* 2313: Model Parameter */
  &E_PUCK_IN_BARRIER,                  /* 2314: Model Parameter */
  &E_PUCK_IN_GOAL,                     /* 2315: Model Parameter */
  &E_PUCK_MISS,                        /* 2316: Model Parameter */
  &E_SHOT_GO,                          /* 2317: Model Parameter */
  &E_SHOT_READY,                       /* 2318: Model Parameter */
  &E_START_TARGET_ON,                  /* 2319: Model Parameter */
  &E_SUCCESS,                          /* 2320: Model Parameter */
  &E_TIMEOUT,                          /* 2321: Model Parameter */
  &E_TRIAL_START,                      /* 2322: Model Parameter */
  &FIRST_FILL,                         /* 2323: Model Parameter */
  &FORCE_MULTIPLIER,                   /* 2324: Model Parameter */
  &F_BUMP,                             /* 2325: Model Parameter */
  &GOAL_ROW,                           /* 2326: Model Parameter */
  &GOAL_TIME,                          /* 2327: Model Parameter */
  &HEIGHT,                             /* 2328: Model Parameter */
  &LOAD_ROW,                           /* 2329: Model Parameter */
  &MASS_CIRCLE,                        /* 2330: Model Parameter */
  &MASS_RECT,                          /* 2331: Model Parameter */
  &PERT_DUR,                           /* 2332: Model Parameter */
  &PERT_RAMP,                          /* 2333: Model Parameter */
  &PRESHOT_ROW,                        /* 2334: Model Parameter */
  &PUCK_DAMPING,                       /* 2335: Model Parameter */
  &PUCK_ROW,                           /* 2336: Model Parameter */
  &RADIUS_LOG,                         /* 2337: Model Parameter */
  &RADIUS_VIS,                         /* 2338: Model Parameter */
  &ROTATION,                           /* 2339: Model Parameter */
  &SECONDS,                            /* 2340: Model Parameter */
  &SECOND_FILL,                        /* 2341: Model Parameter */
  &SHOT_READY_TIME,                    /* 2342: Model Parameter */
  &SHOT_SET_TIME,                      /* 2343: Model Parameter */
  &SHOT_TIME,                          /* 2344: Model Parameter */
  &START_HOLD_TIME,                    /* 2345: Model Parameter */
  &START_ROW,                          /* 2346: Model Parameter */
  &STROKE_COLOR,                       /* 2347: Model Parameter */
  &STROKE_WIDTH,                       /* 2348: Model Parameter */
  &THIRD_FILL,                         /* 2349: Model Parameter */
  &WIDTH,                              /* 2350: Model Parameter */
  &col_x,                              /* 2351: Model Parameter */
  &col_y,                              /* 2352: Model Parameter */
};

/* Declare Data Run-Time Dimension Buffer Addresses statically */
static int32_T* rtVarDimsAddrMap[] = {
  (NULL)
};

#endif

/* Data Type Map - use dataTypeMapIndex to access this structure */
static TARGET_CONST rtwCAPI_DataTypeMap rtDataTypeMap[] = {
  /* cName, mwName, numElements, elemMapIndex, dataSize, slDataId, *
   * isComplex, isPointer, enumStorageType */
  { "unsigned char", "boolean_T", 0, 0, sizeof(boolean_T), SS_BOOLEAN, 0, 0, 0 },

  { "double", "real_T", 0, 0, sizeof(real_T), SS_DOUBLE, 0, 0, 0 },

  { "unsigned int", "uint32_T", 0, 0, sizeof(uint32_T), SS_UINT32, 0, 0, 0 },

  { "unsigned char", "uint8_T", 0, 0, sizeof(uint8_T), SS_UINT8, 0, 0, 0 },

  { "float", "real32_T", 0, 0, sizeof(real32_T), SS_SINGLE, 0, 0, 0 },

  { "int", "int32_T", 0, 0, sizeof(int32_T), SS_INT32, 0, 0, 0 },

  { "short", "int16_T", 0, 0, sizeof(int16_T), SS_INT16, 0, 0, 0 },

  { "unsigned short", "uint16_T", 0, 0, sizeof(uint16_T), SS_UINT16, 0, 0, 0 },

  { "signed char", "int8_T", 0, 0, sizeof(int8_T), SS_INT8, 0, 0, 0 }
};

#ifdef HOST_CAPI_BUILD
#undef sizeof
#endif

/* Structure Element Map - use elemMapIndex to access this structure */
static TARGET_CONST rtwCAPI_ElementMap rtElementMap[] = {
  /* elementName, elementOffset, dataTypeIndex, dimIndex, fxpIndex */
  { (NULL), 0, 0, 0, 0 },
};

/* Dimension Map - use dimensionMapIndex to access elements of ths structure*/
static const rtwCAPI_DimensionMap rtDimensionMap[] = {
  /* dataOrientation, dimArrayIndex, numDims, vardimsIndex */
  { rtwCAPI_SCALAR, 0, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 2, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 4, 2, 0 },

  { rtwCAPI_VECTOR, 6, 2, 0 },

  { rtwCAPI_VECTOR, 8, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 10, 2, 0 },

  { rtwCAPI_VECTOR, 12, 2, 0 },

  { rtwCAPI_VECTOR, 14, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 16, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 18, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 20, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 22, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 24, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 26, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 28, 2, 0 },

  { rtwCAPI_VECTOR, 30, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 32, 2, 0 },

  { rtwCAPI_VECTOR, 34, 2, 0 },

  { rtwCAPI_VECTOR, 36, 2, 0 },

  { rtwCAPI_VECTOR, 38, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 40, 2, 0 },

  { rtwCAPI_VECTOR, 42, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 44, 2, 0 },

  { rtwCAPI_VECTOR, 46, 2, 0 },

  { rtwCAPI_VECTOR, 48, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 50, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 52, 2, 0 },

  { rtwCAPI_VECTOR, 54, 2, 0 },

  { rtwCAPI_VECTOR, 56, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 58, 2, 0 },

  { rtwCAPI_VECTOR, 60, 2, 0 },

  { rtwCAPI_VECTOR, 62, 2, 0 },

  { rtwCAPI_VECTOR, 64, 2, 0 },

  { rtwCAPI_VECTOR, 66, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 68, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 70, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 72, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 74, 2, 0 },

  { rtwCAPI_VECTOR, 76, 2, 0 },

  { rtwCAPI_VECTOR, 78, 2, 0 },

  { rtwCAPI_VECTOR, 80, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 82, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 84, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 86, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 88, 2, 0 },

  { rtwCAPI_VECTOR, 90, 2, 0 },

  { rtwCAPI_VECTOR, 92, 2, 0 },

  { rtwCAPI_VECTOR, 28, 2, 0 },

  { rtwCAPI_VECTOR, 94, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 96, 2, 0 },

  { rtwCAPI_VECTOR, 98, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 100, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 102, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 104, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 106, 2, 0 },

  { rtwCAPI_VECTOR, 108, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 110, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 112, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 114, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 116, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 118, 2, 0 },

  { rtwCAPI_VECTOR, 120, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 122, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 124, 2, 0 },

  { rtwCAPI_VECTOR, 126, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 128, 2, 0 },

  { rtwCAPI_VECTOR, 130, 2, 0 },

  { rtwCAPI_VECTOR, 132, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 134, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 136, 2, 0 },

  { rtwCAPI_VECTOR, 22, 2, 0 },

  { rtwCAPI_VECTOR, 104, 2, 0 },

  { rtwCAPI_VECTOR, 16, 2, 0 },

  { rtwCAPI_VECTOR, 70, 2, 0 },

  { rtwCAPI_VECTOR, 122, 2, 0 },

  { rtwCAPI_VECTOR, 138, 2, 0 },

  { rtwCAPI_VECTOR, 18, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 140, 2, 0 },

  { rtwCAPI_VECTOR, 142, 2, 0 },

  { rtwCAPI_VECTOR, 144, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 146, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 148, 2, 0 },

  { rtwCAPI_VECTOR, 150, 2, 0 },

  { rtwCAPI_MATRIX_COL_MAJOR, 152, 2, 0 },

  { rtwCAPI_VECTOR, 154, 2, 0 },

  { rtwCAPI_VECTOR, 128, 2, 0 },

  { rtwCAPI_VECTOR, 58, 2, 0 },

  { rtwCAPI_VECTOR, 156, 2, 0 },

  { rtwCAPI_VECTOR, 158, 2, 0 },

  { rtwCAPI_VECTOR, 160, 2, 0 },

  { rtwCAPI_VECTOR, 162, 2, 0 },

  { rtwCAPI_VECTOR, 164, 2, 0 },

  { rtwCAPI_VECTOR, 166, 2, 0 },

  { rtwCAPI_VECTOR, 168, 2, 0 }
};

/* Dimension Array- use dimArrayIndex to access elements of this array */
static const uint_T rtDimensionArray[] = {
  1,                                   /* 0 */
  1,                                   /* 1 */
  7,                                   /* 2 */
  70,                                  /* 3 */
  1,                                   /* 4 */
  70,                                  /* 5 */
  4,                                   /* 6 */
  1,                                   /* 7 */
  8,                                   /* 8 */
  1,                                   /* 9 */
  1,                                   /* 10 */
  20,                                  /* 11 */
  16,                                  /* 12 */
  1,                                   /* 13 */
  2,                                   /* 14 */
  1,                                   /* 15 */
  1,                                   /* 16 */
  4,                                   /* 17 */
  1,                                   /* 18 */
  2,                                   /* 19 */
  5,                                   /* 20 */
  2,                                   /* 21 */
  1,                                   /* 22 */
  3,                                   /* 23 */
  1,                                   /* 24 */
  50,                                  /* 25 */
  64,                                  /* 26 */
  5,                                   /* 27 */
  64,                                  /* 28 */
  1,                                   /* 29 */
  10,                                  /* 30 */
  1,                                   /* 31 */
  70,                                  /* 32 */
  16,                                  /* 33 */
  630,                                 /* 34 */
  1,                                   /* 35 */
  490,                                 /* 36 */
  1,                                   /* 37 */
  30,                                  /* 38 */
  1,                                   /* 39 */
  5,                                   /* 40 */
  11,                                  /* 41 */
  25,                                  /* 42 */
  1,                                   /* 43 */
  1,                                   /* 44 */
  25,                                  /* 45 */
  20,                                  /* 46 */
  1,                                   /* 47 */
  35,                                  /* 48 */
  1,                                   /* 49 */
  1,                                   /* 50 */
  71,                                  /* 51 */
  1,                                   /* 52 */
  72,                                  /* 53 */
  40,                                  /* 54 */
  1,                                   /* 55 */
  410,                                 /* 56 */
  1,                                   /* 57 */
  1,                                   /* 58 */
  400,                                 /* 59 */
  34,                                  /* 60 */
  1,                                   /* 61 */
  14,                                  /* 62 */
  1,                                   /* 63 */
  3,                                   /* 64 */
  1,                                   /* 65 */
  512,                                 /* 66 */
  1,                                   /* 67 */
  2,                                   /* 68 */
  4,                                   /* 69 */
  1,                                   /* 70 */
  8,                                   /* 71 */
  1,                                   /* 72 */
  500,                                 /* 73 */
  1000,                                /* 74 */
  1,                                   /* 75 */
  27240,                               /* 76 */
  1,                                   /* 77 */
  5,                                   /* 78 */
  1,                                   /* 79 */
  6810,                                /* 80 */
  1,                                   /* 81 */
  20,                                  /* 82 */
  20,                                  /* 83 */
  2,                                   /* 84 */
  2,                                   /* 85 */
  2,                                   /* 86 */
  70,                                  /* 87 */
  1,                                   /* 88 */
  182,                                 /* 89 */
  21,                                  /* 90 */
  1,                                   /* 91 */
  1640,                                /* 92 */
  1,                                   /* 93 */
  12,                                  /* 94 */
  1,                                   /* 95 */
  12,                                  /* 96 */
  2,                                   /* 97 */
  6,                                   /* 98 */
  1,                                   /* 99 */
  3,                                   /* 100 */
  50,                                  /* 101 */
  2,                                   /* 102 */
  6,                                   /* 103 */
  1,                                   /* 104 */
  6,                                   /* 105 */
  4,                                   /* 106 */
  5,                                   /* 107 */
  7,                                   /* 108 */
  1,                                   /* 109 */
  50,                                  /* 110 */
  500,                                 /* 111 */
  1000,                                /* 112 */
  3,                                   /* 113 */
  100,                                 /* 114 */
  50,                                  /* 115 */
  64,                                  /* 116 */
  50,                                  /* 117 */
  64,                                  /* 118 */
  25,                                  /* 119 */
  50,                                  /* 120 */
  1,                                   /* 121 */
  1,                                   /* 122 */
  10,                                  /* 123 */
  1,                                   /* 124 */
  16,                                  /* 125 */
  36,                                  /* 126 */
  1,                                   /* 127 */
  1,                                   /* 128 */
  7,                                   /* 129 */
  52,                                  /* 130 */
  1,                                   /* 131 */
  13,                                  /* 132 */
  1,                                   /* 133 */
  8,                                   /* 134 */
  3,                                   /* 135 */
  6,                                   /* 136 */
  2,                                   /* 137 */
  1,                                   /* 138 */
  14,                                  /* 139 */
  70,                                  /* 140 */
  9,                                   /* 141 */
  1,                                   /* 142 */
  26,                                  /* 143 */
  1,                                   /* 144 */
  11,                                  /* 145 */
  5,                                   /* 146 */
  5,                                   /* 147 */
  5,                                   /* 148 */
  7,                                   /* 149 */
  1,                                   /* 150 */
  5,                                   /* 151 */
  6,                                   /* 152 */
  8,                                   /* 153 */
  1,                                   /* 154 */
  34,                                  /* 155 */
  1,                                   /* 156 */
  13,                                  /* 157 */
  1,                                   /* 158 */
  46,                                  /* 159 */
  1,                                   /* 160 */
  12,                                  /* 161 */
  1,                                   /* 162 */
  42,                                  /* 163 */
  1,                                   /* 164 */
  41,                                  /* 165 */
  1,                                   /* 166 */
  48,                                  /* 167 */
  1,                                   /* 168 */
  39                                   /* 169 */
};

/* C-API stores floating point values in an array. The elements of this  *
 * are unique. This ensures that values which are shared across the model*
 * are stored in the most efficient way. These values are referenced by  *
 *           - rtwCAPI_FixPtMap.fracSlopePtr,                            *
 *           - rtwCAPI_FixPtMap.biasPtr,                                 *
 *           - rtwCAPI_SampleTimeMap.samplePeriodPtr,                    *
 *           - rtwCAPI_SampleTimeMap.sampleOffsetPtr                     */
static const real_T rtcapiStoredFloats[] = {
  0.00025, 0.0, 0.001, 0.1, 0.0005
};

/* Fixed Point Map */
static const rtwCAPI_FixPtMap rtFixPtMap[] = {
  /* fracSlopePtr, biasPtr, scaleType, wordLength, exponent, isSigned */
  { (NULL), (NULL), rtwCAPI_FIX_RESERVED, 0, 0, 0 },
};

/* Sample Time Map - use sTimeIndex to access elements of ths structure */
static const rtwCAPI_SampleTimeMap rtSampleTimeMap[] = {
  /* samplePeriodPtr, sampleOffsetPtr, tid, samplingMode */
  { (NULL), (NULL), -1, 0 },

  { (const void *) &rtcapiStoredFloats[0], (const void *) &rtcapiStoredFloats[1],
    1, 0 },

  { (const void *) &rtcapiStoredFloats[2], (const void *) &rtcapiStoredFloats[1],
    3, 0 },

  { (NULL), (NULL), -2, 0 },

  { (const void *) &rtcapiStoredFloats[3], (const void *) &rtcapiStoredFloats[1],
    4, 0 },

  { (const void *) &rtcapiStoredFloats[4], (const void *) &rtcapiStoredFloats[1],
    2, 0 }
};

static rtwCAPI_ModelMappingStaticInfo mmiStatic = {
  /* Signals:{signals, numSignals,
   *           rootInputs, numRootInputs,
   *           rootOutputs, numRootOutputs},
   * Params: {blockParameters, numBlockParameters,
   *          modelParameters, numModelParameters},
   * States: {states, numStates},
   * Maps:   {dataTypeMap, dimensionMap, fixPtMap,
   *          elementMap, sampleTimeMap, dimensionArray},
   * TargetType: targetType
   */
  { rtBlockSignals, 1445,
    (NULL), 0,
    (NULL), 0 },

  { rtBlockParameters, 861,
    rtModelParameters, 47 },

  { (NULL), 0 },

  { rtDataTypeMap, rtDimensionMap, rtFixPtMap,
    rtElementMap, rtSampleTimeMap, rtDimensionArray },
  "float",

  { 1224062672U,
    1508236378U,
    1221657549U,
    2978408611U },
  (NULL), 0,
  0
};

/* Function to get C API Model Mapping Static Info */
const rtwCAPI_ModelMappingStaticInfo*
  may23_GetCAPIStaticMap(void)
{
  return &mmiStatic;
}

/* Cache pointers into DataMapInfo substructure of RTModel */
#ifndef HOST_CAPI_BUILD

void may23_InitializeDataMapInfo(void)
{
  /* Set C-API version */
  rtwCAPI_SetVersion(may23_M->DataMapInfo.mmi, 1);

  /* Cache static C-API data into the Real-time Model Data structure */
  rtwCAPI_SetStaticMap(may23_M->DataMapInfo.mmi, &mmiStatic);

  /* Cache static C-API logging data into the Real-time Model Data structure */
  rtwCAPI_SetLoggingStaticMap(may23_M->DataMapInfo.mmi, (NULL));

  /* Cache C-API Data Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetDataAddressMap(may23_M->DataMapInfo.mmi, rtDataAddrMap);

  /* Cache C-API Data Run-Time Dimension Buffer Addresses into the Real-Time Model Data structure */
  rtwCAPI_SetVarDimsAddressMap(may23_M->DataMapInfo.mmi, rtVarDimsAddrMap);

  /* Cache C-API rtp Address and size  into the Real-Time Model Data structure */
  may23_M->DataMapInfo.mmi.InstanceMap.rtpAddress = rtmGetDefaultParam(may23_M);
  may23_M->DataMapInfo.mmi.staticMap->rtpSize = sizeof(P_may23_T);

  /* Cache the instance C-API logging pointer */
  rtwCAPI_SetInstanceLoggingInfo(may23_M->DataMapInfo.mmi, (NULL));

  /* Set reference to submodels */
  rtwCAPI_SetChildMMIArray(may23_M->DataMapInfo.mmi, (NULL));
  rtwCAPI_SetChildMMIArrayLen(may23_M->DataMapInfo.mmi, 0);
}

#else                                  /* HOST_CAPI_BUILD */
#ifdef __cplusplus

extern "C" {

#endif

  void may23_host_InitializeDataMapInfo(may23_host_DataMapInfo_T *dataMap, const
    char *path)
  {
    /* Set C-API version */
    rtwCAPI_SetVersion(dataMap->mmi, 1);

    /* Cache static C-API data into the Real-time Model Data structure */
    rtwCAPI_SetStaticMap(dataMap->mmi, &mmiStatic);

    /* host data address map is NULL */
    rtwCAPI_SetDataAddressMap(dataMap->mmi, NULL);

    /* host vardims address map is NULL */
    rtwCAPI_SetVarDimsAddressMap(dataMap->mmi, NULL);

    /* Set Instance specific path */
    rtwCAPI_SetPath(dataMap->mmi, path);
    rtwCAPI_SetFullPath(dataMap->mmi, NULL);

    /* Set reference to submodels */
    rtwCAPI_SetChildMMIArray(dataMap->mmi, (NULL));
    rtwCAPI_SetChildMMIArrayLen(dataMap->mmi, 0);
  }

#ifdef __cplusplus

}
#endif
#endif                                 /* HOST_CAPI_BUILD */

/* EOF: may23_capi.c */
