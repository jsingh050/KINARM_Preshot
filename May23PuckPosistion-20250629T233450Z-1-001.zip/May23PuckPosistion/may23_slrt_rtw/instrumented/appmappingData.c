#include "slrtappmapping.h"
#include "./maps/may23.map"



const AppMapInfo appInfo[] = 
{
	{ /* Idx 0, <may23> */
		{ /* SignalMapInfo */
			may23_BIOMAP,
			may23_LBLMAP,
			may23_SIDMAP,
			may23_SBIO,
			may23_SLBL,
			{0,90695},
			1445,
		},
		{ /* ParamMapInfo */
			may23_PTIDSMAP,
			may23_PTNAMESMAP,
			may23_SPTMAP,
			{0,907},
			908,
		},
		"may23",
		"",
		"may23",
		9,
		may23_dtmap,
	},
};
int getNumRef(void){
	 return(sizeof(appInfo) / sizeof(AppMapInfo));
}