#include "xpcdatatypes.h"

const serialfifoptr serialfifoground = { 0, 0, 0 };

const bcmsglist1553 bcmsg1553ground = { 0, 0, 0, 0 };

const bcstatus1553 bcstatground = { 0, 0, 0, 0, 0, 0 };

const bmmsglist1553 bmmsg1553ground = { 0, 0, 0, 0 };
