/*
 * Code generation for system system '<S30>/Force Sensor Control'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_ForceSensorControl.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/*
 * System initialize for atomic system:
 *    '<S252>/Create timestamp'
 *    '<S253>/Create timestamp'
 */
void may23_Createtimestamp_Init(DW_Createtimestamp_may23_T *localDW)
{
  localDW->start_time = 0U;
  localDW->last_time = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S252>/Create timestamp'
 *    '<S253>/Create timestamp'
 */
void may23_Createtimestamp(const uint32_T rtu_times_in[3],
  B_Createtimestamp_may23_T *localB, DW_Createtimestamp_may23_T *localDW)
{
  uint32_T q0;
  uint32_T qY;

  /* MATLAB Function 'DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Create timestamp': '<S255>:1' */
  if ((localDW->start_time == 0U) && (rtu_times_in[1] > 0U)) {
    /* '<S255>:1:14' */
    /* '<S255>:1:15' */
    localDW->start_time = rtu_times_in[1];
  }

  if (rtu_times_in[1] < localDW->start_time) {
    /* '<S255>:1:18' */
    /* '<S255>:1:19' */
    localDW->start_time = 0U;
  }

  /* '<S255>:1:26' */
  q0 = rtu_times_in[1];
  qY = q0 - localDW->start_time;
  if (qY > q0) {
    qY = 0U;
  }

  localB->timestamp_out = (real_T)qY / 7000.0;

  /* '<S255>:1:27' */
  localDW->last_time = rtu_times_in[1];
}

/* System initialize for atomic system: '<S30>/Force Sensor Control' */
void may23_ForceSensorControl_Init(void)
{
  /* InitializeConditions for UnitDelay: '<S256>/Delay Input1' */
  may23_DW.DelayInput1_DSTATE = may23_P.DetectChange_vinit;

  /* InitializeConditions for UnitDelay: '<S260>/Delay Input1' */
  may23_DW.DelayInput1_DSTATE_g = may23_P.DetectChange_vinit_k;

  /* SystemInitialize for MATLAB Function: '<S252>/Create timestamp' */
  may23_Createtimestamp_Init(&may23_DW.sf_Createtimestamp);

  /* SystemInitialize for MATLAB Function: '<S253>/Create timestamp' */
  may23_Createtimestamp_Init(&may23_DW.sf_Createtimestamp_o);
}

/* Start for atomic system: '<S30>/Force Sensor Control' */
void may23_ForceSensorControl_Start(void)
{
  /* Start for Enabled SubSystem: '<S252>/If Action Subsystem' */

  /* Start for S-Function (slrtUDPSend): '<S257>/Send' */
  /* Level2 S-Function Block: '<S257>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[19];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of Start for SubSystem: '<S252>/If Action Subsystem' */

  /* Start for S-Function (slrtUDPReceive): '<S252>/Receive from Robot 1 Force Sensor' */
  /* Level2 S-Function Block: '<S252>/Receive from Robot 1 Force Sensor' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[21];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for Enabled SubSystem: '<S253>/Data Transfer Start Subsystem' */

  /* Start for S-Function (slrtUDPSend): '<S259>/Send' */
  /* Level2 S-Function Block: '<S259>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[20];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of Start for SubSystem: '<S253>/Data Transfer Start Subsystem' */

  /* Start for S-Function (slrtUDPReceive): '<S253>/Receive from Robot 2 Force Sensor' */
  /* Level2 S-Function Block: '<S253>/Receive from Robot 2 Force Sensor' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[22];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }
}

/* Outputs for atomic system: '<S30>/Force Sensor Control' */
void may23_ForceSensorControl(void)
{
  int32_T i;

  /* UnitDelay: '<S256>/Delay Input1' */
  may23_B.Uk1 = may23_DW.DelayInput1_DSTATE;

  /* RelationalOperator: '<S256>/FixPt Relational Operator' */
  may23_B.FixPtRelationalOperator = (uint8_T)(may23_B.ReadHasFT[0] !=
    may23_B.Uk1);

  /* Outputs for Enabled SubSystem: '<S252>/If Action Subsystem' incorporates:
   *  EnablePort: '<S257>/Enable'
   */
  if (may23_B.FixPtRelationalOperator > 0) {
    /* S-Function (xpcreverseendian): '<S257>/Byte Reversal1' incorporates:
     *  Constant: '<S257>/Constant'
     */

    /* ReverseEndian: <S257>/Byte Reversal1 */

    /* 2 byte-wide input datatypes */
    ((uint16_T *)&may23_B.ByteReversal1_l)[0] =
      SWAP16(((uint16_T *)&may23_P.Constant_Value_l5)[0]);

    /* Switch: '<S257>/Switch' incorporates:
     *  Constant: '<S257>/Constant2'
     *  Constant: '<S257>/Constant3'
     */
    if (may23_B.ReadHasFT[0] > may23_P.Switch_Threshold) {
      may23_B.Switch_n = may23_P.Constant3_Value;
    } else {
      may23_B.Switch_n = may23_P.Constant2_Value_i;
    }

    /* End of Switch: '<S257>/Switch' */

    /* S-Function (xpcreverseendian): '<S257>/Byte Reversal' */

    /* ReverseEndian: <S257>/Byte Reversal */

    /* 2 byte-wide input datatypes */
    ((uint16_T *)&may23_B.ByteReversal_h)[0] =
      SWAP16(((uint16_T *)&may23_B.Switch_n)[0]);

    /* S-Function (xpcreverseendian): '<S257>/Byte Reversal2' incorporates:
     *  Constant: '<S257>/Constant1'
     */

    /* ReverseEndian: <S257>/Byte Reversal2 */

    /* 4 byte-wide input datatypes */
    ((uint32_T *)&may23_B.ByteReversal2)[0] =
      SWAP32(((uint32_T *)&may23_P.Constant1_Value_ov)[0]);

    /* S-Function (xpcbytepacking): '<S257>/Pack' */

    /* Byte Packing: <S257>/Pack */
    (void)memcpy((uint8_T*)&may23_B.Pack_b[0] + 0, (uint8_T*)
                 &may23_B.ByteReversal1_l, 2);
    (void)memcpy((uint8_T*)&may23_B.Pack_b[0] + 2, (uint8_T*)
                 &may23_B.ByteReversal_h, 2);
    (void)memcpy((uint8_T*)&may23_B.Pack_b[0] + 4, (uint8_T*)
                 &may23_B.ByteReversal2, 4);

    /* S-Function (slrtUDPSend): '<S257>/Send' */

    /* Level2 S-Function Block: '<S257>/Send' (slrtUDPSend) */
    {
      SimStruct *rts = may23_M->childSfunctions[19];
      sfcnOutputs(rts,1);
    }

    srUpdateBC(may23_DW.IfActionSubsystem_SubsysRanBC);
  }

  /* End of Outputs for SubSystem: '<S252>/If Action Subsystem' */

  /* S-Function (slrtUDPReceive): '<S252>/Receive from Robot 1 Force Sensor' */

  /* Level2 S-Function Block: '<S252>/Receive from Robot 1 Force Sensor' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[21];
    sfcnOutputs(rts,1);
  }

  /* S-Function (xpcbytepacking): '<S252>/Unpack' */

  /* Byte Unpacking: <S252>/Unpack */
  (void)memcpy((uint8_T*)&may23_B.Unpack_o1[0], (uint8_T*)
               &may23_B.ReceivefromRobot1ForceSensor_o1[0] + 0, 12);
  (void)memcpy((uint8_T*)&may23_B.Unpack_o2_h[0], (uint8_T*)
               &may23_B.ReceivefromRobot1ForceSensor_o1[0] + 12, 24);

  /* S-Function (xpcreverseendian): '<S252>/Byte Reversal' */

  /* ReverseEndian: <S252>/Byte Reversal */

  /* 4 byte-wide input datatypes */
  {
    int_T i1;
    const int32_T *u0 = &may23_B.Unpack_o2_h[0];
    int32_T *y0 = &may23_B.ByteReversal_m[0];
    for (i1=0; i1 < 6; i1++) {
      ((uint32_T *)&y0[i1])[0] =
        SWAP32(((uint32_T *)&u0[i1])[0]);
    }
  }

  /* S-Function (xpcreverseendian): '<S252>/Byte Reversal1' */

  /* ReverseEndian: <S252>/Byte Reversal1 */

  /* 4 byte-wide input datatypes */
  ((uint32_T *)&may23_B.ByteReversal1[0])[0] =
    SWAP32(((uint32_T *)&may23_B.Unpack_o1[0])[0]);
  ((uint32_T *)&may23_B.ByteReversal1[1])[0] =
    SWAP32(((uint32_T *)&may23_B.Unpack_o1[1])[0]);
  ((uint32_T *)&may23_B.ByteReversal1[2])[0] =
    SWAP32(((uint32_T *)&may23_B.Unpack_o1[2])[0]);

  /* MATLAB Function: '<S252>/Create timestamp' */
  may23_Createtimestamp(may23_B.ByteReversal1, &may23_B.sf_Createtimestamp,
                        &may23_DW.sf_Createtimestamp);

  /* Switch: '<S252>/Switch' incorporates:
   *  Constant: '<S252>/Constant'
   */
  if (may23_B.ReadHasFT[0] > may23_P.Switch_Threshold_f) {
    /* DataTypeConversion: '<S252>/Data Type Conversion' */
    for (i = 0; i < 6; i++) {
      may23_B.DataTypeConversion_e[i] = may23_B.ByteReversal_m[i];
    }

    /* End of DataTypeConversion: '<S252>/Data Type Conversion' */
    for (i = 0; i < 6; i++) {
      may23_B.Switch_m[i] = may23_B.DataTypeConversion_e[i];
    }

    may23_B.Switch_m[6] = may23_B.sf_Createtimestamp.timestamp_out;
  } else {
    for (i = 0; i < 7; i++) {
      may23_B.Switch_m[i] = may23_P.Constant_Value_a[i];
    }
  }

  /* End of Switch: '<S252>/Switch' */

  /* UnitDelay: '<S260>/Delay Input1' */
  may23_B.Uk1_o = may23_DW.DelayInput1_DSTATE_g;

  /* RelationalOperator: '<S260>/FixPt Relational Operator' */
  may23_B.FixPtRelationalOperator_n = (uint8_T)(may23_B.ReadHasFT[1] !=
    may23_B.Uk1_o);

  /* Outputs for Enabled SubSystem: '<S253>/Data Transfer Start Subsystem' incorporates:
   *  EnablePort: '<S259>/Enable'
   */
  if (may23_B.FixPtRelationalOperator_n > 0) {
    /* S-Function (xpcreverseendian): '<S259>/Byte Reversal1' incorporates:
     *  Constant: '<S259>/Constant'
     */

    /* ReverseEndian: <S259>/Byte Reversal1 */

    /* 2 byte-wide input datatypes */
    ((uint16_T *)&may23_B.ByteReversal1_h)[0] =
      SWAP16(((uint16_T *)&may23_P.Constant_Value_g)[0]);

    /* Switch: '<S259>/Switch' incorporates:
     *  Constant: '<S259>/Constant2'
     *  Constant: '<S259>/Constant3'
     */
    if (may23_B.ReadHasFT[1] > may23_P.Switch_Threshold_k) {
      may23_B.Switch_a = may23_P.Constant3_Value_k;
    } else {
      may23_B.Switch_a = may23_P.Constant2_Value_a;
    }

    /* End of Switch: '<S259>/Switch' */

    /* S-Function (xpcreverseendian): '<S259>/Byte Reversal2' */

    /* ReverseEndian: <S259>/Byte Reversal2 */

    /* 2 byte-wide input datatypes */
    ((uint16_T *)&may23_B.ByteReversal2_j)[0] =
      SWAP16(((uint16_T *)&may23_B.Switch_a)[0]);

    /* S-Function (xpcreverseendian): '<S259>/Byte Reversal' incorporates:
     *  Constant: '<S259>/Constant1'
     */

    /* ReverseEndian: <S259>/Byte Reversal */

    /* 4 byte-wide input datatypes */
    ((uint32_T *)&may23_B.ByteReversal)[0] =
      SWAP32(((uint32_T *)&may23_P.Constant1_Value_m)[0]);

    /* S-Function (xpcbytepacking): '<S259>/Pack' */

    /* Byte Packing: <S259>/Pack */
    (void)memcpy((uint8_T*)&may23_B.Pack[0] + 0, (uint8_T*)
                 &may23_B.ByteReversal1_h, 2);
    (void)memcpy((uint8_T*)&may23_B.Pack[0] + 2, (uint8_T*)
                 &may23_B.ByteReversal2_j, 2);
    (void)memcpy((uint8_T*)&may23_B.Pack[0] + 4, (uint8_T*)&may23_B.ByteReversal,
                 4);

    /* S-Function (slrtUDPSend): '<S259>/Send' */

    /* Level2 S-Function Block: '<S259>/Send' (slrtUDPSend) */
    {
      SimStruct *rts = may23_M->childSfunctions[20];
      sfcnOutputs(rts,1);
    }

    srUpdateBC(may23_DW.DataTransferStartSubsystem_SubsysRanBC);
  }

  /* End of Outputs for SubSystem: '<S253>/Data Transfer Start Subsystem' */

  /* S-Function (slrtUDPReceive): '<S253>/Receive from Robot 2 Force Sensor' */

  /* Level2 S-Function Block: '<S253>/Receive from Robot 2 Force Sensor' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[22];
    sfcnOutputs(rts,1);
  }

  /* S-Function (xpcbytepacking): '<S253>/Unpack1' */

  /* Byte Unpacking: <S253>/Unpack1 */
  (void)memcpy((uint8_T*)&may23_B.Unpack1_o1[0], (uint8_T*)
               &may23_B.ReceivefromRobot2ForceSensor_o1[0] + 0, 12);
  (void)memcpy((uint8_T*)&may23_B.Unpack1_o2[0], (uint8_T*)
               &may23_B.ReceivefromRobot2ForceSensor_o1[0] + 12, 24);

  /* S-Function (xpcreverseendian): '<S253>/Byte Reversal' */

  /* ReverseEndian: <S253>/Byte Reversal */

  /* 4 byte-wide input datatypes */
  {
    int_T i1;
    const int32_T *u0 = &may23_B.Unpack1_o2[0];
    int32_T *y0 = &may23_B.ByteReversal_c[0];
    for (i1=0; i1 < 6; i1++) {
      ((uint32_T *)&y0[i1])[0] =
        SWAP32(((uint32_T *)&u0[i1])[0]);
    }
  }

  /* S-Function (xpcreverseendian): '<S253>/Byte Reversal1' */

  /* ReverseEndian: <S253>/Byte Reversal1 */

  /* 4 byte-wide input datatypes */
  ((uint32_T *)&may23_B.ByteReversal1_f[0])[0] =
    SWAP32(((uint32_T *)&may23_B.Unpack1_o1[0])[0]);
  ((uint32_T *)&may23_B.ByteReversal1_f[1])[0] =
    SWAP32(((uint32_T *)&may23_B.Unpack1_o1[1])[0]);
  ((uint32_T *)&may23_B.ByteReversal1_f[2])[0] =
    SWAP32(((uint32_T *)&may23_B.Unpack1_o1[2])[0]);

  /* MATLAB Function: '<S253>/Create timestamp' */
  may23_Createtimestamp(may23_B.ByteReversal1_f, &may23_B.sf_Createtimestamp_o,
                        &may23_DW.sf_Createtimestamp_o);

  /* Switch: '<S253>/Switch1' incorporates:
   *  Constant: '<S253>/Constant1'
   */
  if (may23_B.ReadHasFT[1] > may23_P.Switch1_Threshold) {
    /* DataTypeConversion: '<S253>/Data Type Conversion1' */
    for (i = 0; i < 6; i++) {
      may23_B.DataTypeConversion1_o[i] = may23_B.ByteReversal_c[i];
    }

    /* End of DataTypeConversion: '<S253>/Data Type Conversion1' */
    for (i = 0; i < 6; i++) {
      may23_B.Switch1_g[i] = may23_B.DataTypeConversion1_o[i];
    }

    may23_B.Switch1_g[6] = may23_B.sf_Createtimestamp_o.timestamp_out;
  } else {
    for (i = 0; i < 7; i++) {
      may23_B.Switch1_g[i] = may23_P.Constant1_Value_k[i];
    }
  }

  /* End of Switch: '<S253>/Switch1' */
  for (i = 0; i < 7; i++) {
    /* SignalConversion generated from: '<S254>/ SFunction ' incorporates:
     *  MATLAB Function: '<S67>/MATLAB Function'
     */
    may23_B.TmpSignalConversionAtSFunctionInport1_a[i] = may23_B.Switch_m[i];
    may23_B.TmpSignalConversionAtSFunctionInport1_a[i + 7] = may23_B.Switch1_g[i];
  }

  /* SignalConversion generated from: '<S254>/ SFunction ' incorporates:
   *  MATLAB Function: '<S67>/MATLAB Function'
   */
  may23_B.TmpSignalConversionAtSFunctionInport2_f[0] = may23_B.ByteReversal1[2];
  may23_B.TmpSignalConversionAtSFunctionInport2_f[1] = may23_B.ByteReversal1_f[2];

  /* MATLAB Function: '<S67>/MATLAB Function' */
  /* MATLAB Function 'DataLogging/Poll KINARM/Force Sensor Control/MATLAB Function': '<S254>:1' */
  /* '<S254>:1:4' */
  memcpy(&may23_B.measures_out[0],
         &may23_B.TmpSignalConversionAtSFunctionInport1_a[0], 14U * sizeof
         (real_T));

  /* '<S254>:1:5' */
  may23_B.status_out[0] = may23_B.TmpSignalConversionAtSFunctionInport2_f[0];
  may23_B.status_out[1] = may23_B.TmpSignalConversionAtSFunctionInport2_f[1];
  if (may23_B.ReadHasFT[2] > 0.0) {
    /* '<S254>:1:7' */
    /* '<S254>:1:8' */
    for (i = 0; i < 7; i++) {
      may23_B.measures_out[i] =
        may23_B.TmpSignalConversionAtSFunctionInport1_a[i + 7];
    }

    /* '<S254>:1:9' */
    for (i = 0; i < 7; i++) {
      may23_B.measures_out[i + 7] =
        may23_B.TmpSignalConversionAtSFunctionInport1_a[i];
    }

    /* '<S254>:1:10' */
    may23_B.status_out[0] = may23_B.TmpSignalConversionAtSFunctionInport2_f[1];

    /* '<S254>:1:11' */
    may23_B.status_out[1] = may23_B.TmpSignalConversionAtSFunctionInport2_f[0];
  }
}

/* Update for atomic system: '<S30>/Force Sensor Control' */
void may23_ForceSensorControl_Update(void)
{
  /* Update for UnitDelay: '<S256>/Delay Input1' */
  may23_DW.DelayInput1_DSTATE = may23_B.ReadHasFT[0];

  /* Update for UnitDelay: '<S260>/Delay Input1' */
  may23_DW.DelayInput1_DSTATE_g = may23_B.ReadHasFT[1];
}

/* Termination for atomic system: '<S30>/Force Sensor Control' */
void may23_ForceSensorControl_Term(void)
{
  /* Terminate for Enabled SubSystem: '<S252>/If Action Subsystem' */

  /* Terminate for S-Function (slrtUDPSend): '<S257>/Send' */
  /* Level2 S-Function Block: '<S257>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[19];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S252>/If Action Subsystem' */

  /* Terminate for S-Function (slrtUDPReceive): '<S252>/Receive from Robot 1 Force Sensor' */
  /* Level2 S-Function Block: '<S252>/Receive from Robot 1 Force Sensor' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[21];
    sfcnTerminate(rts);
  }

  /* Terminate for Enabled SubSystem: '<S253>/Data Transfer Start Subsystem' */

  /* Terminate for S-Function (slrtUDPSend): '<S259>/Send' */
  /* Level2 S-Function Block: '<S259>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[20];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S253>/Data Transfer Start Subsystem' */

  /* Terminate for S-Function (slrtUDPReceive): '<S253>/Receive from Robot 2 Force Sensor' */
  /* Level2 S-Function Block: '<S253>/Receive from Robot 2 Force Sensor' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[22];
    sfcnTerminate(rts);
  }
}
