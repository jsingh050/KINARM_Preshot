/*
 * Code generation for system system '<S405>/FeedFwdArm'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_FeedFwdArm.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/* Output and update for atomic system: '<S405>/FeedFwdArm' */
void may23_FeedFwdArm(void)
{
  real_T feedback_status;
  int32_T i;

  /* Constant: '<S405>/block_settings' */
  /* MATLAB Function 'subsystem for moving the square (updating velocity and checking collision)/Hand Feedback/Hand_Feedback/FeedFwdArm': '<S407>:1' */
  /* '<S407>:1:47' */
  /* '<S407>:1:33' */
  /* '<S407>:1:34' */
  /* '<S407>:1:35' */
  /* '<S407>:1:36' */
  if ((may23_B.kinarm_data[11] == 0.0) &&
      (may23_P.Hand_Feedback_feedback_cntl_src == 3.0)) {
    /* '<S407>:1:43' */
    /* '<S407>:1:44' */
    memcpy(&may23_B.VCODES_out[0], &may23_B.MatrixConcatenation[0], 140U *
           sizeof(real_T));
  } else {
    /* '<S407>:1:46' */
    for (i = 0; i < 140; i++) {
      may23_B.VCODES_out[i] = 0.0;
    }

    /* '<S407>:1:47' */
    may23_B.VCODES_out[0] = 1.0;
    may23_B.VCODES_out[1] = 1.0;

    /* '<S407>:1:48' */
    may23_B.VCODES_out[8] = may23_B.kinarm_data[14];
    may23_B.VCODES_out[9] = may23_B.kinarm_data[14];

    /* '<S407>:1:49' */
    may23_B.VCODES_out[10] = may23_B.kinarm_data[14];
    may23_B.VCODES_out[11] = may23_B.kinarm_data[14];

    /* '<S407>:1:50' */
    may23_B.VCODES_out[12] = 0.0;
    may23_B.VCODES_out[13] = 0.0;

    /* '<S407>:1:51' */
    may23_B.VCODES_out[16] = 100.0;
    may23_B.VCODES_out[17] = 100.0;

    /* '<S407>:1:52' */
    may23_B.VCODES_out[18] = may23_B.kinarm_data[17];
    may23_B.VCODES_out[19] = may23_B.kinarm_data[17];
  }

  if (may23_B.kinarm_data[8] == 4.0) {
    /* Constant: '<S405>/block_settings' */
    /* '<S407>:1:60' */
    if (may23_P.Hand_Feedback_feedback_cntl_src == 2.0) {
      /* Constant: '<S405>/feedback_status' */
      /* '<S407>:1:61' */
      /* '<S407>:1:62' */
      feedback_status = may23_P.feedback_status_Value;
    } else if (may23_P.Hand_Feedback_feedback_cntl_src == 3.0) {
      /* '<S407>:1:63' */
      /* '<S407>:1:64' */
      feedback_status = 4.0;
    } else {
      /* '<S407>:1:66' */
      feedback_status = 3.0;
    }
  } else {
    /* '<S407>:1:69' */
    feedback_status = may23_B.kinarm_data[8];
  }

  switch ((int32_T)feedback_status) {
   case 0:
    /* '<S407>:1:75' */
    may23_B.VCODES_out[2] = 0.0;

    /* '<S407>:1:76' */
    may23_B.VCODES_out[3] = 0.0;
    break;

   case 1:
    /* '<S407>:1:78' */
    may23_B.VCODES_out[2] = 1.0;

    /* '<S407>:1:79' */
    may23_B.VCODES_out[3] = 0.0;
    break;

   case 2:
    /* '<S407>:1:81' */
    may23_B.VCODES_out[2] = 0.0;

    /* '<S407>:1:82' */
    may23_B.VCODES_out[3] = 1.0;
    break;

   case 4:
    break;

   default:
    /* '<S407>:1:86' */
    may23_B.VCODES_out[2] = 1.0;

    /* '<S407>:1:87' */
    may23_B.VCODES_out[3] = 1.0;
    break;
  }

  /* '<S407>:1:92' */
  /* '<S407>:1:93' */
  /* '<S407>:1:94' */
  feedback_status = may23_B.kinarm_data[2];

  /* '<S407>:1:98' */
  /* '<S407>:1:99' */
  /* '<S407>:1:108' */
  may23_B.VCODES_out[4] = may23_B.kinarm_data[(int32_T)feedback_status + 65];

  /* '<S407>:1:109' */
  may23_B.VCODES_out[6] = may23_B.kinarm_data[(int32_T)feedback_status + 68];

  /* '<S407>:1:92' */
  /* '<S407>:1:96' */
  feedback_status = 3.0 - may23_B.kinarm_data[2];

  /* '<S407>:1:98' */
  /* '<S407>:1:99' */
  /* '<S407>:1:108' */
  may23_B.VCODES_out[5] = may23_B.kinarm_data[(int32_T)feedback_status + 65];

  /* '<S407>:1:109' */
  may23_B.VCODES_out[7] = may23_B.kinarm_data[(int32_T)feedback_status + 68];

  /* '<S407>:1:112' */
}
