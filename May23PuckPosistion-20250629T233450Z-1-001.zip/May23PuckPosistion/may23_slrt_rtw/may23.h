/*
 * may23.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "may23".
 *
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_may23_h_
#define RTW_HEADER_may23_h_
#include <stddef.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
#include "rtw_modelmap.h"
#ifndef may23_COMMON_INCLUDES_
# define may23_COMMON_INCLUDES_
#include <stdio.h>
#include <string.h>
#include <xpcimports.h>
#include <xpcdatatypes.h>
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rt_logging.h"
#include "xpcimports.h"
#include "stddef.h"
#include "stdlib.h"
#include "xpcethercatutils.h"
#include "xpctarget.h"
#include "BKINethercat.h"
#endif                                 /* may23_COMMON_INCLUDES_ */

#include "may23_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Child system includes */
#include "may23_EmbeddedMATLABInsideTarget.h"
#include "may23_EmbeddedMATLABInsideTarget_b.h"
#include "may23_EmbeddedMATLABInsideTarget_d.h"
#include "may23_EmbeddedMATLABInsideTarget_m.h"
#include "may23_FeedFwdArm.h"
#include "may23_Keepalive.h"
#include "may23_NetworkTransferSubsystem.h"
#include "may23_PVC_core.h"
#include "may23_PollForcePlates.h"
#include "may23_PollKINARM.h"
#include "may23_Receive_Gaze.h"
#include "may23_applyloads.h"
#include "rt_zcfcn.h"
#include "rtGetNaN.h"
#include "rt_nonfinite.h"
#include "rt_defines.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetBlockIO
# define rtmGetBlockIO(rtm)            ((rtm)->blockIO)
#endif

#ifndef rtmSetBlockIO
# define rtmSetBlockIO(rtm, val)       ((rtm)->blockIO = (val))
#endif

#ifndef rtmGetChecksums
# define rtmGetChecksums(rtm)          ((rtm)->Sizes.checksums)
#endif

#ifndef rtmSetChecksums
# define rtmSetChecksums(rtm, val)     ((rtm)->Sizes.checksums = (val))
#endif

#ifndef rtmGetConstBlockIO
# define rtmGetConstBlockIO(rtm)       ((rtm)->constBlockIO)
#endif

#ifndef rtmSetConstBlockIO
# define rtmSetConstBlockIO(rtm, val)  ((rtm)->constBlockIO = (val))
#endif

#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm)  ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm)         ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val)    ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetCtrlRateMdlRefTiming
# define rtmGetCtrlRateMdlRefTiming(rtm) ()
#endif

#ifndef rtmSetCtrlRateMdlRefTiming
# define rtmSetCtrlRateMdlRefTiming(rtm, val) ()
#endif

#ifndef rtmGetCtrlRateMdlRefTimingPtr
# define rtmGetCtrlRateMdlRefTimingPtr(rtm) ()
#endif

#ifndef rtmSetCtrlRateMdlRefTimingPtr
# define rtmSetCtrlRateMdlRefTimingPtr(rtm, val) ()
#endif

#ifndef rtmGetCtrlRateNumTicksToNextHit
# define rtmGetCtrlRateNumTicksToNextHit(rtm) ()
#endif

#ifndef rtmSetCtrlRateNumTicksToNextHit
# define rtmSetCtrlRateNumTicksToNextHit(rtm, val) ()
#endif

#ifndef rtmGetDataMapInfo
# define rtmGetDataMapInfo(rtm)        ((rtm)->DataMapInfo)
#endif

#ifndef rtmSetDataMapInfo
# define rtmSetDataMapInfo(rtm, val)   ((rtm)->DataMapInfo = (val))
#endif

#ifndef rtmGetDefaultParam
# define rtmGetDefaultParam(rtm)       ((rtm)->defaultParam)
#endif

#ifndef rtmSetDefaultParam
# define rtmSetDefaultParam(rtm, val)  ((rtm)->defaultParam = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetDirectFeedThrough
# define rtmGetDirectFeedThrough(rtm)  ((rtm)->Sizes.sysDirFeedThru)
#endif

#ifndef rtmSetDirectFeedThrough
# define rtmSetDirectFeedThrough(rtm, val) ((rtm)->Sizes.sysDirFeedThru = (val))
#endif

#ifndef rtmGetErrorStatusFlag
# define rtmGetErrorStatusFlag(rtm)    ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatusFlag
# define rtmSetErrorStatusFlag(rtm, val) ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetFinalTime
# define rtmGetFinalTime(rtm)          ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetFinalTime
# define rtmSetFinalTime(rtm, val)     ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetFirstInitCondFlag
# define rtmGetFirstInitCondFlag(rtm)  ()
#endif

#ifndef rtmSetFirstInitCondFlag
# define rtmSetFirstInitCondFlag(rtm, val) ()
#endif

#ifndef rtmGetIntgData
# define rtmGetIntgData(rtm)           ()
#endif

#ifndef rtmSetIntgData
# define rtmSetIntgData(rtm, val)      ()
#endif

#ifndef rtmGetMdlRefGlobalTID
# define rtmGetMdlRefGlobalTID(rtm)    ()
#endif

#ifndef rtmSetMdlRefGlobalTID
# define rtmSetMdlRefGlobalTID(rtm, val) ()
#endif

#ifndef rtmGetMdlRefTriggerTID
# define rtmGetMdlRefTriggerTID(rtm)   ()
#endif

#ifndef rtmSetMdlRefTriggerTID
# define rtmSetMdlRefTriggerTID(rtm, val) ()
#endif

#ifndef rtmGetModelMappingInfo
# define rtmGetModelMappingInfo(rtm)   ((rtm)->SpecialInfo.mappingInfo)
#endif

#ifndef rtmSetModelMappingInfo
# define rtmSetModelMappingInfo(rtm, val) ((rtm)->SpecialInfo.mappingInfo = (val))
#endif

#ifndef rtmGetModelName
# define rtmGetModelName(rtm)          ((rtm)->modelName)
#endif

#ifndef rtmSetModelName
# define rtmSetModelName(rtm, val)     ((rtm)->modelName = (val))
#endif

#ifndef rtmGetNonInlinedSFcns
# define rtmGetNonInlinedSFcns(rtm)    ((rtm)->NonInlinedSFcns)
#endif

#ifndef rtmSetNonInlinedSFcns
# define rtmSetNonInlinedSFcns(rtm, val) ((rtm)->NonInlinedSFcns = (val))
#endif

#ifndef rtmGetNumBlockIO
# define rtmGetNumBlockIO(rtm)         ((rtm)->Sizes.numBlockIO)
#endif

#ifndef rtmSetNumBlockIO
# define rtmSetNumBlockIO(rtm, val)    ((rtm)->Sizes.numBlockIO = (val))
#endif

#ifndef rtmGetNumBlockParams
# define rtmGetNumBlockParams(rtm)     ((rtm)->Sizes.numBlockPrms)
#endif

#ifndef rtmSetNumBlockParams
# define rtmSetNumBlockParams(rtm, val) ((rtm)->Sizes.numBlockPrms = (val))
#endif

#ifndef rtmGetNumBlocks
# define rtmGetNumBlocks(rtm)          ((rtm)->Sizes.numBlocks)
#endif

#ifndef rtmSetNumBlocks
# define rtmSetNumBlocks(rtm, val)     ((rtm)->Sizes.numBlocks = (val))
#endif

#ifndef rtmGetNumContStates
# define rtmGetNumContStates(rtm)      ((rtm)->Sizes.numContStates)
#endif

#ifndef rtmSetNumContStates
# define rtmSetNumContStates(rtm, val) ((rtm)->Sizes.numContStates = (val))
#endif

#ifndef rtmGetNumDWork
# define rtmGetNumDWork(rtm)           ((rtm)->Sizes.numDwork)
#endif

#ifndef rtmSetNumDWork
# define rtmSetNumDWork(rtm, val)      ((rtm)->Sizes.numDwork = (val))
#endif

#ifndef rtmGetNumInputPorts
# define rtmGetNumInputPorts(rtm)      ((rtm)->Sizes.numIports)
#endif

#ifndef rtmSetNumInputPorts
# define rtmSetNumInputPorts(rtm, val) ((rtm)->Sizes.numIports = (val))
#endif

#ifndef rtmGetNumNonSampledZCs
# define rtmGetNumNonSampledZCs(rtm)   ((rtm)->Sizes.numNonSampZCs)
#endif

#ifndef rtmSetNumNonSampledZCs
# define rtmSetNumNonSampledZCs(rtm, val) ((rtm)->Sizes.numNonSampZCs = (val))
#endif

#ifndef rtmGetNumOutputPorts
# define rtmGetNumOutputPorts(rtm)     ((rtm)->Sizes.numOports)
#endif

#ifndef rtmSetNumOutputPorts
# define rtmSetNumOutputPorts(rtm, val) ((rtm)->Sizes.numOports = (val))
#endif

#ifndef rtmGetNumPeriodicContStates
# define rtmGetNumPeriodicContStates(rtm) ((rtm)->Sizes.numPeriodicContStates)
#endif

#ifndef rtmSetNumPeriodicContStates
# define rtmSetNumPeriodicContStates(rtm, val) ((rtm)->Sizes.numPeriodicContStates = (val))
#endif

#ifndef rtmGetNumSFcnParams
# define rtmGetNumSFcnParams(rtm)      ((rtm)->Sizes.numSFcnPrms)
#endif

#ifndef rtmSetNumSFcnParams
# define rtmSetNumSFcnParams(rtm, val) ((rtm)->Sizes.numSFcnPrms = (val))
#endif

#ifndef rtmGetNumSFunctions
# define rtmGetNumSFunctions(rtm)      ((rtm)->Sizes.numSFcns)
#endif

#ifndef rtmSetNumSFunctions
# define rtmSetNumSFunctions(rtm, val) ((rtm)->Sizes.numSFcns = (val))
#endif

#ifndef rtmGetNumSampleTimes
# define rtmGetNumSampleTimes(rtm)     ((rtm)->Sizes.numSampTimes)
#endif

#ifndef rtmSetNumSampleTimes
# define rtmSetNumSampleTimes(rtm, val) ((rtm)->Sizes.numSampTimes = (val))
#endif

#ifndef rtmGetNumU
# define rtmGetNumU(rtm)               ((rtm)->Sizes.numU)
#endif

#ifndef rtmSetNumU
# define rtmSetNumU(rtm, val)          ((rtm)->Sizes.numU = (val))
#endif

#ifndef rtmGetNumY
# define rtmGetNumY(rtm)               ((rtm)->Sizes.numY)
#endif

#ifndef rtmSetNumY
# define rtmSetNumY(rtm, val)          ((rtm)->Sizes.numY = (val))
#endif

#ifndef rtmGetOdeF
# define rtmGetOdeF(rtm)               ()
#endif

#ifndef rtmSetOdeF
# define rtmSetOdeF(rtm, val)          ()
#endif

#ifndef rtmGetOdeY
# define rtmGetOdeY(rtm)               ()
#endif

#ifndef rtmSetOdeY
# define rtmSetOdeY(rtm, val)          ()
#endif

#ifndef rtmGetOffsetTimeArray
# define rtmGetOffsetTimeArray(rtm)    ((rtm)->Timing.offsetTimesArray)
#endif

#ifndef rtmSetOffsetTimeArray
# define rtmSetOffsetTimeArray(rtm, val) ((rtm)->Timing.offsetTimesArray = (val))
#endif

#ifndef rtmGetOffsetTimePtr
# define rtmGetOffsetTimePtr(rtm)      ((rtm)->Timing.offsetTimes)
#endif

#ifndef rtmSetOffsetTimePtr
# define rtmSetOffsetTimePtr(rtm, val) ((rtm)->Timing.offsetTimes = (val))
#endif

#ifndef rtmGetOptions
# define rtmGetOptions(rtm)            ((rtm)->Sizes.options)
#endif

#ifndef rtmSetOptions
# define rtmSetOptions(rtm, val)       ((rtm)->Sizes.options = (val))
#endif

#ifndef rtmGetParamIsMalloced
# define rtmGetParamIsMalloced(rtm)    ()
#endif

#ifndef rtmSetParamIsMalloced
# define rtmSetParamIsMalloced(rtm, val) ()
#endif

#ifndef rtmGetPath
# define rtmGetPath(rtm)               ((rtm)->path)
#endif

#ifndef rtmSetPath
# define rtmSetPath(rtm, val)          ((rtm)->path = (val))
#endif

#ifndef rtmGetPerTaskSampleHits
# define rtmGetPerTaskSampleHits(rtm)  ((rtm)->Timing.RateInteraction)
#endif

#ifndef rtmSetPerTaskSampleHits
# define rtmSetPerTaskSampleHits(rtm, val) ((rtm)->Timing.RateInteraction = (val))
#endif

#ifndef rtmGetPerTaskSampleHitsArray
# define rtmGetPerTaskSampleHitsArray(rtm) ((rtm)->Timing.perTaskSampleHitsArray)
#endif

#ifndef rtmSetPerTaskSampleHitsArray
# define rtmSetPerTaskSampleHitsArray(rtm, val) ((rtm)->Timing.perTaskSampleHitsArray = (val))
#endif

#ifndef rtmGetPerTaskSampleHitsPtr
# define rtmGetPerTaskSampleHitsPtr(rtm) ((rtm)->Timing.perTaskSampleHits)
#endif

#ifndef rtmSetPerTaskSampleHitsPtr
# define rtmSetPerTaskSampleHitsPtr(rtm, val) ((rtm)->Timing.perTaskSampleHits = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
# define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
# define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
# define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
# define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetPrevZCSigState
# define rtmGetPrevZCSigState(rtm)     ((rtm)->prevZCSigState)
#endif

#ifndef rtmSetPrevZCSigState
# define rtmSetPrevZCSigState(rtm, val) ((rtm)->prevZCSigState = (val))
#endif

#ifndef rtmGetRTWExtModeInfo
# define rtmGetRTWExtModeInfo(rtm)     ((rtm)->extModeInfo)
#endif

#ifndef rtmSetRTWExtModeInfo
# define rtmSetRTWExtModeInfo(rtm, val) ((rtm)->extModeInfo = (val))
#endif

#ifndef rtmGetRTWGeneratedSFcn
# define rtmGetRTWGeneratedSFcn(rtm)   ((rtm)->Sizes.rtwGenSfcn)
#endif

#ifndef rtmSetRTWGeneratedSFcn
# define rtmSetRTWGeneratedSFcn(rtm, val) ((rtm)->Sizes.rtwGenSfcn = (val))
#endif

#ifndef rtmGetRTWLogInfo
# define rtmGetRTWLogInfo(rtm)         ((rtm)->rtwLogInfo)
#endif

#ifndef rtmSetRTWLogInfo
# define rtmSetRTWLogInfo(rtm, val)    ((rtm)->rtwLogInfo = (val))
#endif

#ifndef rtmGetRTWRTModelMethodsInfo
# define rtmGetRTWRTModelMethodsInfo(rtm) ()
#endif

#ifndef rtmSetRTWRTModelMethodsInfo
# define rtmSetRTWRTModelMethodsInfo(rtm, val) ()
#endif

#ifndef rtmGetRTWSfcnInfo
# define rtmGetRTWSfcnInfo(rtm)        ((rtm)->sfcnInfo)
#endif

#ifndef rtmSetRTWSfcnInfo
# define rtmSetRTWSfcnInfo(rtm, val)   ((rtm)->sfcnInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfo
# define rtmGetRTWSolverInfo(rtm)      ((rtm)->solverInfo)
#endif

#ifndef rtmSetRTWSolverInfo
# define rtmSetRTWSolverInfo(rtm, val) ((rtm)->solverInfo = (val))
#endif

#ifndef rtmGetRTWSolverInfoPtr
# define rtmGetRTWSolverInfoPtr(rtm)   ((rtm)->solverInfoPtr)
#endif

#ifndef rtmSetRTWSolverInfoPtr
# define rtmSetRTWSolverInfoPtr(rtm, val) ((rtm)->solverInfoPtr = (val))
#endif

#ifndef rtmGetReservedForXPC
# define rtmGetReservedForXPC(rtm)     ((rtm)->SpecialInfo.xpcData)
#endif

#ifndef rtmSetReservedForXPC
# define rtmSetReservedForXPC(rtm, val) ((rtm)->SpecialInfo.xpcData = (val))
#endif

#ifndef rtmGetRootDWork
# define rtmGetRootDWork(rtm)          ((rtm)->dwork)
#endif

#ifndef rtmSetRootDWork
# define rtmSetRootDWork(rtm, val)     ((rtm)->dwork = (val))
#endif

#ifndef rtmGetSFunctions
# define rtmGetSFunctions(rtm)         ((rtm)->childSfunctions)
#endif

#ifndef rtmSetSFunctions
# define rtmSetSFunctions(rtm, val)    ((rtm)->childSfunctions = (val))
#endif

#ifndef rtmGetSampleHitArray
# define rtmGetSampleHitArray(rtm)     ((rtm)->Timing.sampleHitArray)
#endif

#ifndef rtmSetSampleHitArray
# define rtmSetSampleHitArray(rtm, val) ((rtm)->Timing.sampleHitArray = (val))
#endif

#ifndef rtmGetSampleHitPtr
# define rtmGetSampleHitPtr(rtm)       ((rtm)->Timing.sampleHits)
#endif

#ifndef rtmSetSampleHitPtr
# define rtmSetSampleHitPtr(rtm, val)  ((rtm)->Timing.sampleHits = (val))
#endif

#ifndef rtmGetSampleTimeArray
# define rtmGetSampleTimeArray(rtm)    ((rtm)->Timing.sampleTimesArray)
#endif

#ifndef rtmSetSampleTimeArray
# define rtmSetSampleTimeArray(rtm, val) ((rtm)->Timing.sampleTimesArray = (val))
#endif

#ifndef rtmGetSampleTimePtr
# define rtmGetSampleTimePtr(rtm)      ((rtm)->Timing.sampleTimes)
#endif

#ifndef rtmSetSampleTimePtr
# define rtmSetSampleTimePtr(rtm, val) ((rtm)->Timing.sampleTimes = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDArray
# define rtmGetSampleTimeTaskIDArray(rtm) ((rtm)->Timing.sampleTimeTaskIDArray)
#endif

#ifndef rtmSetSampleTimeTaskIDArray
# define rtmSetSampleTimeTaskIDArray(rtm, val) ((rtm)->Timing.sampleTimeTaskIDArray = (val))
#endif

#ifndef rtmGetSampleTimeTaskIDPtr
# define rtmGetSampleTimeTaskIDPtr(rtm) ((rtm)->Timing.sampleTimeTaskIDPtr)
#endif

#ifndef rtmSetSampleTimeTaskIDPtr
# define rtmSetSampleTimeTaskIDPtr(rtm, val) ((rtm)->Timing.sampleTimeTaskIDPtr = (val))
#endif

#ifndef rtmGetSelf
# define rtmGetSelf(rtm)               ()
#endif

#ifndef rtmSetSelf
# define rtmSetSelf(rtm, val)          ()
#endif

#ifndef rtmGetSimMode
# define rtmGetSimMode(rtm)            ((rtm)->simMode)
#endif

#ifndef rtmSetSimMode
# define rtmSetSimMode(rtm, val)       ((rtm)->simMode = (val))
#endif

#ifndef rtmGetSimTimeStep
# define rtmGetSimTimeStep(rtm)        ((rtm)->Timing.simTimeStep)
#endif

#ifndef rtmSetSimTimeStep
# define rtmSetSimTimeStep(rtm, val)   ((rtm)->Timing.simTimeStep = (val))
#endif

#ifndef rtmGetStartTime
# define rtmGetStartTime(rtm)          ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetStartTime
# define rtmSetStartTime(rtm, val)     ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmGetStepSize
# define rtmGetStepSize(rtm)           ((rtm)->Timing.stepSize)
#endif

#ifndef rtmSetStepSize
# define rtmSetStepSize(rtm, val)      ((rtm)->Timing.stepSize = (val))
#endif

#ifndef rtmGetStopRequestedFlag
# define rtmGetStopRequestedFlag(rtm)  ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequestedFlag
# define rtmSetStopRequestedFlag(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetTaskCounters
# define rtmGetTaskCounters(rtm)       ((rtm)->Timing.TaskCounters)
#endif

#ifndef rtmSetTaskCounters
# define rtmSetTaskCounters(rtm, val)  ((rtm)->Timing.TaskCounters = (val))
#endif

#ifndef rtmGetTaskTimeArray
# define rtmGetTaskTimeArray(rtm)      ((rtm)->Timing.tArray)
#endif

#ifndef rtmSetTaskTimeArray
# define rtmSetTaskTimeArray(rtm, val) ((rtm)->Timing.tArray = (val))
#endif

#ifndef rtmGetTimePtr
# define rtmGetTimePtr(rtm)            ((rtm)->Timing.t)
#endif

#ifndef rtmSetTimePtr
# define rtmSetTimePtr(rtm, val)       ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTimingData
# define rtmGetTimingData(rtm)         ((rtm)->Timing.timingData)
#endif

#ifndef rtmSetTimingData
# define rtmSetTimingData(rtm, val)    ((rtm)->Timing.timingData = (val))
#endif

#ifndef rtmGetU
# define rtmGetU(rtm)                  ((rtm)->inputs)
#endif

#ifndef rtmSetU
# define rtmSetU(rtm, val)             ((rtm)->inputs = (val))
#endif

#ifndef rtmGetVarNextHitTimesListPtr
# define rtmGetVarNextHitTimesListPtr(rtm) ((rtm)->Timing.varNextHitTimesList)
#endif

#ifndef rtmSetVarNextHitTimesListPtr
# define rtmSetVarNextHitTimesListPtr(rtm, val) ((rtm)->Timing.varNextHitTimesList = (val))
#endif

#ifndef rtmGetY
# define rtmGetY(rtm)                  ((rtm)->outputs)
#endif

#ifndef rtmSetY
# define rtmSetY(rtm, val)             ((rtm)->outputs = (val))
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm)  ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetZCSignalValues
# define rtmGetZCSignalValues(rtm)     ((rtm)->zcSignalValues)
#endif

#ifndef rtmSetZCSignalValues
# define rtmSetZCSignalValues(rtm, val) ((rtm)->zcSignalValues = (val))
#endif

#ifndef rtmGet_TimeOfLastOutput
# define rtmGet_TimeOfLastOutput(rtm)  ((rtm)->Timing.timeOfLastOutput)
#endif

#ifndef rtmSet_TimeOfLastOutput
# define rtmSet_TimeOfLastOutput(rtm, val) ((rtm)->Timing.timeOfLastOutput = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm)                 ((rtm)->derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val)            ((rtm)->derivs = (val))
#endif

#ifndef rtmGettimingBridge
# define rtmGettimingBridge(rtm)       ()
#endif

#ifndef rtmSettimingBridge
# define rtmSettimingBridge(rtm, val)  ()
#endif

#ifndef rtmGetChecksumVal
# define rtmGetChecksumVal(rtm, idx)   ((rtm)->Sizes.checksums[idx])
#endif

#ifndef rtmSetChecksumVal
# define rtmSetChecksumVal(rtm, idx, val) ((rtm)->Sizes.checksums[idx] = (val))
#endif

#ifndef rtmGetDWork
# define rtmGetDWork(rtm, idx)         ((rtm)->dwork[idx])
#endif

#ifndef rtmSetDWork
# define rtmSetDWork(rtm, idx, val)    ((rtm)->dwork[idx] = (val))
#endif

#ifndef rtmGetOffsetTime
# define rtmGetOffsetTime(rtm, idx)    ((rtm)->Timing.offsetTimes[idx])
#endif

#ifndef rtmSetOffsetTime
# define rtmSetOffsetTime(rtm, idx, val) ((rtm)->Timing.offsetTimes[idx] = (val))
#endif

#ifndef rtmGetSFunction
# define rtmGetSFunction(rtm, idx)     ((rtm)->childSfunctions[idx])
#endif

#ifndef rtmSetSFunction
# define rtmSetSFunction(rtm, idx, val) ((rtm)->childSfunctions[idx] = (val))
#endif

#ifndef rtmGetSampleTime
# define rtmGetSampleTime(rtm, idx)    ((rtm)->Timing.sampleTimes[idx])
#endif

#ifndef rtmSetSampleTime
# define rtmSetSampleTime(rtm, idx, val) ((rtm)->Timing.sampleTimes[idx] = (val))
#endif

#ifndef rtmGetSampleTimeTaskID
# define rtmGetSampleTimeTaskID(rtm, idx) ((rtm)->Timing.sampleTimeTaskIDPtr[idx])
#endif

#ifndef rtmSetSampleTimeTaskID
# define rtmSetSampleTimeTaskID(rtm, idx, val) ((rtm)->Timing.sampleTimeTaskIDPtr[idx] = (val))
#endif

#ifndef rtmGetVarNextHitTimeList
# define rtmGetVarNextHitTimeList(rtm, idx) ((rtm)->Timing.varNextHitTimesList[idx])
#endif

#ifndef rtmSetVarNextHitTimeList
# define rtmSetVarNextHitTimeList(rtm, idx, val) ((rtm)->Timing.varNextHitTimesList[idx] = (val))
#endif

#ifndef rtmIsContinuousTask
# define rtmIsContinuousTask(rtm, tid) ((tid) <= 1)
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmIsMajorTimeStep
# define rtmIsMajorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MAJOR_TIME_STEP)
#endif

#ifndef rtmIsMinorTimeStep
# define rtmIsMinorTimeStep(rtm)       (((rtm)->Timing.simTimeStep) == MINOR_TIME_STEP)
#endif

#ifndef rtmIsSampleHit
# define rtmIsSampleHit(rtm, sti, tid) (((rtm)->Timing.sampleTimeTaskIDPtr[sti] == (tid)))
#endif

#ifndef rtmStepTask
# define rtmStepTask(rtm, idx)         ((rtm)->Timing.TaskCounters.TID[(idx)] == 0)
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmSetT
# define rtmSetT(rtm, val)                                       /* Do Nothing */
#endif

#ifndef rtmGetTFinal
# define rtmGetTFinal(rtm)             ((rtm)->Timing.tFinal)
#endif

#ifndef rtmSetTFinal
# define rtmSetTFinal(rtm, val)        ((rtm)->Timing.tFinal = (val))
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

#ifndef rtmSetTPtr
# define rtmSetTPtr(rtm, val)          ((rtm)->Timing.t = (val))
#endif

#ifndef rtmGetTStart
# define rtmGetTStart(rtm)             ((rtm)->Timing.tStart)
#endif

#ifndef rtmSetTStart
# define rtmSetTStart(rtm, val)        ((rtm)->Timing.tStart = (val))
#endif

#ifndef rtmTaskCounter
# define rtmTaskCounter(rtm, idx)      ((rtm)->Timing.TaskCounters.TID[(idx)])
#endif

#ifndef rtmGetTaskTime
# define rtmGetTaskTime(rtm, sti)      (rtmGetTPtr((rtm))[(rtm)->Timing.sampleTimeTaskIDPtr[sti]])
#endif

#ifndef rtmSetTaskTime
# define rtmSetTaskTime(rtm, sti, val) (rtmGetTPtr((rtm))[sti] = (val))
#endif

#ifndef rtmGetTimeOfLastOutput
# define rtmGetTimeOfLastOutput(rtm)   ((rtm)->Timing.timeOfLastOutput)
#endif

#ifdef rtmGetRTWSolverInfo
#undef rtmGetRTWSolverInfo
#endif

#define rtmGetRTWSolverInfo(rtm)       &((rtm)->solverInfo)
#define rtModel_may23                  RT_MODEL_may23_T

/* Definition for use in the target main file */
#define may23_rtModel                  RT_MODEL_may23_T

/* Block signals for system '<S321>/MATLAB Function' */
typedef struct {
  real_T is_right_arm;                 /* '<S321>/MATLAB Function' */
  real_T isExo;                        /* '<S321>/MATLAB Function' */
  real_T has_high_res_encoders;        /* '<S321>/MATLAB Function' */
} B_MATLABFunction_may23_bc_T;

/* Block signals for system '<S4>/Ramp_Up_Down' */
typedef struct {
  real_T scaling;                      /* '<S4>/Ramp_Up_Down' */
  int8_T e_clk;                        /* '<S4>/Ramp_Up_Down' */
} B_Ramp_Up_Down_may23_T;

/* Block states (default storage) for system '<S4>/Ramp_Up_Down' */
typedef struct {
  real_T tick;                         /* '<S4>/Ramp_Up_Down' */
  real_T halfUpTicks;                  /* '<S4>/Ramp_Up_Down' */
  real_T halfDownTicks;                /* '<S4>/Ramp_Up_Down' */
  int32_T sfEvent;                     /* '<S4>/Ramp_Up_Down' */
  uint32_T temporalCounter_i1;         /* '<S4>/Ramp_Up_Down' */
  int8_T Ramp_Up_Down_SubsysRanBC;     /* '<S4>/Ramp_Up_Down' */
  uint8_T is_active_c20_KINARM_EP_loads;/* '<S4>/Ramp_Up_Down' */
  uint8_T is_c20_KINARM_EP_loads;      /* '<S4>/Ramp_Up_Down' */
  uint8_T is_Ramp_Up_Main;             /* '<S4>/Ramp_Up_Down' */
  uint8_T is_Ramp_Down_Main;           /* '<S4>/Ramp_Up_Down' */
} DW_Ramp_Up_Down_may23_T;

/* Zero-crossing (trigger) state for system '<S4>/Ramp_Up_Down' */
typedef struct {
  ZCSigState Ramp_Up_Down_Trig_ZCE_e;  /* '<S4>/Ramp_Up_Down' */
} ZCE_Ramp_Up_Down_may23_T;

/* Block signals for system '<S4>/Remove_NaNs_and_Inf' */
typedef struct {
  real_T TmpSignalConversionAtSFunctionInport1[4];/* '<S4>/Remove_NaNs_and_Inf' */
  real_T out[4];                       /* '<S4>/Remove_NaNs_and_Inf' */
} B_Remove_NaNs_and_Inf_may23_T;

/* Block signals for system '<S360>/MATLAB Function' */
typedef struct {
  boolean_T motors_enabled;            /* '<S360>/MATLAB Function' */
} B_MATLABFunction_may23_f_T;

/* Block signals for system '<S5>/Ramp_Up_Down' */
typedef struct {
  real_T scaling;                      /* '<S5>/Ramp_Up_Down' */
  int8_T e_clk;                        /* '<S5>/Ramp_Up_Down' */
} B_Ramp_Up_Down_may23_g_T;

/* Block states (default storage) for system '<S5>/Ramp_Up_Down' */
typedef struct {
  real_T tick;                         /* '<S5>/Ramp_Up_Down' */
  real_T tickCount;                    /* '<S5>/Ramp_Up_Down' */
  int32_T sfEvent;                     /* '<S5>/Ramp_Up_Down' */
  uint32_T temporalCounter_i1;         /* '<S5>/Ramp_Up_Down' */
  int8_T Ramp_Up_Down_SubsysRanBC;     /* '<S5>/Ramp_Up_Down' */
  uint8_T is_active_c39_KINARM_loads;  /* '<S5>/Ramp_Up_Down' */
  uint8_T is_c39_KINARM_loads;         /* '<S5>/Ramp_Up_Down' */
  uint8_T is_Ramp_Up_Main;             /* '<S5>/Ramp_Up_Down' */
} DW_Ramp_Up_Down_may23_o_T;

/* Zero-crossing (trigger) state for system '<S5>/Ramp_Up_Down' */
typedef struct {
  ZCSigState Ramp_Up_Down_Trig_ZCE;    /* '<S5>/Ramp_Up_Down' */
} ZCE_Ramp_Up_Down_may23_m_T;

/* Block signals for system '<S13>/Embedded MATLAB Function' */
typedef struct {
  real_T VCODE[70];                    /* '<S13>/Embedded MATLAB Function' */
} B_EmbeddedMATLABFunction_may23_T;

/* Block signals for system '<S15>/Embedded MATLAB Function' */
typedef struct {
  real_T VCODE[70];                    /* '<S15>/Embedded MATLAB Function' */
} B_EmbeddedMATLABFunction_may23_d_T;

/* Block signals (default storage) */
typedef struct {
  boolean_T x[24950];
  KinDataStruct BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea;
  real_T Delay1;                       /* '<S336>/Delay1' */
  real_T Product3;                     /* '<S336>/Product3' */
  real_T RunCommandReceive_o2;         /* '<S335>/Run Command Receive' */
  real_T DataTypeConversion;           /* '<S335>/Data Type Conversion' */
  real_T PauseType;                    /* '<S3>/Pause Type' */
  real_T Convert18;                    /* '<S3>/Convert18' */
  real_T UsecustomTPsequence;          /* '<S3>/Use custom TP sequence' */
  real_T Memory;                       /* '<S3>/Memory' */
  real_T TaskClock;                    /* '<S336>/Task Clock' */
  real_T Product;                      /* '<S336>/Product' */
  real_T DataTypeConversion_p;         /* '<S336>/Data Type Conversion' */
  real_T MinMax;                       /* '<S3>/MinMax' */
  real_T TPSelector[50];               /* '<S3>/TP Selector' */
  real_T Memory_d[4];                  /* '<S1>/Memory' */
  real_T Memory_m;                     /* '<S9>/Memory' */
  real_T Gain;                         /* '<S9>/Gain' */
  real_T Memory2;                      /* '<S38>/Memory2' */
  real_T Switch[2];                    /* '<S7>/Switch' */
  real_T ArraySelector[64];            /* '<S7>/Array Selector' */
  real_T Switch_i[2];                  /* '<S6>/Switch' */
  real_T ArraySelector_b[64];          /* '<S6>/Array Selector' */
  real_T Memory2_c[70];                /* '<Root>/Memory2' */
  real_T Selector[2];                  /* '<S12>/Selector' */
  real_T ArraySelector_m[64];          /* '<S12>/Array Selector' */
  real_T Selector_n[2];                /* '<S10>/Selector' */
  real_T ArraySelector_c[64];          /* '<S10>/Array Selector' */
  real_T Selector_g[2];                /* '<S11>/Selector' */
  real_T Convert9[2];                  /* '<S3>/Convert9' */
  real_T Product2;                     /* '<S336>/Product2' */
  real_T DataTypeConversion2;          /* '<S336>/Data Type Conversion2' */
  real_T Convert16;                    /* '<S3>/Convert16' */
  real_T Convert17;                    /* '<S3>/Convert17' */
  real_T TmpRTBAtHold_to_1KhzInport2;
  real_T Selector1[500];               /* '<S336>/Selector1' */
  real_T Selector2[1000];              /* '<S336>/Selector2' */
  real_T Convert10[2];                 /* '<S3>/Convert10' */
  real_T Convert11[10];                /* '<S3>/Convert11' */
  real_T Convert12;                    /* '<S3>/Convert12' */
  real_T Convert13[3];                 /* '<S3>/Convert13' */
  real_T Convert14[2];                 /* '<S3>/Convert14' */
  real_T Convert15;                    /* '<S3>/Convert15' */
  real_T Convert7;                     /* '<S3>/Convert7' */
  real_T Convert8;                     /* '<S3>/Convert8' */
  real_T frame_of_reference_center[2]; /* '<S3>/frame_of_reference_center' */
  real_T LibraryPatchVersion;          /* '<S3>/Library Patch Version' */
  real_T LibraryVersion;               /* '<S3>/Library Version' */
  real_T TaskVersion;                  /* '<S3>/Task Version' */
  real_T xPCVersion;                   /* '<S3>/xPC Version' */
  real_T dlmbuildtime;                 /* '<S3>/dlm build time' */
  real_T preview_detail[3];            /* '<S334>/preview_detail' */
  real_T Subtract;                     /* '<S22>/Subtract' */
  real_T Selector_p[25];               /* '<S14>/Selector' */
  real_T MatrixConcatenation1[55];     /* '<S14>/Matrix Concatenation1' */
  real_T Reshape[70];                  /* '<S405>/Reshape' */
  real_T Reshape1[70];                 /* '<S405>/Reshape1' */
  real_T MatrixConcatenation[140];     /* '<S405>/Matrix Concatenation' */
  real_T Selector_gx[25];              /* '<S17>/Selector' */
  real_T MatrixConcatenation1_a[55];   /* '<S17>/Matrix Concatenation1' */
  real_T Selector_c[25];               /* '<S15>/Selector' */
  real_T MatrixConcatenation1_g[55];   /* '<S15>/Matrix Concatenation1' */
  real_T gethandmass;                  /* '<S21>/get hand mass' */
  real_T getrectanglemass;             /* '<S21>/get rectangle mass' */
  real_T MatrixConcatenate1[4];        /* '<S401>/Matrix Concatenate1' */
  real_T PulseGenerator;               /* '<S21>/Pulse Generator' */
  real_T DataTypeConversion_b;         /* '<S21>/Data Type Conversion' */
  real_T AnalogDataWidth[71];          /* '<S22>/Analog Data Width' */
  real_T DataTypeConversion_g;         /* '<S23>/Data Type Conversion' */
  real_T RateTransition1;              /* '<S23>/Rate Transition1' */
  real_T RateTransition2;              /* '<S23>/Rate Transition2' */
  real_T EventCodes;                   /* '<S24>/Event Codes' */
  real_T Subtract_i;                   /* '<S24>/Subtract' */
  real_T NumberofEventCodes;           /* '<S24>/Number of Event Codes' */
  real_T touint1;                      /* '<S25>/touint1' */
  real_T ButtonStatus;                 /* '<S26>/Button Status' */
  real_T CurrentBlockIndex;            /* '<S26>/Current Block Index' */
  real_T CurrentBlockNumberinSet;      /* '<S26>/Current Block Number in Set' */
  real_T CurrentTPIndex;               /* '<S26>/Current TP Index' */
  real_T CurrentTrialNumberinBlock;  /* '<S26>/Current Trial Number in Block' */
  real_T CurrentTrialNumberinSet;      /* '<S26>/Current Trial Number in Set' */
  real_T Receive_o2;                   /* '<S9>/Receive' */
  real_T Convert1;                     /* '<S9>/Convert1' */
  real_T LastFrameAcknowledged;        /* '<S26>/Last Frame Acknowledged' */
  real_T Convert;                      /* '<S9>/Convert' */
  real_T LastFrameSent;                /* '<S26>/Last Frame Sent' */
  real_T LastFrameSent1;               /* '<S26>/Last Frame Sent1' */
  real_T LoggingEnable;                /* '<S26>/Logging Enable' */
  real_T Servoupdatecount;             /* '<S26>/Servo update count' */
  real_T RateTransition;               /* '<S26>/Rate Transition' */
  real_T RateTransition1_h;            /* '<S26>/Rate Transition1' */
  real_T RunStatus;                    /* '<S26>/Run Status' */
  real_T RateTransition10;             /* '<S26>/Rate Transition10' */
  real_T TaskControlButton;            /* '<S26>/Task Control Button' */
  real_T RateTransition11;             /* '<S26>/Rate Transition11' */
  real_T RateTransition12;             /* '<S26>/Rate Transition12' */
  real_T RateTransition2_k;            /* '<S26>/Rate Transition2' */
  real_T RateTransition3;              /* '<S26>/Rate Transition3' */
  real_T RateTransition4;              /* '<S26>/Rate Transition4' */
  real_T RateTransition5;              /* '<S26>/Rate Transition5' */
  real_T RateTransition6;              /* '<S26>/Rate Transition6' */
  real_T RateTransition7;              /* '<S26>/Rate Transition7' */
  real_T RateTransition8;              /* '<S26>/Rate Transition8' */
  real_T RateTransition9;              /* '<S26>/Rate Transition9' */
  real_T TmpRTBAtTimestampOutport1;    /* '<S26>/Timestamp' */
  real_T conv;                         /* '<S26>/conv' */
  real_T Delay;                        /* '<S34>/Delay' */
  real_T Product_b[4];                 /* '<S34>/Product' */
  real_T up_durationms;                /* '<S4>/up_duration(ms)' */
  real_T down_durationms;              /* '<S4>/down_duration(ms)' */
  real_T up_durationms_h;              /* '<S5>/up_duration(ms)' */
  real_T down_durationms_b;            /* '<S5>/down_duration(ms)' */
  real_T DataTypeConversion_pv;        /* '<S5>/Data Type Conversion' */
  real_T AddR1;                        /* '<S38>/AddR1' */
  real_T up_durationms1;               /* '<S4>/up_duration(ms)1' */
  real_T down_durationms1;             /* '<S4>/down_duration(ms)1' */
  real_T DataTypeConversion1;          /* '<S5>/Data Type Conversion1' */
  real_T AddR2;                        /* '<S38>/AddR2' */
  real_T Delay_a[4];                   /* '<S327>/Delay' */
  real_T DataStoreRead[14];            /* '<S38>/Data Store Read' */
  real_T Product_n[4];                 /* '<S38>/Product' */
  real_T Delay_l;                      /* '<S38>/Delay' */
  real_T TaskClock_h;                  /* '<S38>/Task Clock' */
  real_T Memory3[4];                   /* '<S19>/Memory3' */
  real_T DataTypeConversion_bl[400];   /* '<S396>/Data Type Conversion' */
  real_T Abs[4];                       /* '<S19>/Abs' */
  real_T SumofElements;                /* '<S19>/Sum of Elements' */
  real_T Switch_k[4];                  /* '<S19>/Switch' */
  real_T Product_br[4];                /* '<S19>/Product' */
  real_T Reshape_p[4];                 /* '<S5>/Reshape' */
  real_T Switch_h;                     /* '<S5>/Switch' */
  real_T Product_i[2];                 /* '<S5>/Product' */
  real_T Product1[2];                  /* '<S5>/Product1' */
  real_T Switch1;                      /* '<S369>/Switch1' */
  real_T Reshape_b[4];                 /* '<S4>/Reshape' */
  real_T Product_c[2];                 /* '<S4>/Product' */
  real_T Product1_j[2];                /* '<S4>/Product1' */
  real_T AddTorques[4];                /* '<S1>/AddTorques' */
  real_T Memory1;                      /* '<S38>/Memory1' */
  real_T Product_g[4];                 /* '<S1>/Product' */
  real_T Memory1_l;                    /* '<S1>/Memory1' */
  real_T ArmOrientation;               /* '<S1>/Memory2' */
  real_T M1orientation;                /* '<S1>/Memory2' */
  real_T M2Orientation;                /* '<S1>/Memory2' */
  real_T M1GearRatio;                  /* '<S1>/Memory2' */
  real_T M2GearRatio;                  /* '<S1>/Memory2' */
  real_T torqueconstant;               /* '<S1>/Memory2' */
  real_T ArmOrientation_a;             /* '<S1>/Memory2' */
  real_T M1orientation_i;              /* '<S1>/Memory2' */
  real_T M2Orientation_a;              /* '<S1>/Memory2' */
  real_T M1GearRatio_e;                /* '<S1>/Memory2' */
  real_T M2GearRatio_n;                /* '<S1>/Memory2' */
  real_T torqueconstant_b;             /* '<S1>/Memory2' */
  real_T isEP;                         /* '<S1>/Memory2' */
  real_T isHumanExo;                   /* '<S1>/Memory2' */
  real_T isNHPExo;                     /* '<S1>/Memory2' */
  real_T isClassicExo;                 /* '<S1>/Memory2' */
  real_T isUTSExo;                     /* '<S1>/Memory2' */
  real_T isPMAC;                       /* '<S1>/Memory2' */
  real_T isECAT;                       /* '<S1>/Memory2' */
  real_T robotRevision;                /* '<S1>/Memory2' */
  real_T HasSecondaryEnc;              /* '<S1>/Memory2' */
  real_T robottype;                    /* '<S1>/Memory2' */
  real_T robotversion;                 /* '<S1>/Memory2' */
  real_T isEP_f;                       /* '<S1>/Memory2' */
  real_T isHumanExo_k;                 /* '<S1>/Memory2' */
  real_T isNHPExo_l;                   /* '<S1>/Memory2' */
  real_T isClassicExo_j;               /* '<S1>/Memory2' */
  real_T isUTSExo_n;                   /* '<S1>/Memory2' */
  real_T isPMAC_p;                     /* '<S1>/Memory2' */
  real_T isECAT_o;                     /* '<S1>/Memory2' */
  real_T robotRevision_p;              /* '<S1>/Memory2' */
  real_T HasSecondaryEnc_h;            /* '<S1>/Memory2' */
  real_T robottype_c;                  /* '<S1>/Memory2' */
  real_T robotversion_a;               /* '<S1>/Memory2' */
  real_T DataStoreRead1[10];           /* '<S38>/Data Store Read1' */
  real_T Memory1_e[4];                 /* '<S329>/Memory1' */
  real_T encoder_err_threshold;        /* '<S329>/encoder_err_threshold' */
  real_T DataStoreRead1_l[10];         /* '<S34>/Data Store Read1' */
  real_T readstatus[8];                /* '<S1>/read status' */
  real_T robot_count;                  /* '<S35>/arm_count' */
  real_T has_force_plate_1;            /* '<S35>/fp1_present' */
  real_T has_force_plate_2;            /* '<S35>/fp2_present' */
  real_T has_gaze_tracker;             /* '<S35>/gaze_tracker_present' */
  real_T has_robot_lift;               /* '<S35>/robot_lift_present' */
  real_T Selector_f[25];               /* '<S16>/Selector' */
  real_T MatrixConcatenation1_e[55];   /* '<S16>/Matrix Concatenation1' */
  real_T Selector_i[25];               /* '<S13>/Selector' */
  real_T MatrixConcatenation1_k[55];   /* '<S13>/Matrix Concatenation1' */
  real_T Selector_d[25];               /* '<S18>/Selector' */
  real_T MatrixConcatenation1_b[55];   /* '<S18>/Matrix Concatenation1' */
  real_T MatrixConcatenate[490];       /* '<Root>/Matrix Concatenate' */
  real_T assessment_hand_vel[2];       /* '<S372>/Switch2' */
  real_T contralateral_hand_vel[2];    /* '<S372>/Switch3' */
  real_T assessment_link_angles[2];    /* '<S372>/Switch4' */
  real_T contralateral_link_angles[2]; /* '<S372>/Switch5' */
  real_T assessment_link_vel[2];       /* '<S372>/Switch6' */
  real_T contralateral_link_vel[2];    /* '<S372>/Switch7' */
  real_T assessment_hand_vel_n[2];     /* '<S374>/Switch2' */
  real_T contralateral_hand_vel_d[2];  /* '<S374>/Switch3' */
  real_T assessment_link_angles_m[2];  /* '<S374>/Switch4' */
  real_T contralateral_link_angles_f[2];/* '<S374>/Switch5' */
  real_T assessment_link_vel_n[2];     /* '<S374>/Switch6' */
  real_T contralateral_link_vel_a[2];  /* '<S374>/Switch7' */
  real_T Constant;                     /* '<Root>/Constant' */
  real_T binary_file_names;            /* '<S8>/binary_file_names' */
  real_T binary_files[10];             /* '<S8>/binary_files' */
  real_T BARRIER_ROWBarriertargetBarriernone;
                      /* '<S375>/BARRIER_ROW;Barrier;target;Barrier;;;none;;' */
  real_T CURSOR_ROWHandTargetRowtargethandnone;
                 /* '<S375>/CURSOR_ROW;Hand Target Row;target;hand ;;;none;;' */
  real_T GOAL_ROWGoalRowtargetGoalnone;
                           /* '<S375>/GOAL_ROW;Goal Row;target;Goal;;;none;;' */
  real_T GOAL_TIMEGoaltimesfloatTimethatpuckhastostayingoaltotriggersucc;
  /* '<S375>/GOAL_TIME;Goal time (s);float;Time that puck has to stay in goal to trigger success;;;none;;' */
  real_T LOAD_ROWLoadRowloadLoadnone;
                             /* '<S375>/LOAD_ROW;Load Row;load;Load;;;none;;' */
  real_T PRESHOT_ROWPreshotAreatargetPreshotAreanone;
           /* '<S375>/PRESHOT_ROW;Preshot Area;target;Preshot Area ;;;none;;' */
  real_T PUCK_DAMPINGPuckdampingfloatDampingconstantonpuckbetween0and1no;
  /* '<S375>/PUCK_DAMPING;Puck damping;float;Damping constant on puck (between 0 and 1);;;none;;' */
  real_T PUCK_ROWPuckTargetRowtargetPucknone;
                    /* '<S375>/PUCK_ROW;Puck Target Row;target;Puck;;;none;;' */
  real_T SECONDSTrialdurationsfloatHowlongisthetrialinsecondsnone;
  /* '<S375>/SECONDS;Trial duration (s);float;How long is the trial in seconds.;;;none;;' */
  real_T SHOT_READY_TIMEShotreadytimesfloatTimetoholdinstarttargetduring;
  /* '<S375>/SHOT_READY_TIME;Shot ready time (s);float;Time to hold in start target during preshot routine to trigger the set state;;;none;;' */
  real_T SHOT_SET_TIMEShotsettimesfloatTimetoholdinstarttargetafterpresh;
  /* '<S375>/SHOT_SET_TIME;Shot set time (s);float;Time to hold in start target after preshot routine to trigger go cue;;;none;;' */
  real_T SHOT_TIMEShottimesfloatTimetomakeashotintothegoalnone;
  /* '<S375>/SHOT_TIME;Shot time (s);float;Time to make a shot into the goal;;;none;;' */
  real_T START_HOLD_TIMEStartholdtimesfloatTimetoholdinstarttargetbefore;
  /* '<S375>/START_HOLD_TIME;Start hold time (s);float;Time to hold in start target before triggering preshot routine;;;none;;' */
  real_T START_ROWStartPositiontargetStartingSpotforPtnone;
  /* '<S375>/START_ROW;Start Position;target;Starting Spot for Pt ;;;none;;' */
  real_T E_BEGIN_PRESHOTbeginpreshotroutinenone;
                 /* '<S376>/E_BEGIN_PRESHOT;begin preshot routine;;;;;none;;' */
  real_T E_ENTER_STARTenterstarttargetnone;
                      /* '<S376>/E_ENTER_START;enter start target;;;;;none;;' */
  real_T E_FAILUREfailurered;         /* '<S376>/E_FAILURE;failure;;;;;red;;' */
  real_T E_HAND_IN_BARRIERhandinbarriernone;
                     /* '<S376>/E_HAND_IN_BARRIER;hand in barrier;;;;;none;;' */
  real_T E_NO_EVENTnaThisevent_codedoesnotsaveaneventinthedatafileitjust;
  /* '<S376>/E_NO_EVENT;n|a;;This event_code does not save an event in the data file, it just clears the event;;;none;;' */
  real_T E_PUCK_IN_BARRIERpuckinbarriernone;
                     /* '<S376>/E_PUCK_IN_BARRIER;puck in barrier;;;;;none;;' */
  real_T E_PUCK_IN_GOALpuckingoalnone;
                           /* '<S376>/E_PUCK_IN_GOAL;puck in goal;;;;;none;;' */
  real_T E_PUCK_MISSpuckmissnone;/* '<S376>/E_PUCK_MISS;puck miss;;;;;none;;' */
  real_T E_SHOT_GOshotgonone;        /* '<S376>/E_SHOT_GO;shot go;;;;;none;;' */
  real_T E_SHOT_READYshotreadynone;
                               /* '<S376>/E_SHOT_READY;shot ready;;;;;none;;' */
  real_T E_START_TARGET_ONstarttargetonnone;
                     /* '<S376>/E_START_TARGET_ON;start target on;;;;;none;;' */
  real_T E_SUCCESSsuccessgreen;     /* '<S376>/E_SUCCESS;success;;;;;green;;' */
  real_T E_TIMEOUTtimeoutred;         /* '<S376>/E_TIMEOUT;timeout;;;;;red;;' */
  real_T E_TRIAL_STARTtrialstartnone;
                             /* '<S376>/E_TRIAL_START;trial start;;;;;none;;' */
  real_T F_BUMPF_BUMPfloatCompletelyarbitraryparameterbasedonwhatfeelsgo;
  /* '<S377>/F_BUMP;F_BUMP;float;Completely arbitrary parameter based on what feels good...;;;none;;' */
  real_T MASS_CIRCLECircletargetmassfloatnone;
                   /* '<S377>/MASS_CIRCLE;Circle target mass;float;;;;none;;' */
  real_T MASS_RECTRectangletargetmassfloatnone;
                  /* '<S377>/MASS_RECT;Rectangle target mass;float;;;;none;;' */
  real_T PERT_DURPerturbationDurationfloatmsTimethattheperturbationishig;
  /* '<S377>/PERT_DUR;Perturbation Duration;float;(ms) Time that the perturbation is high for;;;none;;' */
  real_T PERT_RAMPPerturbationRampTimefloatmsTimefortheperturbationtoram;
  /* '<S377>/PERT_RAMP;Perturbation Ramp Time;float;(ms) Time for the perturbation to ramp up and down;;;none;;' */
  real_T FIRST_FILLFirstfillcolorcolourFirstfillcolorforaselectedtargetc;
  /* '<S378>/FIRST_FILL;First fill color;colour;First fill color for a selected target (color);;;none;;' */
  real_T HEIGHTHeightfloatRectangleheightcmnone;
               /* '<S378>/HEIGHT;Height;float;Rectangle height (cm);;;none;;' */
  real_T RADIUS_LOGlogicalradiusfloatcomputationalradiuscmnone;
  /* '<S378>/RADIUS_LOG;logical radius;float;computational radius (cm);;;none;;' */
  real_T RADIUS_VISradiusvisfloatradiusincmlegacynone;
      /* '<S378>/RADIUS_VIS;radius vis;float;radius in cm (legacy?);;;none;;' */
  real_T ROTATIONRotationfloatRectangleroationdegreesnone;
     /* '<S378>/ROTATION;Rotation;float;Rectangle roation (degrees);;;none;;' */
  real_T SECOND_FILLSecondfillcolorcolourSecondfillcolorforaselectedtarg;
  /* '<S378>/SECOND_FILL;Second fill color;colour;Second fill color for a selected target (color);;;none;;' */
  real_T STROKE_COLORStrokecolourcolourStrokecolorcolornone;
  /* '<S378>/STROKE_COLOR;Stroke colour;colour;Stroke color (color);;;none;;' */
  real_T STROKE_WIDTHWidthofthestrokefloatStrokeweightcmnone;
  /* '<S378>/STROKE_WIDTH;Width of the stroke;float;Stroke weight (cm);;;none;;' */
  real_T THIRD_FILLthirdfillcolorcolourThirdfillcolorforaselectedtargetc;
  /* '<S378>/THIRD_FILL;third fill color;colour;Third fill color for a selected target (color);;;none;;' */
  real_T col_xXfloatXPositioncmofthetargetrelativetolocal00none;
  /* '<S378>/col_x;X;float;X Position (cm) of the target relative to  local (0,0);;;none;;' */
  real_T col_yYfloatYPositioncmofthetargetrelativetolocal00none;
  /* '<S378>/col_y;Y;float;Y Position (cm) of the target relative to  local (0,0);;;none;;' */
  real_T WIDTHWidthorRadiusfloatRectanglewidthorCircleRadiuscmnone;
  /* '<S378>/WIDTH;Width or Radius;float;Rectangle width or Circle Radius (cm);;;none;;' */
  real_T INSTRUCTIONS;                 /* '<S379>/INSTRUCTIONS=' */
  real_T LOAD_FOREITHER;               /* '<S379>/LOAD_FOR=EITHER' */
  real_T FORCE_MULTIPLIERForcemultiplierfloatnone;
                /* '<S380>/FORCE_MULTIPLIER;Force multiplier;float;;;;none;;' */
  real_T RateTransition_e[71];         /* '<S22>/Rate Transition' */
  real_T RateTransition2_p[490];       /* '<S9>/Rate Transition2' */
  real_T MatrixConcatenate_d[1120];    /* '<S9>/Matrix Concatenate' */
  real_T RateTransition_k[72];         /* '<S25>/Rate Transition' */
  real_T Timestamp;                    /* '<S26>/Timestamp' */
  real_T RateTransition1_a[16];        /* '<S1>/Rate Transition1' */
  real_T RateTransition2_h[2];         /* '<S1>/Rate Transition2' */
  real_T RateTransition_p[20];         /* '<S1>/Rate Transition' */
  real_T RateTransition1_c;            /* '<S381>/Rate Transition1' */
  real_T SFunctionBuilder_o2;          /* '<S381>/S-Function Builder' */
  real_T SFunctionBuilder_o3[5];       /* '<S381>/S-Function Builder' */
  real_T force_vector[4];              /* '<S21>/MATLAB Function' */
  real_T hand_vcodes[140];             /* '<S402>/MATLAB Function' */
  real_T VCODES_out[140];              /* '<S405>/FeedFwdArm' */
  real_T hand_vcodes_e[4];             /* '<S401>/MATLAB Function' */
  real_T puck_vcode_output[70];        /* '<S21>/Collision Resolution' */
  real_T force_scaling[4];             /* '<S21>/Collision Resolution' */
  real_T event_code;                   /* '<Root>/Trial_Control' */
  real_T cursor_row;                   /* '<Root>/Trial_Control' */
  real_T cursor_state;                 /* '<Root>/Trial_Control' */
  real_T puck_row;                     /* '<Root>/Trial_Control' */
  real_T puck_state;                   /* '<Root>/Trial_Control' */
  real_T load_row;                     /* '<Root>/Trial_Control' */
  real_T barrier_target_row;           /* '<Root>/Trial_Control' */
  real_T barrier_target_state;         /* '<Root>/Trial_Control' */
  real_T start_target_row;             /* '<Root>/Trial_Control' */
  real_T start_target_state;           /* '<Root>/Trial_Control' */
  real_T goal_target_row;              /* '<Root>/Trial_Control' */
  real_T goal_target_state;            /* '<Root>/Trial_Control' */
  real_T preshot_area_row;             /* '<Root>/Trial_Control' */
  real_T preshot_area_state;           /* '<Root>/Trial_Control' */
  real_T perturbation[3];              /* '<S396>/Select Perturbation Times' */
  real_T scaling;                      /* '<S396>/Ramp_up_down' */
  real_T TmpSignalConversionAtSFunctionInport3[5];
                                      /* '<S12>/Embedded MATLAB InsideTarget' */
  real_T intarget[320];               /* '<S12>/Embedded MATLAB InsideTarget' */
  real_T indisplay;                    /* '<S11>/MATLAB Function' */
  real_T TmpSignalConversionAtSFunctionInport3_b[15];
                                      /* '<S10>/Embedded MATLAB InsideTarget' */
  real_T intarget_g[320];             /* '<S10>/Embedded MATLAB InsideTarget' */
  real_T RateTransition1_o;            /* '<S383>/Rate Transition1' */
  real_T Convert_j;                    /* '<S383>/Convert' */
  real_T vis_cmd_len;                  /* '<S383>/Pack VCodeFrame2' */
  real_T vis_cmd_cropped;              /* '<S383>/Pack VCodeFrame2' */
  real_T vcode_err_id;                 /* '<S383>/Pack VCodeFrame2' */
  real_T last_frame_ack;               /* '<S9>/MATLAB Function' */
  real_T last_perm_ack;                /* '<S9>/MATLAB Function' */
  real_T delay;                        /* '<S381>/MATLAB Function' */
  real_T TmpSignalConversionAtSFunctionInport3_n[5];/* '<S7>/Embedded MATLAB InsideTarget' */
  real_T intarget_d[320];              /* '<S7>/Embedded MATLAB InsideTarget' */
  real_T assessment_hand_pos[2];       /* '<S374>/Switch' */
  real_T contralateral_hand_pos[2];    /* '<S374>/Switch1' */
  real_T TmpSignalConversionAtSFunctionInport3_f[15];/* '<S6>/Embedded MATLAB InsideTarget' */
  real_T intarget_j[320];              /* '<S6>/Embedded MATLAB InsideTarget' */
  real_T assessment_hand_pos_f[2];     /* '<S372>/Switch' */
  real_T contralateral_hand_pos_o[2];  /* '<S372>/Switch1' */
  real_T TmpSignalConversionAtSFunctionInport3_h[2];/* '<S369>/clip_motor_torque' */
  real_T clipped_torques[4];           /* '<S369>/clip_motor_torque' */
  real_T y[4];                         /* '<S5>/Torque_Cap' */
  real_T out[4];                       /* '<S5>/Remove_NaNs_and_Inf1' */
  real_T out_p[4];                     /* '<S4>/Remove_NaNs_and_Inf1' */
  real_T joint_loads[4];               /* '<S4>/Forces_to_Torques' */
  real_T out_m[4];                     /* '<S4>/Force_Cap' */
  real_T BlockDefinitions[25000];      /* '<S351>/Block Definitions' */
  real_T BlockSequence[3000];          /* '<S351>/Block Sequence' */
  real_T TPTable[5000];                /* '<S351>/TP Table' */
  real_T TargetLabels[3200];           /* '<S351>/Target Labels' */
  real_T TargetTable[1600];            /* '<S351>/Target Table' */
  real_T LoadTable[400];               /* '<S351>/Load Table' */
  real_T Taskwideparam[50];            /* '<S351>/Task wide param' */
  real_T total_trials;                 /* '<S337>/MATLAB Function' */
  real_T trials_in_block;              /* '<S337>/MATLAB Function' */
  real_T total_blocks;                 /* '<S337>/MATLAB Function' */
  real_T repeat_last_trial;        /* '<S336>/Task Execution Control Machine' */
  real_T extra_trials[2];          /* '<S336>/Task Execution Control Machine' */
  real_T tp_out;                       /* '<S336>/MATLAB Function' */
  real_T value;                        /* '<S335>/Hold_to_1Khz' */
  real_T y_o;                          /* '<S335>/Embedded MATLAB Function' */
  real_T z;                            /* '<S335>/Embedded MATLAB Function' */
  real_T joint_loads_i[4];             /* '<S2>/Forces_to_Torques' */
  real_T TmpSignalConversionAtSFunctionInport2[2];/* '<S38>/torque_monitor' */
  real_T command_multiplier;           /* '<S38>/torque_monitor' */
  real_T stop_vel_mode;                /* '<S38>/torque_monitor' */
  real_T robot_err_bits_out;           /* '<S38>/torque_monitor' */
  real_T torque_multiplier_out;        /* '<S329>/monitor_encoders' */
  real_T stop_vel_mode_out;            /* '<S329>/monitor_encoders' */
  real_T TmpSignalConversionAtSFunctionInport1[8];/* '<S38>/filter' */
  real_T filteredVals[8];              /* '<S38>/filter' */
  real_T TmpSignalConversionAtSFunctionInport1_f[4];/* '<S327>/filter' */
  real_T filteredVals_n[4];            /* '<S327>/filter' */
  real_T robot_limits[3];              /* '<S38>/current_limits' */
  real_T torque_err_bitfield;          /* '<S38>/MATLAB Function' */
  real_T abs_diff[4];                  /* '<S38>/MATLAB Function' */
  real_T rel_diff[4];                  /* '<S38>/MATLAB Function' */
  real_T TmpSignalConversionAtSFunctionInport1_j[4];/* '<S34>/delta' */
  real_T TmpSignalConversionAtSFunctionInport2_n[4];/* '<S34>/delta' */
  real_T deltas[4];                    /* '<S34>/delta' */
  real_T torques_out[4];               /* '<S33>/verify NaN' */
  real_T Product_d[4];                 /* '<S313>/Product' */
  real_T DataStoreRead_h[14];          /* '<S312>/Data Store Read' */
  real_T DataTypeConversion3[4];       /* '<S31>/Data Type Conversion3' */
  real_T DataTypeConversion4;          /* '<S31>/Data Type Conversion4' */
  real_T DataTypeConversion5;          /* '<S31>/Data Type Conversion5' */
  real_T Convert1_n;                   /* '<S31>/Convert1' */
  real_T DataTypeConversion_p5;        /* '<S31>/Data Type Conversion' */
  real_T Convert19[3];                 /* '<S31>/Convert19' */
  real_T Convert3;                     /* '<S31>/Convert3' */
  real_T Gain_o[3];                    /* '<S31>/Gain' */
  real_T Convert4[3];                  /* '<S31>/Convert4' */
  real_T DataTypeConversion1_f[3];     /* '<S31>/Data Type Conversion1' */
  real_T RateTransition_i[3];          /* '<S31>/Rate Transition' */
  real_T Receive_o2_f;                 /* '<S31>/Receive' */
  real_T RateTransition1_n[3];         /* '<S31>/Rate Transition1' */
  real_T RateTransition2_l;            /* '<S31>/Rate Transition2' */
  real_T Convert2[3];                  /* '<S31>/Convert2' */
  real_T event_data_out[3];            /* '<S31>/convert to seconds2' */
  real_T gazeXYCalculated[2];          /* '<S31>/Embedded MATLAB Function1' */
  real_T pupil_area_GLOBAL;            /* '<S31>/Embedded MATLAB Function1' */
  real_T gaze_unit_vector_GLOBAL[3];   /* '<S31>/Embedded MATLAB Function1' */
  real_T pupil_GLOBAL[3];              /* '<S31>/Embedded MATLAB Function1' */
  real_T timestamp_out;                /* '<S31>/Create timestamp' */
  real_T start_time_out;               /* '<S31>/Create timestamp' */
  real_T DataTypeConversion_pn;        /* '<S66>/Data Type Conversion' */
  real_T max_errors_to_fault;          /* '<S66>/max errors to fault' */
  real_T systemtype;                   /* '<S30>/system type' */
  real_T convert[8];                   /* '<S82>/convert' */
  real_T ReadHasFT[3];                 /* '<S30>/Read HasFT' */
  real_T ArmOrientation_f;             /* '<S290>/Arm Orientation' */
  real_T M1orientation_b;              /* '<S290>/Arm Motor1 Orientation' */
  real_T M2Orientation_k;              /* '<S290>/Arm Motor2 Orientation' */
  real_T M1GearRatio_p;                /* '<S290>/Arm Motor1 Gear Ratio' */
  real_T M2GearRatio_i;                /* '<S290>/Arm Motor2 Gear Ratio' */
  real_T HasSecondaryEnc_n;            /* '<S290>/Arm Secondary Encoders' */
  real_T ArmOrientation_m;             /* '<S291>/Arm Orientation' */
  real_T M1orientation_f;              /* '<S291>/Arm Motor1 Orientation' */
  real_T M2Orientation_c;              /* '<S291>/Arm Motor2 Orientation' */
  real_T M1GearRatio_a;                /* '<S291>/Arm Motor1 Gear Ratio' */
  real_T M2GearRatio_ie;               /* '<S291>/Arm Motor2 Gear Ratio' */
  real_T HasSecondaryEnc_c;            /* '<S291>/Arm Secondary Encoders' */
  real_T TmpRTBAtDatawriteInport2[20]; /* '<S69>/Data receive' */
  real_T TmpRTBAtDatawriteInport3[12]; /* '<S69>/Data receive' */
  real_T Selector_i2[50];              /* '<S75>/Selector' */
  real_T Selector1_b[50];              /* '<S75>/Selector1' */
  real_T Selector2_e[50];              /* '<S75>/Selector2' */
  real_T Selector1_e[6];               /* '<S76>/Selector1' */
  real_T Selector2_l[6];               /* '<S76>/Selector2' */
  real_T shoulderangleoffset;          /* '<S290>/Arm Shoulder Angle Offset' */
  real_T elbowangleoffset;             /* '<S290>/Arm Elbow Angle Offset' */
  real_T ShoulderX;                    /* '<S290>/Arm Shoulder X' */
  real_T ShoulderY;                    /* '<S290>/Arm Shoulder Y' */
  real_T L1;                           /* '<S290>/Arm L1' */
  real_T L2;                           /* '<S290>/Arm L2' */
  real_T Pointeroffset;                /* '<S290>/Arm Pointer Offset' */
  real_T L3Error;                      /* '<S290>/Arm L3 Error' */
  real_T robottype_a;                  /* '<S290>/Arm robot type' */
  real_T torqueconstant_bz;            /* '<S290>/Arm Torque Constant' */
  real_T robotversion_h;               /* '<S290>/Arm robot version' */
  real_T shoulderangleoffset_j;        /* '<S291>/Arm Shoulder Angle Offset' */
  real_T elbowangleoffset_o;           /* '<S291>/Arm Elbow Angle Offset' */
  real_T ShoulderX_b;                  /* '<S291>/Arm Shoulder X' */
  real_T ShoulderY_n;                  /* '<S291>/Arm Shoulder Y' */
  real_T L1_e;                         /* '<S291>/Arm L1' */
  real_T L2_j;                         /* '<S291>/Arm L2' */
  real_T Pointeroffset_a;              /* '<S291>/Arm Pointer Offset' */
  real_T L3Error_a;                    /* '<S291>/Arm L3 Error' */
  real_T robottype_j;                  /* '<S291>/Arm robot type' */
  real_T torqueconstant_l;             /* '<S291>/Arm Torque Constant' */
  real_T robotversion_f;               /* '<S291>/Arm robot version' */
  real_T Statusread1[2];               /* '<S290>/Status read1' */
  real_T Statusread1_c[2];             /* '<S291>/Status read1' */
  real_T active_arm;                   /* '<S75>/splitKINDataGeneral' */
  real_T servoCounter;                 /* '<S75>/splitKINDataGeneral' */
  real_T calibrationButtonBits;        /* '<S75>/splitKINDataGeneral' */
  real_T handFF_Dex;                   /* '<S75>/splitKINDataGeneral' */
  real_T is_calibrated[2];             /* '<S73>/is_calibrated' */
  real_T Dataready[10];                /* '<S73>/Data ready' */
  real_T Read[16];                     /* '<S73>/Read' */
  real_T ReadHW[25];                   /* '<S73>/Read HW' */
  real_T ReadKinematics[20];           /* '<S73>/Read Kinematics' */
  real_T DelayRead[4];                 /* '<S73>/Delay Read' */
  real_T Primaryread[12];              /* '<S73>/Primary read' */
  real_T torquefeedback1[10];          /* '<S73>/torque feedback1' */
  real_T DataTypeConversion_f[4];      /* '<S73>/Data Type Conversion' */
  real_T DataTypeConversion1_d;        /* '<S73>/Data Type Conversion1' */
  real_T ErrMsgs[20];                  /* '<S73>/ErrMsgs' */
  real_T newMessage[6];                /* '<S73>/record errors' */
  real_T sentMessageCount;             /* '<S73>/record errors' */
  real_T TmpSignalConversionAtSFunctionInport10[7];/* '<S73>/Create KINARM Data Array' */
  real_T TmpSignalConversionAtSFunctionInport12[14];/* '<S73>/Create KINARM Data Array' */
  real_T kinarm_data[150];             /* '<S73>/Create KINARM Data Array' */
  real_T primary_encoder_data_out[12]; /* '<S73>/Create KINARM Data Array' */
  real_T trigger_calibration[2];       /* '<S73>/Calibration_check' */
  real_T Switch_g[10];                 /* '<S277>/Switch' */
  real_T DataStore[16];                /* '<S86>/Data Store' */
  real_T DataStore1[25];               /* '<S86>/Data Store1' */
  real_T DataTypeConversion3_o[4];     /* '<S86>/Data Type Conversion3' */
  real_T DataTypeConversion5_c[2];     /* '<S86>/Data Type Conversion5' */
  real_T TmpSignalConversionAtSFunctionInport2_a[4];/* '<S86>/update calibrations' */
  real_T TmpSignalConversionAtSFunctionInport4[2];/* '<S86>/update calibrations' */
  real_T calibrationsOut[16];          /* '<S86>/update calibrations' */
  real_T TmpSignalConversionAtSFunctionInport2_ny[2];/* '<S86>/update HW settings' */
  real_T TmpSignalConversionAtSFunctionInport3_c[2];/* '<S86>/update HW settings' */
  real_T TmpSignalConversionAtSFunctionInport4_m[2];/* '<S86>/update HW settings' */
  real_T settingsOut[25];              /* '<S86>/update HW settings' */
  real_T outMem[20];                   /* '<S86>/robottype1' */
  real_T TmpSignalConversionAtSFunctionInport1_e[2];/* '<S86>/create servo counter1' */
  real_T dataReadyStatus[10];          /* '<S86>/create servo counter1' */
  real_T TmpSignalConversionAtSFunctionInport1_p[4];/* '<S86>/create kinematics' */
  real_T TmpSignalConversionAtSFunctionInport2_d[4];/* '<S86>/create kinematics' */
  real_T TmpSignalConversionAtSFunctionInport3_m[2];/* '<S86>/create kinematics' */
  real_T TmpSignalConversionAtSFunctionInport5[2];/* '<S86>/create kinematics' */
  real_T kinematicsOut[20];            /* '<S86>/create kinematics' */
  real_T kinematicsOutPrimary[12];     /* '<S86>/create kinematics' */
  real_T delays[4];                    /* '<S86>/create kinematics' */
  real_T outVals[20];                  /* '<S243>/rebuild' */
  real_T TmpSignalConversionAtSFunctionInport1_m[4];/* '<S243>/filter_velocities' */
  real_T filteredVels[4];              /* '<S243>/filter_velocities' */
  real_T TmpSignalConversionAtSFunctionInport1_me[2];/* '<S86>/MATLAB Function' */
  real_T TmpSignalConversionAtSFunctionInport2_l[2];/* '<S86>/MATLAB Function' */
  real_T swap_order;                   /* '<S86>/MATLAB Function' */
  real_T isEP_e;                       /* '<S291>/decode robot' */
  real_T isHumanEXO;                   /* '<S291>/decode robot' */
  real_T isNHPEXO;                     /* '<S291>/decode robot' */
  real_T isClassicExo_e;               /* '<S291>/decode robot' */
  real_T isUTSEXO;                     /* '<S291>/decode robot' */
  real_T isPMAC_a;                     /* '<S291>/decode robot' */
  real_T isECAT_i;                     /* '<S291>/decode robot' */
  real_T isEP_a;                       /* '<S290>/decode robot' */
  real_T isHumanEXO_c;                 /* '<S290>/decode robot' */
  real_T isNHPEXO_p;                   /* '<S290>/decode robot' */
  real_T isClassicExo_n;               /* '<S290>/decode robot' */
  real_T isUTSEXO_k;                   /* '<S290>/decode robot' */
  real_T isPMAC_c;                     /* '<S290>/decode robot' */
  real_T isECAT_b;                     /* '<S290>/decode robot' */
  real_T Receive_o2_l;                 /* '<S283>/Receive' */
  real_T DataTypeConversion_o[2];      /* '<S283>/Data Type Conversion' */
  real_T DataTypeConversion1_j[2];     /* '<S283>/Data Type Conversion1' */
  real_T DataTypeConversion2_f;        /* '<S283>/Data Type Conversion2' */
  real_T kinematics[20];               /* '<S283>/MATLAB Function' */
  real_T primary[12];                  /* '<S283>/MATLAB Function' */
  real_T DataTypeConversion_m[6];      /* '<S276>/Data Type Conversion' */
  real_T DataTypeConversion1_i[6];     /* '<S276>/Data Type Conversion1' */
  real_T DataTypeConversion2_h;        /* '<S276>/Data Type Conversion2' */
  real_T kinematics_l[20];             /* '<S276>/MATLAB Function' */
  real_T primary_o[12];                /* '<S276>/MATLAB Function' */
  real_T UnitDelay;                    /* '<S264>/Unit Delay' */
  real_T UnitDelay2;                   /* '<S264>/Unit Delay2' */
  real_T DPRAMReadValue;               /* '<S264>/DPRAM Read Value' */
  real_T UnitDelay1;                   /* '<S264>/Unit Delay1' */
  real_T UnitDelay3;                   /* '<S264>/Unit Delay3' */
  real_T Conversion1[6];               /* '<S262>/Conversion1' */
  real_T Conversion2[6];               /* '<S262>/Conversion2' */
  real_T Conversion7[4];               /* '<S262>/Conversion7' */
  real_T DataTypeConversion3_d[10];    /* '<S262>/Data Type Conversion3' */
  real_T DataTypeConversion4_m[10];    /* '<S262>/Data Type Conversion4' */
  real_T robot1DataOut[10];            /* '<S262>/filter_velocities' */
  real_T robot2DataOut[10];            /* '<S262>/filter_velocities' */
  real_T robot1DataOut_k[10];          /* '<S262>/Robot_data_builder' */
  real_T robot2DataOut_i[10];          /* '<S262>/Robot_data_builder' */
  real_T robot1PrimaryEncDataOut[6];   /* '<S262>/Robot_data_builder' */
  real_T robot2PrimaryEncDataOut[6];   /* '<S262>/Robot_data_builder' */
  real_T force_scale;                  /* '<S262>/Monitor_status' */
  real_T DataTypeConversion1_g;        /* '<S269>/Data Type Conversion1' */
  real_T Uk1;                          /* '<S256>/Delay Input1' */
  real_T ReceivefromRobot1ForceSensor_o2;
                                /* '<S252>/Receive from Robot 1 Force Sensor' */
  real_T Switch_m[7];                  /* '<S252>/Switch' */
  real_T Uk1_o;                        /* '<S260>/Delay Input1' */
  real_T ReceivefromRobot2ForceSensor_o2;
                                /* '<S253>/Receive from Robot 2 Force Sensor' */
  real_T Switch1_g[7];                 /* '<S253>/Switch1' */
  real_T TmpSignalConversionAtSFunctionInport1_a[14];/* '<S67>/MATLAB Function' */
  real_T measures_out[14];             /* '<S67>/MATLAB Function' */
  real_T DataTypeConversion1_o[6];     /* '<S253>/Data Type Conversion1' */
  real_T DataTypeConversion_e[6];      /* '<S252>/Data Type Conversion' */
  real_T intAddresses[24];             /* '<S66>/sdo_addrs' */
  real_T floatAddresses[24];           /* '<S66>/sdo_addrs' */
  real_T errVals[12];                  /* '<S66>/latch_errors' */
  real_T DCErrVals[12];                /* '<S66>/latch_errors' */
  real_T Memory_k;                     /* '<S162>/Memory' */
  real_T Memory_j;                     /* '<S163>/Memory' */
  real_T Memory1_ew;                   /* '<S172>/Memory1' */
  real_T A2M1Convert[5];               /* '<S177>/A2M1Convert' */
  real_T offsetrads;                   /* '<S180>/L2 select' */
  real_T encorient;                    /* '<S180>/L2 select1' */
  real_T L2select2;                    /* '<S180>/L2 select2' */
  real_T L2select3;                    /* '<S180>/L2 select3' */
  real_T L2select4;                    /* '<S180>/L2 select4' */
  real_T R2_maxContinuousTorque[2];    /* '<S78>/Memory2' */
  real_T L2select5;                    /* '<S180>/L2 select5' */
  real_T R2_constantsReady;            /* '<S78>/Memory3' */
  real_T A2M2Convert[5];               /* '<S197>/A2M2Convert' */
  real_T L2select;                     /* '<S200>/L2 select' */
  real_T L2select1;                    /* '<S200>/L2 select1' */
  real_T L2select2_m;                  /* '<S200>/L2 select2' */
  real_T L2select3_l;                  /* '<S200>/L2 select3' */
  real_T L2select4_o;                  /* '<S200>/L2 select4' */
  real_T L2select5_k;                  /* '<S200>/L2 select5' */
  real_T R2M1_LinkAngle;               /* '<S78>/Signal Conversion' */
  real_T R2M2_LinkAngle;               /* '<S78>/Signal Conversion' */
  real_T R2M2_PrimaryLinkAngle;        /* '<S78>/Signal Conversion' */
  real_T R2M2_PrimaryLinkVelocity;     /* '<S78>/Signal Conversion' */
  real_T R2M2_RecordedTorque;          /* '<S78>/Signal Conversion' */
  real_T R2M2_digitalInputs[2];        /* '<S78>/Signal Conversion' */
  real_T R2M2_digitalDiagnostics;      /* '<S78>/Signal Conversion' */
  real_T R2M2_EMCY_codes[5];           /* '<S78>/Signal Conversion' */
  real_T R2M1_PrimaryLinkAngle;        /* '<S78>/Signal Conversion' */
  real_T R2M1_PrimaryLinkVelocity;     /* '<S78>/Signal Conversion' */
  real_T R2M1_RecordedTorque;          /* '<S78>/Signal Conversion' */
  real_T R2M1_digitalInputs[2];        /* '<S78>/Signal Conversion' */
  real_T R2M1_digitalDiagnostics;      /* '<S78>/Signal Conversion' */
  real_T R2_calibrationButton;         /* '<S78>/Signal Conversion' */
  real_T R2M1_EMCY_codes[5];           /* '<S78>/Signal Conversion' */
  real_T R2_RobotType;                 /* '<S78>/Signal Conversion1' */
  real_T R2_absAngleOffset[2];         /* '<S78>/Signal Conversion1' */
  real_T R2_LinkLength[2];             /* '<S78>/Signal Conversion1' */
  real_T R2_L2CalibPinOffset;          /* '<S78>/Signal Conversion1' */
  real_T R2_maxContinuousTorque_c[2];  /* '<S78>/Signal Conversion1' */
  real_T R2_gearRatios[2];             /* '<S78>/Signal Conversion1' */
  real_T R2_isCalibrated;              /* '<S78>/Signal Conversion1' */
  real_T R2_OffsetRads[2];             /* '<S78>/Signal Conversion1' */
  real_T R2_OffsetRadsPrimary[2];      /* '<S78>/Signal Conversion1' */
  real_T R2_RobotRevision;             /* '<S78>/Signal Conversion1' */
  real_T R2_constantsReady_b;          /* '<S78>/Signal Conversion1' */
  real_T R2_hasSecondary;              /* '<S78>/Signal Conversion1' */
  real_T R2_hasFT;                     /* '<S78>/Signal Conversion1' */
  real_T R2_robotOrientation;          /* '<S78>/Signal Conversion1' */
  real_T R2_motorOrientation[2];       /* '<S78>/Signal Conversion1' */
  real_T R2_encOrientation[2];         /* '<S78>/Signal Conversion1' */
  real_T R2_encodercounts[2];          /* '<S78>/Signal Conversion1' */
  real_T R2_FTSensorAngleOffset;       /* '<S78>/Signal Conversion1' */
  real_T R2_calibPinAngle[2];          /* '<S78>/Signal Conversion1' */
  real_T RateTransition1_p;            /* '<S172>/Rate Transition1' */
  real_T hasSecondary;                 /* '<S78>/split out constants1' */
  real_T hasFT;                        /* '<S78>/split out constants1' */
  real_T robotOrientation;             /* '<S78>/split out constants1' */
  real_T motorOrientation[2];          /* '<S78>/split out constants1' */
  real_T encOrientation[2];            /* '<S78>/split out constants1' */
  real_T absEnc;                       /* '<S78>/split out constants1' */
  real_T encoderCounts[2];             /* '<S78>/split out constants' */
  real_T FTSensorOffset;               /* '<S78>/split out constants' */
  real_T calibPinAngles[2];            /* '<S78>/split out constants' */
  real_T absAngOffsets[2];             /* '<S78>/split out constants' */
  real_T linkLengths[2];               /* '<S78>/split out constants' */
  real_T L2CalibPinOffset;             /* '<S78>/split out constants' */
  real_T continuousTorques[2];         /* '<S78>/split out constants' */
  real_T gearRatios[2];                /* '<S78>/split out constants' */
  real_T isCalibrated;                 /* '<S78>/split out constants' */
  real_T offsetRads[2];                /* '<S78>/split out constants' */
  real_T offsetRadsPrimary[2];         /* '<S78>/split out constants' */
  real_T robotRevision_g;              /* '<S78>/split out constants' */
  real_T constantsReady;               /* '<S78>/split out constants' */
  real_T TmpSignalConversionAtSFunctionInport6[2];/* '<S78>/forceEnableDisable' */
  real_T forceMotorState;              /* '<S78>/forceEnableDisable' */
  real_T writeData[5];                 /* '<S169>/writeData' */
  real_T status;                       /* '<S169>/status' */
  real_T readAddr[3];                  /* '<S168>/readAddr' */
  real_T convert_b;                    /* '<S168>/convert' */
  real_T convert1;                     /* '<S168>/convert1' */
  real_T convert2;                     /* '<S168>/convert2' */
  real_T convert3;                     /* '<S168>/convert3' */
  real_T status_f;                     /* '<S168>/status' */
  real_T DataTypeConversion_a;         /* '<S222>/Data Type Conversion' */
  real_T DataTypeConversion1_e;        /* '<S222>/Data Type Conversion1' */
  real_T floatSDOValues[20];           /* '<S78>/SDO read machine' */
  real_T LinkAngle;                    /* '<S200>/countsToRads' */
  real_T PrimaryLinkAngle;             /* '<S200>/countsToRads' */
  real_T PrimaryLinkVel;               /* '<S200>/countsToRads' */
  real_T torque;                       /* '<S200>/countsToRads' */
  real_T digitalInputs[2];             /* '<S200>/countsToRads' */
  real_T digitalDiagnostics;           /* '<S200>/countsToRads' */
  real_T DataTypeConversion_mm;        /* '<S199>/Data Type Conversion' */
  real_T driveID;                      /* '<S199>/driveID' */
  real_T DataTypeConversion2_ht[3];    /* '<S209>/Data Type Conversion2' */
  real_T DataTypeConversion_p1[3];     /* '<S210>/Data Type Conversion' */
  real_T Memory_g;                     /* '<S211>/Memory' */
  real_T DataTypeConversion1_gy;       /* '<S211>/Data Type Conversion1' */
  real_T LinkAngle_i;                  /* '<S180>/countsToRads' */
  real_T PrimaryLinkAngle_j;           /* '<S180>/countsToRads' */
  real_T PrimaryLinkVel_k;             /* '<S180>/countsToRads' */
  real_T torque_h;                     /* '<S180>/countsToRads' */
  real_T digitalInputs_g[2];           /* '<S180>/countsToRads' */
  real_T digitalDiagnostics_p;         /* '<S180>/countsToRads' */
  real_T calibrationButton;            /* '<S180>/countsToRads' */
  real_T DataTypeConversion_pw;        /* '<S179>/Data Type Conversion' */
  real_T driveID_d;                    /* '<S179>/driveID' */
  real_T DataTypeConversion2_b[3];     /* '<S189>/Data Type Conversion2' */
  real_T DataTypeConversion_n[3];      /* '<S190>/Data Type Conversion' */
  real_T Memory_e;                     /* '<S191>/Memory' */
  real_T DataTypeConversion1_l;        /* '<S191>/Data Type Conversion1' */
  real_T Memory_p;                     /* '<S87>/Memory' */
  real_T Memory_jp;                    /* '<S88>/Memory' */
  real_T Memory1_g;                    /* '<S97>/Memory1' */
  real_T A1M1Convert[5];               /* '<S102>/A1M1Convert' */
  real_T L2select_k;                   /* '<S105>/L2 select' */
  real_T L2select1_p;                  /* '<S105>/L2 select1' */
  real_T L2select2_l;                  /* '<S105>/L2 select2' */
  real_T L2select3_a;                  /* '<S105>/L2 select3' */
  real_T L2select4_g;                  /* '<S105>/L2 select4' */
  real_T R1_maxContinuousTorque[2];    /* '<S77>/Memory2' */
  real_T L2select5_o;                  /* '<S105>/L2 select5' */
  real_T R1_constantsReady;            /* '<S77>/Memory3' */
  real_T A1M2Convert[5];               /* '<S122>/A1M2Convert' */
  real_T L2select_p;                   /* '<S125>/L2 select' */
  real_T L2select1_pl;                 /* '<S125>/L2 select1' */
  real_T L2select2_mv;                 /* '<S125>/L2 select2' */
  real_T L2select3_i;                  /* '<S125>/L2 select3' */
  real_T L2select4_k;                  /* '<S125>/L2 select4' */
  real_T L2select5_j;                  /* '<S125>/L2 select5' */
  real_T R1M1_LinkAngle;               /* '<S77>/Signal Conversion' */
  real_T R1M2_LinkAngle;               /* '<S77>/Signal Conversion' */
  real_T R1M2_PrimaryLinkAngle;        /* '<S77>/Signal Conversion' */
  real_T R1M2_PrimaryLinkVelocity;     /* '<S77>/Signal Conversion' */
  real_T R1M2_RecordedTorque;          /* '<S77>/Signal Conversion' */
  real_T R1M2_digitalInputs[2];        /* '<S77>/Signal Conversion' */
  real_T R1M2_digitalDiagnostics;      /* '<S77>/Signal Conversion' */
  real_T R1M2_EMCY_codes[5];           /* '<S77>/Signal Conversion' */
  real_T R1M1_PrimaryLinkAngle;        /* '<S77>/Signal Conversion' */
  real_T R1M1_PrimaryLinkVelocity;     /* '<S77>/Signal Conversion' */
  real_T R1M1_RecordedTorque;          /* '<S77>/Signal Conversion' */
  real_T R1M1_digitalInputs[2];        /* '<S77>/Signal Conversion' */
  real_T R1M1_digitalDiagnostics;      /* '<S77>/Signal Conversion' */
  real_T R1_calibrationButton;         /* '<S77>/Signal Conversion' */
  real_T R1M1_EMCY_codes[5];           /* '<S77>/Signal Conversion' */
  real_T R1_RobotType;                 /* '<S77>/Signal Conversion1' */
  real_T R1_absAngleOffset[2];         /* '<S77>/Signal Conversion1' */
  real_T R1_LinkLength[2];             /* '<S77>/Signal Conversion1' */
  real_T R1_L2CalibPinOffset;          /* '<S77>/Signal Conversion1' */
  real_T R1_maxContinuousTorque_i[2];  /* '<S77>/Signal Conversion1' */
  real_T R1_gearRatios[2];             /* '<S77>/Signal Conversion1' */
  real_T R1_isCalibrated;              /* '<S77>/Signal Conversion1' */
  real_T R1_OffsetRads[2];             /* '<S77>/Signal Conversion1' */
  real_T R1_OffsetRadsPrimary[2];      /* '<S77>/Signal Conversion1' */
  real_T R1_RobotRevision;             /* '<S77>/Signal Conversion1' */
  real_T R1_constantsReady_p;          /* '<S77>/Signal Conversion1' */
  real_T R1_hasSecondary;              /* '<S77>/Signal Conversion1' */
  real_T R1_hasFT;                     /* '<S77>/Signal Conversion1' */
  real_T R1_robotOrientation;          /* '<S77>/Signal Conversion1' */
  real_T R1_motorOrientation[2];       /* '<S77>/Signal Conversion1' */
  real_T R1_encOrientation[2];         /* '<S77>/Signal Conversion1' */
  real_T R1_encodercounts[2];          /* '<S77>/Signal Conversion1' */
  real_T R1_FTSensorAngleOffset;       /* '<S77>/Signal Conversion1' */
  real_T R1_calibPinAngle[2];          /* '<S77>/Signal Conversion1' */
  real_T RateTransition1_i;            /* '<S97>/Rate Transition1' */
  real_T hasSecondary_l;               /* '<S77>/split out constants1' */
  real_T hasFT_c;                      /* '<S77>/split out constants1' */
  real_T robotOrientation_o;           /* '<S77>/split out constants1' */
  real_T motorOrientation_j[2];        /* '<S77>/split out constants1' */
  real_T encOrientation_m[2];          /* '<S77>/split out constants1' */
  real_T absEnc_m;                     /* '<S77>/split out constants1' */
  real_T encoderCounts_j[2];           /* '<S77>/split out constants' */
  real_T FTSensorOffset_k;             /* '<S77>/split out constants' */
  real_T calibPinAngles_i[2];          /* '<S77>/split out constants' */
  real_T absAngOffsets_p[2];           /* '<S77>/split out constants' */
  real_T linkLengths_p[2];             /* '<S77>/split out constants' */
  real_T L2CalibPinOffset_e;           /* '<S77>/split out constants' */
  real_T continuousTorques_m[2];       /* '<S77>/split out constants' */
  real_T gearRatios_j[2];              /* '<S77>/split out constants' */
  real_T isCalibrated_j;               /* '<S77>/split out constants' */
  real_T offsetRads_a[2];              /* '<S77>/split out constants' */
  real_T offsetRadsPrimary_f[2];       /* '<S77>/split out constants' */
  real_T robotRevision_h;              /* '<S77>/split out constants' */
  real_T constantsReady_p;             /* '<S77>/split out constants' */
  real_T TmpSignalConversionAtSFunctionInport6_k[2];/* '<S77>/forceEnableDisable' */
  real_T forceMotorState_o;            /* '<S77>/forceEnableDisable' */
  real_T writeData_g[5];               /* '<S95>/writeData' */
  real_T status_d;                     /* '<S95>/status' */
  real_T readAddr_a[3];                /* '<S94>/readAddr' */
  real_T convert_o;                    /* '<S94>/convert' */
  real_T convert1_n;                   /* '<S94>/convert1' */
  real_T convert2_e;                   /* '<S94>/convert2' */
  real_T convert3_b;                   /* '<S94>/convert3' */
  real_T status_n;                     /* '<S94>/status' */
  real_T DataTypeConversion_bj;        /* '<S148>/Data Type Conversion' */
  real_T DataTypeConversion1_j1;       /* '<S148>/Data Type Conversion1' */
  real_T floatSDOValues_d[20];         /* '<S77>/SDO read machine' */
  real_T LinkAngle_a;                  /* '<S125>/countsToRads' */
  real_T PrimaryLinkAngle_f;           /* '<S125>/countsToRads' */
  real_T PrimaryLinkVel_d;             /* '<S125>/countsToRads' */
  real_T torque_l;                     /* '<S125>/countsToRads' */
  real_T digitalInputs_p[2];           /* '<S125>/countsToRads' */
  real_T digitalDiagnostics_b;         /* '<S125>/countsToRads' */
  real_T DataTypeConversion_bu;        /* '<S124>/Data Type Conversion' */
  real_T driveID_o;                    /* '<S124>/driveID' */
  real_T DataTypeConversion2_g[3];     /* '<S134>/Data Type Conversion2' */
  real_T DataTypeConversion_l[3];      /* '<S135>/Data Type Conversion' */
  real_T Memory_ju;                    /* '<S136>/Memory' */
  real_T DataTypeConversion1_m;        /* '<S136>/Data Type Conversion1' */
  real_T LinkAngle_b;                  /* '<S105>/countsToRads' */
  real_T PrimaryLinkAngle_h;           /* '<S105>/countsToRads' */
  real_T PrimaryLinkVel_b;             /* '<S105>/countsToRads' */
  real_T torque_l0;                    /* '<S105>/countsToRads' */
  real_T digitalInputs_o[2];           /* '<S105>/countsToRads' */
  real_T digitalDiagnostics_a;         /* '<S105>/countsToRads' */
  real_T calibrationButton_n;          /* '<S105>/countsToRads' */
  real_T DataTypeConversion_lz;        /* '<S104>/Data Type Conversion' */
  real_T driveID_p;                    /* '<S104>/driveID' */
  real_T DataTypeConversion2_i[3];     /* '<S114>/Data Type Conversion2' */
  real_T DataTypeConversion_lg[3];     /* '<S115>/Data Type Conversion' */
  real_T Memory_es;                    /* '<S116>/Memory' */
  real_T DataTypeConversion1_m3;       /* '<S116>/Data Type Conversion1' */
  real_T Convert19_h[14];              /* '<S29>/Convert19' */
  real_T RateTransition_a;             /* '<S29>/Rate Transition' */
  real_T RateTransition1_ot;           /* '<S29>/Rate Transition1' */
  real_T Receive1_o2;                  /* '<S61>/Receive1' */
  real_T forces[3];                    /* '<S61>/parse packet 1' */
  real_T moments[3];                   /* '<S61>/parse packet 1' */
  real_T timer;                        /* '<S61>/parse packet 1' */
  real_T Receive_o2_b;                 /* '<S60>/Receive' */
  real_T forces_e[3];                  /* '<S60>/parse packet 1' */
  real_T moments_i[3];                 /* '<S60>/parse packet 1' */
  real_T timer_a;                      /* '<S60>/parse packet 1' */
  real_T Receive_o2_c;                 /* '<S52>/Receive' */
  real_T RateTransition2_a;            /* '<S54>/Rate Transition2' */
  real_T TaskClock_e;                  /* '<S28>/Task Clock' */
  real_T trigger;                      /* '<S52>/Memory2' */
  real_T Memory1_m;                    /* '<S52>/Memory1' */
  real_T strobe_out;                   /* '<S54>/force strobe' */
  real_T resetUDP;                     /* '<S28>/Send Control Machine' */
  real_T UnitDelay_h;                  /* '<S55>/Unit Delay' */
  real_T Sum;                          /* '<S55>/Sum' */
  real_T Width;                        /* '<S50>/Width' */
  real_T IdealFramesPerPacket;         /* '<S50>/Ideal Frames Per Packet' */
  real_T MinMax_b;                     /* '<S50>/MinMax' */
  real_T MathFunction;                 /* '<S50>/Math Function' */
  real_T Subtract_h;                   /* '<S50>/Subtract' */
  real_T Product_i0;                   /* '<S50>/Product' */
  real_T dd_out[2];                    /* '<S44>/MATLAB Function' */
  uint32_T DataTypeConversion3_m;      /* '<S336>/Data Type Conversion3' */
  uint32_T Output;                     /* '<S350>/Output' */
  uint32_T Subtract_a;                 /* '<S336>/Subtract' */
  uint32_T Convert24;                  /* '<S3>/Convert24' */
  uint32_T Convert20;                  /* '<S3>/Convert20' */
  uint32_T Convert19_e;                /* '<S3>/Convert19' */
  uint32_T Convert21;                  /* '<S3>/Convert21' */
  uint32_T Convert22;                  /* '<S3>/Convert22' */
  uint32_T Convert23;                  /* '<S3>/Convert23' */
  uint32_T total_trials_in_exam;       /* '<S337>/Data Type Conversion' */
  uint32_T total_trials_in_block;      /* '<S337>/Data Type Conversion1' */
  uint32_T total_blocks_in_exam;       /* '<S337>/Data Type Conversion2' */
  uint32_T FixPtSum1;                  /* '<S352>/FixPt Sum1' */
  uint32_T FixPtSwitch;                /* '<S353>/FixPt Switch' */
  uint32_T readDigitaldiag[4];         /* '<S1>/read Digital diag' */
  uint32_T touint[8];                  /* '<S25>/touint' */
  uint32_T Unpack;                     /* '<S9>/Unpack' */
  uint32_T Output_h;                   /* '<S46>/Output' */
  uint32_T FixPtSum1_h;                /* '<S48>/FixPt Sum1' */
  uint32_T FixPtSwitch_c;              /* '<S49>/FixPt Switch' */
  uint32_T Width2;                     /* '<S336>/Width2' */
  uint32_T frame_number;               /* '<S383>/Pack VCodeFrame2' */
  uint32_T task_status;            /* '<S336>/Task Execution Control Machine' */
  uint32_T tp;                     /* '<S336>/Task Execution Control Machine' */
  uint32_T block_idx;              /* '<S336>/Task Execution Control Machine' */
  uint32_T trial_in_block;         /* '<S336>/Task Execution Control Machine' */
  uint32_T block_in_set;           /* '<S336>/Task Execution Control Machine' */
  uint32_T trial_in_set;           /* '<S336>/Task Execution Control Machine' */
  uint32_T SFunction_o1;               /* '<S31>/S-Function' */
  uint32_T SFunction_o18[3];           /* '<S31>/S-Function' */
  uint32_T RateTransition3_c;          /* '<S31>/Rate Transition3' */
  uint32_T Output_n;                   /* '<S275>/Output' */
  uint32_T Output_hd;                  /* '<S80>/Output' */
  uint32_T TmpRTBAtDatawriteInport4;   /* '<S69>/Data receive' */
  uint32_T TmpRTBAtDatawriteInport5[7];/* '<S69>/Data receive' */
  uint32_T FixPtSum1_j;                /* '<S236>/FixPt Sum1' */
  uint32_T FixPtSwitch_e;              /* '<S237>/FixPt Switch' */
  uint32_T FixPtSum1_l;                /* '<S280>/FixPt Sum1' */
  uint32_T FixPtSwitch_f;              /* '<S281>/FixPt Switch' */
  uint32_T ServoRead;                  /* '<S73>/Servo Read' */
  uint32_T DataStoreRead_d;            /* '<S73>/Data Store Read' */
  uint32_T Output_o;                   /* '<S296>/Output' */
  uint32_T FixPtSum1_c;                /* '<S301>/FixPt Sum1' */
  uint32_T FixPtSwitch_i;              /* '<S302>/FixPt Switch' */
  uint32_T Statusread[7];              /* '<S73>/Status read' */
  uint32_T statusInts[4];              /* '<S73>/bitpack' */
  uint32_T outStatus[7];               /* '<S263>/update status format' */
  uint32_T DataTypeConversion1_b[2];   /* '<S86>/Data Type Conversion1' */
  uint32_T DataTypeConversion_g0[8];   /* '<S86>/Data Type Conversion' */
  uint32_T DataTypeConversion4_l[4];   /* '<S86>/Data Type Conversion4' */
  uint32_T DataTypeConversion2_h2;     /* '<S86>/Data Type Conversion2' */
  uint32_T servoCounterOut;            /* '<S86>/create servo counter' */
  uint32_T TmpSignalConversionAtSFunctionInport4_c[4];/* '<S86>/create kinematics' */
  uint32_T bitField;                   /* '<S86>/convert to bit field' */
  uint32_T Output_d;                   /* '<S286>/Output' */
  uint32_T FixPtSum1_g;                /* '<S288>/FixPt Sum1' */
  uint32_T FixPtSwitch_o;              /* '<S289>/FixPt Switch' */
  uint32_T Constant_d;                 /* '<S283>/Constant' */
  uint32_T Constant1[7];               /* '<S283>/Constant1' */
  uint32_T Constant_k;                 /* '<S276>/Constant' */
  uint32_T Constant1_f[7];             /* '<S276>/Constant1' */
  uint32_T SFunction_o3[2];            /* '<S262>/S-Function' */
  uint32_T SFunction_o7;               /* '<S262>/S-Function' */
  uint32_T SFunction_o8;               /* '<S262>/S-Function' */
  uint32_T SFunction_o9[3];            /* '<S262>/S-Function' */
  uint32_T DataTypeConversion_g5;      /* '<S264>/Data Type Conversion' */
  uint32_T Convert2_o[3];              /* '<S262>/Convert2' */
  uint32_T MinMax_o;                   /* '<S262>/MinMax' */
  uint32_T MinMax1;                    /* '<S262>/MinMax1' */
  uint32_T DataTypeConversion_n3;      /* '<S271>/Data Type Conversion' */
  uint32_T DataTypeConversion_c;       /* '<S269>/Data Type Conversion' */
  uint32_T DataTypeConversion2_o;      /* '<S269>/Data Type Conversion2' */
  uint32_T Unpack_o1[3];               /* '<S252>/Unpack' */
  uint32_T ByteReversal1[3];           /* '<S252>/Byte Reversal1' */
  uint32_T Unpack1_o1[3];              /* '<S253>/Unpack1' */
  uint32_T ByteReversal1_f[3];         /* '<S253>/Byte Reversal1' */
  uint32_T TmpSignalConversionAtSFunctionInport2_f[2];/* '<S67>/MATLAB Function' */
  uint32_T status_out[2];              /* '<S67>/MATLAB Function' */
  uint32_T ByteReversal;               /* '<S259>/Byte Reversal' */
  uint32_T ByteReversal2;              /* '<S257>/Byte Reversal2' */
  uint32_T drive1;                     /* '<S81>/update digital outputs' */
  uint32_T drive2;                     /* '<S81>/update digital outputs' */
  uint32_T drive3;                     /* '<S81>/update digital outputs' */
  uint32_T drive4;                     /* '<S81>/update digital outputs' */
  uint32_T BKINPDOReceiveElmoDrive_o2; /* '<S177>/BKIN PDO Receive ElmoDrive' */
  uint32_T Switch_l;                   /* '<S183>/Switch' */
  uint32_T statusregister;             /* '<S197>/BKIN PDO Receive ElmoDrive' */
  uint32_T Switch_j;                   /* '<S203>/Switch' */
  uint32_T R2M1_CurrentLimitEnabled;   /* '<S78>/Signal Conversion' */
  uint32_T R2M2_CurrentLimitEnabled;   /* '<S78>/Signal Conversion' */
  uint32_T BKINEtherCATAsyncSDOUpload1_o1;
                                  /* '<S233>/BKIN EtherCAT Async SDO Upload1' */
  uint32_T BKINEtherCATAsyncSDOUpload1_o3;
                                  /* '<S233>/BKIN EtherCAT Async SDO Upload1' */
  uint32_T BKINEtherCATAsyncSDODownload_o2;
                                 /* '<S169>/BKIN EtherCAT Async SDO Download' */
  uint32_T BKINEtherCATAsyncSDOUpload1_o1_o;
                                  /* '<S222>/BKIN EtherCAT Async SDO Upload1' */
  uint32_T BKINEtherCATAsyncSDOUpload1_o3_h;
                                  /* '<S222>/BKIN EtherCAT Async SDO Upload1' */
  uint32_T BKINEtherCATAsyncSDOUpload1_o1_g;
                                  /* '<S221>/BKIN EtherCAT Async SDO Upload1' */
  uint32_T BKINEtherCATAsyncSDOUpload1_o3_p;
                                  /* '<S221>/BKIN EtherCAT Async SDO Upload1' */
  uint32_T BKINEtherCATAsyncSDODownload_o2_f;
                                 /* '<S166>/BKIN EtherCAT Async SDO Download' */
  uint32_T BKINEtherCATAsyncSDOUpload_o3;
                                   /* '<S166>/BKIN EtherCAT Async SDO Upload' */
  uint32_T BKINEtherCATAsyncSDODownload_o2_g;
                                 /* '<S165>/BKIN EtherCAT Async SDO Download' */
  uint32_T BKINEtherCATAsyncSDOUpload_o3_c;
                                   /* '<S165>/BKIN EtherCAT Async SDO Upload' */
  uint32_T Memory_gv[3];               /* '<S209>/Memory' */
  uint32_T BKINEtherCATAsyncSDOUpload_o1;
                                   /* '<S209>/BKIN EtherCAT Async SDO Upload' */
  uint32_T BKINEtherCATAsyncSDOUpload_o3_l;
                                   /* '<S209>/BKIN EtherCAT Async SDO Upload' */
  uint32_T DataTypeConversion1_my;     /* '<S209>/Data Type Conversion1' */
  uint32_T RateTransition_l[3];        /* '<S209>/Rate Transition' */
  uint32_T BKINEtherCATAsyncSDOUpload_o3_e;
                                   /* '<S210>/BKIN EtherCAT Async SDO Upload' */
  uint32_T BKINEtherCATAsyncSDODownload_o2_h;
                                 /* '<S211>/BKIN EtherCAT Async SDO Download' */
  uint32_T Memory_c[3];                /* '<S189>/Memory' */
  uint32_T BKINEtherCATAsyncSDOUpload_o1_n;
                                   /* '<S189>/BKIN EtherCAT Async SDO Upload' */
  uint32_T BKINEtherCATAsyncSDOUpload_o3_h;
                                   /* '<S189>/BKIN EtherCAT Async SDO Upload' */
  uint32_T DataTypeConversion1_n;      /* '<S189>/Data Type Conversion1' */
  uint32_T RateTransition_m[3];        /* '<S189>/Rate Transition' */
  uint32_T BKINEtherCATAsyncSDOUpload_o3_e5;
                                   /* '<S190>/BKIN EtherCAT Async SDO Upload' */
  uint32_T BKINEtherCATAsyncSDODownload_o2_b;
                                 /* '<S191>/BKIN EtherCAT Async SDO Download' */
  uint32_T statusregister_n;           /* '<S102>/BKIN PDO Receive ElmoDrive' */
  uint32_T Switch_d;                   /* '<S108>/Switch' */
  uint32_T statusregister_h;           /* '<S122>/BKIN PDO Receive ElmoDrive' */
  uint32_T Switch_p;                   /* '<S128>/Switch' */
  uint32_T R1M1_CurrentLimitEnabled;   /* '<S77>/Signal Conversion' */
  uint32_T R1M2_CurrentLimitEnabled;   /* '<S77>/Signal Conversion' */
  uint32_T BKINEtherCATAsyncSDOUpload1_o1_e;
                                  /* '<S159>/BKIN EtherCAT Async SDO Upload1' */
  uint32_T BKINEtherCATAsyncSDOUpload1_o3_py;
                                  /* '<S159>/BKIN EtherCAT Async SDO Upload1' */
  uint32_T BKINEtherCATAsyncSDODownload_o2_a;
                                  /* '<S95>/BKIN EtherCAT Async SDO Download' */
  uint32_T BKINEtherCATAsyncSDOUpload1_o1_oc;
                                  /* '<S148>/BKIN EtherCAT Async SDO Upload1' */
  uint32_T BKINEtherCATAsyncSDOUpload1_o3_b;
                                  /* '<S148>/BKIN EtherCAT Async SDO Upload1' */
  uint32_T BKINEtherCATAsyncSDOUpload1_o1_p;
                                  /* '<S147>/BKIN EtherCAT Async SDO Upload1' */
  uint32_T BKINEtherCATAsyncSDOUpload1_o3_a;
                                  /* '<S147>/BKIN EtherCAT Async SDO Upload1' */
  uint32_T BKINEtherCATAsyncSDODownload_o2_b4;
                                  /* '<S92>/BKIN EtherCAT Async SDO Download' */
  uint32_T BKINEtherCATAsyncSDOUpload_o3_k;
                                    /* '<S92>/BKIN EtherCAT Async SDO Upload' */
  uint32_T BKINEtherCATAsyncSDODownload_o2_n;
                                  /* '<S91>/BKIN EtherCAT Async SDO Download' */
  uint32_T BKINEtherCATAsyncSDOUpload_o3_n;
                                    /* '<S91>/BKIN EtherCAT Async SDO Upload' */
  uint32_T Memory_c4[3];               /* '<S134>/Memory' */
  uint32_T BKINEtherCATAsyncSDOUpload_o1_k;
                                   /* '<S134>/BKIN EtherCAT Async SDO Upload' */
  uint32_T BKINEtherCATAsyncSDOUpload_o3_nd;
                                   /* '<S134>/BKIN EtherCAT Async SDO Upload' */
  uint32_T DataTypeConversion1_nb;     /* '<S134>/Data Type Conversion1' */
  uint32_T RateTransition_n[3];        /* '<S134>/Rate Transition' */
  uint32_T BKINEtherCATAsyncSDOUpload_o3_ea;
                                   /* '<S135>/BKIN EtherCAT Async SDO Upload' */
  uint32_T BKINEtherCATAsyncSDODownload_o2_m;
                                 /* '<S136>/BKIN EtherCAT Async SDO Download' */
  uint32_T Memory_f[3];                /* '<S114>/Memory' */
  uint32_T BKINEtherCATAsyncSDOUpload_o1_d;
                                   /* '<S114>/BKIN EtherCAT Async SDO Upload' */
  uint32_T BKINEtherCATAsyncSDOUpload_o3_cf;
                                   /* '<S114>/BKIN EtherCAT Async SDO Upload' */
  uint32_T DataTypeConversion1_p;      /* '<S114>/Data Type Conversion1' */
  uint32_T RateTransition_kr[3];       /* '<S114>/Rate Transition' */
  uint32_T BKINEtherCATAsyncSDOUpload_o3_p;
                                   /* '<S115>/BKIN EtherCAT Async SDO Upload' */
  uint32_T BKINEtherCATAsyncSDODownload_o2_p;
                                 /* '<S116>/BKIN EtherCAT Async SDO Download' */
  uint32_T DataTypeConversion_pa;      /* '<S52>/Data Type Conversion' */
  uint32_T max_packet_id;              /* '<S28>/max_packet_id' */
  uint32_T Output_a;                   /* '<S56>/Output' */
  uint32_T FixPtSum1_d;                /* '<S57>/FixPt Sum1' */
  uint32_T FixPtSwitch_ii;             /* '<S58>/FixPt Switch' */
  uint32_T bitfield;                   /* '<S25>/bitfield' */
  uint32_T voltagesOK;                 /* '<S23>/monitor voltage bits' */
  real32_T DataTypeConversion6[4];     /* '<S313>/Data Type Conversion6' */
  real32_T DataTypeConversion_nc[6];   /* '<S313>/Data Type Conversion' */
  real32_T DataTypeConversion1_px[6];  /* '<S313>/Data Type Conversion1' */
  real32_T pupil_X[2];                 /* '<S31>/S-Function' */
  real32_T pupilY[2];                  /* '<S31>/S-Function' */
  real32_T HREFX[2];                   /* '<S31>/S-Function' */
  real32_T HREFY[2];                   /* '<S31>/S-Function' */
  real32_T pupilarea[2];               /* '<S31>/S-Function' */
  real32_T gaze_X[2];                  /* '<S31>/S-Function' */
  real32_T gaze_Y[2];                  /* '<S31>/S-Function' */
  real32_T resolutionX;                /* '<S31>/S-Function' */
  real32_T resolutionY;                /* '<S31>/S-Function' */
  real32_T Reshape_a[8];               /* '<S31>/Reshape' */
  real32_T SelectorLeftEye[4];         /* '<S31>/Selector - Left Eye' */
  real32_T Unpack_o1_n[2];             /* '<S283>/Unpack' */
  real32_T Unpack_o2[2];               /* '<S283>/Unpack' */
  real32_T Unpack_o[13];               /* '<S276>/Unpack' */
  real32_T DataTypeConversion_g5x[10]; /* '<S262>/Data Type Conversion' */
  real32_T DataTypeConversion1_pf[10]; /* '<S262>/Data Type Conversion1' */
  real32_T DataTypeConversion2_n;      /* '<S262>/Data Type Conversion2' */
  real32_T SFunction_o1_j[10];         /* '<S262>/S-Function' */
  real32_T SFunction_o2[10];           /* '<S262>/S-Function' */
  real32_T SFunction_o4[4];            /* '<S262>/S-Function' */
  real32_T SFunction_o5[6];            /* '<S262>/S-Function' */
  real32_T SFunction_o6[6];            /* '<S262>/S-Function' */
  real32_T SFunction_o10;              /* '<S262>/S-Function' */
  real32_T y_h;                        /* '<S264>/TypeCast' */
  real32_T DataTypeConversion1_o3;     /* '<S271>/Data Type Conversion1' */
  real32_T Read_h;                     /* '<S269>/Read' */
  real32_T DataTypeConversion2_k;      /* '<S28>/Data Type Conversion2' */
  real32_T RateTransition1_l[400];     /* '<S28>/Rate Transition1' */
  real32_T data_out[410];              /* '<S28>/Send Control Machine' */
  real32_T queue_size;                 /* '<S28>/Send Control Machine' */
  real32_T total_timeouts;             /* '<S28>/Send Control Machine' */
  real32_T DataTypeConversion_i[182];  /* '<S50>/Data Type Conversion' */
  real32_T t2[182];                    /* '<S50>/t-2' */
  real32_T t1[182];                    /* '<S50>/t-1' */
  real32_T TmpSignalConversionAtSelectorInport1[946];
  real32_T Selector_pl[400];           /* '<S50>/Selector' */
  int32_T vis_cmd[6810];               /* '<S383>/Pack VCodeFrame2' */
  int32_T convert_n;                   /* '<S31>/convert' */
  int32_T len_out;                     /* '<S31>/clean_packet' */
  int32_T BKINEtherCATinit1_o1[6];     /* '<S66>/BKIN EtherCATinit1' */
  int32_T BKINEtherCATinit1_o2;        /* '<S66>/BKIN EtherCATinit1' */
  int32_T BKINEtherCATinit1_o3;        /* '<S66>/BKIN EtherCATinit1' */
  int32_T BKINEtherCATinit1_o4[21];    /* '<S66>/BKIN EtherCATinit1' */
  int32_T BKINEtherCATinit_o1[6];      /* '<S66>/BKIN EtherCATinit' */
  int32_T BKINEtherCATinit_o2;         /* '<S66>/BKIN EtherCATinit' */
  int32_T BKINEtherCATinit_o3;         /* '<S66>/BKIN EtherCATinit' */
  int32_T BKINEtherCATinit_o4[21];     /* '<S66>/BKIN EtherCATinit' */
  int32_T Switch_f[8];                 /* '<S66>/Switch' */
  int32_T Bias;                        /* '<S66>/Bias' */
  int32_T convert1_l;                  /* '<S66>/convert1' */
  int32_T Switch1_b[21];               /* '<S66>/Switch1' */
  int32_T Unpack_o2_h[6];              /* '<S252>/Unpack' */
  int32_T ByteReversal_m[6];           /* '<S252>/Byte Reversal' */
  int32_T Unpack1_o2[6];               /* '<S253>/Unpack1' */
  int32_T ByteReversal_c[6];           /* '<S253>/Byte Reversal' */
  int32_T errVal;                      /* '<S82>/split init' */
  int32_T masterState;                 /* '<S82>/split init' */
  int32_T DCErrVal;                    /* '<S82>/split init' */
  int32_T MasterToNetworkClkDiff;      /* '<S82>/split init' */
  int32_T DCInitState;                 /* '<S82>/split init' */
  int32_T NetworkToSlaveClkDiff;       /* '<S82>/split init' */
  int32_T MasterStateOut;              /* '<S82>/master_state' */
  int32_T primaryposition;             /* '<S177>/BKIN PDO Receive ElmoDrive' */
  int32_T secondaryposition;           /* '<S177>/BKIN PDO Receive ElmoDrive' */
  int32_T primaryvelocity;             /* '<S177>/BKIN PDO Receive ElmoDrive' */
  int32_T digitalinput;                /* '<S177>/BKIN PDO Receive ElmoDrive' */
  int32_T readTrigger;                 /* '<S78>/readTrigger' */
  int32_T Memory_o;                    /* '<S172>/Memory' */
  int32_T Memory2_p[2];                /* '<S172>/Memory2' */
  int32_T DataTypeConversion_mme;      /* '<S177>/Data Type Conversion' */
  int32_T positionprimary;             /* '<S197>/BKIN PDO Receive ElmoDrive' */
  int32_T positionsecondary;           /* '<S197>/BKIN PDO Receive ElmoDrive' */
  int32_T velocityprimary;             /* '<S197>/BKIN PDO Receive ElmoDrive' */
  int32_T digitalinput_o;              /* '<S197>/BKIN PDO Receive ElmoDrive' */
  int32_T DataTypeConversion_ex;       /* '<S197>/Data Type Conversion' */
  int32_T RateTransition_ep;           /* '<S172>/Rate Transition' */
  int32_T RateTransition2_j[2];        /* '<S172>/Rate Transition2' */
  int32_T BKINEtherCATAsyncSDOUpload1_o2;
                                  /* '<S233>/BKIN EtherCAT Async SDO Upload1' */
  int32_T Memory_oh[2];                /* '<S169>/Memory' */
  int32_T DataTypeConversion2_i0;      /* '<S169>/Data Type Conversion2' */
  int32_T DataTypeConversion1_du;      /* '<S169>/Data Type Conversion1' */
  int32_T BKINEtherCATAsyncSDODownload_o1;
                                 /* '<S169>/BKIN EtherCAT Async SDO Download' */
  int32_T Conversion1_o;               /* '<S168>/Conversion1' */
  int32_T Conversion2_i;               /* '<S168>/Conversion2' */
  int32_T Memory_ms[2];                /* '<S168>/Memory' */
  int32_T BKINEtherCATAsyncSDOUpload1_o2_n;
                                  /* '<S222>/BKIN EtherCAT Async SDO Upload1' */
  int32_T BKINEtherCATAsyncSDOUpload1_o2_g;
                                  /* '<S221>/BKIN EtherCAT Async SDO Upload1' */
  int32_T SDOCommand[3];               /* '<S78>/SDO read machine' */
  int32_T intSDOValues[20];            /* '<S78>/SDO read machine' */
  int32_T complete;                    /* '<S78>/SDO read machine' */
  int32_T Memory_i;                    /* '<S166>/Memory' */
  int32_T Memory1_n[2];                /* '<S166>/Memory1' */
  int32_T BKINEtherCATAsyncSDODownload_o1_f;
                                 /* '<S166>/BKIN EtherCAT Async SDO Download' */
  int32_T BKINEtherCATAsyncSDOUpload_o1_k1;
                                   /* '<S166>/BKIN EtherCAT Async SDO Upload' */
  int32_T BKINEtherCATAsyncSDOUpload_o2;
                                   /* '<S166>/BKIN EtherCAT Async SDO Upload' */
  int32_T Memory_pj;                   /* '<S165>/Memory' */
  int32_T Memory1_lg[2];               /* '<S165>/Memory1' */
  int32_T BKINEtherCATAsyncSDODownload_o1_d;
                                 /* '<S165>/BKIN EtherCAT Async SDO Download' */
  int32_T BKINEtherCATAsyncSDOUpload_o1_d2;
                                   /* '<S165>/BKIN EtherCAT Async SDO Upload' */
  int32_T BKINEtherCATAsyncSDOUpload_o2_f;
                                   /* '<S165>/BKIN EtherCAT Async SDO Upload' */
  int32_T Memory_ds[3];                /* '<S210>/Memory' */
  int32_T DataTypeConversion_b5;       /* '<S209>/Data Type Conversion' */
  int32_T BKINEtherCATAsyncSDOUpload_o2_p;
                                   /* '<S209>/BKIN EtherCAT Async SDO Upload' */
  int32_T BKINEtherCATAsyncSDOUpload_o1_n3;
                                   /* '<S210>/BKIN EtherCAT Async SDO Upload' */
  int32_T BKINEtherCATAsyncSDOUpload_o2_a;
                                   /* '<S210>/BKIN EtherCAT Async SDO Upload' */
  int32_T RateTransition_g[3];         /* '<S210>/Rate Transition' */
  int32_T DataTypeConversion_j;        /* '<S211>/Data Type Conversion' */
  int32_T BKINEtherCATAsyncSDODownload_o1_h;
                                 /* '<S211>/BKIN EtherCAT Async SDO Download' */
  int32_T Memory_g3[3];                /* '<S190>/Memory' */
  int32_T DataTypeConversion_k;        /* '<S189>/Data Type Conversion' */
  int32_T BKINEtherCATAsyncSDOUpload_o2_l;
                                   /* '<S189>/BKIN EtherCAT Async SDO Upload' */
  int32_T BKINEtherCATAsyncSDOUpload_o1_m;
                                   /* '<S190>/BKIN EtherCAT Async SDO Upload' */
  int32_T BKINEtherCATAsyncSDOUpload_o2_k;
                                   /* '<S190>/BKIN EtherCAT Async SDO Upload' */
  int32_T RateTransition_gq[3];        /* '<S190>/Rate Transition' */
  int32_T DataTypeConversion_if;       /* '<S191>/Data Type Conversion' */
  int32_T BKINEtherCATAsyncSDODownload_o1_f2;
                                 /* '<S191>/BKIN EtherCAT Async SDO Download' */
  int32_T primaryposition_n;           /* '<S102>/BKIN PDO Receive ElmoDrive' */
  int32_T secondaryposition_k;         /* '<S102>/BKIN PDO Receive ElmoDrive' */
  int32_T primaryvelocity_j;           /* '<S102>/BKIN PDO Receive ElmoDrive' */
  int32_T digitalinputs;               /* '<S102>/BKIN PDO Receive ElmoDrive' */
  int32_T readTrigger_l;               /* '<S77>/readTrigger' */
  int32_T Memory_k5;                   /* '<S97>/Memory' */
  int32_T Memory2_a[2];                /* '<S97>/Memory2' */
  int32_T DataTypeConversion1_jv;      /* '<S102>/Data Type Conversion1' */
  int32_T primaryposition_o;           /* '<S122>/BKIN PDO Receive ElmoDrive' */
  int32_T secondaryposition_e;         /* '<S122>/BKIN PDO Receive ElmoDrive' */
  int32_T primaryvelocity_jy;          /* '<S122>/BKIN PDO Receive ElmoDrive' */
  int32_T digitalinputs_n;             /* '<S122>/BKIN PDO Receive ElmoDrive' */
  int32_T DataTypeConversion_ch;       /* '<S122>/Data Type Conversion' */
  int32_T RateTransition_gd;           /* '<S97>/Rate Transition' */
  int32_T RateTransition2_ph[2];       /* '<S97>/Rate Transition2' */
  int32_T BKINEtherCATAsyncSDOUpload1_o2_e;
                                  /* '<S159>/BKIN EtherCAT Async SDO Upload1' */
  int32_T Memory_n[2];                 /* '<S95>/Memory' */
  int32_T DataTypeConversion2_a;       /* '<S95>/Data Type Conversion2' */
  int32_T DataTypeConversion1_p2;      /* '<S95>/Data Type Conversion1' */
  int32_T BKINEtherCATAsyncSDODownload_o1_c;
                                  /* '<S95>/BKIN EtherCAT Async SDO Download' */
  int32_T DataTypeConversion1_iw;      /* '<S94>/Data Type Conversion1' */
  int32_T DataTypeConversion2_h5;      /* '<S94>/Data Type Conversion2' */
  int32_T Memory_g4[2];                /* '<S94>/Memory' */
  int32_T BKINEtherCATAsyncSDOUpload1_o2_c;
                                  /* '<S148>/BKIN EtherCAT Async SDO Upload1' */
  int32_T BKINEtherCATAsyncSDOUpload1_o2_ee;
                                  /* '<S147>/BKIN EtherCAT Async SDO Upload1' */
  int32_T SDOCommand_j[3];             /* '<S77>/SDO read machine' */
  int32_T intSDOValues_m[20];          /* '<S77>/SDO read machine' */
  int32_T complete_b;                  /* '<S77>/SDO read machine' */
  int32_T Memory_ir;                   /* '<S92>/Memory' */
  int32_T Memory1_i[2];                /* '<S92>/Memory1' */
  int32_T BKINEtherCATAsyncSDODownload_o1_h1;
                                  /* '<S92>/BKIN EtherCAT Async SDO Download' */
  int32_T BKINEtherCATAsyncSDOUpload_o1_g;
                                    /* '<S92>/BKIN EtherCAT Async SDO Upload' */
  int32_T BKINEtherCATAsyncSDOUpload_o2_b;
                                    /* '<S92>/BKIN EtherCAT Async SDO Upload' */
  int32_T Memory_my;                   /* '<S91>/Memory' */
  int32_T Memory1_b[2];                /* '<S91>/Memory1' */
  int32_T BKINEtherCATAsyncSDODownload_o1_l;
                                  /* '<S91>/BKIN EtherCAT Async SDO Download' */
  int32_T BKINEtherCATAsyncSDOUpload_o1_kp;
                                    /* '<S91>/BKIN EtherCAT Async SDO Upload' */
  int32_T BKINEtherCATAsyncSDOUpload_o2_pz;
                                    /* '<S91>/BKIN EtherCAT Async SDO Upload' */
  int32_T Memory_iv[3];                /* '<S135>/Memory' */
  int32_T DataTypeConversion_mx;       /* '<S134>/Data Type Conversion' */
  int32_T BKINEtherCATAsyncSDOUpload_o2_i;
                                   /* '<S134>/BKIN EtherCAT Async SDO Upload' */
  int32_T BKINEtherCATAsyncSDOUpload_o1_a;
                                   /* '<S135>/BKIN EtherCAT Async SDO Upload' */
  int32_T BKINEtherCATAsyncSDOUpload_o2_bg;
                                   /* '<S135>/BKIN EtherCAT Async SDO Upload' */
  int32_T RateTransition_h[3];         /* '<S135>/Rate Transition' */
  int32_T DataTypeConversion_pa3;      /* '<S136>/Data Type Conversion' */
  int32_T BKINEtherCATAsyncSDODownload_o1_o;
                                 /* '<S136>/BKIN EtherCAT Async SDO Download' */
  int32_T Memory_gu[3];                /* '<S115>/Memory' */
  int32_T DataTypeConversion_ol;       /* '<S114>/Data Type Conversion' */
  int32_T BKINEtherCATAsyncSDOUpload_o2_lu;
                                   /* '<S114>/BKIN EtherCAT Async SDO Upload' */
  int32_T BKINEtherCATAsyncSDOUpload_o1_ko;
                                   /* '<S115>/BKIN EtherCAT Async SDO Upload' */
  int32_T BKINEtherCATAsyncSDOUpload_o2_h;
                                   /* '<S115>/BKIN EtherCAT Async SDO Upload' */
  int32_T RateTransition_lt[3];        /* '<S115>/Rate Transition' */
  int32_T DataTypeConversion_ll;       /* '<S116>/Data Type Conversion' */
  int32_T BKINEtherCATAsyncSDODownload_o1_p;
                                 /* '<S116>/BKIN EtherCAT Async SDO Download' */
  int32_T Unpack_n;                    /* '<S52>/Unpack' */
  int32_T queue_size_i;                /* '<S28>/Queue Size' */
  int32_T timeouts;                    /* '<S28>/Total Timeouts' */
  uint16_T ContentFlags;               /* '<S31>/S-Function' */
  uint16_T statusflags;                /* '<S31>/S-Function' */
  uint16_T extrainput;                 /* '<S31>/S-Function' */
  uint16_T buttons;                    /* '<S31>/S-Function' */
  uint16_T Output_c;                   /* '<S268>/Output' */
  uint16_T FixPtSum1_lg;               /* '<S272>/FixPt Sum1' */
  uint16_T FixPtSwitch_ey;             /* '<S273>/FixPt Switch' */
  uint16_T ByteReversal1_h;            /* '<S259>/Byte Reversal1' */
  uint16_T Switch_a;                   /* '<S259>/Switch' */
  uint16_T ByteReversal2_j;            /* '<S259>/Byte Reversal2' */
  uint16_T ByteReversal1_l;            /* '<S257>/Byte Reversal1' */
  uint16_T Switch_n;                   /* '<S257>/Switch' */
  uint16_T ByteReversal_h;             /* '<S257>/Byte Reversal' */
  uint16_T Statusword;                 /* '<S177>/BKIN PDO Receive ElmoDrive' */
  uint16_T Switch_g3;                  /* '<S184>/Switch' */
  uint16_T statusword;                 /* '<S197>/BKIN PDO Receive ElmoDrive' */
  uint16_T Switch_mq;                  /* '<S204>/Switch' */
  uint16_T Statusword_d;               /* '<S102>/BKIN PDO Receive ElmoDrive' */
  uint16_T Switch_mm;                  /* '<S109>/Switch' */
  uint16_T Statusword_n;               /* '<S122>/BKIN PDO Receive ElmoDrive' */
  uint16_T Switch_pj;                  /* '<S129>/Switch' */
  int16_T ecatTorques[4];              /* '<S312>/convert torques' */
  int16_T SAMPE_TYPE;                  /* '<S31>/S-Function' */
  int16_T htype;                       /* '<S31>/S-Function' */
  int16_T hdata[8];                    /* '<S31>/S-Function' */
  int16_T torque_b;                    /* '<S177>/BKIN PDO Receive ElmoDrive' */
  int16_T torque_i;                    /* '<S197>/BKIN PDO Receive ElmoDrive' */
  int16_T torque_f;                    /* '<S102>/BKIN PDO Receive ElmoDrive' */
  int16_T torque_m;                    /* '<S122>/BKIN PDO Receive ElmoDrive' */
  uint8_T RunCommandReceive_o1;        /* '<S335>/Run Command Receive' */
  uint8_T DataTypeConversion1_fy;      /* '<S335>/Data Type Conversion1' */
  uint8_T Compare;                     /* '<S343>/Compare' */
  uint8_T Compare_o;                   /* '<S47>/Compare' */
  uint8_T Receive_o1[4];               /* '<S9>/Receive' */
  uint8_T Product_f;                   /* '<S26>/Product' */
  uint8_T DataTypeConversion2_gv;      /* '<S396>/Data Type Conversion2' */
  uint8_T Compare_j;                   /* '<S395>/Compare' */
  uint8_T HiddenBuf_InsertedFor_Ramp_up_down_at_inport_3[3];
  uint8_T SFunctionBuilder_o1[27240];  /* '<S381>/S-Function Builder' */
  uint8_T Receive_o1_o[512];           /* '<S31>/Receive' */
  uint8_T pack_out[512];               /* '<S31>/clean_packet' */
  uint8_T Compare_k;                   /* '<S79>/Compare' */
  uint8_T Receive_o1_i[16];            /* '<S283>/Receive' */
  uint8_T SFunction[52];               /* '<S276>/S-Function' */
  uint8_T FixPtRelationalOperator;     /* '<S256>/FixPt Relational Operator' */
  uint8_T ReceivefromRobot1ForceSensor_o1[36];
                                /* '<S252>/Receive from Robot 1 Force Sensor' */
  uint8_T FixPtRelationalOperator_n;   /* '<S260>/FixPt Relational Operator' */
  uint8_T ReceivefromRobot2ForceSensor_o1[36];
                                /* '<S253>/Receive from Robot 2 Force Sensor' */
  uint8_T Pack[8];                     /* '<S259>/Pack' */
  uint8_T Pack_b[8];                   /* '<S257>/Pack' */
  uint8_T Convert1_a[34];              /* '<S29>/Convert1' */
  uint8_T Receive1_o1[64];             /* '<S61>/Receive1' */
  uint8_T Receive_o1_p[64];            /* '<S60>/Receive' */
  uint8_T Receive_o1_m[21];            /* '<S52>/Receive' */
  uint8_T Pack_c[1640];                /* '<S53>/Pack' */
  uint8_T Pack_i[40];                  /* '<S27>/Pack' */
  int8_T inputevents[2];               /* '<S21>/Collision Resolution' */
  int8_T inputevents_n[4];             /* '<Root>/Trial_Control' */
  int8_T inputevents_c[3];             /* '<S396>/Ramp_up_down' */
  int8_T inputevents_l[2];         /* '<S336>/Task Execution Control Machine' */
  int8_T e_clk;                        /* '<S38>/torque_monitor' */
  int8_T actualmodeofoperation;        /* '<S177>/BKIN PDO Receive ElmoDrive' */
  int8_T actualmodeofoperation_c;      /* '<S197>/BKIN PDO Receive ElmoDrive' */
  int8_T actualmodeofoperation_h;      /* '<S102>/BKIN PDO Receive ElmoDrive' */
  int8_T actualmodeofoperation_hn;     /* '<S122>/BKIN PDO Receive ElmoDrive' */
  int8_T inputevents_j[3];             /* '<S28>/Send Control Machine' */
  boolean_T Uk1_e;                     /* '<S347>/Delay Input1' */
  boolean_T Compare_e;                 /* '<S349>/Compare' */
  boolean_T Delay_h;                   /* '<S336>/Delay' */
  boolean_T FixPtRelationalOperator_g; /* '<S347>/FixPt Relational Operator' */
  boolean_T Uk1_h;                     /* '<S348>/Delay Input1' */
  boolean_T DataTypeConversion1_jo;    /* '<S336>/Data Type Conversion1' */
  boolean_T Memory1_k;                 /* '<Root>/Memory1' */
  boolean_T DataTypeConversion_j0;     /* '<Root>/Data Type Conversion' */
  boolean_T Memory4;                   /* '<Root>/Memory4' */
  boolean_T DataTypeConversion1_pz;    /* '<Root>/Data Type Conversion1' */
  boolean_T FixPtRelationalOperator_f; /* '<S348>/FixPt Relational Operator' */
  boolean_T Convert25;                 /* '<S3>/Convert25' */
  boolean_T DataTypeConversion1_ft;    /* '<S4>/Data Type Conversion1' */
  boolean_T DataTypeConversion_gj;     /* '<S4>/Data Type Conversion' */
  boolean_T Compare_d;                 /* '<S324>/Compare' */
  boolean_T e_Puck_Stopped;            /* '<S21>/Collision Resolution' */
  boolean_T e_Puck_Hit;                /* '<S21>/Collision Resolution' */
  boolean_T logging_enable;            /* '<Root>/Trial_Control' */
  boolean_T e_Trial_Start;             /* '<Root>/Trial_Control' */
  boolean_T e_Trial_End;               /* '<Root>/Trial_Control' */
  boolean_T e_exit_trial;          /* '<S336>/Task Execution Control Machine' */
  boolean_T robot_failures[2];         /* '<S38>/MATLAB Function' */
  boolean_T Compare_n;                 /* '<S314>/Compare' */
  boolean_T Compare_oi;                /* '<S315>/Compare' */
  boolean_T Compare_ny;                /* '<S74>/Compare' */
  boolean_T Compare_e2;                /* '<S285>/Compare' */
  boolean_T Compare_h;                 /* '<S278>/Compare' */
  boolean_T Compare_ec;                /* '<S279>/Compare' */
  boolean_T LogicalOperator;           /* '<S69>/Logical Operator' */
  boolean_T Compare_f;                 /* '<S261>/Compare' */
  boolean_T RateTransition_b;          /* '<S69>/Rate Transition' */
  boolean_T motorEnableState;          /* '<S66>/setState' */
  boolean_T Compare_ew;                /* '<S178>/Compare' */
  boolean_T Compare_c;                 /* '<S198>/Compare' */
  boolean_T R2_EPGripSensor;           /* '<S78>/Signal Conversion' */
  boolean_T epGripSensor;              /* '<S180>/countsToRads' */
  boolean_T Compare_jc;                /* '<S103>/Compare' */
  boolean_T Compare_fs;                /* '<S123>/Compare' */
  boolean_T R1_EPGripSensor;           /* '<S77>/Signal Conversion' */
  boolean_T epGripSensor_i;            /* '<S105>/countsToRads' */
  boolean_T RateTransition1_l1;        /* '<S54>/Rate Transition1' */
  boolean_T RelationalOperator;        /* '<S50>/Relational Operator' */
  B_EmbeddedMATLABFunction_may23_T sf_EmbeddedMATLABFunction_h;/* '<S18>/Embedded MATLAB Function' */
  B_EmbeddedMATLABFunction_may23_d_T sf_EmbeddedMATLABFunction_a;/* '<S17>/Embedded MATLAB Function' */
  B_EmbeddedMATLABFunction_may23_T sf_EmbeddedMATLABFunction_e;/* '<S16>/Embedded MATLAB Function' */
  B_EmbeddedMATLABFunction_may23_d_T sf_EmbeddedMATLABFunction_m;/* '<S15>/Embedded MATLAB Function' */
  B_EmbeddedMATLABFunction_may23_T sf_EmbeddedMATLABFunction_n;/* '<S14>/Embedded MATLAB Function' */
  B_EmbeddedMATLABFunction_may23_T sf_EmbeddedMATLABFunction_p;/* '<S13>/Embedded MATLAB Function' */
  B_Remove_NaNs_and_Inf_may23_T sf_Remove_NaNs_and_Inf_d;/* '<S5>/Remove_NaNs_and_Inf' */
  B_Ramp_Up_Down_may23_g_T sf_Ramp_Up_Down1_h;/* '<S5>/Ramp_Up_Down1' */
  B_Ramp_Up_Down_may23_g_T sf_Ramp_Up_Down_g;/* '<S5>/Ramp_Up_Down' */
  B_MATLABFunction_may23_f_T sf_MATLABFunction_gh;/* '<S361>/MATLAB Function' */
  B_MATLABFunction_may23_f_T sf_MATLABFunction_b;/* '<S360>/MATLAB Function' */
  B_Remove_NaNs_and_Inf_may23_T sf_Remove_NaNs_and_Inf;/* '<S4>/Remove_NaNs_and_Inf' */
  B_Ramp_Up_Down_may23_T sf_Ramp_Up_Down1;/* '<S4>/Ramp_Up_Down1' */
  B_Ramp_Up_Down_may23_T sf_Ramp_Up_Down;/* '<S4>/Ramp_Up_Down' */
  B_MATLABFunction_may23_bc_T sf_MATLABFunction1;/* '<S321>/MATLAB Function1' */
  B_MATLABFunction_may23_bc_T sf_MATLABFunction_a;/* '<S321>/MATLAB Function' */
  B_split_primary_may23_T sf_split_primary1;/* '<S76>/split_primary1' */
  B_split_primary_may23_T sf_split_primary;/* '<S76>/split_primary' */
  B_splitKINDataarm1_may23_T sf_splitKINDataarm2;/* '<S75>/splitKINData arm2' */
  B_splitKINDataarm1_may23_T sf_splitKINDataarm1;/* '<S75>/splitKINData arm1' */
  B_Createtimestamp_may23_T sf_Createtimestamp_o;/* '<S253>/Create timestamp' */
  B_Createtimestamp_may23_T sf_Createtimestamp;/* '<S252>/Create timestamp' */
  B_size_may23_T sf_size1_b;           /* '<S78>/size1' */
  B_size_may23_T sf_size_l;            /* '<S78>/size' */
  B_converter_may23_T sf_converter_c;  /* '<S233>/converter' */
  B_MATLABFunction_may23_n_T sf_MATLABFunction_g3;/* '<S233>/MATLAB Function' */
  B_MATLABFunction1_may23_T sf_MATLABFunction1_c;/* '<S170>/MATLAB Function1' */
  B_convert_may23_T sf_convert_n;      /* '<S169>/convert' */
  B_SDOwritemachine_may23_T sf_SDOwritemachine_g;/* '<S169>/SDO write machine' */
  B_MATLABFunction_may23_n_T sf_MATLABFunction_c;/* '<S169>/MATLAB Function' */
  B_values_may23_T sf_values2_a;       /* '<S168>/values2' */
  B_values_may23_T sf_values_p;        /* '<S168>/values' */
  B_SDOreadmachine_may23_T sf_SDOreadmachine_f;/* '<S168>/SDO read machine' */
  B_converter_may23_T sf_converter_ai; /* '<S222>/converter' */
  B_converter_may23_T sf_converter_f;  /* '<S221>/converter' */
  B_MATLABFunction_may23_n_T sf_MATLABFunction_f1;/* '<S221>/MATLAB Function' */
  B_setupvalues_may23_T sf_setupvalues_o;/* '<S166>/set-up values' */
  B_AbsEncodermachine_may23_T sf_AbsEncodermachine_n;/* '<S166>/AbsEncoder machine' */
  B_setupvalues_may23_T sf_setupvalues_p;/* '<S165>/set-up values' */
  B_AbsEncodermachine_may23_T sf_AbsEncodermachine_j;/* '<S165>/AbsEncoder machine' */
  B_FindRobottype_may23_T sf_FindRobottype_i;/* '<S78>/Find Robot type' */
  B_cleanword_may23_T sf_cleanword_i;  /* '<S163>/cleanword' */
  B_Whistlestate_may23_T sf_Whistlestate_m;/* '<S163>/Whistle state' */
  B_passemcy_may23_T sf_passemcy_e;    /* '<S199>/pass emcy' */
  B_faultmonitor_may23_T sf_faultmonitor_h;/* '<S199>/fault monitor' */
  B_MATLABFunction_may23_n_T sf_MATLABFunction_lj;/* '<S210>/MATLAB Function' */
  B_MATLABFunction_may23_b_T sf_MATLABFunction_hj;/* '<S209>/MATLAB Function' */
  B_ReadEMCY_may23_T sf_ReadEMCY_o;    /* '<S199>/Read EMCY' */
  B_parsestatusregister_may23_T sf_parsestatusregister1_d;/* '<S197>/parse status register1' */
  B_MATLABFunction_may23_T sf_MATLABFunction_ac;/* '<S205>/MATLAB Function' */
  B_cleanword_may23_T sf_cleanword_e;  /* '<S162>/cleanword' */
  B_Whistlestate_may23_T sf_Whistlestate_l;/* '<S162>/Whistle state' */
  B_passemcy_may23_T sf_passemcy_c;    /* '<S179>/pass emcy' */
  B_faultmonitor_may23_T sf_faultmonitor_f;/* '<S179>/fault monitor' */
  B_MATLABFunction_may23_n_T sf_MATLABFunction_m2;/* '<S190>/MATLAB Function' */
  B_MATLABFunction_may23_b_T sf_MATLABFunction_hm;/* '<S189>/MATLAB Function' */
  B_ReadEMCY_may23_T sf_ReadEMCY_b;    /* '<S179>/Read EMCY' */
  B_parsestatusregister_may23_T sf_parsestatusregister1_g;/* '<S177>/parse status register1' */
  B_MATLABFunction_may23_T sf_MATLABFunction_o;/* '<S185>/MATLAB Function' */
  B_size_may23_T sf_size1;             /* '<S77>/size1' */
  B_size_may23_T sf_size;              /* '<S77>/size' */
  B_converter_may23_T sf_converter_a;  /* '<S159>/converter' */
  B_MATLABFunction_may23_n_T sf_MATLABFunction_e;/* '<S159>/MATLAB Function' */
  B_convert_may23_T sf_convert;        /* '<S95>/convert' */
  B_SDOwritemachine_may23_T sf_SDOwritemachine;/* '<S95>/SDO write machine' */
  B_MATLABFunction_may23_n_T sf_MATLABFunction_ae;/* '<S95>/MATLAB Function' */
  B_values_may23_T sf_values2;         /* '<S94>/values2' */
  B_values_may23_T sf_values;          /* '<S94>/values' */
  B_SDOreadmachine_may23_T sf_SDOreadmachine_i;/* '<S94>/SDO read machine' */
  B_converter_may23_T sf_converter_e;  /* '<S148>/converter' */
  B_MATLABFunction_may23_n_T sf_MATLABFunction_j;/* '<S148>/MATLAB Function' */
  B_converter_may23_T sf_converter;    /* '<S147>/converter' */
  B_MATLABFunction_may23_n_T sf_MATLABFunction_mr;/* '<S147>/MATLAB Function' */
  B_setupvalues_may23_T sf_setupvalues_b;/* '<S92>/set-up values' */
  B_AbsEncodermachine_may23_T sf_AbsEncodermachine_l;/* '<S92>/AbsEncoder machine' */
  B_setupvalues_may23_T sf_setupvalues;/* '<S91>/set-up values' */
  B_AbsEncodermachine_may23_T sf_AbsEncodermachine;/* '<S91>/AbsEncoder machine' */
  B_FindRobottype_may23_T sf_FindRobottype;/* '<S77>/Find Robot type' */
  B_MATLABFunction1_may23_T sf_MATLABFunction1_k;/* '<S89>/MATLAB Function1' */
  B_cleanword_may23_T sf_cleanword_k;  /* '<S88>/cleanword' */
  B_Whistlestate_may23_T sf_Whistlestate_a;/* '<S88>/Whistle state' */
  B_passemcy_may23_T sf_passemcy_b;    /* '<S124>/pass emcy' */
  B_faultmonitor_may23_T sf_faultmonitor_m;/* '<S124>/fault monitor' */
  B_MATLABFunction_may23_n_T sf_MATLABFunction_hz;/* '<S135>/MATLAB Function' */
  B_MATLABFunction_may23_b_T sf_MATLABFunction_lu;/* '<S134>/MATLAB Function' */
  B_ReadEMCY_may23_T sf_ReadEMCY_h;    /* '<S124>/Read EMCY' */
  B_parsestatusregister_may23_T sf_parsestatusregister1;/* '<S122>/parse status register1' */
  B_MATLABFunction_may23_T sf_MATLABFunction_m0;/* '<S130>/MATLAB Function' */
  B_cleanword_may23_T sf_cleanword;    /* '<S87>/cleanword' */
  B_Whistlestate_may23_T sf_Whistlestate;/* '<S87>/Whistle state' */
  B_passemcy_may23_T sf_passemcy;      /* '<S104>/pass emcy' */
  B_faultmonitor_may23_T sf_faultmonitor;/* '<S104>/fault monitor' */
  B_MATLABFunction_may23_n_T sf_MATLABFunction_b1;/* '<S115>/MATLAB Function' */
  B_MATLABFunction_may23_b_T sf_MATLABFunction_gi;/* '<S114>/MATLAB Function' */
  B_ReadEMCY_may23_T sf_ReadEMCY;      /* '<S104>/Read EMCY' */
  B_parsestatusregister_may23_T sf_parsestatusregister;/* '<S102>/parse status register' */
  B_MATLABFunction_may23_T sf_MATLABFunction_k;/* '<S110>/MATLAB Function' */
} B_may23_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  emxArray_real_T_4x100_may23_T secondaryPosData;/* '<S86>/create kinematics' */
  emxArray_real_T_4x100_may23_T secondaryVelData;/* '<S86>/create kinematics' */
  emxArray_real_T_4x100_may23_T primaryPosData;/* '<S86>/create kinematics' */
  emxArray_real_T_4x100_may23_T primaryVelData;/* '<S86>/create kinematics' */
  sbr0BdzAW6GQX2fQakj4o6C_may23_T robot1Struct;/* '<S262>/Robot_data_builder' */
  sbr0BdzAW6GQX2fQakj4o6C_may23_T robot2Struct;/* '<S262>/Robot_data_builder' */
  sbr0BdzAW6GQX2fQakj4o6C_may23_T robot1StructPrimary;/* '<S262>/Robot_data_builder' */
  sbr0BdzAW6GQX2fQakj4o6C_may23_T robot2StructPrimary;/* '<S262>/Robot_data_builder' */
  shSrZ99dE4twa6ELJRaXlMD_may23_T robot1Struct_d;/* '<S262>/filter_velocities' */
  shSrZ99dE4twa6ELJRaXlMD_may23_T robot2Struct_o;/* '<S262>/filter_velocities' */
  real_T Delay_DSTATE[4];              /* '<S34>/Delay' */
  real_T Delay_DSTATE_e[24];           /* '<S327>/Delay' */
  real_T Delay_DSTATE_m[4];            /* '<S38>/Delay' */
  real_T UnitDelay_DSTATE;             /* '<S264>/Unit Delay' */
  real_T UnitDelay2_DSTATE;            /* '<S264>/Unit Delay2' */
  real_T UnitDelay1_DSTATE;            /* '<S264>/Unit Delay1' */
  real_T UnitDelay3_DSTATE;            /* '<S264>/Unit Delay3' */
  real_T DelayInput1_DSTATE;           /* '<S256>/Delay Input1' */
  real_T DelayInput1_DSTATE_g;         /* '<S260>/Delay Input1' */
  real_T UnitDelay_DSTATE_e;           /* '<S55>/Unit Delay' */
  real_T Delay1_PreviousInput;         /* '<S336>/Delay1' */
  real_T Subtract_DWORK1;              /* '<S336>/Subtract' */
  real_T Memory_PreviousInput;         /* '<S3>/Memory' */
  real_T Memory_PreviousInput_m[4];    /* '<S1>/Memory' */
  real_T Memory_PreviousInput_f;       /* '<S9>/Memory' */
  real_T Memory2_PreviousInput;        /* '<S38>/Memory2' */
  real_T Memory2_PreviousInput_c[70];  /* '<Root>/Memory2' */
  real_T TmpRTBAtHold_to_1KhzInport2_Buffer0;/* synthesized block */
  real_T RateTransition_Buffer[71];    /* '<S22>/Rate Transition' */
  real_T RateTransition2_Buffer0;      /* '<S23>/Rate Transition2' */
  real_T RateTransition_Buffer_d[72];  /* '<S25>/Rate Transition' */
  real_T TmpRTBAtTimestampOutport1_Buffer0;/* synthesized block */
  real_T RateTransition_Buffer_j[20];  /* '<S1>/Rate Transition' */
  real_T RateTransition1_Buffer[16];   /* '<S1>/Rate Transition1' */
  real_T RateTransition2_Buffer[2];    /* '<S1>/Rate Transition2' */
  real_T Memory3_PreviousInput[4];     /* '<S19>/Memory3' */
  real_T Memory1_PreviousInput;        /* '<S38>/Memory1' */
  real_T Memory1_PreviousInput_l;      /* '<S1>/Memory1' */
  real_T Memory2_1_PreviousInput;      /* '<S1>/Memory2' */
  real_T Memory2_2_PreviousInput;      /* '<S1>/Memory2' */
  real_T Memory2_3_PreviousInput;      /* '<S1>/Memory2' */
  real_T Memory2_4_PreviousInput;      /* '<S1>/Memory2' */
  real_T Memory2_5_PreviousInput;      /* '<S1>/Memory2' */
  real_T Memory2_9_PreviousInput;      /* '<S1>/Memory2' */
  real_T Memory2_18_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_19_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_20_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_21_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_22_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_26_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_10_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_11_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_12_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_13_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_14_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_15_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_16_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_17_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_23_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_24_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_25_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_27_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_28_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_29_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_30_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_31_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_32_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_33_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_34_PreviousInput;     /* '<S1>/Memory2' */
  real_T Memory2_6_PreviousInput;      /* '<S1>/Memory2' */
  real_T Memory2_7_PreviousInput;      /* '<S1>/Memory2' */
  real_T Memory2_8_PreviousInput;      /* '<S1>/Memory2' */
  real_T Memory1_PreviousInput_k[4];   /* '<S329>/Memory1' */
  real_T ECATStatus[8];                /* '<S1>/ECAT Status' */
  real_T DataReadyStatus[10];          /* '<S1>/ECAT Status1' */
  real_T ECATHardware[14];             /* '<S1>/ECAT hardware' */
  real_T RateTransition1_Buffer_k;     /* '<S381>/Rate Transition1' */
  real_T RateTransition2_Buffer_j[490];/* '<S9>/Rate Transition2' */
  real_T hand_vector[2];               /* '<S21>/Collision Resolution' */
  real_T prev_vel[2];                  /* '<S21>/Collision Resolution' */
  real_T target_colliding;             /* '<S21>/Collision Resolution' */
  real_T hand_vel[2];                  /* '<S21>/Collision Resolution' */
  real_T rect_offset_position;         /* '<S21>/Collision Resolution' */
  real_T barrier_colliding;            /* '<S21>/Collision Resolution' */
  real_T check_collision_barrier1;     /* '<S21>/Collision Resolution' */
  real_T barrier_vel;                  /* '<S21>/Collision Resolution' */
  real_T force_scaling_barrier;        /* '<S21>/Collision Resolution' */
  real_T hand_offset_position;         /* '<S21>/Collision Resolution' */
  real_T prev_hand_vel;                /* '<S21>/Collision Resolution' */
  real_T rect_left;                    /* '<S21>/Collision Resolution' */
  real_T rect_bottom;                  /* '<S21>/Collision Resolution' */
  real_T goal_right;                   /* '<S21>/Collision Resolution' */
  real_T rect_right;                   /* '<S21>/Collision Resolution' */
  real_T goal_bottom;                  /* '<S21>/Collision Resolution' */
  real_T goal_left;                    /* '<S21>/Collision Resolution' */
  real_T new_hand_posistion_c;         /* '<S21>/Collision Resolution' */
  real_T puck_offset_position[2];      /* '<S21>/Collision Resolution' */
  real_T puck_velocity[2];             /* '<S21>/Collision Resolution' */
  real_T puck_damping;                 /* '<S21>/Collision Resolution' */
  real_T trial_duration;               /* '<Root>/Trial_Control' */
  real_T start_hold_time;              /* '<Root>/Trial_Control' */
  real_T shot_set_time;                /* '<Root>/Trial_Control' */
  real_T shot_ready_time;              /* '<Root>/Trial_Control' */
  real_T goal_time;                    /* '<Root>/Trial_Control' */
  real_T shot_time;                    /* '<Root>/Trial_Control' */
  real_T tick;                         /* '<S396>/Ramp_up_down' */
  real_T RateTransition1_Buffer0;      /* '<S383>/Rate Transition1' */
  real_T last_valid_frame_ack;         /* '<S9>/MATLAB Function' */
  real_T last_perm_frame_ack;          /* '<S9>/MATLAB Function' */
  real_T trials_per_block[50];         /* '<S337>/MATLAB Function' */
  real_T total_trials_saved;           /* '<S337>/MATLAB Function' */
  real_T total_blocks_saved;           /* '<S337>/MATLAB Function' */
  real_T trial_queue[499];         /* '<S336>/Task Execution Control Machine' */
  real_T repeat_list[499];         /* '<S336>/Task Execution Control Machine' */
  real_T EXAM;                     /* '<S336>/Task Execution Control Machine' */
  real_T BLOCK;                    /* '<S336>/Task Execution Control Machine' */
  real_T block;                    /* '<S336>/Task Execution Control Machine' */
  real_T held_value[8];                /* '<S335>/Hold_to_1Khz' */
  real_T last_sim;                     /* '<S335>/Hold_to_1Khz' */
  real_T u;                            /* '<S335>/Embedded MATLAB Function' */
  real_T v;                            /* '<S335>/Embedded MATLAB Function' */
  real_T rawVelocities[24];            /* '<S38>/filter' */
  real_T filtVelocities[24];           /* '<S38>/filter' */
  real_T rawVelocities_a[12];          /* '<S327>/filter' */
  real_T filtVelocities_l[12];         /* '<S327>/filter' */
  real_T isWorking;                    /* '<S33>/verify NaN' */
  real_T RateTransition_Buffer0[3];    /* '<S31>/Rate Transition' */
  real_T RateTransition1_Buffer_j[3];  /* '<S31>/Rate Transition1' */
  real_T RateTransition2_Buffer_f;     /* '<S31>/Rate Transition2' */
  real_T start_time;                   /* '<S31>/Create timestamp' */
  real_T last_time;                    /* '<S31>/Create timestamp' */
  real_T BKINEtherCATinit1_DWORK2;     /* '<S66>/BKIN EtherCATinit1' */
  real_T BKINEtherCATinit1_DWORK4;     /* '<S66>/BKIN EtherCATinit1' */
  real_T BKINEtherCATinit_DWORK2;      /* '<S66>/BKIN EtherCATinit' */
  real_T BKINEtherCATinit_DWORK4;      /* '<S66>/BKIN EtherCATinit' */
  real_T TmpRTBAtDatawriteInport2_Buffer0[20];/* synthesized block */
  real_T TmpRTBAtDatawriteInport3_Buffer0[12];/* synthesized block */
  real_T ECATErrMsgs[20];              /* '<S30>/ECAT Err Msgs' */
  real_T ECATExtraData[10];            /* '<S30>/ECATTorque feedback' */
  real_T HardwareSettings[25];         /* '<S30>/HW Settings' */
  real_T Kinematics[20];               /* '<S30>/Kinematics' */
  real_T PrimaryEncoderData[12];       /* '<S30>/PrimaryEnc' */
  real_T RobotCalibrations[16];        /* '<S30>/Robot Calib' */
  real_T RobotRevision[2];             /* '<S30>/RobotRevision' */
  real_T DelayEstimates[4];            /* '<S30>/delays' */
  real_T ArmForceSensors[3];           /* '<S30>/has FT sensors' */
  real_T lastECATMessages[20];         /* '<S73>/record errors' */
  real_T outCount;                     /* '<S73>/record errors' */
  real_T memoryBuffer[300];            /* '<S73>/record errors' */
  real_T waitingMsgCount;              /* '<S73>/record errors' */
  real_T sentCount;                    /* '<S73>/record errors' */
  real_T was_calibrated[4];            /* '<S73>/Create KINARM Data Array' */
  real_T stored_offsets[8];            /* '<S73>/Create KINARM Data Array' */
  real_T rawVelocities_k[12];          /* '<S243>/filter_velocities' */
  real_T filtVelocities_d[12];         /* '<S243>/filter_velocities' */
  real_T r1Sho[4];                     /* '<S283>/MATLAB Function' */
  real_T r1Elb[4];                     /* '<S283>/MATLAB Function' */
  real_T r2Sho[4];                     /* '<S283>/MATLAB Function' */
  real_T r2Elb[4];                     /* '<S283>/MATLAB Function' */
  real_T last_tick[4];                 /* '<S283>/MATLAB Function' */
  real_T servoValuesR1[5];             /* '<S262>/Robot_data_builder' */
  real_T servoValuesR2[5];             /* '<S262>/Robot_data_builder' */
  real_T no_update_count;              /* '<S262>/Monitor_status' */
  real_T latchedErrors[12];            /* '<S66>/latch_errors' */
  real_T latchedDCErrors[12];          /* '<S66>/latch_errors' */
  real_T Memory_PreviousInput_c;       /* '<S162>/Memory' */
  real_T Memory_PreviousInput_g;       /* '<S163>/Memory' */
  real_T Memory1_PreviousInput_n;      /* '<S172>/Memory1' */
  real_T Memory2_PreviousInput_g[2];   /* '<S78>/Memory2' */
  real_T Memory3_PreviousInput_k;      /* '<S78>/Memory3' */
  real_T lastRunningState;             /* '<S78>/forceEnableDisable' */
  real_T faultResetCycles;             /* '<S78>/forceEnableDisable' */
  real_T valueCount;                   /* '<S78>/SDO read machine' */
  real_T Memory_PreviousInput_h;       /* '<S211>/Memory' */
  real_T Memory_PreviousInput_fh;      /* '<S191>/Memory' */
  real_T Memory_PreviousInput_k;       /* '<S87>/Memory' */
  real_T Memory_PreviousInput_d;       /* '<S88>/Memory' */
  real_T Memory1_PreviousInput_j;      /* '<S97>/Memory1' */
  real_T Memory2_PreviousInput_j[2];   /* '<S77>/Memory2' */
  real_T Memory3_PreviousInput_h;      /* '<S77>/Memory3' */
  real_T lastRunningState_o;           /* '<S77>/forceEnableDisable' */
  real_T faultResetCycles_i;           /* '<S77>/forceEnableDisable' */
  real_T valueCount_a;                 /* '<S77>/SDO read machine' */
  real_T Memory_PreviousInput_e;       /* '<S136>/Memory' */
  real_T Memory_PreviousInput_h4;      /* '<S116>/Memory' */
  real_T RateTransition_Buffer_l;      /* '<S29>/Rate Transition' */
  real_T RateTransition1_Buffer_kz;    /* '<S29>/Rate Transition1' */
  real_T RateTransition2_Buffer0_i;    /* '<S54>/Rate Transition2' */
  real_T Memory2_PreviousInput_b;      /* '<S52>/Memory2' */
  real_T Memory1_PreviousInput_c;      /* '<S52>/Memory1' */
  real_T counter;                      /* '<S54>/force strobe' */
  real_T packet_queue_sz;              /* '<S28>/Send Control Machine' */
  real_T outstanding_packet_index;     /* '<S28>/Send Control Machine' */
  struct {
    real_T EXECRATIO;
  } BKINEtherCATinit1_RWORK;           /* '<S66>/BKIN EtherCATinit1' */

  struct {
    real_T EXECRATIO;
  } BKINEtherCATinit_RWORK;            /* '<S66>/BKIN EtherCATinit' */

  void *RunCommandReceive_PWORK[2];    /* '<S335>/Run Command Receive' */
  void *Receive_PWORK[2];              /* '<S9>/Receive' */
  void *Send_PWORK;                    /* '<S9>/Send' */
  void *SFunction1_PWORK;              /* '<S313>/S-Function1' */
  void *Receive_PWORK_g[2];            /* '<S31>/Receive' */
  void *Receive_PWORK_o[2];            /* '<S283>/Receive' */
  void *SFunction_PWORK;               /* '<S262>/S-Function' */
  void *Write_PWORK;                   /* '<S264>/Write' */
  void *Write_PWORK_n;                 /* '<S271>/Write' */
  void *Read_PWORK;                    /* '<S269>/Read' */
  void *ReceivefromRobot1ForceSensor_PWORK[2];
                                /* '<S252>/Receive from Robot 1 Force Sensor' */
  void *ReceivefromRobot2ForceSensor_PWORK[2];
                                /* '<S253>/Receive from Robot 2 Force Sensor' */
  void *Send_PWORK_m;                  /* '<S259>/Send' */
  void *Send_PWORK_mg;                 /* '<S257>/Send' */
  void *BKINPDOReceiveElmoDrive_PWORK; /* '<S177>/BKIN PDO Receive ElmoDrive' */
  void *BKINPDOReceiveElmoDrive_PWORK_k;/* '<S197>/BKIN PDO Receive ElmoDrive' */
  void *BKINPDOReceiveElmoDrive_PWORK_e;/* '<S102>/BKIN PDO Receive ElmoDrive' */
  void *BKINPDOReceiveElmoDrive_PWORK_f;/* '<S122>/BKIN PDO Receive ElmoDrive' */
  void *Send1_PWORK;                   /* '<S63>/Send1' */
  void *Send_PWORK_c;                  /* '<S62>/Send' */
  void *Receive1_PWORK[2];             /* '<S61>/Receive1' */
  void *Receive_PWORK_c[2];            /* '<S60>/Receive' */
  void *Receive_PWORK_co[2];           /* '<S52>/Receive' */
  void *Send_PWORK_b;                  /* '<S53>/Send' */
  void *Send_PWORK_bz;                 /* '<S27>/Send' */
  uint32_T Output_DSTATE;              /* '<S350>/Output' */
  uint32_T Output_DSTATE_d;            /* '<S46>/Output' */
  uint32_T Output_DSTATE_p;            /* '<S275>/Output' */
  uint32_T Output_DSTATE_po;           /* '<S80>/Output' */
  uint32_T Output_DSTATE_f;            /* '<S296>/Output' */
  uint32_T Output_DSTATE_a;            /* '<S286>/Output' */
  uint32_T Output_DSTATE_b;            /* '<S56>/Output' */
  real32_T RateTransition1_Buffer0_i[400];/* '<S28>/Rate Transition1' */
  real32_T packet_queue[20500000];     /* '<S28>/Send Control Machine' */
  real32_T t2_PreviousInput[182];      /* '<S50>/t-2' */
  real32_T t1_PreviousInput[182];      /* '<S50>/t-1' */
  int32_T clockTickCounter;            /* '<S336>/Task Clock' */
  int32_T clockTickCounter_d;          /* '<S21>/Pulse Generator' */
  int32_T clockTickCounter_c;          /* '<S38>/Task Clock' */
  int32_T sfEvent;                     /* '<S21>/Collision Resolution' */
  int32_T sfEvent_b;                   /* '<Root>/Trial_Control' */
  int32_T sfEvent_i;                   /* '<S396>/Ramp_up_down' */
  int32_T sfEvent_j;               /* '<S336>/Task Execution Control Machine' */
  int32_T sfEvent_bs;                  /* '<S38>/torque_monitor' */
  int32_T sfEvent_n;                   /* '<S329>/monitor_encoders' */
  int32_T BKINEtherCATinit1_DWORK1;    /* '<S66>/BKIN EtherCATinit1' */
  int32_T BKINEtherCATinit_DWORK1;     /* '<S66>/BKIN EtherCATinit' */
  int32_T sfEvent_l;                   /* '<S30>/control read write' */
  int32_T sfEvent_e;                   /* '<S73>/Calibration_check' */
  int32_T sfEvent_p;                   /* '<S82>/master_state' */
  int32_T Memory_PreviousInput_b;      /* '<S172>/Memory' */
  int32_T Memory2_PreviousInput_o[2];  /* '<S172>/Memory2' */
  int32_T Memory_PreviousInput_kj[2];  /* '<S169>/Memory' */
  int32_T Memory_PreviousInput_p[2];   /* '<S168>/Memory' */
  int32_T sfEvent_k;                   /* '<S78>/SDO read machine' */
  int32_T valueIdx;                    /* '<S78>/SDO read machine' */
  int32_T lastTrigger;                 /* '<S78>/SDO read machine' */
  int32_T Memory_PreviousInput_po;     /* '<S166>/Memory' */
  int32_T Memory1_PreviousInput_ck[2]; /* '<S166>/Memory1' */
  int32_T Memory_PreviousInput_a;      /* '<S165>/Memory' */
  int32_T Memory1_PreviousInput_b[2];  /* '<S165>/Memory1' */
  int32_T Memory_PreviousInput_f1[3];  /* '<S210>/Memory' */
  int32_T Memory_PreviousInput_md[3];  /* '<S190>/Memory' */
  int32_T Memory_PreviousInput_dp;     /* '<S97>/Memory' */
  int32_T Memory2_PreviousInput_g5[2]; /* '<S97>/Memory2' */
  int32_T Memory_PreviousInput_n[2];   /* '<S95>/Memory' */
  int32_T Memory_PreviousInput_n1[2];  /* '<S94>/Memory' */
  int32_T sfEvent_k0;                  /* '<S77>/SDO read machine' */
  int32_T valueIdx_n;                  /* '<S77>/SDO read machine' */
  int32_T lastTrigger_d;               /* '<S77>/SDO read machine' */
  int32_T Memory_PreviousInput_kk;     /* '<S92>/Memory' */
  int32_T Memory1_PreviousInput_i[2];  /* '<S92>/Memory1' */
  int32_T Memory_PreviousInput_l;      /* '<S91>/Memory' */
  int32_T Memory1_PreviousInput_p[2];  /* '<S91>/Memory1' */
  int32_T Memory_PreviousInput_nk[3];  /* '<S135>/Memory' */
  int32_T Memory_PreviousInput_kg[3];  /* '<S115>/Memory' */
  int32_T clockTickCounter_n;          /* '<S28>/Task Clock' */
  int32_T sfEvent_p2;                  /* '<S28>/Send Control Machine' */
  int32_T j;                           /* '<S28>/Send Control Machine' */
  uint32_T ECATDigDiagnostic[4];       /* '<S1>/ECAT Dig Diagnostic' */
  uint32_T e_Puck_StoppedEventCounter; /* '<S21>/Collision Resolution' */
  uint32_T e_Puck_HitEventCounter;     /* '<S21>/Collision Resolution' */
  uint32_T e_Trial_StartEventCounter;  /* '<Root>/Trial_Control' */
  uint32_T e_Trial_EndEventCounter;    /* '<Root>/Trial_Control' */
  uint32_T temporalCounter_i1;         /* '<Root>/Trial_Control' */
  uint32_T presentTicks;               /* '<Root>/Trial_Control' */
  uint32_T elapsedTicks;               /* '<Root>/Trial_Control' */
  uint32_T previousTicks;              /* '<Root>/Trial_Control' */
  uint32_T temporalCounter_i1_n;       /* '<S396>/Ramp_up_down' */
  uint32_T frame_count;                /* '<S383>/Pack VCodeFrame2' */
  uint32_T e_exit_trialEventCounter;
                                   /* '<S336>/Task Execution Control Machine' */
  uint32_T repeat_list_length;     /* '<S336>/Task Execution Control Machine' */
  uint32_T i;                      /* '<S336>/Task Execution Control Machine' */
  uint32_T swap_index;             /* '<S336>/Task Execution Control Machine' */
  uint32_T temp;                   /* '<S336>/Task Execution Control Machine' */
  uint32_T trial_queue_length;     /* '<S336>/Task Execution Control Machine' */
  uint32_T trial_in_mini_block;    /* '<S336>/Task Execution Control Machine' */
  uint32_T state[625];                 /* '<S33>/verify NaN' */
  uint32_T RateTransition3_Buffer;     /* '<S31>/Rate Transition3' */
  uint32_T last_timestamp;             /* '<S31>/convert to seconds2' */
  uint32_T TmpRTBAtDatawriteInport4_Buffer0;/* synthesized block */
  uint32_T TmpRTBAtDatawriteInport5_Buffer0[7];/* synthesized block */
  uint32_T ECATDigitalInput[8];        /* '<S30>/ECAT Digital in' */
  uint32_T ServoUpdate;                /* '<S30>/ServoUpdate' */
  uint32_T SystemStatus[7];            /* '<S30>/System status' */
  uint32_T CalibrationButton;          /* '<S30>/calib button' */
  uint32_T presentTicks_l;             /* '<S73>/Calibration_check' */
  uint32_T elapsedTicks_n;             /* '<S73>/Calibration_check' */
  uint32_T previousTicks_j;            /* '<S73>/Calibration_check' */
  uint32_T servoCounter;               /* '<S86>/create servo counter' */
  uint32_T last_servo_counter;         /* '<S262>/Monitor_status' */
  uint32_T enteredOpStep;              /* '<S66>/latch_errors' */
  uint32_T Memory_PreviousInput_i[3];  /* '<S209>/Memory' */
  uint32_T Memory_PreviousInput_h4d[3];/* '<S189>/Memory' */
  uint32_T Memory_PreviousInput_n3[3]; /* '<S134>/Memory' */
  uint32_T Memory_PreviousInput_di[3]; /* '<S114>/Memory' */
  uint32_T queue_tail;                 /* '<S28>/Send Control Machine' */
  uint32_T packet_index;               /* '<S28>/Send Control Machine' */
  uint32_T queue_head;                 /* '<S28>/Send Control Machine' */
  int_T ICH7_IWORK[5];                 /* '<S3>/ICH7' */
  int_T RunCommandReceive_IWORK[2];    /* '<S335>/Run Command Receive' */
  int_T Receive_IWORK[2];              /* '<S9>/Receive' */
  int_T Unpack_IWORK[2];               /* '<S9>/Unpack' */
  struct {
    int_T AcquireOK;
  } SFunction_IWORK;                   /* '<S397>/S-Function' */

  int_T Send_IWORK[3];                 /* '<S9>/Send' */
  int_T BKINEtherCATPDOTransmit1_IWORK[23];
                                     /* '<S317>/BKIN EtherCAT PDO Transmit 1' */
  int_T BKINEtherCATPDOTransmit2_IWORK[23];
                                     /* '<S317>/BKIN EtherCAT PDO Transmit 2' */
  int_T BKINEtherCATPDOTransmit1_IWORK_h[23];
                                     /* '<S318>/BKIN EtherCAT PDO Transmit 1' */
  int_T BKINEtherCATPDOTransmit2_IWORK_a[23];
                                     /* '<S318>/BKIN EtherCAT PDO Transmit 2' */
  int_T Receive_IWORK_g[2];            /* '<S31>/Receive' */
  int_T BKINEtherCATPDOTransmit_IWORK[23];/* '<S81>/BKIN EtherCAT PDO Transmit ' */
  int_T BKINEtherCATPDOTransmit1_IWORK_a[23];
                                      /* '<S81>/BKIN EtherCAT PDO Transmit 1' */
  int_T BKINEtherCATPDOTransmit2_IWORK_af[23];
                                      /* '<S81>/BKIN EtherCAT PDO Transmit 2' */
  int_T BKINEtherCATPDOTransmit3_IWORK[23];
                                      /* '<S81>/BKIN EtherCAT PDO Transmit 3' */
  int_T Receive_IWORK_c[2];            /* '<S283>/Receive' */
  int_T Unpack_IWORK_o[4];             /* '<S283>/Unpack' */
  int_T SFunction_IWORK_g[2];          /* '<S276>/S-Function' */
  int_T Unpack_IWORK_j[2];             /* '<S276>/Unpack' */
  int_T ReceivefromRobot1ForceSensor_IWORK[2];
                                /* '<S252>/Receive from Robot 1 Force Sensor' */
  int_T Unpack_IWORK_n[4];             /* '<S252>/Unpack' */
  int_T ReceivefromRobot2ForceSensor_IWORK[2];
                                /* '<S253>/Receive from Robot 2 Force Sensor' */
  int_T Unpack1_IWORK[4];              /* '<S253>/Unpack1' */
  int_T Pack_IWORK[6];                 /* '<S259>/Pack' */
  int_T Send_IWORK_a[3];               /* '<S259>/Send' */
  int_T Pack_IWORK_i[6];               /* '<S257>/Pack' */
  int_T Send_IWORK_b[3];               /* '<S257>/Send' */
  int_T BKINPDOReceiveElmoDrive_IWORK[7];/* '<S177>/BKIN PDO Receive ElmoDrive' */
  int_T BKINEtherCATPDOTransmit_IWORK_p[23];
                                      /* '<S162>/BKIN EtherCAT PDO Transmit ' */
  int_T BKINPDOReceiveElmoDrive_IWORK_i[7];/* '<S197>/BKIN PDO Receive ElmoDrive' */
  int_T BKINEtherCATPDOTransmit_IWORK_e[23];
                                      /* '<S163>/BKIN EtherCAT PDO Transmit ' */
  int_T BKINEtherCATPDOTransmit_IWORK_c[23];
                                      /* '<S170>/BKIN EtherCAT PDO Transmit ' */
  int_T BKINEtherCATPDOTransmit1_IWORK_p[23];
                                     /* '<S170>/BKIN EtherCAT PDO Transmit 1' */
  int_T BKINEtherCATAsyncSDOUpload1_IWORK[10];
                                  /* '<S233>/BKIN EtherCAT Async SDO Upload1' */
  int_T BKINEtherCATAsyncSDODownload_IWORK[9];
                                 /* '<S169>/BKIN EtherCAT Async SDO Download' */
  int_T BKINEtherCATAsyncSDOUpload1_IWORK_h[10];
                                  /* '<S222>/BKIN EtherCAT Async SDO Upload1' */
  int_T BKINEtherCATAsyncSDOUpload1_IWORK_ho[10];
                                  /* '<S221>/BKIN EtherCAT Async SDO Upload1' */
  int_T BKINEtherCATAsyncSDODownload_IWORK_g[9];
                                 /* '<S166>/BKIN EtherCAT Async SDO Download' */
  int_T BKINEtherCATAsyncSDOUpload_IWORK[10];
                                   /* '<S166>/BKIN EtherCAT Async SDO Upload' */
  int_T BKINEtherCATAsyncSDODownload_IWORK_a[9];
                                 /* '<S165>/BKIN EtherCAT Async SDO Download' */
  int_T BKINEtherCATAsyncSDOUpload_IWORK_g[10];
                                   /* '<S165>/BKIN EtherCAT Async SDO Upload' */
  int_T BKINEtherCATAsyncSDOUpload_IWORK_e[10];
                                   /* '<S209>/BKIN EtherCAT Async SDO Upload' */
  int_T BKINEtherCATAsyncSDOUpload_IWORK_j[10];
                                   /* '<S210>/BKIN EtherCAT Async SDO Upload' */
  int_T BKINEtherCATAsyncSDODownload_IWORK_ai[9];
                                 /* '<S211>/BKIN EtherCAT Async SDO Download' */
  int_T BKINEtherCATAsyncSDOUpload_IWORK_jb[10];
                                   /* '<S189>/BKIN EtherCAT Async SDO Upload' */
  int_T BKINEtherCATAsyncSDOUpload_IWORK_l[10];
                                   /* '<S190>/BKIN EtherCAT Async SDO Upload' */
  int_T BKINEtherCATAsyncSDODownload_IWORK_h[9];
                                 /* '<S191>/BKIN EtherCAT Async SDO Download' */
  int_T BKINPDOReceiveElmoDrive_IWORK_b[7];/* '<S102>/BKIN PDO Receive ElmoDrive' */
  int_T BKINEtherCATPDOTransmit_IWORK_b[23];/* '<S87>/BKIN EtherCAT PDO Transmit ' */
  int_T BKINPDOReceiveElmoDrive_IWORK_a[7];/* '<S122>/BKIN PDO Receive ElmoDrive' */
  int_T BKINEtherCATPDOTransmit_IWORK_o[23];/* '<S88>/BKIN EtherCAT PDO Transmit ' */
  int_T BKINEtherCATPDOTransmit_IWORK_k[23];/* '<S89>/BKIN EtherCAT PDO Transmit ' */
  int_T BKINEtherCATPDOTransmit1_IWORK_o[23];
                                      /* '<S89>/BKIN EtherCAT PDO Transmit 1' */
  int_T BKINEtherCATAsyncSDOUpload1_IWORK_c[10];
                                  /* '<S159>/BKIN EtherCAT Async SDO Upload1' */
  int_T BKINEtherCATAsyncSDODownload_IWORK_m[9];
                                  /* '<S95>/BKIN EtherCAT Async SDO Download' */
  int_T BKINEtherCATAsyncSDOUpload1_IWORK_b[10];
                                  /* '<S148>/BKIN EtherCAT Async SDO Upload1' */
  int_T BKINEtherCATAsyncSDOUpload1_IWORK_i[10];
                                  /* '<S147>/BKIN EtherCAT Async SDO Upload1' */
  int_T BKINEtherCATAsyncSDODownload_IWORK_p[9];
                                  /* '<S92>/BKIN EtherCAT Async SDO Download' */
  int_T BKINEtherCATAsyncSDOUpload_IWORK_lj[10];
                                    /* '<S92>/BKIN EtherCAT Async SDO Upload' */
  int_T BKINEtherCATAsyncSDODownload_IWORK_f[9];
                                  /* '<S91>/BKIN EtherCAT Async SDO Download' */
  int_T BKINEtherCATAsyncSDOUpload_IWORK_j0[10];
                                    /* '<S91>/BKIN EtherCAT Async SDO Upload' */
  int_T BKINEtherCATAsyncSDOUpload_IWORK_lh[10];
                                   /* '<S134>/BKIN EtherCAT Async SDO Upload' */
  int_T BKINEtherCATAsyncSDOUpload_IWORK_h[10];
                                   /* '<S135>/BKIN EtherCAT Async SDO Upload' */
  int_T BKINEtherCATAsyncSDODownload_IWORK_mg[9];
                                 /* '<S136>/BKIN EtherCAT Async SDO Download' */
  int_T BKINEtherCATAsyncSDOUpload_IWORK_d[10];
                                   /* '<S114>/BKIN EtherCAT Async SDO Upload' */
  int_T BKINEtherCATAsyncSDOUpload_IWORK_m[10];
                                   /* '<S115>/BKIN EtherCAT Async SDO Upload' */
  int_T BKINEtherCATAsyncSDODownload_IWORK_i[9];
                                 /* '<S116>/BKIN EtherCAT Async SDO Download' */
  int_T Send1_IWORK[3];                /* '<S63>/Send1' */
  int_T Send_IWORK_bh[3];              /* '<S62>/Send' */
  int_T Receive1_IWORK[2];             /* '<S61>/Receive1' */
  int_T Receive_IWORK_k[2];            /* '<S60>/Receive' */
  int_T Receive_IWORK_l[2];            /* '<S52>/Receive' */
  int_T Unpack_IWORK_k[2];             /* '<S52>/Unpack' */
  int_T Pack_IWORK_p[2];               /* '<S53>/Pack' */
  int_T Send_IWORK_n[3];               /* '<S53>/Send' */
  int_T Pack_IWORK_h[2];               /* '<S27>/Pack' */
  int_T Send_IWORK_d[3];               /* '<S27>/Send' */
  uint16_T Output_DSTATE_d2;           /* '<S268>/Output' */
  uint16_T temporalCounter_i1_c;       /* '<S38>/torque_monitor' */
  uint16_T temporalCounter_i2;         /* '<S38>/torque_monitor' */
  uint16_T temporalCounter_i2_n;       /* '<S73>/Calibration_check' */
  uint16_T temporalCounter_i1_n4;      /* '<S78>/SDO read machine' */
  uint16_T temporalCounter_i1_b;       /* '<S77>/SDO read machine' */
  uint16_T temporalCounter_i2_a;       /* '<S28>/Send Control Machine' */
  boolean_T DelayInput1_DSTATE_c;      /* '<S347>/Delay Input1' */
  boolean_T DelayInput1_DSTATE_a;      /* '<S348>/Delay Input1' */
  int8_T CollisionResolution_SubsysRanBC;/* '<S21>/Collision Resolution' */
  int8_T Trial_Control_SubsysRanBC;    /* '<Root>/Trial_Control' */
  int8_T Ramp_up_down_SubsysRanBC;     /* '<S396>/Ramp_up_down' */
  int8_T enable_tables_SubsysRanBC;    /* '<S340>/enable_tables' */
  int8_T TaskExecutionControlMachine_SubsysRanBC;
                                   /* '<S336>/Task Execution Control Machine' */
  int8_T torque_monitor_SubsysRanBC;   /* '<S38>/torque_monitor' */
  int8_T applypmacloads_SubsysRanBC;   /* '<S33>/apply pmac loads' */
  int8_T EtherCATApplyLoads_SubsysRanBC;/* '<S33>/EtherCAT Apply Loads' */
  int8_T createKINData_SubsysRanBC;    /* '<S30>/createKINData' */
  int8_T Datawrite_SubsysRanBC;        /* '<S69>/Data write' */
  int8_T updatesettings_SubsysRanBC;   /* '<S68>/update settings' */
  int8_T update_SubsysRanBC;           /* '<S66>/update' */
  int8_T Datawrite_SubsysRanBC_h;      /* '<S70>/Data write' */
  int8_T updateconstantssubsystem_SubsysRanBC;/* '<S71>/update constants subsystem' */
  int8_T Datareceive_SubsysRanBC;      /* '<S70>/Data receive' */
  int8_T Datareceive_SubsysRanBC_n;    /* '<S69>/Data receive' */
  int8_T read_pmac_SubsysRanBC;        /* '<S68>/read_pmac' */
  int8_T WriteDPRAM_SubsysRanBC;       /* '<S264>/Write DPRAM' */
  int8_T ReadDPRAM_SubsysRanBC;        /* '<S264>/Read DPRAM' */
  int8_T DataTransferStartSubsystem_SubsysRanBC;
                                    /* '<S253>/Data Transfer Start Subsystem' */
  int8_T IfActionSubsystem_SubsysRanBC;/* '<S252>/If Action Subsystem' */
  int8_T Arm2_SubsysRanBC;             /* '<S66>/Arm 2' */
  int8_T M2AbsEncCalibration_SubsysRanBC;/* '<S78>/M2 AbsEnc Calibration' */
  int8_T M1AbsEncCalibration_SubsysRanBC;/* '<S78>/M1 AbsEnc Calibration' */
  int8_T Arm1_SubsysRanBC;             /* '<S66>/Arm 1' */
  int8_T M2AbsEncCalibration_SubsysRanBC_i;/* '<S77>/M2 AbsEnc Calibration' */
  int8_T M1AbsEncCalibration_SubsysRanBC_o;/* '<S77>/M1 AbsEnc Calibration' */
  int8_T sendpoll2_SubsysRanBC;        /* '<S29>/send poll 2' */
  int8_T sendpoll1_SubsysRanBC;        /* '<S29>/send poll 1' */
  int8_T plate2_SubsysRanBC;           /* '<S29>/plate2' */
  int8_T plate1_SubsysRanBC;           /* '<S29>/plate1' */
  int8_T SendControlMachine_SubsysRanBC;/* '<S28>/Send Control Machine' */
  int8_T UDPSendSubsystem_SubsysRanBC; /* '<S28>/UDP Send Subsystem' */
  uint8_T is_active_c1_may23;          /* '<S21>/Collision Resolution' */
  uint8_T is_c1_may23;                 /* '<S21>/Collision Resolution' */
  uint8_T is_active_UpdatePosition;    /* '<S21>/Collision Resolution' */
  uint8_T is_CollisionWithHand;        /* '<S21>/Collision Resolution' */
  uint8_T is_active_CollisionWithHand; /* '<S21>/Collision Resolution' */
  uint8_T is_active_UpdateVelocity;    /* '<S21>/Collision Resolution' */
  uint8_T is_active_c3_may23;          /* '<Root>/Trial_Control' */
  uint8_T is_c3_may23;                 /* '<Root>/Trial_Control' */
  uint8_T is_Main_Trial;               /* '<Root>/Trial_Control' */
  uint8_T is_active_c8_may23;          /* '<S396>/Ramp_up_down' */
  uint8_T is_c8_may23;                 /* '<S396>/Ramp_up_down' */
  uint8_T is_Perturbation;             /* '<S396>/Ramp_up_down' */
  uint8_T is_active_c42_General;   /* '<S336>/Task Execution Control Machine' */
  uint8_T is_c42_General;          /* '<S336>/Task Execution Control Machine' */
  uint8_T is_InTrial1;             /* '<S336>/Task Execution Control Machine' */
  uint8_T is_InTrial;              /* '<S336>/Task Execution Control Machine' */
  uint8_T temporalCounter_i1_h;    /* '<S336>/Task Execution Control Machine' */
  uint8_T is_active_c108_General;      /* '<S38>/torque_monitor' */
  uint8_T is_c108_General;             /* '<S38>/torque_monitor' */
  uint8_T is_Robot1;                   /* '<S38>/torque_monitor' */
  uint8_T is_active_Robot1;            /* '<S38>/torque_monitor' */
  uint8_T is_Robot2;                   /* '<S38>/torque_monitor' */
  uint8_T is_active_Robot2;            /* '<S38>/torque_monitor' */
  uint8_T is_active_c79_General;       /* '<S329>/monitor_encoders' */
  uint8_T is_c79_General;              /* '<S329>/monitor_encoders' */
  uint8_T is_active_c58_General;       /* '<S30>/control read write' */
  uint8_T is_c58_General;              /* '<S30>/control read write' */
  uint8_T is_active_c59_General;       /* '<S73>/Calibration_check' */
  uint8_T is_c59_General;              /* '<S73>/Calibration_check' */
  uint8_T is_Robot1_l;                 /* '<S73>/Calibration_check' */
  uint8_T is_active_Robot1_g;          /* '<S73>/Calibration_check' */
  uint8_T is_Robot2_j;                 /* '<S73>/Calibration_check' */
  uint8_T is_active_Robot2_i;          /* '<S73>/Calibration_check' */
  uint8_T temporalCounter_i1_n5;       /* '<S73>/Calibration_check' */
  uint8_T is_active_c10_ethercat;      /* '<S82>/master_state' */
  uint8_T is_c10_ethercat;             /* '<S82>/master_state' */
  uint8_T prevRunStatus;               /* '<S81>/update digital outputs' */
  uint8_T is_active_c95_ethercat;      /* '<S78>/SDO read machine' */
  uint8_T is_c95_ethercat;             /* '<S78>/SDO read machine' */
  uint8_T is_active_c37_ethercat;      /* '<S77>/SDO read machine' */
  uint8_T is_c37_ethercat;             /* '<S77>/SDO read machine' */
  uint8_T is_active_c3_General;        /* '<S28>/Send Control Machine' */
  uint8_T is_UpdatePacketQueue;        /* '<S28>/Send Control Machine' */
  uint8_T is_active_UpdatePacketQueue; /* '<S28>/Send Control Machine' */
  uint8_T is_SendControlMachine;       /* '<S28>/Send Control Machine' */
  uint8_T is_active_SendControlMachine;/* '<S28>/Send Control Machine' */
  uint8_T is_Fixed;                    /* '<S28>/Send Control Machine' */
  uint8_T is_FixMonitor;               /* '<S28>/Send Control Machine' */
  uint8_T is_active_FixMonitor;        /* '<S28>/Send Control Machine' */
  uint8_T temporalCounter_i1_i;        /* '<S28>/Send Control Machine' */
  uint8_T temporalCounter_i3;          /* '<S28>/Send Control Machine' */
  boolean_T Delay_PreviousInput;       /* '<S336>/Delay' */
  boolean_T Memory1_PreviousInput_lw;  /* '<Root>/Memory1' */
  boolean_T Memory4_PreviousInput;     /* '<Root>/Memory4' */
  boolean_T trials_per_block_not_empty;/* '<S337>/MATLAB Function' */
  boolean_T check_not_empty;           /* '<S33>/verify NaN' */
  boolean_T BKINEtherCATinit1_DWORK3;  /* '<S66>/BKIN EtherCATinit1' */
  boolean_T BKINEtherCATinit_DWORK3;   /* '<S66>/BKIN EtherCATinit' */
  boolean_T RateTransition_Buffer_h;   /* '<S69>/Rate Transition' */
  boolean_T lastECATMessages_not_empty;/* '<S73>/record errors' */
  boolean_T servoCounter_not_empty;    /* '<S86>/create servo counter' */
  boolean_T secondaryPosData_not_empty;/* '<S86>/create kinematics' */
  boolean_T RateTransition1_Buffer0_l; /* '<S54>/Rate Transition1' */
  boolean_T Arm2_MODE;                 /* '<S66>/Arm 2' */
  boolean_T M2AbsEncCalibration_MODE;  /* '<S78>/M2 AbsEnc Calibration' */
  boolean_T M1AbsEncCalibration_MODE;  /* '<S78>/M1 AbsEnc Calibration' */
  boolean_T Arm1_MODE;                 /* '<S66>/Arm 1' */
  boolean_T M2AbsEncCalibration_MODE_p;/* '<S77>/M2 AbsEnc Calibration' */
  boolean_T M1AbsEncCalibration_MODE_c;/* '<S77>/M1 AbsEnc Calibration' */
  DW_Ramp_Up_Down_may23_o_T sf_Ramp_Up_Down1_h;/* '<S5>/Ramp_Up_Down1' */
  DW_Ramp_Up_Down_may23_o_T sf_Ramp_Up_Down_g;/* '<S5>/Ramp_Up_Down' */
  DW_Ramp_Up_Down_may23_T sf_Ramp_Up_Down1;/* '<S4>/Ramp_Up_Down1' */
  DW_Ramp_Up_Down_may23_T sf_Ramp_Up_Down;/* '<S4>/Ramp_Up_Down' */
  DW_Createtimestamp_may23_T sf_Createtimestamp_o;/* '<S253>/Create timestamp' */
  DW_Createtimestamp_may23_T sf_Createtimestamp;/* '<S252>/Create timestamp' */
  DW_SDOwritemachine_may23_T sf_SDOwritemachine_g;/* '<S169>/SDO write machine' */
  DW_SDOreadmachine_may23_T sf_SDOreadmachine_f;/* '<S168>/SDO read machine' */
  DW_AbsEncodermachine_may23_T sf_AbsEncodermachine_n;/* '<S166>/AbsEncoder machine' */
  DW_AbsEncodermachine_may23_T sf_AbsEncodermachine_j;/* '<S165>/AbsEncoder machine' */
  DW_Whistlestate_may23_T sf_Whistlestate_m;/* '<S163>/Whistle state' */
  DW_passemcy_may23_T sf_passemcy_e;   /* '<S199>/pass emcy' */
  DW_faultmonitor_may23_T sf_faultmonitor_h;/* '<S199>/fault monitor' */
  DW_ReadEMCY_may23_T sf_ReadEMCY_o;   /* '<S199>/Read EMCY' */
  DW_Whistlestate_may23_T sf_Whistlestate_l;/* '<S162>/Whistle state' */
  DW_passemcy_may23_T sf_passemcy_c;   /* '<S179>/pass emcy' */
  DW_faultmonitor_may23_T sf_faultmonitor_f;/* '<S179>/fault monitor' */
  DW_ReadEMCY_may23_T sf_ReadEMCY_b;   /* '<S179>/Read EMCY' */
  DW_SDOwritemachine_may23_T sf_SDOwritemachine;/* '<S95>/SDO write machine' */
  DW_SDOreadmachine_may23_T sf_SDOreadmachine_i;/* '<S94>/SDO read machine' */
  DW_AbsEncodermachine_may23_T sf_AbsEncodermachine_l;/* '<S92>/AbsEncoder machine' */
  DW_AbsEncodermachine_may23_T sf_AbsEncodermachine;/* '<S91>/AbsEncoder machine' */
  DW_Whistlestate_may23_T sf_Whistlestate_a;/* '<S88>/Whistle state' */
  DW_passemcy_may23_T sf_passemcy_b;   /* '<S124>/pass emcy' */
  DW_faultmonitor_may23_T sf_faultmonitor_m;/* '<S124>/fault monitor' */
  DW_ReadEMCY_may23_T sf_ReadEMCY_h;   /* '<S124>/Read EMCY' */
  DW_Whistlestate_may23_T sf_Whistlestate;/* '<S87>/Whistle state' */
  DW_passemcy_may23_T sf_passemcy;     /* '<S104>/pass emcy' */
  DW_faultmonitor_may23_T sf_faultmonitor;/* '<S104>/fault monitor' */
  DW_ReadEMCY_may23_T sf_ReadEMCY;     /* '<S104>/Read EMCY' */
} DW_may23_T;

/* Zero-crossing (trigger) state */
typedef struct {
  ZCSigState CollisionResolution_Trig_ZCE[2];/* '<S21>/Collision Resolution' */
  ZCSigState Trial_Control_Trig_ZCE[4];/* '<Root>/Trial_Control' */
  ZCSigState Ramp_up_down_Trig_ZCE[3]; /* '<S396>/Ramp_up_down' */
  ZCE_Ramp_Up_Down_may23_m_T sf_Ramp_Up_Down1_h;/* '<S5>/Ramp_Up_Down1' */
  ZCE_Ramp_Up_Down_may23_m_T sf_Ramp_Up_Down_g;/* '<S5>/Ramp_Up_Down' */
  ZCE_Ramp_Up_Down_may23_T sf_Ramp_Up_Down1;/* '<S4>/Ramp_Up_Down1' */
  ZCE_Ramp_Up_Down_may23_T sf_Ramp_Up_Down;/* '<S4>/Ramp_Up_Down' */
  ZCSigState TaskExecutionControlMachine_Trig_ZCE[2];
                                   /* '<S336>/Task Execution Control Machine' */
  ZCSigState torque_monitor_Trig_ZCE;  /* '<S38>/torque_monitor' */
  ZCSigState SendControlMachine_Trig_ZCE[3];/* '<S28>/Send Control Machine' */
} PrevZCX_may23_T;

/* Invariant block signals (default storage) */
typedef struct {
  const real_T Width;                  /* '<S22>/Width' */
  const real_T Width_g;                /* '<S23>/Width' */
  const real_T Width_o;                /* '<S24>/Width' */
  const real_T Width_m;                /* '<S25>/Width' */
  const real_T Width_f;                /* '<S26>/Width' */
  const real_T Width_i;                /* '<S259>/Width' */
  const real_T Width_c;                /* '<S257>/Width' */
  const real_T Width_gf;               /* '<S63>/Width' */
  const real_T Width_h;                /* '<S62>/Width' */
  const real_T Width_g1;               /* '<S53>/Width' */
  const real_T Width_j;                /* '<S27>/Width' */
  const uint32_T Width1;               /* '<S336>/Width1' */
} ConstB_may23_T;

/* Backward compatible GRT Identifiers */
#define rtB                            may23_B
#define BlockIO                        B_may23_T
#define rtP                            may23_P
#define Parameters                     P_may23_T
#define rtDWork                        may23_DW
#define D_Work                         DW_may23_T
#define tConstBlockIOType              ConstB_may23_T
#define rtC                            may23_ConstB
#define rtPrevZCSigState               may23_PrevZCX
#define PrevZCSigStates                PrevZCX_may23_T

/* Parameters (default storage) */
struct P_may23_T_ {
  real_T BKIN_STEP_TIME;               /* Variable: BKIN_STEP_TIME
                                        * Referenced by:
                                        *   '<S335>/Hold_to_1Khz'
                                        *   '<S73>/step time'
                                        *   '<S86>/Constant'
                                        *   '<S262>/step duration'
                                        *   '<S283>/MATLAB Function'
                                        */
  real_T KINARM_HandInTarget_attribcol1;
                               /* Mask Parameter: KINARM_HandInTarget_attribcol1
                                * Referenced by: '<S7>/attribcol1'
                                */
  real_T KINARM_HandInBarrier_attribcol1[3];
                              /* Mask Parameter: KINARM_HandInBarrier_attribcol1
                               * Referenced by: '<S6>/attribcol1'
                               */
  real_T PuckInTarget_attribcol1;     /* Mask Parameter: PuckInTarget_attribcol1
                                       * Referenced by: '<S12>/attribcol1'
                                       */
  real_T PuckInBarrier_attribcol1[3];/* Mask Parameter: PuckInBarrier_attribcol1
                                      * Referenced by: '<S10>/attribcol1'
                                      */
  real_T Show_Cursor_attribcol1[4];    /* Mask Parameter: Show_Cursor_attribcol1
                                        * Referenced by: '<S14>/state1_indices'
                                        */
  real_T Show_Puck_attribcol1[4];      /* Mask Parameter: Show_Puck_attribcol1
                                        * Referenced by: '<S17>/state1_indices'
                                        */
  real_T Show_Goal_attribcol1[4];      /* Mask Parameter: Show_Goal_attribcol1
                                        * Referenced by: '<S15>/state1_indices'
                                        */
  real_T Show_Preshot_Area_attribcol1[4];
                                 /* Mask Parameter: Show_Preshot_Area_attribcol1
                                  * Referenced by: '<S16>/state1_indices'
                                  */
  real_T Show_Barrier_attribcol1[6];  /* Mask Parameter: Show_Barrier_attribcol1
                                       * Referenced by: '<S13>/state1_indices'
                                       */
  real_T Show_Start_attribcol1[4];     /* Mask Parameter: Show_Start_attribcol1
                                        * Referenced by: '<S18>/state1_indices'
                                        */
  real_T Show_Cursor_attribcol2[4];    /* Mask Parameter: Show_Cursor_attribcol2
                                        * Referenced by: '<S14>/state2_indices'
                                        */
  real_T Show_Puck_attribcol2[4];      /* Mask Parameter: Show_Puck_attribcol2
                                        * Referenced by: '<S17>/state2_indices'
                                        */
  real_T Show_Goal_attribcol2[4];      /* Mask Parameter: Show_Goal_attribcol2
                                        * Referenced by: '<S15>/state2_indices'
                                        */
  real_T Show_Preshot_Area_attribcol2[4];
                                 /* Mask Parameter: Show_Preshot_Area_attribcol2
                                  * Referenced by: '<S16>/state2_indices'
                                  */
  real_T Show_Barrier_attribcol2[6];  /* Mask Parameter: Show_Barrier_attribcol2
                                       * Referenced by: '<S13>/state2_indices'
                                       */
  real_T Show_Start_attribcol2[4];     /* Mask Parameter: Show_Start_attribcol2
                                        * Referenced by: '<S18>/state2_indices'
                                        */
  real_T Show_Cursor_attribcol3[4];    /* Mask Parameter: Show_Cursor_attribcol3
                                        * Referenced by: '<S14>/state3_indices'
                                        */
  real_T Show_Puck_attribcol3[4];      /* Mask Parameter: Show_Puck_attribcol3
                                        * Referenced by: '<S17>/state3_indices'
                                        */
  real_T Show_Goal_attribcol3[4];      /* Mask Parameter: Show_Goal_attribcol3
                                        * Referenced by: '<S15>/state3_indices'
                                        */
  real_T Show_Preshot_Area_attribcol3[4];
                                 /* Mask Parameter: Show_Preshot_Area_attribcol3
                                  * Referenced by: '<S16>/state3_indices'
                                  */
  real_T Show_Barrier_attribcol3[6];  /* Mask Parameter: Show_Barrier_attribcol3
                                       * Referenced by: '<S13>/state3_indices'
                                       */
  real_T Show_Start_attribcol3[4];     /* Mask Parameter: Show_Start_attribcol3
                                        * Referenced by: '<S18>/state3_indices'
                                        */
  real_T isecat_const;                 /* Mask Parameter: isecat_const
                                        * Referenced by: '<S74>/Constant'
                                        */
  real_T ispmac1_const;                /* Mask Parameter: ispmac1_const
                                        * Referenced by: '<S285>/Constant'
                                        */
  real_T ispmac1_const_o;              /* Mask Parameter: ispmac1_const_o
                                        * Referenced by: '<S279>/Constant'
                                        */
  real_T ispmac_const;                 /* Mask Parameter: ispmac_const
                                        * Referenced by: '<S261>/Constant'
                                        */
  real_T isecat_const_n;               /* Mask Parameter: isecat_const_n
                                        * Referenced by: '<S314>/Constant'
                                        */
  real_T isecat1_const;                /* Mask Parameter: isecat1_const
                                        * Referenced by: '<S315>/Constant'
                                        */
  real_T CompareToConstant_const;     /* Mask Parameter: CompareToConstant_const
                                       * Referenced by: '<S324>/Constant'
                                       */
  real_T KINARM_EP_Apply_Loads_down_duration;
                          /* Mask Parameter: KINARM_EP_Apply_Loads_down_duration
                           * Referenced by:
                           *   '<S4>/down_duration(ms)'
                           *   '<S4>/down_duration(ms)1'
                           */
  real_T KINARM_Exo_Apply_Loads_down_duration;
                         /* Mask Parameter: KINARM_Exo_Apply_Loads_down_duration
                          * Referenced by: '<S5>/down_duration(ms)'
                          */
  real_T Hand_Feedback_feedback_cntl_src;
                              /* Mask Parameter: Hand_Feedback_feedback_cntl_src
                               * Referenced by: '<S405>/block_settings'
                               */
  real_T KINARM_Exo_Apply_Loads_limit_motors;
                          /* Mask Parameter: KINARM_Exo_Apply_Loads_limit_motors
                           * Referenced by:
                           *   '<S5>/Torque Limit1'
                           *   '<S369>/Torque Limit4'
                           */
  real_T Perturbation_loadcol[3];      /* Mask Parameter: Perturbation_loadcol
                                        * Referenced by: '<S396>/load_table_column_indices'
                                        */
  real_T KINARM_EP_Apply_Loads_max_force;
                              /* Mask Parameter: KINARM_EP_Apply_Loads_max_force
                               * Referenced by: '<S4>/Force Limit'
                               */
  real_T KINARM_Exo_Apply_Loads_max_torque;
                            /* Mask Parameter: KINARM_Exo_Apply_Loads_max_torque
                             * Referenced by:
                             *   '<S5>/Torque Limit'
                             *   '<S369>/Torque Limit3'
                             */
  real_T KINARM_HandInTarget_num_states;
                               /* Mask Parameter: KINARM_HandInTarget_num_states
                                * Referenced by: '<S7>/num_states'
                                */
  real_T KINARM_HandInBarrier_num_states;
                              /* Mask Parameter: KINARM_HandInBarrier_num_states
                               * Referenced by: '<S6>/num_states'
                               */
  real_T PuckInTarget_num_states;     /* Mask Parameter: PuckInTarget_num_states
                                       * Referenced by: '<S12>/num_states'
                                       */
  real_T PuckInBarrier_num_states;   /* Mask Parameter: PuckInBarrier_num_states
                                      * Referenced by: '<S10>/num_states'
                                      */
  real_T Show_Cursor_num_states;       /* Mask Parameter: Show_Cursor_num_states
                                        * Referenced by: '<S14>/num_states'
                                        */
  real_T Show_Puck_num_states;         /* Mask Parameter: Show_Puck_num_states
                                        * Referenced by: '<S17>/num_states'
                                        */
  real_T Show_Goal_num_states;         /* Mask Parameter: Show_Goal_num_states
                                        * Referenced by: '<S15>/num_states'
                                        */
  real_T Show_Preshot_Area_num_states;
                                 /* Mask Parameter: Show_Preshot_Area_num_states
                                  * Referenced by: '<S16>/num_states'
                                  */
  real_T Show_Barrier_num_states;     /* Mask Parameter: Show_Barrier_num_states
                                       * Referenced by: '<S13>/num_states'
                                       */
  real_T Show_Start_num_states;        /* Mask Parameter: Show_Start_num_states
                                        * Referenced by: '<S18>/num_states'
                                        */
  real_T Show_Cursor_opacity;          /* Mask Parameter: Show_Cursor_opacity
                                        * Referenced by: '<S14>/Opacity'
                                        */
  real_T Show_Puck_opacity;            /* Mask Parameter: Show_Puck_opacity
                                        * Referenced by: '<S17>/Opacity'
                                        */
  real_T Show_Goal_opacity;            /* Mask Parameter: Show_Goal_opacity
                                        * Referenced by: '<S15>/Opacity'
                                        */
  real_T Show_Preshot_Area_opacity; /* Mask Parameter: Show_Preshot_Area_opacity
                                     * Referenced by: '<S16>/Opacity'
                                     */
  real_T Show_Barrier_opacity;         /* Mask Parameter: Show_Barrier_opacity
                                        * Referenced by: '<S13>/Opacity'
                                        */
  real_T Show_Start_opacity;           /* Mask Parameter: Show_Start_opacity
                                        * Referenced by: '<S18>/Opacity'
                                        */
  real_T Show_Cursor_target_display;
                                   /* Mask Parameter: Show_Cursor_target_display
                                    * Referenced by: '<S14>/Target_Display'
                                    */
  real_T Show_Puck_target_display;   /* Mask Parameter: Show_Puck_target_display
                                      * Referenced by: '<S17>/Target_Display'
                                      */
  real_T Show_Goal_target_display;   /* Mask Parameter: Show_Goal_target_display
                                      * Referenced by: '<S15>/Target_Display'
                                      */
  real_T Show_Preshot_Area_target_display;
                             /* Mask Parameter: Show_Preshot_Area_target_display
                              * Referenced by: '<S16>/Target_Display'
                              */
  real_T Show_Barrier_target_display;
                                  /* Mask Parameter: Show_Barrier_target_display
                                   * Referenced by: '<S13>/Target_Display'
                                   */
  real_T Show_Start_target_display; /* Mask Parameter: Show_Start_target_display
                                     * Referenced by: '<S18>/Target_Display'
                                     */
  real_T KINARM_HandInTarget_target_type;
                              /* Mask Parameter: KINARM_HandInTarget_target_type
                               * Referenced by: '<S7>/Target_Type'
                               */
  real_T KINARM_HandInBarrier_target_type;
                             /* Mask Parameter: KINARM_HandInBarrier_target_type
                              * Referenced by: '<S6>/Target_Type'
                              */
  real_T PuckInTarget_target_type;   /* Mask Parameter: PuckInTarget_target_type
                                      * Referenced by: '<S12>/Target_Type'
                                      */
  real_T PuckInBarrier_target_type; /* Mask Parameter: PuckInBarrier_target_type
                                     * Referenced by: '<S10>/Target_Type'
                                     */
  real_T Show_Cursor_target_type;     /* Mask Parameter: Show_Cursor_target_type
                                       * Referenced by: '<S14>/Target_Type'
                                       */
  real_T Show_Puck_target_type;        /* Mask Parameter: Show_Puck_target_type
                                        * Referenced by: '<S17>/Target_Type'
                                        */
  real_T Show_Goal_target_type;        /* Mask Parameter: Show_Goal_target_type
                                        * Referenced by: '<S15>/Target_Type'
                                        */
  real_T Show_Preshot_Area_target_type;
                                /* Mask Parameter: Show_Preshot_Area_target_type
                                 * Referenced by: '<S16>/Target_Type'
                                 */
  real_T Show_Barrier_target_type;   /* Mask Parameter: Show_Barrier_target_type
                                      * Referenced by: '<S13>/Target_Type'
                                      */
  real_T Show_Start_target_type;       /* Mask Parameter: Show_Start_target_type
                                        * Referenced by: '<S18>/Target_Type'
                                        */
  real_T GUIControl_tp_table_rows;   /* Mask Parameter: GUIControl_tp_table_rows
                                      * Referenced by: '<S336>/Constant1'
                                      */
  real_T KINARM_EP_Apply_Loads_up_duration;
                            /* Mask Parameter: KINARM_EP_Apply_Loads_up_duration
                             * Referenced by:
                             *   '<S4>/up_duration(ms)'
                             *   '<S4>/up_duration(ms)1'
                             */
  real_T KINARM_Exo_Apply_Loads_up_duration;
                           /* Mask Parameter: KINARM_Exo_Apply_Loads_up_duration
                            * Referenced by: '<S5>/up_duration(ms)'
                            */
  real_T KINARM_HandInTarget_use_dominant_hand;
                        /* Mask Parameter: KINARM_HandInTarget_use_dominant_hand
                         * Referenced by: '<S7>/Use_Dominant_Hand?'
                         */
  real_T KINARM_HandInBarrier_use_dominant_hand;
                       /* Mask Parameter: KINARM_HandInBarrier_use_dominant_hand
                        * Referenced by: '<S6>/Use_Dominant_Hand?'
                        */
  real_T Process_Video_CMD_video_delay;
                                /* Mask Parameter: Process_Video_CMD_video_delay
                                 * Referenced by: '<S9>/Constant'
                                 */
  real_T DetectChange_vinit;           /* Mask Parameter: DetectChange_vinit
                                        * Referenced by: '<S256>/Delay Input1'
                                        */
  real_T DetectChange_vinit_k;         /* Mask Parameter: DetectChange_vinit_k
                                        * Referenced by: '<S260>/Delay Input1'
                                        */
  int32_T Compare_const;               /* Mask Parameter: Compare_const
                                        * Referenced by: '<S103>/Constant'
                                        */
  int32_T Compare_const_f;             /* Mask Parameter: Compare_const_f
                                        * Referenced by: '<S123>/Constant'
                                        */
  int32_T Compare_const_p;             /* Mask Parameter: Compare_const_p
                                        * Referenced by: '<S178>/Constant'
                                        */
  int32_T Compare_const_d;             /* Mask Parameter: Compare_const_d
                                        * Referenced by: '<S198>/Constant'
                                        */
  uint32_T WrapToZero_Threshold;       /* Mask Parameter: WrapToZero_Threshold
                                        * Referenced by: '<S58>/FixPt Switch'
                                        */
  uint32_T WrapToZero_Threshold_h;     /* Mask Parameter: WrapToZero_Threshold_h
                                        * Referenced by: '<S289>/FixPt Switch'
                                        */
  uint32_T WrapToZero_Threshold_m;     /* Mask Parameter: WrapToZero_Threshold_m
                                        * Referenced by: '<S302>/FixPt Switch'
                                        */
  uint32_T WrapToZero_Threshold_d;     /* Mask Parameter: WrapToZero_Threshold_d
                                        * Referenced by: '<S237>/FixPt Switch'
                                        */
  uint32_T WrapToZero_Threshold_c;     /* Mask Parameter: WrapToZero_Threshold_c
                                        * Referenced by: '<S281>/FixPt Switch'
                                        */
  uint32_T WrapToZero_Threshold_f;     /* Mask Parameter: WrapToZero_Threshold_f
                                        * Referenced by: '<S353>/FixPt Switch'
                                        */
  uint32_T WrapToZero_Threshold_my;   /* Mask Parameter: WrapToZero_Threshold_my
                                       * Referenced by: '<S49>/FixPt Switch'
                                       */
  uint32_T Compare_const_i;            /* Mask Parameter: Compare_const_i
                                        * Referenced by: '<S79>/Constant'
                                        */
  uint32_T is_running_const;           /* Mask Parameter: is_running_const
                                        * Referenced by: '<S278>/Constant'
                                        */
  uint32_T CompareToConstant_const_f;
                                    /* Mask Parameter: CompareToConstant_const_f
                                     * Referenced by: '<S349>/Constant'
                                     */
  uint32_T CompareToConstant_const_g;
                                    /* Mask Parameter: CompareToConstant_const_g
                                     * Referenced by: '<S343>/Constant'
                                     */
  uint32_T IfRunning_const;            /* Mask Parameter: IfRunning_const
                                        * Referenced by: '<S47>/Constant'
                                        */
  uint16_T WrapToZero_Threshold_cm;   /* Mask Parameter: WrapToZero_Threshold_cm
                                       * Referenced by: '<S273>/FixPt Switch'
                                       */
  boolean_T DetectChange_vinit_m;      /* Mask Parameter: DetectChange_vinit_m
                                        * Referenced by: '<S347>/Delay Input1'
                                        */
  boolean_T DetectChange1_vinit;       /* Mask Parameter: DetectChange1_vinit
                                        * Referenced by: '<S348>/Delay Input1'
                                        */
  real_T const_Value[5];               /* Expression: [1 1 1 1 1]
                                        * Referenced by: '<S27>/const'
                                        */
  real_T Send_P1_Size[2];              /* Computed Parameter: Send_P1_Size
                                        * Referenced by: '<S27>/Send'
                                        */
  real_T Send_P1[26];                  /* Computed Parameter: Send_P1
                                        * Referenced by: '<S27>/Send'
                                        */
  real_T Send_P2_Size[2];              /* Computed Parameter: Send_P2_Size
                                        * Referenced by: '<S27>/Send'
                                        */
  real_T Send_P2;                      /* Expression: localPort
                                        * Referenced by: '<S27>/Send'
                                        */
  real_T Send_P3_Size[2];              /* Computed Parameter: Send_P3_Size
                                        * Referenced by: '<S27>/Send'
                                        */
  real_T Send_P3[11];                  /* Computed Parameter: Send_P3
                                        * Referenced by: '<S27>/Send'
                                        */
  real_T Send_P4_Size[2];              /* Computed Parameter: Send_P4_Size
                                        * Referenced by: '<S27>/Send'
                                        */
  real_T Send_P4;                      /* Expression: toPort
                                        * Referenced by: '<S27>/Send'
                                        */
  real_T Send_P5_Size[2];              /* Computed Parameter: Send_P5_Size
                                        * Referenced by: '<S27>/Send'
                                        */
  real_T Send_P5;                      /* Expression: useHostTargetComm
                                        * Referenced by: '<S27>/Send'
                                        */
  real_T Send_P6_Size[2];              /* Computed Parameter: Send_P6_Size
                                        * Referenced by: '<S27>/Send'
                                        */
  real_T Send_P6;                      /* Expression: sampleTime
                                        * Referenced by: '<S27>/Send'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S50>/Constant1'
                                        */
  real_T Constant_Value;               /* Expression: 1
                                        * Referenced by: '<S55>/Constant'
                                        */
  real_T UnitDelay_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S55>/Unit Delay'
                                        */
  real_T MaxFramesPerPacket_Value;     /* Expression: 3
                                        * Referenced by: '<S50>/Max Frames Per Packet'
                                        */
  real_T Send_P1_Size_k[2];            /* Computed Parameter: Send_P1_Size_k
                                        * Referenced by: '<S53>/Send'
                                        */
  real_T Send_P1_d[26];                /* Computed Parameter: Send_P1_d
                                        * Referenced by: '<S53>/Send'
                                        */
  real_T Send_P2_Size_j[2];            /* Computed Parameter: Send_P2_Size_j
                                        * Referenced by: '<S53>/Send'
                                        */
  real_T Send_P2_b;                    /* Expression: localPort
                                        * Referenced by: '<S53>/Send'
                                        */
  real_T Send_P3_Size_c[2];            /* Computed Parameter: Send_P3_Size_c
                                        * Referenced by: '<S53>/Send'
                                        */
  real_T Send_P3_i[11];                /* Computed Parameter: Send_P3_i
                                        * Referenced by: '<S53>/Send'
                                        */
  real_T Send_P4_Size_n[2];            /* Computed Parameter: Send_P4_Size_n
                                        * Referenced by: '<S53>/Send'
                                        */
  real_T Send_P4_a;                    /* Expression: toPort
                                        * Referenced by: '<S53>/Send'
                                        */
  real_T Send_P5_Size_o[2];            /* Computed Parameter: Send_P5_Size_o
                                        * Referenced by: '<S53>/Send'
                                        */
  real_T Send_P5_e;                    /* Expression: useHostTargetComm
                                        * Referenced by: '<S53>/Send'
                                        */
  real_T Send_P6_Size_a[2];            /* Computed Parameter: Send_P6_Size_a
                                        * Referenced by: '<S53>/Send'
                                        */
  real_T Send_P6_e;                    /* Expression: sampleTime
                                        * Referenced by: '<S53>/Send'
                                        */
  real_T runID_Value;                  /* Expression: 0
                                        * Referenced by: '<S28>/runID'
                                        */
  real_T Receive_P1_Size[2];           /* Computed Parameter: Receive_P1_Size
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P1[26];               /* Computed Parameter: Receive_P1
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P2_Size[2];           /* Computed Parameter: Receive_P2_Size
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P2;                   /* Expression: localPort
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P3_Size[2];           /* Computed Parameter: Receive_P3_Size
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P3;                   /* Expression: outWidth
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P4_Size[2];           /* Computed Parameter: Receive_P4_Size
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P4;                   /* Expression: useHostTargetComm
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P5_Size[2];           /* Computed Parameter: Receive_P5_Size
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P5[11];               /* Computed Parameter: Receive_P5
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P6_Size[2];           /* Computed Parameter: Receive_P6_Size
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P6;                   /* Expression: maxUDPQueue
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P7_Size[2];           /* Computed Parameter: Receive_P7_Size
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P7;                   /* Expression: rcvMulticast
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P8_Size[2];           /* Computed Parameter: Receive_P8_Size
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P9_Size[2];           /* Computed Parameter: Receive_P9_Size
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T Receive_P9;                   /* Expression: sampleTime
                                        * Referenced by: '<S52>/Receive'
                                        */
  real_T RateTransition2_InitialCondition;/* Expression: 0
                                           * Referenced by: '<S54>/Rate Transition2'
                                           */
  real_T TaskClock_Amp;                /* Expression: 1
                                        * Referenced by: '<S28>/Task Clock'
                                        */
  real_T TaskClock_Period;             /* Computed Parameter: TaskClock_Period
                                        * Referenced by: '<S28>/Task Clock'
                                        */
  real_T TaskClock_Duty;               /* Computed Parameter: TaskClock_Duty
                                        * Referenced by: '<S28>/Task Clock'
                                        */
  real_T TaskClock_PhaseDelay;         /* Expression: 0
                                        * Referenced by: '<S28>/Task Clock'
                                        */
  real_T Memory2_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S52>/Memory2'
                                        */
  real_T Memory1_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S52>/Memory1'
                                        */
  real_T Receive_P1_Size_h[2];         /* Computed Parameter: Receive_P1_Size_h
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P1_d[26];             /* Computed Parameter: Receive_P1_d
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P2_Size_l[2];         /* Computed Parameter: Receive_P2_Size_l
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P2_p;                 /* Expression: localPort
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P3_Size_p[2];         /* Computed Parameter: Receive_P3_Size_p
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P3_g;                 /* Expression: outWidth
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P4_Size_k[2];         /* Computed Parameter: Receive_P4_Size_k
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P4_g;                 /* Expression: useHostTargetComm
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P5_Size_n[2];         /* Computed Parameter: Receive_P5_Size_n
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P5_a[13];             /* Computed Parameter: Receive_P5_a
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P6_Size_b[2];         /* Computed Parameter: Receive_P6_Size_b
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P6_k;                 /* Expression: maxUDPQueue
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P7_Size_b[2];         /* Computed Parameter: Receive_P7_Size_b
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P7_n;                 /* Expression: rcvMulticast
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P8_Size_i[2];         /* Computed Parameter: Receive_P8_Size_i
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P9_Size_k[2];         /* Computed Parameter: Receive_P9_Size_k
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive_P9_l;                 /* Expression: sampleTime
                                        * Referenced by: '<S60>/Receive'
                                        */
  real_T Receive1_P1_Size[2];          /* Computed Parameter: Receive1_P1_Size
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P1[26];              /* Computed Parameter: Receive1_P1
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P2_Size[2];          /* Computed Parameter: Receive1_P2_Size
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P2;                  /* Expression: localPort
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P3_Size[2];          /* Computed Parameter: Receive1_P3_Size
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P3;                  /* Expression: outWidth
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P4_Size[2];          /* Computed Parameter: Receive1_P4_Size
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P4;                  /* Expression: useHostTargetComm
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P5_Size[2];          /* Computed Parameter: Receive1_P5_Size
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P5[13];              /* Computed Parameter: Receive1_P5
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P6_Size[2];          /* Computed Parameter: Receive1_P6_Size
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P6;                  /* Expression: maxUDPQueue
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P7_Size[2];          /* Computed Parameter: Receive1_P7_Size
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P7;                  /* Expression: rcvMulticast
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P8_Size[2];          /* Computed Parameter: Receive1_P8_Size
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P9_Size[2];          /* Computed Parameter: Receive1_P9_Size
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Receive1_P9;                  /* Expression: sampleTime
                                        * Referenced by: '<S61>/Receive1'
                                        */
  real_T Send_P1_Size_ki[2];           /* Computed Parameter: Send_P1_Size_ki
                                        * Referenced by: '<S62>/Send'
                                        */
  real_T Send_P1_o[26];                /* Computed Parameter: Send_P1_o
                                        * Referenced by: '<S62>/Send'
                                        */
  real_T Send_P2_Size_o[2];            /* Computed Parameter: Send_P2_Size_o
                                        * Referenced by: '<S62>/Send'
                                        */
  real_T Send_P2_bb;                   /* Expression: localPort
                                        * Referenced by: '<S62>/Send'
                                        */
  real_T Send_P3_Size_a[2];            /* Computed Parameter: Send_P3_Size_a
                                        * Referenced by: '<S62>/Send'
                                        */
  real_T Send_P3_m[13];                /* Computed Parameter: Send_P3_m
                                        * Referenced by: '<S62>/Send'
                                        */
  real_T Send_P4_Size_e[2];            /* Computed Parameter: Send_P4_Size_e
                                        * Referenced by: '<S62>/Send'
                                        */
  real_T Send_P4_f;                    /* Expression: toPort
                                        * Referenced by: '<S62>/Send'
                                        */
  real_T Send_P5_Size_j[2];            /* Computed Parameter: Send_P5_Size_j
                                        * Referenced by: '<S62>/Send'
                                        */
  real_T Send_P5_i;                    /* Expression: useHostTargetComm
                                        * Referenced by: '<S62>/Send'
                                        */
  real_T Send_P6_Size_k[2];            /* Computed Parameter: Send_P6_Size_k
                                        * Referenced by: '<S62>/Send'
                                        */
  real_T Send_P6_p;                    /* Expression: sampleTime
                                        * Referenced by: '<S62>/Send'
                                        */
  real_T Send1_P1_Size[2];             /* Computed Parameter: Send1_P1_Size
                                        * Referenced by: '<S63>/Send1'
                                        */
  real_T Send1_P1[26];                 /* Computed Parameter: Send1_P1
                                        * Referenced by: '<S63>/Send1'
                                        */
  real_T Send1_P2_Size[2];             /* Computed Parameter: Send1_P2_Size
                                        * Referenced by: '<S63>/Send1'
                                        */
  real_T Send1_P2;                     /* Expression: localPort
                                        * Referenced by: '<S63>/Send1'
                                        */
  real_T Send1_P3_Size[2];             /* Computed Parameter: Send1_P3_Size
                                        * Referenced by: '<S63>/Send1'
                                        */
  real_T Send1_P3[13];                 /* Computed Parameter: Send1_P3
                                        * Referenced by: '<S63>/Send1'
                                        */
  real_T Send1_P4_Size[2];             /* Computed Parameter: Send1_P4_Size
                                        * Referenced by: '<S63>/Send1'
                                        */
  real_T Send1_P4;                     /* Expression: toPort
                                        * Referenced by: '<S63>/Send1'
                                        */
  real_T Send1_P5_Size[2];             /* Computed Parameter: Send1_P5_Size
                                        * Referenced by: '<S63>/Send1'
                                        */
  real_T Send1_P5;                     /* Expression: useHostTargetComm
                                        * Referenced by: '<S63>/Send1'
                                        */
  real_T Send1_P6_Size[2];             /* Computed Parameter: Send1_P6_Size
                                        * Referenced by: '<S63>/Send1'
                                        */
  real_T Send1_P6;                     /* Expression: sampleTime
                                        * Referenced by: '<S63>/Send1'
                                        */
  real_T gain_Value;                   /* Expression: 256
                                        * Referenced by: '<S29>/gain'
                                        */
  real_T calibration_matrix1_Value[48];/* Expression: zeros(6,8)
                                        * Referenced by: '<S29>/calibration_matrix1'
                                        */
  real_T ain_slope1_Value;             /* Expression: -1
                                        * Referenced by: '<S29>/ain_slope1'
                                        */
  real_T ain_offset1_Value;            /* Expression: -1
                                        * Referenced by: '<S29>/ain_offset1'
                                        */
  real_T orientation1_Value;           /* Expression: 0
                                        * Referenced by: '<S29>/orientation1'
                                        */
  real_T zero_voltage_Value;           /* Expression: 0
                                        * Referenced by: '<S29>/zero_voltage'
                                        */
  real_T enable_plate1_Value;          /* Expression: 0
                                        * Referenced by: '<S29>/enable_plate1'
                                        */
  real_T calibration_matrix2_Value[48];/* Expression: zeros(6,8)
                                        * Referenced by: '<S29>/calibration_matrix2'
                                        */
  real_T ain_slope2_Value;             /* Expression: -1
                                        * Referenced by: '<S29>/ain_slope2'
                                        */
  real_T ain_offset2_Value;            /* Expression: -1
                                        * Referenced by: '<S29>/ain_offset2'
                                        */
  real_T orientation2_Value;           /* Expression: 0
                                        * Referenced by: '<S29>/orientation2'
                                        */
  real_T enable_plate2_Value;          /* Expression: 0
                                        * Referenced by: '<S29>/enable_plate2'
                                        */
  real_T driveID_Value;                /* Expression: 1
                                        * Referenced by: '<S104>/driveID'
                                        */
  real_T Memory_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S116>/Memory'
                                        */
  real_T driveID_Value_c;              /* Expression: 2
                                        * Referenced by: '<S124>/driveID'
                                        */
  real_T Memory_InitialCondition_k;    /* Expression: 0
                                        * Referenced by: '<S136>/Memory'
                                        */
  real_T readAddr_Value[3];            /* Expression: [0, 0, 0]
                                        * Referenced by: '<S94>/readAddr'
                                        */
  real_T writeData_Value[5];           /* Expression: [0, 0, 0, 0, 0]
                                        * Referenced by: '<S95>/writeData'
                                        */
  real_T BKINPDOReceiveElmoDrive_P1_Size[2];
                          /* Computed Parameter: BKINPDOReceiveElmoDrive_P1_Size
                           * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                           */
  real_T BKINPDOReceiveElmoDrive_P1[39];
                               /* Computed Parameter: BKINPDOReceiveElmoDrive_P1
                                * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                                */
  real_T BKINPDOReceiveElmoDrive_P2_Size[2];
                          /* Computed Parameter: BKINPDOReceiveElmoDrive_P2_Size
                           * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                           */
  real_T BKINPDOReceiveElmoDrive_P2;   /* Expression: sig_offset
                                        * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P3_Size[2];
                          /* Computed Parameter: BKINPDOReceiveElmoDrive_P3_Size
                           * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                           */
  real_T BKINPDOReceiveElmoDrive_P3;   /* Expression: sig_type
                                        * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P4_Size[2];
                          /* Computed Parameter: BKINPDOReceiveElmoDrive_P4_Size
                           * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                           */
  real_T BKINPDOReceiveElmoDrive_P4;   /* Expression: type_size
                                        * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P5_Size[2];
                          /* Computed Parameter: BKINPDOReceiveElmoDrive_P5_Size
                           * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                           */
  real_T BKINPDOReceiveElmoDrive_P5;   /* Expression: sig_dim
                                        * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P6_Size[2];
                          /* Computed Parameter: BKINPDOReceiveElmoDrive_P6_Size
                           * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                           */
  real_T BKINPDOReceiveElmoDrive_P6;   /* Expression: device_id
                                        * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P7_Size[2];
                          /* Computed Parameter: BKINPDOReceiveElmoDrive_P7_Size
                           * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                           */
  real_T BKINPDOReceiveElmoDrive_P7;   /* Expression: sample_time
                                        * Referenced by: '<S102>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T enableMotors_Value;           /* Expression: 1
                                        * Referenced by: '<S77>/enableMotors'
                                        */
  real_T Memory_InitialCondition_p;    /* Expression: 0
                                        * Referenced by: '<S87>/Memory'
                                        */
  real_T Memory_InitialCondition_ps;   /* Expression: 0
                                        * Referenced by: '<S88>/Memory'
                                        */
  real_T BKINEtherCATPDOTransmit_P1_Size[2];
                          /* Computed Parameter: BKINEtherCATPDOTransmit_P1_Size
                           * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                           */
  real_T BKINEtherCATPDOTransmit_P1[41];
                               /* Computed Parameter: BKINEtherCATPDOTransmit_P1
                                * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                                */
  real_T BKINEtherCATPDOTransmit_P2_Size[2];
                          /* Computed Parameter: BKINEtherCATPDOTransmit_P2_Size
                           * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                           */
  real_T BKINEtherCATPDOTransmit_P2;   /* Expression: sig_offset
                                        * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P3_Size[2];
                          /* Computed Parameter: BKINEtherCATPDOTransmit_P3_Size
                           * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                           */
  real_T BKINEtherCATPDOTransmit_P3;   /* Expression: sig_type
                                        * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P4_Size[2];
                          /* Computed Parameter: BKINEtherCATPDOTransmit_P4_Size
                           * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                           */
  real_T BKINEtherCATPDOTransmit_P4;   /* Expression: type_size
                                        * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P5_Size[2];
                          /* Computed Parameter: BKINEtherCATPDOTransmit_P5_Size
                           * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                           */
  real_T BKINEtherCATPDOTransmit_P5;   /* Expression: sig_dim
                                        * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P6_Size[2];
                          /* Computed Parameter: BKINEtherCATPDOTransmit_P6_Size
                           * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                           */
  real_T BKINEtherCATPDOTransmit_P6;   /* Expression: device_id
                                        * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P7_Size[2];
                          /* Computed Parameter: BKINEtherCATPDOTransmit_P7_Size
                           * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                           */
  real_T BKINEtherCATPDOTransmit_P7;   /* Expression: sample_time
                                        * Referenced by: '<S87>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T Memory1_InitialCondition_o;   /* Expression: 0
                                        * Referenced by: '<S97>/Memory1'
                                        */
  real_T MotorIdx_Value;               /* Expression: 1
                                        * Referenced by: '<S87>/MotorIdx'
                                        */
  real_T Memory2_InitialCondition_h;   /* Expression: 0
                                        * Referenced by: '<S77>/Memory2'
                                        */
  real_T Memory3_InitialCondition;     /* Expression: 0
                                        * Referenced by: '<S77>/Memory3'
                                        */
  real_T BKINPDOReceiveElmoDrive_P1_Size_o[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P1_Size_o
                         * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P1_c[39];
                             /* Computed Parameter: BKINPDOReceiveElmoDrive_P1_c
                              * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                              */
  real_T BKINPDOReceiveElmoDrive_P2_Size_i[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P2_Size_i
                         * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P2_i; /* Expression: sig_offset
                                        * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P3_Size_j[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P3_Size_j
                         * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P3_b; /* Expression: sig_type
                                        * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P4_Size_m[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P4_Size_m
                         * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P4_l; /* Expression: type_size
                                        * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P5_Size_p[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P5_Size_p
                         * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P5_b; /* Expression: sig_dim
                                        * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P6_Size_d[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P6_Size_d
                         * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P6_g; /* Expression: device_id
                                        * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P7_Size_k[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P7_Size_k
                         * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P7_i; /* Expression: sample_time
                                        * Referenced by: '<S122>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINEtherCATPDOTransmit_P1_Size_h[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P1_Size_h
                         * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P1_j[41];
                             /* Computed Parameter: BKINEtherCATPDOTransmit_P1_j
                              * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                              */
  real_T BKINEtherCATPDOTransmit_P2_Size_a[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P2_Size_a
                         * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P2_n; /* Expression: sig_offset
                                        * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P3_Size_o[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P3_Size_o
                         * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P3_a; /* Expression: sig_type
                                        * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P4_Size_g[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P4_Size_g
                         * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P4_m; /* Expression: type_size
                                        * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P5_Size_h[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P5_Size_h
                         * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P5_k; /* Expression: sig_dim
                                        * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P6_Size_h[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P6_Size_h
                         * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P6_f; /* Expression: device_id
                                        * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P7_Size_e[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P7_Size_e
                         * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P7_j; /* Expression: sample_time
                                        * Referenced by: '<S88>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T MotorIdx_Value_p;             /* Expression: 2
                                        * Referenced by: '<S88>/MotorIdx'
                                        */
  real_T enableCalibration_Value;      /* Expression: 0
                                        * Referenced by: '<S77>/enableCalibration'
                                        */
  real_T override_grip_Value;          /* Expression: 0
                                        * Referenced by: '<S89>/override_grip'
                                        */
  real_T BKINEtherCATPDOTransmit_P1_Size_e[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P1_Size_e
                         * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P1_c[48];
                             /* Computed Parameter: BKINEtherCATPDOTransmit_P1_c
                              * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                              */
  real_T BKINEtherCATPDOTransmit_P2_Size_e[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P2_Size_e
                         * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P2_p; /* Expression: sig_offset
                                        * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P3_Size_h[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P3_Size_h
                         * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P3_i; /* Expression: sig_type
                                        * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P4_Size_k[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P4_Size_k
                         * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P4_n; /* Expression: type_size
                                        * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P5_Size_n[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P5_Size_n
                         * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P5_o; /* Expression: sig_dim
                                        * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P6_Size_hz[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit_P6_Size_hz
                        * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                        */
  real_T BKINEtherCATPDOTransmit_P6_e; /* Expression: device_id
                                        * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P7_Size_m[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P7_Size_m
                         * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P7_p; /* Expression: sample_time
                                        * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit1_P1_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit1_P1_Size
                          * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                          */
  real_T BKINEtherCATPDOTransmit1_P1[48];
                              /* Computed Parameter: BKINEtherCATPDOTransmit1_P1
                               * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                               */
  real_T BKINEtherCATPDOTransmit1_P2_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit1_P2_Size
                          * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                          */
  real_T BKINEtherCATPDOTransmit1_P2;  /* Expression: sig_offset
                                        * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P3_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit1_P3_Size
                          * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                          */
  real_T BKINEtherCATPDOTransmit1_P3;  /* Expression: sig_type
                                        * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P4_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit1_P4_Size
                          * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                          */
  real_T BKINEtherCATPDOTransmit1_P4;  /* Expression: type_size
                                        * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P5_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit1_P5_Size
                          * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                          */
  real_T BKINEtherCATPDOTransmit1_P5;  /* Expression: sig_dim
                                        * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P6_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit1_P6_Size
                          * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                          */
  real_T BKINEtherCATPDOTransmit1_P6;  /* Expression: device_id
                                        * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P7_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit1_P7_Size
                          * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                          */
  real_T BKINEtherCATPDOTransmit1_P7;  /* Expression: sample_time
                                        * Referenced by: '<S89>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T driveID_Value_i;              /* Expression: 3
                                        * Referenced by: '<S179>/driveID'
                                        */
  real_T Memory_InitialCondition_pg;   /* Expression: 0
                                        * Referenced by: '<S191>/Memory'
                                        */
  real_T driveID_Value_n;              /* Expression: 4
                                        * Referenced by: '<S199>/driveID'
                                        */
  real_T Memory_InitialCondition_a;    /* Expression: 0
                                        * Referenced by: '<S211>/Memory'
                                        */
  real_T readAddr_Value_b[3];          /* Expression: [0, 0, 0]
                                        * Referenced by: '<S168>/readAddr'
                                        */
  real_T writeData_Value_o[5];         /* Expression: [0, 0, 0, 0, 0]
                                        * Referenced by: '<S169>/writeData'
                                        */
  real_T BKINPDOReceiveElmoDrive_P1_Size_a[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P1_Size_a
                         * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P1_cm[39];
                            /* Computed Parameter: BKINPDOReceiveElmoDrive_P1_cm
                             * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                             */
  real_T BKINPDOReceiveElmoDrive_P2_Size_i4[2];
                       /* Computed Parameter: BKINPDOReceiveElmoDrive_P2_Size_i4
                        * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                        */
  real_T BKINPDOReceiveElmoDrive_P2_m; /* Expression: sig_offset
                                        * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P3_Size_b[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P3_Size_b
                         * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P3_l; /* Expression: sig_type
                                        * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P4_Size_d[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P4_Size_d
                         * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P4_h; /* Expression: type_size
                                        * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P5_Size_d[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P5_Size_d
                         * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P5_i; /* Expression: sig_dim
                                        * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P6_Size_f[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P6_Size_f
                         * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P6_f; /* Expression: device_id
                                        * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P7_Size_b[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P7_Size_b
                         * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P7_o; /* Expression: sample_time
                                        * Referenced by: '<S177>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T enableMotors_Value_h;         /* Expression: 1
                                        * Referenced by: '<S78>/enableMotors'
                                        */
  real_T Memory_InitialCondition_d;    /* Expression: 0
                                        * Referenced by: '<S162>/Memory'
                                        */
  real_T Memory_InitialCondition_ki;   /* Expression: 0
                                        * Referenced by: '<S163>/Memory'
                                        */
  real_T BKINEtherCATPDOTransmit_P1_Size_o[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P1_Size_o
                         * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P1_i[41];
                             /* Computed Parameter: BKINEtherCATPDOTransmit_P1_i
                              * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                              */
  real_T BKINEtherCATPDOTransmit_P2_Size_n[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P2_Size_n
                         * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P2_c; /* Expression: sig_offset
                                        * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P3_Size_k[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P3_Size_k
                         * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P3_d; /* Expression: sig_type
                                        * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P4_Size_j[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P4_Size_j
                         * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P4_a; /* Expression: type_size
                                        * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P5_Size_j[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P5_Size_j
                         * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P5_n; /* Expression: sig_dim
                                        * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P6_Size_g[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P6_Size_g
                         * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P6_f4;/* Expression: device_id
                                        * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P7_Size_d[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P7_Size_d
                         * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P7_p1;/* Expression: sample_time
                                        * Referenced by: '<S162>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T Memory1_InitialCondition_e;   /* Expression: 0
                                        * Referenced by: '<S172>/Memory1'
                                        */
  real_T MotorIdx_Value_f;             /* Expression: 1
                                        * Referenced by: '<S162>/MotorIdx'
                                        */
  real_T Memory2_InitialCondition_i;   /* Expression: 0
                                        * Referenced by: '<S78>/Memory2'
                                        */
  real_T Memory3_InitialCondition_o;   /* Expression: 0
                                        * Referenced by: '<S78>/Memory3'
                                        */
  real_T BKINPDOReceiveElmoDrive_P1_Size_oe[2];
                       /* Computed Parameter: BKINPDOReceiveElmoDrive_P1_Size_oe
                        * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                        */
  real_T BKINPDOReceiveElmoDrive_P1_g[39];
                             /* Computed Parameter: BKINPDOReceiveElmoDrive_P1_g
                              * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                              */
  real_T BKINPDOReceiveElmoDrive_P2_Size_b[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P2_Size_b
                         * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P2_a; /* Expression: sig_offset
                                        * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P3_Size_e[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P3_Size_e
                         * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P3_bd;/* Expression: sig_type
                                        * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P4_Size_k[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P4_Size_k
                         * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P4_p; /* Expression: type_size
                                        * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P5_Size_o[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P5_Size_o
                         * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P5_f; /* Expression: sig_dim
                                        * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P6_Size_o[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P6_Size_o
                         * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P6_fu;/* Expression: device_id
                                        * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINPDOReceiveElmoDrive_P7_Size_a[2];
                        /* Computed Parameter: BKINPDOReceiveElmoDrive_P7_Size_a
                         * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                         */
  real_T BKINPDOReceiveElmoDrive_P7_g; /* Expression: sample_time
                                        * Referenced by: '<S197>/BKIN PDO Receive ElmoDrive'
                                        */
  real_T BKINEtherCATPDOTransmit_P1_Size_j[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P1_Size_j
                         * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P1_n[41];
                             /* Computed Parameter: BKINEtherCATPDOTransmit_P1_n
                              * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                              */
  real_T BKINEtherCATPDOTransmit_P2_Size_p[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P2_Size_p
                         * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P2_k; /* Expression: sig_offset
                                        * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P3_Size_l[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P3_Size_l
                         * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P3_b; /* Expression: sig_type
                                        * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P4_Size_ki[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit_P4_Size_ki
                        * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                        */
  real_T BKINEtherCATPDOTransmit_P4_k; /* Expression: type_size
                                        * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P5_Size_o[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P5_Size_o
                         * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P5_a; /* Expression: sig_dim
                                        * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P6_Size_d[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P6_Size_d
                         * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P6_g; /* Expression: device_id
                                        * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P7_Size_b[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P7_Size_b
                         * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P7_b; /* Expression: sample_time
                                        * Referenced by: '<S163>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T MotorIdx_Value_b;             /* Expression: 2
                                        * Referenced by: '<S163>/MotorIdx'
                                        */
  real_T enableCalibration_Value_k;    /* Expression: 0
                                        * Referenced by: '<S78>/enableCalibration'
                                        */
  real_T override_grip_Value_p;        /* Expression: 0
                                        * Referenced by: '<S170>/override_grip'
                                        */
  real_T BKINEtherCATPDOTransmit_P1_Size_p[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P1_Size_p
                         * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P1_m[48];
                             /* Computed Parameter: BKINEtherCATPDOTransmit_P1_m
                              * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                              */
  real_T BKINEtherCATPDOTransmit_P2_Size_k[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P2_Size_k
                         * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P2_g; /* Expression: sig_offset
                                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P3_Size_p[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P3_Size_p
                         * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P3_iv;/* Expression: sig_type
                                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P4_Size_m[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P4_Size_m
                         * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P4_j; /* Expression: type_size
                                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P5_Size_i[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P5_Size_i
                         * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P5_l; /* Expression: sig_dim
                                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P6_Size_g5[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit_P6_Size_g5
                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                        */
  real_T BKINEtherCATPDOTransmit_P6_i; /* Expression: device_id
                                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P7_Size_g[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P7_Size_g
                         * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P7_a; /* Expression: sample_time
                                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit1_P1_Size_j[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P1_Size_j
                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P1_d[48];
                            /* Computed Parameter: BKINEtherCATPDOTransmit1_P1_d
                             * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                             */
  real_T BKINEtherCATPDOTransmit1_P2_Size_n[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P2_Size_n
                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P2_a;/* Expression: sig_offset
                                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P3_Size_c[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P3_Size_c
                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P3_n;/* Expression: sig_type
                                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P4_Size_b[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P4_Size_b
                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P4_c;/* Expression: type_size
                                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P5_Size_g[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P5_Size_g
                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P5_c;/* Expression: sig_dim
                                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P6_Size_h[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P6_Size_h
                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P6_b;/* Expression: device_id
                                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P7_Size_f[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P7_Size_f
                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P7_g;/* Expression: sample_time
                                        * Referenced by: '<S170>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T Constant_Value_a[7];          /* Expression: zeros(1, 7);
                                        * Referenced by: '<S252>/Constant'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S257>/Switch'
                                        */
  real_T Send_P1_Size_b[2];            /* Computed Parameter: Send_P1_Size_b
                                        * Referenced by: '<S257>/Send'
                                        */
  real_T Send_P1_k[26];                /* Computed Parameter: Send_P1_k
                                        * Referenced by: '<S257>/Send'
                                        */
  real_T Send_P2_Size_a[2];            /* Computed Parameter: Send_P2_Size_a
                                        * Referenced by: '<S257>/Send'
                                        */
  real_T Send_P2_k;                    /* Expression: localPort
                                        * Referenced by: '<S257>/Send'
                                        */
  real_T Send_P3_Size_ab[2];           /* Computed Parameter: Send_P3_Size_ab
                                        * Referenced by: '<S257>/Send'
                                        */
  real_T Send_P3_a[12];                /* Computed Parameter: Send_P3_a
                                        * Referenced by: '<S257>/Send'
                                        */
  real_T Send_P4_Size_j[2];            /* Computed Parameter: Send_P4_Size_j
                                        * Referenced by: '<S257>/Send'
                                        */
  real_T Send_P4_d;                    /* Expression: toPort
                                        * Referenced by: '<S257>/Send'
                                        */
  real_T Send_P5_Size_e[2];            /* Computed Parameter: Send_P5_Size_e
                                        * Referenced by: '<S257>/Send'
                                        */
  real_T Send_P5_c;                    /* Expression: useHostTargetComm
                                        * Referenced by: '<S257>/Send'
                                        */
  real_T Send_P6_Size_e[2];            /* Computed Parameter: Send_P6_Size_e
                                        * Referenced by: '<S257>/Send'
                                        */
  real_T Send_P6_i;                    /* Expression: sampleTime
                                        * Referenced by: '<S257>/Send'
                                        */
  real_T Constant1_Value_k[7];         /* Expression: zeros(1, 7);
                                        * Referenced by: '<S253>/Constant1'
                                        */
  real_T Switch_Threshold_k;           /* Expression: 0
                                        * Referenced by: '<S259>/Switch'
                                        */
  real_T Send_P1_Size_g[2];            /* Computed Parameter: Send_P1_Size_g
                                        * Referenced by: '<S259>/Send'
                                        */
  real_T Send_P1_p[26];                /* Computed Parameter: Send_P1_p
                                        * Referenced by: '<S259>/Send'
                                        */
  real_T Send_P2_Size_i[2];            /* Computed Parameter: Send_P2_Size_i
                                        * Referenced by: '<S259>/Send'
                                        */
  real_T Send_P2_bu;                   /* Expression: localPort
                                        * Referenced by: '<S259>/Send'
                                        */
  real_T Send_P3_Size_ak[2];           /* Computed Parameter: Send_P3_Size_ak
                                        * Referenced by: '<S259>/Send'
                                        */
  real_T Send_P3_e[12];                /* Computed Parameter: Send_P3_e
                                        * Referenced by: '<S259>/Send'
                                        */
  real_T Send_P4_Size_m[2];            /* Computed Parameter: Send_P4_Size_m
                                        * Referenced by: '<S259>/Send'
                                        */
  real_T Send_P4_m;                    /* Expression: toPort
                                        * Referenced by: '<S259>/Send'
                                        */
  real_T Send_P5_Size_f[2];            /* Computed Parameter: Send_P5_Size_f
                                        * Referenced by: '<S259>/Send'
                                        */
  real_T Send_P5_o;                    /* Expression: useHostTargetComm
                                        * Referenced by: '<S259>/Send'
                                        */
  real_T Send_P6_Size_b[2];            /* Computed Parameter: Send_P6_Size_b
                                        * Referenced by: '<S259>/Send'
                                        */
  real_T Send_P6_m;                    /* Expression: sampleTime
                                        * Referenced by: '<S259>/Send'
                                        */
  real_T ReceivefromRobot1ForceSensor_P1_Size[2];
                     /* Computed Parameter: ReceivefromRobot1ForceSensor_P1_Size
                      * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                      */
  real_T ReceivefromRobot1ForceSensor_P1[26];
                          /* Computed Parameter: ReceivefromRobot1ForceSensor_P1
                           * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                           */
  real_T ReceivefromRobot1ForceSensor_P2_Size[2];
                     /* Computed Parameter: ReceivefromRobot1ForceSensor_P2_Size
                      * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                      */
  real_T ReceivefromRobot1ForceSensor_P2;/* Expression: localPort
                                          * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                                          */
  real_T ReceivefromRobot1ForceSensor_P3_Size[2];
                     /* Computed Parameter: ReceivefromRobot1ForceSensor_P3_Size
                      * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                      */
  real_T ReceivefromRobot1ForceSensor_P3;/* Expression: outWidth
                                          * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                                          */
  real_T ReceivefromRobot1ForceSensor_P4_Size[2];
                     /* Computed Parameter: ReceivefromRobot1ForceSensor_P4_Size
                      * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                      */
  real_T ReceivefromRobot1ForceSensor_P4;/* Expression: useHostTargetComm
                                          * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                                          */
  real_T ReceivefromRobot1ForceSensor_P5_Size[2];
                     /* Computed Parameter: ReceivefromRobot1ForceSensor_P5_Size
                      * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                      */
  real_T ReceivefromRobot1ForceSensor_P5[12];
                          /* Computed Parameter: ReceivefromRobot1ForceSensor_P5
                           * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                           */
  real_T ReceivefromRobot1ForceSensor_P6_Size[2];
                     /* Computed Parameter: ReceivefromRobot1ForceSensor_P6_Size
                      * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                      */
  real_T ReceivefromRobot1ForceSensor_P6;/* Expression: maxUDPQueue
                                          * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                                          */
  real_T ReceivefromRobot1ForceSensor_P7_Size[2];
                     /* Computed Parameter: ReceivefromRobot1ForceSensor_P7_Size
                      * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                      */
  real_T ReceivefromRobot1ForceSensor_P7;/* Expression: rcvMulticast
                                          * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                                          */
  real_T ReceivefromRobot1ForceSensor_P8_Size[2];
                     /* Computed Parameter: ReceivefromRobot1ForceSensor_P8_Size
                      * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                      */
  real_T ReceivefromRobot1ForceSensor_P9_Size[2];
                     /* Computed Parameter: ReceivefromRobot1ForceSensor_P9_Size
                      * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                      */
  real_T ReceivefromRobot1ForceSensor_P9;/* Expression: sampleTime
                                          * Referenced by: '<S252>/Receive from Robot 1 Force Sensor'
                                          */
  real_T Switch_Threshold_f;           /* Expression: 0
                                        * Referenced by: '<S252>/Switch'
                                        */
  real_T ReceivefromRobot2ForceSensor_P1_Size[2];
                     /* Computed Parameter: ReceivefromRobot2ForceSensor_P1_Size
                      * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                      */
  real_T ReceivefromRobot2ForceSensor_P1[26];
                          /* Computed Parameter: ReceivefromRobot2ForceSensor_P1
                           * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                           */
  real_T ReceivefromRobot2ForceSensor_P2_Size[2];
                     /* Computed Parameter: ReceivefromRobot2ForceSensor_P2_Size
                      * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                      */
  real_T ReceivefromRobot2ForceSensor_P2;/* Expression: localPort
                                          * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                                          */
  real_T ReceivefromRobot2ForceSensor_P3_Size[2];
                     /* Computed Parameter: ReceivefromRobot2ForceSensor_P3_Size
                      * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                      */
  real_T ReceivefromRobot2ForceSensor_P3;/* Expression: outWidth
                                          * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                                          */
  real_T ReceivefromRobot2ForceSensor_P4_Size[2];
                     /* Computed Parameter: ReceivefromRobot2ForceSensor_P4_Size
                      * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                      */
  real_T ReceivefromRobot2ForceSensor_P4;/* Expression: useHostTargetComm
                                          * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                                          */
  real_T ReceivefromRobot2ForceSensor_P5_Size[2];
                     /* Computed Parameter: ReceivefromRobot2ForceSensor_P5_Size
                      * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                      */
  real_T ReceivefromRobot2ForceSensor_P5[12];
                          /* Computed Parameter: ReceivefromRobot2ForceSensor_P5
                           * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                           */
  real_T ReceivefromRobot2ForceSensor_P6_Size[2];
                     /* Computed Parameter: ReceivefromRobot2ForceSensor_P6_Size
                      * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                      */
  real_T ReceivefromRobot2ForceSensor_P6;/* Expression: maxUDPQueue
                                          * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                                          */
  real_T ReceivefromRobot2ForceSensor_P7_Size[2];
                     /* Computed Parameter: ReceivefromRobot2ForceSensor_P7_Size
                      * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                      */
  real_T ReceivefromRobot2ForceSensor_P7;/* Expression: rcvMulticast
                                          * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                                          */
  real_T ReceivefromRobot2ForceSensor_P8_Size[2];
                     /* Computed Parameter: ReceivefromRobot2ForceSensor_P8_Size
                      * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                      */
  real_T ReceivefromRobot2ForceSensor_P9_Size[2];
                     /* Computed Parameter: ReceivefromRobot2ForceSensor_P9_Size
                      * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                      */
  real_T ReceivefromRobot2ForceSensor_P9;/* Expression: sampleTime
                                          * Referenced by: '<S253>/Receive from Robot 2 Force Sensor'
                                          */
  real_T Switch1_Threshold;            /* Expression: 0
                                        * Referenced by: '<S253>/Switch1'
                                        */
  real_T DPRAMWatchDogoffset_Value;    /* Expression: 627
                                        * Referenced by: '<S264>/DPRAM WatchDog offset'
                                        */
  real_T DPRAMReadOffset_Value;        /* Expression: 534
                                        * Referenced by: '<S264>/DPRAM Read Offset'
                                        */
  real_T UnitDelay_InitialCondition_c; /* Expression: 0
                                        * Referenced by: '<S264>/Unit Delay'
                                        */
  real_T UnitDelay2_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S264>/Unit Delay2'
                                        */
  real_T ReadasUInt32_Value;           /* Expression: 0
                                        * Referenced by: '<S264>/Read as UInt32'
                                        */
  real_T DPRAMReadValue_Gain;          /* Expression: 1
                                        * Referenced by: '<S264>/DPRAM Read Value'
                                        */
  real_T ReadSwitch_Value;             /* Expression: 0
                                        * Referenced by: '<S264>/Read Switch'
                                        */
  real_T UnitDelay1_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S264>/Unit Delay1'
                                        */
  real_T UnitDelay3_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S264>/Unit Delay3'
                                        */
  real_T DPRAMWriteOffset_Value;       /* Expression: 534
                                        * Referenced by: '<S264>/DPRAM Write Offset'
                                        */
  real_T DPRAMWriteValue_Value;        /* Expression: 1
                                        * Referenced by: '<S264>/DPRAM Write Value'
                                        */
  real_T WriteSwitch_Value;            /* Expression: 0
                                        * Referenced by: '<S264>/Write Switch'
                                        */
  real_T robot_count_Value;            /* Expression: 1.0
                                        * Referenced by: '<S262>/robot_count'
                                        */
  real_T Taskcontrolbutton_Y0;         /* Expression: 0
                                        * Referenced by: '<S276>/Task control button'
                                        */
  real_T SFunction_P1_Size[2];         /* Computed Parameter: SFunction_P1_Size
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T SFunction_P1[14];             /* Computed Parameter: SFunction_P1
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T SFunction_P2_Size[2];         /* Computed Parameter: SFunction_P2_Size
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T SFunction_P2;                 /* Expression: dataSize
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T SFunction_P3_Size[2];         /* Computed Parameter: SFunction_P3_Size
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T SFunction_P3;                 /* Expression: bufSize
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T SFunction_P4_Size[2];         /* Computed Parameter: SFunction_P4_Size
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T SFunction_P4;                 /* Expression: readSize
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T SFunction_P5_Size[2];         /* Computed Parameter: SFunction_P5_Size
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T SFunction_P5;                 /* Expression: EOFOption
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T SFunction_P6_Size[2];         /* Computed Parameter: SFunction_P6_Size
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T SFunction_P6;                 /* Expression: sampTime
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T SFunction_P7_Size[2];         /* Computed Parameter: SFunction_P7_Size
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T SFunction_P7;                 /* Expression: show2ports
                                        * Referenced by: '<S276>/S-Function'
                                        */
  real_T Receive_P1_Size_d[2];         /* Computed Parameter: Receive_P1_Size_d
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P1_m[26];             /* Computed Parameter: Receive_P1_m
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P2_Size_c[2];         /* Computed Parameter: Receive_P2_Size_c
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P2_j;                 /* Expression: localPort
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P3_Size_o[2];         /* Computed Parameter: Receive_P3_Size_o
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P3_b;                 /* Expression: outWidth
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P4_Size_n[2];         /* Computed Parameter: Receive_P4_Size_n
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P4_e;                 /* Expression: useHostTargetComm
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P5_Size_p[2];         /* Computed Parameter: Receive_P5_Size_p
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P5_d[11];             /* Computed Parameter: Receive_P5_d
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P6_Size_m[2];         /* Computed Parameter: Receive_P6_Size_m
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P6_kp;                /* Expression: maxUDPQueue
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P7_Size_k[2];         /* Computed Parameter: Receive_P7_Size_k
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P7_k;                 /* Expression: rcvMulticast
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P8_Size_o[2];         /* Computed Parameter: Receive_P8_Size_o
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P9_Size_c[2];         /* Computed Parameter: Receive_P9_Size_c
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Receive_P9_h;                 /* Expression: sampleTime
                                        * Referenced by: '<S283>/Receive'
                                        */
  real_T Ready_Value;                  /* Expression: 1
                                        * Referenced by: '<S292>/Ready'
                                        */
  real_T ArmForceSensors_Value[3];     /* Expression: [0 0, 0]
                                        * Referenced by: '<S292>/Arm Force Sensors'
                                        */
  real_T Constant_Value_m[4];          /* Expression: zeros(4, 1)
                                        * Referenced by: '<S284>/Constant'
                                        */
  real_T Constant1_Value_f[10];        /* Expression: ones(1,10)
                                        * Referenced by: '<S284>/Constant1'
                                        */
  real_T undorderbutterworth4Khz10hzcutoff_Value[3];
                   /* Expression: [1.639178228e+04, -0.9780305085, 1.9777864838]
                    * Referenced by: '<S243>/2nd order butterworth, 4Khz, 10hz cutoff'
                    */
  real_T Constant_Value_mh[10];        /* Expression: ones(1,10)
                                        * Referenced by: '<S263>/Constant'
                                        */
  real_T Constant1_Value_h[10];        /* Expression: zeros(1,10)
                                        * Referenced by: '<S277>/Constant1'
                                        */
  real_T Constant2_Value[10];          /* Expression: ones(1,10)
                                        * Referenced by: '<S277>/Constant2'
                                        */
  real_T Constant_Value_mg[4];         /* Expression: zeros(4, 1)
                                        * Referenced by: '<S277>/Constant'
                                        */
  real_T is_calibrated_Value[2];       /* Expression: [0, 0]
                                        * Referenced by: '<S73>/is_calibrated'
                                        */
  real_T HandFeedbackStatus_Value;     /* Expression: 3
                                        * Referenced by: '<S299>/Hand Feedback Status'
                                        */
  real_T HandFeedbackSource_Value;     /* Expression: 0
                                        * Referenced by: '<S299>/Hand Feedback Source'
                                        */
  real_T HandFeedbackRadius_Value;     /* Expression: 0.005
                                        * Referenced by: '<S299>/Hand Feedback Radius'
                                        */
  real_T HandFeedbackColour_Value;     /* Expression: 16777215
                                        * Referenced by: '<S299>/Hand Feedback Colour'
                                        */
  real_T HandFeedbackFeedForward_Value;/* Expression: .05
                                        * Referenced by: '<S299>/Hand Feedback Feed Forward'
                                        */
  real_T GazeFeedbackStatus_Value;     /* Expression: 0
                                        * Referenced by: '<S299>/Gaze Feedback Status'
                                        */
  real_T DominantArm_Value;            /* Expression: 1
                                        * Referenced by: '<S73>/Dominant Arm'
                                        */
  real_T exopartnums_Value[6];         /* Expression: [13595, 13387, 0, 0, 0, 0]
                                        * Referenced by: '<S66>/exo part nums'
                                        */
  real_T eppartnums_Value[6];  /* Expression: [10212, 10213 ,14371 , 14372 ,0,0]
                                * Referenced by: '<S66>/ep part nums'
                                */
  real_T nhppartnums_Value[6];         /* Expression: [14609 , 14610  ,0,0,0,0]
                                        * Referenced by: '<S66>/nhp part nums'
                                        */
  real_T forceprimaryonly_Value;       /* Expression: 0
                                        * Referenced by: '<S66>/force primary only'
                                        */
  real_T maxerrorstofault_Value;       /* Expression: 40
                                        * Referenced by: '<S66>/max errors to fault'
                                        */
  real_T systemtype_Value;             /* Expression: 1
                                        * Referenced by: '<S30>/system type'
                                        */
  real_T BKINEtherCATPDOTransmit_P1_Size_g[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P1_Size_g
                         * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P1_k[46];
                             /* Computed Parameter: BKINEtherCATPDOTransmit_P1_k
                              * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                              */
  real_T BKINEtherCATPDOTransmit_P2_Size_j[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P2_Size_j
                         * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P2_j; /* Expression: sig_offset
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P3_Size_c[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P3_Size_c
                         * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P3_n; /* Expression: sig_type
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P4_Size_o[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P4_Size_o
                         * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P4_ms;/* Expression: type_size
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P5_Size_a[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P5_Size_a
                         * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P5_nz;/* Expression: sig_dim
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P6_Size_j[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P6_Size_j
                         * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P6_m; /* Expression: device_id
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit_P7_Size_h[2];
                        /* Computed Parameter: BKINEtherCATPDOTransmit_P7_Size_h
                         * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                         */
  real_T BKINEtherCATPDOTransmit_P7_g; /* Expression: sample_time
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit '
                                        */
  real_T BKINEtherCATPDOTransmit1_P1_Size_e[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P1_Size_e
                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P1_p[46];
                            /* Computed Parameter: BKINEtherCATPDOTransmit1_P1_p
                             * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                             */
  real_T BKINEtherCATPDOTransmit1_P2_Size_e[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P2_Size_e
                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P2_f;/* Expression: sig_offset
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P3_Size_m[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P3_Size_m
                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P3_l;/* Expression: sig_type
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P4_Size_l[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P4_Size_l
                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P4_e;/* Expression: type_size
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P5_Size_d[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P5_Size_d
                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P5_k;/* Expression: sig_dim
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P6_Size_n[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P6_Size_n
                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P6_f;/* Expression: device_id
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P7_Size_p[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P7_Size_p
                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P7_n;/* Expression: sample_time
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit2_P1_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit2_P1_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                          */
  real_T BKINEtherCATPDOTransmit2_P1[46];
                              /* Computed Parameter: BKINEtherCATPDOTransmit2_P1
                               * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                               */
  real_T BKINEtherCATPDOTransmit2_P2_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit2_P2_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                          */
  real_T BKINEtherCATPDOTransmit2_P2;  /* Expression: sig_offset
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P3_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit2_P3_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                          */
  real_T BKINEtherCATPDOTransmit2_P3;  /* Expression: sig_type
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P4_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit2_P4_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                          */
  real_T BKINEtherCATPDOTransmit2_P4;  /* Expression: type_size
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P5_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit2_P5_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                          */
  real_T BKINEtherCATPDOTransmit2_P5;  /* Expression: sig_dim
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P6_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit2_P6_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                          */
  real_T BKINEtherCATPDOTransmit2_P6;  /* Expression: device_id
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P7_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit2_P7_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                          */
  real_T BKINEtherCATPDOTransmit2_P7;  /* Expression: sample_time
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit3_P1_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit3_P1_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                          */
  real_T BKINEtherCATPDOTransmit3_P1[46];
                              /* Computed Parameter: BKINEtherCATPDOTransmit3_P1
                               * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                               */
  real_T BKINEtherCATPDOTransmit3_P2_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit3_P2_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                          */
  real_T BKINEtherCATPDOTransmit3_P2;  /* Expression: sig_offset
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                                        */
  real_T BKINEtherCATPDOTransmit3_P3_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit3_P3_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                          */
  real_T BKINEtherCATPDOTransmit3_P3;  /* Expression: sig_type
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                                        */
  real_T BKINEtherCATPDOTransmit3_P4_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit3_P4_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                          */
  real_T BKINEtherCATPDOTransmit3_P4;  /* Expression: type_size
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                                        */
  real_T BKINEtherCATPDOTransmit3_P5_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit3_P5_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                          */
  real_T BKINEtherCATPDOTransmit3_P5;  /* Expression: sig_dim
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                                        */
  real_T BKINEtherCATPDOTransmit3_P6_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit3_P6_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                          */
  real_T BKINEtherCATPDOTransmit3_P6;  /* Expression: device_id
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                                        */
  real_T BKINEtherCATPDOTransmit3_P7_Size[2];
                         /* Computed Parameter: BKINEtherCATPDOTransmit3_P7_Size
                          * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                          */
  real_T BKINEtherCATPDOTransmit3_P7;  /* Expression: sample_time
                                        * Referenced by: '<S81>/BKIN EtherCAT PDO Transmit 3'
                                        */
  real_T ArmOrientation_Value;         /* Expression: 1.0
                                        * Referenced by: '<S290>/Arm Orientation'
                                        */
  real_T ArmMotor1Orientation_Value;   /* Expression: -1.0
                                        * Referenced by: '<S290>/Arm Motor1 Orientation'
                                        */
  real_T ArmMotor2Orientation_Value;   /* Expression: -1.0
                                        * Referenced by: '<S290>/Arm Motor2 Orientation'
                                        */
  real_T ArmMotor1GearRatio_Value;     /* Expression: 4.0
                                        * Referenced by: '<S290>/Arm Motor1 Gear Ratio'
                                        */
  real_T ArmMotor2GearRatio_Value;     /* Expression: 4.0
                                        * Referenced by: '<S290>/Arm Motor2 Gear Ratio'
                                        */
  real_T ArmSecondaryEncoders_Value;   /* Expression: 0.0
                                        * Referenced by: '<S290>/Arm Secondary Encoders'
                                        */
  real_T ArmEncoderOrientation1_Value; /* Expression: 1
                                        * Referenced by: '<S290>/Arm Encoder Orientation 1'
                                        */
  real_T ArmEncoderOrientation2_Value; /* Expression: 1
                                        * Referenced by: '<S290>/Arm Encoder Orientation 2'
                                        */
  real_T Armprimaryencodercounts_Value;/* Expression: 20000
                                        * Referenced by: '<S290>/Arm primary encoder counts'
                                        */
  real_T Armsecondaryencodercounts_Value;/* Expression: 655360
                                          * Referenced by: '<S290>/Arm secondary encoder counts'
                                          */
  real_T ArmOrientation_Value_g;       /* Expression: 1.0
                                        * Referenced by: '<S291>/Arm Orientation'
                                        */
  real_T ArmMotor1Orientation_Value_j; /* Expression: -1.0
                                        * Referenced by: '<S291>/Arm Motor1 Orientation'
                                        */
  real_T ArmMotor2Orientation_Value_o; /* Expression: -1.0
                                        * Referenced by: '<S291>/Arm Motor2 Orientation'
                                        */
  real_T ArmMotor1GearRatio_Value_b;   /* Expression: 4.0
                                        * Referenced by: '<S291>/Arm Motor1 Gear Ratio'
                                        */
  real_T ArmMotor2GearRatio_Value_a;   /* Expression: 4.0
                                        * Referenced by: '<S291>/Arm Motor2 Gear Ratio'
                                        */
  real_T ArmSecondaryEncoders_Value_f; /* Expression: 0.0
                                        * Referenced by: '<S291>/Arm Secondary Encoders'
                                        */
  real_T ArmEncoderOrientation1_Value_b;/* Expression: 1
                                         * Referenced by: '<S291>/Arm Encoder Orientation 1'
                                         */
  real_T ArmEncoderOrientation2_Value_m;/* Expression: 1
                                         * Referenced by: '<S291>/Arm Encoder Orientation 2'
                                         */
  real_T Armprimaryencodercounts_Value_n;/* Expression: 20000
                                          * Referenced by: '<S291>/Arm primary encoder counts'
                                          */
  real_T Armsecondaryencodercounts_Value_p;/* Expression: 655360
                                            * Referenced by: '<S291>/Arm secondary encoder counts'
                                            */
  real_T TmpRTBAtDatawriteInport2_InitialCondition;/* Expression: 0
                                                    * Referenced by: synthesized block
                                                    */
  real_T TmpRTBAtDatawriteInport3_InitialCondition;/* Expression: 0
                                                    * Referenced by: synthesized block
                                                    */
  real_T Subject_Arm_Value;            /* Expression: 1
                                        * Referenced by: '<S75>/Subject_Arm'
                                        */
  real_T ArmShoulderAngleOffset_Value; /* Expression: 0.0
                                        * Referenced by: '<S290>/Arm Shoulder Angle Offset'
                                        */
  real_T ArmElbowAngleOffset_Value;    /* Expression: 0.0
                                        * Referenced by: '<S290>/Arm Elbow Angle Offset'
                                        */
  real_T ArmShoulderX_Value;           /* Expression: 0.0
                                        * Referenced by: '<S290>/Arm Shoulder X'
                                        */
  real_T ArmShoulderY_Value;           /* Expression: 0.0
                                        * Referenced by: '<S290>/Arm Shoulder Y'
                                        */
  real_T ArmL1_Value;                  /* Expression: 0.0
                                        * Referenced by: '<S290>/Arm L1'
                                        */
  real_T ArmL2_Value;                  /* Expression: 0.0
                                        * Referenced by: '<S290>/Arm L2'
                                        */
  real_T ArmPointerOffset_Value;       /* Expression: 0.0
                                        * Referenced by: '<S290>/Arm Pointer Offset'
                                        */
  real_T ArmL3Error_Value;             /* Expression: 0.0
                                        * Referenced by: '<S290>/Arm L3 Error'
                                        */
  real_T Armrobottype_Value;           /* Expression: 0.0
                                        * Referenced by: '<S290>/Arm robot type'
                                        */
  real_T ArmTorqueConstant_Value;      /* Expression: 3.3
                                        * Referenced by: '<S290>/Arm Torque Constant'
                                        */
  real_T ArmL5_Value;                  /* Expression: 0.0
                                        * Referenced by: '<S290>/Arm L5'
                                        */
  real_T ArmL2L5Angle_Value;           /* Expression: 0.0
                                        * Referenced by: '<S290>/Arm L2 L5 Angle'
                                        */
  real_T ArmForceSensorAngleOffset_Value;/* Expression: 0.0
                                          * Referenced by: '<S290>/Arm Force Sensor Angle Offset'
                                          */
  real_T Armrobotversion_Value;        /* Expression: 1
                                        * Referenced by: '<S290>/Arm robot version'
                                        */
  real_T ArmShoulderAngleOffset_Value_i;/* Expression: 0.0
                                         * Referenced by: '<S291>/Arm Shoulder Angle Offset'
                                         */
  real_T ArmElbowAngleOffset_Value_g;  /* Expression: 0.0
                                        * Referenced by: '<S291>/Arm Elbow Angle Offset'
                                        */
  real_T ArmShoulderX_Value_l;         /* Expression: 0.0
                                        * Referenced by: '<S291>/Arm Shoulder X'
                                        */
  real_T ArmShoulderY_Value_e;         /* Expression: 0.0
                                        * Referenced by: '<S291>/Arm Shoulder Y'
                                        */
  real_T ArmL1_Value_f;                /* Expression: 0.0
                                        * Referenced by: '<S291>/Arm L1'
                                        */
  real_T ArmL2_Value_g;                /* Expression: 0.0
                                        * Referenced by: '<S291>/Arm L2'
                                        */
  real_T ArmPointerOffset_Value_g;     /* Expression: 0.0
                                        * Referenced by: '<S291>/Arm Pointer Offset'
                                        */
  real_T ArmL3Error_Value_g;           /* Expression: 0.0
                                        * Referenced by: '<S291>/Arm L3 Error'
                                        */
  real_T Armrobottype_Value_k;         /* Expression: 0.0
                                        * Referenced by: '<S291>/Arm robot type'
                                        */
  real_T ArmTorqueConstant_Value_g;    /* Expression: 3.3
                                        * Referenced by: '<S291>/Arm Torque Constant'
                                        */
  real_T ArmL5_Value_j;                /* Expression: 0.0
                                        * Referenced by: '<S291>/Arm L5'
                                        */
  real_T ArmL2L5Angle_Value_h;         /* Expression: 0.0
                                        * Referenced by: '<S291>/Arm L2 L5 Angle'
                                        */
  real_T ArmForceSensorAngleOffset_Value_l;/* Expression: 0.0
                                            * Referenced by: '<S291>/Arm Force Sensor Angle Offset'
                                            */
  real_T Armrobotversion_Value_e;      /* Expression: 1
                                        * Referenced by: '<S291>/Arm robot version'
                                        */
  real_T updateconstants_Value;        /* Expression: 1
                                        * Referenced by: '<S71>/update constants'
                                        */
  real_T ECATErrMsgs_InitialValue[20]; /* Expression: zeros(4, 5)
                                        * Referenced by: '<S30>/ECAT Err Msgs'
                                        */
  real_T ECATTorquefeedback_InitialValue[10];
                                   /* Expression: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
                                    * Referenced by: '<S30>/ECATTorque feedback'
                                    */
  real_T HWSettings_InitialValue[25];  /* Expression: zeros(25, 1)
                                        * Referenced by: '<S30>/HW Settings'
                                        */
  real_T Kinematics_InitialValue[20];  /* Expression: zeros(20, 1)
                                        * Referenced by: '<S30>/Kinematics'
                                        */
  real_T PrimaryEnc_InitialValue[12];  /* Expression: zeros(12, 1)
                                        * Referenced by: '<S30>/PrimaryEnc'
                                        */
  real_T RobotCalib_InitialValue[16];  /* Expression: zeros(16, 1)
                                        * Referenced by: '<S30>/Robot Calib'
                                        */
  real_T RobotRevision_InitialValue[2];/* Expression: [1, 1]
                                        * Referenced by: '<S30>/RobotRevision'
                                        */
  real_T delays_InitialValue[4];       /* Expression: zeros(4, 1)
                                        * Referenced by: '<S30>/delays'
                                        */
  real_T hasFTsensors_InitialValue[3]; /* Expression: [0, 0, 0]
                                        * Referenced by: '<S30>/has FT sensors'
                                        */
  real_T ELTrackingAvailable_Value;    /* Expression: 1
                                        * Referenced by: '<S31>/EL Tracking Available'
                                        */
  real_T ELCameraAngle_Value[2];       /* Expression: [47, -10]
                                        * Referenced by: '<S31>/EL Camera Angle'
                                        */
  real_T ELCameraPosition_Value[3];    /* Expression: [0.10, 0.35, -0.15]
                                        * Referenced by: '<S31>/EL Camera Position'
                                        */
  real_T ELCameraFocalLength_Value;    /* Expression: 0.017
                                        * Referenced by: '<S31>/EL Camera Focal Length'
                                        */
  real_T Gain_Gain;                    /* Expression: -1
                                        * Referenced by: '<S31>/Gain'
                                        */
  real_T RateTransition_InitialCondition;/* Expression: 0
                                          * Referenced by: '<S31>/Rate Transition'
                                          */
  real_T Receive_P1_Size_e[2];         /* Computed Parameter: Receive_P1_Size_e
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P1_g[26];             /* Computed Parameter: Receive_P1_g
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P2_Size_j[2];         /* Computed Parameter: Receive_P2_Size_j
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P2_e;                 /* Expression: localPort
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P3_Size_l[2];         /* Computed Parameter: Receive_P3_Size_l
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P3_c;                 /* Expression: outWidth
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P4_Size_b[2];         /* Computed Parameter: Receive_P4_Size_b
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P4_m;                 /* Expression: useHostTargetComm
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P5_Size_j[2];         /* Computed Parameter: Receive_P5_Size_j
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P5_o[7];              /* Computed Parameter: Receive_P5_o
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P6_Size_a[2];         /* Computed Parameter: Receive_P6_Size_a
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P6_m;                 /* Expression: maxUDPQueue
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P7_Size_i[2];         /* Computed Parameter: Receive_P7_Size_i
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P7_l;                 /* Expression: rcvMulticast
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P8_Size_a[2];         /* Computed Parameter: Receive_P8_Size_a
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P9_Size_i[2];         /* Computed Parameter: Receive_P9_Size_i
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T Receive_P9_c;                 /* Expression: sampleTime
                                        * Referenced by: '<S31>/Receive'
                                        */
  real_T BKINEtherCATPDOTransmit1_P1_Size_b[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P1_Size_b
                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P1_a[42];
                            /* Computed Parameter: BKINEtherCATPDOTransmit1_P1_a
                             * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                             */
  real_T BKINEtherCATPDOTransmit1_P2_Size_et[2];
                      /* Computed Parameter: BKINEtherCATPDOTransmit1_P2_Size_et
                       * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                       */
  real_T BKINEtherCATPDOTransmit1_P2_i;/* Expression: sig_offset
                                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P3_Size_l[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P3_Size_l
                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P3_h;/* Expression: sig_type
                                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P4_Size_h[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P4_Size_h
                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P4_g;/* Expression: type_size
                                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P5_Size_g0[2];
                      /* Computed Parameter: BKINEtherCATPDOTransmit1_P5_Size_g0
                       * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                       */
  real_T BKINEtherCATPDOTransmit1_P5_f;/* Expression: sig_dim
                                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P6_Size_e[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P6_Size_e
                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P6_m;/* Expression: device_id
                                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P7_Size_o[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P7_Size_o
                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P7_a;/* Expression: sample_time
                                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit2_P1_Size_g[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P1_Size_g
                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P1_n[42];
                            /* Computed Parameter: BKINEtherCATPDOTransmit2_P1_n
                             * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                             */
  real_T BKINEtherCATPDOTransmit2_P2_Size_l[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P2_Size_l
                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P2_b;/* Expression: sig_offset
                                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P3_Size_f[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P3_Size_f
                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P3_g;/* Expression: sig_type
                                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P4_Size_k[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P4_Size_k
                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P4_o;/* Expression: type_size
                                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P5_Size_h[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P5_Size_h
                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P5_g;/* Expression: sig_dim
                                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P6_Size_a[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P6_Size_a
                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P6_p;/* Expression: device_id
                                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P7_Size_l[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P7_Size_l
                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P7_g;/* Expression: sample_time
                                        * Referenced by: '<S317>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit1_P1_Size_a[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P1_Size_a
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P1_i[42];
                            /* Computed Parameter: BKINEtherCATPDOTransmit1_P1_i
                             * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                             */
  real_T BKINEtherCATPDOTransmit1_P2_Size_o[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P2_Size_o
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P2_h;/* Expression: sig_offset
                                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P3_Size_d[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P3_Size_d
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P3_j;/* Expression: sig_type
                                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P4_Size_o[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P4_Size_o
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P4_i;/* Expression: type_size
                                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P5_Size_a[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P5_Size_a
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P5_k2;/* Expression: sig_dim
                                         * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                                         */
  real_T BKINEtherCATPDOTransmit1_P6_Size_k[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P6_Size_k
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P6_n;/* Expression: device_id
                                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit1_P7_Size_l[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit1_P7_Size_l
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                        */
  real_T BKINEtherCATPDOTransmit1_P7_h;/* Expression: sample_time
                                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 1'
                                        */
  real_T BKINEtherCATPDOTransmit2_P1_Size_e[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P1_Size_e
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P1_i[42];
                            /* Computed Parameter: BKINEtherCATPDOTransmit2_P1_i
                             * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                             */
  real_T BKINEtherCATPDOTransmit2_P2_Size_a[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P2_Size_a
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P2_f;/* Expression: sig_offset
                                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P3_Size_d[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P3_Size_d
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P3_o;/* Expression: sig_type
                                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P4_Size_j[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P4_Size_j
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P4_m;/* Expression: type_size
                                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P5_Size_o[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P5_Size_o
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P5_j;/* Expression: sig_dim
                                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P6_Size_n[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P6_Size_n
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P6_b;/* Expression: device_id
                                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T BKINEtherCATPDOTransmit2_P7_Size_e[2];
                       /* Computed Parameter: BKINEtherCATPDOTransmit2_P7_Size_e
                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                        */
  real_T BKINEtherCATPDOTransmit2_P7_j;/* Expression: sample_time
                                        * Referenced by: '<S318>/BKIN EtherCAT PDO Transmit 2'
                                        */
  real_T block_defs_Y0[25000];         /* Expression: zeros(50, 500)
                                        * Referenced by: '<S351>/block_defs'
                                        */
  real_T block_seq_Y0[3000];           /* Expression: zeros(1000, 3)
                                        * Referenced by: '<S351>/block_seq'
                                        */
  real_T tp_table_Y0[5000];            /* Expression: zeros(tp_table_rows, 50)
                                        * Referenced by: '<S351>/tp_table'
                                        */
  real_T labels_Y0[3200];            /* Expression: zeros(target_table_rows, 50)
                                      * Referenced by: '<S351>/labels'
                                      */
  real_T targets_Y0[1600];           /* Expression: zeros(target_table_rows, 25)
                                      * Referenced by: '<S351>/targets'
                                      */
  real_T loads_Y0[400];                /* Expression: zeros(load_table_rows, 20)
                                        * Referenced by: '<S351>/loads'
                                        */
  real_T twp_Y0[50];                   /* Expression: zeros(50, 1)
                                        * Referenced by: '<S351>/twp'
                                        */
  real_T BlockDefinitions_Value[25000];/* Expression: zeros(50, 500);
                                        * Referenced by: '<S351>/Block Definitions'
                                        */
  real_T BlockSequence_Value[3000];    /* Expression: zeros(1000, 3);
                                        * Referenced by: '<S351>/Block Sequence'
                                        */
  real_T TPTable_Value[5000];          /* Expression: zeros(tp_table_rows, 50);
                                        * Referenced by: '<S351>/TP Table'
                                        */
  real_T TargetLabels_Value[3200];  /* Expression: zeros(target_table_rows, 50);
                                     * Referenced by: '<S351>/Target Labels'
                                     */
  real_T TargetTable_Value[1600];   /* Expression: zeros(target_table_rows, 25);
                                     * Referenced by: '<S351>/Target Table'
                                     */
  real_T LoadTable_Value[400];        /* Expression: zeros(load_table_rows, 20);
                                       * Referenced by: '<S351>/Load Table'
                                       */
  real_T Taskwideparam_Value[50];      /* Expression: zeros(50, 1);
                                        * Referenced by: '<S351>/Task wide param'
                                        */
  real_T TorqueLimit2_Value;           /* Expression: -1
                                        * Referenced by: '<S5>/Torque Limit2'
                                        */
  real_T TorqueLimit5_Value;           /* Expression: -1
                                        * Referenced by: '<S369>/Torque Limit5'
                                        */
  real_T Switch1_Threshold_h;          /* Expression: 1
                                        * Referenced by: '<S372>/Switch1'
                                        */
  real_T Switch_Threshold_g;           /* Expression: 1
                                        * Referenced by: '<S372>/Switch'
                                        */
  real_T Switch1_Threshold_b;          /* Expression: 1
                                        * Referenced by: '<S374>/Switch1'
                                        */
  real_T Switch_Threshold_h;           /* Expression: 1
                                        * Referenced by: '<S374>/Switch'
                                        */
  real_T RateTransition1_InitialCondition;/* Expression: 0
                                           * Referenced by: '<S383>/Rate Transition1'
                                           */
  real_T Constant_Value_b;             /* Expression: 0
                                        * Referenced by: '<S395>/Constant'
                                        */
  real_T Delay1_InitialCondition;      /* Expression: 0
                                        * Referenced by: '<S336>/Delay1'
                                        */
  real_T UseRepeatTrialFlag_Value;     /* Expression: 0
                                        * Referenced by: '<S3>/Use Repeat Trial Flag'
                                        */
  real_T RunCommandReceive_P1_Size[2];
                                /* Computed Parameter: RunCommandReceive_P1_Size
                                 * Referenced by: '<S335>/Run Command Receive'
                                 */
  real_T RunCommandReceive_P1[26];   /* Computed Parameter: RunCommandReceive_P1
                                      * Referenced by: '<S335>/Run Command Receive'
                                      */
  real_T RunCommandReceive_P2_Size[2];
                                /* Computed Parameter: RunCommandReceive_P2_Size
                                 * Referenced by: '<S335>/Run Command Receive'
                                 */
  real_T RunCommandReceive_P2;         /* Expression: localPort
                                        * Referenced by: '<S335>/Run Command Receive'
                                        */
  real_T RunCommandReceive_P3_Size[2];
                                /* Computed Parameter: RunCommandReceive_P3_Size
                                 * Referenced by: '<S335>/Run Command Receive'
                                 */
  real_T RunCommandReceive_P3;         /* Expression: outWidth
                                        * Referenced by: '<S335>/Run Command Receive'
                                        */
  real_T RunCommandReceive_P4_Size[2];
                                /* Computed Parameter: RunCommandReceive_P4_Size
                                 * Referenced by: '<S335>/Run Command Receive'
                                 */
  real_T RunCommandReceive_P4;         /* Expression: useHostTargetComm
                                        * Referenced by: '<S335>/Run Command Receive'
                                        */
  real_T RunCommandReceive_P5_Size[2];
                                /* Computed Parameter: RunCommandReceive_P5_Size
                                 * Referenced by: '<S335>/Run Command Receive'
                                 */
  real_T RunCommandReceive_P5[7];    /* Computed Parameter: RunCommandReceive_P5
                                      * Referenced by: '<S335>/Run Command Receive'
                                      */
  real_T RunCommandReceive_P6_Size[2];
                                /* Computed Parameter: RunCommandReceive_P6_Size
                                 * Referenced by: '<S335>/Run Command Receive'
                                 */
  real_T RunCommandReceive_P6;         /* Expression: maxUDPQueue
                                        * Referenced by: '<S335>/Run Command Receive'
                                        */
  real_T RunCommandReceive_P7_Size[2];
                                /* Computed Parameter: RunCommandReceive_P7_Size
                                 * Referenced by: '<S335>/Run Command Receive'
                                 */
  real_T RunCommandReceive_P7;         /* Expression: rcvMulticast
                                        * Referenced by: '<S335>/Run Command Receive'
                                        */
  real_T RunCommandReceive_P8_Size[2];
                                /* Computed Parameter: RunCommandReceive_P8_Size
                                 * Referenced by: '<S335>/Run Command Receive'
                                 */
  real_T RunCommandReceive_P9_Size[2];
                                /* Computed Parameter: RunCommandReceive_P9_Size
                                 * Referenced by: '<S335>/Run Command Receive'
                                 */
  real_T RunCommandReceive_P9;         /* Expression: sampleTime
                                        * Referenced by: '<S335>/Run Command Receive'
                                        */
  real_T PauseType_Value;              /* Expression: 0
                                        * Referenced by: '<S3>/Pause Type'
                                        */
  real_T Seed_Value;                   /* Expression: 0
                                        * Referenced by: '<S3>/Seed'
                                        */
  real_T Constant_Value_l;             /* Expression: 1
                                        * Referenced by: '<S336>/Constant'
                                        */
  real_T UsecustomTPsequence_Value;    /* Expression: 0
                                        * Referenced by: '<S3>/Use custom TP sequence'
                                        */
  real_T Memory_InitialCondition_m;    /* Expression: 0
                                        * Referenced by: '<S3>/Memory'
                                        */
  real_T RunTaskClockFlag_Value;       /* Expression: 1
                                        * Referenced by: '<S3>/Run Task Clock Flag'
                                        */
  real_T TaskClock_Amp_b;              /* Expression: 1
                                        * Referenced by: '<S336>/Task Clock'
                                        */
  real_T TaskClock_Period_f;           /* Computed Parameter: TaskClock_Period_f
                                        * Referenced by: '<S336>/Task Clock'
                                        */
  real_T TaskClock_Duty_p;             /* Computed Parameter: TaskClock_Duty_p
                                        * Referenced by: '<S336>/Task Clock'
                                        */
  real_T TaskClock_PhaseDelay_h;       /* Expression: 0
                                        * Referenced by: '<S336>/Task Clock'
                                        */
  real_T Constant_Value_d;             /* Expression: 1
                                        * Referenced by: '<S3>/Constant'
                                        */
  real_T Memory_InitialCondition_pk;   /* Expression: 0
                                        * Referenced by: '<S1>/Memory'
                                        */
  real_T ZeroDigOut_Value[4];          /* Expression: [0 0 0 0]
                                        * Referenced by: '<S1>/ZeroDigOut'
                                        */
  real_T Memory_InitialCondition_i;    /* Expression: 0
                                        * Referenced by: '<S9>/Memory'
                                        */
  real_T Gain_Gain_g;                  /* Expression: 0.001
                                        * Referenced by: '<S9>/Gain'
                                        */
  real_T Memory2_InitialCondition_d;   /* Expression: 0
                                        * Referenced by: '<S38>/Memory2'
                                        */
  real_T Switch_Threshold_j;           /* Expression: 0
                                        * Referenced by: '<S7>/Switch'
                                        */
  real_T attribcol2_Value;             /* Expression: attribcol2
                                        * Referenced by: '<S7>/attribcol2'
                                        */
  real_T attribcol3_Value;             /* Expression: attribcol3
                                        * Referenced by: '<S7>/attribcol3'
                                        */
  real_T attribcol4_Value;             /* Expression: attribcol4
                                        * Referenced by: '<S7>/attribcol4'
                                        */
  real_T attribcol5_Value;             /* Expression: attribcol5
                                        * Referenced by: '<S7>/attribcol5'
                                        */
  real_T SelectedStates_Value;         /* Expression: [1]
                                        * Referenced by: '<S7>/Selected States'
                                        */
  real_T Switch_Threshold_b;           /* Expression: 0
                                        * Referenced by: '<S6>/Switch'
                                        */
  real_T attribcol2_Value_b[3];        /* Expression: attribcol2
                                        * Referenced by: '<S6>/attribcol2'
                                        */
  real_T attribcol3_Value_o[3];        /* Expression: attribcol3
                                        * Referenced by: '<S6>/attribcol3'
                                        */
  real_T attribcol4_Value_l[3];        /* Expression: attribcol4
                                        * Referenced by: '<S6>/attribcol4'
                                        */
  real_T attribcol5_Value_n[3];        /* Expression: attribcol5
                                        * Referenced by: '<S6>/attribcol5'
                                        */
  real_T SelectedStates_Value_b;       /* Expression: [1]
                                        * Referenced by: '<S6>/Selected States'
                                        */
  real_T Memory2_InitialCondition_o;   /* Expression: 0
                                        * Referenced by: '<Root>/Memory2'
                                        */
  real_T attribcol2_Value_i;           /* Expression: attribcol2
                                        * Referenced by: '<S12>/attribcol2'
                                        */
  real_T attribcol3_Value_f;           /* Expression: attribcol3
                                        * Referenced by: '<S12>/attribcol3'
                                        */
  real_T attribcol4_Value_la;          /* Expression: attribcol4
                                        * Referenced by: '<S12>/attribcol4'
                                        */
  real_T attribcol5_Value_b;           /* Expression: attribcol5
                                        * Referenced by: '<S12>/attribcol5'
                                        */
  real_T SelectedStates_Value_m;       /* Expression: [1]
                                        * Referenced by: '<S12>/Selected States'
                                        */
  real_T attribcol2_Value_d[3];        /* Expression: attribcol2
                                        * Referenced by: '<S10>/attribcol2'
                                        */
  real_T attribcol3_Value_c[3];        /* Expression: attribcol3
                                        * Referenced by: '<S10>/attribcol3'
                                        */
  real_T attribcol4_Value_lm[3];       /* Expression: attribcol4
                                        * Referenced by: '<S10>/attribcol4'
                                        */
  real_T attribcol5_Value_j[3];        /* Expression: attribcol5
                                        * Referenced by: '<S10>/attribcol5'
                                        */
  real_T SelectedStates_Value_n;       /* Expression: [1]
                                        * Referenced by: '<S10>/Selected States'
                                        */
  real_T DisplaySizem_Value[2];        /* Expression: [0.0, 0.0]
                                        * Referenced by: '<S3>/Display Size (m)'
                                        */
  real_T NextTProw_Value;              /* Expression: -1
                                        * Referenced by: '<S3>/Next TP row'
                                        */
  real_T Repeat_Trial_Flag_Value;      /* Expression: 0
                                        * Referenced by: '<S3>/Repeat_Trial_Flag'
                                        */
  real_T TmpRTBAtHold_to_1KhzInport2_InitialCondition;/* Expression: 0
                                                       * Referenced by: synthesized block
                                                       */
  real_T DisplaySizepels_Value[2];     /* Expression: [0, 0]
                                        * Referenced by: '<S3>/Display Size (pels)'
                                        */
  real_T DockingPoints_Value[10];      /* Expression: zeros(5, 2);
                                        * Referenced by: '<S3>/Docking Points'
                                        */
  real_T ELCameraFocalLength_Value_h;  /* Expression: 0
                                        * Referenced by: '<S3>/EL Camera Focal Length'
                                        */
  real_T ELCameraPosition_Value_e[3];  /* Expression: [0, 0, 0]
                                        * Referenced by: '<S3>/EL Camera Position'
                                        */
  real_T ELCameraAngle_Value_j[2];     /* Expression: [0, 0]
                                        * Referenced by: '<S3>/EL Camera Angle'
                                        */
  real_T ELTrackingAvailable_Value_m;  /* Expression: 0
                                        * Referenced by: '<S3>/EL Tracking Available'
                                        */
  real_T SubjectHeight_Value;          /* Expression: 0
                                        * Referenced by: '<S3>/Subject Height'
                                        */
  real_T SubjectWeight_Value;          /* Expression: 0
                                        * Referenced by: '<S3>/Subject Weight'
                                        */
  real_T frame_of_reference_center_Value[2];/* Expression: [0, 0]
                                             * Referenced by: '<S3>/frame_of_reference_center'
                                             */
  real_T LibraryPatchVersion_Value;    /* Expression: 5
                                        * Referenced by: '<S3>/Library Patch Version'
                                        */
  real_T LibraryVersion_Value;         /* Expression: 3.9
                                        * Referenced by: '<S3>/Library Version'
                                        */
  real_T TaskVersion_Value;            /* Expression: 1
                                        * Referenced by: '<S3>/Task Version'
                                        */
  real_T xPCVersion_Value;             /* Expression: 6.11
                                        * Referenced by: '<S3>/xPC Version'
                                        */
  real_T dlmbuildtime_Value;           /* Expression: 20250523.144123602659
                                        * Referenced by: '<S3>/dlm build time'
                                        */
  real_T preview_detail_Value[3];     /* Expression: [Target_Type, Vcols, Lcols]
                                       * Referenced by: '<S334>/preview_detail'
                                       */
  real_T NotLoggingAnalogInputs_Value; /* Expression: 0
                                        * Referenced by: '<S22>/Not Logging Analog Inputs'
                                        */
  real_T xpos_index_Value;             /* Expression: 1
                                        * Referenced by: '<S14>/xpos_index'
                                        */
  real_T ypos_index_Value;             /* Expression: 2
                                        * Referenced by: '<S14>/ypos_index'
                                        */
  real_T state4_indices_Value[4];      /* Expression: attribcol4
                                        * Referenced by: '<S14>/state4_indices'
                                        */
  real_T state5_indices_Value[4];      /* Expression: attribcol5
                                        * Referenced by: '<S14>/state5_indices'
                                        */
  real_T padder_Value[35];             /* Expression: stateindices_padding
                                        * Referenced by: '<S14>/padder'
                                        */
  real_T feedback_status_Value;        /* Expression: 1
                                        * Referenced by: '<S405>/feedback_status'
                                        */
  real_T Constant2_Value_e;            /* Expression: 1
                                        * Referenced by: '<S21>/Constant2'
                                        */
  real_T xpos_index_Value_l;           /* Expression: 1
                                        * Referenced by: '<S17>/xpos_index'
                                        */
  real_T ypos_index_Value_d;           /* Expression: 2
                                        * Referenced by: '<S17>/ypos_index'
                                        */
  real_T state4_indices_Value_p[4];    /* Expression: attribcol4
                                        * Referenced by: '<S17>/state4_indices'
                                        */
  real_T state5_indices_Value_l[4];    /* Expression: attribcol5
                                        * Referenced by: '<S17>/state5_indices'
                                        */
  real_T padder_Value_l[35];           /* Expression: stateindices_padding
                                        * Referenced by: '<S17>/padder'
                                        */
  real_T xpos_index_Value_p;           /* Expression: 1
                                        * Referenced by: '<S15>/xpos_index'
                                        */
  real_T ypos_index_Value_p;           /* Expression: 2
                                        * Referenced by: '<S15>/ypos_index'
                                        */
  real_T state4_indices_Value_i[4];    /* Expression: attribcol4
                                        * Referenced by: '<S15>/state4_indices'
                                        */
  real_T state5_indices_Value_j[4];    /* Expression: attribcol5
                                        * Referenced by: '<S15>/state5_indices'
                                        */
  real_T padder_Value_a[35];           /* Expression: stateindices_padding
                                        * Referenced by: '<S15>/padder'
                                        */
  real_T PulseGenerator_Amp;           /* Expression: 1
                                        * Referenced by: '<S21>/Pulse Generator'
                                        */
  real_T PulseGenerator_Period;     /* Computed Parameter: PulseGenerator_Period
                                     * Referenced by: '<S21>/Pulse Generator'
                                     */
  real_T PulseGenerator_Duty;         /* Computed Parameter: PulseGenerator_Duty
                                       * Referenced by: '<S21>/Pulse Generator'
                                       */
  real_T PulseGenerator_PhaseDelay;    /* Expression: 0
                                        * Referenced by: '<S21>/Pulse Generator'
                                        */
  real_T seconds_remaining_Value;      /* Expression: -1
                                        * Referenced by: '<S1>/seconds_remaining'
                                        */
  real_T RateTransition2_InitialCondition_l;/* Expression: 0
                                             * Referenced by: '<S23>/Rate Transition2'
                                             */
  real_T custom_version_Value;         /* Expression: 9
                                        * Referenced by: '<S23>/custom_version'
                                        */
  real_T NotLoggingEventCodes_Value;   /* Expression: 0
                                        * Referenced by: '<S24>/Not Logging Event Codes'
                                        */
  real_T Receive_P1_Size_k[2];         /* Computed Parameter: Receive_P1_Size_k
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P1_i[26];             /* Computed Parameter: Receive_P1_i
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P2_Size_l1[2];        /* Computed Parameter: Receive_P2_Size_l1
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P2_g;                 /* Expression: localPort
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P3_Size_k[2];         /* Computed Parameter: Receive_P3_Size_k
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P3_b2;                /* Expression: outWidth
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P4_Size_c[2];         /* Computed Parameter: Receive_P4_Size_c
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P4_gy;                /* Expression: useHostTargetComm
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P5_Size_g[2];         /* Computed Parameter: Receive_P5_Size_g
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P5_i[11];             /* Computed Parameter: Receive_P5_i
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P6_Size_o[2];         /* Computed Parameter: Receive_P6_Size_o
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P6_j;                 /* Expression: maxUDPQueue
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P7_Size_c[2];         /* Computed Parameter: Receive_P7_Size_c
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P7_g;                 /* Expression: rcvMulticast
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P8_Size_g[2];         /* Computed Parameter: Receive_P8_Size_g
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P9_Size_j[2];         /* Computed Parameter: Receive_P9_Size_j
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T Receive_P9_m;                 /* Expression: sampleTime
                                        * Referenced by: '<S9>/Receive'
                                        */
  real_T TmpRTBAtTimestampOutport1_InitialCondition;/* Expression: 0
                                                     * Referenced by: synthesized block
                                                     */
  real_T packet_version_Value;         /* Expression: -1
                                        * Referenced by: '<S26>/packet_version'
                                        */
  real_T Delay_InitialCondition;       /* Expression: 0.0
                                        * Referenced by: '<S34>/Delay'
                                        */
  real_T Delay_InitialCondition_p;     /* Expression: 0.0
                                        * Referenced by: '<S327>/Delay'
                                        */
  real_T butterworth_2nd_order_10hz_Value[3];
                     /* Expression: [1.639178228e+04 -0.9780305085 1.9777864838]
                      * Referenced by: '<S38>/butterworth_2nd_order_10hz'
                      */
  real_T rel_diff_Value;               /* Expression: 0.1
                                        * Referenced by: '<S38>/rel_diff'
                                        */
  real_T abs_diff_Value;               /* Expression: 0.1
                                        * Referenced by: '<S38>/abs_diff'
                                        */
  real_T Delay_InitialCondition_c;     /* Expression: 0.0
                                        * Referenced by: '<S38>/Delay'
                                        */
  real_T TaskClock_Amp_l;              /* Expression: 1
                                        * Referenced by: '<S38>/Task Clock'
                                        */
  real_T TaskClock_Period_m;           /* Computed Parameter: TaskClock_Period_m
                                        * Referenced by: '<S38>/Task Clock'
                                        */
  real_T TaskClock_Duty_f;             /* Computed Parameter: TaskClock_Duty_f
                                        * Referenced by: '<S38>/Task Clock'
                                        */
  real_T TaskClock_PhaseDelay_hb;      /* Expression: 0
                                        * Referenced by: '<S38>/Task Clock'
                                        */
  real_T Memory3_InitialCondition_c;   /* Expression: 0
                                        * Referenced by: '<S19>/Memory3'
                                        */
  real_T Switch_Threshold_e;           /* Expression: 0
                                        * Referenced by: '<S19>/Switch'
                                        */
  real_T Switch_Threshold_bf;          /* Expression: 1
                                        * Referenced by: '<S5>/Switch'
                                        */
  real_T Switch1_Threshold_j;          /* Expression: 1
                                        * Referenced by: '<S369>/Switch1'
                                        */
  real_T Memory1_InitialCondition_b;   /* Expression: 0
                                        * Referenced by: '<S38>/Memory1'
                                        */
  real_T Memory1_InitialCondition_n;   /* Expression: 0
                                        * Referenced by: '<S1>/Memory1'
                                        */
  real_T Memory2_1_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_2_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_3_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_4_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_5_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_9_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_18_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_19_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_20_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_21_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_22_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_26_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_10_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_11_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_12_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_13_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_14_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_15_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_16_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_17_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_23_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_24_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_25_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_27_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_28_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_29_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_30_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_31_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_32_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_33_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_34_InitialCondition;  /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_6_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_7_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T Memory2_8_InitialCondition;   /* Expression: 0
                                        * Referenced by: '<S1>/Memory2'
                                        */
  real_T butterworth_2nd_order_250hz_Value[3];
                     /* Expression: [3.338387406e+01 -0.5740619151 1.4542435863]
                      * Referenced by: '<S327>/butterworth_2nd_order_250hz'
                      */
  real_T Memory1_InitialCondition_m;   /* Expression: 0
                                        * Referenced by: '<S329>/Memory1'
                                        */
  real_T encoder_err_threshold_Value;  /* Expression: 4*pi/180
                                        * Referenced by: '<S329>/encoder_err_threshold'
                                        */
  real_T arm_count_Value;              /* Expression: 0
                                        * Referenced by: '<S35>/arm_count'
                                        */
  real_T fp1_present_Value;            /* Expression: 0
                                        * Referenced by: '<S35>/fp1_present'
                                        */
  real_T fp2_present_Value;            /* Expression: 0
                                        * Referenced by: '<S35>/fp2_present'
                                        */
  real_T gaze_tracker_present_Value;   /* Expression: 0
                                        * Referenced by: '<S35>/gaze_tracker_present'
                                        */
  real_T robot_lift_present_Value;     /* Expression: 0
                                        * Referenced by: '<S35>/robot_lift_present'
                                        */
  real_T ECATStatus_InitialValue[8];   /* Expression: zeros(1,8)
                                        * Referenced by: '<S1>/ECAT Status'
                                        */
  real_T ECATStatus1_InitialValue[10]; /* Expression: zeros(1,10)
                                        * Referenced by: '<S1>/ECAT Status1'
                                        */
  real_T ECAThardware_InitialValue[14];/* Expression: zeros(1,14)
                                        * Referenced by: '<S1>/ECAT hardware'
                                        */
  real_T xpos_index_Value_g;           /* Expression: 1
                                        * Referenced by: '<S16>/xpos_index'
                                        */
  real_T ypos_index_Value_e;           /* Expression: 2
                                        * Referenced by: '<S16>/ypos_index'
                                        */
  real_T state4_indices_Value_k[4];    /* Expression: attribcol4
                                        * Referenced by: '<S16>/state4_indices'
                                        */
  real_T state5_indices_Value_jv[4];   /* Expression: attribcol5
                                        * Referenced by: '<S16>/state5_indices'
                                        */
  real_T padder_Value_b[35];           /* Expression: stateindices_padding
                                        * Referenced by: '<S16>/padder'
                                        */
  real_T xpos_index_Value_e;           /* Expression: 1
                                        * Referenced by: '<S13>/xpos_index'
                                        */
  real_T ypos_index_Value_c;           /* Expression: 2
                                        * Referenced by: '<S13>/ypos_index'
                                        */
  real_T state4_indices_Value_d[6];    /* Expression: attribcol4
                                        * Referenced by: '<S13>/state4_indices'
                                        */
  real_T state5_indices_Value_p[6];    /* Expression: attribcol5
                                        * Referenced by: '<S13>/state5_indices'
                                        */
  real_T padder_Value_bi[25];          /* Expression: stateindices_padding
                                        * Referenced by: '<S13>/padder'
                                        */
  real_T xpos_index_Value_a;           /* Expression: 1
                                        * Referenced by: '<S18>/xpos_index'
                                        */
  real_T ypos_index_Value_f;           /* Expression: 2
                                        * Referenced by: '<S18>/ypos_index'
                                        */
  real_T state4_indices_Value_l[4];    /* Expression: attribcol4
                                        * Referenced by: '<S18>/state4_indices'
                                        */
  real_T state5_indices_Value_d[4];    /* Expression: attribcol5
                                        * Referenced by: '<S18>/state5_indices'
                                        */
  real_T padder_Value_p[35];           /* Expression: stateindices_padding
                                        * Referenced by: '<S18>/padder'
                                        */
  real_T Switch2_Threshold;            /* Expression: 1
                                        * Referenced by: '<S372>/Switch2'
                                        */
  real_T Switch3_Threshold;            /* Expression: 1
                                        * Referenced by: '<S372>/Switch3'
                                        */
  real_T Switch4_Threshold;            /* Expression: 1
                                        * Referenced by: '<S372>/Switch4'
                                        */
  real_T Switch5_Threshold;            /* Expression: 1
                                        * Referenced by: '<S372>/Switch5'
                                        */
  real_T Switch6_Threshold;            /* Expression: 1
                                        * Referenced by: '<S372>/Switch6'
                                        */
  real_T Switch7_Threshold;            /* Expression: 1
                                        * Referenced by: '<S372>/Switch7'
                                        */
  real_T Switch2_Threshold_p;          /* Expression: 1
                                        * Referenced by: '<S374>/Switch2'
                                        */
  real_T Switch3_Threshold_g;          /* Expression: 1
                                        * Referenced by: '<S374>/Switch3'
                                        */
  real_T Switch4_Threshold_h;          /* Expression: 1
                                        * Referenced by: '<S374>/Switch4'
                                        */
  real_T Switch5_Threshold_j;          /* Expression: 1
                                        * Referenced by: '<S374>/Switch5'
                                        */
  real_T Switch6_Threshold_o;          /* Expression: 1
                                        * Referenced by: '<S374>/Switch6'
                                        */
  real_T Switch7_Threshold_l;          /* Expression: 1
                                        * Referenced by: '<S374>/Switch7'
                                        */
  real_T Constant_Value_c;             /* Expression: 1
                                        * Referenced by: '<Root>/Constant'
                                        */
  real_T binary_file_names_Value;      /* Expression: 0
                                        * Referenced by: '<S8>/binary_file_names'
                                        */
  real_T binary_files_Value[10];   /* Expression: [0  0  0  0  0  0  0  0  0  0]
                                    * Referenced by: '<S8>/binary_files'
                                    */
  real_T BARRIER_ROWBarriertargetBarriernone_Value;/* Expression: 5
                                                    * Referenced by: '<S375>/BARRIER_ROW;Barrier;target;Barrier;;;none;;'
                                                    */
  real_T CURSOR_ROWHandTargetRowtargethandnone_Value;/* Expression: 2
                                                      * Referenced by: '<S375>/CURSOR_ROW;Hand Target Row;target;hand ;;;none;;'
                                                      */
  real_T GOAL_ROWGoalRowtargetGoalnone_Value;/* Expression: 8
                                              * Referenced by: '<S375>/GOAL_ROW;Goal Row;target;Goal;;;none;;'
                                              */
  real_T GOAL_TIMEGoaltimesfloatTimethatpuckhastostayingoaltotriggersucc;/* Expression: 13
                                                                      * Referenced by: '<S375>/GOAL_TIME;Goal time (s);float;Time that puck has to stay in goal to trigger success;;;none;;'
                                                                      */
  real_T LOAD_ROWLoadRowloadLoadnone_Value;/* Expression: 4
                                            * Referenced by: '<S375>/LOAD_ROW;Load Row;load;Load;;;none;;'
                                            */
  real_T PRESHOT_ROWPreshotAreatargetPreshotAreanone_Value;/* Expression: 7
                                                            * Referenced by: '<S375>/PRESHOT_ROW;Preshot Area;target;Preshot Area ;;;none;;'
                                                            */
  real_T PUCK_DAMPINGPuckdampingfloatDampingconstantonpuckbetween0and1no;/* Expression: 14
                                                                      * Referenced by: '<S375>/PUCK_DAMPING;Puck damping;float;Damping constant on puck (between 0 and 1);;;none;;'
                                                                      */
  real_T PUCK_ROWPuckTargetRowtargetPucknone_Value;/* Expression: 3
                                                    * Referenced by: '<S375>/PUCK_ROW;Puck Target Row;target;Puck;;;none;;'
                                                    */
  real_T SECONDSTrialdurationsfloatHowlongisthetrialinsecondsnone_Value;/* Expression: 1
                                                                      * Referenced by: '<S375>/SECONDS;Trial duration (s);float;How long is the trial in seconds.;;;none;;'
                                                                      */
  real_T SHOT_READY_TIMEShotreadytimesfloatTimetoholdinstarttargetduring;/* Expression: 10
                                                                      * Referenced by: '<S375>/SHOT_READY_TIME;Shot ready time (s);float;Time to hold in start target during preshot routine to trigger the set state;;;none;;'
                                                                      */
  real_T SHOT_SET_TIMEShotsettimesfloatTimetoholdinstarttargetafterpresh;/* Expression: 11
                                                                      * Referenced by: '<S375>/SHOT_SET_TIME;Shot set time (s);float;Time to hold in start target after preshot routine to trigger go cue;;;none;;'
                                                                      */
  real_T SHOT_TIMEShottimesfloatTimetomakeashotintothegoalnone_Value;/* Expression: 12
                                                                      * Referenced by: '<S375>/SHOT_TIME;Shot time (s);float;Time to make a shot into the goal;;;none;;'
                                                                      */
  real_T START_HOLD_TIMEStartholdtimesfloatTimetoholdinstarttargetbefore;/* Expression: 9
                                                                      * Referenced by: '<S375>/START_HOLD_TIME;Start hold time (s);float;Time to hold in start target before triggering preshot routine;;;none;;'
                                                                      */
  real_T START_ROWStartPositiontargetStartingSpotforPtnone_Value;/* Expression: 6
                                                                  * Referenced by: '<S375>/START_ROW;Start Position;target;Starting Spot for Pt ;;;none;;'
                                                                  */
  real_T E_BEGIN_PRESHOTbeginpreshotroutinenone_Value;/* Expression: 4
                                                       * Referenced by: '<S376>/E_BEGIN_PRESHOT;begin preshot routine;;;;;none;;'
                                                       */
  real_T E_ENTER_STARTenterstarttargetnone_Value;/* Expression: 2
                                                  * Referenced by: '<S376>/E_ENTER_START;enter start target;;;;;none;;'
                                                  */
  real_T E_FAILUREfailurered_Value;    /* Expression: 13
                                        * Referenced by: '<S376>/E_FAILURE;failure;;;;;red;;'
                                        */
  real_T E_HAND_IN_BARRIERhandinbarriernone_Value;/* Expression: 9
                                                   * Referenced by: '<S376>/E_HAND_IN_BARRIER;hand in barrier;;;;;none;;'
                                                   */
  real_T E_NO_EVENTnaThisevent_codedoesnotsaveaneventinthedatafileitjust;/* Expression: 0
                                                                      * Referenced by: '<S376>/E_NO_EVENT;n|a;;This event_code does not save an event in the data file, it just clears the event;;;none;;'
                                                                      */
  real_T E_PUCK_IN_BARRIERpuckinbarriernone_Value;/* Expression: 10
                                                   * Referenced by: '<S376>/E_PUCK_IN_BARRIER;puck in barrier;;;;;none;;'
                                                   */
  real_T E_PUCK_IN_GOALpuckingoalnone_Value;/* Expression: 7
                                             * Referenced by: '<S376>/E_PUCK_IN_GOAL;puck in goal;;;;;none;;'
                                             */
  real_T E_PUCK_MISSpuckmissnone_Value;/* Expression: 11
                                        * Referenced by: '<S376>/E_PUCK_MISS;puck miss;;;;;none;;'
                                        */
  real_T E_SHOT_GOshotgonone_Value;    /* Expression: 6
                                        * Referenced by: '<S376>/E_SHOT_GO;shot go;;;;;none;;'
                                        */
  real_T E_SHOT_READYshotreadynone_Value;/* Expression: 5
                                          * Referenced by: '<S376>/E_SHOT_READY;shot ready;;;;;none;;'
                                          */
  real_T E_START_TARGET_ONstarttargetonnone_Value;/* Expression: 1
                                                   * Referenced by: '<S376>/E_START_TARGET_ON;start target on;;;;;none;;'
                                                   */
  real_T E_SUCCESSsuccessgreen_Value;  /* Expression: 8
                                        * Referenced by: '<S376>/E_SUCCESS;success;;;;;green;;'
                                        */
  real_T E_TIMEOUTtimeoutred_Value;    /* Expression: 14
                                        * Referenced by: '<S376>/E_TIMEOUT;timeout;;;;;red;;'
                                        */
  real_T E_TRIAL_STARTtrialstartnone_Value;/* Expression: 3
                                            * Referenced by: '<S376>/E_TRIAL_START;trial start;;;;;none;;'
                                            */
  real_T F_BUMPF_BUMPfloatCompletelyarbitraryparameterbasedonwhatfeelsgo;/* Expression: 1
                                                                      * Referenced by: '<S377>/F_BUMP;F_BUMP;float;Completely arbitrary parameter based on what feels good...;;;none;;'
                                                                      */
  real_T MASS_CIRCLECircletargetmassfloatnone_Value;/* Expression: 2
                                                     * Referenced by: '<S377>/MASS_CIRCLE;Circle target mass;float;;;;none;;'
                                                     */
  real_T MASS_RECTRectangletargetmassfloatnone_Value;/* Expression: 3
                                                      * Referenced by: '<S377>/MASS_RECT;Rectangle target mass;float;;;;none;;'
                                                      */
  real_T PERT_DURPerturbationDurationfloatmsTimethattheperturbationishig;/* Expression: 5
                                                                      * Referenced by: '<S377>/PERT_DUR;Perturbation Duration;float;(ms) Time that the perturbation is high for;;;none;;'
                                                                      */
  real_T PERT_RAMPPerturbationRampTimefloatmsTimefortheperturbationtoram;/* Expression: 4
                                                                      * Referenced by: '<S377>/PERT_RAMP;Perturbation Ramp Time;float;(ms) Time for the perturbation to ramp up and down;;;none;;'
                                                                      */
  real_T FIRST_FILLFirstfillcolorcolourFirstfillcolorforaselectedtargetc;/* Expression: 8
                                                                      * Referenced by: '<S378>/FIRST_FILL;First fill color;colour;First fill color for a selected target (color);;;none;;'
                                                                      */
  real_T HEIGHTHeightfloatRectangleheightcmnone_Value;/* Expression: 6
                                                       * Referenced by: '<S378>/HEIGHT;Height;float;Rectangle height (cm);;;none;;'
                                                       */
  real_T RADIUS_LOGlogicalradiusfloatcomputationalradiuscmnone_Value;/* Expression: 4
                                                                      * Referenced by: '<S378>/RADIUS_LOG;logical radius;float;computational radius (cm);;;none;;'
                                                                      */
  real_T RADIUS_VISradiusvisfloatradiusincmlegacynone_Value;/* Expression: 5
                                                             * Referenced by: '<S378>/RADIUS_VIS;radius vis;float;radius in cm (legacy?);;;none;;'
                                                             */
  real_T ROTATIONRotationfloatRectangleroationdegreesnone_Value;/* Expression: 7
                                                                 * Referenced by: '<S378>/ROTATION;Rotation;float;Rectangle roation (degrees);;;none;;'
                                                                 */
  real_T SECOND_FILLSecondfillcolorcolourSecondfillcolorforaselectedtarg;/* Expression: 9
                                                                      * Referenced by: '<S378>/SECOND_FILL;Second fill color;colour;Second fill color for a selected target (color);;;none;;'
                                                                      */
  real_T STROKE_COLORStrokecolourcolourStrokecolorcolornone_Value;/* Expression: 11
                                                                   * Referenced by: '<S378>/STROKE_COLOR;Stroke colour;colour;Stroke color (color);;;none;;'
                                                                   */
  real_T STROKE_WIDTHWidthofthestrokefloatStrokeweightcmnone_Value;/* Expression: 12
                                                                    * Referenced by: '<S378>/STROKE_WIDTH;Width of the stroke;float;Stroke weight (cm);;;none;;'
                                                                    */
  real_T THIRD_FILLthirdfillcolorcolourThirdfillcolorforaselectedtargetc;/* Expression: 10
                                                                      * Referenced by: '<S378>/THIRD_FILL;third fill color;colour;Third fill color for a selected target (color);;;none;;'
                                                                      */
  real_T col_xXfloatXPositioncmofthetargetrelativetolocal00none_Value;/* Expression: 1
                                                                      * Referenced by: '<S378>/col_x;X;float;X Position (cm) of the target relative to  local (0,0);;;none;;'
                                                                      */
  real_T col_yYfloatYPositioncmofthetargetrelativetolocal00none_Value;/* Expression: 2
                                                                      * Referenced by: '<S378>/col_y;Y;float;Y Position (cm) of the target relative to  local (0,0);;;none;;'
                                                                      */
  real_T WIDTHWidthorRadiusfloatRectanglewidthorCircleRadiuscmnone_Value;/* Expression: 3
                                                                      * Referenced by: '<S378>/WIDTH;Width or Radius;float;Rectangle width or Circle Radius (cm);;;none;;'
                                                                      */
  real_T INSTRUCTIONS_Value;           /* Expression: 1
                                        * Referenced by: '<S379>/INSTRUCTIONS='
                                        */
  real_T LOAD_FOREITHER_Value;         /* Expression: 2
                                        * Referenced by: '<S379>/LOAD_FOR=EITHER'
                                        */
  real_T FORCE_MULTIPLIERForcemultiplierfloatnone_Value;/* Expression: 1
                                                         * Referenced by: '<S380>/FORCE_MULTIPLIER;Force multiplier;float;;;;none;;'
                                                         */
  real_T GUI_VCODE_Value[630];         /* Expression: zeros(70, 9);
                                        * Referenced by: '<S9>/GUI_VCODE'
                                        */
  real_T u000hz_Value;                 /* Expression: 1
                                        * Referenced by: '<S381>/1000 hz'
                                        */
  real_T Send_P1_Size_a[2];            /* Computed Parameter: Send_P1_Size_a
                                        * Referenced by: '<S9>/Send'
                                        */
  real_T Send_P1_k1[26];               /* Computed Parameter: Send_P1_k1
                                        * Referenced by: '<S9>/Send'
                                        */
  real_T Send_P2_Size_h[2];            /* Computed Parameter: Send_P2_Size_h
                                        * Referenced by: '<S9>/Send'
                                        */
  real_T Send_P2_i;                    /* Expression: localPort
                                        * Referenced by: '<S9>/Send'
                                        */
  real_T Send_P3_Size_i[2];            /* Computed Parameter: Send_P3_Size_i
                                        * Referenced by: '<S9>/Send'
                                        */
  real_T Send_P3_d[11];                /* Computed Parameter: Send_P3_d
                                        * Referenced by: '<S9>/Send'
                                        */
  real_T Send_P4_Size_o[2];            /* Computed Parameter: Send_P4_Size_o
                                        * Referenced by: '<S9>/Send'
                                        */
  real_T Send_P4_g;                    /* Expression: toPort
                                        * Referenced by: '<S9>/Send'
                                        */
  real_T Send_P5_Size_n[2];            /* Computed Parameter: Send_P5_Size_n
                                        * Referenced by: '<S9>/Send'
                                        */
  real_T Send_P5_ev;                   /* Expression: useHostTargetComm
                                        * Referenced by: '<S9>/Send'
                                        */
  real_T Send_P6_Size_p[2];            /* Computed Parameter: Send_P6_Size_p
                                        * Referenced by: '<S9>/Send'
                                        */
  real_T Send_P6_l;                    /* Expression: sampleTime
                                        * Referenced by: '<S9>/Send'
                                        */
  int32_T request_packet_Value[34];    /* Expression: zeros(1, 34, 'int32')
                                        * Referenced by: '<S29>/request_packet'
                                        */
  int32_T Memory_InitialCondition_g;
                                /* Computed Parameter: Memory_InitialCondition_g
                                 * Referenced by: '<S115>/Memory'
                                 */
  int32_T Constant_Value_l2;           /* Computed Parameter: Constant_Value_l2
                                        * Referenced by: '<S114>/Constant'
                                        */
  int32_T Constant1_Value_n;           /* Computed Parameter: Constant1_Value_n
                                        * Referenced by: '<S114>/Constant1'
                                        */
  int32_T Constant_Value_k;            /* Computed Parameter: Constant_Value_k
                                        * Referenced by: '<S115>/Constant'
                                        */
  int32_T Constant1_Value_c;           /* Computed Parameter: Constant1_Value_c
                                        * Referenced by: '<S116>/Constant1'
                                        */
  int32_T Memory_InitialCondition_ax;
                               /* Computed Parameter: Memory_InitialCondition_ax
                                * Referenced by: '<S135>/Memory'
                                */
  int32_T Constant_Value_p;            /* Computed Parameter: Constant_Value_p
                                        * Referenced by: '<S134>/Constant'
                                        */
  int32_T Constant1_Value_o;           /* Computed Parameter: Constant1_Value_o
                                        * Referenced by: '<S134>/Constant1'
                                        */
  int32_T Constant_Value_ka;           /* Computed Parameter: Constant_Value_ka
                                        * Referenced by: '<S135>/Constant'
                                        */
  int32_T Constant1_Value_i;           /* Computed Parameter: Constant1_Value_i
                                        * Referenced by: '<S136>/Constant1'
                                        */
  int32_T Memory_InitialCondition_b;
                                /* Computed Parameter: Memory_InitialCondition_b
                                 * Referenced by: '<S91>/Memory'
                                 */
  int32_T Memory1_InitialCondition_a;
                               /* Computed Parameter: Memory1_InitialCondition_a
                                * Referenced by: '<S91>/Memory1'
                                */
  int32_T Memory_InitialCondition_ba;
                               /* Computed Parameter: Memory_InitialCondition_ba
                                * Referenced by: '<S92>/Memory'
                                */
  int32_T Memory1_InitialCondition_nm;
                              /* Computed Parameter: Memory1_InitialCondition_nm
                               * Referenced by: '<S92>/Memory1'
                               */
  int32_T Memory_InitialCondition_e;
                                /* Computed Parameter: Memory_InitialCondition_e
                                 * Referenced by: '<S94>/Memory'
                                 */
  int32_T Memory_InitialCondition_n;
                                /* Computed Parameter: Memory_InitialCondition_n
                                 * Referenced by: '<S95>/Memory'
                                 */
  int32_T Switch_Threshold_p;          /* Computed Parameter: Switch_Threshold_p
                                        * Referenced by: '<S109>/Switch'
                                        */
  int32_T Switch_Threshold_h2;        /* Computed Parameter: Switch_Threshold_h2
                                       * Referenced by: '<S108>/Switch'
                                       */
  int32_T readTrigger_Value;           /* Computed Parameter: readTrigger_Value
                                        * Referenced by: '<S77>/readTrigger'
                                        */
  int32_T Memory_InitialCondition_h;
                                /* Computed Parameter: Memory_InitialCondition_h
                                 * Referenced by: '<S97>/Memory'
                                 */
  int32_T Memory2_InitialCondition_j;
                               /* Computed Parameter: Memory2_InitialCondition_j
                                * Referenced by: '<S97>/Memory2'
                                */
  int32_T Switch_Threshold_jw;        /* Computed Parameter: Switch_Threshold_jw
                                       * Referenced by: '<S129>/Switch'
                                       */
  int32_T Switch_Threshold_c;          /* Computed Parameter: Switch_Threshold_c
                                        * Referenced by: '<S128>/Switch'
                                        */
  int32_T Memory_InitialCondition_bo;
                               /* Computed Parameter: Memory_InitialCondition_bo
                                * Referenced by: '<S190>/Memory'
                                */
  int32_T Constant_Value_mj;           /* Computed Parameter: Constant_Value_mj
                                        * Referenced by: '<S189>/Constant'
                                        */
  int32_T Constant1_Value_g;           /* Computed Parameter: Constant1_Value_g
                                        * Referenced by: '<S189>/Constant1'
                                        */
  int32_T Constant_Value_k2;           /* Computed Parameter: Constant_Value_k2
                                        * Referenced by: '<S190>/Constant'
                                        */
  int32_T Constant1_Value_p;           /* Computed Parameter: Constant1_Value_p
                                        * Referenced by: '<S191>/Constant1'
                                        */
  int32_T Memory_InitialCondition_l;
                                /* Computed Parameter: Memory_InitialCondition_l
                                 * Referenced by: '<S210>/Memory'
                                 */
  int32_T Constant_Value_de;           /* Computed Parameter: Constant_Value_de
                                        * Referenced by: '<S209>/Constant'
                                        */
  int32_T Constant1_Value_j;           /* Computed Parameter: Constant1_Value_j
                                        * Referenced by: '<S209>/Constant1'
                                        */
  int32_T Constant_Value_o;            /* Computed Parameter: Constant_Value_o
                                        * Referenced by: '<S210>/Constant'
                                        */
  int32_T Constant1_Value_ns;          /* Computed Parameter: Constant1_Value_ns
                                        * Referenced by: '<S211>/Constant1'
                                        */
  int32_T Memory_InitialCondition_ec;
                               /* Computed Parameter: Memory_InitialCondition_ec
                                * Referenced by: '<S165>/Memory'
                                */
  int32_T Memory1_InitialCondition_p;
                               /* Computed Parameter: Memory1_InitialCondition_p
                                * Referenced by: '<S165>/Memory1'
                                */
  int32_T Memory_InitialCondition_pu;
                               /* Computed Parameter: Memory_InitialCondition_pu
                                * Referenced by: '<S166>/Memory'
                                */
  int32_T Memory1_InitialCondition_ai;
                              /* Computed Parameter: Memory1_InitialCondition_ai
                               * Referenced by: '<S166>/Memory1'
                               */
  int32_T Memory_InitialCondition_ex;
                               /* Computed Parameter: Memory_InitialCondition_ex
                                * Referenced by: '<S168>/Memory'
                                */
  int32_T Memory_InitialCondition_o;
                                /* Computed Parameter: Memory_InitialCondition_o
                                 * Referenced by: '<S169>/Memory'
                                 */
  int32_T Switch_Threshold_l;          /* Computed Parameter: Switch_Threshold_l
                                        * Referenced by: '<S184>/Switch'
                                        */
  int32_T Switch_Threshold_eg;        /* Computed Parameter: Switch_Threshold_eg
                                       * Referenced by: '<S183>/Switch'
                                       */
  int32_T readTrigger_Value_a;        /* Computed Parameter: readTrigger_Value_a
                                       * Referenced by: '<S78>/readTrigger'
                                       */
  int32_T Memory_InitialCondition_lc;
                               /* Computed Parameter: Memory_InitialCondition_lc
                                * Referenced by: '<S172>/Memory'
                                */
  int32_T Memory2_InitialCondition_c;
                               /* Computed Parameter: Memory2_InitialCondition_c
                                * Referenced by: '<S172>/Memory2'
                                */
  int32_T Switch_Threshold_pr;        /* Computed Parameter: Switch_Threshold_pr
                                       * Referenced by: '<S204>/Switch'
                                       */
  int32_T Switch_Threshold_kt;        /* Computed Parameter: Switch_Threshold_kt
                                       * Referenced by: '<S203>/Switch'
                                       */
  int32_T activation_Value[2];         /* Computed Parameter: activation_Value
                                        * Referenced by: '<S66>/activation'
                                        */
  int32_T PCIBusSlot_Value[2];         /* Computed Parameter: PCIBusSlot_Value
                                        * Referenced by: '<S66>/PCI Bus Slot'
                                        */
  int32_T Switch_Threshold_bk;        /* Computed Parameter: Switch_Threshold_bk
                                       * Referenced by: '<S66>/Switch'
                                       */
  int32_T Bias_Bias;                   /* Computed Parameter: Bias_Bias
                                        * Referenced by: '<S66>/Bias'
                                        */
  int32_T Switch1_Threshold_m;        /* Computed Parameter: Switch1_Threshold_m
                                       * Referenced by: '<S66>/Switch1'
                                       */
  real32_T Constant_Value_bt[400];     /* Computed Parameter: Constant_Value_bt
                                        * Referenced by: '<S50>/Constant'
                                        */
  real32_T t2_InitialCondition;       /* Computed Parameter: t2_InitialCondition
                                       * Referenced by: '<S50>/t-2'
                                       */
  real32_T t1_InitialCondition;       /* Computed Parameter: t1_InitialCondition
                                       * Referenced by: '<S50>/t-1'
                                       */
  real32_T RateTransition1_InitialCondition_c;
                       /* Computed Parameter: RateTransition1_InitialCondition_c
                        * Referenced by: '<S28>/Rate Transition1'
                        */
  uint32_T total_packets_sent_Y0;   /* Computed Parameter: total_packets_sent_Y0
                                     * Referenced by: '<S53>/total_packets_sent'
                                     */
  uint32_T FixPtConstant_Value;       /* Computed Parameter: FixPtConstant_Value
                                       * Referenced by: '<S57>/FixPt Constant'
                                       */
  uint32_T Output_InitialCondition;
                                  /* Computed Parameter: Output_InitialCondition
                                   * Referenced by: '<S56>/Output'
                                   */
  uint32_T Constant_Value_j;           /* Computed Parameter: Constant_Value_j
                                        * Referenced by: '<S58>/Constant'
                                        */
  uint32_T max_packet_id_Value;       /* Computed Parameter: max_packet_id_Value
                                       * Referenced by: '<S28>/max_packet_id'
                                       */
  uint32_T Constant_Value_pb;          /* Computed Parameter: Constant_Value_pb
                                        * Referenced by: '<S108>/Constant'
                                        */
  uint32_T Memory_InitialCondition_ny;
                               /* Computed Parameter: Memory_InitialCondition_ny
                                * Referenced by: '<S114>/Memory'
                                */
  uint32_T Constant_Value_di;          /* Computed Parameter: Constant_Value_di
                                        * Referenced by: '<S116>/Constant'
                                        */
  uint32_T Constant_Value_l0;          /* Computed Parameter: Constant_Value_l0
                                        * Referenced by: '<S128>/Constant'
                                        */
  uint32_T Memory_InitialCondition_c;
                                /* Computed Parameter: Memory_InitialCondition_c
                                 * Referenced by: '<S134>/Memory'
                                 */
  uint32_T Constant_Value_ce;          /* Computed Parameter: Constant_Value_ce
                                        * Referenced by: '<S136>/Constant'
                                        */
  uint32_T Constant_Value_cey;         /* Computed Parameter: Constant_Value_cey
                                        * Referenced by: '<S183>/Constant'
                                        */
  uint32_T Memory_InitialCondition_iz;
                               /* Computed Parameter: Memory_InitialCondition_iz
                                * Referenced by: '<S189>/Memory'
                                */
  uint32_T Constant_Value_jo;          /* Computed Parameter: Constant_Value_jo
                                        * Referenced by: '<S191>/Constant'
                                        */
  uint32_T Constant_Value_e;           /* Computed Parameter: Constant_Value_e
                                        * Referenced by: '<S203>/Constant'
                                        */
  uint32_T Memory_InitialCondition_hd;
                               /* Computed Parameter: Memory_InitialCondition_hd
                                * Referenced by: '<S209>/Memory'
                                */
  uint32_T Constant_Value_oz;          /* Computed Parameter: Constant_Value_oz
                                        * Referenced by: '<S211>/Constant'
                                        */
  uint32_T Constant1_Value_ov;         /* Computed Parameter: Constant1_Value_ov
                                        * Referenced by: '<S257>/Constant1'
                                        */
  uint32_T Constant1_Value_m;          /* Computed Parameter: Constant1_Value_m
                                        * Referenced by: '<S259>/Constant1'
                                        */
  uint32_T EPcalibrationbtn_Y0;        /* Expression: uint32(0)
                                        * Referenced by: '<S276>/EP calibration btn'
                                        */
  uint32_T Statusbits_Y0[7];           /* Expression: zeros(7,1, 'uint32')
                                        * Referenced by: '<S276>/Status bits'
                                        */
  uint32_T Constant_Value_jt;          /* Computed Parameter: Constant_Value_jt
                                        * Referenced by: '<S276>/Constant'
                                        */
  uint32_T Constant1_Value_pc[7];      /* Computed Parameter: Constant1_Value_pc
                                        * Referenced by: '<S276>/Constant1'
                                        */
  uint32_T servocounter_Y0;            /* Computed Parameter: servocounter_Y0
                                        * Referenced by: '<S283>/servo counter'
                                        */
  uint32_T EPcalibrationbtn_Y0_f;      /* Expression: uint32(0)
                                        * Referenced by: '<S283>/EP calibration btn'
                                        */
  uint32_T Statusbits_Y0_l[7];         /* Expression: zeros(7,1, 'uint32')
                                        * Referenced by: '<S283>/Status bits'
                                        */
  uint32_T FixPtConstant_Value_h;   /* Computed Parameter: FixPtConstant_Value_h
                                     * Referenced by: '<S288>/FixPt Constant'
                                     */
  uint32_T Output_InitialCondition_e;
                                /* Computed Parameter: Output_InitialCondition_e
                                 * Referenced by: '<S286>/Output'
                                 */
  uint32_T Constant_Value_pz;          /* Computed Parameter: Constant_Value_pz
                                        * Referenced by: '<S289>/Constant'
                                        */
  uint32_T Constant_Value_h;           /* Computed Parameter: Constant_Value_h
                                        * Referenced by: '<S283>/Constant'
                                        */
  uint32_T Constant1_Value_nm[7];      /* Computed Parameter: Constant1_Value_nm
                                        * Referenced by: '<S283>/Constant1'
                                        */
  uint32_T Constant1_Value_oq;         /* Computed Parameter: Constant1_Value_oq
                                        * Referenced by: '<S86>/Constant1'
                                        */
  uint32_T FixPtConstant_Value_g;   /* Computed Parameter: FixPtConstant_Value_g
                                     * Referenced by: '<S301>/FixPt Constant'
                                     */
  uint32_T Output_InitialCondition_i;
                                /* Computed Parameter: Output_InitialCondition_i
                                 * Referenced by: '<S296>/Output'
                                 */
  uint32_T Constant_Value_li;          /* Computed Parameter: Constant_Value_li
                                        * Referenced by: '<S302>/Constant'
                                        */
  uint32_T Output_InitialCondition_d;
                                /* Computed Parameter: Output_InitialCondition_d
                                 * Referenced by: '<S275>/Output'
                                 */
  uint32_T Output_InitialCondition_p;
                                /* Computed Parameter: Output_InitialCondition_p
                                 * Referenced by: '<S80>/Output'
                                 */
  uint32_T TmpRTBAtDatawriteInport4_InitialCondition;
                /* Computed Parameter: TmpRTBAtDatawriteInport4_InitialCondition
                 * Referenced by: synthesized block
                 */
  uint32_T TmpRTBAtDatawriteInport5_InitialCondition;
                /* Computed Parameter: TmpRTBAtDatawriteInport5_InitialCondition
                 * Referenced by: synthesized block
                 */
  uint32_T FixPtConstant_Value_j;   /* Computed Parameter: FixPtConstant_Value_j
                                     * Referenced by: '<S236>/FixPt Constant'
                                     */
  uint32_T Constant_Value_mv;          /* Computed Parameter: Constant_Value_mv
                                        * Referenced by: '<S237>/Constant'
                                        */
  uint32_T FixPtConstant_Value_a;   /* Computed Parameter: FixPtConstant_Value_a
                                     * Referenced by: '<S280>/FixPt Constant'
                                     */
  uint32_T Constant_Value_i;           /* Computed Parameter: Constant_Value_i
                                        * Referenced by: '<S281>/Constant'
                                        */
  uint32_T ECATDigitalin_InitialValue[8];
                               /* Computed Parameter: ECATDigitalin_InitialValue
                                * Referenced by: '<S30>/ECAT Digital in'
                                */
  uint32_T ServoUpdate_InitialValue;
                                 /* Computed Parameter: ServoUpdate_InitialValue
                                  * Referenced by: '<S30>/ServoUpdate'
                                  */
  uint32_T Systemstatus_InitialValue[7];
                                /* Computed Parameter: Systemstatus_InitialValue
                                 * Referenced by: '<S30>/System status'
                                 */
  uint32_T calibbutton_InitialValue;
                                 /* Computed Parameter: calibbutton_InitialValue
                                  * Referenced by: '<S30>/calib button'
                                  */
  uint32_T Output_InitialCondition_a;
                                /* Computed Parameter: Output_InitialCondition_a
                                 * Referenced by: '<S350>/Output'
                                 */
  uint32_T FixPtConstant_Value_k;   /* Computed Parameter: FixPtConstant_Value_k
                                     * Referenced by: '<S352>/FixPt Constant'
                                     */
  uint32_T Constant_Value_px;          /* Computed Parameter: Constant_Value_px
                                        * Referenced by: '<S353>/Constant'
                                        */
  uint32_T ECATDigDiagnostic_InitialValue[4];
                           /* Computed Parameter: ECATDigDiagnostic_InitialValue
                            * Referenced by: '<S1>/ECAT Dig Diagnostic'
                            */
  uint32_T FixPtConstant_Value_gy; /* Computed Parameter: FixPtConstant_Value_gy
                                    * Referenced by: '<S48>/FixPt Constant'
                                    */
  uint32_T Output_InitialCondition_k;
                                /* Computed Parameter: Output_InitialCondition_k
                                 * Referenced by: '<S46>/Output'
                                 */
  uint32_T Constant_Value_n;           /* Computed Parameter: Constant_Value_n
                                        * Referenced by: '<S49>/Constant'
                                        */
  uint16_T Constant_Value_f;           /* Computed Parameter: Constant_Value_f
                                        * Referenced by: '<S109>/Constant'
                                        */
  uint16_T Constant_Value_cg;          /* Computed Parameter: Constant_Value_cg
                                        * Referenced by: '<S129>/Constant'
                                        */
  uint16_T Constant_Value_cq;          /* Computed Parameter: Constant_Value_cq
                                        * Referenced by: '<S184>/Constant'
                                        */
  uint16_T Constant_Value_cc;          /* Computed Parameter: Constant_Value_cc
                                        * Referenced by: '<S204>/Constant'
                                        */
  uint16_T Constant2_Value_i;          /* Computed Parameter: Constant2_Value_i
                                        * Referenced by: '<S257>/Constant2'
                                        */
  uint16_T Constant3_Value;            /* Computed Parameter: Constant3_Value
                                        * Referenced by: '<S257>/Constant3'
                                        */
  uint16_T Constant_Value_l5;          /* Computed Parameter: Constant_Value_l5
                                        * Referenced by: '<S257>/Constant'
                                        */
  uint16_T Constant2_Value_a;          /* Computed Parameter: Constant2_Value_a
                                        * Referenced by: '<S259>/Constant2'
                                        */
  uint16_T Constant3_Value_k;          /* Computed Parameter: Constant3_Value_k
                                        * Referenced by: '<S259>/Constant3'
                                        */
  uint16_T Constant_Value_g;           /* Computed Parameter: Constant_Value_g
                                        * Referenced by: '<S259>/Constant'
                                        */
  uint16_T Output_InitialCondition_o;
                                /* Computed Parameter: Output_InitialCondition_o
                                 * Referenced by: '<S268>/Output'
                                 */
  uint16_T FixPtConstant_Value_n;   /* Computed Parameter: FixPtConstant_Value_n
                                     * Referenced by: '<S272>/FixPt Constant'
                                     */
  uint16_T Constant_Value_pq;          /* Computed Parameter: Constant_Value_pq
                                        * Referenced by: '<S273>/Constant'
                                        */
  boolean_T RateTransition1_InitialCondition_l;
                       /* Computed Parameter: RateTransition1_InitialCondition_l
                        * Referenced by: '<S54>/Rate Transition1'
                        */
  boolean_T Delay_InitialCondition_g;
                                 /* Computed Parameter: Delay_InitialCondition_g
                                  * Referenced by: '<S336>/Delay'
                                  */
  boolean_T Memory1_InitialCondition_k;
                               /* Computed Parameter: Memory1_InitialCondition_k
                                * Referenced by: '<Root>/Memory1'
                                */
  boolean_T Memory4_InitialCondition;
                                 /* Computed Parameter: Memory4_InitialCondition
                                  * Referenced by: '<Root>/Memory4'
                                  */
};

/* Real-time Model Data Structure */
struct tag_RTM_may23_T {
  const char_T *path;
  const char_T *modelName;
  struct SimStruct_tag * *childSfunctions;
  const char_T *errorStatus;
  SS_SimMode simMode;
  RTWLogInfo *rtwLogInfo;
  RTWExtModeInfo *extModeInfo;
  RTWSolverInfo solverInfo;
  RTWSolverInfo *solverInfoPtr;
  void *sfcnInfo;

  /*
   * NonInlinedSFcns:
   * The following substructure contains information regarding
   * non-inlined s-functions used in the model.
   */
  struct {
    RTWSfcnInfo sfcnInfo;
    time_T *taskTimePtrs[5];
    SimStruct childSFunctions[44];
    SimStruct *childSFunctionPtrs[44];
    struct _ssBlkInfo2 blkInfo2[44];
    struct _ssSFcnModelMethods2 methods2[44];
    struct _ssSFcnModelMethods3 methods3[44];
    struct _ssSFcnModelMethods4 methods4[44];
    struct _ssStatesInfo2 statesInfo2[44];
    ssPeriodicStatesInfo periodicStatesInfo[44];
    struct _ssPortInfo2 inputOutputPortInfo2[44];
    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[2];
      struct _ssInPortUnit inputPortUnits[2];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[2];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn0;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[2];
      struct _ssInPortUnit inputPortUnits[2];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[2];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn1;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[9];
      mxArray *params[9];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn2;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[9];
      mxArray *params[9];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn3;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[9];
      mxArray *params[9];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn4;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[2];
      struct _ssInPortUnit inputPortUnits[2];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[2];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn5;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[2];
      struct _ssInPortUnit inputPortUnits[2];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[2];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn6;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[8];
      struct _ssOutPortUnit outputPortUnits[8];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[8];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn7;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn8;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[8];
      struct _ssOutPortUnit outputPortUnits[8];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[8];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn9;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn10;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn11;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn12;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[8];
      struct _ssOutPortUnit outputPortUnits[8];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[8];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn13;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn14;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[8];
      struct _ssOutPortUnit outputPortUnits[8];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[8];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn15;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn16;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn17;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn18;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[2];
      struct _ssInPortUnit inputPortUnits[2];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[2];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn19;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[2];
      struct _ssInPortUnit inputPortUnits[2];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[2];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn20;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[9];
      mxArray *params[9];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn21;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[9];
      mxArray *params[9];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn22;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      real_T const *UPtrs0[2];
      struct _ssPortOutputs outputPortInfo[1];
      struct _ssOutPortUnit outputPortUnits[1];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn23;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[2];
      struct _ssInPortUnit inputPortUnits[2];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[2];
      real_T const *UPtrs0[1];
      real_T const *UPtrs1[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn24;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[3];
      struct _ssInPortUnit inputPortUnits[3];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[3];
      real_T const *UPtrs0[10];
      real_T const *UPtrs1[10];
      real_T const *UPtrs2[1];
      struct _ssPortOutputs outputPortInfo[10];
      struct _ssOutPortUnit outputPortUnits[10];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[10];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn25;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[2];
      struct _ssInPortUnit inputPortUnits[2];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[2];
      real_T const *UPtrs0[1];
      real_T const *UPtrs1[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn26;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[1];
      struct _ssOutPortUnit outputPortUnits[1];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn27;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[9];
      mxArray *params[9];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn28;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn29;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn30;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn31;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn32;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[2];
      struct _ssInPortUnit inputPortUnits[2];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[2];
      real_T const *UPtrs0[512];
      real_T const *UPtrs1[1];
      struct _ssPortOutputs outputPortInfo[18];
      struct _ssOutPortUnit outputPortUnits[18];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[18];
    } Sfcn33;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[9];
      mxArray *params[9];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn34;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn35;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn36;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn37;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[1];
      struct _ssInPortUnit inputPortUnits[1];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[1];
      uint_T attribs[7];
      mxArray *params[7];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn38;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[3];
      struct _ssInPortUnit inputPortUnits[3];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[3];
      real_T const *UPtrs0[4];
      real_T const *UPtrs1[6];
      real_T const *UPtrs2[6];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn39;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssDWorkRecord dWork[1];
      struct _ssDWorkAuxRecord dWorkAux[1];
    } Sfcn40;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[9];
      mxArray *params[9];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn41;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortOutputs outputPortInfo[2];
      struct _ssOutPortUnit outputPortUnits[2];
      struct _ssOutPortCoSimAttribute outputPortCoSimAttribute[2];
      uint_T attribs[9];
      mxArray *params[9];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn42;

    struct {
      time_T sfcnPeriod[1];
      time_T sfcnOffset[1];
      int_T sfcnTsMap[1];
      struct _ssPortInputs inputPortInfo[2];
      struct _ssInPortUnit inputPortUnits[2];
      struct _ssInPortCoSimAttribute inputPortCoSimAttribute[2];
      uint_T attribs[6];
      mxArray *params[6];
      struct _ssDWorkRecord dWork[2];
      struct _ssDWorkAuxRecord dWorkAux[2];
    } Sfcn43;
  } NonInlinedSFcns;

  void *blockIO;
  const void *constBlockIO;
  void *defaultParam;
  ZCSigState *prevZCSigState;
  real_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  void *zcSignalValues;
  void *inputs;
  void *outputs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  void *dwork;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
  } DataMapInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    uint32_T checksums[4];
    uint32_T options;
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numU;
    int_T numY;
    int_T numSampTimes;
    int_T numBlocks;
    int_T numBlockIO;
    int_T numBlockPrms;
    int_T numDwork;
    int_T numSFcnPrms;
    int_T numSFcns;
    int_T numIports;
    int_T numOports;
    int_T numNonSampZCs;
    int_T sysDirFeedThru;
    int_T rtwGenSfcn;
  } Sizes;

  /*
   * SpecialInfo:
   * The following substructure contains special information
   * related to other components that are dependent on RTW.
   */
  struct {
    const void *mappingInfo;
    void *xpcData;
  } SpecialInfo;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    time_T stepSize;
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    time_T stepSize1;
    uint32_T clockTick2;
    uint32_T clockTickH2;
    time_T stepSize2;
    uint32_T clockTick3;
    uint32_T clockTickH3;
    time_T stepSize3;
    uint32_T clockTick4;
    uint32_T clockTickH4;
    time_T stepSize4;
    struct {
      uint16_T TID[5];
    } TaskCounters;

    struct {
      boolean_T TID1_2;
      boolean_T TID1_3;
      boolean_T TID2_3;
    } RateInteraction;

    time_T tStart;
    time_T tFinal;
    time_T timeOfLastOutput;
    void *timingData;
    real_T *varNextHitTimesList;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *sampleTimes;
    time_T *offsetTimes;
    int_T *sampleTimeTaskIDPtr;
    int_T *sampleHits;
    int_T *perTaskSampleHits;
    time_T *t;
    time_T sampleTimesArray[5];
    time_T offsetTimesArray[5];
    int_T sampleTimeTaskIDArray[5];
    int_T sampleHitArray[5];
    int_T perTaskSampleHitsArray[25];
    time_T tArray[5];
  } Timing;
};

extern real_T col_x;
extern real_T col_y;
extern real_T SECONDS;
extern real_T E_NO_EVENT;
extern real_T WIDTH;
extern real_T HEIGHT;
extern real_T ROTATION;
extern real_T FORCE_MULTIPLIER;
extern real_T LOAD_ROW;
extern real_T F_BUMP;
extern real_T MASS_CIRCLE;
extern real_T MASS_RECT;
extern real_T PERT_RAMP;
extern real_T PERT_DUR;
extern real_T START_ROW;
extern real_T GOAL_ROW;
extern real_T RADIUS_LOG;
extern real_T RADIUS_VIS;
extern real_T BARRIER_ROW;
extern real_T PRESHOT_ROW;
extern real_T START_HOLD_TIME;
extern real_T SHOT_READY_TIME;
extern real_T SHOT_SET_TIME;
extern real_T GOAL_TIME;
extern real_T FIRST_FILL;
extern real_T SECOND_FILL;
extern real_T THIRD_FILL;
extern real_T PUCK_ROW;
extern real_T CURSOR_ROW;
extern real_T E_START_TARGET_ON;
extern real_T E_ENTER_START;
extern real_T E_TRIAL_START;
extern real_T E_BEGIN_PRESHOT;
extern real_T E_SHOT_READY;
extern real_T E_SHOT_GO;
extern real_T E_PUCK_IN_GOAL;
extern real_T E_HAND_IN_BARRIER;
extern real_T E_PUCK_IN_BARRIER;
extern real_T E_SUCCESS;
extern real_T E_FAILURE;
extern real_T E_TIMEOUT;
extern real_T STROKE_COLOR;
extern real_T STROKE_WIDTH;
extern real_T PUCK_DAMPING;
extern real_T E_PUCK_MISS;
extern real_T SHOT_TIME;

/* Block parameters (default storage) */
extern P_may23_T may23_P;

/* Block signals (default storage) */
extern B_may23_T may23_B;

/* Block states (default storage) */
extern DW_may23_T may23_DW;

/* External data declarations for dependent source files */
extern const KinDataStruct may23_rtZKinDataStruct;/* KinDataStruct ground */

/* Zero-crossing (trigger) state */
extern PrevZCX_may23_T may23_PrevZCX;
extern const ConstB_may23_T may23_ConstB;/* constant block i/o */

/* External function called from main */
extern time_T rt_SimUpdateDiscreteEvents(
  int_T rtmNumSampTimes, void *rtmTimingData, int_T *rtmSampleHitPtr, int_T
  *rtmPerTaskSampleHits )
  ;

/*====================*
 * External functions *
 *====================*/
extern may23_rtModel *may23(void);
extern void MdlInitializeSizes(void);
extern void MdlInitializeSampleTimes(void);
extern void MdlInitialize(void);
extern void MdlStart(void);
extern void MdlOutputs(int_T tid);
extern void MdlUpdate(int_T tid);
extern void MdlTerminate(void);

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  may23_GetCAPIStaticMap(void);

/* Real-time Model object */
extern RT_MODEL_may23_T *const may23_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'may23'
 * '<S1>'   : 'may23/DataLogging'
 * '<S2>'   : 'may23/Forces_to_Torques'
 * '<S3>'   : 'may23/GUI Control'
 * '<S4>'   : 'may23/KINARM_EP_Apply_Loads'
 * '<S5>'   : 'may23/KINARM_Exo_Apply_Loads'
 * '<S6>'   : 'may23/KINARM_HandInBarrier'
 * '<S7>'   : 'may23/KINARM_HandInTarget'
 * '<S8>'   : 'may23/Parameter Table Defn'
 * '<S9>'   : 'may23/Process_Video_CMD'
 * '<S10>'  : 'may23/PuckInBarrier'
 * '<S11>'  : 'may23/PuckInDisplay'
 * '<S12>'  : 'may23/PuckInTarget'
 * '<S13>'  : 'may23/Show_Barrier'
 * '<S14>'  : 'may23/Show_Cursor'
 * '<S15>'  : 'may23/Show_Goal'
 * '<S16>'  : 'may23/Show_Preshot_Area'
 * '<S17>'  : 'may23/Show_Puck'
 * '<S18>'  : 'may23/Show_Start'
 * '<S19>'  : 'may23/Subsystem'
 * '<S20>'  : 'may23/Trial_Control'
 * '<S21>'  : 'may23/subsystem for moving the square (updating velocity and checking collision)'
 * '<S22>'  : 'may23/DataLogging/Create Analog Inputs Subsystem'
 * '<S23>'  : 'may23/DataLogging/Create Custom Data Subsystem'
 * '<S24>'  : 'may23/DataLogging/Create Event Codes Subsystem'
 * '<S25>'  : 'may23/DataLogging/Create KINARM Data Subsystem'
 * '<S26>'  : 'may23/DataLogging/Create Task State Subsystem'
 * '<S27>'  : 'may23/DataLogging/Keep alive'
 * '<S28>'  : 'may23/DataLogging/Network Transfer Subsystem'
 * '<S29>'  : 'may23/DataLogging/Poll Force Plates'
 * '<S30>'  : 'may23/DataLogging/Poll KINARM'
 * '<S31>'  : 'may23/DataLogging/Receive_Gaze'
 * '<S32>'  : 'may23/DataLogging/Terminators for Gotos'
 * '<S33>'  : 'may23/DataLogging/apply loads'
 * '<S34>'  : 'may23/DataLogging/compare encoders'
 * '<S35>'  : 'may23/DataLogging/create_lab_info'
 * '<S36>'  : 'may23/DataLogging/gaze gotos'
 * '<S37>'  : 'may23/DataLogging/kindata gotos'
 * '<S38>'  : 'may23/DataLogging/monitor torques'
 * '<S39>'  : 'may23/DataLogging/motor gotos'
 * '<S40>'  : 'may23/DataLogging/robot gotos'
 * '<S41>'  : 'may23/DataLogging/Create Custom Data Subsystem/monitor voltage bits'
 * '<S42>'  : 'may23/DataLogging/Create KINARM Data Subsystem/bitfield'
 * '<S43>'  : 'may23/DataLogging/Create KINARM Data Subsystem/gaze_data'
 * '<S44>'  : 'may23/DataLogging/Create KINARM Data Subsystem/select KINData'
 * '<S45>'  : 'may23/DataLogging/Create KINARM Data Subsystem/select KINData/MATLAB Function'
 * '<S46>'  : 'may23/DataLogging/Create Task State Subsystem/Counter Free-Running'
 * '<S47>'  : 'may23/DataLogging/Create Task State Subsystem/If Running'
 * '<S48>'  : 'may23/DataLogging/Create Task State Subsystem/Counter Free-Running/Increment Real World'
 * '<S49>'  : 'may23/DataLogging/Create Task State Subsystem/Counter Free-Running/Wrap To Zero'
 * '<S50>'  : 'may23/DataLogging/Network Transfer Subsystem/Data Packing Subsystem'
 * '<S51>'  : 'may23/DataLogging/Network Transfer Subsystem/Send Control Machine'
 * '<S52>'  : 'may23/DataLogging/Network Transfer Subsystem/UDP Receiver'
 * '<S53>'  : 'may23/DataLogging/Network Transfer Subsystem/UDP Send Subsystem'
 * '<S54>'  : 'may23/DataLogging/Network Transfer Subsystem/force strobe'
 * '<S55>'  : 'may23/DataLogging/Network Transfer Subsystem/Data Packing Subsystem/Counter'
 * '<S56>'  : 'may23/DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Counter Free-Running'
 * '<S57>'  : 'may23/DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Counter Free-Running/Increment Real World'
 * '<S58>'  : 'may23/DataLogging/Network Transfer Subsystem/UDP Send Subsystem/Counter Free-Running/Wrap To Zero'
 * '<S59>'  : 'may23/DataLogging/Network Transfer Subsystem/force strobe/force strobe'
 * '<S60>'  : 'may23/DataLogging/Poll Force Plates/plate1'
 * '<S61>'  : 'may23/DataLogging/Poll Force Plates/plate2'
 * '<S62>'  : 'may23/DataLogging/Poll Force Plates/send poll 1'
 * '<S63>'  : 'may23/DataLogging/Poll Force Plates/send poll 2'
 * '<S64>'  : 'may23/DataLogging/Poll Force Plates/plate1/parse packet 1'
 * '<S65>'  : 'may23/DataLogging/Poll Force Plates/plate2/parse packet 1'
 * '<S66>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem'
 * '<S67>'  : 'may23/DataLogging/Poll KINARM/Force Sensor Control'
 * '<S68>'  : 'may23/DataLogging/Poll KINARM/PMAC Subsystem'
 * '<S69>'  : 'may23/DataLogging/Poll KINARM/bkin_file_source'
 * '<S70>'  : 'may23/DataLogging/Poll KINARM/bkin_internal_testing'
 * '<S71>'  : 'may23/DataLogging/Poll KINARM/constants'
 * '<S72>'  : 'may23/DataLogging/Poll KINARM/control read write'
 * '<S73>'  : 'may23/DataLogging/Poll KINARM/createKINData'
 * '<S74>'  : 'may23/DataLogging/Poll KINARM/isecat'
 * '<S75>'  : 'may23/DataLogging/Poll KINARM/make KINData bus'
 * '<S76>'  : 'may23/DataLogging/Poll KINARM/split_primary'
 * '<S77>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1'
 * '<S78>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2'
 * '<S79>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Compare'
 * '<S80>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Counter Free-Running'
 * '<S81>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output'
 * '<S82>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Init to Bus'
 * '<S83>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/latch_errors'
 * '<S84>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/sdo_addrs'
 * '<S85>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/setState'
 * '<S86>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/update'
 * '<S87>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1'
 * '<S88>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2'
 * '<S89>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode'
 * '<S90>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Find Robot type'
 * '<S91>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration'
 * '<S92>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration'
 * '<S93>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO read machine'
 * '<S94>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading'
 * '<S95>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing'
 * '<S96>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/forceEnableDisable'
 * '<S97>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem'
 * '<S98>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/size'
 * '<S99>'  : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/size1'
 * '<S100>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants'
 * '<S101>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/split out constants1'
 * '<S102>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs'
 * '<S103>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/Compare'
 * '<S104>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump'
 * '<S105>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem'
 * '<S106>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/Whistle state'
 * '<S107>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/cleanword'
 * '<S108>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/SR_clean'
 * '<S109>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/SW_clean'
 * '<S110>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/Subsystem'
 * '<S111>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/parse status register'
 * '<S112>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/Subsystem/MATLAB Function'
 * '<S113>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY'
 * '<S114>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count'
 * '<S115>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Value'
 * '<S116>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/clear errors'
 * '<S117>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/fault monitor'
 * '<S118>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/pass emcy'
 * '<S119>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/MATLAB Function'
 * '<S120>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Value/MATLAB Function'
 * '<S121>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/countsToRads'
 * '<S122>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs'
 * '<S123>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/Compare'
 * '<S124>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump'
 * '<S125>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem'
 * '<S126>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/Whistle state'
 * '<S127>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/cleanword'
 * '<S128>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/SR_clean'
 * '<S129>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/SW_clean'
 * '<S130>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/Subsystem'
 * '<S131>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/parse status register1'
 * '<S132>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/A1M2 PDOs/Subsystem/MATLAB Function'
 * '<S133>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY'
 * '<S134>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count'
 * '<S135>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Value'
 * '<S136>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/clear errors'
 * '<S137>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/fault monitor'
 * '<S138>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/pass emcy'
 * '<S139>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Count/MATLAB Function'
 * '<S140>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/EMCY Message pump/Read EMCY Value/MATLAB Function'
 * '<S141>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/countsToRads'
 * '<S142>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/Control Torque Mode/MATLAB Function1'
 * '<S143>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/AbsEncoder machine'
 * '<S144>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/set-up values'
 * '<S145>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/AbsEncoder machine'
 * '<S146>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/M2 AbsEnc Calibration/set-up values'
 * '<S147>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 1 SDO'
 * '<S148>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 2 SDO'
 * '<S149>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/SDO read machine'
 * '<S150>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/values'
 * '<S151>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/values2'
 * '<S152>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 1 SDO/MATLAB Function'
 * '<S153>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 1 SDO/converter'
 * '<S154>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 2 SDO/MATLAB Function'
 * '<S155>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO reading/Read Drive 2 SDO/converter'
 * '<S156>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/MATLAB Function'
 * '<S157>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/SDO write machine'
 * '<S158>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/SDO writing/convert'
 * '<S159>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Read Drive 1 SDO'
 * '<S160>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Read Drive 1 SDO/MATLAB Function'
 * '<S161>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 1/int subsystem/Read Drive 1 SDO/converter'
 * '<S162>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1'
 * '<S163>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2'
 * '<S164>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/Find Robot type'
 * '<S165>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration'
 * '<S166>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration'
 * '<S167>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO read machine'
 * '<S168>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading'
 * '<S169>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing'
 * '<S170>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode'
 * '<S171>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/forceEnableDisable'
 * '<S172>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem'
 * '<S173>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/size'
 * '<S174>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/size1'
 * '<S175>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants'
 * '<S176>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/split out constants1'
 * '<S177>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs'
 * '<S178>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/Compare'
 * '<S179>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump'
 * '<S180>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem'
 * '<S181>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/Whistle state'
 * '<S182>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/cleanword'
 * '<S183>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/SR_clean'
 * '<S184>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/SW_clean'
 * '<S185>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/Subsystem'
 * '<S186>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/parse status register1'
 * '<S187>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/A2M1 PDOs/Subsystem/MATLAB Function'
 * '<S188>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY'
 * '<S189>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count'
 * '<S190>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Value'
 * '<S191>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/clear errors'
 * '<S192>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/fault monitor'
 * '<S193>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/pass emcy'
 * '<S194>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Count/MATLAB Function'
 * '<S195>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/EMCY Message pump/Read EMCY Value/MATLAB Function'
 * '<S196>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/countsToRads'
 * '<S197>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs'
 * '<S198>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/Compare'
 * '<S199>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump'
 * '<S200>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem'
 * '<S201>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/Whistle state'
 * '<S202>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/cleanword'
 * '<S203>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/SR_clean'
 * '<S204>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/SW_clean'
 * '<S205>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/Subsystem'
 * '<S206>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/parse status register1'
 * '<S207>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/A2M2 PDOs/Subsystem/MATLAB Function'
 * '<S208>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY'
 * '<S209>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count'
 * '<S210>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Value'
 * '<S211>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/clear errors'
 * '<S212>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/fault monitor'
 * '<S213>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/pass emcy'
 * '<S214>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Count/MATLAB Function'
 * '<S215>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/EMCY Message pump/Read EMCY Value/MATLAB Function'
 * '<S216>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/countsToRads'
 * '<S217>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/AbsEncoder machine'
 * '<S218>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M1 AbsEnc Calibration/set-up values'
 * '<S219>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/AbsEncoder machine'
 * '<S220>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/M2 AbsEnc Calibration/set-up values'
 * '<S221>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 3 SDO'
 * '<S222>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 4 SDO'
 * '<S223>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/SDO read machine'
 * '<S224>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/values'
 * '<S225>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/values2'
 * '<S226>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 3 SDO/MATLAB Function'
 * '<S227>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 3 SDO/converter'
 * '<S228>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO reading/Read Drive 4 SDO/converter'
 * '<S229>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/MATLAB Function'
 * '<S230>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/SDO write machine'
 * '<S231>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/SDO writing/convert'
 * '<S232>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/control torque mode/MATLAB Function1'
 * '<S233>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Read Drive 3 SDO'
 * '<S234>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Read Drive 3 SDO/MATLAB Function'
 * '<S235>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Arm 2/int subsystem/Read Drive 3 SDO/converter'
 * '<S236>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Counter Free-Running/Increment Real World'
 * '<S237>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Counter Free-Running/Wrap To Zero'
 * '<S238>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Digital output/update digital outputs'
 * '<S239>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Init to Bus/master_state'
 * '<S240>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/Init to Bus/split init'
 * '<S241>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/update/MATLAB Function'
 * '<S242>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/update/convert to bit field'
 * '<S243>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/update/create filtered velocities'
 * '<S244>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/update/create kinematics'
 * '<S245>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/update/create servo counter'
 * '<S246>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/update/create servo counter1'
 * '<S247>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/update/robottype1'
 * '<S248>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/update/update HW settings'
 * '<S249>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/update/update calibrations'
 * '<S250>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/update/create filtered velocities/filter_velocities'
 * '<S251>' : 'may23/DataLogging/Poll KINARM/EtherCAT Subsystem/update/create filtered velocities/rebuild'
 * '<S252>' : 'may23/DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem'
 * '<S253>' : 'may23/DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem'
 * '<S254>' : 'may23/DataLogging/Poll KINARM/Force Sensor Control/MATLAB Function'
 * '<S255>' : 'may23/DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Create timestamp'
 * '<S256>' : 'may23/DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/Detect Change'
 * '<S257>' : 'may23/DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 1 Subsystem/If Action Subsystem'
 * '<S258>' : 'may23/DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Create timestamp'
 * '<S259>' : 'may23/DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Data Transfer Start Subsystem'
 * '<S260>' : 'may23/DataLogging/Poll KINARM/Force Sensor Control/Force Sensor 2 Subsystem/Detect Change'
 * '<S261>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/ispmac'
 * '<S262>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac'
 * '<S263>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/update settings'
 * '<S264>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem'
 * '<S265>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Monitor_status'
 * '<S266>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Robot_data_builder'
 * '<S267>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/filter_velocities'
 * '<S268>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Counter Free-Running'
 * '<S269>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Read DPRAM'
 * '<S270>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/TypeCast'
 * '<S271>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Write DPRAM'
 * '<S272>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Counter Free-Running/Increment Real World'
 * '<S273>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/Counter Free-Running/Wrap To Zero'
 * '<S274>' : 'may23/DataLogging/Poll KINARM/PMAC Subsystem/update settings/update status format'
 * '<S275>' : 'may23/DataLogging/Poll KINARM/bkin_file_source/Counter Free-Running'
 * '<S276>' : 'may23/DataLogging/Poll KINARM/bkin_file_source/Data receive'
 * '<S277>' : 'may23/DataLogging/Poll KINARM/bkin_file_source/Data write'
 * '<S278>' : 'may23/DataLogging/Poll KINARM/bkin_file_source/is_running'
 * '<S279>' : 'may23/DataLogging/Poll KINARM/bkin_file_source/ispmac1'
 * '<S280>' : 'may23/DataLogging/Poll KINARM/bkin_file_source/Counter Free-Running/Increment Real World'
 * '<S281>' : 'may23/DataLogging/Poll KINARM/bkin_file_source/Counter Free-Running/Wrap To Zero'
 * '<S282>' : 'may23/DataLogging/Poll KINARM/bkin_file_source/Data receive/MATLAB Function'
 * '<S283>' : 'may23/DataLogging/Poll KINARM/bkin_internal_testing/Data receive'
 * '<S284>' : 'may23/DataLogging/Poll KINARM/bkin_internal_testing/Data write'
 * '<S285>' : 'may23/DataLogging/Poll KINARM/bkin_internal_testing/ispmac1'
 * '<S286>' : 'may23/DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Counter Free-Running'
 * '<S287>' : 'may23/DataLogging/Poll KINARM/bkin_internal_testing/Data receive/MATLAB Function'
 * '<S288>' : 'may23/DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Counter Free-Running/Increment Real World'
 * '<S289>' : 'may23/DataLogging/Poll KINARM/bkin_internal_testing/Data receive/Counter Free-Running/Wrap To Zero'
 * '<S290>' : 'may23/DataLogging/Poll KINARM/constants/arm1'
 * '<S291>' : 'may23/DataLogging/Poll KINARM/constants/arm2'
 * '<S292>' : 'may23/DataLogging/Poll KINARM/constants/update constants subsystem'
 * '<S293>' : 'may23/DataLogging/Poll KINARM/constants/arm1/decode robot'
 * '<S294>' : 'may23/DataLogging/Poll KINARM/constants/arm2/decode robot'
 * '<S295>' : 'may23/DataLogging/Poll KINARM/createKINData/Calibration_check'
 * '<S296>' : 'may23/DataLogging/Poll KINARM/createKINData/Counter Free-Running'
 * '<S297>' : 'may23/DataLogging/Poll KINARM/createKINData/Create KINARM Data Array'
 * '<S298>' : 'may23/DataLogging/Poll KINARM/createKINData/bitpack'
 * '<S299>' : 'may23/DataLogging/Poll KINARM/createKINData/hand feedback'
 * '<S300>' : 'may23/DataLogging/Poll KINARM/createKINData/record errors'
 * '<S301>' : 'may23/DataLogging/Poll KINARM/createKINData/Counter Free-Running/Increment Real World'
 * '<S302>' : 'may23/DataLogging/Poll KINARM/createKINData/Counter Free-Running/Wrap To Zero'
 * '<S303>' : 'may23/DataLogging/Poll KINARM/make KINData bus/splitKINData arm1'
 * '<S304>' : 'may23/DataLogging/Poll KINARM/make KINData bus/splitKINData arm2'
 * '<S305>' : 'may23/DataLogging/Poll KINARM/make KINData bus/splitKINDataGeneral'
 * '<S306>' : 'may23/DataLogging/Poll KINARM/split_primary/split_primary'
 * '<S307>' : 'may23/DataLogging/Poll KINARM/split_primary/split_primary1'
 * '<S308>' : 'may23/DataLogging/Receive_Gaze/Create timestamp'
 * '<S309>' : 'may23/DataLogging/Receive_Gaze/Embedded MATLAB Function1'
 * '<S310>' : 'may23/DataLogging/Receive_Gaze/clean_packet'
 * '<S311>' : 'may23/DataLogging/Receive_Gaze/convert to seconds2'
 * '<S312>' : 'may23/DataLogging/apply loads/EtherCAT Apply Loads'
 * '<S313>' : 'may23/DataLogging/apply loads/apply pmac loads'
 * '<S314>' : 'may23/DataLogging/apply loads/isecat'
 * '<S315>' : 'may23/DataLogging/apply loads/isecat1'
 * '<S316>' : 'may23/DataLogging/apply loads/verify NaN'
 * '<S317>' : 'may23/DataLogging/apply loads/EtherCAT Apply Loads/A1 Apply torques'
 * '<S318>' : 'may23/DataLogging/apply loads/EtherCAT Apply Loads/A2 Apply torques'
 * '<S319>' : 'may23/DataLogging/apply loads/EtherCAT Apply Loads/convert torques'
 * '<S320>' : 'may23/DataLogging/compare encoders/delta'
 * '<S321>' : 'may23/DataLogging/create_lab_info/Subsystem'
 * '<S322>' : 'may23/DataLogging/create_lab_info/Subsystem/MATLAB Function'
 * '<S323>' : 'may23/DataLogging/create_lab_info/Subsystem/MATLAB Function1'
 * '<S324>' : 'may23/DataLogging/monitor torques/Compare To Constant'
 * '<S325>' : 'may23/DataLogging/monitor torques/MATLAB Function'
 * '<S326>' : 'may23/DataLogging/monitor torques/current_limits'
 * '<S327>' : 'may23/DataLogging/monitor torques/delay'
 * '<S328>' : 'may23/DataLogging/monitor torques/filter'
 * '<S329>' : 'may23/DataLogging/monitor torques/monitor_enc_delta'
 * '<S330>' : 'may23/DataLogging/monitor torques/torque_monitor'
 * '<S331>' : 'may23/DataLogging/monitor torques/delay/filter'
 * '<S332>' : 'may23/DataLogging/monitor torques/monitor_enc_delta/monitor_encoders'
 * '<S333>' : 'may23/Forces_to_Torques/Forces_to_Torques'
 * '<S334>' : 'may23/GUI Control/Preview Targets Subsystem'
 * '<S335>' : 'may23/GUI Control/Run Command Subsystem'
 * '<S336>' : 'may23/GUI Control/Task Execution Control Subsystem'
 * '<S337>' : 'may23/GUI Control/Task_progress'
 * '<S338>' : 'may23/GUI Control/Unused Gotos Subsystem'
 * '<S339>' : 'may23/GUI Control/exit_trial_goto'
 * '<S340>' : 'may23/GUI Control/tables'
 * '<S341>' : 'may23/GUI Control/Run Command Subsystem/Embedded MATLAB Function'
 * '<S342>' : 'may23/GUI Control/Run Command Subsystem/Hold_to_1Khz'
 * '<S343>' : 'may23/GUI Control/Task Execution Control Subsystem/Compare To Constant'
 * '<S344>' : 'may23/GUI Control/Task Execution Control Subsystem/MATLAB Function'
 * '<S345>' : 'may23/GUI Control/Task Execution Control Subsystem/Task Execution Control Machine'
 * '<S346>' : 'may23/GUI Control/Task_progress/MATLAB Function'
 * '<S347>' : 'may23/GUI Control/exit_trial_goto/Detect Change'
 * '<S348>' : 'may23/GUI Control/exit_trial_goto/Detect Change1'
 * '<S349>' : 'may23/GUI Control/tables/Compare To Constant'
 * '<S350>' : 'may23/GUI Control/tables/Counter Free-Running'
 * '<S351>' : 'may23/GUI Control/tables/enable_tables'
 * '<S352>' : 'may23/GUI Control/tables/Counter Free-Running/Increment Real World'
 * '<S353>' : 'may23/GUI Control/tables/Counter Free-Running/Wrap To Zero'
 * '<S354>' : 'may23/KINARM_EP_Apply_Loads/Force_Cap'
 * '<S355>' : 'may23/KINARM_EP_Apply_Loads/Forces_to_Torques'
 * '<S356>' : 'may23/KINARM_EP_Apply_Loads/Ramp_Up_Down'
 * '<S357>' : 'may23/KINARM_EP_Apply_Loads/Ramp_Up_Down1'
 * '<S358>' : 'may23/KINARM_EP_Apply_Loads/Remove_NaNs_and_Inf'
 * '<S359>' : 'may23/KINARM_EP_Apply_Loads/Remove_NaNs_and_Inf1'
 * '<S360>' : 'may23/KINARM_EP_Apply_Loads/detect motor state'
 * '<S361>' : 'may23/KINARM_EP_Apply_Loads/detect motor state1'
 * '<S362>' : 'may23/KINARM_EP_Apply_Loads/detect motor state/MATLAB Function'
 * '<S363>' : 'may23/KINARM_EP_Apply_Loads/detect motor state1/MATLAB Function'
 * '<S364>' : 'may23/KINARM_Exo_Apply_Loads/Ramp_Up_Down'
 * '<S365>' : 'may23/KINARM_Exo_Apply_Loads/Ramp_Up_Down1'
 * '<S366>' : 'may23/KINARM_Exo_Apply_Loads/Remove_NaNs_and_Inf'
 * '<S367>' : 'may23/KINARM_Exo_Apply_Loads/Remove_NaNs_and_Inf1'
 * '<S368>' : 'may23/KINARM_Exo_Apply_Loads/Torque_Cap'
 * '<S369>' : 'may23/KINARM_Exo_Apply_Loads/clip motor torques'
 * '<S370>' : 'may23/KINARM_Exo_Apply_Loads/clip motor torques/clip_motor_torque'
 * '<S371>' : 'may23/KINARM_HandInBarrier/Embedded MATLAB InsideTarget'
 * '<S372>' : 'may23/KINARM_HandInBarrier/kin data split'
 * '<S373>' : 'may23/KINARM_HandInTarget/Embedded MATLAB InsideTarget'
 * '<S374>' : 'may23/KINARM_HandInTarget/kin data split'
 * '<S375>' : 'may23/Parameter Table Defn/TP_table'
 * '<S376>' : 'may23/Parameter Table Defn/events'
 * '<S377>' : 'may23/Parameter Table Defn/load_table'
 * '<S378>' : 'may23/Parameter Table Defn/target_table'
 * '<S379>' : 'may23/Parameter Table Defn/task_definition'
 * '<S380>' : 'may23/Parameter Table Defn/task_wide'
 * '<S381>' : 'may23/Process_Video_CMD/Add_requested_Delay'
 * '<S382>' : 'may23/Process_Video_CMD/MATLAB Function'
 * '<S383>' : 'may23/Process_Video_CMD/PVC_core'
 * '<S384>' : 'may23/Process_Video_CMD/Add_requested_Delay/MATLAB Function'
 * '<S385>' : 'may23/Process_Video_CMD/PVC_core/Pack VCodeFrame2'
 * '<S386>' : 'may23/PuckInBarrier/Embedded MATLAB InsideTarget'
 * '<S387>' : 'may23/PuckInDisplay/MATLAB Function'
 * '<S388>' : 'may23/PuckInTarget/Embedded MATLAB InsideTarget'
 * '<S389>' : 'may23/Show_Barrier/Embedded MATLAB Function'
 * '<S390>' : 'may23/Show_Cursor/Embedded MATLAB Function'
 * '<S391>' : 'may23/Show_Goal/Embedded MATLAB Function'
 * '<S392>' : 'may23/Show_Preshot_Area/Embedded MATLAB Function'
 * '<S393>' : 'may23/Show_Puck/Embedded MATLAB Function'
 * '<S394>' : 'may23/Show_Start/Embedded MATLAB Function'
 * '<S395>' : 'may23/Subsystem/Compare To Zero1'
 * '<S396>' : 'may23/Subsystem/Perturbation'
 * '<S397>' : 'may23/Subsystem/Scope 1'
 * '<S398>' : 'may23/Subsystem/Perturbation/Ramp_up_down'
 * '<S399>' : 'may23/Subsystem/Perturbation/Select Perturbation Times'
 * '<S400>' : 'may23/subsystem for moving the square (updating velocity and checking collision)/Collision Resolution'
 * '<S401>' : 'may23/subsystem for moving the square (updating velocity and checking collision)/Get Hand Speed'
 * '<S402>' : 'may23/subsystem for moving the square (updating velocity and checking collision)/Hand Feedback'
 * '<S403>' : 'may23/subsystem for moving the square (updating velocity and checking collision)/MATLAB Function'
 * '<S404>' : 'may23/subsystem for moving the square (updating velocity and checking collision)/Get Hand Speed/MATLAB Function'
 * '<S405>' : 'may23/subsystem for moving the square (updating velocity and checking collision)/Hand Feedback/Hand_Feedback'
 * '<S406>' : 'may23/subsystem for moving the square (updating velocity and checking collision)/Hand Feedback/MATLAB Function'
 * '<S407>' : 'may23/subsystem for moving the square (updating velocity and checking collision)/Hand Feedback/Hand_Feedback/FeedFwdArm'
 */
#endif                                 /* RTW_HEADER_may23_h_ */
