/*
 * Code generation for system system '<S30>/createKINData'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_createKINData.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/* Named constants for Chart: '<S73>/Calibration_check' */
#define may23_CALL_EVENT_ig            (-1)
#define may23_IN_Calibrated            ((uint8_T)1U)
#define may23_IN_Done_d                ((uint8_T)2U)
#define may23_IN_Init_j                ((uint8_T)3U)
#define may23_IN_Monitor               ((uint8_T)1U)
#define may23_IN_NO_ACTIVE_CHILD_a     ((uint8_T)0U)
#define may23_IN_Short_wait            ((uint8_T)4U)
#define may23_IN_WaitForOp             ((uint8_T)5U)

/* Forward declaration for local functions */
static void may23_correct_elbow_angle(real_T elbow_angle, real_T elbow_vel,
  real_T elbow_acc, real_T theta2_5, real_T L1, real_T L5, real_T L3_error,
  real_T *angle_corr, real_T *vel_corr, real_T *acc_corr);
static void may23_apply_offsets(real_T idx, real_T L1_angle, real_T L2_angle,
  real_T is_calibrated, boolean_T isEP, real_T robot_orientation, real_T
  *L1_ang_out, real_T *L2_ang_out);
static void may23_create_robot_row(real_T idx, const real_T calibration[8],
  const real_T hardware_settings[12], const real_T force_sensor_data[7], const
  real_T robot_data[10], const real_T torque_command[2], real_T is_calibrated,
  real_T robot_row[50]);

/* Function for MATLAB Function: '<S73>/Create KINARM Data Array' */
static void may23_correct_elbow_angle(real_T elbow_angle, real_T elbow_vel,
  real_T elbow_acc, real_T theta2_5, real_T L1, real_T L5, real_T L3_error,
  real_T *angle_corr, real_T *vel_corr, real_T *acc_corr)
{
  real_T L3;
  real_T theta1_3;
  real_T a;
  real_T b;
  real_T dbdt;
  real_T dcdt;
  real_T d2bdt2;
  real_T d2cdt2;
  real_T sqroot;

  /* '<S297>:1:420' */
  L3 = L5 + L3_error;

  /* '<S297>:1:422' */
  theta1_3 = theta2_5 - elbow_angle;

  /* '<S297>:1:423' */
  /* '<S297>:1:424' */
  /* '<S297>:1:429' */
  /* '<S297>:1:430' */
  theta1_3 -= floor((theta1_3 + 3.1415926535897931) / 6.2831853071795862) * 2.0 *
    3.1415926535897931;

  /* '<S297>:1:433' */
  a = 4.0 * L3 * L5 - 4.0 * L1 * L5 * cos(theta1_3);

  /* '<S297>:1:434' */
  b = -4.0 * L1 * L5 * sin(theta1_3);

  /* '<S297>:1:435' */
  /* '<S297>:1:437' */
  dbdt = -4.0 * L1 * L5 * cos(theta1_3) * -elbow_vel;

  /* '<S297>:1:438' */
  dcdt = 2.0 * L1 * L3_error * sin(theta1_3) * -elbow_vel;

  /* '<S297>:1:440' */
  d2bdt2 = 4.0 * L1 * L5 * sin(theta1_3) * (-elbow_vel * -elbow_vel) - 4.0 * L1 *
    L5 * cos(theta1_3) * -elbow_acc;

  /* '<S297>:1:441' */
  d2cdt2 = 2.0 * L1 * L3_error * cos(theta1_3) * (-elbow_vel * -elbow_vel) + 2.0
    * L1 * L3_error * sin(theta1_3) * -elbow_acc;

  /* '<S297>:1:443' */
  sqroot = sqrt(b * b - (((L3 * L3 + L5 * L5) - 2.0 * L3 * L5) - 2.0 * L1 *
    L3_error * cos(theta1_3)) * (4.0 * a));
  if (sqroot > 0.0) {
    /* '<S297>:1:445' */
    if (b > 0.0) {
      /* '<S297>:1:446' */
      /* '<S297>:1:447' */
      L3 = (-b + sqroot) / (2.0 * a);

      /* '<S297>:1:448' */
      theta1_3 = ((2.0 * b * dbdt - 4.0 * a * dcdt) * (0.5 / sqroot) + -dbdt) /
        (2.0 * a);

      /* '<S297>:1:449' */
      dcdt = 2.0 * b * dbdt - 4.0 * a * dcdt;
      a = (((dbdt * dbdt * 2.0 + 2.0 * b * d2bdt2) - 4.0 * a * d2cdt2) * (0.5 /
            sqroot) + (-d2bdt2 - 0.25 / rt_powd_snf(sqroot, 3.0) * (dcdt * dcdt)))
        / (2.0 * a);
    } else {
      /* '<S297>:1:451' */
      L3 = (-b - sqroot) / (2.0 * a);

      /* '<S297>:1:452' */
      theta1_3 = (-dbdt - (2.0 * b * dbdt - 4.0 * a * dcdt) * (0.5 / sqroot)) /
        (2.0 * a);

      /* '<S297>:1:453' */
      dcdt = 2.0 * b * dbdt - 4.0 * a * dcdt;
      a = ((0.25 / rt_powd_snf(sqroot, 3.0) * (dcdt * dcdt) + -d2bdt2) - ((dbdt *
             dbdt * 2.0 + 2.0 * b * d2bdt2) - 4.0 * a * d2cdt2) * (0.5 / sqroot))
        / (2.0 * a);
    }
  } else {
    /* '<S297>:1:456' */
    L3 = -b / (2.0 * a);

    /* '<S297>:1:457' */
    theta1_3 = -dbdt / (2.0 * a);

    /* '<S297>:1:458' */
    a = -d2bdt2 / (2.0 * a);
  }

  if (L3 > 1.0) {
    /* '<S297>:1:461' */
    /* '<S297>:1:462' */
    L3 = 1.0;
  } else {
    if (L3 < -1.0) {
      /* '<S297>:1:463' */
      /* '<S297>:1:464' */
      L3 = -1.0;
    }
  }

  /* '<S297>:1:467' */
  /* '<S297>:1:469' */
  /* '<S297>:1:470' */
  /* '<S297>:1:471' */
  /* '<S297>:1:473' */
  *angle_corr = -(2.0 * asin(L3));

  /* '<S297>:1:474' */
  *vel_corr = -(2.0 / sqrt(1.0 - L3 * L3) * theta1_3);

  /* '<S297>:1:475' */
  *acc_corr = -(2.0 / rt_powd_snf(1.0 - L3 * L3, 1.5) * L3 * (theta1_3 *
    theta1_3) + 2.0 / sqrt(1.0 - L3 * L3) * a);
}

/* Function for MATLAB Function: '<S73>/Create KINARM Data Array' */
static void may23_apply_offsets(real_T idx, real_T L1_angle, real_T L2_angle,
  real_T is_calibrated, boolean_T isEP, real_T robot_orientation, real_T
  *L1_ang_out, real_T *L2_ang_out)
{
  real_T b_L2_angle;
  real_T L1_angle_b;

  /* '<S297>:1:541' */
  *L1_ang_out = L1_angle;

  /* '<S297>:1:542' */
  *L2_ang_out = L2_angle;
  if ((is_calibrated == 1.0) && (may23_DW.was_calibrated[(int32_T)idx - 1] ==
       0.0)) {
    /* '<S297>:1:544' */
    /* '<S297>:1:545' */
    may23_DW.was_calibrated[(int32_T)idx - 1] = 1.0;

    /* '<S297>:1:547' */
    b_L2_angle = L2_angle;
    if (isEP) {
      /* '<S297>:1:502' */
      /* '<S297>:1:503' */
      /* '<S297>:1:504' */
      L1_angle_b = L1_angle;
      if ((!rtIsInf(L1_angle)) && (!rtIsNaN(L1_angle))) {
        while (L1_angle_b < -4.71238898038469) {
          /* '<S297>:1:483' */
          /* '<S297>:1:484' */
          L1_angle_b += 6.2831853071795862;
        }

        while (L1_angle_b > 1.5707963267948966) {
          /* '<S297>:1:486' */
          /* '<S297>:1:487' */
          L1_angle_b -= 6.2831853071795862;
        }
      } else {
        /* '<S297>:1:479' */
      }

      /* '<S297>:1:505' */
      if (robot_orientation == -1.0) {
        /* '<S297>:1:506' */
        /* '<S297>:1:508' */
        if ((!rtIsInf(L2_angle)) && (!rtIsNaN(L2_angle))) {
          while (b_L2_angle < L1_angle_b - 6.2831853071795862) {
            /* '<S297>:1:483' */
            /* '<S297>:1:484' */
            b_L2_angle += 6.2831853071795862;
          }

          while (b_L2_angle > L1_angle_b) {
            /* '<S297>:1:486' */
            /* '<S297>:1:487' */
            b_L2_angle -= 6.2831853071795862;
          }

          if ((b_L2_angle < 0.0) && (b_L2_angle + 6.2831853071795862 <
               L1_angle_b)) {
            /* '<S297>:1:491' */
            /* '<S297>:1:492' */
            b_L2_angle += 6.2831853071795862;
          }
        } else {
          /* '<S297>:1:479' */
        }
      } else {
        /* '<S297>:1:511' */
        if ((!rtIsInf(L2_angle)) && (!rtIsNaN(L2_angle))) {
          while (b_L2_angle < L1_angle_b) {
            /* '<S297>:1:483' */
            /* '<S297>:1:484' */
            b_L2_angle += 6.2831853071795862;
          }

          while (b_L2_angle > L1_angle_b + 6.2831853071795862) {
            /* '<S297>:1:486' */
            /* '<S297>:1:487' */
            b_L2_angle -= 6.2831853071795862;
          }

          if ((b_L2_angle < 0.0) && (b_L2_angle + 6.2831853071795862 <
               L1_angle_b + 6.2831853071795862)) {
            /* '<S297>:1:491' */
            /* '<S297>:1:492' */
            b_L2_angle += 6.2831853071795862;
          }
        } else {
          /* '<S297>:1:479' */
        }
      }
    } else {
      /* '<S297>:1:514' */
      /* '<S297>:1:515' */
      L1_angle_b = L1_angle;
      if ((!rtIsInf(L1_angle)) && (!rtIsNaN(L1_angle))) {
        while (L1_angle_b < -1.5707963267948966) {
          /* '<S297>:1:483' */
          /* '<S297>:1:484' */
          L1_angle_b += 6.2831853071795862;
        }

        while (L1_angle_b > 4.71238898038469) {
          /* '<S297>:1:486' */
          /* '<S297>:1:487' */
          L1_angle_b -= 6.2831853071795862;
        }
      } else {
        /* '<S297>:1:479' */
      }

      /* '<S297>:1:516' */
      if (robot_orientation == 1.0) {
        /* '<S297>:1:517' */
        /* '<S297>:1:519' */
        if ((!rtIsInf(L2_angle)) && (!rtIsNaN(L2_angle))) {
          while (b_L2_angle < L1_angle_b) {
            /* '<S297>:1:483' */
            /* '<S297>:1:484' */
            b_L2_angle += 6.2831853071795862;
          }

          while (b_L2_angle > L1_angle_b + 6.2831853071795862) {
            /* '<S297>:1:486' */
            /* '<S297>:1:487' */
            b_L2_angle -= 6.2831853071795862;
          }

          if ((b_L2_angle < 0.0) && (b_L2_angle + 6.2831853071795862 <
               L1_angle_b + 6.2831853071795862)) {
            /* '<S297>:1:491' */
            /* '<S297>:1:492' */
            b_L2_angle += 6.2831853071795862;
          }
        } else {
          /* '<S297>:1:479' */
        }
      } else {
        /* '<S297>:1:522' */
        if ((!rtIsInf(L2_angle)) && (!rtIsNaN(L2_angle))) {
          while (b_L2_angle < L1_angle_b - 6.2831853071795862) {
            /* '<S297>:1:483' */
            /* '<S297>:1:484' */
            b_L2_angle += 6.2831853071795862;
          }

          while (b_L2_angle > L1_angle_b) {
            /* '<S297>:1:486' */
            /* '<S297>:1:487' */
            b_L2_angle -= 6.2831853071795862;
          }

          if ((b_L2_angle < 0.0) && (b_L2_angle + 6.2831853071795862 <
               L1_angle_b)) {
            /* '<S297>:1:491' */
            /* '<S297>:1:492' */
            b_L2_angle += 6.2831853071795862;
          }
        } else {
          /* '<S297>:1:479' */
        }
      }
    }

    /* '<S297>:1:527' */
    /* '<S297>:1:528' */
    /* '<S297>:1:548' */
    may23_DW.stored_offsets[(int32_T)idx - 1] = L1_angle - L1_angle_b;

    /* '<S297>:1:549' */
    may23_DW.stored_offsets[(int32_T)idx + 3] = L2_angle - b_L2_angle;
  }

  if (may23_DW.was_calibrated[(int32_T)idx - 1] != 0.0) {
    /* '<S297>:1:553' */
    *L1_ang_out = L1_angle - may23_DW.stored_offsets[(int32_T)idx - 1];

    /* '<S297>:1:554' */
    *L2_ang_out = L2_angle - may23_DW.stored_offsets[(int32_T)idx + 3];
  }
}

/* Function for MATLAB Function: '<S73>/Create KINARM Data Array' */
static void may23_create_robot_row(real_T idx, const real_T calibration[8],
  const real_T hardware_settings[12], const real_T force_sensor_data[7], const
  real_T robot_data[10], const real_T torque_command[2], real_T is_calibrated,
  real_T robot_row[50])
{
  boolean_T isEP;
  real_T force_sensor_force_u;
  real_T force_sensor_force_v;
  real_T force_sensor_force_w;
  real_T force_sensor_torque_u;
  real_T force_sensor_torque_v;
  real_T force_sensor_torque_w;
  real_T elbow_velocity;
  real_T elbow_acceleration;
  real_T motor1_status;
  real_T motor2_status;
  real_T shoulder_angle;
  real_T elbow_angle;
  int32_T arm_orientation;
  real_T L2_angle;
  real_T L1_velocity;
  real_T L2_velocity;
  real_T L1_acceleration;
  real_T L2_acceleration;
  real_T M1_torque_cmd;
  real_T M2_torque_cmd;
  real_T elbow_position_x;
  real_T elbow_position_y;
  real_T elbow_velocity_x;
  real_T elbow_velocity_y;
  real_T elbow_acceleration_x;
  real_T elbow_acceleration_y;
  real_T force_sensor_force_x;
  real_T force_sensor_force_y;
  real_T force_sensor_force_z;
  real_T force_sensor_torque_x;
  real_T force_sensor_torque_y;
  real_T force_sensor_torque_z;
  real_T b_L1_angle;
  real_T b_L2_angle;
  real_T b_shoulder_angle;
  boolean_T isExo;

  /* '<S297>:1:160' */
  /* '<S297>:1:161' */
  /* '<S297>:1:162' */
  /* '<S297>:1:163' */
  /* '<S297>:1:164' */
  /* '<S297>:1:165' */
  /* '<S297>:1:166' */
  /* '<S297>:1:167' */
  /* '<S297>:1:169' */
  if ((hardware_settings[0] == 0.0) || (hardware_settings[0] == 2.0)) {
    /* '<S297>:1:170' */
    isExo = true;
  } else {
    isExo = false;
  }

  /* '<S297>:1:171' */
  isEP = (hardware_settings[0] == 1.0);

  /* '<S297>:1:173' */
  /* '<S297>:1:174' */
  /* '<S297>:1:175' */
  /* '<S297>:1:176' */
  /* '<S297>:1:178' */
  /* '<S297>:1:179' */
  /* '<S297>:1:180' */
  /* '<S297>:1:181' */
  /* '<S297>:1:182' */
  /* '<S297>:1:183' */
  /* '<S297>:1:184' */
  /* '<S297>:1:186' */
  /* '<S297>:1:187' */
  /* '<S297>:1:188' */
  /* '<S297>:1:189' */
  elbow_velocity = robot_data[3];

  /* '<S297>:1:190' */
  /* '<S297>:1:191' */
  elbow_acceleration = robot_data[5];

  /* '<S297>:1:192' */
  /* '<S297>:1:193' */
  /* '<S297>:1:194' */
  motor1_status = robot_data[8];

  /* '<S297>:1:195' */
  motor2_status = robot_data[9];

  /* '<S297>:1:197' */
  /* '<S297>:1:198' */
  /* '<S297>:1:211' */
  shoulder_angle = robot_data[0] + calibration[0];
  if (isExo) {
    /* '<S297>:1:215' */
    may23_correct_elbow_angle(robot_data[1] + calibration[1], robot_data[3],
      robot_data[5], hardware_settings[3], calibration[4], hardware_settings[2],
      calibration[7], &elbow_angle, &elbow_velocity, &elbow_acceleration);

    /* '<S297>:1:216' */
    elbow_angle += robot_data[1] + calibration[1];

    /* '<S297>:1:217' */
    elbow_velocity += robot_data[3];

    /* '<S297>:1:218' */
    elbow_acceleration += robot_data[5];
  } else {
    /* '<S297>:1:220' */
    elbow_angle = robot_data[1] + calibration[1];
  }

  if ((isEP && (hardware_settings[5] < 0.0)) || (isExo && (hardware_settings[5] >
        0.0))) {
    /* '<S297>:1:226' */
    /* '<S297>:1:227' */
    arm_orientation = 1;
  } else {
    /* '<S297>:1:229' */
    arm_orientation = 2;
  }

  if (robot_data[9] != 0.0) {
    /* '<S297>:1:234' */
    /* '<S297>:1:235' */
    motor2_status = 1.0;
  }

  if (robot_data[8] != 0.0) {
    /* '<S297>:1:237' */
    /* '<S297>:1:238' */
    motor1_status = 1.0;
  }

  /* '<S297>:1:240' */
  /* '<S297>:1:253' */
  /* '<S297>:1:254' */
  L2_angle = shoulder_angle + elbow_angle;

  /* '<S297>:1:256' */
  elbow_angle = (shoulder_angle + elbow_angle) + 1.5707963267948966;

  /* '<S297>:1:258' */
  L1_velocity = robot_data[2];

  /* '<S297>:1:259' */
  L2_velocity = robot_data[2] + elbow_velocity;

  /* '<S297>:1:261' */
  L1_acceleration = robot_data[4];

  /* '<S297>:1:262' */
  L2_acceleration = robot_data[4] + elbow_acceleration;

  /* '<S297>:1:264' */
  M1_torque_cmd = torque_command[0] - torque_command[1];

  /* '<S297>:1:265' */
  M2_torque_cmd = torque_command[1];
  if (hardware_settings[5] == -1.0) {
    /* '<S297>:1:271' */
    /* '<S297>:1:272' */
    shoulder_angle = -shoulder_angle + 3.1415926535897931;

    /* '<S297>:1:273' */
    L2_angle = -L2_angle + 3.1415926535897931;

    /* '<S297>:1:275' */
    elbow_angle = -elbow_angle + 3.1415926535897931;

    /* '<S297>:1:277' */
    L1_velocity = -robot_data[2];

    /* '<S297>:1:278' */
    L2_velocity = -L2_velocity;

    /* '<S297>:1:280' */
    L1_acceleration = -robot_data[4];

    /* '<S297>:1:281' */
    L2_acceleration = -L2_acceleration;

    /* '<S297>:1:283' */
    M1_torque_cmd = -M1_torque_cmd;

    /* '<S297>:1:284' */
    M2_torque_cmd = -torque_command[1];
  }

  /* '<S297>:1:288' */
  may23_apply_offsets(idx, shoulder_angle, L2_angle, is_calibrated, isEP,
                      hardware_settings[5], &b_L1_angle, &b_L2_angle);

  /* '<S297>:1:290' */
  shoulder_angle = b_L1_angle;
  L2_angle = b_L2_angle;

  /* '<S297>:1:560' */
  b_shoulder_angle = b_L1_angle;
  if (hardware_settings[5] == -1.0) {
    /* '<S297>:1:562' */
    /* '<S297>:1:563' */
    L2_angle = -b_L2_angle + 3.1415926535897931;

    /* '<S297>:1:564' */
    shoulder_angle = -b_L1_angle + 3.1415926535897931;

    /* '<S297>:1:565' */
    b_shoulder_angle = -b_L1_angle + 3.1415926535897931;
  }

  /* '<S297>:1:568' */
  /* '<S297>:1:293' */
  elbow_position_x = calibration[4] * cos(b_L1_angle) + calibration[2];

  /* '<S297>:1:294' */
  elbow_position_y = calibration[4] * sin(b_L1_angle) + calibration[3];

  /* '<S297>:1:296' */
  elbow_velocity_x = -calibration[4] * sin(b_L1_angle) * L1_velocity;

  /* '<S297>:1:297' */
  elbow_velocity_y = calibration[4] * cos(b_L1_angle) * L1_velocity;

  /* '<S297>:1:299' */
  elbow_acceleration_x = (L1_velocity * L1_velocity * cos(b_L1_angle) + sin
    (b_L1_angle) * L1_acceleration) * -calibration[4];

  /* '<S297>:1:300' */
  elbow_acceleration_y = (L1_velocity * L1_velocity * -sin(b_L1_angle) + cos
    (b_L1_angle) * L1_acceleration) * calibration[4];

  /* '<S297>:1:303' */
  /* '<S297>:1:304' */
  /* '<S297>:1:306' */
  /* '<S297>:1:307' */
  /* '<S297>:1:309' */
  /* '<S297>:1:311' */
  if (isEP) {
    /* '<S297>:1:317' */
    /* '<S297>:1:319' */
    force_sensor_force_u = force_sensor_data[0] / 1.0E+6;

    /* '<S297>:1:320' */
    force_sensor_force_v = force_sensor_data[1] / 1.0E+6;

    /* '<S297>:1:321' */
    force_sensor_force_w = force_sensor_data[2] / 1.0E+6;

    /* '<S297>:1:323' */
    force_sensor_torque_u = force_sensor_data[3] / 1.0E+6;

    /* '<S297>:1:324' */
    force_sensor_torque_v = force_sensor_data[4] / 1.0E+6;

    /* '<S297>:1:325' */
    force_sensor_torque_w = force_sensor_data[5] / 1.0E+6;

    /* '<S297>:1:327' */
    force_sensor_torque_y = b_L2_angle - hardware_settings[4];

    /* '<S297>:1:328' */
    force_sensor_torque_z = (b_L2_angle - hardware_settings[4]) -
      1.5707963267948966;

    /* '<S297>:1:330' */
    force_sensor_force_x = force_sensor_force_u * cos(force_sensor_torque_y) +
      force_sensor_force_v * cos(force_sensor_torque_z);

    /* '<S297>:1:331' */
    force_sensor_force_y = force_sensor_force_u * sin(force_sensor_torque_y) +
      force_sensor_force_v * sin(force_sensor_torque_z);

    /* '<S297>:1:332' */
    force_sensor_force_z = -force_sensor_force_w;

    /* '<S297>:1:334' */
    force_sensor_torque_x = force_sensor_torque_u * cos(force_sensor_torque_y) +
      force_sensor_torque_v * cos(force_sensor_torque_z);

    /* '<S297>:1:335' */
    force_sensor_torque_y = force_sensor_torque_u * sin(force_sensor_torque_y) +
      force_sensor_torque_v * sin(force_sensor_torque_z);

    /* '<S297>:1:336' */
    force_sensor_torque_z = -force_sensor_torque_w;
  } else {
    /* '<S297>:1:339' */
    force_sensor_force_u = 0.0;

    /* '<S297>:1:340' */
    force_sensor_force_v = 0.0;

    /* '<S297>:1:341' */
    force_sensor_force_w = 0.0;

    /* '<S297>:1:343' */
    force_sensor_torque_u = 0.0;

    /* '<S297>:1:344' */
    force_sensor_torque_v = 0.0;

    /* '<S297>:1:345' */
    force_sensor_torque_w = 0.0;

    /* '<S297>:1:347' */
    force_sensor_force_x = 0.0;

    /* '<S297>:1:348' */
    force_sensor_force_y = 0.0;

    /* '<S297>:1:349' */
    force_sensor_force_z = 0.0;

    /* '<S297>:1:351' */
    force_sensor_torque_x = 0.0;

    /* '<S297>:1:352' */
    force_sensor_torque_y = 0.0;

    /* '<S297>:1:353' */
    force_sensor_torque_z = 0.0;
  }

  /* '<S297>:1:359' */
  robot_row[0] = calibration[4];

  /* '<S297>:1:360' */
  robot_row[1] = calibration[5];

  /* '<S297>:1:361' */
  robot_row[2] = calibration[6];

  /* '<S297>:1:362' */
  robot_row[3] = calibration[2];

  /* '<S297>:1:363' */
  robot_row[4] = calibration[3];

  /* '<S297>:1:364' */
  robot_row[5] = arm_orientation;

  /* '<S297>:1:365' */
  robot_row[6] = b_shoulder_angle;

  /* '<S297>:1:366' */
  robot_row[7] = L2_angle - shoulder_angle;

  /* '<S297>:1:367' */
  robot_row[8] = robot_data[2];

  /* '<S297>:1:368' */
  robot_row[9] = elbow_velocity;

  /* '<S297>:1:369' */
  robot_row[10] = robot_data[4];

  /* '<S297>:1:370' */
  robot_row[11] = elbow_acceleration;

  /* '<S297>:1:371' */
  robot_row[12] = torque_command[0];

  /* '<S297>:1:372' */
  robot_row[13] = torque_command[1];

  /* '<S297>:1:373' */
  robot_row[14] = M1_torque_cmd;

  /* '<S297>:1:374' */
  robot_row[15] = M2_torque_cmd;

  /* '<S297>:1:375' */
  robot_row[16] = b_L1_angle;

  /* '<S297>:1:376' */
  robot_row[17] = b_L2_angle;

  /* '<S297>:1:377' */
  robot_row[18] = L1_velocity;

  /* '<S297>:1:378' */
  robot_row[19] = L2_velocity;

  /* '<S297>:1:379' */
  robot_row[20] = L1_acceleration;

  /* '<S297>:1:380' */
  robot_row[21] = L2_acceleration;

  /* '<S297>:1:381' */
  robot_row[22] = (calibration[5] * cos(b_L2_angle) + elbow_position_x) +
    calibration[6] * cos(elbow_angle);

  /* '<S297>:1:382' */
  robot_row[23] = (calibration[5] * sin(b_L2_angle) + elbow_position_y) +
    calibration[6] * sin(elbow_angle);

  /* '<S297>:1:383' */
  robot_row[24] = (elbow_velocity_x - calibration[5] * sin(b_L2_angle) *
                   L2_velocity) - calibration[6] * sin(elbow_angle) *
    L2_velocity;

  /* '<S297>:1:384' */
  robot_row[25] = (calibration[5] * cos(b_L2_angle) * L2_velocity +
                   elbow_velocity_y) + calibration[6] * cos(elbow_angle) *
    L2_velocity;

  /* '<S297>:1:385' */
  robot_row[26] = (elbow_acceleration_x - (L2_velocity * L2_velocity * cos
    (b_L2_angle) + sin(b_L2_angle) * L2_acceleration) * calibration[5]) -
    (L2_velocity * L2_velocity * cos(elbow_angle) + sin(elbow_angle) *
     L2_acceleration) * calibration[6];

  /* '<S297>:1:386' */
  robot_row[27] = ((L2_velocity * L2_velocity * -sin(b_L2_angle) + cos
                    (b_L2_angle) * L2_acceleration) * calibration[5] +
                   elbow_acceleration_y) + (L2_velocity * L2_velocity * -sin
    (elbow_angle) + cos(elbow_angle) * L2_acceleration) * calibration[6];

  /* '<S297>:1:387' */
  robot_row[28] = elbow_position_x;

  /* '<S297>:1:388' */
  robot_row[29] = elbow_position_y;

  /* '<S297>:1:389' */
  robot_row[30] = elbow_velocity_x;

  /* '<S297>:1:390' */
  robot_row[31] = elbow_velocity_y;

  /* '<S297>:1:391' */
  robot_row[32] = elbow_acceleration_x;

  /* '<S297>:1:392' */
  robot_row[33] = elbow_acceleration_y;

  /* '<S297>:1:393' */
  robot_row[34] = robot_data[6];

  /* '<S297>:1:394' */
  robot_row[35] = robot_data[7];

  /* '<S297>:1:395' */
  robot_row[36] = motor2_status * 2.0 + motor1_status;

  /* '<S297>:1:396' */
  robot_row[37] = force_sensor_force_u;

  /* '<S297>:1:397' */
  robot_row[38] = force_sensor_force_v;

  /* '<S297>:1:398' */
  robot_row[39] = force_sensor_force_w;

  /* '<S297>:1:399' */
  robot_row[40] = force_sensor_torque_u;

  /* '<S297>:1:400' */
  robot_row[41] = force_sensor_torque_v;

  /* '<S297>:1:401' */
  robot_row[42] = force_sensor_torque_w;

  /* '<S297>:1:402' */
  robot_row[43] = force_sensor_force_x;

  /* '<S297>:1:403' */
  robot_row[44] = force_sensor_force_y;

  /* '<S297>:1:404' */
  robot_row[45] = force_sensor_force_z;

  /* '<S297>:1:405' */
  robot_row[46] = force_sensor_torque_x;

  /* '<S297>:1:406' */
  robot_row[47] = force_sensor_torque_y;

  /* '<S297>:1:407' */
  robot_row[48] = force_sensor_torque_z;

  /* '<S297>:1:408' */
  robot_row[49] = force_sensor_data[6];
}

/* System initialize for function-call system: '<S30>/createKINData' */
void may23_createKINData_Init(void)
{
  int32_T i;

  /* InitializeConditions for UnitDelay: '<S296>/Output' */
  may23_DW.Output_DSTATE_f = may23_P.Output_InitialCondition_i;

  /* SystemInitialize for Chart: '<S73>/Calibration_check' */
  may23_DW.sfEvent_e = may23_CALL_EVENT_ig;
  may23_DW.is_active_Robot1_g = 0U;
  may23_DW.is_Robot1_l = may23_IN_NO_ACTIVE_CHILD_a;
  may23_DW.temporalCounter_i1_n5 = 0U;
  may23_DW.is_active_Robot2_i = 0U;
  may23_DW.is_Robot2_j = may23_IN_NO_ACTIVE_CHILD_a;
  may23_DW.temporalCounter_i2_n = 0U;
  may23_DW.is_active_c59_General = 0U;
  may23_DW.is_c59_General = may23_IN_NO_ACTIVE_CHILD_a;
  may23_DW.presentTicks_l = 0U;
  may23_DW.elapsedTicks_n = 0U;
  may23_DW.previousTicks_j = 0U;

  /* SystemInitialize for MATLAB Function: '<S73>/Create KINARM Data Array' */
  may23_DW.was_calibrated[0] = 0.0;
  may23_DW.was_calibrated[1] = 0.0;
  may23_DW.was_calibrated[2] = 0.0;
  may23_DW.was_calibrated[3] = 0.0;
  for (i = 0; i < 8; i++) {
    may23_DW.stored_offsets[i] = 0.0;
  }

  /* End of SystemInitialize for MATLAB Function: '<S73>/Create KINARM Data Array' */

  /* SystemInitialize for MATLAB Function: '<S73>/record errors' */
  may23_DW.lastECATMessages_not_empty = false;
  for (i = 0; i < 300; i++) {
    may23_DW.memoryBuffer[i] = 0.0;
  }

  may23_DW.waitingMsgCount = 0.0;
  may23_DW.outCount = 0.0;
  may23_DW.sentCount = 0.0;

  /* End of SystemInitialize for MATLAB Function: '<S73>/record errors' */
}

/* Enable for function-call system: '<S30>/createKINData' */
void may23_createKINData_Enable(void)
{
  /* Enable for Chart: '<S73>/Calibration_check' */
  may23_DW.presentTicks_l = may23_M->Timing.clockTick1;
  may23_DW.previousTicks_j = may23_DW.presentTicks_l;
}

/* Start for function-call system: '<S30>/createKINData' */
void may23_createKINData_Start(void)
{
  /* Start for Constant: '<S73>/is_calibrated' */
  may23_B.is_calibrated[0] = may23_P.is_calibrated_Value[0];
  may23_B.is_calibrated[1] = may23_P.is_calibrated_Value[1];
}

/* Output and update for function-call system: '<S30>/createKINData' */
void may23_createKINData(void)
{
  uint32_T ep_calibration_button_bitfield;
  real_T feed_forward_duration;
  real_T elbow_velocity;
  real_T elbow_acceleration;
  real_T shoulder_angle;
  real_T L1_velocity;
  real_T L1_acceleration;
  real_T b_L1_angle;
  real_T b_L2_angle;
  boolean_T isExo;
  uint32_T motorInt;
  int32_T i;
  real_T tmp[50];
  int32_T i_0;
  int32_T i_1;

  /* Constant: '<S73>/is_calibrated' */
  may23_B.is_calibrated[0] = may23_P.is_calibrated_Value[0];
  may23_B.is_calibrated[1] = may23_P.is_calibrated_Value[1];

  /* DataStoreRead: '<S73>/Data ready' */
  memcpy(&may23_B.Dataready[0], &may23_DW.DataReadyStatus[0], 10U * sizeof
         (real_T));

  /* Chart: '<S73>/Calibration_check' */
  may23_DW.presentTicks_l = may23_M->Timing.clockTick1;
  may23_DW.elapsedTicks_n = may23_DW.presentTicks_l - may23_DW.previousTicks_j;
  may23_DW.previousTicks_j = may23_DW.presentTicks_l;
  if (may23_DW.temporalCounter_i1_n5 + may23_DW.elapsedTicks_n <= 7U) {
    may23_DW.temporalCounter_i1_n5 = (uint8_T)(may23_DW.temporalCounter_i1_n5 +
      may23_DW.elapsedTicks_n);
  } else {
    may23_DW.temporalCounter_i1_n5 = 7U;
  }

  if (may23_DW.temporalCounter_i2_n + may23_DW.elapsedTicks_n <= 511U) {
    may23_DW.temporalCounter_i2_n = (uint16_T)(may23_DW.temporalCounter_i2_n +
      may23_DW.elapsedTicks_n);
  } else {
    may23_DW.temporalCounter_i2_n = 511U;
  }

  /* Gateway: DataLogging/Poll KINARM/createKINData/Calibration_check */
  may23_DW.sfEvent_e = may23_CALL_EVENT_ig;

  /* During: DataLogging/Poll KINARM/createKINData/Calibration_check */
  if (may23_DW.is_active_c59_General == 0U) {
    /* Entry: DataLogging/Poll KINARM/createKINData/Calibration_check */
    may23_DW.is_active_c59_General = 1U;

    /* Entry Internal: DataLogging/Poll KINARM/createKINData/Calibration_check */
    /* Transition: '<S295>:8' */
    may23_DW.is_c59_General = may23_IN_Monitor;

    /* Entry 'Monitor': '<S295>:7' */
    may23_B.trigger_calibration[0] = 0.0;
    may23_B.trigger_calibration[1] = 0.0;

    /* Entry Internal 'Monitor': '<S295>:7' */
    may23_DW.is_active_Robot1_g = 1U;

    /* Entry Internal 'Robot1': '<S295>:9' */
    /* Transition: '<S295>:11' */
    may23_DW.is_Robot1_l = may23_IN_Init_j;
    may23_DW.is_active_Robot2_i = 1U;

    /* Entry Internal 'Robot2': '<S295>:25' */
    /* Transition: '<S295>:21' */
    may23_DW.is_Robot2_j = may23_IN_Init_j;
  } else {
    /* During 'Monitor': '<S295>:7' */
    /* During 'Robot1': '<S295>:9' */
    switch (may23_DW.is_Robot1_l) {
     case may23_IN_Calibrated:
      /* During 'Calibrated': '<S295>:12' */
      /* Transition: '<S295>:16' */
      may23_DW.is_Robot1_l = may23_IN_WaitForOp;
      break;

     case may23_IN_Done_d:
      /* During 'Done': '<S295>:14' */
      break;

     case may23_IN_Init_j:
      /* During 'Init': '<S295>:10' */
      if (may23_B.is_calibrated[0] == 1.0) {
        /* Transition: '<S295>:13' */
        may23_DW.is_Robot1_l = may23_IN_Calibrated;
      }
      break;

     case may23_IN_Short_wait:
      /* During 'Short_wait': '<S295>:17' */
      if (may23_DW.temporalCounter_i1_n5 >= 4U) {
        /* Transition: '<S295>:19' */
        may23_DW.is_Robot1_l = may23_IN_Done_d;

        /* Entry 'Done': '<S295>:14' */
        may23_B.trigger_calibration[0] = 1.0;
      }
      break;

     default:
      /* During 'WaitForOp': '<S295>:15' */
      if (may23_B.Dataready[0] == 1.0) {
        /* Transition: '<S295>:18' */
        may23_DW.is_Robot1_l = may23_IN_Short_wait;
        may23_DW.temporalCounter_i1_n5 = 0U;
      }
      break;
    }

    /* During 'Robot2': '<S295>:25' */
    switch (may23_DW.is_Robot2_j) {
     case may23_IN_Calibrated:
      /* During 'Calibrated': '<S295>:22' */
      /* Transition: '<S295>:27' */
      may23_DW.is_Robot2_j = may23_IN_WaitForOp;
      break;

     case may23_IN_Done_d:
      /* During 'Done': '<S295>:26' */
      break;

     case may23_IN_Init_j:
      /* During 'Init': '<S295>:24' */
      if (may23_B.is_calibrated[1] == 1.0) {
        /* Transition: '<S295>:23' */
        may23_DW.is_Robot2_j = may23_IN_Calibrated;
      }
      break;

     case may23_IN_Short_wait:
      /* During 'Short_wait': '<S295>:28' */
      if (may23_DW.temporalCounter_i2_n >= 400U) {
        /* Transition: '<S295>:30' */
        may23_DW.is_Robot2_j = may23_IN_Done_d;

        /* Entry 'Done': '<S295>:26' */
        may23_B.trigger_calibration[1] = 1.0;
      }
      break;

     default:
      /* During 'WaitForOp': '<S295>:29' */
      if (may23_B.Dataready[0] == 1.0) {
        /* Transition: '<S295>:31' */
        may23_DW.is_Robot2_j = may23_IN_Short_wait;
        may23_DW.temporalCounter_i2_n = 0U;
      }
      break;
    }
  }

  /* End of Chart: '<S73>/Calibration_check' */

  /* DataStoreRead: '<S73>/Read' */
  memcpy(&may23_B.Read[0], &may23_DW.RobotCalibrations[0], sizeof(real_T) << 4U);

  /* DataStoreRead: '<S73>/Read HW' */
  memcpy(&may23_B.ReadHW[0], &may23_DW.HardwareSettings[0], 25U * sizeof(real_T));

  /* DataStoreRead: '<S73>/Read Kinematics' */
  memcpy(&may23_B.ReadKinematics[0], &may23_DW.Kinematics[0], 20U * sizeof
         (real_T));

  /* DataStoreRead: '<S73>/Servo Read' */
  may23_B.ServoRead = may23_DW.ServoUpdate;

  /* DataStoreRead: '<S73>/Delay Read' */
  may23_B.DelayRead[0] = may23_DW.DelayEstimates[0];
  may23_B.DelayRead[1] = may23_DW.DelayEstimates[1];
  may23_B.DelayRead[2] = may23_DW.DelayEstimates[2];
  may23_B.DelayRead[3] = may23_DW.DelayEstimates[3];

  /* DataStoreRead: '<S73>/Primary read' */
  memcpy(&may23_B.Primaryread[0], &may23_DW.PrimaryEncoderData[0], 12U * sizeof
         (real_T));

  /* DataStoreRead: '<S73>/Data Store Read' */
  may23_B.DataStoreRead_d = may23_DW.CalibrationButton;

  /* SignalConversion generated from: '<S297>/ SFunction ' incorporates:
   *  Constant: '<S299>/Gaze Feedback Status'
   *  Constant: '<S299>/Hand Feedback Colour'
   *  Constant: '<S299>/Hand Feedback Feed Forward'
   *  Constant: '<S299>/Hand Feedback Radius'
   *  Constant: '<S299>/Hand Feedback Source'
   *  Constant: '<S299>/Hand Feedback Status'
   *  MATLAB Function: '<S73>/Create KINARM Data Array'
   */
  may23_B.TmpSignalConversionAtSFunctionInport10[0] =
    may23_P.HandFeedbackStatus_Value;
  may23_B.TmpSignalConversionAtSFunctionInport10[1] =
    may23_P.HandFeedbackSource_Value;
  may23_B.TmpSignalConversionAtSFunctionInport10[2] =
    may23_P.HandFeedbackRadius_Value;
  may23_B.TmpSignalConversionAtSFunctionInport10[3] =
    may23_P.HandFeedbackColour_Value;
  may23_B.TmpSignalConversionAtSFunctionInport10[4] =
    may23_P.HandFeedbackFeedForward_Value;
  may23_B.TmpSignalConversionAtSFunctionInport10[5] =
    may23_P.GazeFeedbackStatus_Value;
  may23_B.TmpSignalConversionAtSFunctionInport10[6] = may23_B.Gain;

  /* SignalConversion generated from: '<S297>/ SFunction ' incorporates:
   *  MATLAB Function: '<S73>/Create KINARM Data Array'
   */
  may23_B.TmpSignalConversionAtSFunctionInport12[0] = may23_B.Convert3;
  may23_B.TmpSignalConversionAtSFunctionInport12[1] = may23_B.Convert19[0];
  may23_B.TmpSignalConversionAtSFunctionInport12[2] = may23_B.Convert19[1];
  may23_B.TmpSignalConversionAtSFunctionInport12[3] = may23_B.Convert19[2];
  may23_B.TmpSignalConversionAtSFunctionInport12[4] = may23_B.Convert1_n;
  may23_B.TmpSignalConversionAtSFunctionInport12[5] = may23_B.RateTransition_i[0];
  may23_B.TmpSignalConversionAtSFunctionInport12[6] = may23_B.RateTransition_i[1];
  may23_B.TmpSignalConversionAtSFunctionInport12[7] = may23_B.RateTransition_i[2];
  may23_B.TmpSignalConversionAtSFunctionInport12[8] = may23_B.Convert4[0];
  may23_B.TmpSignalConversionAtSFunctionInport12[9] = may23_B.Convert4[1];
  may23_B.TmpSignalConversionAtSFunctionInport12[10] = may23_B.Convert4[2];
  may23_B.TmpSignalConversionAtSFunctionInport12[11] = may23_B.pupil_GLOBAL[0];
  may23_B.TmpSignalConversionAtSFunctionInport12[12] = may23_B.pupil_GLOBAL[1];
  may23_B.TmpSignalConversionAtSFunctionInport12[13] = may23_B.pupil_GLOBAL[2];

  /* MATLAB Function: '<S73>/Create KINARM Data Array' incorporates:
   *  Constant: '<S73>/Dominant Arm'
   */
  motorInt = may23_B.ServoRead;
  ep_calibration_button_bitfield = may23_B.DataStoreRead_d;
  shoulder_angle = may23_P.DominantArm_Value;

  /* MATLAB Function 'DataLogging/Poll KINARM/createKINData/Create KINARM Data Array': '<S297>:1' */
  /* '<S297>:1:8' */
  for (i = 0; i < 150; i++) {
    may23_B.kinarm_data[i] = 0.0;
  }

  /* '<S297>:1:9' */
  for (i = 0; i < 12; i++) {
    may23_B.primary_encoder_data_out[i] = 0.0;
  }

  /* '<S297>:1:13' */
  may23_create_robot_row(1.0, &may23_B.Read[0], &may23_B.ReadHW[0],
    &may23_B.measures_out[0], &may23_B.ReadKinematics[0], &may23_B.Memory_d[0],
    may23_B.trigger_calibration[0], tmp);
  for (i_0 = 0; i_0 < 50; i_0++) {
    may23_B.kinarm_data[3 * i_0] = tmp[i_0];
  }

  /* '<S297>:1:16' */
  may23_create_robot_row(2.0, &may23_B.Read[8], &may23_B.ReadHW[12],
    &may23_B.measures_out[7], &may23_B.ReadKinematics[10], &may23_B.Memory_d[2],
    may23_B.trigger_calibration[1], tmp);
  for (i_0 = 0; i_0 < 50; i_0++) {
    may23_B.kinarm_data[3 * i_0 + 1] = tmp[i_0];
  }

  /* '<S297>:1:22' */
  feed_forward_duration = may23_B.TmpSignalConversionAtSFunctionInport10[4];
  if (may23_B.TmpSignalConversionAtSFunctionInport10[6] >
      may23_B.TmpSignalConversionAtSFunctionInport10[4]) {
    /* '<S297>:1:23' */
    /* '<S297>:1:24' */
    feed_forward_duration = may23_B.TmpSignalConversionAtSFunctionInport10[6];
  }

  /* '<S297>:1:28' */
  may23_B.kinarm_data[2] = shoulder_angle;

  /* '<S297>:1:29' */
  may23_B.kinarm_data[5] = feed_forward_duration;

  /* '<S297>:1:30' */
  may23_B.kinarm_data[8] = may23_B.TmpSignalConversionAtSFunctionInport10[0];

  /* '<S297>:1:31' */
  may23_B.kinarm_data[11] = may23_B.TmpSignalConversionAtSFunctionInport10[1];

  /* '<S297>:1:32' */
  may23_B.kinarm_data[14] = may23_B.TmpSignalConversionAtSFunctionInport10[3];

  /* '<S297>:1:33' */
  may23_B.kinarm_data[17] = may23_B.TmpSignalConversionAtSFunctionInport10[2];

  /* '<S297>:1:34' */
  may23_B.kinarm_data[20] = may23_B.TmpSignalConversionAtSFunctionInport10[4];

  /* '<S297>:1:35' */
  may23_B.kinarm_data[23] = may23_B.DelayRead[0];

  /* '<S297>:1:36' */
  may23_B.kinarm_data[26] = may23_B.DelayRead[1];

  /* '<S297>:1:37' */
  may23_B.kinarm_data[29] = may23_B.DelayRead[2];

  /* '<S297>:1:38' */
  may23_B.kinarm_data[32] = may23_B.DelayRead[3];

  /* '<S297>:1:39' */
  may23_B.kinarm_data[35] = motorInt;

  /* '<S297>:1:40' */
  may23_B.kinarm_data[38] = ep_calibration_button_bitfield;

  /* '<S297>:1:42' */
  /* '<S297>:1:43' */
  may23_B.kinarm_data[41] = may23_B.TmpSignalConversionAtSFunctionInport12[0];

  /* '<S297>:1:44' */
  may23_B.kinarm_data[44] = may23_B.TmpSignalConversionAtSFunctionInport10[5];
  if (may23_B.TmpSignalConversionAtSFunctionInport12[0] != 0.0) {
    /* '<S297>:1:47' */
    may23_B.kinarm_data[47] = may23_B.TmpSignalConversionAtSFunctionInport12[1];

    /* '<S297>:1:48' */
    may23_B.kinarm_data[50] = may23_B.TmpSignalConversionAtSFunctionInport12[2];

    /* '<S297>:1:49' */
    may23_B.kinarm_data[53] = may23_B.TmpSignalConversionAtSFunctionInport12[3];

    /* '<S297>:1:50' */
    may23_B.kinarm_data[56] = may23_B.TmpSignalConversionAtSFunctionInport12[4];

    /* '<S297>:1:51' */
    may23_B.kinarm_data[59] = may23_B.TmpSignalConversionAtSFunctionInport12[5];

    /* '<S297>:1:52' */
    may23_B.kinarm_data[62] = may23_B.TmpSignalConversionAtSFunctionInport12[6];

    /* '<S297>:1:53' */
    may23_B.kinarm_data[65] = may23_B.TmpSignalConversionAtSFunctionInport12[7];

    /* '<S297>:1:54' */
    may23_B.kinarm_data[68] = may23_B.TmpSignalConversionAtSFunctionInport12[8];

    /* '<S297>:1:55' */
    may23_B.kinarm_data[71] = may23_B.TmpSignalConversionAtSFunctionInport12[9];

    /* '<S297>:1:56' */
    may23_B.kinarm_data[74] = may23_B.TmpSignalConversionAtSFunctionInport12[10];

    /* '<S297>:1:57' */
    may23_B.kinarm_data[77] = may23_B.TmpSignalConversionAtSFunctionInport12[11];

    /* '<S297>:1:58' */
    may23_B.kinarm_data[80] = may23_B.TmpSignalConversionAtSFunctionInport12[12];

    /* '<S297>:1:59' */
    may23_B.kinarm_data[83] = may23_B.TmpSignalConversionAtSFunctionInport12[13];
  } else {
    /* '<S297>:1:61' */
    may23_B.kinarm_data[47] = -100.0;

    /* '<S297>:1:62' */
    may23_B.kinarm_data[50] = -100.0;

    /* '<S297>:1:63' */
    may23_B.kinarm_data[53] = -100.0;

    /* '<S297>:1:64' */
    may23_B.kinarm_data[56] = -100.0;

    /* '<S297>:1:65' */
    may23_B.kinarm_data[68] = -100.0;

    /* '<S297>:1:66' */
    may23_B.kinarm_data[71] = -100.0;

    /* '<S297>:1:67' */
    may23_B.kinarm_data[74] = -100.0;

    /* '<S297>:1:68' */
    may23_B.kinarm_data[77] = -100.0;

    /* '<S297>:1:69' */
    may23_B.kinarm_data[80] = -100.0;

    /* '<S297>:1:70' */
    may23_B.kinarm_data[83] = -100.0;
  }

  /* '<S297>:1:76' */
  /* '<S297>:1:77' */
  /* '<S297>:1:79' */
  /* '<S297>:1:80' */
  /* '<S297>:1:81' */
  /* '<S297>:1:82' */
  elbow_velocity = may23_B.Primaryread[3];

  /* '<S297>:1:83' */
  /* '<S297>:1:84' */
  elbow_acceleration = may23_B.Primaryread[5];

  /* '<S297>:1:86' */
  /* '<S297>:1:87' */
  feed_forward_duration = may23_B.Read[1];

  /* '<S297>:1:88' */
  /* '<S297>:1:89' */
  /* '<S297>:1:91' */
  /* '<S297>:1:92' */
  /* '<S297>:1:93' */
  /* '<S297>:1:94' */
  /* '<S297>:1:95' */
  if ((may23_B.ReadHW[0] == 0.0) || (may23_B.ReadHW[0] == 2.0)) {
    /* '<S297>:1:96' */
    isExo = true;
  } else {
    isExo = false;
  }

  /* '<S297>:1:97' */
  /* '<S297>:1:104' */
  shoulder_angle = may23_B.Primaryread[0] + may23_B.Read[0];
  if (isExo) {
    /* '<S297>:1:108' */
    may23_correct_elbow_angle(may23_B.Primaryread[1] + feed_forward_duration,
      may23_B.Primaryread[3], may23_B.Primaryread[5], may23_B.ReadHW[3],
      may23_B.Read[4], may23_B.ReadHW[2], may23_B.Read[7], &elbow_velocity,
      &elbow_acceleration, &L1_velocity);

    /* '<S297>:1:109' */
    feed_forward_duration = (may23_B.Primaryread[1] + feed_forward_duration) +
      elbow_velocity;

    /* '<S297>:1:110' */
    elbow_velocity = may23_B.Primaryread[3] + elbow_acceleration;

    /* '<S297>:1:111' */
    elbow_acceleration = may23_B.Primaryread[5] + L1_velocity;
  } else {
    /* '<S297>:1:113' */
    feed_forward_duration += may23_B.Primaryread[1];
  }

  /* '<S297>:1:116' */
  /* '<S297>:1:117' */
  feed_forward_duration += shoulder_angle;

  /* '<S297>:1:119' */
  L1_velocity = may23_B.Primaryread[2];

  /* '<S297>:1:120' */
  elbow_velocity += may23_B.Primaryread[2];

  /* '<S297>:1:122' */
  L1_acceleration = may23_B.Primaryread[4];

  /* '<S297>:1:123' */
  elbow_acceleration += may23_B.Primaryread[4];
  if (may23_B.ReadHW[5] < 0.0) {
    /* '<S297>:1:129' */
    /* '<S297>:1:130' */
    shoulder_angle = -shoulder_angle + 3.1415926535897931;

    /* '<S297>:1:131' */
    feed_forward_duration = -feed_forward_duration + 3.1415926535897931;

    /* '<S297>:1:133' */
    L1_velocity = -may23_B.Primaryread[2];

    /* '<S297>:1:134' */
    elbow_velocity = -elbow_velocity;

    /* '<S297>:1:136' */
    L1_acceleration = -may23_B.Primaryread[4];

    /* '<S297>:1:137' */
    elbow_acceleration = -elbow_acceleration;
  }

  /* '<S297>:1:140' */
  may23_apply_offsets(3.0, shoulder_angle, feed_forward_duration,
                      may23_B.trigger_calibration[0], may23_B.ReadHW[0] == 1.0,
                      may23_B.ReadHW[5], &b_L1_angle, &b_L2_angle);

  /* '<S297>:1:142' */
  may23_B.primary_encoder_data_out[0] = b_L1_angle;

  /* '<S297>:1:143' */
  may23_B.primary_encoder_data_out[2] = b_L2_angle;

  /* '<S297>:1:145' */
  may23_B.primary_encoder_data_out[4] = L1_velocity;

  /* '<S297>:1:146' */
  may23_B.primary_encoder_data_out[6] = elbow_velocity;

  /* '<S297>:1:148' */
  may23_B.primary_encoder_data_out[8] = L1_acceleration;

  /* '<S297>:1:149' */
  may23_B.primary_encoder_data_out[10] = elbow_acceleration;

  /* '<S297>:1:76' */
  /* '<S297>:1:77' */
  /* '<S297>:1:79' */
  /* '<S297>:1:80' */
  /* '<S297>:1:81' */
  /* '<S297>:1:82' */
  elbow_velocity = may23_B.Primaryread[9];

  /* '<S297>:1:83' */
  /* '<S297>:1:84' */
  elbow_acceleration = may23_B.Primaryread[11];

  /* '<S297>:1:86' */
  /* '<S297>:1:87' */
  feed_forward_duration = may23_B.Read[9];

  /* '<S297>:1:88' */
  /* '<S297>:1:89' */
  /* '<S297>:1:91' */
  /* '<S297>:1:92' */
  /* '<S297>:1:93' */
  /* '<S297>:1:94' */
  /* '<S297>:1:95' */
  if ((may23_B.ReadHW[12] == 0.0) || (may23_B.ReadHW[12] == 2.0)) {
    /* '<S297>:1:96' */
    isExo = true;
  } else {
    isExo = false;
  }

  /* '<S297>:1:97' */
  /* '<S297>:1:104' */
  shoulder_angle = may23_B.Primaryread[6] + may23_B.Read[8];
  if (isExo) {
    /* '<S297>:1:108' */
    may23_correct_elbow_angle(may23_B.Primaryread[7] + feed_forward_duration,
      may23_B.Primaryread[9], may23_B.Primaryread[11], may23_B.ReadHW[15],
      may23_B.Read[12], may23_B.ReadHW[14], may23_B.Read[15], &elbow_velocity,
      &elbow_acceleration, &L1_velocity);

    /* '<S297>:1:109' */
    feed_forward_duration = (may23_B.Primaryread[7] + feed_forward_duration) +
      elbow_velocity;

    /* '<S297>:1:110' */
    elbow_velocity = may23_B.Primaryread[9] + elbow_acceleration;

    /* '<S297>:1:111' */
    elbow_acceleration = may23_B.Primaryread[11] + L1_velocity;
  } else {
    /* '<S297>:1:113' */
    feed_forward_duration += may23_B.Primaryread[7];
  }

  /* '<S297>:1:116' */
  /* '<S297>:1:117' */
  feed_forward_duration += shoulder_angle;

  /* '<S297>:1:119' */
  L1_velocity = may23_B.Primaryread[8];

  /* '<S297>:1:120' */
  elbow_velocity += may23_B.Primaryread[8];

  /* '<S297>:1:122' */
  L1_acceleration = may23_B.Primaryread[10];

  /* '<S297>:1:123' */
  elbow_acceleration += may23_B.Primaryread[10];
  if (may23_B.ReadHW[17] < 0.0) {
    /* '<S297>:1:129' */
    /* '<S297>:1:130' */
    shoulder_angle = -shoulder_angle + 3.1415926535897931;

    /* '<S297>:1:131' */
    feed_forward_duration = -feed_forward_duration + 3.1415926535897931;

    /* '<S297>:1:133' */
    L1_velocity = -may23_B.Primaryread[8];

    /* '<S297>:1:134' */
    elbow_velocity = -elbow_velocity;

    /* '<S297>:1:136' */
    L1_acceleration = -may23_B.Primaryread[10];

    /* '<S297>:1:137' */
    elbow_acceleration = -elbow_acceleration;
  }

  /* '<S297>:1:140' */
  may23_apply_offsets(4.0, shoulder_angle, feed_forward_duration,
                      may23_B.trigger_calibration[1], may23_B.ReadHW[12] == 1.0,
                      may23_B.ReadHW[17], &b_L1_angle, &b_L2_angle);

  /* '<S297>:1:142' */
  may23_B.primary_encoder_data_out[1] = b_L1_angle;

  /* '<S297>:1:143' */
  may23_B.primary_encoder_data_out[3] = b_L2_angle;

  /* '<S297>:1:145' */
  may23_B.primary_encoder_data_out[5] = L1_velocity;

  /* '<S297>:1:146' */
  may23_B.primary_encoder_data_out[7] = elbow_velocity;

  /* '<S297>:1:148' */
  may23_B.primary_encoder_data_out[9] = L1_acceleration;

  /* '<S297>:1:149' */
  may23_B.primary_encoder_data_out[11] = elbow_acceleration;

  /* DataStoreRead: '<S73>/Status read1' */
  for (i = 0; i < 8; i++) {
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.ecat_digital_input
      [i] = may23_DW.ECATDigitalInput[i];
  }

  /* End of DataStoreRead: '<S73>/Status read1' */

  /* DataStoreRead: '<S73>/torque feedback1' */
  memcpy(&may23_B.torquefeedback1[0], &may23_DW.ECATExtraData[0], 10U * sizeof
         (real_T));

  /* UnitDelay: '<S296>/Output' */
  may23_B.Output_o = may23_DW.Output_DSTATE_f;

  /* Sum: '<S301>/FixPt Sum1' incorporates:
   *  Constant: '<S301>/FixPt Constant'
   */
  may23_B.FixPtSum1_c = may23_B.Output_o + may23_P.FixPtConstant_Value_g;

  /* Switch: '<S302>/FixPt Switch' incorporates:
   *  Constant: '<S302>/Constant'
   */
  if (may23_B.FixPtSum1_c > may23_P.WrapToZero_Threshold_m) {
    may23_B.FixPtSwitch_i = may23_P.Constant_Value_li;
  } else {
    may23_B.FixPtSwitch_i = may23_B.FixPtSum1_c;
  }

  /* End of Switch: '<S302>/FixPt Switch' */

  /* DataStoreRead: '<S73>/Status read' */
  for (i = 0; i < 7; i++) {
    may23_B.Statusread[i] = may23_DW.SystemStatus[i];
  }

  /* End of DataStoreRead: '<S73>/Status read' */

  /* MATLAB Function: '<S73>/bitpack' */
  /* MATLAB Function 'DataLogging/Poll KINARM/createKINData/bitpack': '<S298>:1' */
  /* '<S298>:1:2' */
  may23_B.statusInts[1] = may23_B.Statusread[4];
  may23_B.statusInts[2] = may23_B.Statusread[5];
  may23_B.statusInts[3] = may23_B.Statusread[6];

  /* '<S298>:1:8' */
  /* '<S298>:1:9' */
  /* '<S298>:1:10' */
  motorInt = may23_B.Statusread[0];

  /* '<S298>:1:9' */
  /* '<S298>:1:10' */
  motorInt |= may23_B.Statusread[1] << 2U;

  /* '<S298>:1:9' */
  /* '<S298>:1:10' */
  motorInt |= may23_B.Statusread[2] << 4U;

  /* '<S298>:1:9' */
  /* '<S298>:1:10' */
  motorInt |= may23_B.Statusread[3] << 6U;

  /* '<S298>:1:12' */
  may23_B.statusInts[0] = motorInt;

  /* DataTypeConversion: '<S73>/Data Type Conversion' */
  may23_B.DataTypeConversion_f[0] = may23_B.statusInts[0];
  may23_B.DataTypeConversion_f[1] = may23_B.statusInts[1];
  may23_B.DataTypeConversion_f[2] = may23_B.statusInts[2];
  may23_B.DataTypeConversion_f[3] = may23_B.statusInts[3];

  /* DataTypeConversion: '<S73>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_d = may23_B.Output_o;

  /* DataStoreRead: '<S73>/ErrMsgs' */
  memcpy(&may23_B.ErrMsgs[0], &may23_DW.ECATErrMsgs[0], 20U * sizeof(real_T));

  /* MATLAB Function: '<S73>/record errors' incorporates:
   *  Constant: '<S73>/step time'
   */
  /* MATLAB Function 'DataLogging/Poll KINARM/createKINData/record errors': '<S300>:1' */
  if (!may23_DW.lastECATMessages_not_empty) {
    /* '<S300>:1:5' */
    /* '<S300>:1:6' */
    memcpy(&may23_DW.lastECATMessages[0], &may23_B.ErrMsgs[0], 20U * sizeof
           (real_T));
    may23_DW.lastECATMessages_not_empty = true;
  }

  /* '<S300>:1:13' */
  /* '<S300>:1:16' */
  for (i = 0; i < 4; i++) {
    /* '<S300>:1:16' */
    if ((!(may23_DW.waitingMsgCount >= 50.0)) && (may23_B.ErrMsgs[i + 8] !=
         may23_DW.lastECATMessages[i + 8]) && (may23_B.ErrMsgs[i + 8] != 0.0)) {
      /* '<S300>:1:21' */
      /* '<S300>:1:22' */
      may23_DW.waitingMsgCount++;

      /* '<S300>:1:24' */
      may23_DW.memoryBuffer[(int32_T)may23_DW.waitingMsgCount - 1] =
        may23_B.DataTypeConversion1_d;

      /* '<S300>:1:25' */
      i_0 = (int32_T)may23_DW.waitingMsgCount;
      for (i_1 = 0; i_1 < 5; i_1++) {
        may23_DW.memoryBuffer[(i_0 + 50 * (i_1 + 1)) - 1] = may23_B.ErrMsgs[(i_1
          << 2) + i];
      }
    } else {
      /* '<S300>:1:17' */
    }
  }

  /* '<S300>:1:29' */
  for (i = 0; i < 6; i++) {
    may23_B.newMessage[i] = 0.0;
  }

  if (may23_DW.waitingMsgCount > 0.0) {
    /* '<S300>:1:37' */
    /* '<S300>:1:38' */
    for (i_0 = 0; i_0 < 6; i_0++) {
      may23_B.newMessage[i_0] = may23_DW.memoryBuffer[50 * i_0];
    }

    /* '<S300>:1:39' */
    may23_DW.outCount++;
    if (may23_DW.outCount >= 0.001 / may23_P.BKIN_STEP_TIME) {
      /* '<S300>:1:42' */
      /* '<S300>:1:44' */
      for (i_0 = 0; i_0 < 6; i_0++) {
        for (i_1 = 0; i_1 < 49; i_1++) {
          shoulder_angle = may23_DW.memoryBuffer[(50 * i_0 + i_1) + 1];
          may23_DW.memoryBuffer[i_1 + 50 * i_0] = shoulder_angle;
        }
      }

      /* '<S300>:1:45' */
      may23_DW.waitingMsgCount--;

      /* '<S300>:1:46' */
      may23_DW.sentCount++;

      /* '<S300>:1:47' */
      may23_DW.outCount = 0.0;
      if (may23_DW.waitingMsgCount > 0.0) {
        /* '<S300>:1:50' */
        /* '<S300>:1:51' */
        for (i_0 = 0; i_0 < 6; i_0++) {
          may23_B.newMessage[i_0] = may23_DW.memoryBuffer[50 * i_0];
        }

        /* '<S300>:1:52' */
        may23_DW.outCount = 1.0;
      }
    }
  }

  /* '<S300>:1:57' */
  memcpy(&may23_DW.lastECATMessages[0], &may23_B.ErrMsgs[0], 20U * sizeof(real_T));

  /* '<S300>:1:58' */
  may23_B.sentMessageCount = may23_DW.sentCount;

  /* End of MATLAB Function: '<S73>/record errors' */

  /* Update for UnitDelay: '<S296>/Output' */
  may23_DW.Output_DSTATE_f = may23_B.FixPtSwitch_i;
  may23_DW.createKINData_SubsysRanBC = 4;
}
