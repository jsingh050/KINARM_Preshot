/*
 * Code generation for system system '<S1>/Receive_Gaze'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_Receive_Gaze.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/* Forward declaration for local functions */
static real_T may23_norm(const real_T vec[3]);

/* Function for MATLAB Function: '<S31>/Embedded MATLAB Function1' */
static real_T may23_norm(const real_T vec[3])
{
  real_T vec_0;
  real_T z1_idx_0;
  real_T z1_idx_1;
  vec_0 = vec[0];
  z1_idx_0 = vec_0 * vec_0;
  vec_0 = vec[1];
  z1_idx_1 = vec_0 * vec_0;
  vec_0 = vec[2];
  vec_0 *= vec_0;
  z1_idx_0 += z1_idx_1;
  z1_idx_0 += vec_0;
  return sqrt(z1_idx_0);
}

/* System initialize for atomic system: '<S1>/Receive_Gaze' */
void may23_Receive_Gaze_Init(void)
{
  /* InitializeConditions for RateTransition: '<S31>/Rate Transition' */
  may23_DW.RateTransition_Buffer0[0] = may23_P.RateTransition_InitialCondition;
  may23_DW.RateTransition_Buffer0[1] = may23_P.RateTransition_InitialCondition;
  may23_DW.RateTransition_Buffer0[2] = may23_P.RateTransition_InitialCondition;

  /* SystemInitialize for MATLAB Function: '<S31>/Create timestamp' */
  may23_DW.start_time = -1.0;
  may23_DW.last_time = -1.0;

  /* SystemInitialize for MATLAB Function: '<S31>/convert to seconds2' */
  may23_DW.last_timestamp = 0U;
}

/* Start for atomic system: '<S1>/Receive_Gaze' */
void may23_Receive_Gaze_Start(void)
{
  /* Start for RateTransition: '<S31>/Rate Transition' */
  may23_B.RateTransition_i[0] = may23_P.RateTransition_InitialCondition;
  may23_B.RateTransition_i[1] = may23_P.RateTransition_InitialCondition;
  may23_B.RateTransition_i[2] = may23_P.RateTransition_InitialCondition;

  /* Start for S-Function (slrtUDPReceive): '<S31>/Receive' */
  /* Level2 S-Function Block: '<S31>/Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[34];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }
}

/* Output and update for atomic system: '<S1>/Receive_Gaze' */
void may23_Receive_GazeTID0(void)
{
  real_T target_distance;
  real_T R_CMRA2GLBL[9];
  real_T pupil_CAMERA[3];
  real_T pupil_distance;
  real_T R_HREF2CMRA[9];
  real_T rot_axis[3];
  real_T n[3];
  real_T cosA;
  real_T tmp;
  real_T tmp_0;
  real_T tmp_1;
  real_T tmp_2;
  real_T tmp_3;
  real_T b[9];
  real_T n_0[9];
  real_T R_HREF2CMRA_0[3];
  int32_T i;
  int32_T i_0;
  real_T R_CMRA2GLBL_0;
  real_T href_idx_0;
  real_T href_idx_1;
  real_T raw_pupil_idx_0;
  real_T raw_pupil_idx_1;
  static const real_T v2[3] = { 0.0, 0.0, 1.0 };

  static const int8_T b_a[9] = { 1, 0, 0, 0, 1, 0, 0, 0, 1 };

  /* S-Function (eyelink_unpack): '<S31>/S-Function' */

  /* Level2 S-Function Block: '<S31>/S-Function' (eyelink_unpack) */
  {
    SimStruct *rts = may23_M->childSfunctions[33];
    sfcnOutputs(rts,1);
  }

  /* Reshape: '<S31>/Reshape' */
  may23_B.Reshape_a[0] = may23_B.pupil_X[0];
  may23_B.Reshape_a[1] = may23_B.pupil_X[1];
  may23_B.Reshape_a[2] = may23_B.pupilY[0];
  may23_B.Reshape_a[3] = may23_B.pupilY[1];
  may23_B.Reshape_a[4] = may23_B.HREFX[0];
  may23_B.Reshape_a[5] = may23_B.HREFX[1];
  may23_B.Reshape_a[6] = may23_B.HREFY[0];
  may23_B.Reshape_a[7] = may23_B.HREFY[1];

  /* Selector: '<S31>/Selector - Left Eye' */
  may23_B.SelectorLeftEye[0] = may23_B.Reshape_a[0];

  /* DataTypeConversion: '<S31>/Data Type Conversion3' */
  may23_B.DataTypeConversion3[0] = may23_B.SelectorLeftEye[0];

  /* Selector: '<S31>/Selector - Left Eye' */
  may23_B.SelectorLeftEye[1] = may23_B.Reshape_a[2];

  /* DataTypeConversion: '<S31>/Data Type Conversion3' */
  may23_B.DataTypeConversion3[1] = may23_B.SelectorLeftEye[1];

  /* Selector: '<S31>/Selector - Left Eye' */
  may23_B.SelectorLeftEye[2] = may23_B.Reshape_a[4];

  /* DataTypeConversion: '<S31>/Data Type Conversion3' */
  may23_B.DataTypeConversion3[2] = may23_B.SelectorLeftEye[2];

  /* Selector: '<S31>/Selector - Left Eye' */
  may23_B.SelectorLeftEye[3] = may23_B.Reshape_a[6];

  /* DataTypeConversion: '<S31>/Data Type Conversion3' */
  may23_B.DataTypeConversion3[3] = may23_B.SelectorLeftEye[3];

  /* DataTypeConversion: '<S31>/Data Type Conversion4' */
  may23_B.DataTypeConversion4 = may23_B.pupilarea[0];

  /* DataTypeConversion: '<S31>/Data Type Conversion5' */
  may23_B.DataTypeConversion5 = may23_B.hdata[2];

  /* MATLAB Function: '<S31>/Embedded MATLAB Function1' incorporates:
   *  Constant: '<S31>/EL Camera Angle'
   *  Constant: '<S31>/EL Camera Focal Length'
   *  Constant: '<S31>/EL Camera Position'
   *  Constant: '<S31>/EL Tracking Available'
   */
  /* MATLAB Function 'DataLogging/Receive_Gaze/Embedded MATLAB Function1': '<S309>:1' */
  /* '<S309>:1:37' */
  /* '<S309>:1:7' */
  raw_pupil_idx_0 = may23_B.DataTypeConversion3[0];
  raw_pupil_idx_1 = may23_B.DataTypeConversion3[1];

  /* '<S309>:1:8' */
  href_idx_0 = may23_B.DataTypeConversion3[2];
  href_idx_1 = may23_B.DataTypeConversion3[3];

  /* '<S309>:1:9' */
  target_distance = may23_B.DataTypeConversion5 / 10000.0;
  if ((may23_B.statusflags == 4) || (may23_P.ELTrackingAvailable_Value == 0.0) ||
      ((href_idx_0 == 0.0) && (href_idx_1 == 0.0)) || ((raw_pupil_idx_0 ==
        -32768.0) && (raw_pupil_idx_1 == -32768.0))) {
    /* '<S309>:1:12' */
    /* '<S309>:1:13' */
    may23_B.gazeXYCalculated[0] = -100.0;
    may23_B.gazeXYCalculated[1] = -100.0;

    /* '<S309>:1:14' */
    may23_B.pupil_area_GLOBAL = -100.0;

    /* '<S309>:1:15' */
    may23_B.gaze_unit_vector_GLOBAL[0] = -100.0;
    may23_B.gaze_unit_vector_GLOBAL[1] = -100.0;
    may23_B.gaze_unit_vector_GLOBAL[2] = -100.0;

    /* '<S309>:1:16' */
    may23_B.pupil_GLOBAL[0] = -100.0;
    may23_B.pupil_GLOBAL[1] = -100.0;
    may23_B.pupil_GLOBAL[2] = -100.0;
  } else {
    /* '<S309>:1:20' */
    /* '<S309>:1:134' */
    /* '<S309>:1:135' */
    /* '<S309>:1:136' */
    /* '<S309>:1:131' */
    pupil_distance = may23_P.ELCameraAngle_Value[0] / 180.0 * 3.1415926535897931;

    /* '<S309>:1:132' */
    cosA = may23_P.ELCameraAngle_Value[1] / 180.0 * 3.1415926535897931;

    /* '<S309>:1:133' */
    /* '<S309>:1:134' */
    /* '<S309>:1:135' */
    /* '<S309>:1:136' */
    /* '<S309>:1:21' */
    R_CMRA2GLBL_0 = cos(pupil_distance);
    tmp = sin(pupil_distance);
    tmp_0 = sin(pupil_distance);
    pupil_distance = cos(pupil_distance);
    tmp_1 = cos(cosA);
    tmp_2 = sin(cosA);
    tmp_3 = sin(cosA);
    cosA = cos(cosA);
    b[1] = 0.0;
    b[4] = R_CMRA2GLBL_0;
    b[7] = -tmp;
    b[2] = 0.0;
    b[5] = tmp_0;
    b[8] = pupil_distance;
    n_0[0] = tmp_1;
    n_0[3] = 0.0;
    n_0[6] = tmp_2;
    b[0] = 1.0;
    n_0[1] = 0.0;
    b[3] = 0.0;
    n_0[4] = 1.0;
    b[6] = 0.0;
    n_0[7] = 0.0;
    n_0[2] = -tmp_3;
    n_0[5] = 0.0;
    n_0[8] = cosA;
    for (i_0 = 0; i_0 < 3; i_0++) {
      for (i = 0; i < 3; i++) {
        R_CMRA2GLBL[i + 3 * i_0] = 0.0;
        R_CMRA2GLBL_0 = R_CMRA2GLBL[3 * i_0 + i];
        R_CMRA2GLBL_0 += n_0[3 * i_0] * b[i];
        R_CMRA2GLBL[i + 3 * i_0] = R_CMRA2GLBL_0;
        R_CMRA2GLBL_0 = R_CMRA2GLBL[3 * i_0 + i];
        R_CMRA2GLBL_0 += n_0[3 * i_0 + 1] * b[i + 3];
        R_CMRA2GLBL[i + 3 * i_0] = R_CMRA2GLBL_0;
        R_CMRA2GLBL_0 = R_CMRA2GLBL[3 * i_0 + i];
        R_CMRA2GLBL_0 += n_0[3 * i_0 + 2] * b[i + 6];
        R_CMRA2GLBL[i + 3 * i_0] = R_CMRA2GLBL_0;
      }
    }

    /* '<S309>:1:25' */
    /* '<S309>:1:101' */
    /* '<S309>:1:102' */
    /* '<S309>:1:105' */
    /* '<S309>:1:107' */
    /* '<S309>:1:108' */
    /* '<S309>:1:109' */
    /* '<S309>:1:110' */
    /* '<S309>:1:112' */
    /* '<S309>:1:113' */
    /* '<S309>:1:115' */
    /* '<S309>:1:116' */
    /* '<S309>:1:119' */
    /* '<S309>:1:120' */
    /* '<S309>:1:122' */
    /* '<S309>:1:123' */
    /* '<S309>:1:125' */
    /* '<S309>:1:26' */
    /* '<S309>:1:73' */
    /* '<S309>:1:89' */
    /* '<S309>:1:68' */
    pupil_CAMERA[0] = -((648.0 - (raw_pupil_idx_0 - -40760.869565217392) /
                         65.217391304347814) / 200.0) / 1000.0 * target_distance
      / may23_P.ELCameraFocalLength_Value;
    pupil_CAMERA[1] = (510.0 - (raw_pupil_idx_1 - -41810.34482758621) /
                       86.206896551724142) / 200.0 / 1000.0 * target_distance /
      may23_P.ELCameraFocalLength_Value;
    pupil_CAMERA[2] = target_distance;

    /* '<S309>:1:69' */
    pupil_distance = may23_norm(pupil_CAMERA);

    /* '<S309>:1:73' */
    /* '<S309>:1:156' */
    /* '<S309>:1:143' */
    rot_axis[0] = 0.0 * pupil_CAMERA[2] - pupil_CAMERA[1];
    rot_axis[1] = pupil_CAMERA[0] - 0.0 * pupil_CAMERA[2];
    rot_axis[2] = 0.0 * pupil_CAMERA[1] - 0.0 * pupil_CAMERA[0];
    if ((may23_norm(pupil_CAMERA) == 0.0) || (may23_norm(v2) == 0.0) ||
        (may23_norm(rot_axis) == 0.0)) {
      /* '<S309>:1:148' */
      /* '<S309>:1:149' */
      for (i_0 = 0; i_0 < 9; i_0++) {
        R_HREF2CMRA[i_0] = 0.0;
      }

      R_HREF2CMRA[0] = 1.0;
      R_HREF2CMRA[4] = 1.0;
      R_HREF2CMRA[8] = 1.0;
    } else {
      /* '<S309>:1:151' */
      raw_pupil_idx_0 = asin(may23_norm(rot_axis) / may23_norm(pupil_CAMERA) /
        may23_norm(v2));

      /* '<S309>:1:152' */
      R_CMRA2GLBL_0 = may23_norm(rot_axis);
      n[0] = rot_axis[0] / R_CMRA2GLBL_0;
      n[1] = rot_axis[1] / R_CMRA2GLBL_0;
      n[2] = rot_axis[2] / R_CMRA2GLBL_0;

      /* '<S309>:1:153' */
      /* '<S309>:1:154' */
      cosA = cos(raw_pupil_idx_0);

      /* '<S309>:1:155' */
      raw_pupil_idx_0 = sin(raw_pupil_idx_0);

      /* '<S309>:1:156' */
      b[0] = raw_pupil_idx_0 * 0.0;
      b[3] = raw_pupil_idx_0 * -n[2];
      b[6] = raw_pupil_idx_0 * n[1];
      b[1] = raw_pupil_idx_0 * n[2];
      b[4] = raw_pupil_idx_0 * 0.0;
      b[7] = raw_pupil_idx_0 * -n[0];
      b[2] = raw_pupil_idx_0 * -n[1];
      b[5] = raw_pupil_idx_0 * n[0];
      b[8] = raw_pupil_idx_0 * 0.0;
      R_CMRA2GLBL_0 = 1.0 - cosA;
      for (i_0 = 0; i_0 < 3; i_0++) {
        n_0[3 * i_0] = n[0] * n[i_0];
        n_0[3 * i_0 + 1] = n[1] * n[i_0];
        n_0[3 * i_0 + 2] = n[2] * n[i_0];
      }

      for (i_0 = 0; i_0 < 9; i_0++) {
        R_HREF2CMRA[i_0] = ((real_T)b_a[i_0] * cosA + b[i_0]) + R_CMRA2GLBL_0 *
          n_0[i_0];
      }
    }

    /* '<S309>:1:77' */
    /* '<S309>:1:81' */
    for (i_0 = 0; i_0 < 3; i_0++) {
      R_CMRA2GLBL_0 = R_CMRA2GLBL[i_0] * pupil_CAMERA[0];
      R_CMRA2GLBL_0 += R_CMRA2GLBL[i_0 + 3] * pupil_CAMERA[1];
      R_CMRA2GLBL_0 += R_CMRA2GLBL[i_0 + 6] * pupil_CAMERA[2];
      may23_B.pupil_GLOBAL[i_0] = R_CMRA2GLBL_0 +
        may23_P.ELCameraPosition_Value[i_0];
    }

    /* '<S309>:1:82' */
    /* '<S309>:1:89' */
    /* '<S309>:1:194' */
    /* '<S309>:1:195' */
    pupil_CAMERA[0] = 0.0;
    href_idx_0 = href_idx_0 * pupil_distance / 15000.0;
    pupil_CAMERA[1] = 0.0;
    href_idx_1 = href_idx_1 * pupil_distance / 15000.0;
    pupil_CAMERA[2] = 0.0;
    raw_pupil_idx_0 = 0.0 * pupil_distance / 15000.0;
    for (i_0 = 0; i_0 < 3; i_0++) {
      raw_pupil_idx_1 = R_HREF2CMRA[i_0] * href_idx_0;
      raw_pupil_idx_1 += R_HREF2CMRA[i_0 + 3] * href_idx_1;
      raw_pupil_idx_1 += R_HREF2CMRA[i_0 + 6] * raw_pupil_idx_0;
      R_HREF2CMRA_0[i_0] = raw_pupil_idx_1;
    }

    for (i_0 = 0; i_0 < 3; i_0++) {
      R_CMRA2GLBL_0 = R_CMRA2GLBL[i_0] * R_HREF2CMRA_0[0];
      R_CMRA2GLBL_0 += R_CMRA2GLBL[i_0 + 3] * R_HREF2CMRA_0[1];
      R_CMRA2GLBL_0 += R_CMRA2GLBL[i_0 + 6] * R_HREF2CMRA_0[2];
      n[i_0] = (R_CMRA2GLBL_0 + may23_P.ELCameraPosition_Value[i_0]) -
        may23_B.pupil_GLOBAL[i_0];
    }

    /* '<S309>:1:196' */
    rot_axis[0] = may23_B.pupil_GLOBAL[0];
    rot_axis[1] = may23_B.pupil_GLOBAL[1];
    rot_axis[2] = may23_B.pupil_GLOBAL[2];

    /* '<S309>:1:197' */
    /* '<S309>:1:198' */
    pupil_distance = 0.0 * n[0];
    cosA = 0.0 * rot_axis[0];
    pupil_distance += 0.0 * n[1];
    cosA += 0.0 * rot_axis[1];
    pupil_distance += n[2];
    cosA += rot_axis[2];
    if (!(fabs(pupil_distance) < 1.0E-7)) {
      /* '<S309>:1:211' */
      pupil_distance = -cosA / pupil_distance;

      /* '<S309>:1:212' */
      pupil_CAMERA[0] = pupil_distance * n[0] + may23_B.pupil_GLOBAL[0];
      pupil_CAMERA[1] = pupil_distance * n[1] + may23_B.pupil_GLOBAL[1];
      pupil_CAMERA[2] = pupil_distance * n[2] + may23_B.pupil_GLOBAL[2];
    } else {
      /* '<S309>:1:200' */
    }

    /* '<S309>:1:26' */
    /* '<S309>:1:27' */
    may23_B.gazeXYCalculated[0] = pupil_CAMERA[0];
    may23_B.gazeXYCalculated[1] = pupil_CAMERA[1];

    /* '<S309>:1:31' */
    /* '<S309>:1:34' */
    target_distance /= may23_P.ELCameraFocalLength_Value;

    /* '<S309>:1:37' */
    for (i_0 = 0; i_0 < 3; i_0++) {
      href_idx_0 = R_CMRA2GLBL[i_0] * 0.0;
      href_idx_0 += R_CMRA2GLBL[i_0 + 3] * 0.0;
      href_idx_0 += R_CMRA2GLBL[i_0 + 6];
      rot_axis[i_0] = href_idx_0;
    }

    /* '<S309>:1:40' */
    href_idx_0 = pupil_CAMERA[0];
    href_idx_0 = may23_B.pupil_GLOBAL[0] - href_idx_0;
    pupil_CAMERA[0] = href_idx_0;
    href_idx_0 = pupil_CAMERA[1];
    href_idx_0 = may23_B.pupil_GLOBAL[1] - href_idx_0;
    pupil_CAMERA[1] = href_idx_0;
    href_idx_0 = pupil_CAMERA[2];
    href_idx_0 = may23_B.pupil_GLOBAL[2] - href_idx_0;
    pupil_CAMERA[2] = href_idx_0;

    /* '<S309>:1:41' */
    R_CMRA2GLBL_0 = may23_norm(pupil_CAMERA);

    /* '<S309>:1:44' */
    may23_B.gaze_unit_vector_GLOBAL[0] = pupil_CAMERA[0] / R_CMRA2GLBL_0;
    pupil_distance = rot_axis[0] * may23_B.gaze_unit_vector_GLOBAL[0];
    may23_B.gaze_unit_vector_GLOBAL[1] = pupil_CAMERA[1] / R_CMRA2GLBL_0;
    pupil_distance += rot_axis[1] * may23_B.gaze_unit_vector_GLOBAL[1];
    may23_B.gaze_unit_vector_GLOBAL[2] = pupil_CAMERA[2] / R_CMRA2GLBL_0;
    pupil_distance += rot_axis[2] * may23_B.gaze_unit_vector_GLOBAL[2];

    /* '<S309>:1:50' */
    may23_B.pupil_area_GLOBAL = may23_B.DataTypeConversion4 / 4.0E+10 *
      (target_distance * target_distance) / pupil_distance;
  }

  /* End of MATLAB Function: '<S31>/Embedded MATLAB Function1' */

  /* DataTypeConversion: '<S31>/Convert1' */
  may23_B.Convert1_n = may23_B.pupil_area_GLOBAL;

  /* DataTypeConversion: '<S31>/Data Type Conversion' */
  may23_B.DataTypeConversion_p5 = may23_B.SFunction_o1;

  /* MATLAB Function: '<S31>/Create timestamp' */
  /* MATLAB Function 'DataLogging/Receive_Gaze/Create timestamp': '<S308>:1' */
  if ((may23_DW.start_time == -1.0) && (may23_B.DataTypeConversion_p5 != 0.0)) {
    /* '<S308>:1:14' */
    /* '<S308>:1:15' */
    may23_DW.start_time = may23_B.DataTypeConversion_p5;
  }

  if (may23_B.DataTypeConversion_p5 < may23_DW.start_time) {
    /* '<S308>:1:20' */
    /* '<S308>:1:21' */
    may23_DW.start_time = -(may23_DW.last_time - may23_DW.start_time);
  }

  /* '<S308>:1:24' */
  may23_B.timestamp_out = (may23_B.DataTypeConversion_p5 - may23_DW.start_time) /
    1000.0;

  /* '<S308>:1:25' */
  may23_DW.last_time = may23_B.DataTypeConversion_p5;

  /* '<S308>:1:26' */
  may23_B.start_time_out = may23_DW.start_time;

  /* End of MATLAB Function: '<S31>/Create timestamp' */

  /* DataTypeConversion: '<S31>/Convert19' */
  may23_B.Convert19[0] = may23_B.gazeXYCalculated[0];
  may23_B.Convert19[1] = may23_B.gazeXYCalculated[1];
  may23_B.Convert19[2] = may23_B.timestamp_out;

  /* DataTypeConversion: '<S31>/Convert3' incorporates:
   *  Constant: '<S31>/EL Tracking Available'
   */
  may23_B.Convert3 = may23_P.ELTrackingAvailable_Value;

  /* Gain: '<S31>/Gain' */
  may23_B.Gain_o[0] = may23_P.Gain_Gain * may23_B.gaze_unit_vector_GLOBAL[0];
  may23_B.Gain_o[1] = may23_P.Gain_Gain * may23_B.gaze_unit_vector_GLOBAL[1];
  may23_B.Gain_o[2] = may23_P.Gain_Gain * may23_B.gaze_unit_vector_GLOBAL[2];

  /* DataTypeConversion: '<S31>/Convert4' */
  may23_B.Convert4[0] = may23_B.Gain_o[0];
  may23_B.Convert4[1] = may23_B.Gain_o[1];
  may23_B.Convert4[2] = may23_B.Gain_o[2];

  /* DataTypeConversion: '<S31>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_f[0] = may23_B.SFunction_o18[0];
  may23_B.DataTypeConversion1_f[1] = may23_B.SFunction_o18[1];
  may23_B.DataTypeConversion1_f[2] = may23_B.SFunction_o18[2];

  /* RateTransition: '<S31>/Rate Transition' */
  if (may23_M->Timing.RateInteraction.TID1_3) {
    may23_B.RateTransition_i[0] = may23_DW.RateTransition_Buffer0[0];
    may23_B.RateTransition_i[1] = may23_DW.RateTransition_Buffer0[1];
    may23_B.RateTransition_i[2] = may23_DW.RateTransition_Buffer0[2];

    /* RateTransition: '<S31>/Rate Transition1' */
    may23_DW.RateTransition1_Buffer_j[0] = may23_B.DataTypeConversion1_f[0];
    may23_DW.RateTransition1_Buffer_j[1] = may23_B.DataTypeConversion1_f[1];
    may23_DW.RateTransition1_Buffer_j[2] = may23_B.DataTypeConversion1_f[2];

    /* RateTransition: '<S31>/Rate Transition2' */
    may23_DW.RateTransition2_Buffer_f = may23_B.start_time_out;

    /* RateTransition: '<S31>/Rate Transition3' */
    may23_DW.RateTransition3_Buffer = may23_B.SFunction_o1;
  }

  /* End of RateTransition: '<S31>/Rate Transition' */

  /* S-Function (slrtUDPReceive): '<S31>/Receive' */

  /* Level2 S-Function Block: '<S31>/Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[34];
    sfcnOutputs(rts,1);
  }

  /* DataTypeConversion: '<S31>/convert' */
  R_CMRA2GLBL_0 = floor(may23_B.Receive_o2_f);
  if (rtIsNaN(R_CMRA2GLBL_0) || rtIsInf(R_CMRA2GLBL_0)) {
    R_CMRA2GLBL_0 = 0.0;
  } else {
    R_CMRA2GLBL_0 = fmod(R_CMRA2GLBL_0, 4.294967296E+9);
  }

  may23_B.convert_n = R_CMRA2GLBL_0 < 0.0 ? -(int32_T)(uint32_T)-R_CMRA2GLBL_0 :
    (int32_T)(uint32_T)R_CMRA2GLBL_0;

  /* End of DataTypeConversion: '<S31>/convert' */

  /* MATLAB Function: '<S31>/clean_packet' */
  /* MATLAB Function 'DataLogging/Receive_Gaze/clean_packet': '<S310>:1' */
  if (may23_B.convert_n < 512) {
    /* '<S310>:1:7' */
    /* '<S310>:1:8' */
    memcpy(&may23_B.pack_out[0], &may23_B.Receive_o1_o[0], sizeof(uint8_T) << 9U);

    /* '<S310>:1:9' */
    may23_B.len_out = may23_B.convert_n;
  } else {
    /* '<S310>:1:11' */
    memset(&may23_B.pack_out[0], 0, sizeof(uint8_T) << 9U);

    /* '<S310>:1:12' */
    may23_B.len_out = 0;
  }

  /* End of MATLAB Function: '<S31>/clean_packet' */
}

/* Output and update for atomic system: '<S1>/Receive_Gaze' */
void may23_Receive_GazeTID3(void)
{
  /* RateTransition: '<S31>/Rate Transition1' */
  may23_B.RateTransition1_n[0] = may23_DW.RateTransition1_Buffer_j[0];
  may23_B.RateTransition1_n[1] = may23_DW.RateTransition1_Buffer_j[1];
  may23_B.RateTransition1_n[2] = may23_DW.RateTransition1_Buffer_j[2];

  /* RateTransition: '<S31>/Rate Transition2' */
  may23_B.RateTransition2_l = may23_DW.RateTransition2_Buffer_f;

  /* RateTransition: '<S31>/Rate Transition3' */
  may23_B.RateTransition3_c = may23_DW.RateTransition3_Buffer;

  /* MATLAB Function: '<S31>/convert to seconds2' */
  /* MATLAB Function 'DataLogging/Receive_Gaze/convert to seconds2': '<S311>:1' */
  if (may23_DW.last_timestamp == may23_B.RateTransition3_c) {
    /* '<S311>:1:11' */
    /* '<S311>:1:12' */
    may23_B.event_data_out[0] = 0.0;
    may23_B.event_data_out[1] = 0.0;
    may23_B.event_data_out[2] = 0.0;
  } else {
    /* '<S311>:1:16' */
    may23_DW.last_timestamp = may23_B.RateTransition3_c;

    /* '<S311>:1:17' */
    may23_B.event_data_out[0] = may23_B.RateTransition1_n[0];
    may23_B.event_data_out[1] = may23_B.RateTransition1_n[1];
    may23_B.event_data_out[2] = may23_B.RateTransition1_n[2];
    if (may23_B.RateTransition1_n[0] != 0.0) {
      /* '<S311>:1:19' */
      /* '<S311>:1:20' */
      may23_B.event_data_out[1] = (may23_B.RateTransition1_n[1] -
        may23_B.RateTransition2_l) / 1000.0;

      /* '<S311>:1:21' */
      may23_B.event_data_out[2] = (may23_B.RateTransition1_n[2] -
        may23_B.RateTransition2_l) / 1000.0;
    }
  }

  /* End of MATLAB Function: '<S31>/convert to seconds2' */

  /* DataTypeConversion: '<S31>/Convert2' */
  may23_B.Convert2[0] = may23_B.event_data_out[0];

  /* RateTransition: '<S31>/Rate Transition' */
  may23_DW.RateTransition_Buffer0[0] = may23_B.Convert2[0];

  /* DataTypeConversion: '<S31>/Convert2' */
  may23_B.Convert2[1] = may23_B.event_data_out[1];

  /* RateTransition: '<S31>/Rate Transition' */
  may23_DW.RateTransition_Buffer0[1] = may23_B.Convert2[1];

  /* DataTypeConversion: '<S31>/Convert2' */
  may23_B.Convert2[2] = may23_B.event_data_out[2];

  /* RateTransition: '<S31>/Rate Transition' */
  may23_DW.RateTransition_Buffer0[2] = may23_B.Convert2[2];
}

/* Termination for atomic system: '<S1>/Receive_Gaze' */
void may23_Receive_Gaze_Term(void)
{
  /* Terminate for S-Function (eyelink_unpack): '<S31>/S-Function' */
  /* Level2 S-Function Block: '<S31>/S-Function' (eyelink_unpack) */
  {
    SimStruct *rts = may23_M->childSfunctions[33];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (slrtUDPReceive): '<S31>/Receive' */
  /* Level2 S-Function Block: '<S31>/Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[34];
    sfcnTerminate(rts);
  }
}
