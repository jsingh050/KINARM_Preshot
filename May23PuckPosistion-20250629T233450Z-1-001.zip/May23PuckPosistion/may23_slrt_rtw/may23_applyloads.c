/*
 * Code generation for system system '<S1>/apply loads'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_applyloads.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/* Forward declaration for local functions */
static real_T may23_eml_rand_mt19937ar(uint32_T state[625]);
static real_T may23_rand(void);

/* Function for MATLAB Function: '<S33>/verify NaN' */
static real_T may23_eml_rand_mt19937ar(uint32_T state[625])
{
  real_T r;
  uint32_T u[2];
  uint32_T mti;
  uint32_T y;
  int32_T kk;
  int32_T k;
  boolean_T b_isvalid;
  int32_T exitg1;
  boolean_T exitg2;

  /* ========================= COPYRIGHT NOTICE ============================ */
  /*  This is a uniform (0,1) pseudorandom number generator based on:        */
  /*                                                                         */
  /*  A C-program for MT19937, with initialization improved 2002/1/26.       */
  /*  Coded by Takuji Nishimura and Makoto Matsumoto.                        */
  /*                                                                         */
  /*  Copyright (C) 1997 - 2002, Makoto Matsumoto and Takuji Nishimura,      */
  /*  All rights reserved.                                                   */
  /*                                                                         */
  /*  Redistribution and use in source and binary forms, with or without     */
  /*  modification, are permitted provided that the following conditions     */
  /*  are met:                                                               */
  /*                                                                         */
  /*    1. Redistributions of source code must retain the above copyright    */
  /*       notice, this list of conditions and the following disclaimer.     */
  /*                                                                         */
  /*    2. Redistributions in binary form must reproduce the above copyright */
  /*       notice, this list of conditions and the following disclaimer      */
  /*       in the documentation and/or other materials provided with the     */
  /*       distribution.                                                     */
  /*                                                                         */
  /*    3. The names of its contributors may not be used to endorse or       */
  /*       promote products derived from this software without specific      */
  /*       prior written permission.                                         */
  /*                                                                         */
  /*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS    */
  /*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT      */
  /*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR  */
  /*  A PARTICULAR PURPOSE ARE DISCLAIMED.  IN NO EVENT SHALL THE COPYRIGHT  */
  /*  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,  */
  /*  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT       */
  /*  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,  */
  /*  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY  */
  /*  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT    */
  /*  (INCLUDING  NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE */
  /*  OF THIS  SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.  */
  /*                                                                         */
  /* =============================   END   ================================= */
  do {
    exitg1 = 0;
    for (k = 0; k < 2; k++) {
      mti = state[624] + 1U;
      if (mti >= 625U) {
        for (kk = 0; kk < 227; kk++) {
          y = (state[kk + 1] & 2147483647U) | (state[kk] & 2147483648U);
          if ((y & 1U) == 0U) {
            mti = y >> 1U;
          } else {
            mti = y >> 1U ^ 2567483615U;
          }

          state[kk] = state[kk + 397] ^ mti;
        }

        for (kk = 0; kk < 396; kk++) {
          y = (state[kk + 227] & 2147483648U) | (state[kk + 228] & 2147483647U);
          if ((y & 1U) == 0U) {
            mti = y >> 1U;
          } else {
            mti = y >> 1U ^ 2567483615U;
          }

          state[kk + 227] = state[kk] ^ mti;
        }

        y = (state[623] & 2147483648U) | (state[0] & 2147483647U);
        if ((y & 1U) == 0U) {
          mti = y >> 1U;
        } else {
          mti = y >> 1U ^ 2567483615U;
        }

        state[623] = state[396] ^ mti;
        mti = 1U;
      }

      y = state[(int32_T)mti - 1];
      state[624] = mti;
      y ^= y >> 11U;
      y ^= y << 7U & 2636928640U;
      y ^= y << 15U & 4022730752U;
      y ^= y >> 18U;
      u[k] = y;
    }

    r = ((real_T)(u[0] >> 5U) * 6.7108864E+7 + (real_T)(u[1] >> 6U)) *
      1.1102230246251565E-16;
    if (r == 0.0) {
      if ((state[624] >= 1U) && (state[624] < 625U)) {
        b_isvalid = false;
        k = 1;
        exitg2 = false;
        while ((!exitg2) && (k < 625)) {
          if (state[k - 1] == 0U) {
            k++;
          } else {
            b_isvalid = true;
            exitg2 = true;
          }
        }
      } else {
        b_isvalid = false;
      }

      if (!b_isvalid) {
        mti = 5489U;
        state[0] = 5489U;
        for (k = 0; k < 623; k++) {
          mti = ((mti >> 30U ^ mti) * 1812433253U + k) + 1U;
          state[k + 1] = mti;
        }

        state[624] = 624U;
      }
    } else {
      exitg1 = 1;
    }
  } while (exitg1 == 0);

  return r;
}

/* Function for MATLAB Function: '<S33>/verify NaN' */
static real_T may23_rand(void)
{
  return may23_eml_rand_mt19937ar(may23_DW.state);
}

/* System initialize for atomic system: '<S1>/apply loads' */
void may23_applyloads_Init(void)
{
  uint32_T r;
  int32_T mti;

  /* SystemInitialize for MATLAB Function: '<S33>/verify NaN' */
  may23_DW.check_not_empty = false;
  memset(&may23_DW.state[0], 0, 625U * sizeof(uint32_T));
  r = 5489U;
  may23_DW.state[0] = 5489U;
  for (mti = 0; mti < 623; mti++) {
    r = ((r >> 30U ^ r) * 1812433253U + mti) + 1U;
    may23_DW.state[mti + 1] = r;
  }

  may23_DW.state[624] = 624U;

  /* End of SystemInitialize for MATLAB Function: '<S33>/verify NaN' */
}

/* Start for atomic system: '<S1>/apply loads' */
void may23_applyloads_Start(void)
{
  /* Start for Enabled SubSystem: '<S33>/EtherCAT Apply Loads' */

  /* Start for S-Function (BKINethercatpdotx): '<S317>/BKIN EtherCAT PDO Transmit 1' */
  /* Level2 S-Function Block: '<S317>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[35];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (BKINethercatpdotx): '<S317>/BKIN EtherCAT PDO Transmit 2' */
  /* Level2 S-Function Block: '<S317>/BKIN EtherCAT PDO Transmit 2' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[36];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (BKINethercatpdotx): '<S318>/BKIN EtherCAT PDO Transmit 1' */
  /* Level2 S-Function Block: '<S318>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[37];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (BKINethercatpdotx): '<S318>/BKIN EtherCAT PDO Transmit 2' */
  /* Level2 S-Function Block: '<S318>/BKIN EtherCAT PDO Transmit 2' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[38];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of Start for SubSystem: '<S33>/EtherCAT Apply Loads' */

  /* Start for Enabled SubSystem: '<S33>/apply pmac loads' */
  may23_applypmacloads_Start();

  /* End of Start for SubSystem: '<S33>/apply pmac loads' */
}

/* Output and update for atomic system: '<S1>/apply loads' */
void may23_applyloads(void)
{
  real_T sq;
  int8_T b_data[4];
  int8_T c_data[4];
  int32_T nz;
  boolean_T b_b_idx_0;
  real_T motorTorques_idx_0;
  real_T motorTorques_idx_2;
  real_T motorTorques_idx_3;
  int32_T b_size_idx_0;
  boolean_T b_b_idx_1;
  boolean_T b_b_idx_2;
  boolean_T b_b_idx_3;
  int16_T tmp;

  /* MATLAB Function: '<S33>/verify NaN' */
  /* MATLAB Function 'DataLogging/apply loads/verify NaN': '<S316>:1' */
  if (!may23_DW.check_not_empty) {
    /* '<S316>:1:6' */
    /* '<S316>:1:7' */
    may23_DW.check_not_empty = true;

    /* '<S316>:1:17' */
    sq = may23_rand();
    while (sq > 0.99) {
      /* '<S316>:1:18' */
      /* '<S316>:1:19' */
      sq = may23_rand();
    }

    /* '<S316>:1:22' */
    may23_rand();
    if (!rtIsNaN(sqrt(sq - 0.99))) {
      /* '<S316>:1:32' */
      /* '<S316>:1:33' */
      may23_DW.isWorking = 0.0;

      /* '<S316>:1:34' */
      printf("***WARNING****");
      fflush(stdout);

      /* '<S316>:1:35' */
      printf("Checks for NaN/inf FAIL. No forces will be produced.\n");
      fflush(stdout);
    } else {
      /* '<S316>:1:37' */
      may23_DW.isWorking = 1.0;

      /* '<S316>:1:38' */
      printf("Checks for NaN/inf WORK.\n");
      fflush(stdout);
    }
  }

  /* '<S316>:1:43' */
  may23_B.torques_out[0] = may23_B.Product_g[0];
  may23_B.torques_out[1] = may23_B.Product_g[1];
  may23_B.torques_out[2] = may23_B.Product_g[2];
  may23_B.torques_out[3] = may23_B.Product_g[3];
  if (may23_DW.isWorking != 0.0) {
    b_b_idx_0 = rtIsNaN(may23_B.Product_g[0]);
    b_b_idx_1 = rtIsNaN(may23_B.Product_g[1]);
    b_b_idx_2 = rtIsNaN(may23_B.Product_g[2]);
    b_b_idx_3 = rtIsNaN(may23_B.Product_g[3]);
    nz = b_b_idx_0;
    nz += b_b_idx_1;
    nz += b_b_idx_2;
    nz += b_b_idx_3;
    if (nz > 0) {
      /* '<S316>:1:50' */
      /* '<S316>:1:51' */
      b_b_idx_0 = rtIsNaN(may23_B.Product_g[0]);
      b_b_idx_1 = rtIsNaN(may23_B.Product_g[1]);
      b_b_idx_2 = rtIsNaN(may23_B.Product_g[2]);
      b_b_idx_3 = rtIsNaN(may23_B.Product_g[3]);
      nz = 0;
      if (b_b_idx_0) {
        nz = 1;
      }

      if (b_b_idx_1) {
        nz++;
      }

      if (b_b_idx_2) {
        nz++;
      }

      if (b_b_idx_3) {
        nz++;
      }

      b_size_idx_0 = nz;
      nz = 0;
      if (b_b_idx_0) {
        b_data[0] = 1;
        nz = 1;
      }

      if (b_b_idx_1) {
        b_data[nz] = 2;
        nz++;
      }

      if (b_b_idx_2) {
        b_data[nz] = 3;
        nz++;
      }

      if (b_b_idx_3) {
        b_data[nz] = 4;
      }

      /* '<S316>:1:51' */
      for (nz = 0; nz < b_size_idx_0; nz++) {
        may23_B.torques_out[b_data[nz] - 1] = 0.0;
      }
    }

    b_b_idx_0 = rtIsInf(may23_B.torques_out[0]);
    b_b_idx_1 = rtIsInf(may23_B.torques_out[1]);
    b_b_idx_2 = rtIsInf(may23_B.torques_out[2]);
    b_b_idx_3 = rtIsInf(may23_B.torques_out[3]);
    nz = b_b_idx_0;
    nz += b_b_idx_1;
    nz += b_b_idx_2;
    nz += b_b_idx_3;
    if (nz > 0) {
      /* '<S316>:1:54' */
      /* '<S316>:1:55' */
      b_b_idx_0 = rtIsInf(may23_B.torques_out[0]);
      b_b_idx_1 = rtIsInf(may23_B.torques_out[1]);
      b_b_idx_2 = rtIsInf(may23_B.torques_out[2]);
      b_b_idx_3 = rtIsInf(may23_B.torques_out[3]);
      nz = 0;
      if (b_b_idx_0) {
        nz = 1;
      }

      if (b_b_idx_1) {
        nz++;
      }

      if (b_b_idx_2) {
        nz++;
      }

      if (b_b_idx_3) {
        nz++;
      }

      b_size_idx_0 = nz;
      nz = 0;
      if (b_b_idx_0) {
        c_data[0] = 1;
        nz = 1;
      }

      if (b_b_idx_1) {
        c_data[nz] = 2;
        nz++;
      }

      if (b_b_idx_2) {
        c_data[nz] = 3;
        nz++;
      }

      if (b_b_idx_3) {
        c_data[nz] = 4;
      }

      /* '<S316>:1:55' */
      for (nz = 0; nz < b_size_idx_0; nz++) {
        may23_B.torques_out[c_data[nz] - 1] = 0.0;
      }
    }
  } else {
    /* '<S316>:1:58' */
    may23_B.torques_out[0] = 0.0;
    may23_B.torques_out[1] = 0.0;
    may23_B.torques_out[2] = 0.0;
    may23_B.torques_out[3] = 0.0;
  }

  /* End of MATLAB Function: '<S33>/verify NaN' */

  /* RelationalOperator: '<S314>/Compare' incorporates:
   *  Constant: '<S314>/Constant'
   */
  may23_B.Compare_n = (may23_B.systemtype == may23_P.isecat_const_n);

  /* Outputs for Enabled SubSystem: '<S33>/EtherCAT Apply Loads' incorporates:
   *  EnablePort: '<S312>/Enable1'
   */
  if (may23_B.Compare_n) {
    /* DataStoreRead: '<S312>/Data Store Read' */
    memcpy(&may23_B.DataStoreRead_h[0], &may23_DW.ECATHardware[0], 14U * sizeof
           (real_T));

    /* MATLAB Function: '<S312>/convert torques' */
    /* MATLAB Function 'ECAT Apply Loads/convert torques': '<S319>:1' */
    /* '<S319>:1:5' */
    motorTorques_idx_0 = (may23_B.torques_out[0] - may23_B.torques_out[1]) *
      may23_B.DataStoreRead_h[8];
    sq = may23_B.torques_out[1] * may23_B.DataStoreRead_h[8];
    motorTorques_idx_2 = (may23_B.torques_out[2] - may23_B.torques_out[3]) *
      may23_B.DataStoreRead_h[9];
    motorTorques_idx_3 = may23_B.torques_out[3] * may23_B.DataStoreRead_h[9];

    /* '<S319>:1:13' */
    may23_B.ecatTorques[0] = 0;
    may23_B.ecatTorques[1] = 0;
    may23_B.ecatTorques[2] = 0;
    may23_B.ecatTorques[3] = 0;

    /* '<S319>:1:15' */
    if ((!(may23_B.DataStoreRead_h[0] <= 0.0)) && (!(may23_B.DataStoreRead_h[4] <=
          0.0))) {
      /* '<S319>:1:21' */
      motorTorques_idx_0 = rt_roundd_snf(motorTorques_idx_0 *
        may23_B.DataStoreRead_h[10] / may23_B.DataStoreRead_h[4] * 1000.0 /
        may23_B.DataStoreRead_h[0]);
      if (motorTorques_idx_0 < 32768.0) {
        if (motorTorques_idx_0 >= -32768.0) {
          tmp = (int16_T)motorTorques_idx_0;
        } else {
          tmp = MIN_int16_T;
        }
      } else {
        tmp = MAX_int16_T;
      }

      may23_B.ecatTorques[0] = tmp;
    } else {
      /* '<S319>:1:18' */
    }

    /* '<S319>:1:15' */
    if ((!(may23_B.DataStoreRead_h[1] <= 0.0)) && (!(may23_B.DataStoreRead_h[5] <=
          0.0))) {
      /* '<S319>:1:21' */
      motorTorques_idx_0 = rt_roundd_snf(sq * may23_B.DataStoreRead_h[11] /
        may23_B.DataStoreRead_h[5] * 1000.0 / may23_B.DataStoreRead_h[1]);
      if (motorTorques_idx_0 < 32768.0) {
        if (motorTorques_idx_0 >= -32768.0) {
          tmp = (int16_T)motorTorques_idx_0;
        } else {
          tmp = MIN_int16_T;
        }
      } else {
        tmp = MAX_int16_T;
      }

      may23_B.ecatTorques[1] = tmp;
    } else {
      /* '<S319>:1:18' */
    }

    /* '<S319>:1:15' */
    if ((!(may23_B.DataStoreRead_h[2] <= 0.0)) && (!(may23_B.DataStoreRead_h[6] <=
          0.0))) {
      /* '<S319>:1:21' */
      motorTorques_idx_0 = rt_roundd_snf(motorTorques_idx_2 *
        may23_B.DataStoreRead_h[12] / may23_B.DataStoreRead_h[6] * 1000.0 /
        may23_B.DataStoreRead_h[2]);
      if (motorTorques_idx_0 < 32768.0) {
        if (motorTorques_idx_0 >= -32768.0) {
          tmp = (int16_T)motorTorques_idx_0;
        } else {
          tmp = MIN_int16_T;
        }
      } else {
        tmp = MAX_int16_T;
      }

      may23_B.ecatTorques[2] = tmp;
    } else {
      /* '<S319>:1:18' */
    }

    /* '<S319>:1:15' */
    if ((!(may23_B.DataStoreRead_h[3] <= 0.0)) && (!(may23_B.DataStoreRead_h[7] <=
          0.0))) {
      /* '<S319>:1:21' */
      motorTorques_idx_0 = rt_roundd_snf(motorTorques_idx_3 *
        may23_B.DataStoreRead_h[13] / may23_B.DataStoreRead_h[7] * 1000.0 /
        may23_B.DataStoreRead_h[3]);
      if (motorTorques_idx_0 < 32768.0) {
        if (motorTorques_idx_0 >= -32768.0) {
          tmp = (int16_T)motorTorques_idx_0;
        } else {
          tmp = MIN_int16_T;
        }
      } else {
        tmp = MAX_int16_T;
      }

      may23_B.ecatTorques[3] = tmp;
    } else {
      /* '<S319>:1:18' */
    }

    /* End of MATLAB Function: '<S312>/convert torques' */

    /* S-Function (BKINethercatpdotx): '<S317>/BKIN EtherCAT PDO Transmit 1' */

    /* Level2 S-Function Block: '<S317>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[35];
      sfcnOutputs(rts,1);
    }

    /* S-Function (BKINethercatpdotx): '<S317>/BKIN EtherCAT PDO Transmit 2' */

    /* Level2 S-Function Block: '<S317>/BKIN EtherCAT PDO Transmit 2' (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[36];
      sfcnOutputs(rts,1);
    }

    /* S-Function (BKINethercatpdotx): '<S318>/BKIN EtherCAT PDO Transmit 1' */

    /* Level2 S-Function Block: '<S318>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[37];
      sfcnOutputs(rts,1);
    }

    /* S-Function (BKINethercatpdotx): '<S318>/BKIN EtherCAT PDO Transmit 2' */

    /* Level2 S-Function Block: '<S318>/BKIN EtherCAT PDO Transmit 2' (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[38];
      sfcnOutputs(rts,1);
    }

    srUpdateBC(may23_DW.EtherCATApplyLoads_SubsysRanBC);
  }

  /* End of Outputs for SubSystem: '<S33>/EtherCAT Apply Loads' */

  /* RelationalOperator: '<S315>/Compare' incorporates:
   *  Constant: '<S315>/Constant'
   */
  may23_B.Compare_oi = (may23_B.systemtype == may23_P.isecat1_const);

  /* Outputs for Enabled SubSystem: '<S33>/apply pmac loads' */
  may23_applypmacloads();

  /* End of Outputs for SubSystem: '<S33>/apply pmac loads' */
}

/* Termination for atomic system: '<S1>/apply loads' */
void may23_applyloads_Term(void)
{
  /* Terminate for Enabled SubSystem: '<S33>/EtherCAT Apply Loads' */

  /* Terminate for S-Function (BKINethercatpdotx): '<S317>/BKIN EtherCAT PDO Transmit 1' */
  /* Level2 S-Function Block: '<S317>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[35];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (BKINethercatpdotx): '<S317>/BKIN EtherCAT PDO Transmit 2' */
  /* Level2 S-Function Block: '<S317>/BKIN EtherCAT PDO Transmit 2' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[36];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (BKINethercatpdotx): '<S318>/BKIN EtherCAT PDO Transmit 1' */
  /* Level2 S-Function Block: '<S318>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[37];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (BKINethercatpdotx): '<S318>/BKIN EtherCAT PDO Transmit 2' */
  /* Level2 S-Function Block: '<S318>/BKIN EtherCAT PDO Transmit 2' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[38];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S33>/EtherCAT Apply Loads' */

  /* Terminate for Enabled SubSystem: '<S33>/apply pmac loads' */
  may23_applypmacloads_Term();

  /* End of Terminate for SubSystem: '<S33>/apply pmac loads' */
}
