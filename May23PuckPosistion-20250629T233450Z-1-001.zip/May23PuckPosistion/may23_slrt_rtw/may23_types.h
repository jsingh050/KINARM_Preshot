/*
 * may23_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "may23".
 *
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Target selection: slrt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_may23_types_h_
#define RTW_HEADER_may23_types_h_
#include "rtwtypes.h"
#include "builtin_typeid_types.h"
#include "multiword_types.h"
#include "zero_crossing_types.h"
#ifndef DEFINED_TYPEDEF_FOR_KinRobot_
#define DEFINED_TYPEDEF_FOR_KinRobot_

typedef struct {
  real_T link_lengths[2];
  real_T pointer_offset;
  real_T shoulder_position[2];
  real_T arm_orientation;
  real_T shoulder_angle;
  real_T elbow_angle;
  real_T shoulder_ang_velocity;
  real_T elbow_ang_velocity;
  real_T shoulder_ang_acceleration;
  real_T elbow_ang_acceleration;
  real_T joint_torque_command[2];
  real_T motor_torque_command[2];
  real_T link_angles[2];
  real_T link_angle_velocities[2];
  real_T link_angle_accelerations[2];
  real_T hand_position[2];
  real_T hand_velocities[2];
  real_T hand_accelerations[2];
  real_T elbow_position[2];
  real_T elbow_cart_velocity[2];
  real_T elbow_cart_acceleration[2];
  real_T motor_status;
  real_T fs_force_uvw[3];
  real_T fs_torque_uvw[3];
  real_T fs_force_xyz[3];
  real_T fs_torque_xyz[3];
  real_T fs_timestamp;
  uint32_T fs_status;
  real_T ecat_recorded_torques[2];
  real_T ecat_current_limit_enabled[2];
  real_T ep_grip_sensor;
} KinRobot;

#endif

#ifndef DEFINED_TYPEDEF_FOR_KinGaze_
#define DEFINED_TYPEDEF_FOR_KinGaze_

typedef struct {
  real_T has_gaze;
  real_T feedback_control;
  real_T location[2];
  real_T timestamp;
  real_T pupil_area;
  real_T event[3];
  real_T gaze_vector[3];
  real_T pupil_locatoin[3];
} KinGaze;

#endif

#ifndef DEFINED_TYPEDEF_FOR_KinGeneral_
#define DEFINED_TYPEDEF_FOR_KinGeneral_

typedef struct {
  real_T active_arm;
  real_T delay_estimates[4];
  real_T servo_counter;
  real_T calibration_button_bits;
  real_T robot_arm;
  real_T subject_arm;
} KinGeneral;

#endif

#ifndef DEFINED_TYPEDEF_FOR_KinHandFB_
#define DEFINED_TYPEDEF_FOR_KinHandFB_

typedef struct {
  real_T feed_forward;
  real_T dex_feed_forward;
  real_T arm;
  real_T rad;
  real_T control;
  real_T color;
} KinHandFB;

#endif

#ifndef DEFINED_TYPEDEF_FOR_KinDataStruct_
#define DEFINED_TYPEDEF_FOR_KinDataStruct_

typedef struct {
  KinGeneral general;
  KinHandFB hand_feedback;
  KinGaze gaze;
  KinRobot robot1;
  KinRobot robot2;
  uint32_T ecat_digital_input[8];
} KinDataStruct;

#endif

/* Custom Type definition for MATLAB Function: '<S262>/Robot_data_builder' */
#ifndef struct_tag_sbr0BdzAW6GQX2fQakj4o6C
#define struct_tag_sbr0BdzAW6GQX2fQakj4o6C

struct tag_sbr0BdzAW6GQX2fQakj4o6C
{
  real_T shoPos[5];
  real_T elbPos[5];
  real_T shoVel[5];
  real_T elbVel[5];
  real_T shoAcc;
  real_T elbAcc;
  real_T bHasSecondary;
};

#endif                                 /*struct_tag_sbr0BdzAW6GQX2fQakj4o6C*/

#ifndef typedef_sbr0BdzAW6GQX2fQakj4o6C_may23_T
#define typedef_sbr0BdzAW6GQX2fQakj4o6C_may23_T

typedef struct tag_sbr0BdzAW6GQX2fQakj4o6C sbr0BdzAW6GQX2fQakj4o6C_may23_T;

#endif                               /*typedef_sbr0BdzAW6GQX2fQakj4o6C_may23_T*/

/* Custom Type definition for MATLAB Function: '<S262>/filter_velocities' */
#ifndef struct_tag_shSrZ99dE4twa6ELJRaXlMD
#define struct_tag_shSrZ99dE4twa6ELJRaXlMD

struct tag_shSrZ99dE4twa6ELJRaXlMD
{
  real_T shoVel[3];
  real_T elbVel[3];
  real_T shoVelFilt[3];
  real_T elbVelFilt[3];
  real_T servoCounter[3];
};

#endif                                 /*struct_tag_shSrZ99dE4twa6ELJRaXlMD*/

#ifndef typedef_shSrZ99dE4twa6ELJRaXlMD_may23_T
#define typedef_shSrZ99dE4twa6ELJRaXlMD_may23_T

typedef struct tag_shSrZ99dE4twa6ELJRaXlMD shSrZ99dE4twa6ELJRaXlMD_may23_T;

#endif                               /*typedef_shSrZ99dE4twa6ELJRaXlMD_may23_T*/

/* Custom Type definition for MATLAB Function: '<S86>/create kinematics' */
#ifndef struct_emxArray_real_T_4x100
#define struct_emxArray_real_T_4x100

struct emxArray_real_T_4x100
{
  real_T data[400];
  int32_T size[2];
};

#endif                                 /*struct_emxArray_real_T_4x100*/

#ifndef typedef_emxArray_real_T_4x100_may23_T
#define typedef_emxArray_real_T_4x100_may23_T

typedef struct emxArray_real_T_4x100 emxArray_real_T_4x100_may23_T;

#endif                                 /*typedef_emxArray_real_T_4x100_may23_T*/

/* Custom Type definition for MATLAB Function: '<S33>/verify NaN' */
#ifndef struct_tag_sL6LJlPlxhdTxZzXh5NTaQC
#define struct_tag_sL6LJlPlxhdTxZzXh5NTaQC

struct tag_sL6LJlPlxhdTxZzXh5NTaQC
{
  int32_T intNumBits;
};

#endif                                 /*struct_tag_sL6LJlPlxhdTxZzXh5NTaQC*/

#ifndef typedef_sL6LJlPlxhdTxZzXh5NTaQC_may23_T
#define typedef_sL6LJlPlxhdTxZzXh5NTaQC_may23_T

typedef struct tag_sL6LJlPlxhdTxZzXh5NTaQC sL6LJlPlxhdTxZzXh5NTaQC_may23_T;

#endif                               /*typedef_sL6LJlPlxhdTxZzXh5NTaQC_may23_T*/

/* Parameters (default storage) */
typedef struct P_may23_T_ P_may23_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_may23_T RT_MODEL_may23_T;

#endif                                 /* RTW_HEADER_may23_types_h_ */
