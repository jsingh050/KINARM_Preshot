/*
 * Code generation for system system '<S68>/read_pmac'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_read_pmac.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/* Forward declaration for local functions */
static void may23_circshift(real_T a[5]);
static void may23_calculateVelAcc_aa(const real_T robotStruct_shoPos[5], const
  real_T robotStruct_elbPos[5], const real_T robotStruct_shoVel[5], const real_T
  robotStruct_elbVel[5], real_T robotStruct_shoAcc, real_T robotStruct_elbAcc,
  real_T robotStruct_bHasSecondary, const real_T servoValues[5], const real_T
  robotData[10], real_T robotStructOut_shoVel[5], real_T robotStructOut_elbVel[5],
  real_T *robotStructOut_shoAcc, real_T *robotStructOut_elbAcc, real_T
  *robotStructOut_bHasSecondary);
static void may23_calculateVelAcc_aam(const real_T robotStruct_shoPos[5], const
  real_T robotStruct_elbPos[5], const real_T robotStruct_shoVel[5], const real_T
  robotStruct_elbVel[5], real_T robotStruct_shoAcc, real_T robotStruct_elbAcc,
  real_T robotStruct_bHasSecondary, const real_T servoValues[5], const real_T
  robotData[6], real_T robotStructOut_shoVel[5], real_T robotStructOut_elbVel[5],
  real_T *robotStructOut_shoAcc, real_T *robotStructOut_elbAcc, real_T
  *robotStructOut_bHasSecondary);
static void may23_circshift_f(real_T a[3]);
static void may23_updateValues(shSrZ99dE4twa6ELJRaXlMD_may23_T *robotStruct,
  const real_T robotData[10], uint32_T servoCounter, real_T POLES);

/* Function for MATLAB Function: '<S262>/Robot_data_builder' */
static void may23_circshift(real_T a[5])
{
  real_T b_a[5];
  int32_T i;
  for (i = 0; i < 5; i++) {
    b_a[i] = a[i];
  }

  b_a[4] = b_a[3];
  b_a[3] = b_a[2];
  b_a[2] = b_a[1];
  b_a[1] = b_a[0];
  b_a[0] = a[4];
  for (i = 0; i < 5; i++) {
    a[i] = b_a[i];
  }
}

/* Function for MATLAB Function: '<S262>/Robot_data_builder' */
static void may23_calculateVelAcc_aa(const real_T robotStruct_shoPos[5], const
  real_T robotStruct_elbPos[5], const real_T robotStruct_shoVel[5], const real_T
  robotStruct_elbVel[5], real_T robotStruct_shoAcc, real_T robotStruct_elbAcc,
  real_T robotStruct_bHasSecondary, const real_T servoValues[5], const real_T
  robotData[10], real_T robotStructOut_shoVel[5], real_T robotStructOut_elbVel[5],
  real_T *robotStructOut_shoAcc, real_T *robotStructOut_elbAcc, real_T
  *robotStructOut_bHasSecondary)
{
  real_T stepDuration;
  real_T shoVel;
  real_T elbVel;
  int32_T i;

  /* '<S266>:1:78' */
  *robotStructOut_bHasSecondary = robotStruct_bHasSecondary;

  /* '<S266>:1:79' */
  /* '<S266>:1:84' */
  stepDuration = 0.0;
  if (robotStruct_bHasSecondary != 0.0) {
    /* '<S266>:1:87' */
    stepDuration = (servoValues[0] - servoValues[1]) * 0.00088541674613952634;
    if (stepDuration == 0.0) {
      /* '<S266>:1:88' */
      /* '<S266>:1:89' */
      shoVel = robotStruct_shoVel[0];

      /* '<S266>:1:90' */
      elbVel = robotStruct_elbVel[0];
    } else {
      /* '<S266>:1:92' */
      shoVel = (robotStruct_shoPos[0] - robotStruct_shoPos[1]) / stepDuration;

      /* '<S266>:1:93' */
      elbVel = (robotStruct_elbPos[0] - robotStruct_elbPos[1]) / stepDuration;
    }
  } else {
    /* '<S266>:1:96' */
    shoVel = robotData[2];

    /* '<S266>:1:97' */
    elbVel = robotData[3];
  }

  /* '<S266>:1:100' */
  /* '<S266>:1:72' */
  for (i = 0; i < 5; i++) {
    robotStructOut_shoVel[i] = robotStruct_shoVel[i];
  }

  may23_circshift(robotStructOut_shoVel);

  /* '<S266>:1:73' */
  robotStructOut_shoVel[0] = shoVel;

  /* '<S266>:1:101' */
  /* '<S266>:1:72' */
  for (i = 0; i < 5; i++) {
    robotStructOut_elbVel[i] = robotStruct_elbVel[i];
  }

  may23_circshift(robotStructOut_elbVel);

  /* '<S266>:1:73' */
  robotStructOut_elbVel[0] = elbVel;
  if (robotStruct_bHasSecondary != 0.0) {
    if (stepDuration == 0.0) {
      /* '<S266>:1:104' */
      /* '<S266>:1:105' */
      *robotStructOut_shoAcc = robotStruct_shoAcc;

      /* '<S266>:1:106' */
      *robotStructOut_elbAcc = robotStruct_elbAcc;
    } else {
      /* '<S266>:1:108' */
      *robotStructOut_shoAcc = (robotStruct_shoVel[0] - robotStruct_shoVel[1]) /
        stepDuration;

      /* '<S266>:1:109' */
      *robotStructOut_elbAcc = (robotStruct_elbVel[0] - robotStruct_elbVel[1]) /
        stepDuration;
    }
  } else {
    /* '<S266>:1:112' */
    stepDuration = (servoValues[0] - servoValues[4]) * 0.00088541674613952634;

    /* '<S266>:1:113' */
    *robotStructOut_shoAcc = (robotStruct_shoVel[0] - robotStruct_shoVel[4]) /
      stepDuration;

    /* '<S266>:1:114' */
    *robotStructOut_elbAcc = (robotStruct_elbVel[0] - robotStruct_elbVel[4]) /
      stepDuration;
  }

  /* '<S266>:1:117' */
  /* '<S266>:1:118' */
}

/* Function for MATLAB Function: '<S262>/Robot_data_builder' */
static void may23_calculateVelAcc_aam(const real_T robotStruct_shoPos[5], const
  real_T robotStruct_elbPos[5], const real_T robotStruct_shoVel[5], const real_T
  robotStruct_elbVel[5], real_T robotStruct_shoAcc, real_T robotStruct_elbAcc,
  real_T robotStruct_bHasSecondary, const real_T servoValues[5], const real_T
  robotData[6], real_T robotStructOut_shoVel[5], real_T robotStructOut_elbVel[5],
  real_T *robotStructOut_shoAcc, real_T *robotStructOut_elbAcc, real_T
  *robotStructOut_bHasSecondary)
{
  real_T stepDuration;
  real_T shoVel;
  real_T elbVel;
  int32_T i;

  /* '<S266>:1:78' */
  *robotStructOut_bHasSecondary = robotStruct_bHasSecondary;

  /* '<S266>:1:79' */
  /* '<S266>:1:84' */
  stepDuration = 0.0;
  if (robotStruct_bHasSecondary != 0.0) {
    /* '<S266>:1:87' */
    stepDuration = (servoValues[0] - servoValues[1]) * 0.00088541674613952634;
    if (stepDuration == 0.0) {
      /* '<S266>:1:88' */
      /* '<S266>:1:89' */
      shoVel = robotStruct_shoVel[0];

      /* '<S266>:1:90' */
      elbVel = robotStruct_elbVel[0];
    } else {
      /* '<S266>:1:92' */
      shoVel = (robotStruct_shoPos[0] - robotStruct_shoPos[1]) / stepDuration;

      /* '<S266>:1:93' */
      elbVel = (robotStruct_elbPos[0] - robotStruct_elbPos[1]) / stepDuration;
    }
  } else {
    /* '<S266>:1:96' */
    shoVel = robotData[2];

    /* '<S266>:1:97' */
    elbVel = robotData[3];
  }

  /* '<S266>:1:100' */
  /* '<S266>:1:72' */
  for (i = 0; i < 5; i++) {
    robotStructOut_shoVel[i] = robotStruct_shoVel[i];
  }

  may23_circshift(robotStructOut_shoVel);

  /* '<S266>:1:73' */
  robotStructOut_shoVel[0] = shoVel;

  /* '<S266>:1:101' */
  /* '<S266>:1:72' */
  for (i = 0; i < 5; i++) {
    robotStructOut_elbVel[i] = robotStruct_elbVel[i];
  }

  may23_circshift(robotStructOut_elbVel);

  /* '<S266>:1:73' */
  robotStructOut_elbVel[0] = elbVel;
  if (robotStruct_bHasSecondary != 0.0) {
    if (stepDuration == 0.0) {
      /* '<S266>:1:104' */
      /* '<S266>:1:105' */
      *robotStructOut_shoAcc = robotStruct_shoAcc;

      /* '<S266>:1:106' */
      *robotStructOut_elbAcc = robotStruct_elbAcc;
    } else {
      /* '<S266>:1:108' */
      *robotStructOut_shoAcc = (robotStruct_shoVel[0] - robotStruct_shoVel[1]) /
        stepDuration;

      /* '<S266>:1:109' */
      *robotStructOut_elbAcc = (robotStruct_elbVel[0] - robotStruct_elbVel[1]) /
        stepDuration;
    }
  } else {
    /* '<S266>:1:112' */
    stepDuration = (servoValues[0] - servoValues[4]) * 0.00088541674613952634;

    /* '<S266>:1:113' */
    *robotStructOut_shoAcc = (robotStruct_shoVel[0] - robotStruct_shoVel[4]) /
      stepDuration;

    /* '<S266>:1:114' */
    *robotStructOut_elbAcc = (robotStruct_elbVel[0] - robotStruct_elbVel[4]) /
      stepDuration;
  }

  /* '<S266>:1:117' */
  /* '<S266>:1:118' */
}

/* Function for MATLAB Function: '<S262>/filter_velocities' */
static void may23_circshift_f(real_T a[3])
{
  real_T b_a_idx_2;
  real_T b_a_idx_0;
  real_T b_a_idx_1;
  b_a_idx_1 = a[1];
  b_a_idx_2 = a[2];
  b_a_idx_0 = b_a_idx_1;
  b_a_idx_1 = b_a_idx_2;
  b_a_idx_2 = a[0];
  a[0] = b_a_idx_0;
  a[1] = b_a_idx_1;
  a[2] = b_a_idx_2;
}

/* Function for MATLAB Function: '<S262>/filter_velocities' */
static void may23_updateValues(shSrZ99dE4twa6ELJRaXlMD_may23_T *robotStruct,
  const real_T robotData[10], uint32_T servoCounter, real_T POLES)
{
  real_T b[3];
  real_T c[3];
  real_T b_0;
  if (!(robotStruct->servoCounter[(int32_T)(POLES + 1.0) - 1] == servoCounter))
  {
    /* '<S267>:1:47' */
    /* '<S267>:1:38' */
    may23_circshift_f(robotStruct->servoCounter);

    /* '<S267>:1:39' */
    robotStruct->servoCounter[2] = servoCounter;

    /* '<S267>:1:49' */
    /* '<S267>:1:61' */
    /* '<S267>:1:63' */
    /* '<S267>:1:38' */
    b[0] = robotStruct->shoVel[0];
    b[1] = robotStruct->shoVel[1];
    b[2] = robotStruct->shoVel[2];
    may23_circshift_f(b);

    /* '<S267>:1:39' */
    b[2] = robotData[2] / 1342.624471;

    /* '<S267>:1:64' */
    /* '<S267>:1:38' */
    c[0] = robotStruct->shoVelFilt[0];
    c[1] = robotStruct->shoVelFilt[1];
    c[2] = robotStruct->shoVelFilt[2];
    may23_circshift_f(c);

    /* '<S267>:1:39' */
    c[2] = 0.0;

    /* '<S267>:1:66' */
    c[(int32_T)(POLES + 1.0) - 1] = (((b[1] * 2.0 + b[0]) + robotData[2] /
      1342.624471) + c[0] * -0.9243128082) + c[1] * 1.9213335686;
    if (rtIsNaN(c[(int32_T)(POLES + 1.0) - 1]) || rtIsInf(c[(int32_T)(POLES +
          1.0) - 1])) {
      /* '<S267>:1:72' */
      /* '<S267>:1:73' */
      c[(int32_T)(POLES + 1.0) - 1] = 0.0;
    }

    /* '<S267>:1:49' */
    /* '<S267>:1:50' */
    /* '<S267>:1:61' */
    /* '<S267>:1:63' */
    /* '<S267>:1:38' */
    b_0 = b[0];
    robotStruct->shoVel[0] = b_0;
    robotStruct->shoVelFilt[0] = c[0];
    b_0 = robotStruct->elbVel[0];
    b[0] = b_0;
    b_0 = b[1];
    robotStruct->shoVel[1] = b_0;
    robotStruct->shoVelFilt[1] = c[1];
    b_0 = robotStruct->elbVel[1];
    b[1] = b_0;
    b_0 = b[2];
    robotStruct->shoVel[2] = b_0;
    robotStruct->shoVelFilt[2] = c[2];
    b_0 = robotStruct->elbVel[2];
    b[2] = b_0;
    may23_circshift_f(b);

    /* '<S267>:1:39' */
    b[2] = robotData[3] / 1342.624471;

    /* '<S267>:1:64' */
    /* '<S267>:1:38' */
    c[0] = robotStruct->elbVelFilt[0];
    c[1] = robotStruct->elbVelFilt[1];
    c[2] = robotStruct->elbVelFilt[2];
    may23_circshift_f(c);

    /* '<S267>:1:39' */
    c[2] = 0.0;

    /* '<S267>:1:66' */
    c[(int32_T)(POLES + 1.0) - 1] = (((b[1] * 2.0 + b[0]) + robotData[3] /
      1342.624471) + c[0] * -0.9243128082) + c[1] * 1.9213335686;
    if (rtIsNaN(c[(int32_T)(POLES + 1.0) - 1]) || rtIsInf(c[(int32_T)(POLES +
          1.0) - 1])) {
      /* '<S267>:1:72' */
      /* '<S267>:1:73' */
      c[(int32_T)(POLES + 1.0) - 1] = 0.0;
    }

    /* '<S267>:1:50' */
    robotStruct->elbVel[0] = b[0];
    robotStruct->elbVelFilt[0] = c[0];
    robotStruct->elbVel[1] = b[1];
    robotStruct->elbVelFilt[1] = c[1];
    robotStruct->elbVel[2] = b[2];
    robotStruct->elbVelFilt[2] = c[2];
  } else {
    /* '<S267>:1:43' */
  }
}

/* System initialize for enable system: '<S68>/read_pmac' */
void may23_read_pmac_Init(void)
{
  int32_T i;
  static const sbr0BdzAW6GQX2fQakj4o6C_may23_T tmp = { { 0.0, 0.0, 0.0, 0.0, 0.0
    },                                 /* shoPos */
    { 0.0, 0.0, 0.0, 0.0, 0.0 },       /* elbPos */
    { 0.0, 0.0, 0.0, 0.0, 0.0 },       /* shoVel */
    { 0.0, 0.0, 0.0, 0.0, 0.0 },       /* elbVel */
    0.0,                               /* shoAcc */
    0.0,                               /* elbAcc */
    0.0                                /* bHasSecondary */
  };

  static const shSrZ99dE4twa6ELJRaXlMD_may23_T tmp_0 = { { 0.0, 0.0, 0.0 },/* shoVel */
    { 0.0, 0.0, 0.0 },                 /* elbVel */
    { 0.0, 0.0, 0.0 },                 /* shoVelFilt */
    { 0.0, 0.0, 0.0 },                 /* elbVelFilt */
    { 0.0, 0.0, 0.0 }                  /* servoCounter */
  };

  /* InitializeConditions for UnitDelay: '<S268>/Output' */
  may23_DW.Output_DSTATE_d2 = may23_P.Output_InitialCondition_o;

  /* InitializeConditions for UnitDelay: '<S264>/Unit Delay' */
  may23_DW.UnitDelay_DSTATE = may23_P.UnitDelay_InitialCondition_c;

  /* InitializeConditions for UnitDelay: '<S264>/Unit Delay2' */
  may23_DW.UnitDelay2_DSTATE = may23_P.UnitDelay2_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S264>/Unit Delay1' */
  may23_DW.UnitDelay1_DSTATE = may23_P.UnitDelay1_InitialCondition;

  /* InitializeConditions for UnitDelay: '<S264>/Unit Delay3' */
  may23_DW.UnitDelay3_DSTATE = may23_P.UnitDelay3_InitialCondition;

  /* SystemInitialize for MATLAB Function: '<S262>/Monitor_status' */
  may23_DW.no_update_count = 0.0;
  may23_DW.last_servo_counter = 0U;

  /* SystemInitialize for MATLAB Function: '<S262>/Robot_data_builder' */
  may23_DW.robot1Struct = tmp;
  may23_DW.robot2Struct = may23_DW.robot1Struct;
  may23_DW.robot1StructPrimary = may23_DW.robot1Struct;
  may23_DW.robot2StructPrimary = may23_DW.robot1Struct;
  for (i = 0; i < 5; i++) {
    may23_DW.servoValuesR1[i] = 0.0;
    may23_DW.servoValuesR2[i] = 0.0;
  }

  /* End of SystemInitialize for MATLAB Function: '<S262>/Robot_data_builder' */

  /* SystemInitialize for MATLAB Function: '<S262>/filter_velocities' */
  may23_DW.robot1Struct_d = tmp_0;
  may23_DW.robot2Struct_o = may23_DW.robot1Struct_d;
}

/* Start for enable system: '<S68>/read_pmac' */
void may23_read_pmac_Start(void)
{
  /* Start for S-Function (mcc_pollall): '<S262>/S-Function' */
  /* Level2 S-Function Block: '<S262>/S-Function' (mcc_pollall) */
  {
    SimStruct *rts = may23_M->childSfunctions[25];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (mcc_writemem): '<S264>/Write' */
  /* Level2 S-Function Block: '<S264>/Write' (mcc_writemem) */
  {
    SimStruct *rts = may23_M->childSfunctions[26];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for IfAction SubSystem: '<S264>/Read DPRAM' */

  /* Start for S-Function (mcc_readmem): '<S269>/Read' */
  /* Level2 S-Function Block: '<S269>/Read' (mcc_readmem) */
  {
    SimStruct *rts = may23_M->childSfunctions[23];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of Start for SubSystem: '<S264>/Read DPRAM' */

  /* Start for IfAction SubSystem: '<S264>/Write DPRAM' */

  /* Start for S-Function (mcc_writemem): '<S271>/Write' */
  /* Level2 S-Function Block: '<S271>/Write' (mcc_writemem) */
  {
    SimStruct *rts = may23_M->childSfunctions[24];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of Start for SubSystem: '<S264>/Write DPRAM' */
}

/* Outputs for enable system: '<S68>/read_pmac' */
void may23_read_pmac(void)
{
  real32_T y;
  uint32_T temp;
  int32_T i;
  real_T tmp[5];
  real_T tmp_0[5];
  real_T tmp_1;
  uint32_T u1;
  real_T tmp_2;
  real_T tmp_3;

  /* Outputs for Enabled SubSystem: '<S68>/read_pmac' incorporates:
   *  EnablePort: '<S262>/Enable'
   */
  if (may23_B.Compare_f) {
    /* DataTypeConversion: '<S262>/Data Type Conversion' incorporates:
     *  Constant: '<S290>/Arm Encoder Orientation 1'
     *  Constant: '<S290>/Arm Encoder Orientation 2'
     *  Constant: '<S290>/Arm primary encoder counts'
     *  Constant: '<S290>/Arm secondary encoder counts'
     */
    may23_B.DataTypeConversion_g5x[0] = (real32_T)may23_B.ArmOrientation_f;
    may23_B.DataTypeConversion_g5x[1] = (real32_T)may23_B.M1orientation_b;
    may23_B.DataTypeConversion_g5x[2] = (real32_T)may23_B.M2Orientation_k;
    may23_B.DataTypeConversion_g5x[3] = (real32_T)may23_B.M1GearRatio_p;
    may23_B.DataTypeConversion_g5x[4] = (real32_T)may23_B.M2GearRatio_i;
    may23_B.DataTypeConversion_g5x[5] = (real32_T)may23_B.HasSecondaryEnc_n;
    may23_B.DataTypeConversion_g5x[6] = (real32_T)
      may23_P.ArmEncoderOrientation1_Value;
    may23_B.DataTypeConversion_g5x[7] = (real32_T)
      may23_P.ArmEncoderOrientation2_Value;
    may23_B.DataTypeConversion_g5x[8] = (real32_T)
      may23_P.Armprimaryencodercounts_Value;
    may23_B.DataTypeConversion_g5x[9] = (real32_T)
      may23_P.Armsecondaryencodercounts_Value;

    /* DataTypeConversion: '<S262>/Data Type Conversion1' incorporates:
     *  Constant: '<S291>/Arm Encoder Orientation 1'
     *  Constant: '<S291>/Arm Encoder Orientation 2'
     *  Constant: '<S291>/Arm primary encoder counts'
     *  Constant: '<S291>/Arm secondary encoder counts'
     */
    may23_B.DataTypeConversion1_pf[0] = (real32_T)may23_B.ArmOrientation_m;
    may23_B.DataTypeConversion1_pf[1] = (real32_T)may23_B.M1orientation_f;
    may23_B.DataTypeConversion1_pf[2] = (real32_T)may23_B.M2Orientation_c;
    may23_B.DataTypeConversion1_pf[3] = (real32_T)may23_B.M1GearRatio_a;
    may23_B.DataTypeConversion1_pf[4] = (real32_T)may23_B.M2GearRatio_ie;
    may23_B.DataTypeConversion1_pf[5] = (real32_T)may23_B.HasSecondaryEnc_c;
    may23_B.DataTypeConversion1_pf[6] = (real32_T)
      may23_P.ArmEncoderOrientation1_Value_b;
    may23_B.DataTypeConversion1_pf[7] = (real32_T)
      may23_P.ArmEncoderOrientation2_Value_m;
    may23_B.DataTypeConversion1_pf[8] = (real32_T)
      may23_P.Armprimaryencodercounts_Value_n;
    may23_B.DataTypeConversion1_pf[9] = (real32_T)
      may23_P.Armsecondaryencodercounts_Value_p;

    /* DataTypeConversion: '<S262>/Data Type Conversion2' incorporates:
     *  Constant: '<S262>/step duration'
     */
    may23_B.DataTypeConversion2_n = (real32_T)may23_P.BKIN_STEP_TIME;

    /* S-Function (mcc_pollall): '<S262>/S-Function' */

    /* Level2 S-Function Block: '<S262>/S-Function' (mcc_pollall) */
    {
      SimStruct *rts = may23_M->childSfunctions[25];
      sfcnOutputs(rts,1);
    }

    /* DataTypeConversion: '<S264>/Data Type Conversion' incorporates:
     *  Constant: '<S264>/DPRAM WatchDog offset'
     */
    tmp_1 = may23_P.DPRAMWatchDogoffset_Value;
    if (tmp_1 < 4.294967296E+9) {
      if (tmp_1 >= 0.0) {
        temp = (uint32_T)tmp_1;
      } else {
        temp = 0U;
      }
    } else {
      temp = MAX_uint32_T;
    }

    may23_B.DataTypeConversion_g5 = temp;

    /* End of DataTypeConversion: '<S264>/Data Type Conversion' */

    /* UnitDelay: '<S268>/Output' */
    may23_B.Output_c = may23_DW.Output_DSTATE_d2;

    /* MATLAB Function: '<S264>/TypeCast' */
    /* MATLAB Function 'DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/DPRAM Access Subsystem/TypeCast': '<S270>:1' */
    /* '<S270>:1:9' */
    temp = may23_B.Output_c;

    /* '<S270>:1:10' */
    memcpy((void *)&y, (void *)&temp, (uint32_T)((size_t)1 * sizeof(real32_T)));
    may23_B.y_h = y;

    /* S-Function (mcc_writemem): '<S264>/Write' */

    /* Level2 S-Function Block: '<S264>/Write' (mcc_writemem) */
    {
      SimStruct *rts = may23_M->childSfunctions[26];
      sfcnOutputs(rts,1);
    }

    /* Sum: '<S272>/FixPt Sum1' incorporates:
     *  Constant: '<S272>/FixPt Constant'
     */
    may23_B.FixPtSum1_lg = (uint16_T)((uint32_T)may23_B.Output_c +
      may23_P.FixPtConstant_Value_n);

    /* Switch: '<S273>/FixPt Switch' incorporates:
     *  Constant: '<S273>/Constant'
     */
    if (may23_B.FixPtSum1_lg > may23_P.WrapToZero_Threshold_cm) {
      may23_B.FixPtSwitch_ey = may23_P.Constant_Value_pq;
    } else {
      may23_B.FixPtSwitch_ey = may23_B.FixPtSum1_lg;
    }

    /* End of Switch: '<S273>/FixPt Switch' */

    /* UnitDelay: '<S264>/Unit Delay' */
    may23_B.UnitDelay = may23_DW.UnitDelay_DSTATE;

    /* UnitDelay: '<S264>/Unit Delay2' */
    may23_B.UnitDelay2 = may23_DW.UnitDelay2_DSTATE;

    /* If: '<S264>/If' */
    if (may23_B.UnitDelay2 > may23_B.UnitDelay) {
      /* Outputs for IfAction SubSystem: '<S264>/Read DPRAM' incorporates:
       *  ActionPort: '<S269>/Action Port'
       */
      /* DataTypeConversion: '<S269>/Data Type Conversion' incorporates:
       *  Constant: '<S264>/DPRAM Read Offset'
       */
      tmp_1 = may23_P.DPRAMReadOffset_Value;
      if (tmp_1 < 4.294967296E+9) {
        if (tmp_1 >= 0.0) {
          temp = (uint32_T)tmp_1;
        } else {
          temp = 0U;
        }
      } else {
        temp = MAX_uint32_T;
      }

      may23_B.DataTypeConversion_c = temp;

      /* End of DataTypeConversion: '<S269>/Data Type Conversion' */

      /* DataTypeConversion: '<S269>/Data Type Conversion2' incorporates:
       *  Constant: '<S264>/Read as UInt32'
       */
      tmp_1 = may23_P.ReadasUInt32_Value;
      if (tmp_1 < 4.294967296E+9) {
        if (tmp_1 >= 0.0) {
          temp = (uint32_T)tmp_1;
        } else {
          temp = 0U;
        }
      } else {
        temp = MAX_uint32_T;
      }

      may23_B.DataTypeConversion2_o = temp;

      /* End of DataTypeConversion: '<S269>/Data Type Conversion2' */

      /* S-Function (mcc_readmem): '<S269>/Read' */

      /* Level2 S-Function Block: '<S269>/Read' (mcc_readmem) */
      {
        SimStruct *rts = may23_M->childSfunctions[23];
        sfcnOutputs(rts,1);
      }

      /* DataTypeConversion: '<S269>/Data Type Conversion1' */
      may23_B.DataTypeConversion1_g = may23_B.Read_h;

      /* End of Outputs for SubSystem: '<S264>/Read DPRAM' */

      /* Update for IfAction SubSystem: '<S264>/Read DPRAM' incorporates:
       *  ActionPort: '<S269>/Action Port'
       */
      /* Update for If: '<S264>/If' */
      srUpdateBC(may23_DW.ReadDPRAM_SubsysRanBC);

      /* End of Update for SubSystem: '<S264>/Read DPRAM' */
    }

    /* End of If: '<S264>/If' */

    /* Gain: '<S264>/DPRAM Read Value' */
    may23_B.DPRAMReadValue = may23_P.DPRAMReadValue_Gain *
      may23_B.DataTypeConversion1_g;

    /* UnitDelay: '<S264>/Unit Delay1' */
    may23_B.UnitDelay1 = may23_DW.UnitDelay1_DSTATE;

    /* UnitDelay: '<S264>/Unit Delay3' */
    may23_B.UnitDelay3 = may23_DW.UnitDelay3_DSTATE;

    /* If: '<S264>/If1' */
    if (may23_B.UnitDelay3 > may23_B.UnitDelay1) {
      /* Outputs for IfAction SubSystem: '<S264>/Write DPRAM' incorporates:
       *  ActionPort: '<S271>/Action Port'
       */
      /* DataTypeConversion: '<S271>/Data Type Conversion' incorporates:
       *  Constant: '<S264>/DPRAM Write Offset'
       */
      tmp_1 = may23_P.DPRAMWriteOffset_Value;
      if (tmp_1 < 4.294967296E+9) {
        if (tmp_1 >= 0.0) {
          temp = (uint32_T)tmp_1;
        } else {
          temp = 0U;
        }
      } else {
        temp = MAX_uint32_T;
      }

      may23_B.DataTypeConversion_n3 = temp;

      /* End of DataTypeConversion: '<S271>/Data Type Conversion' */

      /* DataTypeConversion: '<S271>/Data Type Conversion1' incorporates:
       *  Constant: '<S264>/DPRAM Write Value'
       */
      may23_B.DataTypeConversion1_o3 = (real32_T)may23_P.DPRAMWriteValue_Value;

      /* S-Function (mcc_writemem): '<S271>/Write' */

      /* Level2 S-Function Block: '<S271>/Write' (mcc_writemem) */
      {
        SimStruct *rts = may23_M->childSfunctions[24];
        sfcnOutputs(rts,1);
      }

      /* End of Outputs for SubSystem: '<S264>/Write DPRAM' */

      /* Update for IfAction SubSystem: '<S264>/Write DPRAM' incorporates:
       *  ActionPort: '<S271>/Action Port'
       */
      /* Update for If: '<S264>/If1' */
      srUpdateBC(may23_DW.WriteDPRAM_SubsysRanBC);

      /* End of Update for SubSystem: '<S264>/Write DPRAM' */
    }

    /* End of If: '<S264>/If1' */

    /* DataTypeConversion: '<S262>/Conversion1' */
    for (i = 0; i < 6; i++) {
      may23_B.Conversion1[i] = may23_B.SFunction_o6[i];
    }

    /* End of DataTypeConversion: '<S262>/Conversion1' */

    /* DataTypeConversion: '<S262>/Conversion2' */
    for (i = 0; i < 6; i++) {
      may23_B.Conversion2[i] = may23_B.SFunction_o5[i];
    }

    /* End of DataTypeConversion: '<S262>/Conversion2' */

    /* DataTypeConversion: '<S262>/Conversion7' */
    may23_B.Conversion7[0] = may23_B.SFunction_o4[0];
    may23_B.Conversion7[1] = may23_B.SFunction_o4[1];
    may23_B.Conversion7[2] = may23_B.SFunction_o4[2];
    may23_B.Conversion7[3] = may23_B.SFunction_o4[3];

    /* DataTypeConversion: '<S262>/Convert2' */
    may23_B.Convert2_o[0] = may23_B.SFunction_o9[0];
    may23_B.Convert2_o[1] = may23_B.SFunction_o9[1];
    may23_B.Convert2_o[2] = may23_B.SFunction_o9[2];

    /* DataTypeConversion: '<S262>/Data Type Conversion3' */
    for (i = 0; i < 10; i++) {
      may23_B.DataTypeConversion3_d[i] = may23_B.SFunction_o1_j[i];
    }

    /* End of DataTypeConversion: '<S262>/Data Type Conversion3' */

    /* DataTypeConversion: '<S262>/Data Type Conversion4' */
    for (i = 0; i < 10; i++) {
      may23_B.DataTypeConversion4_m[i] = may23_B.SFunction_o2[i];
    }

    /* End of DataTypeConversion: '<S262>/Data Type Conversion4' */

    /* MinMax: '<S262>/MinMax' */
    temp = may23_B.SFunction_o3[0];
    u1 = may23_B.SFunction_o3[1];
    if (temp <= u1) {
      temp = u1;
    }

    may23_B.MinMax_o = temp;

    /* End of MinMax: '<S262>/MinMax' */

    /* MinMax: '<S262>/MinMax1' */
    temp = may23_B.SFunction_o3[0];
    u1 = may23_B.SFunction_o3[1];
    if (temp <= u1) {
      temp = u1;
    }

    may23_B.MinMax1 = temp;

    /* End of MinMax: '<S262>/MinMax1' */

    /* MATLAB Function: '<S262>/Monitor_status' incorporates:
     *  Constant: '<S262>/robot_count'
     */
    /* MATLAB Function 'DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Monitor_status': '<S265>:1' */
    /* '<S265>:1:14' */
    /* '<S265>:1:15' */
    /* '<S265>:1:16' */
    may23_B.force_scale = 1.0;
    if ((may23_B.SFunction_o10 >= 6.0F) && (may23_B.SFunction_o10 < 1000.0F)) {
      /* '<S265>:1:19' */
      if ((may23_B.SFunction_o9[2] == 4U) && (may23_DW.last_servo_counter ==
           may23_B.MinMax_o)) {
        /* '<S265>:1:21' */
        /* '<S265>:1:22' */
        may23_DW.no_update_count++;
        if (may23_DW.no_update_count >= 5.0) {
          /* '<S265>:1:24' */
          /* '<S265>:1:25' */
          may23_B.force_scale = 0.0;
        }
      } else {
        /* '<S265>:1:28' */
        may23_DW.no_update_count = 0.0;
      }

      /* '<S265>:1:30' */
      may23_DW.last_servo_counter = may23_B.MinMax_o;
    }

    if ((may23_B.SFunction_o10 >= 7.0F) && (may23_B.SFunction_o10 < 1000.0F)) {
      /* '<S265>:1:34' */
      if ((may23_P.robot_count_Value == 1.0) && ((int32_T)(may23_B.SFunction_o9
            [1] & 1U) == 1)) {
        /* '<S265>:1:36' */
        /* '<S265>:1:37' */
        may23_B.force_scale = 0.0;
      } else {
        if ((may23_P.robot_count_Value == 2.0) && ((may23_B.SFunction_o9[1] & 3U)
             != 0U)) {
          /* '<S265>:1:39' */
          /* '<S265>:1:40' */
          may23_B.force_scale = 0.0;
        }
      }
    }

    if (may23_B.SFunction_o10 == 0.0F) {
      /* '<S265>:1:44' */
      /* '<S265>:1:45' */
      may23_B.force_scale = 0.0;
    }

    /* End of MATLAB Function: '<S262>/Monitor_status' */

    /* MATLAB Function: '<S262>/Robot_data_builder' */
    /* MATLAB Function 'DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/Robot_data_builder': '<S266>:1' */
    if (may23_B.SFunction_o10 < 7.0F) {
      /* '<S266>:1:14' */
      /* '<S266>:1:15' */
      /* '<S266>:1:16' */
      memcpy(&may23_B.robot1DataOut_k[0], &may23_B.DataTypeConversion3_d[0], 10U
             * sizeof(real_T));
      memcpy(&may23_B.robot2DataOut_i[0], &may23_B.DataTypeConversion4_m[0], 10U
             * sizeof(real_T));

      /* '<S266>:1:17' */
      for (i = 0; i < 6; i++) {
        may23_B.robot1PrimaryEncDataOut[i] = may23_B.Conversion2[i];
      }

      /* '<S266>:1:18' */
      for (i = 0; i < 6; i++) {
        may23_B.robot2PrimaryEncDataOut[i] = may23_B.Conversion1[i];
      }
    } else {
      if (may23_B.SFunction_o3[0] != may23_DW.servoValuesR1[0]) {
        /* '<S266>:1:22' */
        /* '<S266>:1:23' */
        /* '<S266>:1:66' */
        /* '<S266>:1:72' */
        may23_circshift(may23_DW.robot1Struct.shoPos);

        /* '<S266>:1:73' */
        may23_DW.robot1Struct.shoPos[0] = may23_B.DataTypeConversion3_d[0];

        /* '<S266>:1:67' */
        /* '<S266>:1:72' */
        may23_circshift(may23_DW.robot1Struct.elbPos);

        /* '<S266>:1:73' */
        may23_DW.robot1Struct.elbPos[0] = may23_B.DataTypeConversion3_d[1];

        /* '<S266>:1:68' */
        may23_DW.robot1Struct.bHasSecondary = may23_B.HasSecondaryEnc_n;

        /* '<S266>:1:24' */
        /* '<S266>:1:66' */
        /* '<S266>:1:72' */
        may23_circshift(may23_DW.robot1StructPrimary.shoPos);

        /* '<S266>:1:73' */
        may23_DW.robot1StructPrimary.shoPos[0] = may23_B.Conversion2[0];

        /* '<S266>:1:67' */
        /* '<S266>:1:72' */
        may23_circshift(may23_DW.robot1StructPrimary.elbPos);

        /* '<S266>:1:73' */
        may23_DW.robot1StructPrimary.elbPos[0] = may23_B.Conversion2[1];

        /* '<S266>:1:68' */
        may23_DW.robot1StructPrimary.bHasSecondary = 0.0;

        /* '<S266>:1:25' */
        /* '<S266>:1:72' */
        may23_circshift(may23_DW.servoValuesR1);

        /* '<S266>:1:73' */
        may23_DW.servoValuesR1[0] = may23_B.SFunction_o3[0];

        /* '<S266>:1:26' */
        for (i = 0; i < 5; i++) {
          tmp[i] = may23_DW.robot1Struct.shoVel[i];
          tmp_0[i] = may23_DW.robot1Struct.elbVel[i];
        }

        may23_calculateVelAcc_aa(may23_DW.robot1Struct.shoPos,
          may23_DW.robot1Struct.elbPos, tmp, tmp_0, may23_DW.robot1Struct.shoAcc,
          may23_DW.robot1Struct.elbAcc, may23_DW.robot1Struct.bHasSecondary,
          may23_DW.servoValuesR1, may23_B.DataTypeConversion3_d,
          may23_DW.robot1Struct.shoVel, may23_DW.robot1Struct.elbVel, &tmp_1,
          &tmp_2, &tmp_3);
        may23_DW.robot1Struct.bHasSecondary = tmp_3;
        may23_DW.robot1Struct.elbAcc = tmp_2;
        may23_DW.robot1Struct.shoAcc = tmp_1;

        /* '<S266>:1:27' */
        for (i = 0; i < 5; i++) {
          tmp[i] = may23_DW.robot1StructPrimary.shoVel[i];
          tmp_0[i] = may23_DW.robot1StructPrimary.elbVel[i];
        }

        may23_calculateVelAcc_aam(may23_DW.robot1StructPrimary.shoPos,
          may23_DW.robot1StructPrimary.elbPos, tmp, tmp_0,
          may23_DW.robot1StructPrimary.shoAcc,
          may23_DW.robot1StructPrimary.elbAcc,
          may23_DW.robot1StructPrimary.bHasSecondary, may23_DW.servoValuesR1,
          may23_B.Conversion2, may23_DW.robot1StructPrimary.shoVel,
          may23_DW.robot1StructPrimary.elbVel, &tmp_1, &tmp_2, &tmp_3);
        may23_DW.robot1StructPrimary.bHasSecondary = tmp_3;
        may23_DW.robot1StructPrimary.elbAcc = tmp_2;
        may23_DW.robot1StructPrimary.shoAcc = tmp_1;
      }

      if (may23_B.SFunction_o3[1] != may23_DW.servoValuesR2[0]) {
        /* '<S266>:1:30' */
        /* '<S266>:1:31' */
        /* '<S266>:1:66' */
        /* '<S266>:1:72' */
        may23_circshift(may23_DW.robot2Struct.shoPos);

        /* '<S266>:1:73' */
        may23_DW.robot2Struct.shoPos[0] = may23_B.DataTypeConversion4_m[0];

        /* '<S266>:1:67' */
        /* '<S266>:1:72' */
        may23_circshift(may23_DW.robot2Struct.elbPos);

        /* '<S266>:1:73' */
        may23_DW.robot2Struct.elbPos[0] = may23_B.DataTypeConversion4_m[1];

        /* '<S266>:1:68' */
        may23_DW.robot2Struct.bHasSecondary = may23_B.HasSecondaryEnc_c;

        /* '<S266>:1:32' */
        /* '<S266>:1:66' */
        /* '<S266>:1:72' */
        may23_circshift(may23_DW.robot2StructPrimary.shoPos);

        /* '<S266>:1:73' */
        may23_DW.robot2StructPrimary.shoPos[0] = may23_B.Conversion1[0];

        /* '<S266>:1:67' */
        /* '<S266>:1:72' */
        may23_circshift(may23_DW.robot2StructPrimary.elbPos);

        /* '<S266>:1:73' */
        may23_DW.robot2StructPrimary.elbPos[0] = may23_B.Conversion1[1];

        /* '<S266>:1:68' */
        may23_DW.robot2StructPrimary.bHasSecondary = 0.0;

        /* '<S266>:1:33' */
        /* '<S266>:1:72' */
        may23_circshift(may23_DW.servoValuesR2);

        /* '<S266>:1:73' */
        may23_DW.servoValuesR2[0] = may23_B.SFunction_o3[1];

        /* '<S266>:1:34' */
        for (i = 0; i < 5; i++) {
          tmp[i] = may23_DW.robot2Struct.shoVel[i];
          tmp_0[i] = may23_DW.robot2Struct.elbVel[i];
        }

        may23_calculateVelAcc_aa(may23_DW.robot2Struct.shoPos,
          may23_DW.robot2Struct.elbPos, tmp, tmp_0, may23_DW.robot2Struct.shoAcc,
          may23_DW.robot2Struct.elbAcc, may23_DW.robot2Struct.bHasSecondary,
          may23_DW.servoValuesR2, may23_B.DataTypeConversion4_m,
          may23_DW.robot2Struct.shoVel, may23_DW.robot2Struct.elbVel, &tmp_1,
          &tmp_2, &tmp_3);
        may23_DW.robot2Struct.bHasSecondary = tmp_3;
        may23_DW.robot2Struct.elbAcc = tmp_2;
        may23_DW.robot2Struct.shoAcc = tmp_1;

        /* '<S266>:1:35' */
        for (i = 0; i < 5; i++) {
          tmp[i] = may23_DW.robot2StructPrimary.shoVel[i];
          tmp_0[i] = may23_DW.robot2StructPrimary.elbVel[i];
        }

        may23_calculateVelAcc_aam(may23_DW.robot2StructPrimary.shoPos,
          may23_DW.robot2StructPrimary.elbPos, tmp, tmp_0,
          may23_DW.robot2StructPrimary.shoAcc,
          may23_DW.robot2StructPrimary.elbAcc,
          may23_DW.robot2StructPrimary.bHasSecondary, may23_DW.servoValuesR2,
          may23_B.Conversion1, may23_DW.robot2StructPrimary.shoVel,
          may23_DW.robot2StructPrimary.elbVel, &tmp_1, &tmp_2, &tmp_3);
        may23_DW.robot2StructPrimary.bHasSecondary = tmp_3;
        may23_DW.robot2StructPrimary.elbAcc = tmp_2;
        may23_DW.robot2StructPrimary.shoAcc = tmp_1;
      }

      /* '<S266>:1:38' */
      /* '<S266>:1:52' */
      /* '<S266>:1:53' */
      memcpy(&may23_B.robot1DataOut_k[0], &may23_B.DataTypeConversion3_d[0], 10U
             * sizeof(real_T));
      memcpy(&may23_B.robot2DataOut_i[0], &may23_B.DataTypeConversion4_m[0], 10U
             * sizeof(real_T));
      may23_B.robot1DataOut_k[2] = may23_DW.robot1Struct.shoVel[0];

      /* '<S266>:1:54' */
      may23_B.robot1DataOut_k[3] = may23_DW.robot1Struct.elbVel[0];

      /* '<S266>:1:55' */
      may23_B.robot1DataOut_k[4] = may23_DW.robot1Struct.shoAcc;

      /* '<S266>:1:56' */
      may23_B.robot1DataOut_k[5] = may23_DW.robot1Struct.elbAcc;

      /* '<S266>:1:39' */
      /* '<S266>:1:52' */
      /* '<S266>:1:53' */
      may23_B.robot2DataOut_i[2] = may23_DW.robot2Struct.shoVel[0];

      /* '<S266>:1:54' */
      may23_B.robot2DataOut_i[3] = may23_DW.robot2Struct.elbVel[0];

      /* '<S266>:1:55' */
      may23_B.robot2DataOut_i[4] = may23_DW.robot2Struct.shoAcc;

      /* '<S266>:1:56' */
      may23_B.robot2DataOut_i[5] = may23_DW.robot2Struct.elbAcc;

      /* '<S266>:1:41' */
      /* '<S266>:1:52' */
      for (i = 0; i < 6; i++) {
        may23_B.robot1PrimaryEncDataOut[i] = may23_B.Conversion2[i];
      }

      /* '<S266>:1:53' */
      may23_B.robot1PrimaryEncDataOut[2] = may23_DW.robot1StructPrimary.shoVel[0];

      /* '<S266>:1:54' */
      may23_B.robot1PrimaryEncDataOut[3] = may23_DW.robot1StructPrimary.elbVel[0];

      /* '<S266>:1:55' */
      may23_B.robot1PrimaryEncDataOut[4] = may23_DW.robot1StructPrimary.shoAcc;

      /* '<S266>:1:56' */
      may23_B.robot1PrimaryEncDataOut[5] = may23_DW.robot1StructPrimary.elbAcc;

      /* '<S266>:1:42' */
      /* '<S266>:1:52' */
      for (i = 0; i < 6; i++) {
        may23_B.robot2PrimaryEncDataOut[i] = may23_B.Conversion1[i];
      }

      /* '<S266>:1:53' */
      may23_B.robot2PrimaryEncDataOut[2] = may23_DW.robot2StructPrimary.shoVel[0];

      /* '<S266>:1:54' */
      may23_B.robot2PrimaryEncDataOut[3] = may23_DW.robot2StructPrimary.elbVel[0];

      /* '<S266>:1:55' */
      may23_B.robot2PrimaryEncDataOut[4] = may23_DW.robot2StructPrimary.shoAcc;

      /* '<S266>:1:56' */
      may23_B.robot2PrimaryEncDataOut[5] = may23_DW.robot2StructPrimary.elbAcc;

      /* '<S266>:1:46' */
      tmp_1 = may23_B.robot1DataOut_k[2];
      may23_B.robot1DataOut_k[6] = tmp_1;
      tmp_1 = may23_B.robot1DataOut_k[3];
      may23_B.robot1DataOut_k[7] = tmp_1;

      /* '<S266>:1:47' */
      tmp_1 = may23_B.robot2DataOut_i[2];
      may23_B.robot2DataOut_i[6] = tmp_1;
      tmp_1 = may23_B.robot2DataOut_i[3];
      may23_B.robot2DataOut_i[7] = tmp_1;
    }

    /* End of MATLAB Function: '<S262>/Robot_data_builder' */

    /* MATLAB Function: '<S262>/filter_velocities' */
    /* MATLAB Function 'DataLogging/Poll KINARM/PMAC Subsystem/read_pmac/filter_velocities': '<S267>:1' */
    if (may23_B.SFunction_o10 < 7.0F) {
      /* '<S267>:1:11' */
      /* '<S267>:1:12' */
      memcpy(&may23_B.robot1DataOut[0], &may23_B.robot1DataOut_k[0], 10U *
             sizeof(real_T));

      /* '<S267>:1:13' */
      memcpy(&may23_B.robot2DataOut[0], &may23_B.robot2DataOut_i[0], 10U *
             sizeof(real_T));
    } else {
      /* '<S267>:1:17' */
      memcpy(&may23_B.robot1DataOut[0], &may23_B.robot1DataOut_k[0], 10U *
             sizeof(real_T));

      /* '<S267>:1:18' */
      memcpy(&may23_B.robot2DataOut[0], &may23_B.robot2DataOut_i[0], 10U *
             sizeof(real_T));

      /* '<S267>:1:20' */
      may23_updateValues(&may23_DW.robot1Struct_d, may23_B.robot1DataOut_k,
                         may23_B.SFunction_o3[0], 2.0);

      /* '<S267>:1:21' */
      may23_updateValues(&may23_DW.robot2Struct_o, may23_B.robot2DataOut_i,
                         may23_B.SFunction_o3[1], 2.0);

      /* '<S267>:1:25' */
      may23_B.robot1DataOut[6] = may23_DW.robot1Struct_d.shoVelFilt[2];
      may23_B.robot1DataOut[7] = may23_DW.robot1Struct_d.elbVelFilt[2];

      /* '<S267>:1:26' */
      may23_B.robot2DataOut[6] = may23_DW.robot2Struct_o.shoVelFilt[2];
      may23_B.robot2DataOut[7] = may23_DW.robot2Struct_o.elbVelFilt[2];
    }

    /* End of MATLAB Function: '<S262>/filter_velocities' */
    srUpdateBC(may23_DW.read_pmac_SubsysRanBC);
  }

  /* End of Outputs for SubSystem: '<S68>/read_pmac' */
}

/* Update for enable system: '<S68>/read_pmac' */
void may23_read_pmac_Update(void)
{
  /* Update for Enabled SubSystem: '<S68>/read_pmac' incorporates:
   *  EnablePort: '<S262>/Enable'
   */
  if (may23_B.Compare_f) {
    /* Update for UnitDelay: '<S268>/Output' */
    may23_DW.Output_DSTATE_d2 = may23_B.FixPtSwitch_ey;

    /* Update for UnitDelay: '<S264>/Unit Delay' */
    may23_DW.UnitDelay_DSTATE = may23_B.UnitDelay2;

    /* Update for UnitDelay: '<S264>/Unit Delay2' incorporates:
     *  Constant: '<S264>/Read Switch'
     */
    may23_DW.UnitDelay2_DSTATE = may23_P.ReadSwitch_Value;

    /* Update for UnitDelay: '<S264>/Unit Delay1' */
    may23_DW.UnitDelay1_DSTATE = may23_B.UnitDelay3;

    /* Update for UnitDelay: '<S264>/Unit Delay3' incorporates:
     *  Constant: '<S264>/Write Switch'
     */
    may23_DW.UnitDelay3_DSTATE = may23_P.WriteSwitch_Value;
  }

  /* End of Update for SubSystem: '<S68>/read_pmac' */
}

/* Termination for enable system: '<S68>/read_pmac' */
void may23_read_pmac_Term(void)
{
  /* Terminate for S-Function (mcc_pollall): '<S262>/S-Function' */
  /* Level2 S-Function Block: '<S262>/S-Function' (mcc_pollall) */
  {
    SimStruct *rts = may23_M->childSfunctions[25];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (mcc_writemem): '<S264>/Write' */
  /* Level2 S-Function Block: '<S264>/Write' (mcc_writemem) */
  {
    SimStruct *rts = may23_M->childSfunctions[26];
    sfcnTerminate(rts);
  }

  /* Terminate for IfAction SubSystem: '<S264>/Read DPRAM' */

  /* Terminate for S-Function (mcc_readmem): '<S269>/Read' */
  /* Level2 S-Function Block: '<S269>/Read' (mcc_readmem) */
  {
    SimStruct *rts = may23_M->childSfunctions[23];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S264>/Read DPRAM' */

  /* Terminate for IfAction SubSystem: '<S264>/Write DPRAM' */

  /* Terminate for S-Function (mcc_writemem): '<S271>/Write' */
  /* Level2 S-Function Block: '<S271>/Write' (mcc_writemem) */
  {
    SimStruct *rts = may23_M->childSfunctions[24];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S264>/Write DPRAM' */
}
