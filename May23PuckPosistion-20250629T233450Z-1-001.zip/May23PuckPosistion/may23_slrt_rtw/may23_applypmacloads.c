/*
 * Code generation for system system '<S33>/apply pmac loads'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_applypmacloads.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/* Start for enable system: '<S33>/apply pmac loads' */
void may23_applypmacloads_Start(void)
{
  /* Start for S-Function (mcc_apply_loads): '<S313>/S-Function1' */
  /* Level2 S-Function Block: '<S313>/S-Function1' (mcc_apply_loads) */
  {
    SimStruct *rts = may23_M->childSfunctions[39];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }
}

/* Output and update for enable system: '<S33>/apply pmac loads' */
void may23_applypmacloads(void)
{
  /* Outputs for Enabled SubSystem: '<S33>/apply pmac loads' incorporates:
   *  EnablePort: '<S313>/Enable'
   */
  if (may23_B.Compare_oi) {
    /* Product: '<S313>/Product' */
    may23_B.Product_d[0] = may23_B.torques_out[0] * may23_B.Memory1_l;
    may23_B.Product_d[1] = may23_B.torques_out[1] * may23_B.Memory1_l;
    may23_B.Product_d[2] = may23_B.torques_out[2] * may23_B.Memory1_l;
    may23_B.Product_d[3] = may23_B.torques_out[3] * may23_B.Memory1_l;

    /* DataTypeConversion: '<S313>/Data Type Conversion6' */
    may23_B.DataTypeConversion6[0] = (real32_T)may23_B.Product_d[0];
    may23_B.DataTypeConversion6[1] = (real32_T)may23_B.Product_d[1];
    may23_B.DataTypeConversion6[2] = (real32_T)may23_B.Product_d[2];
    may23_B.DataTypeConversion6[3] = (real32_T)may23_B.Product_d[3];

    /* DataTypeConversion: '<S313>/Data Type Conversion' */
    may23_B.DataTypeConversion_nc[0] = (real32_T)may23_B.ArmOrientation;
    may23_B.DataTypeConversion_nc[1] = (real32_T)may23_B.M1orientation;
    may23_B.DataTypeConversion_nc[2] = (real32_T)may23_B.M2Orientation;
    may23_B.DataTypeConversion_nc[3] = (real32_T)may23_B.M1GearRatio;
    may23_B.DataTypeConversion_nc[4] = (real32_T)may23_B.M2GearRatio;
    may23_B.DataTypeConversion_nc[5] = (real32_T)may23_B.torqueconstant;

    /* DataTypeConversion: '<S313>/Data Type Conversion1' */
    may23_B.DataTypeConversion1_px[0] = (real32_T)may23_B.ArmOrientation_a;
    may23_B.DataTypeConversion1_px[1] = (real32_T)may23_B.M1orientation_i;
    may23_B.DataTypeConversion1_px[2] = (real32_T)may23_B.M2Orientation_a;
    may23_B.DataTypeConversion1_px[3] = (real32_T)may23_B.M1GearRatio_e;
    may23_B.DataTypeConversion1_px[4] = (real32_T)may23_B.M2GearRatio_n;
    may23_B.DataTypeConversion1_px[5] = (real32_T)may23_B.torqueconstant_b;

    /* S-Function (mcc_apply_loads): '<S313>/S-Function1' */

    /* Level2 S-Function Block: '<S313>/S-Function1' (mcc_apply_loads) */
    {
      SimStruct *rts = may23_M->childSfunctions[39];
      sfcnOutputs(rts,1);
    }

    srUpdateBC(may23_DW.applypmacloads_SubsysRanBC);
  }

  /* End of Outputs for SubSystem: '<S33>/apply pmac loads' */
}

/* Termination for enable system: '<S33>/apply pmac loads' */
void may23_applypmacloads_Term(void)
{
  /* Terminate for S-Function (mcc_apply_loads): '<S313>/S-Function1' */
  /* Level2 S-Function Block: '<S313>/S-Function1' (mcc_apply_loads) */
  {
    SimStruct *rts = may23_M->childSfunctions[39];
    sfcnTerminate(rts);
  }
}
