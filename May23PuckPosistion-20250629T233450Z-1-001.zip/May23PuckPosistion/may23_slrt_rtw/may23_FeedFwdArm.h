/*
 * Code generation for system system '<S405>/FeedFwdArm'
 * For more details, see corresponding source file may23_FeedFwdArm.c
 *
 */

#ifndef RTW_HEADER_may23_FeedFwdArm_h_
#define RTW_HEADER_may23_FeedFwdArm_h_
#include <string.h>
#ifndef may23_COMMON_INCLUDES_
# define may23_COMMON_INCLUDES_
#include <stdio.h>
#include <string.h>
#include <xpcimports.h>
#include <xpcdatatypes.h>
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rt_logging.h"
#include "xpcimports.h"
#include "stddef.h"
#include "stdlib.h"
#include "xpcethercatutils.h"
#include "xpctarget.h"
#include "BKINethercat.h"
#endif                                 /* may23_COMMON_INCLUDES_ */

#include "may23_types.h"

/* Shared type includes */
#include "multiword_types.h"

extern void may23_FeedFwdArm(void);

#endif                                 /* RTW_HEADER_may23_FeedFwdArm_h_ */
