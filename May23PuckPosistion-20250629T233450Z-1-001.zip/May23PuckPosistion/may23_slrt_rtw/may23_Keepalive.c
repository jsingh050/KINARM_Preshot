/*
 * Code generation for system system '<S1>/Keep alive'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_Keepalive.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/* Start for atomic system: '<S1>/Keep alive' */
void may23_Keepalive_Start(void)
{
  /* Start for S-Function (slrtUDPSend): '<S27>/Send' */
  /* Level2 S-Function Block: '<S27>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[0];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }
}

/* Output and update for atomic system: '<S1>/Keep alive' */
void may23_Keepalive(void)
{
  /* S-Function (xpcbytepacking): '<S27>/Pack' incorporates:
   *  Constant: '<S27>/const'
   */

  /* Byte Packing: <S27>/Pack */
  (void)memcpy((uint8_T*)&may23_B.Pack_i[0] + 0, (uint8_T*)&may23_P.const_Value
               [0], 40);

  /* S-Function (slrtUDPSend): '<S27>/Send' */

  /* Level2 S-Function Block: '<S27>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[0];
    sfcnOutputs(rts,4);
  }
}

/* Termination for atomic system: '<S1>/Keep alive' */
void may23_Keepalive_Term(void)
{
  /* Terminate for S-Function (slrtUDPSend): '<S27>/Send' */
  /* Level2 S-Function Block: '<S27>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[0];
    sfcnTerminate(rts);
  }
}
