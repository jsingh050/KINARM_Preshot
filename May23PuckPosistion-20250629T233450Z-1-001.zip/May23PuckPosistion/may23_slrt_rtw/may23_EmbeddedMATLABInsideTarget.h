/*
 * Code generation for system system '<S6>/Embedded MATLAB InsideTarget'
 * For more details, see corresponding source file may23_EmbeddedMATLABInsideTarget.c
 *
 */

#ifndef RTW_HEADER_may23_EmbeddedMATLABInsideTarget_h_
#define RTW_HEADER_may23_EmbeddedMATLABInsideTarget_h_
#include <math.h>
#include <string.h>
#ifndef may23_COMMON_INCLUDES_
# define may23_COMMON_INCLUDES_
#include <stdio.h>
#include <string.h>
#include <xpcimports.h>
#include <xpcdatatypes.h>
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rt_logging.h"
#include "xpcimports.h"
#include "stddef.h"
#include "stdlib.h"
#include "xpcethercatutils.h"
#include "xpctarget.h"
#include "BKINethercat.h"
#endif                                 /* may23_COMMON_INCLUDES_ */

#include "may23_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "rt_defines.h"
#include "rt_nonfinite.h"

extern void may23_EmbeddedMATLABInsideTarget(void);

#endif                      /* RTW_HEADER_may23_EmbeddedMATLABInsideTarget_h_ */
