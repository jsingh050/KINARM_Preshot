/*
 * Code generation for system system '<S1>/Poll KINARM'
 * For more details, see corresponding source file may23_PollKINARM.c
 *
 */

#ifndef RTW_HEADER_may23_PollKINARM_h_
#define RTW_HEADER_may23_PollKINARM_h_
#include <stddef.h>
#include <math.h>
#include <string.h>
#ifndef may23_COMMON_INCLUDES_
# define may23_COMMON_INCLUDES_
#include <stdio.h>
#include <string.h>
#include <xpcimports.h>
#include <xpcdatatypes.h>
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rt_logging.h"
#include "xpcimports.h"
#include "stddef.h"
#include "stdlib.h"
#include "xpcethercatutils.h"
#include "xpctarget.h"
#include "BKINethercat.h"
#endif                                 /* may23_COMMON_INCLUDES_ */

#include "may23_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Child system includes */
#include "may23_ForceSensorControl.h"
#include "may23_createKINData.h"
#include "may23_read_pmac.h"
#include "rt_nonfinite.h"

/* Block signals for system '<S110>/MATLAB Function' */
typedef struct {
  int32_T prime_out;                   /* '<S110>/MATLAB Function' */
  int32_T sec_out;                     /* '<S110>/MATLAB Function' */
} B_MATLABFunction_may23_T;

/* Block signals for system '<S102>/parse status register' */
typedef struct {
  uint32_T allOK;                      /* '<S102>/parse status register' */
  uint32_T ampStatus;                  /* '<S102>/parse status register' */
  uint32_T servoEnabled;               /* '<S102>/parse status register' */
  uint32_T faultFound;                 /* '<S102>/parse status register' */
  uint32_T currentLimitEnabled;        /* '<S102>/parse status register' */
  uint32_T eStopOut;                   /* '<S102>/parse status register' */
  uint32_T motorOn;                    /* '<S102>/parse status register' */
} B_parsestatusregister_may23_T;

/* Block signals for system '<S104>/Read EMCY' */
typedef struct {
  real_T emcyValPump[3];               /* '<S104>/Read EMCY' */
  int32_T triggerCountRead;            /* '<S104>/Read EMCY' */
  int32_T emcyReadTrigger[2];          /* '<S104>/Read EMCY' */
  int32_T countOverwriteTrigger;       /* '<S104>/Read EMCY' */
} B_ReadEMCY_may23_T;

/* Block states (default storage) for system '<S104>/Read EMCY' */
typedef struct {
  real_T currReadIdx;                  /* '<S104>/Read EMCY' */
  real_T valuesToRead;                 /* '<S104>/Read EMCY' */
  int32_T sfEvent;                     /* '<S104>/Read EMCY' */
  uint8_T is_active_c99_ethercat;      /* '<S104>/Read EMCY' */
  uint8_T is_c99_ethercat;             /* '<S104>/Read EMCY' */
} DW_ReadEMCY_may23_T;

/* Block signals for system '<S114>/MATLAB Function' */
typedef struct {
  uint32_T out_err_code;               /* '<S114>/MATLAB Function' */
} B_MATLABFunction_may23_b_T;

/* Block signals for system '<S115>/MATLAB Function' */
typedef struct {
  int32_T out_err_code;                /* '<S115>/MATLAB Function' */
} B_MATLABFunction_may23_n_T;

/* Block signals for system '<S104>/fault monitor' */
typedef struct {
  real_T triggerFaultRead;             /* '<S104>/fault monitor' */
} B_faultmonitor_may23_T;

/* Block states (default storage) for system '<S104>/fault monitor' */
typedef struct {
  real_T preOpCounter;                 /* '<S104>/fault monitor' */
} DW_faultmonitor_may23_T;

/* Block signals for system '<S104>/pass emcy' */
typedef struct {
  real_T EMCYMsg[5];                   /* '<S104>/pass emcy' */
  uint32_T TmpSignalConversionAtSFunctionInport3[3];/* '<S104>/pass emcy' */
} B_passemcy_may23_T;

/* Block states (default storage) for system '<S104>/pass emcy' */
typedef struct {
  uint32_T lastRegister;               /* '<S104>/pass emcy' */
} DW_passemcy_may23_T;

/* Block signals for system '<S87>/Whistle state' */
typedef struct {
  real_T isPermFaulted;                /* '<S87>/Whistle state' */
  uint32_T motorStatus;                /* '<S87>/Whistle state' */
  uint16_T ControlWord;                /* '<S87>/Whistle state' */
} B_Whistlestate_may23_T;

/* Block states (default storage) for system '<S87>/Whistle state' */
typedef struct {
  int32_T sfEvent;                     /* '<S87>/Whistle state' */
  uint32_T faultClock;                 /* '<S87>/Whistle state' */
  uint32_T resetCounter;               /* '<S87>/Whistle state' */
  uint32_T faultResetAttempts;         /* '<S87>/Whistle state' */
  uint8_T is_active_c22_ethercat;      /* '<S87>/Whistle state' */
  uint8_T is_c22_ethercat;             /* '<S87>/Whistle state' */
  uint8_T is_MotorStatus;              /* '<S87>/Whistle state' */
  uint8_T is_active_MotorStatus;       /* '<S87>/Whistle state' */
  uint8_T is_ControlWordUpdate;        /* '<S87>/Whistle state' */
  uint8_T is_active_ControlWordUpdate; /* '<S87>/Whistle state' */
  uint8_T is_SWSwitchOnDisabled_64;    /* '<S87>/Whistle state' */
  uint8_T is_SWReadyToSwitchOn_33;     /* '<S87>/Whistle state' */
  uint8_T is_SWOperationEnabled_39;    /* '<S87>/Whistle state' */
  uint8_T is_SWFault_8;                /* '<S87>/Whistle state' */
  uint8_T temporalCounter_i1;          /* '<S87>/Whistle state' */
} DW_Whistlestate_may23_T;

/* Block signals for system '<S87>/cleanword' */
typedef struct {
  uint16_T out_val;                    /* '<S87>/cleanword' */
} B_cleanword_may23_T;

/* Block signals for system '<S89>/MATLAB Function1' */
typedef struct {
  int8_T mode;                         /* '<S89>/MATLAB Function1' */
} B_MATLABFunction1_may23_T;

/* Block signals for system '<S77>/Find Robot type' */
typedef struct {
  real_T robotType;                    /* '<S77>/Find Robot type' */
} B_FindRobottype_may23_T;

/* Block signals for system '<S91>/AbsEncoder machine' */
typedef struct {
  int32_T setupData[4];                /* '<S91>/AbsEncoder machine' */
  int32_T SDORequest[3];               /* '<S91>/AbsEncoder machine' */
  int32_T encoderOutputs[6];           /* '<S91>/AbsEncoder machine' */
  int32_T complete;                    /* '<S91>/AbsEncoder machine' */
} B_AbsEncodermachine_may23_T;

/* Block states (default storage) for system '<S91>/AbsEncoder machine' */
typedef struct {
  real_T encoderIdx;                   /* '<S91>/AbsEncoder machine' */
  int32_T sfEvent;                     /* '<S91>/AbsEncoder machine' */
  int32_T setupIdx;                    /* '<S91>/AbsEncoder machine' */
  int32_T donePolling;                 /* '<S91>/AbsEncoder machine' */
  uint8_T is_active_c18_ethercat;      /* '<S91>/AbsEncoder machine' */
  uint8_T is_c18_ethercat;             /* '<S91>/AbsEncoder machine' */
} DW_AbsEncodermachine_may23_T;

/* Block signals for system '<S91>/set-up values' */
typedef struct {
  real_T setupValues[24];              /* '<S91>/set-up values' */
  real_T setupValuesCount;             /* '<S91>/set-up values' */
  real_T pollValues[3];                /* '<S91>/set-up values' */
  real_T encoderValues[12];            /* '<S91>/set-up values' */
  real_T encoderValuesCount;           /* '<S91>/set-up values' */
} B_setupvalues_may23_T;

/* Block signals for system '<S147>/converter' */
typedef struct {
  real_T doubleOut;                    /* '<S147>/converter' */
  uint32_T uint32Out;                  /* '<S147>/converter' */
  int32_T int32Out;                    /* '<S147>/converter' */
} B_converter_may23_T;

/* Block signals for system '<S94>/SDO read machine' */
typedef struct {
  int32_T enable;                      /* '<S94>/SDO read machine' */
  int32_T complete;                    /* '<S94>/SDO read machine' */
} B_SDOreadmachine_may23_T;

/* Block states (default storage) for system '<S94>/SDO read machine' */
typedef struct {
  int32_T sfEvent;                     /* '<S94>/SDO read machine' */
  int32_T lastTriggerValue;            /* '<S94>/SDO read machine' */
  uint8_T is_active_c40_ethercat;      /* '<S94>/SDO read machine' */
  uint8_T is_c40_ethercat;             /* '<S94>/SDO read machine' */
} DW_SDOreadmachine_may23_T;

/* Block signals for system '<S94>/values' */
typedef struct {
  real_T TmpSignalConversionAtSFunctionInport1[3];/* '<S94>/values' */
  real_T outVal[3];                    /* '<S94>/values' */
} B_values_may23_T;

/* Block signals for system '<S95>/SDO write machine' */
typedef struct {
  int32_T enable;                      /* '<S95>/SDO write machine' */
  int32_T complete;                    /* '<S95>/SDO write machine' */
} B_SDOwritemachine_may23_T;

/* Block states (default storage) for system '<S95>/SDO write machine' */
typedef struct {
  int32_T sfEvent;                     /* '<S95>/SDO write machine' */
  int32_T lastTriggerValue;            /* '<S95>/SDO write machine' */
  uint8_T is_active_c42_ethercat;      /* '<S95>/SDO write machine' */
  uint8_T is_c42_ethercat;             /* '<S95>/SDO write machine' */
} DW_SDOwritemachine_may23_T;

/* Block signals for system '<S95>/convert' */
typedef struct {
  uint32_T y;                          /* '<S95>/convert' */
} B_convert_may23_T;

/* Block signals for system '<S77>/size' */
typedef struct {
  real_T count;                        /* '<S77>/size' */
} B_size_may23_T;

/* Block signals for system '<S75>/splitKINData arm1' */
typedef struct {
  real_T link_lengths[2];              /* '<S75>/splitKINData arm1' */
  real_T pointer_offset;               /* '<S75>/splitKINData arm1' */
  real_T shoulder_loc[2];              /* '<S75>/splitKINData arm1' */
  real_T arm_orientation;              /* '<S75>/splitKINData arm1' */
  real_T shoulder_ang;                 /* '<S75>/splitKINData arm1' */
  real_T elbow_ang;                    /* '<S75>/splitKINData arm1' */
  real_T shoulder_ang_velocity;        /* '<S75>/splitKINData arm1' */
  real_T elbow_ang_velocity;           /* '<S75>/splitKINData arm1' */
  real_T shoulder_ang_acceleration;    /* '<S75>/splitKINData arm1' */
  real_T elbow_ang_acceleration;       /* '<S75>/splitKINData arm1' */
  real_T joint_torque_cmd[2];          /* '<S75>/splitKINData arm1' */
  real_T motor_torque_cmd[2];          /* '<S75>/splitKINData arm1' */
  real_T link_angle[2];                /* '<S75>/splitKINData arm1' */
  real_T link_velocity[2];             /* '<S75>/splitKINData arm1' */
  real_T link_acceleration[2];         /* '<S75>/splitKINData arm1' */
  real_T hand_position[2];             /* '<S75>/splitKINData arm1' */
  real_T hand_velocity[2];             /* '<S75>/splitKINData arm1' */
  real_T hand_acceleration[2];         /* '<S75>/splitKINData arm1' */
  real_T elbow_position[2];            /* '<S75>/splitKINData arm1' */
  real_T elbow_velocity[2];            /* '<S75>/splitKINData arm1' */
  real_T elbow_acceleration[2];        /* '<S75>/splitKINData arm1' */
  real_T motor_status;                 /* '<S75>/splitKINData arm1' */
  real_T force_sensor_force_uvw[3];    /* '<S75>/splitKINData arm1' */
  real_T force_sensor_torque_uvw[3];   /* '<S75>/splitKINData arm1' */
  real_T force_sensor_force_xyz[3];    /* '<S75>/splitKINData arm1' */
  real_T force_sensor_torque_xyz[3];   /* '<S75>/splitKINData arm1' */
  real_T force_sensor_timestamp;       /* '<S75>/splitKINData arm1' */
} B_splitKINDataarm1_may23_T;

/* Block signals for system '<S76>/split_primary' */
typedef struct {
  real_T link_angles[2];               /* '<S76>/split_primary' */
  real_T link_velocities[2];           /* '<S76>/split_primary' */
  real_T link_acceleration[2];         /* '<S76>/split_primary' */
} B_split_primary_may23_T;

extern void may23_MATLABFunction(int32_T rtu_primary, int32_T rtu_secondary,
  real_T rtu_encoder_type, B_MATLABFunction_may23_T *localB);
extern void may23_parsestatusregister(uint32_T rtu_statusRegister,
  B_parsestatusregister_may23_T *localB);
extern void may23_ReadEMCY_Init(B_ReadEMCY_may23_T *localB, DW_ReadEMCY_may23_T *
  localDW);
extern void may23_ReadEMCY(real_T rtu_triggerReading, real_T rtu_driveID, const
  real_T rtu_countValues[3], const real_T rtu_emcyValues[3], real_T
  rtu_overwriteStatus, B_ReadEMCY_may23_T *localB, DW_ReadEMCY_may23_T *localDW);
extern void may23_MATLABFunction_g(uint32_T rtu_err_code,
  B_MATLABFunction_may23_b_T *localB);
extern void may23_MATLABFunction_b(uint32_T rtu_err_code,
  B_MATLABFunction_may23_n_T *localB);
extern void may23_faultmonitor_Init(DW_faultmonitor_may23_T *localDW);
extern void may23_faultmonitor(uint16_T rtu_StatusWord, B_faultmonitor_may23_T
  *localB, DW_faultmonitor_may23_T *localDW);
extern void may23_passemcy_Init(DW_passemcy_may23_T *localDW);
extern void may23_passemcy(const real_T rtu_SDOEMCY[3], real_T rtu_drive,
  uint32_T rtu_registerInfo, uint32_T rtu_registerInfo_c, uint32_T
  rtu_registerInfo_e, real_T rtu_statusWord, B_passemcy_may23_T *localB,
  DW_passemcy_may23_T *localDW);
extern void may23_Whistlestate_Init(DW_Whistlestate_may23_T *localDW);
extern void may23_Whistlestate(uint16_T rtu_StatusWord, uint32_T rtu_allOK,
  uint32_T rtu_motorOn, uint32_T rtu_eStops, boolean_T rtu_masterEnabled, real_T
  rtu_requestEnable, real_T rtu_max_errors_to_fault, B_Whistlestate_may23_T
  *localB, DW_Whistlestate_may23_T *localDW);
extern void may23_cleanword(uint16_T rtu_val, B_cleanword_may23_T *localB);
extern void may23_MATLABFunction1(boolean_T rtu_gripSensor, real_T rtu_robotType,
  real_T rtu_override, real_T rtu_stop_vel_mode, B_MATLABFunction1_may23_T
  *localB);
extern void may23_FindRobottype(const int32_T rtu_intVals[20], const real_T
  rtu_epPNs[6], const real_T rtu_nhpPNs[6], B_FindRobottype_may23_T *localB);
extern void may23_AbsEncodermachine_Init(B_AbsEncodermachine_may23_T *localB,
  DW_AbsEncodermachine_may23_T *localDW);
extern void may23_AbsEncodermachine_Reset(B_AbsEncodermachine_may23_T *localB,
  DW_AbsEncodermachine_may23_T *localDW);
extern void may23_AbsEncodermachine(const real_T rtu_setupValues[24], real_T
  rtu_setupValuesCount, const real_T rtu_pollValues[3], const real_T
  rtu_encoderValues[12], real_T rtu_encoderValuesCount, int32_T rtu_intStatus,
  const int32_T rtu_pollResponse[2], B_AbsEncodermachine_may23_T *localB,
  DW_AbsEncodermachine_may23_T *localDW);
extern void may23_setupvalues(B_setupvalues_may23_T *localB);
extern void may23_converter(uint32_T rtu_inVal, B_converter_may23_T *localB);
extern void may23_SDOreadmachine_Init(B_SDOreadmachine_may23_T *localB,
  DW_SDOreadmachine_may23_T *localDW);
extern void may23_SDOreadmachine(real_T rtu_triggerWriting, const int32_T
  rtu_readState[2], B_SDOreadmachine_may23_T *localB, DW_SDOreadmachine_may23_T *
  localDW);
extern void may23_values(real_T rtu_inVal, real_T rtu_inVal_a, real_T
  rtu_inVal_e, B_values_may23_T *localB);
extern void may23_SDOwritemachine_Init(DW_SDOwritemachine_may23_T *localDW);
extern void may23_SDOwritemachine(real_T rtu_triggerReading, const int32_T
  rtu_writeState[2], B_SDOwritemachine_may23_T *localB,
  DW_SDOwritemachine_may23_T *localDW);
extern void may23_convert(real_T rtu_u, real_T rtu_type, B_convert_may23_T
  *localB);
extern void may23_size(B_size_may23_T *localB);
extern void may23_splitKINDataarm1(const real_T rtu_robot_row[50],
  B_splitKINDataarm1_may23_T *localB);
extern void may23_split_primary(const real_T rtu_primary_data[6],
  B_split_primary_may23_T *localB);
extern void may23_EMCYMessagepump_Init(void);
extern void may23_EMCYMessagepump_Start(void);
extern void may23_EMCYMessagepump_Update(void);
extern void may23_EMCYMessagepump(void);
extern void may23_EMCYMessagepump_l_Init(void);
extern void may23_EMCYMessagepump_k_Start(void);
extern void may23_EMCYMessagepump_h_Update(void);
extern void may23_EMCYMessagepump_h(void);
extern void may23_ReadDrive1SDO(void);
extern void may23_ReadDrive2SDO(void);
extern void may23_SDOreading_Init(void);
extern void may23_SDOreading_Start(void);
extern void may23_SDOreading_Update(void);
extern void may23_SDOreading(void);
extern void may23_SDOwriting_Init(void);
extern void may23_SDOwriting_Start(void);
extern void may23_SDOwriting_Update(void);
extern void may23_SDOwriting(void);
extern void may23_ReadDrive1SDO_c(void);
extern void may23_EMCYMessagepump_h_Init(void);
extern void may23_EMCYMessagepump_h_Start(void);
extern void may23_EMCYMessagepump_k_Update(void);
extern void may23_EMCYMessagepump_p(void);
extern void may23_EMCYMessagepump_a_Init(void);
extern void may23_EMCYMessagepump_o_Start(void);
extern void may23_EMCYMessagepump_hc_Update(void);
extern void may23_EMCYMessagepump_hr(void);
extern void may23_ReadDrive3SDO(void);
extern void may23_ReadDrive4SDO(void);
extern void may23_SDOreading_i_Init(void);
extern void may23_SDOreading_b_Start(void);
extern void may23_SDOreading_a_Update(void);
extern void may23_SDOreading_f(void);
extern void may23_SDOwriting_b_Init(void);
extern void may23_SDOwriting_j_Start(void);
extern void may23_SDOwriting_g_Update(void);
extern void may23_SDOwriting_l(void);
extern void may23_ReadDrive3SDO_d(void);
extern void may23_PollKINARM_Init(void);
extern void may23_PollKINARM_Enable(void);
extern void may23_PollKINARM_Start(void);
extern void may23_PollKINARM_UpdateTID0(void);
extern void may23_PollKINARMTID0(void);
extern void may23_PollKINARMTID3(void);
extern void may23_EMCYMessagepump_Term(void);
extern void may23_EMCYMessagepump_k_Term(void);
extern void may23_ReadDrive1SDO_Term(void);
extern void may23_ReadDrive2SDO_Term(void);
extern void may23_SDOreading_Term(void);
extern void may23_SDOwriting_Term(void);
extern void may23_ReadDrive1SDO_g_Term(void);
extern void may23_EMCYMessagepump_m_Term(void);
extern void may23_EMCYMessagepump_n_Term(void);
extern void may23_ReadDrive3SDO_Term(void);
extern void may23_ReadDrive4SDO_Term(void);
extern void may23_SDOreading_p_Term(void);
extern void may23_SDOwriting_k_Term(void);
extern void may23_ReadDrive3SDO_j_Term(void);
extern void may23_PollKINARM_Term(void);

#endif                                 /* RTW_HEADER_may23_PollKINARM_h_ */
