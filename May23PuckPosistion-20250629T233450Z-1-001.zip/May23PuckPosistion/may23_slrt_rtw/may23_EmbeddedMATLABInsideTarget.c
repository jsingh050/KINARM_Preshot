/*
 * Code generation for system system '<S6>/Embedded MATLAB InsideTarget'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_EmbeddedMATLABInsideTarget.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/* Forward declaration for local functions */
static void may23_sin(real_T x[64]);
static void may23_cos(real_T x[64]);
static void may23_atan2(const real_T y[64], const real_T x[64], real_T r[64]);
static void may23_power(const real_T a[64], real_T y[64]);
static void may23_sqrt(real_T x[64]);
static void may23_abs(const real_T x[64], real_T y[64]);

/* Function for MATLAB Function: '<S6>/Embedded MATLAB InsideTarget' */
static void may23_sin(real_T x[64])
{
  int32_T k;
  for (k = 0; k < 64; k++) {
    x[k] = sin(x[k]);
  }
}

/* Function for MATLAB Function: '<S6>/Embedded MATLAB InsideTarget' */
static void may23_cos(real_T x[64])
{
  int32_T k;
  for (k = 0; k < 64; k++) {
    x[k] = cos(x[k]);
  }
}

real_T rt_atan2d_snf(real_T u0, real_T u1)
{
  real_T y;
  int32_T tmp;
  int32_T tmp_0;
  if (rtIsNaN(u0) || rtIsNaN(u1)) {
    y = (rtNaN);
  } else if (rtIsInf(u0) && rtIsInf(u1)) {
    if (u1 > 0.0) {
      tmp = 1;
    } else {
      tmp = -1;
    }

    if (u0 > 0.0) {
      tmp_0 = 1;
    } else {
      tmp_0 = -1;
    }

    y = atan2(tmp_0, tmp);
  } else if (u1 == 0.0) {
    if (u0 > 0.0) {
      y = RT_PI / 2.0;
    } else if (u0 < 0.0) {
      y = -(RT_PI / 2.0);
    } else {
      y = 0.0;
    }
  } else {
    y = atan2(u0, u1);
  }

  return y;
}

/* Function for MATLAB Function: '<S6>/Embedded MATLAB InsideTarget' */
static void may23_atan2(const real_T y[64], const real_T x[64], real_T r[64])
{
  int32_T k;
  for (k = 0; k < 64; k++) {
    r[k] = rt_atan2d_snf(y[k], x[k]);
  }
}

/* Function for MATLAB Function: '<S6>/Embedded MATLAB InsideTarget' */
static void may23_power(const real_T a[64], real_T y[64])
{
  int32_T k;
  real_T a_0;
  for (k = 0; k < 64; k++) {
    a_0 = a[k];
    y[k] = a_0 * a_0;
  }
}

/* Function for MATLAB Function: '<S6>/Embedded MATLAB InsideTarget' */
static void may23_sqrt(real_T x[64])
{
  int32_T k;
  for (k = 0; k < 64; k++) {
    x[k] = sqrt(x[k]);
  }
}

/* Function for MATLAB Function: '<S6>/Embedded MATLAB InsideTarget' */
static void may23_abs(const real_T x[64], real_T y[64])
{
  int32_T k;
  for (k = 0; k < 64; k++) {
    y[k] = fabs(x[k]);
  }
}

/* Output and update for atomic system: '<S6>/Embedded MATLAB InsideTarget' */
void may23_EmbeddedMATLABInsideTarget(void)
{
  real_T deltax[64];
  real_T deltay[64];
  real_T t[64];
  real_T sint[64];
  real_T w[64];
  real_T h[64];
  real_T p[64];
  real_T A[128];
  real_T v0[128];
  real_T v1[128];
  real_T v2[128];
  real_T dot02[64];
  real_T dot11[64];
  int32_T e_target;
  int32_T i;
  real_T dot02_0[64];
  real_T tmp[64];
  int32_T i_0;
  int32_T i_1;
  real_T deltax_0;
  real_T t_0;
  real_T deltay_0;
  real_T sint_0;
  real_T w_0;
  real_T p_0;
  real_T h_0;

  /* SignalConversion generated from: '<S371>/ SFunction ' incorporates:
   *  Constant: '<S6>/attribcol1'
   *  Constant: '<S6>/attribcol2'
   *  Constant: '<S6>/attribcol3'
   *  Constant: '<S6>/attribcol4'
   *  Constant: '<S6>/attribcol5'
   */
  may23_B.TmpSignalConversionAtSFunctionInport3_f[0] =
    may23_P.KINARM_HandInBarrier_attribcol1[0];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[3] =
    may23_P.attribcol2_Value_b[0];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[6] =
    may23_P.attribcol3_Value_o[0];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[9] =
    may23_P.attribcol4_Value_l[0];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[12] =
    may23_P.attribcol5_Value_n[0];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[1] =
    may23_P.KINARM_HandInBarrier_attribcol1[1];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[4] =
    may23_P.attribcol2_Value_b[1];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[7] =
    may23_P.attribcol3_Value_o[1];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[10] =
    may23_P.attribcol4_Value_l[1];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[13] =
    may23_P.attribcol5_Value_n[1];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[2] =
    may23_P.KINARM_HandInBarrier_attribcol1[2];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[5] =
    may23_P.attribcol2_Value_b[2];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[8] =
    may23_P.attribcol3_Value_o[2];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[11] =
    may23_P.attribcol4_Value_l[2];
  may23_B.TmpSignalConversionAtSFunctionInport3_f[14] =
    may23_P.attribcol5_Value_n[2];

  /* MATLAB Function 'KINARM_HandInBarrier/Embedded MATLAB InsideTarget': '<S371>:1' */
  /* '<S371>:1:31' */
  /* '<S371>:1:26' */
  /* '<S371>:1:27' */
  /* '<S371>:1:29' */
  for (i = 0; i < 320; i++) {
    may23_B.intarget_j[i] = 0.0;
  }

  /* '<S371>:1:31' */
  /* '<S371>:1:32' */
  /* '<S371>:1:34' */
  h_0 = may23_B.Switch_i[0];
  for (i = 0; i < 64; i++) {
    deltax[i] = h_0 - may23_B.TargetTable[i] * 0.01;
  }

  /* '<S371>:1:35' */
  h_0 = may23_B.Switch_i[1];
  for (i = 0; i < 64; i++) {
    deltay[i] = h_0 - may23_B.TargetTable[i + 64] * 0.01;
  }

  /* Constant: '<S6>/Target_Type' */
  if (may23_P.KINARM_HandInBarrier_target_type == 1.0) {
    /* Constant: '<S6>/num_states' */
    /* '<S371>:1:37' */
    /* '<S371>:1:38' */
    if (0 <= (int32_T)may23_P.KINARM_HandInBarrier_num_states - 1) {
      may23_power(deltax, tmp);
      may23_power(deltay, w);
    }

    /* Constant: '<S6>/num_states' */
    for (e_target = 0; e_target < (int32_T)
         may23_P.KINARM_HandInBarrier_num_states; e_target++) {
      /* '<S371>:1:38' */
      /* '<S371>:1:39' */
      /* '<S371>:1:41' */
      /* '<S371>:1:42' */
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[e_target];
      for (i_0 = 0; i_0 < 64; i_0++) {
        t[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
      }

      may23_power(t, sint);
      for (i = 0; i < 64; i++) {
        may23_B.intarget_j[i + (e_target << 6)] = (tmp[i] + w[i] <= sint[i]);
      }
    }
  } else if (may23_P.KINARM_HandInBarrier_target_type == 2.0) {
    /* '<S371>:1:44' */
    /* '<S371>:1:45' */
    /* Constant: '<S6>/num_states' */
    for (e_target = 1; e_target - 1 < (int32_T)
         may23_P.KINARM_HandInBarrier_num_states; e_target++) {
      /* '<S371>:1:45' */
      /* '<S371>:1:46' */
      /* '<S371>:1:47' */
      /* '<S371>:1:48' */
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[e_target * 3
        - 1];
      for (i_0 = 0; i_0 < 64; i_0++) {
        t[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] *
          0.017453292519943295;
      }

      /* '<S371>:1:49' */
      memcpy(&sint[0], &t[0], sizeof(real_T) << 6U);
      may23_sin(sint);

      /* '<S371>:1:50' */
      may23_cos(t);

      /* '<S371>:1:51' */
      /* '<S371>:1:52' */
      for (i = 0; i < 64; i++) {
        w[i] = -deltax[i] * sint[i] + deltay[i] * t[i];
      }

      /* '<S371>:1:53' */
      /* '<S371>:1:54' */
      /* '<S371>:1:55' */
      may23_power(w, tmp);
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[e_target * 3
        - 3];
      for (i_0 = 0; i_0 < 64; i_0++) {
        h[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01 * (w[i_0] /
          (deltax[i_0] * t[i_0] + deltay[i_0] * sint[i_0]));
      }

      may23_power(h, w);
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[e_target * 3
        - 2];
      for (i_0 = 0; i_0 < 64; i_0++) {
        t[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
      }

      may23_power(t, sint);
      for (i = 0; i < 64; i++) {
        may23_B.intarget_j[i + ((e_target - 1) << 6)] = (tmp[i] <= 1.0 / (1.0 /
          w[i] + 1.0 / sint[i]));
      }
    }
  } else if (may23_P.KINARM_HandInBarrier_target_type == 3.0) {
    /* '<S371>:1:57' */
    /* '<S371>:1:58' */
    /* Constant: '<S6>/num_states' */
    for (e_target = 1; e_target - 1 < (int32_T)
         may23_P.KINARM_HandInBarrier_num_states; e_target++) {
      /* '<S371>:1:58' */
      /* '<S371>:1:59' */
      /* '<S371>:1:60' */
      if (may23_B.TmpSignalConversionAtSFunctionInport3_f[e_target * 3 - 1] >
          0.0) {
        /* '<S371>:1:62' */
        /* '<S371>:1:63' */
        i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[e_target *
          3 - 1];
        for (i_0 = 0; i_0 < 64; i_0++) {
          t[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] *
            0.017453292519943295;
        }
      } else {
        /* '<S371>:1:65' */
        for (i = 0; i < 64; i++) {
          t[i] = 0.0;
        }
      }

      /* '<S371>:1:68' */
      memcpy(&sint[0], &t[0], sizeof(real_T) << 6U);
      may23_sin(sint);

      /* '<S371>:1:69' */
      may23_cos(t);

      /* '<S371>:1:71' */
      /* '<S371>:1:72' */
      /* '<S371>:1:74' */
      for (i = 0; i < 64; i++) {
        h[i] = deltax[i] * t[i] + deltay[i] * sint[i];
      }

      may23_abs(h, tmp);
      for (i = 0; i < 64; i++) {
        h[i] = -deltax[i] * sint[i] + deltay[i] * t[i];
      }

      may23_abs(h, w);
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[e_target * 3
        - 3];
      i_0 = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[e_target *
        3 - 2];
      for (i_1 = 0; i_1 < 64; i_1++) {
        may23_B.intarget_j[i_1 + ((e_target - 1) << 6)] = ((tmp[i_1] <=
          may23_B.TargetTable[((i - 1) << 6) + i_1] * 0.01 / 2.0) && (w[i_1] <=
          may23_B.TargetTable[((i_0 - 1) << 6) + i_1] * 0.01 / 2.0));
      }
    }
  } else if (may23_P.KINARM_HandInBarrier_target_type == 4.0) {
    /* '<S371>:1:76' */
    /* '<S371>:1:77' */
    /* Constant: '<S6>/num_states' */
    for (e_target = 1; e_target - 1 < (int32_T)
         may23_P.KINARM_HandInBarrier_num_states; e_target++) {
      /* '<S371>:1:77' */
      if (may23_B.TmpSignalConversionAtSFunctionInport3_f[e_target * 3 - 3] ==
          0.0) {
        /* '<S371>:1:80' */
        /* '<S371>:1:81' */
        for (i = 0; i < 64; i++) {
          h[i] = 0.0;
        }
      } else if (may23_B.TmpSignalConversionAtSFunctionInport3_f[e_target * 3 -
                 3] < 0.0) {
        /* '<S371>:1:82' */
        /* '<S371>:1:83' */
        for (i = 0; i < 64; i++) {
          h[i] = 0.001;
        }
      } else {
        /* '<S371>:1:85' */
        i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[e_target *
          3 - 3];
        for (i_0 = 0; i_0 < 64; i_0++) {
          h[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
        }
      }

      /* '<S371>:1:88' */
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[e_target * 3
        - 2];
      for (i_0 = 0; i_0 < 64; i_0++) {
        w[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
      }

      /* '<S371>:1:89' */
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[e_target * 3
        - 1];
      for (i_0 = 0; i_0 < 64; i_0++) {
        p[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
      }

      /* '<S371>:1:91' */
      /* '<S371>:1:94' */
      /* '<S371>:1:95' */
      /* '<S371>:1:97' */
      may23_atan2(p, w, t);

      /* '<S371>:1:98' */
      for (i = 0; i < 64; i++) {
        dot02[i] = deltax[i] - w[i] / 2.0;
        dot11[i] = deltay[i] - p[i] / 2.0;
        sint[i] = t[i];
      }

      may23_sin(sint);

      /* '<S371>:1:99' */
      may23_cos(t);

      /* '<S371>:1:101' */
      /* '<S371>:1:102' */
      /* '<S371>:1:104' */
      may23_power(w, tmp);
      may23_power(p, w);
      for (i = 0; i < 64; i++) {
        p[i] = tmp[i] + w[i];
      }

      may23_sqrt(p);
      for (i = 0; i < 64; i++) {
        dot02_0[i] = dot02[i] * t[i] + dot11[i] * sint[i];
      }

      may23_abs(dot02_0, tmp);
      for (i = 0; i < 64; i++) {
        dot02_0[i] = -dot02[i] * sint[i] + dot11[i] * t[i];
      }

      may23_abs(dot02_0, w);
      for (i = 0; i < 64; i++) {
        may23_B.intarget_j[i + ((e_target - 1) << 6)] = ((tmp[i] <= p[i] / 2.0) &&
          (w[i] <= h[i] / 2.0));
      }
    }
  } else {
    if (may23_P.KINARM_HandInBarrier_target_type == 5.0) {
      /* '<S371>:1:106' */
      /* '<S371>:1:107' */
      /* Constant: '<S6>/num_states' */
      for (e_target = 1; e_target - 1 < (int32_T)
           may23_P.KINARM_HandInBarrier_num_states; e_target++) {
        /* '<S371>:1:107' */
        /* '<S371>:1:108' */
        i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[(e_target <<
          2) - 4];
        for (i_0 = 0; i_0 < 64; i_0++) {
          w[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
        }

        if (may23_B.TmpSignalConversionAtSFunctionInport3_f[(e_target << 2) - 3]
            > 0.0) {
          /* '<S371>:1:112' */
          /* '<S371>:1:113' */
          i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[(e_target
            << 2) - 3];
          for (i_0 = 0; i_0 < 64; i_0++) {
            h[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
          }

          /* '<S371>:1:114' */
          i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[(e_target
            << 2) - 2];
          for (i_0 = 0; i_0 < 64; i_0++) {
            p[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
          }
        } else {
          /* '<S371>:1:116' */
          /* '<S371>:1:117' */
          for (i = 0; i < 64; i++) {
            h[i] = w[i] * 0.8660254037844386;
            p[i] = 0.0;
          }
        }

        if (may23_B.TmpSignalConversionAtSFunctionInport3_f[(e_target << 2) - 1]
            > 0.0) {
          /* '<S371>:1:120' */
          /* '<S371>:1:121' */
          i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_f[(e_target
            << 2) - 1];
          for (i_0 = 0; i_0 < 64; i_0++) {
            t[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] *
              0.017453292519943295;
          }
        } else {
          /* '<S371>:1:123' */
          for (i = 0; i < 64; i++) {
            t[i] = 0.0;
          }
        }

        /* '<S371>:1:126' */
        memcpy(&sint[0], &t[0], sizeof(real_T) << 6U);
        may23_sin(sint);

        /* '<S371>:1:127' */
        may23_cos(t);

        /* '<S371>:1:129' */
        /* '<S371>:1:130' */
        /* '<S371>:1:133' */
        /* '<S371>:1:134' */
        /* '<S371>:1:135' */
        /* '<S371>:1:137' */
        /* '<S371>:1:138' */
        /* '<S371>:1:139' */
        /* '<S371>:1:141' */
        /* '<S371>:1:142' */
        /* '<S371>:1:143' */
        /* '<S371>:1:144' */
        /* '<S371>:1:145' */
        /* '<S371>:1:147' */
        /* '<S371>:1:148' */
        /* '<S371>:1:149' */
        for (i = 0; i < 64; i++) {
          h_0 = h[i];
          p_0 = p[i];
          w_0 = w[i];
          A[i] = -w_0 / 2.0 - p_0 / 3.0;
          A[i + 64] = -h_0 / 3.0;
          sint_0 = sint[i];
          deltay_0 = deltay[i];
          t_0 = t[i];
          deltax_0 = deltax[i];
          v0[i] = (w_0 / 2.0 - p_0 / 3.0) - A[i];
          v0[i + 64] = -h_0 / 3.0 - A[i + 64];
          v1[i] = 2.0 * p_0 / 3.0 - A[i];
          v1[i + 64] = 2.0 * h_0 / 3.0 - A[i + 64];
          v2[i] = (deltax_0 * t_0 + deltay_0 * sint_0) - A[i];
          v2[i + 64] = (-deltax_0 * sint_0 + deltay_0 * t_0) - A[i + 64];
          w_0 = v0[i + 64] * v0[i + 64] + v0[i] * v0[i];
          p_0 = v0[i + 64] * v1[i + 64] + v0[i] * v1[i];
          sint_0 = v0[i + 64] * v2[i + 64] + v0[i] * v2[i];
          deltay_0 = v1[i + 64] * v1[i + 64] + v1[i] * v1[i];
          t_0 = v1[i + 64] * v2[i + 64] + v1[i] * v2[i];
          h_0 = 1.0 / (w_0 * deltay_0 - p_0 * p_0);
          deltay_0 = (deltay_0 * sint_0 - p_0 * t_0) * h_0;
          w_0 = (w_0 * t_0 - p_0 * sint_0) * h_0;
          dot11[i] = deltay_0;
          w[i] = w_0;
          p[i] = p_0;
          h[i] = h_0;
        }

        /* '<S371>:1:151' */
        for (i = 0; i < 64; i++) {
          w_0 = w[i];
          deltay_0 = dot11[i];
          may23_B.intarget_j[i + ((e_target - 1) << 6)] = ((deltay_0 > 0.0) &&
            (w_0 > 0.0) && (deltay_0 + w_0 < 1.0));
        }
      }
    }
  }

  /* End of Constant: '<S6>/Target_Type' */
}
