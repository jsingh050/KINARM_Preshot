/*
 * Code generation for system system '<S1>/Network Transfer Subsystem'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_NetworkTransferSubsystem.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/* Named constants for Chart: '<S28>/Send Control Machine' */
#define may23_FULL_PACKET_SIZE         (410)
#define may23_IN_AddPacketToQueue      ((uint8_T)1U)
#define may23_IN_Fix                   ((uint8_T)1U)
#define may23_IN_Fixed                 ((uint8_T)1U)
#define may23_IN_Idle                  ((uint8_T)1U)
#define may23_IN_NO_ACTIVE_CHILD_hb    ((uint8_T)0U)
#define may23_IN_NoFix                 ((uint8_T)2U)
#define may23_IN_ResetUDPPort          ((uint8_T)2U)
#define may23_IN_SendPacket            ((uint8_T)2U)
#define may23_KINEMATIC_LEN            (400)
#define may23_event_e_clk_d            (2)
#define may23_event_e_data_ready_strobe (1)
#define may23_event_e_fast_clk         (3)
#define may23_event_e_reset_UDP        (0)

/* Forward declaration for local functions */
static void may23_TrackQueueSize(void);
static void may23_SendControlMachine(void);
static void may23_chartstep_c3_General(void);

/* System initialize for function-call system: '<S28>/UDP Send Subsystem' */
void may23_UDPSendSubsystem_Init(void)
{
  /* InitializeConditions for UnitDelay: '<S56>/Output' */
  may23_DW.Output_DSTATE_b = may23_P.Output_InitialCondition;

  /* SystemInitialize for Outport: '<S53>/total_packets_sent' */
  may23_B.Output_a = may23_P.total_packets_sent_Y0;
}

/* Start for function-call system: '<S28>/UDP Send Subsystem' */
void may23_UDPSendSubsystem_Start(void)
{
  /* Start for S-Function (slrtUDPSend): '<S53>/Send' */
  /* Level2 S-Function Block: '<S53>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[1];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }
}

/* Output and update for function-call system: '<S28>/UDP Send Subsystem' */
void may23_UDPSendSubsystem(void)
{
  /* UnitDelay: '<S56>/Output' */
  may23_B.Output_a = may23_DW.Output_DSTATE_b;

  /* Sum: '<S57>/FixPt Sum1' incorporates:
   *  Constant: '<S57>/FixPt Constant'
   */
  may23_B.FixPtSum1_d = may23_B.Output_a + may23_P.FixPtConstant_Value;

  /* Switch: '<S58>/FixPt Switch' incorporates:
   *  Constant: '<S58>/Constant'
   */
  if (may23_B.FixPtSum1_d > may23_P.WrapToZero_Threshold) {
    may23_B.FixPtSwitch_ii = may23_P.Constant_Value_j;
  } else {
    may23_B.FixPtSwitch_ii = may23_B.FixPtSum1_d;
  }

  /* End of Switch: '<S58>/FixPt Switch' */

  /* S-Function (xpcbytepacking): '<S53>/Pack' */

  /* Byte Packing: <S53>/Pack */
  (void)memcpy((uint8_T*)&may23_B.Pack_c[0] + 0, (uint8_T*)&may23_B.data_out[0],
               1640);

  /* S-Function (slrtUDPSend): '<S53>/Send' */

  /* Level2 S-Function Block: '<S53>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[1];
    sfcnOutputs(rts,1);
  }

  /* Update for UnitDelay: '<S56>/Output' */
  may23_DW.Output_DSTATE_b = may23_B.FixPtSwitch_ii;
  may23_DW.UDPSendSubsystem_SubsysRanBC = 4;
}

/* Termination for function-call system: '<S28>/UDP Send Subsystem' */
void may23_UDPSendSubsystem_Term(void)
{
  /* Terminate for S-Function (slrtUDPSend): '<S53>/Send' */
  /* Level2 S-Function Block: '<S53>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[1];
    sfcnTerminate(rts);
  }
}

/* Function for Chart: '<S28>/Send Control Machine' */
static void may23_TrackQueueSize(void)
{
  /* Graphical Function 'TrackQueueSize': '<S51>:8' */
  /* Transition: '<S51>:21' */
  if (may23_DW.queue_head < may23_DW.queue_tail) {
    /* Transition: '<S51>:22' */
    may23_B.queue_size = (real32_T)(((real_T)may23_DW.queue_head +
      may23_DW.packet_queue_sz) - (real_T)may23_DW.queue_tail);
  } else {
    if (may23_DW.queue_head >= may23_DW.queue_tail) {
      /* Transition: '<S51>:23' */
      may23_B.queue_size = (real32_T)(may23_DW.queue_head - may23_DW.queue_tail);
    }
  }
}

/* Function for Chart: '<S28>/Send Control Machine' */
static void may23_SendControlMachine(void)
{
  boolean_T guard1 = false;

  /* During 'SendControlMachine': '<S51>:4' */
  guard1 = false;
  switch (may23_DW.is_SendControlMachine) {
   case may23_IN_Fixed:
    may23_B.resetUDP = 0.0;

    /* During 'Fixed': '<S51>:375' */
    if (may23_DW.sfEvent_p2 == may23_event_e_reset_UDP) {
      /* Transition: '<S51>:393' */
      /* Exit Internal 'Fixed': '<S51>:375' */
      may23_DW.is_Fixed = may23_IN_NO_ACTIVE_CHILD_hb;
      may23_DW.is_SendControlMachine = may23_IN_ResetUDPPort;
      may23_DW.temporalCounter_i3 = 0U;

      /* Entry 'ResetUDPPort': '<S51>:289' */
      may23_B.resetUDP = 1.0;
    } else {
      switch (may23_DW.is_Fixed) {
       case may23_IN_Idle:
        /* During 'Idle': '<S51>:391' */
        if ((may23_DW.sfEvent_p2 == may23_event_e_fast_clk) &&
            (may23_DW.queue_head != may23_DW.queue_tail)) {
          /* Transition: '<S51>:386' */
          may23_DW.is_Fixed = may23_IN_SendPacket;
          may23_DW.temporalCounter_i1_i = 0U;

          /* Entry 'SendPacket': '<S51>:392' */
          buildOutputPacket(&may23_B.data_out[0], &may23_DW.packet_queue[410 *
                            (int32_T)may23_DW.queue_tail],
                            may23_FULL_PACKET_SIZE, may23_B.queue_size,
                            may23_B.total_timeouts,
                            may23_B.DataTypeConversion2_k);
          may23_DW.outstanding_packet_index = may23_B.data_out[2];

          /* Outputs for Function Call SubSystem: '<S28>/UDP Send Subsystem' */
          /* Event: '<S51>:66' */
          may23_UDPSendSubsystem();

          /* End of Outputs for SubSystem: '<S28>/UDP Send Subsystem' */
        }
        break;

       case may23_IN_SendPacket:
        /* During 'SendPacket': '<S51>:392' */
        if ((may23_DW.sfEvent_p2 == may23_event_e_fast_clk) &&
            (may23_DW.temporalCounter_i1_i >= 10)) {
          /* Transition: '<S51>:388' */
          /* Transition: '<S51>:390' */
          if (may23_B.Convert16 == 0.0) {
            /* Transition: '<S51>:406' */
            may23_B.total_timeouts++;
          } else {
            /* Transition: '<S51>:407' */
            /* Transition: '<S51>:389' */
            may23_B.total_timeouts++;
          }

          guard1 = true;
        } else {
          /* Transition: '<S51>:387' */
          if ((may23_DW.sfEvent_p2 == may23_event_e_fast_clk) &&
              (may23_B.DataTypeConversion_pa ==
               may23_DW.outstanding_packet_index)) {
            /* Transition: '<S51>:385' */
            may23_DW.queue_tail = (uint32_T)fmod(may23_DW.queue_tail + 1U,
              may23_DW.packet_queue_sz);

            /* Transition: '<S51>:383' */
            if (may23_DW.queue_head == may23_DW.queue_tail) {
              /* Transition: '<S51>:382' */
              may23_DW.is_Fixed = may23_IN_Idle;

              /* Entry 'Idle': '<S51>:391' */
              /*  Wait to acquire a new packet to send. */
            } else {
              if (may23_DW.queue_head != may23_DW.queue_tail) {
                /* Transition: '<S51>:384' */
                guard1 = true;
              }
            }
          }
        }
        break;

       default:
        /* Unreachable state, for coverage only */
        may23_DW.is_Fixed = may23_IN_NO_ACTIVE_CHILD_hb;
        break;
      }
    }
    break;

   case may23_IN_ResetUDPPort:
    may23_B.resetUDP = 1.0;

    /* During 'ResetUDPPort': '<S51>:289' */
    if ((may23_DW.sfEvent_p2 == may23_event_e_fast_clk) &&
        (may23_DW.temporalCounter_i3 >= 2)) {
      /* Transition: '<S51>:395' */
      may23_DW.is_SendControlMachine = may23_IN_Fixed;

      /* Entry 'Fixed': '<S51>:375' */
      may23_B.resetUDP = 0.0;

      /* Entry Internal 'Fixed': '<S51>:375' */
      /* Transition: '<S51>:381' */
      may23_DW.is_Fixed = may23_IN_Idle;

      /* Entry 'Idle': '<S51>:391' */
      /*  Wait to acquire a new packet to send. */
    }
    break;

   default:
    /* Unreachable state, for coverage only */
    may23_DW.is_SendControlMachine = may23_IN_NO_ACTIVE_CHILD_hb;
    break;
  }

  if (guard1) {
    may23_DW.is_Fixed = may23_IN_SendPacket;
    may23_DW.temporalCounter_i1_i = 0U;

    /* Entry 'SendPacket': '<S51>:392' */
    buildOutputPacket(&may23_B.data_out[0], &may23_DW.packet_queue[410 *
                      (int32_T)may23_DW.queue_tail], may23_FULL_PACKET_SIZE,
                      may23_B.queue_size, may23_B.total_timeouts,
                      may23_B.DataTypeConversion2_k);
    may23_DW.outstanding_packet_index = may23_B.data_out[2];

    /* Outputs for Function Call SubSystem: '<S28>/UDP Send Subsystem' */
    /* Event: '<S51>:66' */
    may23_UDPSendSubsystem();

    /* End of Outputs for SubSystem: '<S28>/UDP Send Subsystem' */
  }
}

/* Function for Chart: '<S28>/Send Control Machine' */
static void may23_chartstep_c3_General(void)
{
  int32_T b_previousEvent;

  /* Chart: '<S28>/Send Control Machine' */
  /* During: DataLogging/Network Transfer Subsystem/Send Control Machine */
  if (may23_DW.is_active_c3_General == 0U) {
    /* Entry: DataLogging/Network Transfer Subsystem/Send Control Machine */
    may23_DW.is_active_c3_General = 1U;

    /* Entry Internal: DataLogging/Network Transfer Subsystem/Send Control Machine */
    may23_DW.is_active_UpdatePacketQueue = 1U;

    /* Entry Internal 'UpdatePacketQueue': '<S51>:7' */
    /* Transition: '<S51>:20' */
    may23_DW.is_UpdatePacketQueue = may23_IN_AddPacketToQueue;
    may23_DW.is_active_SendControlMachine = 1U;

    /* Entry Internal 'SendControlMachine': '<S51>:4' */
    /* Transition: '<S51>:236' */
    may23_DW.is_SendControlMachine = may23_IN_Fixed;

    /* Entry 'Fixed': '<S51>:375' */
    may23_B.resetUDP = 0.0;

    /* Entry Internal 'Fixed': '<S51>:375' */
    /* Transition: '<S51>:381' */
    may23_DW.is_Fixed = may23_IN_Idle;

    /* Entry 'Idle': '<S51>:391' */
    /*  Wait to acquire a new packet to send. */
    may23_DW.is_active_FixMonitor = 1U;

    /* Entry Internal 'FixMonitor': '<S51>:183' */
    /* Transition: '<S51>:189' */
    may23_DW.is_FixMonitor = may23_IN_NoFix;
  } else {
    if ((may23_DW.is_active_UpdatePacketQueue != 0U) &&
        (may23_DW.is_UpdatePacketQueue == may23_IN_AddPacketToQueue)) {
      /* During 'UpdatePacketQueue': '<S51>:7' */
      /* During 'AddPacketToQueue': '<S51>:6' */
      /* Transition: '<S51>:181' */
      if (may23_DW.sfEvent_p2 == may23_event_e_data_ready_strobe) {
        /* Transition: '<S51>:180' */
        /*  Prepend the data of the new packet in the queue with the packet's index,
           a.k.a. "tracking number". */
        may23_DW.packet_index++;
        may23_DW.packet_queue[410 * (int32_T)may23_DW.queue_head + 2] =
          (real32_T)may23_DW.packet_index;

        /* identify the packet version */
        may23_DW.packet_queue[410 * (int32_T)may23_DW.queue_head + 1] = -12.0F;

        /*  Copy the new packet into the packet_queue. //CopyInput(); */
        recordPacket(&may23_DW.packet_queue[may23_DW.j + 410 * (int32_T)
                     may23_DW.queue_head], may23_FULL_PACKET_SIZE,
                     &may23_B.RateTransition1_l[0], may23_KINEMATIC_LEN);

        /*  Increment the head pointer of the packet_queue for the next packet. */
        may23_DW.queue_head = (uint32_T)fmod(may23_DW.queue_head + 1U,
          may23_DW.packet_queue_sz);
        if (may23_DW.packet_index == may23_B.max_packet_id) {
          /* Transition: '<S51>:37' */
          may23_DW.packet_index = 0U;
        } else {
          /* Transition: '<S51>:36' */
        }

        if (may23_DW.queue_head == may23_DW.queue_tail) {
          /* Transition: '<S51>:32' */
          may23_DW.queue_tail = (uint32_T)fmod(may23_DW.queue_tail + 1U,
            may23_DW.packet_queue_sz);
        } else {
          /* Transition: '<S51>:33' */
        }

        /* Transition: '<S51>:31' */
        may23_TrackQueueSize();
      } else {
        /* Transition: '<S51>:182' */
      }

      may23_DW.is_UpdatePacketQueue = may23_IN_AddPacketToQueue;
    }

    if (may23_DW.is_active_SendControlMachine != 0U) {
      may23_SendControlMachine();
    }

    if (may23_DW.is_active_FixMonitor != 0U) {
      /* During 'FixMonitor': '<S51>:183' */
      switch (may23_DW.is_FixMonitor) {
       case may23_IN_Fix:
        /* During 'Fix': '<S51>:186' */
        if ((may23_DW.sfEvent_p2 == may23_event_e_fast_clk) &&
            (may23_DW.temporalCounter_i2_a >= 1000)) {
          /* Transition: '<S51>:298' */
          may23_DW.is_FixMonitor = may23_IN_NoFix;
        }
        break;

       case may23_IN_NoFix:
        /* During 'NoFix': '<S51>:184' */
        if (may23_B.queue_size > 2500.0F) {
          /* Transition: '<S51>:187' */
          may23_DW.is_FixMonitor = may23_IN_Fix;
          may23_DW.temporalCounter_i2_a = 0U;

          /* Entry 'Fix': '<S51>:186' */
          b_previousEvent = may23_DW.sfEvent_p2;
          may23_DW.sfEvent_p2 = may23_event_e_reset_UDP;
          if (may23_DW.is_active_SendControlMachine != 0U) {
            may23_SendControlMachine();
          }

          may23_DW.sfEvent_p2 = b_previousEvent;
        }
        break;

       default:
        /* Unreachable state, for coverage only */
        may23_DW.is_FixMonitor = may23_IN_NO_ACTIVE_CHILD_hb;
        break;
      }
    }
  }

  /* End of Chart: '<S28>/Send Control Machine' */
}

real_T rt_modd_snf(real_T u0, real_T u1)
{
  real_T y;
  boolean_T yEq;
  real_T q;
  y = u0;
  if (u1 == 0.0) {
    if (u0 == 0.0) {
      y = u1;
    }
  } else if (rtIsNaN(u0) || rtIsNaN(u1) || rtIsInf(u0)) {
    y = (rtNaN);
  } else if (u0 == 0.0) {
    y = 0.0 / u1;
  } else if (rtIsInf(u1)) {
    if ((u1 < 0.0) != (u0 < 0.0)) {
      y = u1;
    }
  } else {
    y = fmod(u0, u1);
    yEq = (y == 0.0);
    if ((!yEq) && (u1 > floor(u1))) {
      q = fabs(u0 / u1);
      yEq = !(fabs(q - floor(q + 0.5)) > DBL_EPSILON * q);
    }

    if (yEq) {
      y = u1 * 0.0;
    } else {
      if ((u0 < 0.0) != (u1 < 0.0)) {
        y += u1;
      }
    }
  }

  return y;
}

/* System initialize for atomic system: '<S1>/Network Transfer Subsystem' */
void may23_NetworkTransferSubsystem_Init(void)
{
  int32_T i;

  /* InitializeConditions for RateTransition: '<S28>/Rate Transition1' */
  for (i = 0; i < 400; i++) {
    may23_DW.RateTransition1_Buffer0_i[i] =
      may23_P.RateTransition1_InitialCondition_c;
  }

  /* End of InitializeConditions for RateTransition: '<S28>/Rate Transition1' */

  /* InitializeConditions for RateTransition: '<S54>/Rate Transition2' */
  may23_DW.RateTransition2_Buffer0_i = may23_P.RateTransition2_InitialCondition;

  /* InitializeConditions for Memory: '<S52>/Memory2' */
  may23_DW.Memory2_PreviousInput_b = may23_P.Memory2_InitialCondition;

  /* InitializeConditions for Memory: '<S52>/Memory1' */
  may23_DW.Memory1_PreviousInput_c = may23_P.Memory1_InitialCondition;

  /* InitializeConditions for RateTransition: '<S54>/Rate Transition1' */
  may23_DW.RateTransition1_Buffer0_l =
    may23_P.RateTransition1_InitialCondition_l;

  /* SystemInitialize for Atomic SubSystem: '<S28>/Data Packing Subsystem' */
  /* InitializeConditions for UnitDelay: '<S55>/Unit Delay' */
  may23_DW.UnitDelay_DSTATE_e = may23_P.UnitDelay_InitialCondition;
  for (i = 0; i < 182; i++) {
    /* InitializeConditions for Memory: '<S50>/t-2' */
    may23_DW.t2_PreviousInput[i] = may23_P.t2_InitialCondition;

    /* InitializeConditions for Memory: '<S50>/t-1' */
    may23_DW.t1_PreviousInput[i] = may23_P.t1_InitialCondition;
  }

  /* End of SystemInitialize for SubSystem: '<S28>/Data Packing Subsystem' */
  may23_DW.is_active_FixMonitor = 0U;
  may23_DW.is_FixMonitor = may23_IN_NO_ACTIVE_CHILD_hb;
  may23_DW.temporalCounter_i2_a = 0U;
  may23_DW.is_active_SendControlMachine = 0U;
  may23_DW.is_SendControlMachine = may23_IN_NO_ACTIVE_CHILD_hb;
  may23_DW.is_Fixed = may23_IN_NO_ACTIVE_CHILD_hb;
  may23_DW.temporalCounter_i1_i = 0U;
  may23_DW.temporalCounter_i3 = 0U;
  may23_DW.is_active_UpdatePacketQueue = 0U;
  may23_DW.is_UpdatePacketQueue = may23_IN_NO_ACTIVE_CHILD_hb;
  may23_DW.is_active_c3_General = 0U;
  may23_DW.queue_tail = 0U;
  may23_DW.packet_index = 0U;
  for (i = 0; i < 20500000; i++) {
    may23_DW.packet_queue[i] = 0.0F;
  }

  may23_DW.packet_queue_sz = 50000.0;
  may23_DW.j = 0;
  may23_DW.outstanding_packet_index = 0.0;
  may23_DW.queue_head = 0U;
  may23_B.resetUDP = 0.0;
  for (i = 0; i < 410; i++) {
    may23_B.data_out[i] = 0.0F;
  }

  may23_B.queue_size = 0.0F;
  may23_B.total_timeouts = 0.0F;

  /* SystemInitialize for Chart: '<S28>/Send Control Machine' incorporates:
   *  SubSystem: '<S28>/UDP Send Subsystem'
   */
  may23_UDPSendSubsystem_Init();

  /* SystemInitialize for MATLAB Function: '<S54>/force strobe' */
  may23_DW.counter = 0.0;
}

/* Start for atomic system: '<S1>/Network Transfer Subsystem' */
void may23_NetworkTransferSubsystem_Start(void)
{
  int32_T i;

  /* Start for RateTransition: '<S28>/Rate Transition1' */
  for (i = 0; i < 400; i++) {
    may23_B.RateTransition1_l[i] = may23_P.RateTransition1_InitialCondition_c;
  }

  /* End of Start for RateTransition: '<S28>/Rate Transition1' */

  /* Start for S-Function (slrtUDPReceive): '<S52>/Receive' */
  /* Level2 S-Function Block: '<S52>/Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[2];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for Constant: '<S28>/max_packet_id' */
  may23_B.max_packet_id = may23_P.max_packet_id_Value;

  /* Start for RateTransition: '<S54>/Rate Transition2' */
  may23_B.RateTransition2_a = may23_P.RateTransition2_InitialCondition;

  /* Start for DiscretePulseGenerator: '<S28>/Task Clock' */
  may23_DW.clockTickCounter_n = 0;

  /* Start for Chart: '<S28>/Send Control Machine' incorporates:
   *  SubSystem: '<S28>/UDP Send Subsystem'
   */
  may23_UDPSendSubsystem_Start();

  /* Start for RateTransition: '<S54>/Rate Transition1' */
  may23_B.RateTransition1_l1 = may23_P.RateTransition1_InitialCondition_l;

  /* Start for Atomic SubSystem: '<S28>/Data Packing Subsystem' */
  /* Start for Width: '<S50>/Width' */
  may23_B.Width = 182.0;

  /* End of Start for SubSystem: '<S28>/Data Packing Subsystem' */
}

/* Outputs for atomic system: '<S1>/Network Transfer Subsystem' */
void may23_NetworkTransferSubsystemTID0(void)
{
  boolean_T zcEvent;
  ZCEventType zcEvent_idx_0;
  ZCEventType zcEvent_idx_1;
  ZCEventType zcEvent_idx_2;
  int32_T tmp;
  real32_T tmp_0;

  /* DataTypeConversion: '<S28>/Data Type Conversion2' incorporates:
   *  Constant: '<S28>/runID'
   */
  may23_B.DataTypeConversion2_k = (real32_T)may23_P.runID_Value;

  /* RateTransition: '<S28>/Rate Transition1' */
  if (may23_M->Timing.RateInteraction.TID1_3) {
    memcpy(&may23_B.RateTransition1_l[0], &may23_DW.RateTransition1_Buffer0_i[0],
           400U * sizeof(real32_T));
  }

  /* End of RateTransition: '<S28>/Rate Transition1' */

  /* S-Function (slrtUDPReceive): '<S52>/Receive' */

  /* Level2 S-Function Block: '<S52>/Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[2];
    sfcnOutputs(rts,1);
  }

  /* S-Function (xpcbytepacking): '<S52>/Unpack' */

  /* Byte Unpacking: <S52>/Unpack */
  (void)memcpy((uint8_T*)&may23_B.Unpack_n, (uint8_T*)&may23_B.Receive_o1_m[1] +
               0, 4);

  /* DataTypeConversion: '<S52>/Data Type Conversion' */
  may23_B.DataTypeConversion_pa = (uint32_T)may23_B.Unpack_n;

  /* Constant: '<S28>/max_packet_id' */
  may23_B.max_packet_id = may23_P.max_packet_id_Value;

  /* RateTransition: '<S54>/Rate Transition2' */
  if (may23_M->Timing.RateInteraction.TID1_2) {
    may23_B.RateTransition2_a = may23_DW.RateTransition2_Buffer0_i;
  }

  /* End of RateTransition: '<S54>/Rate Transition2' */

  /* DiscretePulseGenerator: '<S28>/Task Clock' */
  may23_B.TaskClock_e = (may23_DW.clockTickCounter_n < may23_P.TaskClock_Duty) &&
    (may23_DW.clockTickCounter_n >= 0) ? may23_P.TaskClock_Amp : 0.0;
  if (may23_DW.clockTickCounter_n >= may23_P.TaskClock_Period - 1.0) {
    may23_DW.clockTickCounter_n = 0;
  } else {
    may23_DW.clockTickCounter_n++;
  }

  /* End of DiscretePulseGenerator: '<S28>/Task Clock' */

  /* Chart: '<S28>/Send Control Machine' incorporates:
   *  TriggerPort: '<S51>/ input events '
   */
  zcEvent_idx_0 = rt_ZCFcn(ANY_ZERO_CROSSING,
    &may23_PrevZCX.SendControlMachine_Trig_ZCE[0],
    (may23_B.RateTransition2_a));
  zcEvent_idx_1 = rt_ZCFcn(ANY_ZERO_CROSSING,
    &may23_PrevZCX.SendControlMachine_Trig_ZCE[1],
    (may23_B.Convert17));
  zcEvent_idx_2 = rt_ZCFcn(ANY_ZERO_CROSSING,
    &may23_PrevZCX.SendControlMachine_Trig_ZCE[2],
    (may23_B.TaskClock_e));
  zcEvent = (zcEvent_idx_0 != NO_ZCEVENT);
  zcEvent = (zcEvent || (zcEvent_idx_1 != NO_ZCEVENT));
  zcEvent = (zcEvent || (zcEvent_idx_2 != NO_ZCEVENT));
  if (zcEvent) {
    may23_B.inputevents_j[0] = (int8_T)zcEvent_idx_0;
    may23_B.inputevents_j[1] = (int8_T)zcEvent_idx_1;
    may23_B.inputevents_j[2] = (int8_T)zcEvent_idx_2;

    /* Gateway: DataLogging/Network Transfer Subsystem/Send Control Machine */
    if (may23_B.inputevents_j[0U] == 1) {
      /* Event: '<S51>:67' */
      may23_DW.sfEvent_p2 = may23_event_e_data_ready_strobe;
      may23_chartstep_c3_General();
    }

    if (may23_B.inputevents_j[1U] == 1) {
      if (may23_DW.temporalCounter_i1_i < 15U) {
        may23_DW.temporalCounter_i1_i++;
      }

      if (may23_DW.temporalCounter_i2_a < 1023U) {
        may23_DW.temporalCounter_i2_a++;
      }

      /* Event: '<S51>:208' */
      may23_DW.sfEvent_p2 = may23_event_e_clk_d;
      may23_chartstep_c3_General();
    }

    if (may23_B.inputevents_j[2U] != 0) {
      if (may23_DW.temporalCounter_i3 < 3U) {
        may23_DW.temporalCounter_i3++;
      }

      /* Event: '<S51>:258' */
      may23_DW.sfEvent_p2 = may23_event_e_fast_clk;
      may23_chartstep_c3_General();
    }

    may23_DW.SendControlMachine_SubsysRanBC = 4;
  }

  /* DataTypeConversion: '<S28>/Queue Size' */
  tmp_0 = may23_B.queue_size;
  if (tmp_0 < 2.14748365E+9F) {
    if (tmp_0 >= -2.14748365E+9F) {
      tmp = (int32_T)tmp_0;
    } else {
      tmp = MIN_int32_T;
    }
  } else {
    tmp = MAX_int32_T;
  }

  may23_B.queue_size_i = tmp;

  /* End of DataTypeConversion: '<S28>/Queue Size' */

  /* DataTypeConversion: '<S28>/Total Timeouts' */
  tmp_0 = may23_B.total_timeouts;
  if (tmp_0 < 2.14748365E+9F) {
    if (tmp_0 >= -2.14748365E+9F) {
      tmp = (int32_T)tmp_0;
    } else {
      tmp = MIN_int32_T;
    }
  } else {
    tmp = MAX_int32_T;
  }

  may23_B.timeouts = tmp;

  /* End of DataTypeConversion: '<S28>/Total Timeouts' */

  /* Memory: '<S52>/Memory2' */
  may23_B.trigger = may23_DW.Memory2_PreviousInput_b;

  /* Memory: '<S52>/Memory1' */
  may23_B.Memory1_m = may23_DW.Memory1_PreviousInput_c;
}

/* Outputs for atomic system: '<S1>/Network Transfer Subsystem' */
void may23_NetworkTransferSubsystemTID2(void)
{
  real_T r;

  /* RateTransition: '<S54>/Rate Transition1' */
  if (may23_M->Timing.RateInteraction.TID2_3) {
    may23_B.RateTransition1_l1 = may23_DW.RateTransition1_Buffer0_l;
  }

  /* End of RateTransition: '<S54>/Rate Transition1' */

  /* MATLAB Function: '<S54>/force strobe' */
  /* MATLAB Function 'DataLogging/Network Transfer Subsystem/force strobe/force strobe': '<S59>:1' */
  /* '<S59>:1:17' */
  may23_DW.counter++;
  if (rtIsNaN(may23_DW.counter) || rtIsInf(may23_DW.counter)) {
    r = (rtNaN);
  } else if (may23_DW.counter == 0.0) {
    r = 0.0;
  } else {
    r = fmod(may23_DW.counter, 2.0);
    if (r == 0.0) {
      r = 0.0;
    } else {
      if (may23_DW.counter < 0.0) {
        r += 2.0;
      }
    }
  }

  if (r == 0.0) {
    /* '<S59>:1:19' */
    /* '<S59>:1:20' */
    may23_B.strobe_out = 0.0;

    /* '<S59>:1:21' */
    may23_DW.counter = 0.0;
  } else {
    /* '<S59>:1:23' */
    may23_B.strobe_out = may23_B.RateTransition1_l1;
  }

  /* End of MATLAB Function: '<S54>/force strobe' */

  /* RateTransition: '<S54>/Rate Transition2' */
  may23_DW.RateTransition2_Buffer0_i = may23_B.strobe_out;
}

/* Outputs for atomic system: '<S1>/Network Transfer Subsystem' */
void may23_NetworkTransferSubsystemTID3(void)
{
  int32_T i;
  real_T u0;
  real_T u1;

  /* Outputs for Atomic SubSystem: '<S28>/Data Packing Subsystem' */
  /* UnitDelay: '<S55>/Unit Delay' */
  may23_B.UnitDelay_h = may23_DW.UnitDelay_DSTATE_e;

  /* Sum: '<S55>/Sum' incorporates:
   *  Constant: '<S55>/Constant'
   */
  may23_B.Sum = may23_B.UnitDelay_h + may23_P.Constant_Value;

  /* DataTypeConversion: '<S50>/Data Type Conversion' */
  for (i = 0; i < 16; i++) {
    may23_B.DataTypeConversion_i[i] = (real32_T)may23_B.RateTransition1_a[i];
  }

  may23_B.DataTypeConversion_i[16] = (real32_T)may23_B.RateTransition2_h[0];
  may23_B.DataTypeConversion_i[17] = (real32_T)may23_B.RateTransition2_h[1];
  may23_B.DataTypeConversion_i[18] = (real32_T)may23_ConstB.Width_m;
  for (i = 0; i < 72; i++) {
    may23_B.DataTypeConversion_i[i + 19] = (real32_T)may23_B.RateTransition_k[i];
  }

  for (i = 0; i < 71; i++) {
    may23_B.DataTypeConversion_i[i + 91] = (real32_T)may23_B.RateTransition_e[i];
  }

  for (i = 0; i < 20; i++) {
    may23_B.DataTypeConversion_i[i + 162] = (real32_T)may23_B.RateTransition_p[i];
  }

  /* End of DataTypeConversion: '<S50>/Data Type Conversion' */

  /* Fcn: '<S50>/Ideal Frames Per Packet' */
  may23_B.IdealFramesPerPacket = floor(400.0 / may23_B.Width);

  /* MinMax: '<S50>/MinMax' incorporates:
   *  Constant: '<S50>/Max Frames Per Packet'
   */
  u0 = may23_P.MaxFramesPerPacket_Value;
  u1 = may23_B.IdealFramesPerPacket;
  if ((u0 < u1) || rtIsNaN(u1)) {
    u1 = u0;
  }

  may23_B.MinMax_b = u1;

  /* End of MinMax: '<S50>/MinMax' */

  /* Math: '<S50>/Math Function' */
  may23_B.MathFunction = rt_modd_snf(may23_B.Sum, may23_B.MinMax_b);

  /* Sum: '<S50>/Subtract' incorporates:
   *  Constant: '<S50>/Max Frames Per Packet'
   */
  may23_B.Subtract_h = may23_P.MaxFramesPerPacket_Value - may23_B.MinMax_b;

  /* Product: '<S50>/Product' */
  may23_B.Product_i0 = may23_B.Width * may23_B.Subtract_h;

  /* RelationalOperator: '<S50>/Relational Operator' incorporates:
   *  Constant: '<S50>/Constant1'
   */
  may23_B.RelationalOperator = (may23_P.Constant1_Value == may23_B.MathFunction);

  /* Memory: '<S50>/t-2' */
  memcpy(&may23_B.t2[0], &may23_DW.t2_PreviousInput[0], 182U * sizeof(real32_T));

  /* Memory: '<S50>/t-1' */
  memcpy(&may23_B.t1[0], &may23_DW.t1_PreviousInput[0], 182U * sizeof(real32_T));

  /* SignalConversion generated from: '<S50>/Selector' incorporates:
   *  Constant: '<S50>/Constant'
   */
  memcpy(&may23_B.TmpSignalConversionAtSelectorInport1[0], &may23_B.t2[0], 182U *
         sizeof(real32_T));
  memcpy(&may23_B.TmpSignalConversionAtSelectorInport1[182], &may23_B.t1[0],
         182U * sizeof(real32_T));
  memcpy(&may23_B.TmpSignalConversionAtSelectorInport1[364],
         &may23_B.DataTypeConversion_i[0], 182U * sizeof(real32_T));
  memcpy(&may23_B.TmpSignalConversionAtSelectorInport1[546],
         &may23_P.Constant_Value_bt[0], 400U * sizeof(real32_T));
  for (i = 0; i < 400; i++) {
    /* Selector: '<S50>/Selector' */
    may23_B.Selector_pl[i] = may23_B.TmpSignalConversionAtSelectorInport1[i +
      (int32_T)may23_B.Product_i0];

    /* RateTransition: '<S28>/Rate Transition1' */
    may23_DW.RateTransition1_Buffer0_i[i] = may23_B.Selector_pl[i];
  }

  /* End of Outputs for SubSystem: '<S28>/Data Packing Subsystem' */

  /* RateTransition: '<S54>/Rate Transition1' */
  may23_DW.RateTransition1_Buffer0_l = may23_B.RelationalOperator;
}

/* Update for atomic system: '<S1>/Network Transfer Subsystem' */
void may23_NetworkTransferSubsystem_UpdateTID0(void)
{
  /* Update for Memory: '<S52>/Memory2' */
  may23_DW.Memory2_PreviousInput_b = may23_B.resetUDP;

  /* Update for Memory: '<S52>/Memory1' */
  may23_DW.Memory1_PreviousInput_c = 0.0;
}

/* Update for atomic system: '<S1>/Network Transfer Subsystem' */
void may23_NetworkTransferSubsystem_UpdateTID3(void)
{
  /* Update for Atomic SubSystem: '<S28>/Data Packing Subsystem' */
  /* Update for UnitDelay: '<S55>/Unit Delay' */
  may23_DW.UnitDelay_DSTATE_e = may23_B.Sum;

  /* Update for Memory: '<S50>/t-2' */
  memcpy(&may23_DW.t2_PreviousInput[0], &may23_B.t1[0], 182U * sizeof(real32_T));

  /* Update for Memory: '<S50>/t-1' */
  memcpy(&may23_DW.t1_PreviousInput[0], &may23_B.DataTypeConversion_i[0], 182U *
         sizeof(real32_T));

  /* End of Update for SubSystem: '<S28>/Data Packing Subsystem' */
}

/* Termination for atomic system: '<S1>/Network Transfer Subsystem' */
void may23_NetworkTransferSubsystem_Term(void)
{
  /* Terminate for S-Function (slrtUDPReceive): '<S52>/Receive' */
  /* Level2 S-Function Block: '<S52>/Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[2];
    sfcnTerminate(rts);
  }

  /* Terminate for Chart: '<S28>/Send Control Machine' incorporates:
   *  SubSystem: '<S28>/UDP Send Subsystem'
   */
  may23_UDPSendSubsystem_Term();
}
