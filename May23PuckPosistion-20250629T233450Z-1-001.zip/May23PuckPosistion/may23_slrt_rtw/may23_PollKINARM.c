/*
 * Code generation for system system '<S1>/Poll KINARM'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_PollKINARM.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/* Named constants for Chart: '<S104>/Read EMCY' */
#define may23_CALL_EVENT_c             (-1)
#define may23_IN_DoneClearing          ((uint8_T)1U)
#define may23_IN_NO_ACTIVE_CHILD       ((uint8_T)0U)
#define may23_IN_ReadNextEMCY          ((uint8_T)2U)
#define may23_IN_ReceivedFloat         ((uint8_T)3U)
#define may23_IN_StartOverwrite        ((uint8_T)4U)
#define may23_IN_StartReadingCount     ((uint8_T)5U)
#define may23_IN_disableCount          ((uint8_T)6U)
#define may23_IN_disableEMCY           ((uint8_T)7U)
#define may23_IN_setup                 ((uint8_T)8U)
#define may23_IN_startEMCYs            ((uint8_T)9U)

/* Named constants for Chart: '<S87>/Whistle state' */
#define may23_CALL_EVENT_cc            (-1)
#define may23_CWDisable                ((uint16_T)0U)
#define may23_CWEnable                 ((uint16_T)15U)
#define may23_CWGetReady               ((uint16_T)6U)
#define may23_CWResetFault             ((uint16_T)128U)
#define may23_IN_Faulted               ((uint8_T)1U)
#define may23_IN_MotorStatusUpdate     ((uint8_T)1U)
#define may23_IN_NO_ACTIVE_CHILD_h     ((uint8_T)0U)
#define may23_IN_ReadyToGo             ((uint8_T)1U)
#define may23_IN_ResetEstop            ((uint8_T)2U)
#define may23_IN_SWFault_8             ((uint8_T)1U)
#define may23_IN_SWOperationEnabled_39 ((uint8_T)2U)
#define may23_IN_SWReadyToSwitchOn_33  ((uint8_T)3U)
#define may23_IN_SWSwitchOnDisabled_64 ((uint8_T)4U)
#define may23_IN_StatusMonitor         ((uint8_T)1U)
#define may23_IN_UnknownState          ((uint8_T)5U)
#define may23_IN_Wait                  ((uint8_T)3U)
#define may23_IN_WaitReset             ((uint8_T)4U)
#define may23_IN_Waiting               ((uint8_T)2U)
#define may23_IN_Waiting1              ((uint8_T)1U)
#define may23_IN_Waiting2              ((uint8_T)1U)
#define may23_IN_Working               ((uint8_T)2U)
#define may23_IN_eStopped              ((uint8_T)5U)
#define may23_SWFault                  (8.0)
#define may23_SWOperationEnabled       (39.0)
#define may23_SWReadyToSwitchOn        (33.0)
#define may23_SWSwitchOnDisabled       (64.0)

/* Named constants for Chart: '<S91>/AbsEncoder machine' */
#define may23_CALL_EVENT_b             (-1)
#define may23_IN_Complete              ((uint8_T)1U)
#define may23_IN_Done                  ((uint8_T)2U)
#define may23_IN_NO_ACTIVE_CHILD_o     ((uint8_T)0U)
#define may23_IN_PollingComplete       ((uint8_T)3U)
#define may23_IN_ReadNext              ((uint8_T)4U)
#define may23_IN_ReadNextEncoder       ((uint8_T)5U)
#define may23_IN_Received              ((uint8_T)6U)
#define may23_IN_disable               ((uint8_T)7U)
#define may23_IN_disable1              ((uint8_T)8U)
#define may23_IN_disableRead           ((uint8_T)9U)
#define may23_IN_encoderReadSetup      ((uint8_T)10U)
#define may23_IN_pollReceived          ((uint8_T)11U)
#define may23_IN_receivedEncoder       ((uint8_T)12U)
#define may23_IN_setup_e               ((uint8_T)13U)
#define may23_IN_startPolling          ((uint8_T)14U)

/* Named constants for Chart: '<S94>/SDO read machine' */
#define may23_CALL_EVENT_en            (-1)
#define may23_IN_NO_ACTIVE_CHILD_m     ((uint8_T)0U)
#define may23_IN_ReadNext_l            ((uint8_T)1U)
#define may23_IN_disable_o             ((uint8_T)2U)
#define may23_IN_setup_f               ((uint8_T)3U)

/* Named constants for Chart: '<S95>/SDO write machine' */
#define may23_CALL_EVENT_ov            (-1)
#define may23_IN_NO_ACTIVE_CHILD_f     ((uint8_T)0U)
#define may23_IN_ReadNext_f            ((uint8_T)1U)
#define may23_IN_disable_c             ((uint8_T)2U)
#define may23_IN_setup_d               ((uint8_T)3U)

/* Named constants for Chart: '<S77>/SDO read machine' */
#define may23_IN_Done_m                ((uint8_T)1U)
#define may23_IN_Error                 ((uint8_T)2U)
#define may23_IN_NO_ACTIVE_CHILD_mv    ((uint8_T)0U)
#define may23_IN_ReadNextFloat         ((uint8_T)3U)
#define may23_IN_ReadNextInt           ((uint8_T)4U)
#define may23_IN_ReceivedFloat_h       ((uint8_T)5U)
#define may23_IN_ReceivedInt           ((uint8_T)6U)
#define may23_IN_disableFloat          ((uint8_T)7U)
#define may23_IN_disableInt            ((uint8_T)8U)
#define may23_IN_setup_a               ((uint8_T)9U)
#define may23_IN_startFloats           ((uint8_T)10U)

/* Named constants for Chart: '<S82>/master_state' */
#define may23_IN_Wait_f                ((uint8_T)1U)
#define may23_IN_setup_em              ((uint8_T)2U)

/* Named constants for Chart: '<S30>/control read write' */
#define may23_IN_File_input            ((uint8_T)1U)
#define may23_IN_RunECat               ((uint8_T)2U)
#define may23_IN_RunPMAC               ((uint8_T)3U)
#define may23_IN_RunSim                ((uint8_T)4U)

/* Forward declaration for local functions */
static void may23_MotorStatus(uint16_T rtu_StatusWord, uint32_T rtu_allOK,
  uint32_T rtu_motorOn, B_Whistlestate_may23_T *localB, DW_Whistlestate_may23_T *
  localDW);
static void may23_UnknownState(uint16_T rtu_StatusWord, uint32_T rtu_eStops,
  real_T rtu_requestEnable, B_Whistlestate_may23_T *localB,
  DW_Whistlestate_may23_T *localDW);
static void may23_SWFault_8(uint16_T rtu_StatusWord, uint32_T rtu_allOK,
  uint32_T rtu_eStops, boolean_T rtu_masterEnabled, real_T rtu_requestEnable,
  real_T rtu_max_errors_to_fault, B_Whistlestate_may23_T *localB,
  DW_Whistlestate_may23_T *localDW);
static void may23_StatusMonitor(uint16_T rtu_StatusWord, uint32_T rtu_allOK,
  uint32_T rtu_motorOn, uint32_T rtu_eStops, boolean_T rtu_masterEnabled, real_T
  rtu_requestEnable, real_T rtu_max_errors_to_fault, B_Whistlestate_may23_T
  *localB, DW_Whistlestate_may23_T *localDW);

/* Forward declaration for local functions */
static void may23_clearValues(void);
static void may23_clearValues_p(void);
static void may23_circshift_b(real_T a[12]);
static void may23_convertL1L2ToShoElb(const real_T L1L2[4], const real_T
  orientation[2], real_T shoElb[4]);
static void may23_reduce(const int32_T a_size[2], int32_T absp[2], boolean_T
  shiftright[2]);
static void may23_circshift_f5(real_T a_data[], const int32_T a_size[2]);
static void may23_updatePosVel(const real_T oldPosData_data[], const int32_T
  oldPosData_size[2], const real_T oldVelData_data[], const int32_T
  oldVelData_size[2], const real_T L1L2Angs[4], real_T stepTime, const real_T
  robotOrientation[2], real_T posData_data[], int32_T posData_size[2], real_T
  velData_data[], int32_T velData_size[2]);
static void may23_buildEncoderData(real_T queueSize, const real_T shoElb[4],
  real_T encData_data[], int32_T encData_size[2]);
static void may23_buildEncoderData_k(real_T queueSize, real_T encData_data[],
  int32_T encData_size[2]);
static void may23_buildKinematics(const real_T posData_data[], const real_T
  velData_data[], const int32_T velData_size[2], real_T stepTime, const uint32_T
  motorStatuses[4], real_T r1[10], real_T r2[10]);
static void may23_insertVal(real_T arr[3], real_T v);

/*
 * Output and update for atomic system:
 *    '<S110>/MATLAB Function'
 *    '<S130>/MATLAB Function'
 *    '<S185>/MATLAB Function'
 *    '<S205>/MATLAB Function'
 */
void may23_MATLABFunction(int32_T rtu_primary, int32_T rtu_secondary, real_T
  rtu_encoder_type, B_MATLABFunction_may23_T *localB)
{
  /* MATLAB Function 'EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/Subsystem/MATLAB Function': '<S112>:1' */
  if (rtu_encoder_type == 1.0) {
    /* '<S112>:1:6' */
    /* '<S112>:1:7' */
    localB->prime_out = rtu_secondary;

    /* '<S112>:1:8' */
    localB->sec_out = rtu_primary;
  } else {
    /* '<S112>:1:10' */
    localB->prime_out = rtu_primary;

    /* '<S112>:1:11' */
    localB->sec_out = rtu_secondary;
  }
}

/*
 * Output and update for atomic system:
 *    '<S102>/parse status register'
 *    '<S122>/parse status register1'
 *    '<S177>/parse status register1'
 *    '<S197>/parse status register1'
 */
void may23_parsestatusregister(uint32_T rtu_statusRegister,
  B_parsestatusregister_may23_T *localB)
{
  int32_T allOK;
  int32_T ampStatus;
  int32_T eStopOut;

  /* MATLAB Function 'EtherCAT Subsystem/Arm 1/A1M1/A1M1 PDOs/parse status register': '<S111>:1' */
  /* '<S111>:1:6' */
  ampStatus = (int32_T)(rtu_statusRegister & 15U);
  if (ampStatus == 0) {
    /* '<S111>:1:7' */
    /* '<S111>:1:8' */
    allOK = 1;
  } else {
    /* '<S111>:1:10' */
    allOK = 0;
  }

  /* '<S111>:1:12' */
  /* '<S111>:1:13' */
  /* '<S111>:1:14' */
  /* '<S111>:1:15' */
  if (rtu_statusRegister == 0U) {
    /* '<S111>:1:17' */
    /* '<S111>:1:18' */
    eStopOut = 0;
  } else {
    /* '<S111>:1:20' */
    /* '<S111>:1:21' */
    eStopOut = (int32_T)((rtu_statusRegister >> 14U & 3U) ^ 3U);
  }

  localB->allOK = (uint32_T)allOK;
  localB->ampStatus = (uint32_T)ampStatus;
  localB->servoEnabled = rtu_statusRegister >> 4U & 1U;
  localB->faultFound = rtu_statusRegister >> 6U & 1U;
  localB->currentLimitEnabled = rtu_statusRegister >> 13U & 1U;
  localB->eStopOut = (uint32_T)eStopOut;
  localB->motorOn = rtu_statusRegister >> 22U & 1U;
}

/*
 * System initialize for atomic system:
 *    '<S104>/Read EMCY'
 *    '<S124>/Read EMCY'
 *    '<S179>/Read EMCY'
 *    '<S199>/Read EMCY'
 */
void may23_ReadEMCY_Init(B_ReadEMCY_may23_T *localB, DW_ReadEMCY_may23_T
  *localDW)
{
  localDW->sfEvent = may23_CALL_EVENT_c;
  localDW->is_active_c99_ethercat = 0U;
  localDW->is_c99_ethercat = may23_IN_NO_ACTIVE_CHILD;
  localDW->currReadIdx = 0.0;
  localDW->valuesToRead = 0.0;
  localB->triggerCountRead = 0;
  localB->emcyReadTrigger[0] = 0;
  localB->emcyReadTrigger[1] = 0;
  localB->countOverwriteTrigger = 0;
  localB->emcyValPump[0] = 0.0;
  localB->emcyValPump[1] = 0.0;
  localB->emcyValPump[2] = 0.0;
}

/*
 * Output and update for atomic system:
 *    '<S104>/Read EMCY'
 *    '<S124>/Read EMCY'
 *    '<S179>/Read EMCY'
 *    '<S199>/Read EMCY'
 */
void may23_ReadEMCY(real_T rtu_triggerReading, real_T rtu_driveID, const real_T
                    rtu_countValues[3], const real_T rtu_emcyValues[3], real_T
                    rtu_overwriteStatus, B_ReadEMCY_may23_T *localB,
                    DW_ReadEMCY_may23_T *localDW)
{
  /* Gateway: EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY */
  localDW->sfEvent = may23_CALL_EVENT_c;

  /* Chart: '<S104>/Read EMCY' */
  /* During: EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY */
  if (localDW->is_active_c99_ethercat == 0U) {
    /* Entry: EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY */
    localDW->is_active_c99_ethercat = 1U;

    /* Entry Internal: EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY */
    /* Transition: '<S113>:140' */
    localDW->is_c99_ethercat = may23_IN_setup;
  } else {
    switch (localDW->is_c99_ethercat) {
     case may23_IN_DoneClearing:
      localB->countOverwriteTrigger = 0;

      /* During 'DoneClearing': '<S113>:197' */
      /* Transition: '<S113>:200' */
      localDW->is_c99_ethercat = may23_IN_setup;
      break;

     case may23_IN_ReadNextEMCY:
      /* During 'ReadNextEMCY': '<S113>:184' */
      if (rtu_emcyValues[1] == 1.0) {
        /* Transition: '<S113>:187' */
        localDW->is_c99_ethercat = may23_IN_disableEMCY;

        /* Entry 'disableEMCY': '<S113>:186' */
        localB->emcyReadTrigger[0] = 0;
      }
      break;

     case may23_IN_ReceivedFloat:
      /* During 'ReceivedFloat': '<S113>:188' */
      if (localDW->currReadIdx <= localDW->valuesToRead) {
        /* Transition: '<S113>:192' */
        localDW->is_c99_ethercat = may23_IN_ReadNextEMCY;

        /* Entry 'ReadNextEMCY': '<S113>:184' */
        localB->emcyReadTrigger[0] = 1;
        localB->emcyReadTrigger[1] = (int32_T)localDW->currReadIdx;
      } else {
        /* Transition: '<S113>:191' */
        localDW->is_c99_ethercat = may23_IN_StartOverwrite;

        /* Entry 'StartOverwrite': '<S113>:193' */
        localB->countOverwriteTrigger = 1;
        localB->emcyValPump[0] = 0.0;
        localB->emcyValPump[1] = 0.0;
        localB->emcyValPump[2] = 0.0;
      }
      break;

     case may23_IN_StartOverwrite:
      localB->countOverwriteTrigger = 1;

      /* During 'StartOverwrite': '<S113>:193' */
      if (rtu_overwriteStatus == 1.0) {
        /* Transition: '<S113>:223' */
        localDW->is_c99_ethercat = may23_IN_DoneClearing;

        /* Entry 'DoneClearing': '<S113>:197' */
        localB->countOverwriteTrigger = 0;
      }
      break;

     case may23_IN_StartReadingCount:
      localB->triggerCountRead = 1;

      /* During 'StartReadingCount': '<S113>:141' */
      if (rtu_countValues[1] == 1.0) {
        /* Transition: '<S113>:157' */
        localDW->is_c99_ethercat = may23_IN_disableCount;

        /* Entry 'disableCount': '<S113>:156' */
        localB->triggerCountRead = 0;
      }
      break;

     case may23_IN_disableCount:
      localB->triggerCountRead = 0;

      /* During 'disableCount': '<S113>:156' */
      if (rtu_countValues[1] >= 2.0) {
        /* Transition: '<S113>:143' */
        if (rtu_countValues[0] == 0.0) {
          /* Transition: '<S113>:219' */
          localDW->is_c99_ethercat = may23_IN_setup;
        } else {
          /* Transition: '<S113>:220' */
          localDW->is_c99_ethercat = may23_IN_startEMCYs;

          /* Entry 'startEMCYs': '<S113>:183' */
          localDW->currReadIdx = 1.0;
          localDW->valuesToRead = rtu_countValues[0];
        }
      }
      break;

     case may23_IN_disableEMCY:
      /* During 'disableEMCY': '<S113>:186' */
      if (rtu_emcyValues[1] >= 2.0) {
        /* Transition: '<S113>:189' */
        localDW->is_c99_ethercat = may23_IN_ReceivedFloat;

        /* Entry 'ReceivedFloat': '<S113>:188' */
        localB->emcyValPump[0] = 1.0;

        /* ID for EMCY messge */
        localB->emcyValPump[1] = rtu_driveID;
        localB->emcyValPump[2] = rtu_emcyValues[0];
        localDW->currReadIdx++;
      }
      break;

     case may23_IN_setup:
      /* During 'setup': '<S113>:139' */
      if (rtu_triggerReading == 1.0) {
        /* Transition: '<S113>:145' */
        localDW->is_c99_ethercat = may23_IN_StartReadingCount;

        /* Entry 'StartReadingCount': '<S113>:141' */
        localB->triggerCountRead = 1;
      }
      break;

     default:
      /* During 'startEMCYs': '<S113>:183' */
      /* Transition: '<S113>:185' */
      localDW->is_c99_ethercat = may23_IN_ReadNextEMCY;

      /* Entry 'ReadNextEMCY': '<S113>:184' */
      localB->emcyReadTrigger[0] = 1;
      localB->emcyReadTrigger[1] = (int32_T)localDW->currReadIdx;
      break;
    }
  }

  /* End of Chart: '<S104>/Read EMCY' */
}

/*
 * Output and update for atomic system:
 *    '<S114>/MATLAB Function'
 *    '<S134>/MATLAB Function'
 *    '<S189>/MATLAB Function'
 *    '<S209>/MATLAB Function'
 */
void may23_MATLABFunction_g(uint32_T rtu_err_code, B_MATLABFunction_may23_b_T
  *localB)
{
  /* MATLAB Function 'EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Count/MATLAB Function': '<S119>:1' */
  /* '<S119>:1:5' */
  localB->out_err_code = rtu_err_code & 511U;
}

/*
 * Output and update for atomic system:
 *    '<S115>/MATLAB Function'
 *    '<S135>/MATLAB Function'
 *    '<S147>/MATLAB Function'
 *    '<S148>/MATLAB Function'
 *    '<S95>/MATLAB Function'
 *    '<S159>/MATLAB Function'
 *    '<S190>/MATLAB Function'
 *    '<S210>/MATLAB Function'
 *    '<S221>/MATLAB Function'
 *    '<S169>/MATLAB Function'
 *    '<S233>/MATLAB Function'
 */
void may23_MATLABFunction_b(uint32_T rtu_err_code, B_MATLABFunction_may23_n_T
  *localB)
{
  /* MATLAB Function 'EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/Read EMCY Value/MATLAB Function': '<S120>:1' */
  /* '<S120>:1:5' */
  localB->out_err_code = (int32_T)(rtu_err_code & 511U);
}

/*
 * System initialize for atomic system:
 *    '<S104>/fault monitor'
 *    '<S124>/fault monitor'
 *    '<S179>/fault monitor'
 *    '<S199>/fault monitor'
 */
void may23_faultmonitor_Init(DW_faultmonitor_may23_T *localDW)
{
  localDW->preOpCounter = 0.0;
}

/*
 * Output and update for atomic system:
 *    '<S104>/fault monitor'
 *    '<S124>/fault monitor'
 *    '<S179>/fault monitor'
 *    '<S199>/fault monitor'
 */
void may23_faultmonitor(uint16_T rtu_StatusWord, B_faultmonitor_may23_T *localB,
  DW_faultmonitor_may23_T *localDW)
{
  int32_T triggerFaultRead;

  /* MATLAB Function 'EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/fault monitor': '<S117>:1' */
  if (rtu_StatusWord == 0) {
    /* '<S117>:1:13' */
    /* '<S117>:1:14' */
    localDW->preOpCounter++;
    if (localDW->preOpCounter >= 20.0) {
      /* '<S117>:1:16' */
      /* '<S117>:1:17' */
      triggerFaultRead = 1;

      /* '<S117>:1:18' */
      localDW->preOpCounter = 0.0;
    } else {
      /* '<S117>:1:20' */
      triggerFaultRead = 0;
    }
  } else {
    /* '<S117>:1:26' */
    /* '<S117>:1:27' */
    if (((rtu_StatusWord & 15) == 8) && (((uint32_T)rtu_StatusWord >> 6 & 1U) ==
         0U)) {
      /* '<S117>:1:29' */
      /* '<S117>:1:30' */
      triggerFaultRead = 1;
    } else {
      /* '<S117>:1:32' */
      triggerFaultRead = 0;
    }
  }

  localB->triggerFaultRead = triggerFaultRead;
}

/*
 * System initialize for atomic system:
 *    '<S104>/pass emcy'
 *    '<S124>/pass emcy'
 *    '<S179>/pass emcy'
 *    '<S199>/pass emcy'
 */
void may23_passemcy_Init(DW_passemcy_may23_T *localDW)
{
  localDW->lastRegister = 0U;
}

/*
 * Output and update for atomic system:
 *    '<S104>/pass emcy'
 *    '<S124>/pass emcy'
 *    '<S179>/pass emcy'
 *    '<S199>/pass emcy'
 */
void may23_passemcy(const real_T rtu_SDOEMCY[3], real_T rtu_drive, uint32_T
                    rtu_registerInfo, uint32_T rtu_registerInfo_c, uint32_T
                    rtu_registerInfo_e, real_T rtu_statusWord,
                    B_passemcy_may23_T *localB, DW_passemcy_may23_T *localDW)
{
  uint32_T registerEMCY;
  real32_T y;
  int32_T i;

  /* SignalConversion generated from: '<S118>/ SFunction ' */
  localB->TmpSignalConversionAtSFunctionInport3[0] = rtu_registerInfo;
  localB->TmpSignalConversionAtSFunctionInport3[1] = rtu_registerInfo_c;
  localB->TmpSignalConversionAtSFunctionInport3[2] = rtu_registerInfo_e;

  /* MATLAB Function 'EtherCAT Subsystem/Arm 1/A1M1/EMCY Message pump/pass emcy': '<S118>:1' */
  /* '<S118>:1:11' */
  registerEMCY = localB->TmpSignalConversionAtSFunctionInport3[2];
  memcpy((void *)&y, (void *)&registerEMCY, (uint32_T)((size_t)1 * sizeof
          (real32_T)));
  if (rtu_SDOEMCY[0] != 0.0) {
    /* '<S118>:1:13' */
    /* '<S118>:1:14' */
    localB->EMCYMsg[0] = rtu_SDOEMCY[0];
    localB->EMCYMsg[1] = rtu_SDOEMCY[1];
    localB->EMCYMsg[2] = rtu_SDOEMCY[2];
    localB->EMCYMsg[3] = rtu_statusWord;
    localB->EMCYMsg[4] = y;
  } else {
    /* '<S118>:1:28' */
    /* '<S118>:1:29' */
    registerEMCY = localB->TmpSignalConversionAtSFunctionInport3[0];

    /* '<S118>:1:30' */
    if (localB->TmpSignalConversionAtSFunctionInport3[1] != 0U) {
      /* '<S118>:1:33' */
      registerEMCY = 32U;
    }

    if ((localDW->lastRegister != registerEMCY) && (registerEMCY == 32U)) {
      /* '<S118>:1:38' */
      /* '<S118>:1:58' */
      /* '<S118>:1:59' */
      /* '<S118>:1:72' */
      localB->EMCYMsg[0] = 3.0;
      localB->EMCYMsg[1] = rtu_drive;
      localB->EMCYMsg[2] = 10.0;
      localB->EMCYMsg[3] = rtu_statusWord;
      localB->EMCYMsg[4] = y;
    } else {
      /* '<S118>:1:67' */
      /* '<S118>:1:68' */
      for (i = 0; i < 5; i++) {
        localB->EMCYMsg[i] = 0.0;
      }
    }
  }
}

/* System initialize for atomic system: '<S87>/EMCY Message pump' */
void may23_EMCYMessagepump_Init(void)
{
  /* InitializeConditions for Memory: '<S114>/Memory' */
  may23_DW.Memory_PreviousInput_di[0] = may23_P.Memory_InitialCondition_ny;

  /* InitializeConditions for Memory: '<S115>/Memory' */
  may23_DW.Memory_PreviousInput_kg[0] = may23_P.Memory_InitialCondition_g;

  /* InitializeConditions for Memory: '<S114>/Memory' */
  may23_DW.Memory_PreviousInput_di[1] = may23_P.Memory_InitialCondition_ny;

  /* InitializeConditions for Memory: '<S115>/Memory' */
  may23_DW.Memory_PreviousInput_kg[1] = may23_P.Memory_InitialCondition_g;

  /* InitializeConditions for Memory: '<S114>/Memory' */
  may23_DW.Memory_PreviousInput_di[2] = may23_P.Memory_InitialCondition_ny;

  /* InitializeConditions for Memory: '<S115>/Memory' */
  may23_DW.Memory_PreviousInput_kg[2] = may23_P.Memory_InitialCondition_g;

  /* InitializeConditions for Memory: '<S116>/Memory' */
  may23_DW.Memory_PreviousInput_h4 = may23_P.Memory_InitialCondition;

  /* SystemInitialize for Chart: '<S104>/Read EMCY' */
  may23_ReadEMCY_Init(&may23_B.sf_ReadEMCY, &may23_DW.sf_ReadEMCY);

  /* SystemInitialize for MATLAB Function: '<S104>/fault monitor' */
  may23_faultmonitor_Init(&may23_DW.sf_faultmonitor);

  /* SystemInitialize for MATLAB Function: '<S104>/pass emcy' */
  may23_passemcy_Init(&may23_DW.sf_passemcy);
}

/* Start for atomic system: '<S87>/EMCY Message pump' */
void may23_EMCYMessagepump_Start(void)
{
  /* Start for Constant: '<S104>/driveID' */
  may23_B.driveID_p = may23_P.driveID_Value;
}

/* Outputs for atomic system: '<S87>/EMCY Message pump' */
void may23_EMCYMessagepump(void)
{
  /* DataTypeConversion: '<S104>/Data Type Conversion' */
  may23_B.DataTypeConversion_lz = may23_B.Switch_mm;

  /* MATLAB Function: '<S104>/fault monitor' */
  may23_faultmonitor(may23_B.Switch_mm, &may23_B.sf_faultmonitor,
                     &may23_DW.sf_faultmonitor);

  /* Constant: '<S104>/driveID' */
  may23_B.driveID_p = may23_P.driveID_Value;

  /* Memory: '<S114>/Memory' */
  may23_B.Memory_f[0] = may23_DW.Memory_PreviousInput_di[0];
  may23_B.Memory_f[1] = may23_DW.Memory_PreviousInput_di[1];
  may23_B.Memory_f[2] = may23_DW.Memory_PreviousInput_di[2];

  /* DataTypeConversion: '<S114>/Data Type Conversion2' */
  may23_B.DataTypeConversion2_i[0] = may23_B.Memory_f[0];
  may23_B.DataTypeConversion2_i[1] = may23_B.Memory_f[1];
  may23_B.DataTypeConversion2_i[2] = may23_B.Memory_f[2];

  /* Memory: '<S115>/Memory' */
  may23_B.Memory_gu[0] = may23_DW.Memory_PreviousInput_kg[0];
  may23_B.Memory_gu[1] = may23_DW.Memory_PreviousInput_kg[1];
  may23_B.Memory_gu[2] = may23_DW.Memory_PreviousInput_kg[2];

  /* DataTypeConversion: '<S115>/Data Type Conversion' */
  may23_B.DataTypeConversion_lg[0] = may23_B.Memory_gu[0];
  may23_B.DataTypeConversion_lg[1] = may23_B.Memory_gu[1];
  may23_B.DataTypeConversion_lg[2] = may23_B.Memory_gu[2];

  /* Memory: '<S116>/Memory' */
  may23_B.Memory_es = may23_DW.Memory_PreviousInput_h4;

  /* Chart: '<S104>/Read EMCY' */
  may23_ReadEMCY(may23_B.sf_faultmonitor.triggerFaultRead, may23_B.driveID_p,
                 may23_B.DataTypeConversion2_i, may23_B.DataTypeConversion_lg,
                 may23_B.Memory_es, &may23_B.sf_ReadEMCY, &may23_DW.sf_ReadEMCY);

  /* DataTypeConversion: '<S114>/Data Type Conversion' */
  may23_B.DataTypeConversion_ol = may23_B.sf_ReadEMCY.triggerCountRead;

  /* S-Function (BKINethercatasyncsdoupload): '<S114>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S114>/Constant'
   *  Constant: '<S114>/Constant1'
   */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_d[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload_o3_cf;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload_o1_d;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload_o2_lu;
        enInputPtr = &may23_B.DataTypeConversion_ol;
        indexInputPtr = &may23_P.Constant_Value_l2;
        subIndexInputPtr = &may23_P.Constant1_Value_n;
        if (may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_d[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1001,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            658983257,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_d[7] = 1;
        ;
      }
    }
  }

  /* DataTypeConversion: '<S114>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_p = (uint32_T)
    may23_B.BKINEtherCATAsyncSDOUpload_o2_lu;

  /* MATLAB Function: '<S114>/MATLAB Function' */
  may23_MATLABFunction_g(may23_B.BKINEtherCATAsyncSDOUpload_o3_cf,
    &may23_B.sf_MATLABFunction_gi);

  /* RateTransition: '<S114>/Rate Transition' */
  may23_B.RateTransition_kr[0] = may23_B.BKINEtherCATAsyncSDOUpload_o1_d;
  may23_B.RateTransition_kr[1] = may23_B.DataTypeConversion1_p;
  may23_B.RateTransition_kr[2] = may23_B.sf_MATLABFunction_gi.out_err_code;

  /* S-Function (BKINethercatasyncsdoupload): '<S115>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S115>/Constant'
   */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_m[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload_o3_p;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload_o1_ko;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload_o2_h;
        enInputPtr = &may23_B.sf_ReadEMCY.emcyReadTrigger[0];
        indexInputPtr = &may23_P.Constant_Value_k;
        subIndexInputPtr = &may23_B.sf_ReadEMCY.emcyReadTrigger[1];
        if (may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_m[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1001,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            658983265,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_m[7] = 1;
        ;
      }
    }
  }

  /* MATLAB Function: '<S115>/MATLAB Function' */
  may23_MATLABFunction_b(may23_B.BKINEtherCATAsyncSDOUpload_o3_p,
    &may23_B.sf_MATLABFunction_b1);

  /* RateTransition: '<S115>/Rate Transition' */
  may23_B.RateTransition_lt[0] = may23_B.BKINEtherCATAsyncSDOUpload_o1_ko;
  may23_B.RateTransition_lt[1] = may23_B.BKINEtherCATAsyncSDOUpload_o2_h;
  may23_B.RateTransition_lt[2] = may23_B.sf_MATLABFunction_b1.out_err_code;

  /* DataTypeConversion: '<S116>/Data Type Conversion' incorporates:
   *  Constant: '<S116>/Constant'
   */
  may23_B.DataTypeConversion_ll = (int32_T)may23_P.Constant_Value_di;

  /* S-Function (BKINethercatasyncsdodownload): '<S116>/BKIN EtherCAT Async SDO Download' incorporates:
   *  Constant: '<S116>/Constant'
   *  Constant: '<S116>/Constant1'
   */
  {
    int8_T *sigInputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_i[0];
    perror = &may23_B.BKINEtherCATAsyncSDODownload_o2_p;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDODownload_o1_p;
        sigInputPtr = (int8_T*)&may23_P.Constant_Value_di;
        enInputPtr = &may23_B.sf_ReadEMCY.countOverwriteTrigger;
        indexInputPtr = &may23_P.Constant1_Value_c;
        subIndexInputPtr = &may23_B.DataTypeConversion_ll;
        if (may23_DW.BKINEtherCATAsyncSDODownload_IWORK_i[7] != 0) {
          res = ecatAsyncSDODownload(deviceIndex,
            1001,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigInputPtr,
            1*4,
            500,
            658983277,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        } else {
          *sigStatusPtr = 0;
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_i[7] = 1;
        ;
      }
    }
  }

  /* DataTypeConversion: '<S116>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_m3 = may23_B.BKINEtherCATAsyncSDODownload_o1_p;

  /* MATLAB Function: '<S104>/pass emcy' */
  may23_passemcy(may23_B.sf_ReadEMCY.emcyValPump, may23_B.driveID_p,
                 may23_B.sf_parsestatusregister.ampStatus,
                 may23_B.sf_parsestatusregister.currentLimitEnabled,
                 may23_B.Switch_d, may23_B.DataTypeConversion_lz,
                 &may23_B.sf_passemcy, &may23_DW.sf_passemcy);
}

/* Update for atomic system: '<S87>/EMCY Message pump' */
void may23_EMCYMessagepump_Update(void)
{
  /* Update for Memory: '<S114>/Memory' */
  may23_DW.Memory_PreviousInput_di[0] = may23_B.RateTransition_kr[0];
  may23_DW.Memory_PreviousInput_di[1] = may23_B.RateTransition_kr[1];
  may23_DW.Memory_PreviousInput_di[2] = may23_B.RateTransition_kr[2];

  /* Update for Memory: '<S115>/Memory' */
  may23_DW.Memory_PreviousInput_kg[0] = may23_B.RateTransition_lt[0];
  may23_DW.Memory_PreviousInput_kg[1] = may23_B.RateTransition_lt[1];
  may23_DW.Memory_PreviousInput_kg[2] = may23_B.RateTransition_lt[2];

  /* Update for Memory: '<S116>/Memory' */
  may23_DW.Memory_PreviousInput_h4 = may23_B.DataTypeConversion1_m3;
}

/* Termination for atomic system: '<S87>/EMCY Message pump' */
void may23_EMCYMessagepump_Term(void)
{
  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S114>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S114>/Constant'
   *  Constant: '<S114>/Constant1'
   */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_d[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658983257, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1001);
      }
    }
  }

  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S115>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S115>/Constant'
   */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_m[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658983265, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1001);
      }
    }
  }

  /* Terminate for S-Function (BKINethercatasyncsdodownload): '<S116>/BKIN EtherCAT Async SDO Download' incorporates:
   *  Constant: '<S116>/Constant'
   *  Constant: '<S116>/Constant1'
   */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_i[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDODownload(658983277, deviceIndex);
        printf("SDO Download. Unregister device %d, slave addr: %d\n",
               deviceIndex, 1001);
      }
    }
  }
}

/* Function for Chart: '<S87>/Whistle state' */
static void may23_MotorStatus(uint16_T rtu_StatusWord, uint32_T rtu_allOK,
  uint32_T rtu_motorOn, B_Whistlestate_may23_T *localB, DW_Whistlestate_may23_T *
  localDW)
{
  boolean_T sf_internal_predicateOutput;

  /* During 'MotorStatus': '<S106>:34' */
  /* During 'MotorStatusUpdate': '<S106>:30' */
  /* Transition: '<S106>:48' */
  sf_internal_predicateOutput = ((rtu_allOK != 0U) && (rtu_StatusWord !=
    (int32_T)may23_SWFault));
  if (sf_internal_predicateOutput) {
    /* Transition: '<S106>:38' */
    if (rtu_motorOn != 0U) {
      /* Transition: '<S106>:40' */
      /* Transition: '<S106>:45' */
      localB->motorStatus = 0U;

      /* Transition: '<S106>:46' */
    } else {
      /* Transition: '<S106>:42' */
      localB->motorStatus = 1U;
    }

    /* Transition: '<S106>:43' */
  } else {
    /* Transition: '<S106>:51' */
    localB->motorStatus = 2U;
  }

  /* Transition: '<S106>:50' */
  localDW->is_MotorStatus = may23_IN_MotorStatusUpdate;

  /* Entry 'MotorStatusUpdate': '<S106>:30' */
}

/* Function for Chart: '<S87>/Whistle state' */
static void may23_UnknownState(uint16_T rtu_StatusWord, uint32_T rtu_eStops,
  real_T rtu_requestEnable, B_Whistlestate_may23_T *localB,
  DW_Whistlestate_may23_T *localDW)
{
  uint32_T q0;
  uint32_T qY;
  localB->ControlWord = may23_CWDisable;

  /* During 'UnknownState': '<S106>:291' */
  /* Transition: '<S106>:297' */
  /* Transition: '<S106>:298' */
  /* Transition: '<S106>:178' */
  /* Transition: '<S106>:179' */
  /* Transition: '<S106>:180' */
  /* Transition: '<S106>:186' */
  /* Transition: '<S106>:187' */
  /* Transition: '<S106>:188' */
  if (rtu_StatusWord == (int32_T)may23_SWSwitchOnDisabled) {
    /* Transition: '<S106>:165' */
    localDW->is_ControlWordUpdate = may23_IN_SWSwitchOnDisabled_64;

    /* Entry Internal 'SWSwitchOnDisabled_64': '<S106>:159' */
    /* Transition: '<S106>:240' */
    if (rtu_requestEnable != 0.0) {
      /* Transition: '<S106>:192' */
      localDW->is_SWSwitchOnDisabled_64 = may23_IN_ReadyToGo;

      /* Entry 'ReadyToGo': '<S106>:189' */
      localB->ControlWord = may23_CWGetReady;
    } else {
      /* Transition: '<S106>:241' */
      /* Transition: '<S106>:196' */
      localDW->is_SWSwitchOnDisabled_64 = may23_IN_Waiting;

      /* Entry 'Waiting': '<S106>:195' */
      localB->ControlWord = may23_CWDisable;
    }
  } else {
    /* Transition: '<S106>:168' */
    if (rtu_StatusWord == (int32_T)may23_SWReadyToSwitchOn) {
      /* Transition: '<S106>:169' */
      localDW->is_ControlWordUpdate = may23_IN_SWReadyToSwitchOn_33;

      /* Entry Internal 'SWReadyToSwitchOn_33': '<S106>:160' */
      /* Transition: '<S106>:210' */
      localDW->is_SWReadyToSwitchOn_33 = may23_IN_Waiting1;

      /* Entry 'Waiting1': '<S106>:205' */
      localB->ControlWord = may23_CWEnable;
    } else {
      /* Transition: '<S106>:170' */
      if (rtu_StatusWord == (int32_T)may23_SWOperationEnabled) {
        /* Transition: '<S106>:171' */
        localDW->is_ControlWordUpdate = may23_IN_SWOperationEnabled_39;

        /* Entry 'SWOperationEnabled_39': '<S106>:161' */
        /* Entry Internal 'SWOperationEnabled_39': '<S106>:161' */
        /* Transition: '<S106>:216' */
        if (rtu_requestEnable != 0.0) {
          /* Transition: '<S106>:218' */
          localDW->is_SWOperationEnabled_39 = may23_IN_Working;

          /* Entry 'Working': '<S106>:213' */
          localB->ControlWord = may23_CWEnable;
          localDW->faultResetAttempts = 0U;
        } else {
          /* Transition: '<S106>:212' */
          /* Transition: '<S106>:220' */
          localDW->is_SWOperationEnabled_39 = may23_IN_Waiting2;

          /* Entry 'Waiting2': '<S106>:211' */
          localB->ControlWord = may23_CWDisable;
        }
      } else {
        /* Transition: '<S106>:172' */
        if (rtu_StatusWord == (int32_T)may23_SWFault) {
          /* Transition: '<S106>:293' */
          localDW->is_ControlWordUpdate = may23_IN_SWFault_8;

          /* Entry Internal 'SWFault_8': '<S106>:162' */
          /* Transition: '<S106>:279' */
          if (rtu_eStops != 0U) {
            /* Transition: '<S106>:336' */
            localDW->is_SWFault_8 = may23_IN_eStopped;

            /* Entry 'eStopped': '<S106>:335' */
            localB->ControlWord = may23_CWDisable;
            localDW->resetCounter = 0U;
          } else {
            /* Transition: '<S106>:344' */
            /* Transition: '<S106>:346' */
            localDW->is_SWFault_8 = may23_IN_WaitReset;

            /* Entry 'WaitReset': '<S106>:347' */
            localB->ControlWord = may23_CWDisable;
            q0 = localDW->faultResetAttempts;
            qY = q0 + 1U;
            if (qY < q0) {
              qY = MAX_uint32_T;
            }

            localDW->faultResetAttempts = qY;
            localDW->faultClock = 0U;
          }
        } else {
          /* Transition: '<S106>:294' */
          /* Transition: '<S106>:295' */
          localDW->is_ControlWordUpdate = may23_IN_UnknownState;

          /* Entry 'UnknownState': '<S106>:291' */
          localB->ControlWord = may23_CWDisable;
        }
      }
    }
  }
}

/* Function for Chart: '<S87>/Whistle state' */
static void may23_SWFault_8(uint16_T rtu_StatusWord, uint32_T rtu_allOK,
  uint32_T rtu_eStops, boolean_T rtu_masterEnabled, real_T rtu_requestEnable,
  real_T rtu_max_errors_to_fault, B_Whistlestate_may23_T *localB,
  DW_Whistlestate_may23_T *localDW)
{
  boolean_T sf_internal_predicateOutput;
  uint32_T q0;
  uint32_T qY;

  /* During 'SWFault_8': '<S106>:162' */
  if (rtu_StatusWord != (int32_T)may23_SWFault) {
    /* Transition: '<S106>:174' */
    /* Transition: '<S106>:178' */
    /* Transition: '<S106>:179' */
    /* Transition: '<S106>:180' */
    /* Transition: '<S106>:186' */
    /* Transition: '<S106>:187' */
    /* Transition: '<S106>:188' */
    if (rtu_StatusWord == (int32_T)may23_SWSwitchOnDisabled) {
      /* Transition: '<S106>:165' */
      /* Exit Internal 'SWFault_8': '<S106>:162' */
      localDW->is_SWFault_8 = may23_IN_NO_ACTIVE_CHILD_h;
      localDW->is_ControlWordUpdate = may23_IN_SWSwitchOnDisabled_64;

      /* Entry Internal 'SWSwitchOnDisabled_64': '<S106>:159' */
      /* Transition: '<S106>:240' */
      if (rtu_requestEnable != 0.0) {
        /* Transition: '<S106>:192' */
        localDW->is_SWSwitchOnDisabled_64 = may23_IN_ReadyToGo;

        /* Entry 'ReadyToGo': '<S106>:189' */
        localB->ControlWord = may23_CWGetReady;
      } else {
        /* Transition: '<S106>:241' */
        /* Transition: '<S106>:196' */
        localDW->is_SWSwitchOnDisabled_64 = may23_IN_Waiting;

        /* Entry 'Waiting': '<S106>:195' */
        localB->ControlWord = may23_CWDisable;
      }
    } else {
      /* Transition: '<S106>:168' */
      if (rtu_StatusWord == (int32_T)may23_SWReadyToSwitchOn) {
        /* Transition: '<S106>:169' */
        /* Exit Internal 'SWFault_8': '<S106>:162' */
        localDW->is_SWFault_8 = may23_IN_NO_ACTIVE_CHILD_h;
        localDW->is_ControlWordUpdate = may23_IN_SWReadyToSwitchOn_33;

        /* Entry Internal 'SWReadyToSwitchOn_33': '<S106>:160' */
        /* Transition: '<S106>:210' */
        localDW->is_SWReadyToSwitchOn_33 = may23_IN_Waiting1;

        /* Entry 'Waiting1': '<S106>:205' */
        localB->ControlWord = may23_CWEnable;
      } else {
        /* Transition: '<S106>:170' */
        if (rtu_StatusWord == (int32_T)may23_SWOperationEnabled) {
          /* Transition: '<S106>:171' */
          /* Exit Internal 'SWFault_8': '<S106>:162' */
          localDW->is_SWFault_8 = may23_IN_NO_ACTIVE_CHILD_h;
          localDW->is_ControlWordUpdate = may23_IN_SWOperationEnabled_39;

          /* Entry 'SWOperationEnabled_39': '<S106>:161' */
          /* Entry Internal 'SWOperationEnabled_39': '<S106>:161' */
          /* Transition: '<S106>:216' */
          if (rtu_requestEnable != 0.0) {
            /* Transition: '<S106>:218' */
            localDW->is_SWOperationEnabled_39 = may23_IN_Working;

            /* Entry 'Working': '<S106>:213' */
            localB->ControlWord = may23_CWEnable;
            localDW->faultResetAttempts = 0U;
          } else {
            /* Transition: '<S106>:212' */
            /* Transition: '<S106>:220' */
            localDW->is_SWOperationEnabled_39 = may23_IN_Waiting2;

            /* Entry 'Waiting2': '<S106>:211' */
            localB->ControlWord = may23_CWDisable;
          }
        } else {
          /* Transition: '<S106>:172' */
          if (rtu_StatusWord == (int32_T)may23_SWFault) {
            /* Transition: '<S106>:293' */
            /* Exit Internal 'SWFault_8': '<S106>:162' */
            localDW->is_ControlWordUpdate = may23_IN_SWFault_8;

            /* Entry Internal 'SWFault_8': '<S106>:162' */
            /* Transition: '<S106>:279' */
            if (rtu_eStops != 0U) {
              /* Transition: '<S106>:336' */
              localDW->is_SWFault_8 = may23_IN_eStopped;

              /* Entry 'eStopped': '<S106>:335' */
              localB->ControlWord = may23_CWDisable;
              localDW->resetCounter = 0U;
            } else {
              /* Transition: '<S106>:344' */
              /* Transition: '<S106>:346' */
              localDW->is_SWFault_8 = may23_IN_WaitReset;

              /* Entry 'WaitReset': '<S106>:347' */
              localB->ControlWord = may23_CWDisable;
              q0 = localDW->faultResetAttempts;
              qY = q0 + 1U;
              if (qY < q0) {
                qY = MAX_uint32_T;
              }

              localDW->faultResetAttempts = qY;
              localDW->faultClock = 0U;
            }
          } else {
            /* Transition: '<S106>:294' */
            /* Transition: '<S106>:295' */
            /* Exit Internal 'SWFault_8': '<S106>:162' */
            localDW->is_SWFault_8 = may23_IN_NO_ACTIVE_CHILD_h;
            localDW->is_ControlWordUpdate = may23_IN_UnknownState;

            /* Entry 'UnknownState': '<S106>:291' */
            localB->ControlWord = may23_CWDisable;
          }
        }
      }
    }
  } else {
    switch (localDW->is_SWFault_8) {
     case may23_IN_Faulted:
      localB->ControlWord = may23_CWDisable;

      /* During 'Faulted': '<S106>:221' */
      break;

     case may23_IN_ResetEstop:
      localB->ControlWord = may23_CWResetFault;

      /* During 'ResetEstop': '<S106>:231' */
      if (localDW->resetCounter > rtu_max_errors_to_fault) {
        /* Transition: '<S106>:338' */
        /* Transition: '<S106>:352' */
        localDW->is_SWFault_8 = may23_IN_Faulted;

        /* Entry 'Faulted': '<S106>:221' */
        localB->ControlWord = may23_CWDisable;
        localB->isPermFaulted = 1.0;
      } else {
        q0 = localDW->resetCounter;
        qY = q0 + 1U;
        if (qY < q0) {
          qY = MAX_uint32_T;
        }

        localDW->resetCounter = qY;
      }
      break;

     case may23_IN_Wait:
      /* During 'Wait': '<S106>:360' */
      if (localDW->temporalCounter_i1 >= 4U) {
        /* Transition: '<S106>:361' */
        /* Transition: '<S106>:363' */
        sf_internal_predicateOutput = ((rtu_allOK != 0U) && rtu_masterEnabled);
        if (sf_internal_predicateOutput) {
          /* Transition: '<S106>:337' */
          localDW->is_SWFault_8 = may23_IN_ResetEstop;

          /* Entry 'ResetEstop': '<S106>:231' */
          localB->ControlWord = may23_CWResetFault;
        } else {
          /* Transition: '<S106>:364' */
          localDW->is_SWFault_8 = may23_IN_WaitReset;

          /* Entry 'WaitReset': '<S106>:347' */
          localB->ControlWord = may23_CWDisable;
          q0 = localDW->faultResetAttempts;
          qY = q0 + 1U;
          if (qY < q0) {
            qY = MAX_uint32_T;
          }

          localDW->faultResetAttempts = qY;
          localDW->faultClock = 0U;
        }
      }
      break;

     case may23_IN_WaitReset:
      localB->ControlWord = may23_CWDisable;

      /* During 'WaitReset': '<S106>:347' */
      /* Transition: '<S106>:348' */
      sf_internal_predicateOutput = ((rtu_allOK != 0U) && rtu_masterEnabled);
      if (sf_internal_predicateOutput) {
        /* Transition: '<S106>:337' */
        localDW->is_SWFault_8 = may23_IN_ResetEstop;

        /* Entry 'ResetEstop': '<S106>:231' */
        localB->ControlWord = may23_CWResetFault;
      } else {
        sf_internal_predicateOutput = ((localDW->faultClock > 12000U) ||
          (localDW->faultResetAttempts > 3U));
        if (sf_internal_predicateOutput) {
          /* Transition: '<S106>:357' */
          /* Transition: '<S106>:352' */
          localDW->is_SWFault_8 = may23_IN_Faulted;

          /* Entry 'Faulted': '<S106>:221' */
          localB->ControlWord = may23_CWDisable;
          localB->isPermFaulted = 1.0;
        } else if (rtu_eStops != 0U) {
          /* Transition: '<S106>:358' */
          localDW->is_SWFault_8 = may23_IN_eStopped;

          /* Entry 'eStopped': '<S106>:335' */
          localB->ControlWord = may23_CWDisable;
          localDW->resetCounter = 0U;
        } else {
          q0 = localDW->faultClock;
          qY = q0 + 1U;
          if (qY < q0) {
            qY = MAX_uint32_T;
          }

          localDW->faultClock = qY;
        }
      }
      break;

     default:
      localB->ControlWord = may23_CWDisable;

      /* During 'eStopped': '<S106>:335' */
      if (rtu_eStops == 0U) {
        /* Transition: '<S106>:356' */
        localDW->is_SWFault_8 = may23_IN_Wait;
        localDW->temporalCounter_i1 = 0U;

        /* Entry 'Wait': '<S106>:360' */
      }
      break;
    }
  }
}

/* Function for Chart: '<S87>/Whistle state' */
static void may23_StatusMonitor(uint16_T rtu_StatusWord, uint32_T rtu_allOK,
  uint32_T rtu_motorOn, uint32_T rtu_eStops, boolean_T rtu_masterEnabled, real_T
  rtu_requestEnable, real_T rtu_max_errors_to_fault, B_Whistlestate_may23_T
  *localB, DW_Whistlestate_may23_T *localDW)
{
  uint32_T q0;
  uint32_T qY;

  /* During 'StatusMonitor': '<S106>:29' */
  may23_MotorStatus(rtu_StatusWord, rtu_allOK, rtu_motorOn, localB, localDW);

  /* During 'ControlWordUpdate': '<S106>:52' */
  switch (localDW->is_ControlWordUpdate) {
   case may23_IN_SWFault_8:
    may23_SWFault_8(rtu_StatusWord, rtu_allOK, rtu_eStops, rtu_masterEnabled,
                    rtu_requestEnable, rtu_max_errors_to_fault, localB, localDW);
    break;

   case may23_IN_SWOperationEnabled_39:
    /* During 'SWOperationEnabled_39': '<S106>:161' */
    if (rtu_StatusWord != (int32_T)may23_SWOperationEnabled) {
      /* Transition: '<S106>:181' */
      /* Transition: '<S106>:179' */
      /* Transition: '<S106>:180' */
      /* Transition: '<S106>:186' */
      /* Transition: '<S106>:187' */
      /* Transition: '<S106>:188' */
      if (rtu_StatusWord == (int32_T)may23_SWSwitchOnDisabled) {
        /* Transition: '<S106>:165' */
        /* Exit Internal 'SWOperationEnabled_39': '<S106>:161' */
        localDW->is_SWOperationEnabled_39 = may23_IN_NO_ACTIVE_CHILD_h;
        localDW->is_ControlWordUpdate = may23_IN_SWSwitchOnDisabled_64;

        /* Entry Internal 'SWSwitchOnDisabled_64': '<S106>:159' */
        /* Transition: '<S106>:240' */
        if (rtu_requestEnable != 0.0) {
          /* Transition: '<S106>:192' */
          localDW->is_SWSwitchOnDisabled_64 = may23_IN_ReadyToGo;

          /* Entry 'ReadyToGo': '<S106>:189' */
          localB->ControlWord = may23_CWGetReady;
        } else {
          /* Transition: '<S106>:241' */
          /* Transition: '<S106>:196' */
          localDW->is_SWSwitchOnDisabled_64 = may23_IN_Waiting;

          /* Entry 'Waiting': '<S106>:195' */
          localB->ControlWord = may23_CWDisable;
        }
      } else {
        /* Transition: '<S106>:168' */
        if (rtu_StatusWord == (int32_T)may23_SWReadyToSwitchOn) {
          /* Transition: '<S106>:169' */
          /* Exit Internal 'SWOperationEnabled_39': '<S106>:161' */
          localDW->is_SWOperationEnabled_39 = may23_IN_NO_ACTIVE_CHILD_h;
          localDW->is_ControlWordUpdate = may23_IN_SWReadyToSwitchOn_33;

          /* Entry Internal 'SWReadyToSwitchOn_33': '<S106>:160' */
          /* Transition: '<S106>:210' */
          localDW->is_SWReadyToSwitchOn_33 = may23_IN_Waiting1;

          /* Entry 'Waiting1': '<S106>:205' */
          localB->ControlWord = may23_CWEnable;
        } else {
          /* Transition: '<S106>:170' */
          if (rtu_StatusWord == (int32_T)may23_SWOperationEnabled) {
            /* Transition: '<S106>:171' */
            /* Exit Internal 'SWOperationEnabled_39': '<S106>:161' */
            localDW->is_ControlWordUpdate = may23_IN_SWOperationEnabled_39;

            /* Entry 'SWOperationEnabled_39': '<S106>:161' */
            /* Entry Internal 'SWOperationEnabled_39': '<S106>:161' */
            /* Transition: '<S106>:216' */
            if (rtu_requestEnable != 0.0) {
              /* Transition: '<S106>:218' */
              localDW->is_SWOperationEnabled_39 = may23_IN_Working;

              /* Entry 'Working': '<S106>:213' */
              localB->ControlWord = may23_CWEnable;
              localDW->faultResetAttempts = 0U;
            } else {
              /* Transition: '<S106>:212' */
              /* Transition: '<S106>:220' */
              localDW->is_SWOperationEnabled_39 = may23_IN_Waiting2;

              /* Entry 'Waiting2': '<S106>:211' */
              localB->ControlWord = may23_CWDisable;
            }
          } else {
            /* Transition: '<S106>:172' */
            if (rtu_StatusWord == (int32_T)may23_SWFault) {
              /* Transition: '<S106>:293' */
              /* Exit Internal 'SWOperationEnabled_39': '<S106>:161' */
              localDW->is_SWOperationEnabled_39 = may23_IN_NO_ACTIVE_CHILD_h;
              localDW->is_ControlWordUpdate = may23_IN_SWFault_8;

              /* Entry Internal 'SWFault_8': '<S106>:162' */
              /* Transition: '<S106>:279' */
              if (rtu_eStops != 0U) {
                /* Transition: '<S106>:336' */
                localDW->is_SWFault_8 = may23_IN_eStopped;

                /* Entry 'eStopped': '<S106>:335' */
                localB->ControlWord = may23_CWDisable;
                localDW->resetCounter = 0U;
              } else {
                /* Transition: '<S106>:344' */
                /* Transition: '<S106>:346' */
                localDW->is_SWFault_8 = may23_IN_WaitReset;

                /* Entry 'WaitReset': '<S106>:347' */
                localB->ControlWord = may23_CWDisable;
                q0 = localDW->faultResetAttempts;
                qY = q0 + 1U;
                if (qY < q0) {
                  qY = MAX_uint32_T;
                }

                localDW->faultResetAttempts = qY;
                localDW->faultClock = 0U;
              }
            } else {
              /* Transition: '<S106>:294' */
              /* Transition: '<S106>:295' */
              /* Exit Internal 'SWOperationEnabled_39': '<S106>:161' */
              localDW->is_SWOperationEnabled_39 = may23_IN_NO_ACTIVE_CHILD_h;
              localDW->is_ControlWordUpdate = may23_IN_UnknownState;

              /* Entry 'UnknownState': '<S106>:291' */
              localB->ControlWord = may23_CWDisable;
            }
          }
        }
      }
    } else if (localDW->is_SWOperationEnabled_39 == may23_IN_Waiting2) {
      localB->ControlWord = may23_CWDisable;

      /* During 'Waiting2': '<S106>:211' */
      /* Transition: '<S106>:227' */
      /* Entry Internal 'SWOperationEnabled_39': '<S106>:161' */
      /* Transition: '<S106>:216' */
      if (rtu_requestEnable != 0.0) {
        /* Transition: '<S106>:218' */
        localDW->is_SWOperationEnabled_39 = may23_IN_Working;

        /* Entry 'Working': '<S106>:213' */
        localB->ControlWord = may23_CWEnable;
        localDW->faultResetAttempts = 0U;
      } else {
        /* Transition: '<S106>:212' */
        /* Transition: '<S106>:220' */
        localDW->is_SWOperationEnabled_39 = may23_IN_Waiting2;

        /* Entry 'Waiting2': '<S106>:211' */
        localB->ControlWord = may23_CWDisable;
      }
    } else {
      localB->ControlWord = may23_CWEnable;

      /* During 'Working': '<S106>:213' */
      /* Transition: '<S106>:226' */
      /* Entry Internal 'SWOperationEnabled_39': '<S106>:161' */
      /* Transition: '<S106>:216' */
      if (rtu_requestEnable != 0.0) {
        /* Transition: '<S106>:218' */
        localDW->is_SWOperationEnabled_39 = may23_IN_Working;

        /* Entry 'Working': '<S106>:213' */
        localB->ControlWord = may23_CWEnable;
        localDW->faultResetAttempts = 0U;
      } else {
        /* Transition: '<S106>:212' */
        /* Transition: '<S106>:220' */
        localDW->is_SWOperationEnabled_39 = may23_IN_Waiting2;

        /* Entry 'Waiting2': '<S106>:211' */
        localB->ControlWord = may23_CWDisable;
      }
    }
    break;

   case may23_IN_SWReadyToSwitchOn_33:
    /* During 'SWReadyToSwitchOn_33': '<S106>:160' */
    if (rtu_StatusWord != (int32_T)may23_SWReadyToSwitchOn) {
      /* Transition: '<S106>:182' */
      /* Transition: '<S106>:180' */
      /* Transition: '<S106>:186' */
      /* Transition: '<S106>:187' */
      /* Transition: '<S106>:188' */
      if (rtu_StatusWord == (int32_T)may23_SWSwitchOnDisabled) {
        /* Transition: '<S106>:165' */
        /* Exit Internal 'SWReadyToSwitchOn_33': '<S106>:160' */
        localDW->is_SWReadyToSwitchOn_33 = may23_IN_NO_ACTIVE_CHILD_h;
        localDW->is_ControlWordUpdate = may23_IN_SWSwitchOnDisabled_64;

        /* Entry Internal 'SWSwitchOnDisabled_64': '<S106>:159' */
        /* Transition: '<S106>:240' */
        if (rtu_requestEnable != 0.0) {
          /* Transition: '<S106>:192' */
          localDW->is_SWSwitchOnDisabled_64 = may23_IN_ReadyToGo;

          /* Entry 'ReadyToGo': '<S106>:189' */
          localB->ControlWord = may23_CWGetReady;
        } else {
          /* Transition: '<S106>:241' */
          /* Transition: '<S106>:196' */
          localDW->is_SWSwitchOnDisabled_64 = may23_IN_Waiting;

          /* Entry 'Waiting': '<S106>:195' */
          localB->ControlWord = may23_CWDisable;
        }
      } else {
        /* Transition: '<S106>:168' */
        if (rtu_StatusWord == (int32_T)may23_SWReadyToSwitchOn) {
          /* Transition: '<S106>:169' */
          /* Exit Internal 'SWReadyToSwitchOn_33': '<S106>:160' */
          localDW->is_ControlWordUpdate = may23_IN_SWReadyToSwitchOn_33;

          /* Entry Internal 'SWReadyToSwitchOn_33': '<S106>:160' */
          /* Transition: '<S106>:210' */
          localDW->is_SWReadyToSwitchOn_33 = may23_IN_Waiting1;

          /* Entry 'Waiting1': '<S106>:205' */
          localB->ControlWord = may23_CWEnable;
        } else {
          /* Transition: '<S106>:170' */
          if (rtu_StatusWord == (int32_T)may23_SWOperationEnabled) {
            /* Transition: '<S106>:171' */
            /* Exit Internal 'SWReadyToSwitchOn_33': '<S106>:160' */
            localDW->is_SWReadyToSwitchOn_33 = may23_IN_NO_ACTIVE_CHILD_h;
            localDW->is_ControlWordUpdate = may23_IN_SWOperationEnabled_39;

            /* Entry 'SWOperationEnabled_39': '<S106>:161' */
            /* Entry Internal 'SWOperationEnabled_39': '<S106>:161' */
            /* Transition: '<S106>:216' */
            if (rtu_requestEnable != 0.0) {
              /* Transition: '<S106>:218' */
              localDW->is_SWOperationEnabled_39 = may23_IN_Working;

              /* Entry 'Working': '<S106>:213' */
              localB->ControlWord = may23_CWEnable;
              localDW->faultResetAttempts = 0U;
            } else {
              /* Transition: '<S106>:212' */
              /* Transition: '<S106>:220' */
              localDW->is_SWOperationEnabled_39 = may23_IN_Waiting2;

              /* Entry 'Waiting2': '<S106>:211' */
              localB->ControlWord = may23_CWDisable;
            }
          } else {
            /* Transition: '<S106>:172' */
            if (rtu_StatusWord == (int32_T)may23_SWFault) {
              /* Transition: '<S106>:293' */
              /* Exit Internal 'SWReadyToSwitchOn_33': '<S106>:160' */
              localDW->is_SWReadyToSwitchOn_33 = may23_IN_NO_ACTIVE_CHILD_h;
              localDW->is_ControlWordUpdate = may23_IN_SWFault_8;

              /* Entry Internal 'SWFault_8': '<S106>:162' */
              /* Transition: '<S106>:279' */
              if (rtu_eStops != 0U) {
                /* Transition: '<S106>:336' */
                localDW->is_SWFault_8 = may23_IN_eStopped;

                /* Entry 'eStopped': '<S106>:335' */
                localB->ControlWord = may23_CWDisable;
                localDW->resetCounter = 0U;
              } else {
                /* Transition: '<S106>:344' */
                /* Transition: '<S106>:346' */
                localDW->is_SWFault_8 = may23_IN_WaitReset;

                /* Entry 'WaitReset': '<S106>:347' */
                localB->ControlWord = may23_CWDisable;
                q0 = localDW->faultResetAttempts;
                qY = q0 + 1U;
                if (qY < q0) {
                  qY = MAX_uint32_T;
                }

                localDW->faultResetAttempts = qY;
                localDW->faultClock = 0U;
              }
            } else {
              /* Transition: '<S106>:294' */
              /* Transition: '<S106>:295' */
              /* Exit Internal 'SWReadyToSwitchOn_33': '<S106>:160' */
              localDW->is_SWReadyToSwitchOn_33 = may23_IN_NO_ACTIVE_CHILD_h;
              localDW->is_ControlWordUpdate = may23_IN_UnknownState;

              /* Entry 'UnknownState': '<S106>:291' */
              localB->ControlWord = may23_CWDisable;
            }
          }
        }
      }
    } else {
      localB->ControlWord = may23_CWEnable;

      /* During 'Waiting1': '<S106>:205' */
    }
    break;

   case may23_IN_SWSwitchOnDisabled_64:
    /* During 'SWSwitchOnDisabled_64': '<S106>:159' */
    if (rtu_StatusWord != (int32_T)may23_SWSwitchOnDisabled) {
      /* Transition: '<S106>:183' */
      /* Transition: '<S106>:186' */
      /* Transition: '<S106>:187' */
      /* Transition: '<S106>:188' */
      if (rtu_StatusWord == (int32_T)may23_SWSwitchOnDisabled) {
        /* Transition: '<S106>:165' */
        /* Exit Internal 'SWSwitchOnDisabled_64': '<S106>:159' */
        localDW->is_ControlWordUpdate = may23_IN_SWSwitchOnDisabled_64;

        /* Entry Internal 'SWSwitchOnDisabled_64': '<S106>:159' */
        /* Transition: '<S106>:240' */
        if (rtu_requestEnable != 0.0) {
          /* Transition: '<S106>:192' */
          localDW->is_SWSwitchOnDisabled_64 = may23_IN_ReadyToGo;

          /* Entry 'ReadyToGo': '<S106>:189' */
          localB->ControlWord = may23_CWGetReady;
        } else {
          /* Transition: '<S106>:241' */
          /* Transition: '<S106>:196' */
          localDW->is_SWSwitchOnDisabled_64 = may23_IN_Waiting;

          /* Entry 'Waiting': '<S106>:195' */
          localB->ControlWord = may23_CWDisable;
        }
      } else {
        /* Transition: '<S106>:168' */
        if (rtu_StatusWord == (int32_T)may23_SWReadyToSwitchOn) {
          /* Transition: '<S106>:169' */
          /* Exit Internal 'SWSwitchOnDisabled_64': '<S106>:159' */
          localDW->is_SWSwitchOnDisabled_64 = may23_IN_NO_ACTIVE_CHILD_h;
          localDW->is_ControlWordUpdate = may23_IN_SWReadyToSwitchOn_33;

          /* Entry Internal 'SWReadyToSwitchOn_33': '<S106>:160' */
          /* Transition: '<S106>:210' */
          localDW->is_SWReadyToSwitchOn_33 = may23_IN_Waiting1;

          /* Entry 'Waiting1': '<S106>:205' */
          localB->ControlWord = may23_CWEnable;
        } else {
          /* Transition: '<S106>:170' */
          if (rtu_StatusWord == (int32_T)may23_SWOperationEnabled) {
            /* Transition: '<S106>:171' */
            /* Exit Internal 'SWSwitchOnDisabled_64': '<S106>:159' */
            localDW->is_SWSwitchOnDisabled_64 = may23_IN_NO_ACTIVE_CHILD_h;
            localDW->is_ControlWordUpdate = may23_IN_SWOperationEnabled_39;

            /* Entry 'SWOperationEnabled_39': '<S106>:161' */
            /* Entry Internal 'SWOperationEnabled_39': '<S106>:161' */
            /* Transition: '<S106>:216' */
            if (rtu_requestEnable != 0.0) {
              /* Transition: '<S106>:218' */
              localDW->is_SWOperationEnabled_39 = may23_IN_Working;

              /* Entry 'Working': '<S106>:213' */
              localB->ControlWord = may23_CWEnable;
              localDW->faultResetAttempts = 0U;
            } else {
              /* Transition: '<S106>:212' */
              /* Transition: '<S106>:220' */
              localDW->is_SWOperationEnabled_39 = may23_IN_Waiting2;

              /* Entry 'Waiting2': '<S106>:211' */
              localB->ControlWord = may23_CWDisable;
            }
          } else {
            /* Transition: '<S106>:172' */
            if (rtu_StatusWord == (int32_T)may23_SWFault) {
              /* Transition: '<S106>:293' */
              /* Exit Internal 'SWSwitchOnDisabled_64': '<S106>:159' */
              localDW->is_SWSwitchOnDisabled_64 = may23_IN_NO_ACTIVE_CHILD_h;
              localDW->is_ControlWordUpdate = may23_IN_SWFault_8;

              /* Entry Internal 'SWFault_8': '<S106>:162' */
              /* Transition: '<S106>:279' */
              if (rtu_eStops != 0U) {
                /* Transition: '<S106>:336' */
                localDW->is_SWFault_8 = may23_IN_eStopped;

                /* Entry 'eStopped': '<S106>:335' */
                localB->ControlWord = may23_CWDisable;
                localDW->resetCounter = 0U;
              } else {
                /* Transition: '<S106>:344' */
                /* Transition: '<S106>:346' */
                localDW->is_SWFault_8 = may23_IN_WaitReset;

                /* Entry 'WaitReset': '<S106>:347' */
                localB->ControlWord = may23_CWDisable;
                q0 = localDW->faultResetAttempts;
                qY = q0 + 1U;
                if (qY < q0) {
                  qY = MAX_uint32_T;
                }

                localDW->faultResetAttempts = qY;
                localDW->faultClock = 0U;
              }
            } else {
              /* Transition: '<S106>:294' */
              /* Transition: '<S106>:295' */
              /* Exit Internal 'SWSwitchOnDisabled_64': '<S106>:159' */
              localDW->is_SWSwitchOnDisabled_64 = may23_IN_NO_ACTIVE_CHILD_h;
              localDW->is_ControlWordUpdate = may23_IN_UnknownState;

              /* Entry 'UnknownState': '<S106>:291' */
              localB->ControlWord = may23_CWDisable;
            }
          }
        }
      }
    } else if (localDW->is_SWSwitchOnDisabled_64 == may23_IN_ReadyToGo) {
      localB->ControlWord = may23_CWGetReady;

      /* During 'ReadyToGo': '<S106>:189' */
      /* Transition: '<S106>:222' */
      /* Entry Internal 'SWSwitchOnDisabled_64': '<S106>:159' */
      /* Transition: '<S106>:240' */
      if (rtu_requestEnable != 0.0) {
        /* Transition: '<S106>:192' */
        localDW->is_SWSwitchOnDisabled_64 = may23_IN_ReadyToGo;

        /* Entry 'ReadyToGo': '<S106>:189' */
        localB->ControlWord = may23_CWGetReady;
      } else {
        /* Transition: '<S106>:241' */
        /* Transition: '<S106>:196' */
        localDW->is_SWSwitchOnDisabled_64 = may23_IN_Waiting;

        /* Entry 'Waiting': '<S106>:195' */
        localB->ControlWord = may23_CWDisable;
      }
    } else {
      localB->ControlWord = may23_CWDisable;

      /* During 'Waiting': '<S106>:195' */
      /* Transition: '<S106>:223' */
      /* Entry Internal 'SWSwitchOnDisabled_64': '<S106>:159' */
      /* Transition: '<S106>:240' */
      if (rtu_requestEnable != 0.0) {
        /* Transition: '<S106>:192' */
        localDW->is_SWSwitchOnDisabled_64 = may23_IN_ReadyToGo;

        /* Entry 'ReadyToGo': '<S106>:189' */
        localB->ControlWord = may23_CWGetReady;
      } else {
        /* Transition: '<S106>:241' */
        /* Transition: '<S106>:196' */
        localDW->is_SWSwitchOnDisabled_64 = may23_IN_Waiting;

        /* Entry 'Waiting': '<S106>:195' */
        localB->ControlWord = may23_CWDisable;
      }
    }
    break;

   default:
    may23_UnknownState(rtu_StatusWord, rtu_eStops, rtu_requestEnable, localB,
                       localDW);
    break;
  }
}

/*
 * System initialize for atomic system:
 *    '<S87>/Whistle state'
 *    '<S88>/Whistle state'
 *    '<S162>/Whistle state'
 *    '<S163>/Whistle state'
 */
void may23_Whistlestate_Init(DW_Whistlestate_may23_T *localDW)
{
  localDW->sfEvent = may23_CALL_EVENT_cc;
  localDW->is_active_ControlWordUpdate = 0U;
  localDW->is_ControlWordUpdate = may23_IN_NO_ACTIVE_CHILD_h;
  localDW->is_SWFault_8 = may23_IN_NO_ACTIVE_CHILD_h;
  localDW->temporalCounter_i1 = 0U;
  localDW->is_SWOperationEnabled_39 = may23_IN_NO_ACTIVE_CHILD_h;
  localDW->is_SWReadyToSwitchOn_33 = may23_IN_NO_ACTIVE_CHILD_h;
  localDW->is_SWSwitchOnDisabled_64 = may23_IN_NO_ACTIVE_CHILD_h;
  localDW->is_active_MotorStatus = 0U;
  localDW->is_MotorStatus = may23_IN_NO_ACTIVE_CHILD_h;
  localDW->is_active_c22_ethercat = 0U;
  localDW->is_c22_ethercat = may23_IN_NO_ACTIVE_CHILD_h;
}

/*
 * Output and update for atomic system:
 *    '<S87>/Whistle state'
 *    '<S88>/Whistle state'
 *    '<S162>/Whistle state'
 *    '<S163>/Whistle state'
 */
void may23_Whistlestate(uint16_T rtu_StatusWord, uint32_T rtu_allOK, uint32_T
  rtu_motorOn, uint32_T rtu_eStops, boolean_T rtu_masterEnabled, real_T
  rtu_requestEnable, real_T rtu_max_errors_to_fault, B_Whistlestate_may23_T
  *localB, DW_Whistlestate_may23_T *localDW)
{
  boolean_T sf_internal_predicateOutput;
  uint32_T q0;
  uint32_T qY;
  if (localDW->temporalCounter_i1 < 7U) {
    localDW->temporalCounter_i1++;
  }

  /* Gateway: EtherCAT Subsystem/Arm 1/A1M1/Whistle state */
  localDW->sfEvent = may23_CALL_EVENT_cc;

  /* Chart: '<S87>/Whistle state' */
  /* During: EtherCAT Subsystem/Arm 1/A1M1/Whistle state */
  if (localDW->is_active_c22_ethercat == 0U) {
    /* Entry: EtherCAT Subsystem/Arm 1/A1M1/Whistle state */
    localDW->is_active_c22_ethercat = 1U;

    /* Entry Internal: EtherCAT Subsystem/Arm 1/A1M1/Whistle state */
    /* Transition: '<S106>:36' */
    localB->isPermFaulted = 0.0;
    localDW->faultResetAttempts = 0U;
    localDW->is_c22_ethercat = may23_IN_StatusMonitor;

    /* Entry Internal 'StatusMonitor': '<S106>:29' */
    localDW->is_active_MotorStatus = 1U;

    /* Entry Internal 'MotorStatus': '<S106>:34' */
    /* Transition: '<S106>:340' */
    sf_internal_predicateOutput = ((rtu_allOK != 0U) && (rtu_StatusWord !=
      (int32_T)may23_SWFault));
    if (sf_internal_predicateOutput) {
      /* Transition: '<S106>:38' */
      if (rtu_motorOn != 0U) {
        /* Transition: '<S106>:40' */
        /* Transition: '<S106>:45' */
        localB->motorStatus = 0U;

        /* Transition: '<S106>:46' */
      } else {
        /* Transition: '<S106>:42' */
        localB->motorStatus = 1U;
      }

      /* Transition: '<S106>:43' */
    } else {
      /* Transition: '<S106>:51' */
      localB->motorStatus = 2U;
    }

    /* Transition: '<S106>:50' */
    localDW->is_MotorStatus = may23_IN_MotorStatusUpdate;

    /* Entry 'MotorStatusUpdate': '<S106>:30' */
    localDW->is_active_ControlWordUpdate = 1U;

    /* Entry Internal 'ControlWordUpdate': '<S106>:52' */
    /* Transition: '<S106>:245' */
    /* Transition: '<S106>:188' */
    if (rtu_StatusWord == (int32_T)may23_SWSwitchOnDisabled) {
      /* Transition: '<S106>:165' */
      localDW->is_ControlWordUpdate = may23_IN_SWSwitchOnDisabled_64;

      /* Entry Internal 'SWSwitchOnDisabled_64': '<S106>:159' */
      /* Transition: '<S106>:240' */
      if (rtu_requestEnable != 0.0) {
        /* Transition: '<S106>:192' */
        localDW->is_SWSwitchOnDisabled_64 = may23_IN_ReadyToGo;

        /* Entry 'ReadyToGo': '<S106>:189' */
        localB->ControlWord = may23_CWGetReady;
      } else {
        /* Transition: '<S106>:241' */
        /* Transition: '<S106>:196' */
        localDW->is_SWSwitchOnDisabled_64 = may23_IN_Waiting;

        /* Entry 'Waiting': '<S106>:195' */
        localB->ControlWord = may23_CWDisable;
      }
    } else {
      /* Transition: '<S106>:168' */
      if (rtu_StatusWord == (int32_T)may23_SWReadyToSwitchOn) {
        /* Transition: '<S106>:169' */
        localDW->is_ControlWordUpdate = may23_IN_SWReadyToSwitchOn_33;

        /* Entry Internal 'SWReadyToSwitchOn_33': '<S106>:160' */
        /* Transition: '<S106>:210' */
        localDW->is_SWReadyToSwitchOn_33 = may23_IN_Waiting1;

        /* Entry 'Waiting1': '<S106>:205' */
        localB->ControlWord = may23_CWEnable;
      } else {
        /* Transition: '<S106>:170' */
        if (rtu_StatusWord == (int32_T)may23_SWOperationEnabled) {
          /* Transition: '<S106>:171' */
          localDW->is_ControlWordUpdate = may23_IN_SWOperationEnabled_39;

          /* Entry 'SWOperationEnabled_39': '<S106>:161' */
          /* Entry Internal 'SWOperationEnabled_39': '<S106>:161' */
          /* Transition: '<S106>:216' */
          if (rtu_requestEnable != 0.0) {
            /* Transition: '<S106>:218' */
            localDW->is_SWOperationEnabled_39 = may23_IN_Working;

            /* Entry 'Working': '<S106>:213' */
            localB->ControlWord = may23_CWEnable;
            localDW->faultResetAttempts = 0U;
          } else {
            /* Transition: '<S106>:212' */
            /* Transition: '<S106>:220' */
            localDW->is_SWOperationEnabled_39 = may23_IN_Waiting2;

            /* Entry 'Waiting2': '<S106>:211' */
            localB->ControlWord = may23_CWDisable;
          }
        } else {
          /* Transition: '<S106>:172' */
          if (rtu_StatusWord == (int32_T)may23_SWFault) {
            /* Transition: '<S106>:293' */
            localDW->is_ControlWordUpdate = may23_IN_SWFault_8;

            /* Entry Internal 'SWFault_8': '<S106>:162' */
            /* Transition: '<S106>:279' */
            if (rtu_eStops != 0U) {
              /* Transition: '<S106>:336' */
              localDW->is_SWFault_8 = may23_IN_eStopped;

              /* Entry 'eStopped': '<S106>:335' */
              localB->ControlWord = may23_CWDisable;
              localDW->resetCounter = 0U;
            } else {
              /* Transition: '<S106>:344' */
              /* Transition: '<S106>:346' */
              localDW->is_SWFault_8 = may23_IN_WaitReset;

              /* Entry 'WaitReset': '<S106>:347' */
              localB->ControlWord = may23_CWDisable;
              q0 = localDW->faultResetAttempts;
              qY = q0 + 1U;
              if (qY < q0) {
                qY = MAX_uint32_T;
              }

              localDW->faultResetAttempts = qY;
              localDW->faultClock = 0U;
            }
          } else {
            /* Transition: '<S106>:294' */
            /* Transition: '<S106>:295' */
            localDW->is_ControlWordUpdate = may23_IN_UnknownState;

            /* Entry 'UnknownState': '<S106>:291' */
            localB->ControlWord = may23_CWDisable;
          }
        }
      }
    }
  } else {
    may23_StatusMonitor(rtu_StatusWord, rtu_allOK, rtu_motorOn, rtu_eStops,
                        rtu_masterEnabled, rtu_requestEnable,
                        rtu_max_errors_to_fault, localB, localDW);
  }

  /* End of Chart: '<S87>/Whistle state' */
}

/*
 * Output and update for atomic system:
 *    '<S87>/cleanword'
 *    '<S88>/cleanword'
 *    '<S162>/cleanword'
 *    '<S163>/cleanword'
 */
void may23_cleanword(uint16_T rtu_val, B_cleanword_may23_T *localB)
{
  /* MATLAB Function 'EtherCAT Subsystem/Arm 1/A1M1/cleanword': '<S107>:1' */
  /* '<S107>:1:10' */
  localB->out_val = (uint16_T)(rtu_val & 111);
  if (((rtu_val & 8U) != 0U) || ((rtu_val & 15U) == 0U)) {
    /* '<S107>:1:13' */
    /* '<S107>:1:14' */
    localB->out_val = (uint16_T)(rtu_val & 79);
  }
}

/* System initialize for atomic system: '<S88>/EMCY Message pump' */
void may23_EMCYMessagepump_l_Init(void)
{
  /* InitializeConditions for Memory: '<S134>/Memory' */
  may23_DW.Memory_PreviousInput_n3[0] = may23_P.Memory_InitialCondition_c;

  /* InitializeConditions for Memory: '<S135>/Memory' */
  may23_DW.Memory_PreviousInput_nk[0] = may23_P.Memory_InitialCondition_ax;

  /* InitializeConditions for Memory: '<S134>/Memory' */
  may23_DW.Memory_PreviousInput_n3[1] = may23_P.Memory_InitialCondition_c;

  /* InitializeConditions for Memory: '<S135>/Memory' */
  may23_DW.Memory_PreviousInput_nk[1] = may23_P.Memory_InitialCondition_ax;

  /* InitializeConditions for Memory: '<S134>/Memory' */
  may23_DW.Memory_PreviousInput_n3[2] = may23_P.Memory_InitialCondition_c;

  /* InitializeConditions for Memory: '<S135>/Memory' */
  may23_DW.Memory_PreviousInput_nk[2] = may23_P.Memory_InitialCondition_ax;

  /* InitializeConditions for Memory: '<S136>/Memory' */
  may23_DW.Memory_PreviousInput_e = may23_P.Memory_InitialCondition_k;

  /* SystemInitialize for Chart: '<S124>/Read EMCY' */
  may23_ReadEMCY_Init(&may23_B.sf_ReadEMCY_h, &may23_DW.sf_ReadEMCY_h);

  /* SystemInitialize for MATLAB Function: '<S124>/fault monitor' */
  may23_faultmonitor_Init(&may23_DW.sf_faultmonitor_m);

  /* SystemInitialize for MATLAB Function: '<S124>/pass emcy' */
  may23_passemcy_Init(&may23_DW.sf_passemcy_b);
}

/* Start for atomic system: '<S88>/EMCY Message pump' */
void may23_EMCYMessagepump_k_Start(void)
{
  /* Start for Constant: '<S124>/driveID' */
  may23_B.driveID_o = may23_P.driveID_Value_c;
}

/* Outputs for atomic system: '<S88>/EMCY Message pump' */
void may23_EMCYMessagepump_h(void)
{
  /* DataTypeConversion: '<S124>/Data Type Conversion' */
  may23_B.DataTypeConversion_bu = may23_B.Switch_pj;

  /* MATLAB Function: '<S124>/fault monitor' */
  may23_faultmonitor(may23_B.Switch_pj, &may23_B.sf_faultmonitor_m,
                     &may23_DW.sf_faultmonitor_m);

  /* Constant: '<S124>/driveID' */
  may23_B.driveID_o = may23_P.driveID_Value_c;

  /* Memory: '<S134>/Memory' */
  may23_B.Memory_c4[0] = may23_DW.Memory_PreviousInput_n3[0];
  may23_B.Memory_c4[1] = may23_DW.Memory_PreviousInput_n3[1];
  may23_B.Memory_c4[2] = may23_DW.Memory_PreviousInput_n3[2];

  /* DataTypeConversion: '<S134>/Data Type Conversion2' */
  may23_B.DataTypeConversion2_g[0] = may23_B.Memory_c4[0];
  may23_B.DataTypeConversion2_g[1] = may23_B.Memory_c4[1];
  may23_B.DataTypeConversion2_g[2] = may23_B.Memory_c4[2];

  /* Memory: '<S135>/Memory' */
  may23_B.Memory_iv[0] = may23_DW.Memory_PreviousInput_nk[0];
  may23_B.Memory_iv[1] = may23_DW.Memory_PreviousInput_nk[1];
  may23_B.Memory_iv[2] = may23_DW.Memory_PreviousInput_nk[2];

  /* DataTypeConversion: '<S135>/Data Type Conversion' */
  may23_B.DataTypeConversion_l[0] = may23_B.Memory_iv[0];
  may23_B.DataTypeConversion_l[1] = may23_B.Memory_iv[1];
  may23_B.DataTypeConversion_l[2] = may23_B.Memory_iv[2];

  /* Memory: '<S136>/Memory' */
  may23_B.Memory_ju = may23_DW.Memory_PreviousInput_e;

  /* Chart: '<S124>/Read EMCY' */
  may23_ReadEMCY(may23_B.sf_faultmonitor_m.triggerFaultRead, may23_B.driveID_o,
                 may23_B.DataTypeConversion2_g, may23_B.DataTypeConversion_l,
                 may23_B.Memory_ju, &may23_B.sf_ReadEMCY_h,
                 &may23_DW.sf_ReadEMCY_h);

  /* DataTypeConversion: '<S134>/Data Type Conversion' */
  may23_B.DataTypeConversion_mx = may23_B.sf_ReadEMCY_h.triggerCountRead;

  /* S-Function (BKINethercatasyncsdoupload): '<S134>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S134>/Constant'
   *  Constant: '<S134>/Constant1'
   */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_lh[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload_o3_nd;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload_o1_k;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload_o2_i;
        enInputPtr = &may23_B.DataTypeConversion_mx;
        indexInputPtr = &may23_P.Constant_Value_p;
        subIndexInputPtr = &may23_P.Constant1_Value_o;
        if (may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_lh[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1002,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            658983341,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_lh[7] = 1;
        ;
      }
    }
  }

  /* DataTypeConversion: '<S134>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_nb = (uint32_T)
    may23_B.BKINEtherCATAsyncSDOUpload_o2_i;

  /* MATLAB Function: '<S134>/MATLAB Function' */
  may23_MATLABFunction_g(may23_B.BKINEtherCATAsyncSDOUpload_o3_nd,
    &may23_B.sf_MATLABFunction_lu);

  /* RateTransition: '<S134>/Rate Transition' */
  may23_B.RateTransition_n[0] = may23_B.BKINEtherCATAsyncSDOUpload_o1_k;
  may23_B.RateTransition_n[1] = may23_B.DataTypeConversion1_nb;
  may23_B.RateTransition_n[2] = may23_B.sf_MATLABFunction_lu.out_err_code;

  /* S-Function (BKINethercatasyncsdoupload): '<S135>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S135>/Constant'
   */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_h[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload_o3_ea;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload_o1_a;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload_o2_bg;
        enInputPtr = &may23_B.sf_ReadEMCY_h.emcyReadTrigger[0];
        indexInputPtr = &may23_P.Constant_Value_ka;
        subIndexInputPtr = &may23_B.sf_ReadEMCY_h.emcyReadTrigger[1];
        if (may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_h[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1002,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            658983352,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_h[7] = 1;
        ;
      }
    }
  }

  /* MATLAB Function: '<S135>/MATLAB Function' */
  may23_MATLABFunction_b(may23_B.BKINEtherCATAsyncSDOUpload_o3_ea,
    &may23_B.sf_MATLABFunction_hz);

  /* RateTransition: '<S135>/Rate Transition' */
  may23_B.RateTransition_h[0] = may23_B.BKINEtherCATAsyncSDOUpload_o1_a;
  may23_B.RateTransition_h[1] = may23_B.BKINEtherCATAsyncSDOUpload_o2_bg;
  may23_B.RateTransition_h[2] = may23_B.sf_MATLABFunction_hz.out_err_code;

  /* DataTypeConversion: '<S136>/Data Type Conversion' incorporates:
   *  Constant: '<S136>/Constant'
   */
  may23_B.DataTypeConversion_pa3 = (int32_T)may23_P.Constant_Value_ce;

  /* S-Function (BKINethercatasyncsdodownload): '<S136>/BKIN EtherCAT Async SDO Download' incorporates:
   *  Constant: '<S136>/Constant'
   *  Constant: '<S136>/Constant1'
   */
  {
    int8_T *sigInputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_mg[0];
    perror = &may23_B.BKINEtherCATAsyncSDODownload_o2_m;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDODownload_o1_o;
        sigInputPtr = (int8_T*)&may23_P.Constant_Value_ce;
        enInputPtr = &may23_B.sf_ReadEMCY_h.countOverwriteTrigger;
        indexInputPtr = &may23_P.Constant1_Value_i;
        subIndexInputPtr = &may23_B.DataTypeConversion_pa3;
        if (may23_DW.BKINEtherCATAsyncSDODownload_IWORK_mg[7] != 0) {
          res = ecatAsyncSDODownload(deviceIndex,
            1002,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigInputPtr,
            1*4,
            500,
            658983361,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        } else {
          *sigStatusPtr = 0;
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_mg[7] = 1;
        ;
      }
    }
  }

  /* DataTypeConversion: '<S136>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_m = may23_B.BKINEtherCATAsyncSDODownload_o1_o;

  /* MATLAB Function: '<S124>/pass emcy' */
  may23_passemcy(may23_B.sf_ReadEMCY_h.emcyValPump, may23_B.driveID_o,
                 may23_B.sf_parsestatusregister1.ampStatus,
                 may23_B.sf_parsestatusregister1.currentLimitEnabled,
                 may23_B.Switch_p, may23_B.DataTypeConversion_bu,
                 &may23_B.sf_passemcy_b, &may23_DW.sf_passemcy_b);
}

/* Update for atomic system: '<S88>/EMCY Message pump' */
void may23_EMCYMessagepump_h_Update(void)
{
  /* Update for Memory: '<S134>/Memory' */
  may23_DW.Memory_PreviousInput_n3[0] = may23_B.RateTransition_n[0];
  may23_DW.Memory_PreviousInput_n3[1] = may23_B.RateTransition_n[1];
  may23_DW.Memory_PreviousInput_n3[2] = may23_B.RateTransition_n[2];

  /* Update for Memory: '<S135>/Memory' */
  may23_DW.Memory_PreviousInput_nk[0] = may23_B.RateTransition_h[0];
  may23_DW.Memory_PreviousInput_nk[1] = may23_B.RateTransition_h[1];
  may23_DW.Memory_PreviousInput_nk[2] = may23_B.RateTransition_h[2];

  /* Update for Memory: '<S136>/Memory' */
  may23_DW.Memory_PreviousInput_e = may23_B.DataTypeConversion1_m;
}

/* Termination for atomic system: '<S88>/EMCY Message pump' */
void may23_EMCYMessagepump_k_Term(void)
{
  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S134>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S134>/Constant'
   *  Constant: '<S134>/Constant1'
   */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_lh[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658983341, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1002);
      }
    }
  }

  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S135>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S135>/Constant'
   */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_h[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658983352, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1002);
      }
    }
  }

  /* Terminate for S-Function (BKINethercatasyncsdodownload): '<S136>/BKIN EtherCAT Async SDO Download' incorporates:
   *  Constant: '<S136>/Constant'
   *  Constant: '<S136>/Constant1'
   */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_mg[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDODownload(658983361, deviceIndex);
        printf("SDO Download. Unregister device %d, slave addr: %d\n",
               deviceIndex, 1002);
      }
    }
  }
}

/*
 * Output and update for atomic system:
 *    '<S89>/MATLAB Function1'
 *    '<S170>/MATLAB Function1'
 */
void may23_MATLABFunction1(boolean_T rtu_gripSensor, real_T rtu_robotType,
  real_T rtu_override, real_T rtu_stop_vel_mode, B_MATLABFunction1_may23_T
  *localB)
{
  /* MATLAB Function 'EtherCAT Subsystem/Arm 1/Control Torque Mode/MATLAB Function1': '<S142>:1' */
  /* '<S142>:1:4' */
  /* '<S142>:1:5' */
  /* '<S142>:1:6' */
  /* '<S142>:1:8' */
  localB->mode = 10;
  if ((!(rtu_stop_vel_mode != 0.0)) && (!(rtu_override != 0.0)) &&
      (rtu_robotType == 1.0) && ((real_T)rtu_gripSensor < 0.5)) {
    /* '<S142>:1:10' */
    /* '<S142>:1:11' */
    localB->mode = 9;
  }
}

/*
 * Output and update for atomic system:
 *    '<S77>/Find Robot type'
 *    '<S78>/Find Robot type'
 */
void may23_FindRobottype(const int32_T rtu_intVals[20], const real_T rtu_epPNs[6],
  const real_T rtu_nhpPNs[6], B_FindRobottype_may23_T *localB)
{
  boolean_T x[6];
  int32_T b_ii;
  int32_T i;
  boolean_T exitg1;

  /* MATLAB Function 'EtherCAT Subsystem/Arm 1/Find Robot type': '<S90>:1' */
  /* '<S90>:1:7' */
  localB->robotType = 0.0;

  /* '<S90>:1:8' */
  for (i = 0; i < 6; i++) {
    x[i] = (rtu_epPNs[i] == rtu_intVals[1]);
  }

  i = 0;
  b_ii = 0;
  exitg1 = false;
  while ((!exitg1) && (b_ii < 6)) {
    if (x[b_ii]) {
      i = 1;
      exitg1 = true;
    } else {
      b_ii++;
    }
  }

  if (i == 0) {
    for (i = 0; i < 6; i++) {
      x[i] = (rtu_nhpPNs[i] == rtu_intVals[1]);
    }

    i = 0;
    b_ii = 0;
    exitg1 = false;
    while ((!exitg1) && (b_ii < 6)) {
      if (x[b_ii]) {
        i = 1;
        exitg1 = true;
      } else {
        b_ii++;
      }
    }

    if (i != 0) {
      /* '<S90>:1:11' */
      /* '<S90>:1:12' */
      localB->robotType = 2.0;
    }
  } else {
    /* '<S90>:1:9' */
    /* '<S90>:1:10' */
    localB->robotType = 1.0;
  }
}

/*
 * System initialize for atomic system:
 *    '<S91>/AbsEncoder machine'
 *    '<S92>/AbsEncoder machine'
 *    '<S165>/AbsEncoder machine'
 *    '<S166>/AbsEncoder machine'
 */
void may23_AbsEncodermachine_Init(B_AbsEncodermachine_may23_T *localB,
  DW_AbsEncodermachine_may23_T *localDW)
{
  int32_T i;
  localDW->sfEvent = may23_CALL_EVENT_b;
  localDW->is_active_c18_ethercat = 0U;
  localDW->is_c18_ethercat = may23_IN_NO_ACTIVE_CHILD_o;
  localDW->setupIdx = 0;
  localDW->donePolling = 0;
  localDW->encoderIdx = 0.0;
  localB->setupData[0] = 0;
  localB->setupData[1] = 0;
  localB->setupData[2] = 0;
  localB->setupData[3] = 0;
  localB->SDORequest[0] = 0;
  localB->SDORequest[1] = 0;
  localB->SDORequest[2] = 0;
  for (i = 0; i < 6; i++) {
    localB->encoderOutputs[i] = 0;
  }

  localB->complete = 0;
}

/*
 * System reset for atomic system:
 *    '<S91>/AbsEncoder machine'
 *    '<S92>/AbsEncoder machine'
 *    '<S165>/AbsEncoder machine'
 *    '<S166>/AbsEncoder machine'
 */
void may23_AbsEncodermachine_Reset(B_AbsEncodermachine_may23_T *localB,
  DW_AbsEncodermachine_may23_T *localDW)
{
  int32_T i;
  localDW->sfEvent = may23_CALL_EVENT_b;
  localDW->is_active_c18_ethercat = 0U;
  localDW->is_c18_ethercat = may23_IN_NO_ACTIVE_CHILD_o;
  localDW->setupIdx = 0;
  localDW->donePolling = 0;
  localDW->encoderIdx = 0.0;
  localB->setupData[0] = 0;
  localB->setupData[1] = 0;
  localB->setupData[2] = 0;
  localB->setupData[3] = 0;
  localB->SDORequest[0] = 0;
  localB->SDORequest[1] = 0;
  localB->SDORequest[2] = 0;
  for (i = 0; i < 6; i++) {
    localB->encoderOutputs[i] = 0;
  }

  localB->complete = 0;
}

/*
 * Output and update for atomic system:
 *    '<S91>/AbsEncoder machine'
 *    '<S92>/AbsEncoder machine'
 *    '<S165>/AbsEncoder machine'
 *    '<S166>/AbsEncoder machine'
 */
void may23_AbsEncodermachine(const real_T rtu_setupValues[24], real_T
  rtu_setupValuesCount, const real_T rtu_pollValues[3], const real_T
  rtu_encoderValues[12], real_T rtu_encoderValuesCount, int32_T rtu_intStatus,
  const int32_T rtu_pollResponse[2], B_AbsEncodermachine_may23_T *localB,
  DW_AbsEncodermachine_may23_T *localDW)
{
  /* Gateway: EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/AbsEncoder machine */
  localDW->sfEvent = may23_CALL_EVENT_b;

  /* Chart: '<S91>/AbsEncoder machine' */
  /* During: EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/AbsEncoder machine */
  if (localDW->is_active_c18_ethercat == 0U) {
    /* Entry: EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/AbsEncoder machine */
    localDW->is_active_c18_ethercat = 1U;

    /* Entry Internal: EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/AbsEncoder machine */
    /* Transition: '<S143>:140' */
    localDW->is_c18_ethercat = may23_IN_setup_e;

    /* Entry 'setup': '<S143>:139' */
    localDW->setupIdx = 0;
    localDW->donePolling = 0;
  } else {
    switch (localDW->is_c18_ethercat) {
     case may23_IN_Complete:
      localB->complete = 1;

      /* During 'Complete': '<S143>:200' */
      break;

     case may23_IN_Done:
      /* During 'Done': '<S143>:146' */
      /* Transition: '<S143>:173' */
      localDW->is_c18_ethercat = may23_IN_startPolling;

      /* Entry 'startPolling': '<S143>:172' */
      localB->SDORequest[0] = 1;
      localB->SDORequest[1] = (int32_T)rtu_pollValues[0];
      localB->SDORequest[2] = (int32_T)rtu_pollValues[1];
      break;

     case may23_IN_PollingComplete:
      /* During 'PollingComplete': '<S143>:181' */
      /* Transition: '<S143>:192' */
      localDW->is_c18_ethercat = may23_IN_encoderReadSetup;

      /* Entry 'encoderReadSetup': '<S143>:191' */
      localDW->encoderIdx = 0.0;
      break;

     case may23_IN_ReadNext:
      /* During 'ReadNext': '<S143>:141' */
      if (rtu_intStatus == 1) {
        /* Transition: '<S143>:157' */
        localDW->is_c18_ethercat = may23_IN_disable;

        /* Entry 'disable': '<S143>:156' */
        localB->setupData[1] = 0;
      }
      break;

     case may23_IN_ReadNextEncoder:
      /* During 'ReadNextEncoder': '<S143>:193' */
      if (rtu_pollResponse[1] == 1) {
        /* Transition: '<S143>:196' */
        localDW->is_c18_ethercat = may23_IN_disableRead;

        /* Entry 'disableRead': '<S143>:195' */
        localB->SDORequest[0] = 0;
      }
      break;

     case may23_IN_Received:
      /* During 'Received': '<S143>:142' */
      if (localDW->setupIdx + 1 > rtu_setupValuesCount) {
        /* Transition: '<S143>:147' */
        localDW->is_c18_ethercat = may23_IN_Done;

        /* Entry 'Done': '<S143>:146' */
        localDW->setupIdx = -1;
      } else {
        if (rtu_intStatus == 0) {
          /* Transition: '<S143>:144' */
          localDW->is_c18_ethercat = may23_IN_ReadNext;

          /* Entry 'ReadNext': '<S143>:141' */
          localDW->setupIdx++;
          localB->setupData[0] = (int32_T)rtu_setupValues[localDW->setupIdx + 15];
          localB->setupData[1] = 1;
          localB->setupData[2] = (int32_T)rtu_setupValues[localDW->setupIdx - 1];
          localB->setupData[3] = (int32_T)rtu_setupValues[localDW->setupIdx + 7];
        }
      }
      break;

     case may23_IN_disable:
      /* During 'disable': '<S143>:156' */
      if (rtu_intStatus >= 2) {
        /* Transition: '<S143>:143' */
        localDW->is_c18_ethercat = may23_IN_Received;
      }
      break;

     case may23_IN_disable1:
      /* During 'disable1': '<S143>:174' */
      if (rtu_pollResponse[1] >= 2) {
        /* Transition: '<S143>:179' */
        localDW->is_c18_ethercat = may23_IN_pollReceived;
      }
      break;

     case may23_IN_disableRead:
      /* During 'disableRead': '<S143>:195' */
      if (rtu_pollResponse[1] >= 2) {
        /* Transition: '<S143>:198' */
        localDW->is_c18_ethercat = may23_IN_receivedEncoder;

        /* Entry 'receivedEncoder': '<S143>:197' */
        localB->encoderOutputs[(int32_T)(localDW->encoderIdx - 1.0)] =
          rtu_pollResponse[0];
      }
      break;

     case may23_IN_encoderReadSetup:
      /* During 'encoderReadSetup': '<S143>:191' */
      /* Transition: '<S143>:194' */
      localDW->is_c18_ethercat = may23_IN_ReadNextEncoder;

      /* Entry 'ReadNextEncoder': '<S143>:193' */
      localDW->encoderIdx++;
      localB->SDORequest[0] = 1;
      localB->SDORequest[1] = (int32_T)rtu_encoderValues[(int32_T)
        (localDW->encoderIdx - 1.0)];
      localB->SDORequest[2] = (int32_T)rtu_encoderValues[(int32_T)
        (localDW->encoderIdx - 1.0) + 6];
      break;

     case may23_IN_pollReceived:
      /* During 'pollReceived': '<S143>:178' */
      if (rtu_pollResponse[0] != rtu_pollValues[2]) {
        /* Transition: '<S143>:180' */
        localDW->is_c18_ethercat = may23_IN_startPolling;

        /* Entry 'startPolling': '<S143>:172' */
        localB->SDORequest[0] = 1;
        localB->SDORequest[1] = (int32_T)rtu_pollValues[0];
        localB->SDORequest[2] = (int32_T)rtu_pollValues[1];
      } else {
        /* Transition: '<S143>:189' */
        localDW->is_c18_ethercat = may23_IN_PollingComplete;

        /* Entry 'PollingComplete': '<S143>:181' */
        localDW->donePolling = 1;
      }
      break;

     case may23_IN_receivedEncoder:
      /* During 'receivedEncoder': '<S143>:197' */
      if (localDW->encoderIdx + 1.0 > rtu_encoderValuesCount) {
        /* Transition: '<S143>:201' */
        localDW->is_c18_ethercat = may23_IN_Complete;

        /* Entry 'Complete': '<S143>:200' */
        localB->complete = 1;
      } else {
        /* Transition: '<S143>:199' */
        localDW->is_c18_ethercat = may23_IN_ReadNextEncoder;

        /* Entry 'ReadNextEncoder': '<S143>:193' */
        localDW->encoderIdx++;
        localB->SDORequest[0] = 1;
        localB->SDORequest[1] = (int32_T)rtu_encoderValues[(int32_T)
          (localDW->encoderIdx - 1.0)];
        localB->SDORequest[2] = (int32_T)rtu_encoderValues[(int32_T)
          (localDW->encoderIdx - 1.0) + 6];
      }
      break;

     case may23_IN_setup_e:
      /* During 'setup': '<S143>:139' */
      /* Transition: '<S143>:145' */
      localDW->is_c18_ethercat = may23_IN_ReadNext;

      /* Entry 'ReadNext': '<S143>:141' */
      localDW->setupIdx++;
      localB->setupData[0] = (int32_T)rtu_setupValues[localDW->setupIdx + 15];
      localB->setupData[1] = 1;
      localB->setupData[2] = (int32_T)rtu_setupValues[localDW->setupIdx - 1];
      localB->setupData[3] = (int32_T)rtu_setupValues[localDW->setupIdx + 7];
      break;

     default:
      /* During 'startPolling': '<S143>:172' */
      if (rtu_pollResponse[1] == 1) {
        /* Transition: '<S143>:175' */
        localDW->is_c18_ethercat = may23_IN_disable1;

        /* Entry 'disable1': '<S143>:174' */
        localB->SDORequest[0] = 0;
      }
      break;
    }
  }

  /* End of Chart: '<S91>/AbsEncoder machine' */
}

/*
 * Output and update for atomic system:
 *    '<S91>/set-up values'
 *    '<S92>/set-up values'
 *    '<S165>/set-up values'
 *    '<S166>/set-up values'
 */
void may23_setupvalues(B_setupvalues_may23_T *localB)
{
  int32_T i;
  static const int16_T tmp[24] = { 12475, 12475, 12475, 12475, 12475, 12475,
    12475, 12475, 3, 4, 5, 10, 11, 12, 13, 1, 3, 2, 2, 2, 4, 19, 24, 6 };

  static const int16_T tmp_0[12] = { 12032, 12032, 12032, 12032, 12032, 12032,
    19, 20, 21, 22, 23, 24 };

  for (i = 0; i < 24; i++) {
    localB->setupValues[i] = tmp[i];
  }

  localB->pollValues[0] = 12475.0;
  localB->pollValues[1] = 1.0;
  localB->pollValues[2] = 0.0;
  for (i = 0; i < 12; i++) {
    localB->encoderValues[i] = tmp_0[i];
  }

  /* MATLAB Function 'EtherCAT Subsystem/Arm 1/M1 AbsEnc Calibration/set-up values': '<S144>:1' */
  /* '<S144>:1:5' */
  /* '<S144>:1:16' */
  localB->setupValuesCount = 8.0;

  /* '<S144>:1:18' */
  /* '<S144>:1:20' */
  /* '<S144>:1:29' */
  localB->encoderValuesCount = 6.0;
}

/*
 * Output and update for atomic system:
 *    '<S147>/converter'
 *    '<S148>/converter'
 *    '<S159>/converter'
 *    '<S221>/converter'
 *    '<S222>/converter'
 *    '<S233>/converter'
 */
void may23_converter(uint32_T rtu_inVal, B_converter_may23_T *localB)
{
  uint32_T uint32Out;
  int32_T int32Out;
  real32_T y;

  /* MATLAB Function 'Read Drive 1 SDO/converter': '<S153>:1' */
  /* '<S153>:1:4' */
  memcpy((void *)&uint32Out, (void *)&rtu_inVal, (uint32_T)((size_t)1 * sizeof
          (uint32_T)));

  /* '<S153>:1:5' */
  memcpy((void *)&int32Out, (void *)&rtu_inVal, (uint32_T)((size_t)1 * sizeof
          (int32_T)));

  /* '<S153>:1:6' */
  memcpy((void *)&y, (void *)&rtu_inVal, (uint32_T)((size_t)1 * sizeof(real32_T)));
  localB->uint32Out = uint32Out;
  localB->int32Out = int32Out;
  localB->doubleOut = y;
}

/* Output and update for atomic system: '<S94>/Read Drive 1 SDO' */
void may23_ReadDrive1SDO(void)
{
  /* S-Function (BKINethercatasyncsdoupload): '<S147>/BKIN EtherCAT Async SDO Upload1' */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_i[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload1_o3_a;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload1_o1_p;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload1_o2_ee;
        enInputPtr = &may23_B.sf_SDOreadmachine_i.enable;
        indexInputPtr = &may23_B.DataTypeConversion2_h5;
        subIndexInputPtr = &may23_B.DataTypeConversion1_iw;
        if (may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_i[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1001,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            35101310,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_i[7] = 1;
        ;
      }
    }
  }

  /* MATLAB Function: '<S147>/MATLAB Function' */
  may23_MATLABFunction_b(may23_B.BKINEtherCATAsyncSDOUpload1_o3_a,
    &may23_B.sf_MATLABFunction_mr);

  /* MATLAB Function: '<S147>/converter' */
  may23_converter(may23_B.BKINEtherCATAsyncSDOUpload1_o1_p,
                  &may23_B.sf_converter);
}

/* Termination for atomic system: '<S94>/Read Drive 1 SDO' */
void may23_ReadDrive1SDO_Term(void)
{
  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S147>/BKIN EtherCAT Async SDO Upload1' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_i[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(35101310, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1001);
      }
    }
  }
}

/* Output and update for atomic system: '<S94>/Read Drive 2 SDO' */
void may23_ReadDrive2SDO(void)
{
  /* S-Function (BKINethercatasyncsdoupload): '<S148>/BKIN EtherCAT Async SDO Upload1' */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_b[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload1_o3_b;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload1_o1_oc;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload1_o2_c;
        enInputPtr = &may23_B.sf_SDOreadmachine_i.enable;
        indexInputPtr = &may23_B.DataTypeConversion2_h5;
        subIndexInputPtr = &may23_B.DataTypeConversion1_iw;
        if (may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_b[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1002,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            658985860,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_b[7] = 1;
        ;
      }
    }
  }

  /* DataTypeConversion: '<S148>/Data Type Conversion' */
  may23_B.DataTypeConversion_bj = may23_B.BKINEtherCATAsyncSDOUpload1_o2_c;

  /* MATLAB Function: '<S148>/MATLAB Function' */
  may23_MATLABFunction_b(may23_B.BKINEtherCATAsyncSDOUpload1_o3_b,
    &may23_B.sf_MATLABFunction_j);

  /* DataTypeConversion: '<S148>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_j1 = may23_B.sf_MATLABFunction_j.out_err_code;

  /* MATLAB Function: '<S148>/converter' */
  may23_converter(may23_B.BKINEtherCATAsyncSDOUpload1_o1_oc,
                  &may23_B.sf_converter_e);
}

/* Termination for atomic system: '<S94>/Read Drive 2 SDO' */
void may23_ReadDrive2SDO_Term(void)
{
  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S148>/BKIN EtherCAT Async SDO Upload1' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_b[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658985860, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1002);
      }
    }
  }
}

/*
 * System initialize for atomic system:
 *    '<S94>/SDO read machine'
 *    '<S168>/SDO read machine'
 */
void may23_SDOreadmachine_Init(B_SDOreadmachine_may23_T *localB,
  DW_SDOreadmachine_may23_T *localDW)
{
  localDW->sfEvent = may23_CALL_EVENT_en;
  localDW->is_active_c40_ethercat = 0U;
  localDW->is_c40_ethercat = may23_IN_NO_ACTIVE_CHILD_m;
  localDW->lastTriggerValue = 0;
  localB->enable = 0;
  localB->complete = 0;
}

/*
 * Output and update for atomic system:
 *    '<S94>/SDO read machine'
 *    '<S168>/SDO read machine'
 */
void may23_SDOreadmachine(real_T rtu_triggerWriting, const int32_T
  rtu_readState[2], B_SDOreadmachine_may23_T *localB, DW_SDOreadmachine_may23_T *
  localDW)
{
  boolean_T guard1 = false;

  /* Gateway: EtherCAT Subsystem/Arm 1/SDO reading/SDO read machine */
  localDW->sfEvent = may23_CALL_EVENT_en;

  /* Chart: '<S94>/SDO read machine' */
  /* During: EtherCAT Subsystem/Arm 1/SDO reading/SDO read machine */
  if (localDW->is_active_c40_ethercat == 0U) {
    /* Entry: EtherCAT Subsystem/Arm 1/SDO reading/SDO read machine */
    localDW->is_active_c40_ethercat = 1U;

    /* Entry Internal: EtherCAT Subsystem/Arm 1/SDO reading/SDO read machine */
    /* Transition: '<S149>:140' */
    localDW->is_c40_ethercat = may23_IN_setup_f;

    /* Entry 'setup': '<S149>:139' */
    localB->enable = 0;
  } else {
    guard1 = false;
    switch (localDW->is_c40_ethercat) {
     case may23_IN_ReadNext_l:
      localB->enable = 1;

      /* During 'ReadNext': '<S149>:141' */
      if (rtu_readState[0] == 1) {
        /* Transition: '<S149>:157' */
        localDW->is_c40_ethercat = may23_IN_disable_o;

        /* Entry 'disable': '<S149>:156' */
        localB->enable = 0;
      }
      break;

     case may23_IN_disable_o:
      localB->enable = 0;

      /* During 'disable': '<S149>:156' */
      if (rtu_readState[0] == 2) {
        /* Transition: '<S149>:143' */
        localB->complete = 1;
        guard1 = true;
      } else {
        if (rtu_readState[0] == 3) {
          /* Transition: '<S149>:169' */
          if (rtu_readState[1] == 0) {
            /* Transition: '<S149>:173' */
            localB->complete = -1;
          } else {
            /* Transition: '<S149>:179' */
            /* Transition: '<S149>:178' */
            localB->complete = rtu_readState[1];

            /* Transition: '<S149>:177' */
          }

          /* Transition: '<S149>:174' */
          guard1 = true;
        }
      }
      break;

     default:
      localB->enable = 0;

      /* During 'setup': '<S149>:139' */
      if (rtu_triggerWriting != localDW->lastTriggerValue) {
        /* Transition: '<S149>:145' */
        localDW->is_c40_ethercat = may23_IN_ReadNext_l;

        /* Entry 'ReadNext': '<S149>:141' */
        localB->enable = 1;
        localB->complete = 0;
      }
      break;
    }

    if (guard1) {
      /* Transition: '<S149>:167' */
      localDW->lastTriggerValue = (int32_T)rtu_triggerWriting;
      localDW->is_c40_ethercat = may23_IN_setup_f;

      /* Entry 'setup': '<S149>:139' */
      localB->enable = 0;
    }
  }

  /* End of Chart: '<S94>/SDO read machine' */
}

/*
 * Output and update for atomic system:
 *    '<S94>/values'
 *    '<S94>/values2'
 *    '<S168>/values'
 *    '<S168>/values2'
 */
void may23_values(real_T rtu_inVal, real_T rtu_inVal_a, real_T rtu_inVal_e,
                  B_values_may23_T *localB)
{
  /* SignalConversion generated from: '<S150>/ SFunction ' */
  localB->TmpSignalConversionAtSFunctionInport1[0] = rtu_inVal;
  localB->TmpSignalConversionAtSFunctionInport1[1] = rtu_inVal_a;
  localB->TmpSignalConversionAtSFunctionInport1[2] = rtu_inVal_e;

  /* MATLAB Function 'EtherCAT Subsystem/Arm 1/SDO reading/values': '<S150>:1' */
  /* '<S150>:1:4' */
  localB->outVal[0] = localB->TmpSignalConversionAtSFunctionInport1[0];
  localB->outVal[1] = localB->TmpSignalConversionAtSFunctionInport1[1];
  localB->outVal[2] = localB->TmpSignalConversionAtSFunctionInport1[2];
}

/* System initialize for atomic system: '<S77>/SDO reading' */
void may23_SDOreading_Init(void)
{
  /* InitializeConditions for Memory: '<S94>/Memory' */
  may23_DW.Memory_PreviousInput_n1[0] = may23_P.Memory_InitialCondition_e;
  may23_DW.Memory_PreviousInput_n1[1] = may23_P.Memory_InitialCondition_e;

  /* SystemInitialize for Chart: '<S94>/SDO read machine' */
  may23_SDOreadmachine_Init(&may23_B.sf_SDOreadmachine_i,
    &may23_DW.sf_SDOreadmachine_i);
}

/* Start for atomic system: '<S77>/SDO reading' */
void may23_SDOreading_Start(void)
{
  /* Start for Constant: '<S94>/readAddr' */
  may23_B.readAddr_a[0] = may23_P.readAddr_Value[0];
  may23_B.readAddr_a[1] = may23_P.readAddr_Value[1];
  may23_B.readAddr_a[2] = may23_P.readAddr_Value[2];
}

/* Outputs for atomic system: '<S77>/SDO reading' */
void may23_SDOreading(void)
{
  real_T tmp;

  /* Constant: '<S94>/readAddr' */
  may23_B.readAddr_a[0] = may23_P.readAddr_Value[0];
  may23_B.readAddr_a[1] = may23_P.readAddr_Value[1];
  may23_B.readAddr_a[2] = may23_P.readAddr_Value[2];

  /* DataTypeConversion: '<S94>/Data Type Conversion1' */
  tmp = floor(may23_B.readAddr_a[2]);
  if (rtIsNaN(tmp) || rtIsInf(tmp)) {
    tmp = 0.0;
  } else {
    tmp = fmod(tmp, 4.294967296E+9);
  }

  may23_B.DataTypeConversion1_iw = tmp < 0.0 ? -(int32_T)(uint32_T)-tmp :
    (int32_T)(uint32_T)tmp;

  /* End of DataTypeConversion: '<S94>/Data Type Conversion1' */

  /* DataTypeConversion: '<S94>/Data Type Conversion2' */
  tmp = floor(may23_B.readAddr_a[1]);
  if (rtIsNaN(tmp) || rtIsInf(tmp)) {
    tmp = 0.0;
  } else {
    tmp = fmod(tmp, 4.294967296E+9);
  }

  may23_B.DataTypeConversion2_h5 = tmp < 0.0 ? -(int32_T)(uint32_T)-tmp :
    (int32_T)(uint32_T)tmp;

  /* End of DataTypeConversion: '<S94>/Data Type Conversion2' */

  /* Memory: '<S94>/Memory' */
  may23_B.Memory_g4[0] = may23_DW.Memory_PreviousInput_n1[0];
  may23_B.Memory_g4[1] = may23_DW.Memory_PreviousInput_n1[1];

  /* Chart: '<S94>/SDO read machine' */
  may23_SDOreadmachine(may23_B.readAddr_a[0], may23_B.Memory_g4,
                       &may23_B.sf_SDOreadmachine_i,
                       &may23_DW.sf_SDOreadmachine_i);

  /* Outputs for Atomic SubSystem: '<S94>/Read Drive 1 SDO' */
  may23_ReadDrive1SDO();

  /* End of Outputs for SubSystem: '<S94>/Read Drive 1 SDO' */

  /* Outputs for Atomic SubSystem: '<S94>/Read Drive 2 SDO' */
  may23_ReadDrive2SDO();

  /* End of Outputs for SubSystem: '<S94>/Read Drive 2 SDO' */

  /* DataTypeConversion: '<S94>/convert' */
  may23_B.convert_o = may23_B.sf_converter.uint32Out;

  /* DataTypeConversion: '<S94>/convert1' */
  may23_B.convert1_n = may23_B.sf_converter.int32Out;

  /* DataTypeConversion: '<S94>/convert2' */
  may23_B.convert2_e = may23_B.sf_converter_e.uint32Out;

  /* DataTypeConversion: '<S94>/convert3' */
  may23_B.convert3_b = may23_B.sf_converter_e.int32Out;

  /* DataTypeConversion: '<S94>/status' */
  may23_B.status_n = may23_B.sf_SDOreadmachine_i.complete;

  /* MATLAB Function: '<S94>/values' */
  may23_values(may23_B.convert_o, may23_B.convert1_n,
               may23_B.sf_converter.doubleOut, &may23_B.sf_values);

  /* MATLAB Function: '<S94>/values2' */
  may23_values(may23_B.convert2_e, may23_B.convert3_b,
               may23_B.sf_converter_e.doubleOut, &may23_B.sf_values2);
}

/* Update for atomic system: '<S77>/SDO reading' */
void may23_SDOreading_Update(void)
{
  /* Update for Memory: '<S94>/Memory' */
  may23_DW.Memory_PreviousInput_n1[0] =
    may23_B.BKINEtherCATAsyncSDOUpload1_o2_ee;
  may23_DW.Memory_PreviousInput_n1[1] =
    may23_B.sf_MATLABFunction_mr.out_err_code;
}

/* Termination for atomic system: '<S77>/SDO reading' */
void may23_SDOreading_Term(void)
{
  /* Terminate for Atomic SubSystem: '<S94>/Read Drive 1 SDO' */
  may23_ReadDrive1SDO_Term();

  /* End of Terminate for SubSystem: '<S94>/Read Drive 1 SDO' */

  /* Terminate for Atomic SubSystem: '<S94>/Read Drive 2 SDO' */
  may23_ReadDrive2SDO_Term();

  /* End of Terminate for SubSystem: '<S94>/Read Drive 2 SDO' */
}

real_T rt_roundd_snf(real_T u)
{
  real_T y;
  if (fabs(u) < 4.503599627370496E+15) {
    if (u >= 0.5) {
      y = floor(u + 0.5);
    } else if (u > -0.5) {
      y = u * 0.0;
    } else {
      y = ceil(u - 0.5);
    }
  } else {
    y = u;
  }

  return y;
}

/*
 * System initialize for atomic system:
 *    '<S95>/SDO write machine'
 *    '<S169>/SDO write machine'
 */
void may23_SDOwritemachine_Init(DW_SDOwritemachine_may23_T *localDW)
{
  localDW->sfEvent = may23_CALL_EVENT_ov;
  localDW->is_active_c42_ethercat = 0U;
  localDW->is_c42_ethercat = may23_IN_NO_ACTIVE_CHILD_f;
}

/*
 * Output and update for atomic system:
 *    '<S95>/SDO write machine'
 *    '<S169>/SDO write machine'
 */
void may23_SDOwritemachine(real_T rtu_triggerReading, const int32_T
  rtu_writeState[2], B_SDOwritemachine_may23_T *localB,
  DW_SDOwritemachine_may23_T *localDW)
{
  boolean_T guard1 = false;

  /* Gateway: EtherCAT Subsystem/Arm 1/SDO writing/SDO write machine */
  localDW->sfEvent = may23_CALL_EVENT_ov;

  /* Chart: '<S95>/SDO write machine' */
  /* During: EtherCAT Subsystem/Arm 1/SDO writing/SDO write machine */
  if (localDW->is_active_c42_ethercat == 0U) {
    /* Entry: EtherCAT Subsystem/Arm 1/SDO writing/SDO write machine */
    localDW->is_active_c42_ethercat = 1U;

    /* Entry Internal: EtherCAT Subsystem/Arm 1/SDO writing/SDO write machine */
    /* Transition: '<S157>:140' */
    localDW->is_c42_ethercat = may23_IN_setup_d;

    /* Entry 'setup': '<S157>:139' */
    localB->enable = 0;
  } else {
    guard1 = false;
    switch (localDW->is_c42_ethercat) {
     case may23_IN_ReadNext_f:
      localB->enable = 1;

      /* During 'ReadNext': '<S157>:141' */
      if (rtu_writeState[0] == 1) {
        /* Transition: '<S157>:157' */
        localDW->is_c42_ethercat = may23_IN_disable_c;

        /* Entry 'disable': '<S157>:156' */
        localB->enable = 0;
      }
      break;

     case may23_IN_disable_c:
      localB->enable = 0;

      /* During 'disable': '<S157>:156' */
      if (rtu_writeState[0] == 2) {
        /* Transition: '<S157>:143' */
        localB->complete = 1;
        guard1 = true;
      } else {
        if (rtu_writeState[0] == 3) {
          /* Transition: '<S157>:168' */
          if (rtu_writeState[1] == 0) {
            /* Transition: '<S157>:173' */
            localB->complete = -1;
          } else {
            /* Transition: '<S157>:176' */
            /* Transition: '<S157>:179' */
            localB->complete = rtu_writeState[1];

            /* Transition: '<S157>:178' */
          }

          /* Transition: '<S157>:174' */
          guard1 = true;
        }
      }
      break;

     default:
      localB->enable = 0;

      /* During 'setup': '<S157>:139' */
      if (rtu_triggerReading != localDW->lastTriggerValue) {
        /* Transition: '<S157>:145' */
        localDW->is_c42_ethercat = may23_IN_ReadNext_f;

        /* Entry 'ReadNext': '<S157>:141' */
        localB->enable = 1;
        localB->complete = 0;
      }
      break;
    }

    if (guard1) {
      /* Transition: '<S157>:170' */
      localDW->lastTriggerValue = (int32_T)rt_roundd_snf(rtu_triggerReading);
      localDW->is_c42_ethercat = may23_IN_setup_d;

      /* Entry 'setup': '<S157>:139' */
      localB->enable = 0;
    }
  }

  /* End of Chart: '<S95>/SDO write machine' */
}

/*
 * Output and update for atomic system:
 *    '<S95>/convert'
 *    '<S169>/convert'
 */
void may23_convert(real_T rtu_u, real_T rtu_type, B_convert_may23_T *localB)
{
  uint32_T y;
  real32_T x;
  int32_T b_x;
  real_T tmp;

  /* MATLAB Function 'EtherCAT Subsystem/Arm 1/SDO writing/convert': '<S158>:1' */
  if (rtu_type == 1.0) {
    /* '<S158>:1:4' */
    /* '<S158>:1:5' */
    tmp = rt_roundd_snf(rtu_u);
    if (tmp < 4.294967296E+9) {
      if (tmp >= 0.0) {
        y = (uint32_T)tmp;
      } else {
        y = 0U;
      }
    } else {
      y = MAX_uint32_T;
    }
  } else if (rtu_type == 2.0) {
    /* '<S158>:1:6' */
    /* '<S158>:1:7' */
    tmp = rt_roundd_snf(rtu_u);
    if (tmp < 2.147483648E+9) {
      if (tmp >= -2.147483648E+9) {
        b_x = (int32_T)tmp;
      } else {
        b_x = MIN_int32_T;
      }
    } else {
      b_x = MAX_int32_T;
    }

    memcpy((void *)&y, (void *)&b_x, (uint32_T)((size_t)1 * sizeof(uint32_T)));
  } else {
    /* '<S158>:1:9' */
    x = (real32_T)rtu_u;
    memcpy((void *)&y, (void *)&x, (uint32_T)((size_t)1 * sizeof(uint32_T)));
  }

  localB->y = y;
}

/* System initialize for atomic system: '<S77>/SDO writing' */
void may23_SDOwriting_Init(void)
{
  /* InitializeConditions for Memory: '<S95>/Memory' */
  may23_DW.Memory_PreviousInput_n[0] = may23_P.Memory_InitialCondition_n;
  may23_DW.Memory_PreviousInput_n[1] = may23_P.Memory_InitialCondition_n;

  /* SystemInitialize for Chart: '<S95>/SDO write machine' */
  may23_SDOwritemachine_Init(&may23_DW.sf_SDOwritemachine);
}

/* Start for atomic system: '<S77>/SDO writing' */
void may23_SDOwriting_Start(void)
{
  int32_T i;

  /* Start for Constant: '<S95>/writeData' */
  for (i = 0; i < 5; i++) {
    may23_B.writeData_g[i] = may23_P.writeData_Value[i];
  }

  /* End of Start for Constant: '<S95>/writeData' */
}

/* Outputs for atomic system: '<S77>/SDO writing' */
void may23_SDOwriting(void)
{
  int32_T i;
  real_T tmp;

  /* Constant: '<S95>/writeData' */
  for (i = 0; i < 5; i++) {
    may23_B.writeData_g[i] = may23_P.writeData_Value[i];
  }

  /* End of Constant: '<S95>/writeData' */

  /* MATLAB Function: '<S95>/convert' */
  may23_convert(may23_B.writeData_g[1], may23_B.writeData_g[2],
                &may23_B.sf_convert);

  /* Memory: '<S95>/Memory' */
  may23_B.Memory_n[0] = may23_DW.Memory_PreviousInput_n[0];
  may23_B.Memory_n[1] = may23_DW.Memory_PreviousInput_n[1];

  /* Chart: '<S95>/SDO write machine' */
  may23_SDOwritemachine(may23_B.writeData_g[0], may23_B.Memory_n,
                        &may23_B.sf_SDOwritemachine,
                        &may23_DW.sf_SDOwritemachine);

  /* DataTypeConversion: '<S95>/Data Type Conversion2' */
  tmp = floor(may23_B.writeData_g[3]);
  if (rtIsNaN(tmp) || rtIsInf(tmp)) {
    tmp = 0.0;
  } else {
    tmp = fmod(tmp, 4.294967296E+9);
  }

  may23_B.DataTypeConversion2_a = tmp < 0.0 ? -(int32_T)(uint32_T)-tmp :
    (int32_T)(uint32_T)tmp;

  /* End of DataTypeConversion: '<S95>/Data Type Conversion2' */

  /* DataTypeConversion: '<S95>/Data Type Conversion1' */
  tmp = floor(may23_B.writeData_g[4]);
  if (rtIsNaN(tmp) || rtIsInf(tmp)) {
    tmp = 0.0;
  } else {
    tmp = fmod(tmp, 4.294967296E+9);
  }

  may23_B.DataTypeConversion1_p2 = tmp < 0.0 ? -(int32_T)(uint32_T)-tmp :
    (int32_T)(uint32_T)tmp;

  /* End of DataTypeConversion: '<S95>/Data Type Conversion1' */

  /* S-Function (BKINethercatasyncsdodownload): '<S95>/BKIN EtherCAT Async SDO Download' */
  {
    int8_T *sigInputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_m[0];
    perror = &may23_B.BKINEtherCATAsyncSDODownload_o2_a;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDODownload_o1_c;
        sigInputPtr = (int8_T*)&may23_B.sf_convert.y;
        enInputPtr = &may23_B.sf_SDOwritemachine.enable;
        indexInputPtr = &may23_B.DataTypeConversion2_a;
        subIndexInputPtr = &may23_B.DataTypeConversion1_p2;
        if (may23_DW.BKINEtherCATAsyncSDODownload_IWORK_m[7] != 0) {
          res = ecatAsyncSDODownload(deviceIndex,
            1001,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigInputPtr,
            1*4,
            500,
            65898580,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        } else {
          *sigStatusPtr = 0;
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_m[7] = 1;
        ;
      }
    }
  }

  /* MATLAB Function: '<S95>/MATLAB Function' */
  may23_MATLABFunction_b(may23_B.BKINEtherCATAsyncSDODownload_o2_a,
    &may23_B.sf_MATLABFunction_ae);

  /* DataTypeConversion: '<S95>/status' */
  may23_B.status_d = may23_B.sf_SDOwritemachine.complete;
}

/* Update for atomic system: '<S77>/SDO writing' */
void may23_SDOwriting_Update(void)
{
  /* Update for Memory: '<S95>/Memory' */
  may23_DW.Memory_PreviousInput_n[0] = may23_B.BKINEtherCATAsyncSDODownload_o1_c;
  may23_DW.Memory_PreviousInput_n[1] = may23_B.sf_MATLABFunction_ae.out_err_code;
}

/* Termination for atomic system: '<S77>/SDO writing' */
void may23_SDOwriting_Term(void)
{
  /* Terminate for S-Function (BKINethercatasyncsdodownload): '<S95>/BKIN EtherCAT Async SDO Download' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_m[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDODownload(65898580, deviceIndex);
        printf("SDO Download. Unregister device %d, slave addr: %d\n",
               deviceIndex, 1001);
      }
    }
  }
}

/* Output and update for atomic system: '<S97>/Read Drive 1 SDO' */
void may23_ReadDrive1SDO_c(void)
{
  /* S-Function (BKINethercatasyncsdoupload): '<S159>/BKIN EtherCAT Async SDO Upload1' */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_c[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload1_o3_py;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload1_o1_e;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload1_o2_e;
        enInputPtr = &may23_B.SDOCommand_j[0];
        indexInputPtr = &may23_B.SDOCommand_j[1];
        subIndexInputPtr = &may23_B.SDOCommand_j[2];
        if (may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_c[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1001,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            35081310,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_c[7] = 1;
        ;
      }
    }
  }

  /* MATLAB Function: '<S159>/MATLAB Function' */
  may23_MATLABFunction_b(may23_B.BKINEtherCATAsyncSDOUpload1_o3_py,
    &may23_B.sf_MATLABFunction_e);

  /* MATLAB Function: '<S159>/converter' */
  may23_converter(may23_B.BKINEtherCATAsyncSDOUpload1_o1_e,
                  &may23_B.sf_converter_a);
}

/* Termination for atomic system: '<S97>/Read Drive 1 SDO' */
void may23_ReadDrive1SDO_g_Term(void)
{
  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S159>/BKIN EtherCAT Async SDO Upload1' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_c[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(35081310, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1001);
      }
    }
  }
}

/*
 * Output and update for atomic system:
 *    '<S77>/size'
 *    '<S77>/size1'
 *    '<S78>/size'
 *    '<S78>/size1'
 */
void may23_size(B_size_may23_T *localB)
{
  /* MATLAB Function 'EtherCAT Subsystem/Arm 1/size': '<S98>:1' */
  /* '<S98>:1:3' */
  localB->count = 12.0;
}

/* System initialize for atomic system: '<S162>/EMCY Message pump' */
void may23_EMCYMessagepump_h_Init(void)
{
  /* InitializeConditions for Memory: '<S189>/Memory' */
  may23_DW.Memory_PreviousInput_h4d[0] = may23_P.Memory_InitialCondition_iz;

  /* InitializeConditions for Memory: '<S190>/Memory' */
  may23_DW.Memory_PreviousInput_md[0] = may23_P.Memory_InitialCondition_bo;

  /* InitializeConditions for Memory: '<S189>/Memory' */
  may23_DW.Memory_PreviousInput_h4d[1] = may23_P.Memory_InitialCondition_iz;

  /* InitializeConditions for Memory: '<S190>/Memory' */
  may23_DW.Memory_PreviousInput_md[1] = may23_P.Memory_InitialCondition_bo;

  /* InitializeConditions for Memory: '<S189>/Memory' */
  may23_DW.Memory_PreviousInput_h4d[2] = may23_P.Memory_InitialCondition_iz;

  /* InitializeConditions for Memory: '<S190>/Memory' */
  may23_DW.Memory_PreviousInput_md[2] = may23_P.Memory_InitialCondition_bo;

  /* InitializeConditions for Memory: '<S191>/Memory' */
  may23_DW.Memory_PreviousInput_fh = may23_P.Memory_InitialCondition_pg;

  /* SystemInitialize for Chart: '<S179>/Read EMCY' */
  may23_ReadEMCY_Init(&may23_B.sf_ReadEMCY_b, &may23_DW.sf_ReadEMCY_b);

  /* SystemInitialize for MATLAB Function: '<S179>/fault monitor' */
  may23_faultmonitor_Init(&may23_DW.sf_faultmonitor_f);

  /* SystemInitialize for MATLAB Function: '<S179>/pass emcy' */
  may23_passemcy_Init(&may23_DW.sf_passemcy_c);
}

/* Start for atomic system: '<S162>/EMCY Message pump' */
void may23_EMCYMessagepump_h_Start(void)
{
  /* Start for Constant: '<S179>/driveID' */
  may23_B.driveID_d = may23_P.driveID_Value_i;
}

/* Outputs for atomic system: '<S162>/EMCY Message pump' */
void may23_EMCYMessagepump_p(void)
{
  /* DataTypeConversion: '<S179>/Data Type Conversion' */
  may23_B.DataTypeConversion_pw = may23_B.Switch_g3;

  /* MATLAB Function: '<S179>/fault monitor' */
  may23_faultmonitor(may23_B.Switch_g3, &may23_B.sf_faultmonitor_f,
                     &may23_DW.sf_faultmonitor_f);

  /* Constant: '<S179>/driveID' */
  may23_B.driveID_d = may23_P.driveID_Value_i;

  /* Memory: '<S189>/Memory' */
  may23_B.Memory_c[0] = may23_DW.Memory_PreviousInput_h4d[0];
  may23_B.Memory_c[1] = may23_DW.Memory_PreviousInput_h4d[1];
  may23_B.Memory_c[2] = may23_DW.Memory_PreviousInput_h4d[2];

  /* DataTypeConversion: '<S189>/Data Type Conversion2' */
  may23_B.DataTypeConversion2_b[0] = may23_B.Memory_c[0];
  may23_B.DataTypeConversion2_b[1] = may23_B.Memory_c[1];
  may23_B.DataTypeConversion2_b[2] = may23_B.Memory_c[2];

  /* Memory: '<S190>/Memory' */
  may23_B.Memory_g3[0] = may23_DW.Memory_PreviousInput_md[0];
  may23_B.Memory_g3[1] = may23_DW.Memory_PreviousInput_md[1];
  may23_B.Memory_g3[2] = may23_DW.Memory_PreviousInput_md[2];

  /* DataTypeConversion: '<S190>/Data Type Conversion' */
  may23_B.DataTypeConversion_n[0] = may23_B.Memory_g3[0];
  may23_B.DataTypeConversion_n[1] = may23_B.Memory_g3[1];
  may23_B.DataTypeConversion_n[2] = may23_B.Memory_g3[2];

  /* Memory: '<S191>/Memory' */
  may23_B.Memory_e = may23_DW.Memory_PreviousInput_fh;

  /* Chart: '<S179>/Read EMCY' */
  may23_ReadEMCY(may23_B.sf_faultmonitor_f.triggerFaultRead, may23_B.driveID_d,
                 may23_B.DataTypeConversion2_b, may23_B.DataTypeConversion_n,
                 may23_B.Memory_e, &may23_B.sf_ReadEMCY_b,
                 &may23_DW.sf_ReadEMCY_b);

  /* DataTypeConversion: '<S189>/Data Type Conversion' */
  may23_B.DataTypeConversion_k = may23_B.sf_ReadEMCY_b.triggerCountRead;

  /* S-Function (BKINethercatasyncsdoupload): '<S189>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S189>/Constant'
   *  Constant: '<S189>/Constant1'
   */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_jb[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload_o3_h;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload_o1_n;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload_o2_l;
        enInputPtr = &may23_B.DataTypeConversion_k;
        indexInputPtr = &may23_P.Constant_Value_mj;
        subIndexInputPtr = &may23_P.Constant1_Value_g;
        if (may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_jb[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1003,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            658983381,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_jb[7] = 1;
        ;
      }
    }
  }

  /* DataTypeConversion: '<S189>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_n = (uint32_T)
    may23_B.BKINEtherCATAsyncSDOUpload_o2_l;

  /* MATLAB Function: '<S189>/MATLAB Function' */
  may23_MATLABFunction_g(may23_B.BKINEtherCATAsyncSDOUpload_o3_h,
    &may23_B.sf_MATLABFunction_hm);

  /* RateTransition: '<S189>/Rate Transition' */
  may23_B.RateTransition_m[0] = may23_B.BKINEtherCATAsyncSDOUpload_o1_n;
  may23_B.RateTransition_m[1] = may23_B.DataTypeConversion1_n;
  may23_B.RateTransition_m[2] = may23_B.sf_MATLABFunction_hm.out_err_code;

  /* S-Function (BKINethercatasyncsdoupload): '<S190>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S190>/Constant'
   */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_l[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload_o3_e5;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload_o1_m;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload_o2_k;
        enInputPtr = &may23_B.sf_ReadEMCY_b.emcyReadTrigger[0];
        indexInputPtr = &may23_P.Constant_Value_k2;
        subIndexInputPtr = &may23_B.sf_ReadEMCY_b.emcyReadTrigger[1];
        if (may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_l[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1003,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            658983393,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_l[7] = 1;
        ;
      }
    }
  }

  /* MATLAB Function: '<S190>/MATLAB Function' */
  may23_MATLABFunction_b(may23_B.BKINEtherCATAsyncSDOUpload_o3_e5,
    &may23_B.sf_MATLABFunction_m2);

  /* RateTransition: '<S190>/Rate Transition' */
  may23_B.RateTransition_gq[0] = may23_B.BKINEtherCATAsyncSDOUpload_o1_m;
  may23_B.RateTransition_gq[1] = may23_B.BKINEtherCATAsyncSDOUpload_o2_k;
  may23_B.RateTransition_gq[2] = may23_B.sf_MATLABFunction_m2.out_err_code;

  /* DataTypeConversion: '<S191>/Data Type Conversion' incorporates:
   *  Constant: '<S191>/Constant'
   */
  may23_B.DataTypeConversion_if = (int32_T)may23_P.Constant_Value_jo;

  /* S-Function (BKINethercatasyncsdodownload): '<S191>/BKIN EtherCAT Async SDO Download' incorporates:
   *  Constant: '<S191>/Constant'
   *  Constant: '<S191>/Constant1'
   */
  {
    int8_T *sigInputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_h[0];
    perror = &may23_B.BKINEtherCATAsyncSDODownload_o2_b;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDODownload_o1_f2;
        sigInputPtr = (int8_T*)&may23_P.Constant_Value_jo;
        enInputPtr = &may23_B.sf_ReadEMCY_b.countOverwriteTrigger;
        indexInputPtr = &may23_P.Constant1_Value_p;
        subIndexInputPtr = &may23_B.DataTypeConversion_if;
        if (may23_DW.BKINEtherCATAsyncSDODownload_IWORK_h[7] != 0) {
          res = ecatAsyncSDODownload(deviceIndex,
            1003,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigInputPtr,
            1*4,
            500,
            658983403,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        } else {
          *sigStatusPtr = 0;
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_h[7] = 1;
        ;
      }
    }
  }

  /* DataTypeConversion: '<S191>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_l = may23_B.BKINEtherCATAsyncSDODownload_o1_f2;

  /* MATLAB Function: '<S179>/pass emcy' */
  may23_passemcy(may23_B.sf_ReadEMCY_b.emcyValPump, may23_B.driveID_d,
                 may23_B.sf_parsestatusregister1_g.ampStatus,
                 may23_B.sf_parsestatusregister1_g.currentLimitEnabled,
                 may23_B.Switch_l, may23_B.DataTypeConversion_pw,
                 &may23_B.sf_passemcy_c, &may23_DW.sf_passemcy_c);
}

/* Update for atomic system: '<S162>/EMCY Message pump' */
void may23_EMCYMessagepump_k_Update(void)
{
  /* Update for Memory: '<S189>/Memory' */
  may23_DW.Memory_PreviousInput_h4d[0] = may23_B.RateTransition_m[0];
  may23_DW.Memory_PreviousInput_h4d[1] = may23_B.RateTransition_m[1];
  may23_DW.Memory_PreviousInput_h4d[2] = may23_B.RateTransition_m[2];

  /* Update for Memory: '<S190>/Memory' */
  may23_DW.Memory_PreviousInput_md[0] = may23_B.RateTransition_gq[0];
  may23_DW.Memory_PreviousInput_md[1] = may23_B.RateTransition_gq[1];
  may23_DW.Memory_PreviousInput_md[2] = may23_B.RateTransition_gq[2];

  /* Update for Memory: '<S191>/Memory' */
  may23_DW.Memory_PreviousInput_fh = may23_B.DataTypeConversion1_l;
}

/* Termination for atomic system: '<S162>/EMCY Message pump' */
void may23_EMCYMessagepump_m_Term(void)
{
  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S189>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S189>/Constant'
   *  Constant: '<S189>/Constant1'
   */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_jb[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658983381, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1003);
      }
    }
  }

  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S190>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S190>/Constant'
   */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_l[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658983393, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1003);
      }
    }
  }

  /* Terminate for S-Function (BKINethercatasyncsdodownload): '<S191>/BKIN EtherCAT Async SDO Download' incorporates:
   *  Constant: '<S191>/Constant'
   *  Constant: '<S191>/Constant1'
   */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_h[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDODownload(658983403, deviceIndex);
        printf("SDO Download. Unregister device %d, slave addr: %d\n",
               deviceIndex, 1003);
      }
    }
  }
}

/* System initialize for atomic system: '<S163>/EMCY Message pump' */
void may23_EMCYMessagepump_a_Init(void)
{
  /* InitializeConditions for Memory: '<S209>/Memory' */
  may23_DW.Memory_PreviousInput_i[0] = may23_P.Memory_InitialCondition_hd;

  /* InitializeConditions for Memory: '<S210>/Memory' */
  may23_DW.Memory_PreviousInput_f1[0] = may23_P.Memory_InitialCondition_l;

  /* InitializeConditions for Memory: '<S209>/Memory' */
  may23_DW.Memory_PreviousInput_i[1] = may23_P.Memory_InitialCondition_hd;

  /* InitializeConditions for Memory: '<S210>/Memory' */
  may23_DW.Memory_PreviousInput_f1[1] = may23_P.Memory_InitialCondition_l;

  /* InitializeConditions for Memory: '<S209>/Memory' */
  may23_DW.Memory_PreviousInput_i[2] = may23_P.Memory_InitialCondition_hd;

  /* InitializeConditions for Memory: '<S210>/Memory' */
  may23_DW.Memory_PreviousInput_f1[2] = may23_P.Memory_InitialCondition_l;

  /* InitializeConditions for Memory: '<S211>/Memory' */
  may23_DW.Memory_PreviousInput_h = may23_P.Memory_InitialCondition_a;

  /* SystemInitialize for Chart: '<S199>/Read EMCY' */
  may23_ReadEMCY_Init(&may23_B.sf_ReadEMCY_o, &may23_DW.sf_ReadEMCY_o);

  /* SystemInitialize for MATLAB Function: '<S199>/fault monitor' */
  may23_faultmonitor_Init(&may23_DW.sf_faultmonitor_h);

  /* SystemInitialize for MATLAB Function: '<S199>/pass emcy' */
  may23_passemcy_Init(&may23_DW.sf_passemcy_e);
}

/* Start for atomic system: '<S163>/EMCY Message pump' */
void may23_EMCYMessagepump_o_Start(void)
{
  /* Start for Constant: '<S199>/driveID' */
  may23_B.driveID = may23_P.driveID_Value_n;
}

/* Outputs for atomic system: '<S163>/EMCY Message pump' */
void may23_EMCYMessagepump_hr(void)
{
  /* DataTypeConversion: '<S199>/Data Type Conversion' */
  may23_B.DataTypeConversion_mm = may23_B.Switch_mq;

  /* MATLAB Function: '<S199>/fault monitor' */
  may23_faultmonitor(may23_B.Switch_mq, &may23_B.sf_faultmonitor_h,
                     &may23_DW.sf_faultmonitor_h);

  /* Constant: '<S199>/driveID' */
  may23_B.driveID = may23_P.driveID_Value_n;

  /* Memory: '<S209>/Memory' */
  may23_B.Memory_gv[0] = may23_DW.Memory_PreviousInput_i[0];
  may23_B.Memory_gv[1] = may23_DW.Memory_PreviousInput_i[1];
  may23_B.Memory_gv[2] = may23_DW.Memory_PreviousInput_i[2];

  /* DataTypeConversion: '<S209>/Data Type Conversion2' */
  may23_B.DataTypeConversion2_ht[0] = may23_B.Memory_gv[0];
  may23_B.DataTypeConversion2_ht[1] = may23_B.Memory_gv[1];
  may23_B.DataTypeConversion2_ht[2] = may23_B.Memory_gv[2];

  /* Memory: '<S210>/Memory' */
  may23_B.Memory_ds[0] = may23_DW.Memory_PreviousInput_f1[0];
  may23_B.Memory_ds[1] = may23_DW.Memory_PreviousInput_f1[1];
  may23_B.Memory_ds[2] = may23_DW.Memory_PreviousInput_f1[2];

  /* DataTypeConversion: '<S210>/Data Type Conversion' */
  may23_B.DataTypeConversion_p1[0] = may23_B.Memory_ds[0];
  may23_B.DataTypeConversion_p1[1] = may23_B.Memory_ds[1];
  may23_B.DataTypeConversion_p1[2] = may23_B.Memory_ds[2];

  /* Memory: '<S211>/Memory' */
  may23_B.Memory_g = may23_DW.Memory_PreviousInput_h;

  /* Chart: '<S199>/Read EMCY' */
  may23_ReadEMCY(may23_B.sf_faultmonitor_h.triggerFaultRead, may23_B.driveID,
                 may23_B.DataTypeConversion2_ht, may23_B.DataTypeConversion_p1,
                 may23_B.Memory_g, &may23_B.sf_ReadEMCY_o,
                 &may23_DW.sf_ReadEMCY_o);

  /* DataTypeConversion: '<S209>/Data Type Conversion' */
  may23_B.DataTypeConversion_b5 = may23_B.sf_ReadEMCY_o.triggerCountRead;

  /* S-Function (BKINethercatasyncsdoupload): '<S209>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S209>/Constant'
   *  Constant: '<S209>/Constant1'
   */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_e[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload_o3_l;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload_o1;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload_o2_p;
        enInputPtr = &may23_B.DataTypeConversion_b5;
        indexInputPtr = &may23_P.Constant_Value_de;
        subIndexInputPtr = &may23_P.Constant1_Value_j;
        if (may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_e[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1004,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            658983419,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_e[7] = 1;
        ;
      }
    }
  }

  /* DataTypeConversion: '<S209>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_my = (uint32_T)
    may23_B.BKINEtherCATAsyncSDOUpload_o2_p;

  /* MATLAB Function: '<S209>/MATLAB Function' */
  may23_MATLABFunction_g(may23_B.BKINEtherCATAsyncSDOUpload_o3_l,
    &may23_B.sf_MATLABFunction_hj);

  /* RateTransition: '<S209>/Rate Transition' */
  may23_B.RateTransition_l[0] = may23_B.BKINEtherCATAsyncSDOUpload_o1;
  may23_B.RateTransition_l[1] = may23_B.DataTypeConversion1_my;
  may23_B.RateTransition_l[2] = may23_B.sf_MATLABFunction_hj.out_err_code;

  /* S-Function (BKINethercatasyncsdoupload): '<S210>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S210>/Constant'
   */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_j[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload_o3_e;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload_o1_n3;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload_o2_a;
        enInputPtr = &may23_B.sf_ReadEMCY_o.emcyReadTrigger[0];
        indexInputPtr = &may23_P.Constant_Value_o;
        subIndexInputPtr = &may23_B.sf_ReadEMCY_o.emcyReadTrigger[1];
        if (may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_j[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1004,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            658983431,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_j[7] = 1;
        ;
      }
    }
  }

  /* MATLAB Function: '<S210>/MATLAB Function' */
  may23_MATLABFunction_b(may23_B.BKINEtherCATAsyncSDOUpload_o3_e,
    &may23_B.sf_MATLABFunction_lj);

  /* RateTransition: '<S210>/Rate Transition' */
  may23_B.RateTransition_g[0] = may23_B.BKINEtherCATAsyncSDOUpload_o1_n3;
  may23_B.RateTransition_g[1] = may23_B.BKINEtherCATAsyncSDOUpload_o2_a;
  may23_B.RateTransition_g[2] = may23_B.sf_MATLABFunction_lj.out_err_code;

  /* DataTypeConversion: '<S211>/Data Type Conversion' incorporates:
   *  Constant: '<S211>/Constant'
   */
  may23_B.DataTypeConversion_j = (int32_T)may23_P.Constant_Value_oz;

  /* S-Function (BKINethercatasyncsdodownload): '<S211>/BKIN EtherCAT Async SDO Download' incorporates:
   *  Constant: '<S211>/Constant'
   *  Constant: '<S211>/Constant1'
   */
  {
    int8_T *sigInputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_ai[0];
    perror = &may23_B.BKINEtherCATAsyncSDODownload_o2_h;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDODownload_o1_h;
        sigInputPtr = (int8_T*)&may23_P.Constant_Value_oz;
        enInputPtr = &may23_B.sf_ReadEMCY_o.countOverwriteTrigger;
        indexInputPtr = &may23_P.Constant1_Value_ns;
        subIndexInputPtr = &may23_B.DataTypeConversion_j;
        if (may23_DW.BKINEtherCATAsyncSDODownload_IWORK_ai[7] != 0) {
          res = ecatAsyncSDODownload(deviceIndex,
            1004,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigInputPtr,
            1*4,
            500,
            658983441,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        } else {
          *sigStatusPtr = 0;
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK_ai[7] = 1;
        ;
      }
    }
  }

  /* DataTypeConversion: '<S211>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_gy = may23_B.BKINEtherCATAsyncSDODownload_o1_h;

  /* MATLAB Function: '<S199>/pass emcy' */
  may23_passemcy(may23_B.sf_ReadEMCY_o.emcyValPump, may23_B.driveID,
                 may23_B.sf_parsestatusregister1_d.ampStatus,
                 may23_B.sf_parsestatusregister1_d.currentLimitEnabled,
                 may23_B.Switch_j, may23_B.DataTypeConversion_mm,
                 &may23_B.sf_passemcy_e, &may23_DW.sf_passemcy_e);
}

/* Update for atomic system: '<S163>/EMCY Message pump' */
void may23_EMCYMessagepump_hc_Update(void)
{
  /* Update for Memory: '<S209>/Memory' */
  may23_DW.Memory_PreviousInput_i[0] = may23_B.RateTransition_l[0];
  may23_DW.Memory_PreviousInput_i[1] = may23_B.RateTransition_l[1];
  may23_DW.Memory_PreviousInput_i[2] = may23_B.RateTransition_l[2];

  /* Update for Memory: '<S210>/Memory' */
  may23_DW.Memory_PreviousInput_f1[0] = may23_B.RateTransition_g[0];
  may23_DW.Memory_PreviousInput_f1[1] = may23_B.RateTransition_g[1];
  may23_DW.Memory_PreviousInput_f1[2] = may23_B.RateTransition_g[2];

  /* Update for Memory: '<S211>/Memory' */
  may23_DW.Memory_PreviousInput_h = may23_B.DataTypeConversion1_gy;
}

/* Termination for atomic system: '<S163>/EMCY Message pump' */
void may23_EMCYMessagepump_n_Term(void)
{
  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S209>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S209>/Constant'
   *  Constant: '<S209>/Constant1'
   */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_e[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658983419, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1004);
      }
    }
  }

  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S210>/BKIN EtherCAT Async SDO Upload' incorporates:
   *  Constant: '<S210>/Constant'
   */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_j[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658983431, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1004);
      }
    }
  }

  /* Terminate for S-Function (BKINethercatasyncsdodownload): '<S211>/BKIN EtherCAT Async SDO Download' incorporates:
   *  Constant: '<S211>/Constant'
   *  Constant: '<S211>/Constant1'
   */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_ai[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDODownload(658983441, deviceIndex);
        printf("SDO Download. Unregister device %d, slave addr: %d\n",
               deviceIndex, 1004);
      }
    }
  }
}

/* Output and update for atomic system: '<S168>/Read Drive 3 SDO' */
void may23_ReadDrive3SDO(void)
{
  /* S-Function (BKINethercatasyncsdoupload): '<S221>/BKIN EtherCAT Async SDO Upload1' */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_ho[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload1_o3_p;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload1_o1_g;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload1_o2_g;
        enInputPtr = &may23_B.sf_SDOreadmachine_f.enable;
        indexInputPtr = &may23_B.Conversion2_i;
        subIndexInputPtr = &may23_B.Conversion1_o;
        if (may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_ho[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1003,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            35471299,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_ho[7] = 1;
        ;
      }
    }
  }

  /* MATLAB Function: '<S221>/MATLAB Function' */
  may23_MATLABFunction_b(may23_B.BKINEtherCATAsyncSDOUpload1_o3_p,
    &may23_B.sf_MATLABFunction_f1);

  /* MATLAB Function: '<S221>/converter' */
  may23_converter(may23_B.BKINEtherCATAsyncSDOUpload1_o1_g,
                  &may23_B.sf_converter_f);
}

/* Termination for atomic system: '<S168>/Read Drive 3 SDO' */
void may23_ReadDrive3SDO_Term(void)
{
  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S221>/BKIN EtherCAT Async SDO Upload1' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_ho[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(35471299, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1003);
      }
    }
  }
}

/* Output and update for atomic system: '<S168>/Read Drive 4 SDO' */
void may23_ReadDrive4SDO(void)
{
  /* S-Function (BKINethercatasyncsdoupload): '<S222>/BKIN EtherCAT Async SDO Upload1' */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_h[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload1_o3_h;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload1_o1_o;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload1_o2_n;
        enInputPtr = &may23_B.sf_SDOreadmachine_f.enable;
        indexInputPtr = &may23_B.Conversion2_i;
        subIndexInputPtr = &may23_B.Conversion1_o;
        if (may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_h[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1004,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            658985869,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_h[7] = 1;
        ;
      }
    }
  }

  /* DataTypeConversion: '<S222>/Data Type Conversion' */
  may23_B.DataTypeConversion_a = may23_B.BKINEtherCATAsyncSDOUpload1_o2_n;

  /* DataTypeConversion: '<S222>/Data Type Conversion1' */
  may23_B.DataTypeConversion1_e = may23_B.BKINEtherCATAsyncSDOUpload1_o3_h;

  /* MATLAB Function: '<S222>/converter' */
  may23_converter(may23_B.BKINEtherCATAsyncSDOUpload1_o1_o,
                  &may23_B.sf_converter_ai);
}

/* Termination for atomic system: '<S168>/Read Drive 4 SDO' */
void may23_ReadDrive4SDO_Term(void)
{
  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S222>/BKIN EtherCAT Async SDO Upload1' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK_h[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658985869, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1004);
      }
    }
  }
}

/* System initialize for atomic system: '<S78>/SDO reading' */
void may23_SDOreading_i_Init(void)
{
  /* InitializeConditions for Memory: '<S168>/Memory' */
  may23_DW.Memory_PreviousInput_p[0] = may23_P.Memory_InitialCondition_ex;
  may23_DW.Memory_PreviousInput_p[1] = may23_P.Memory_InitialCondition_ex;

  /* SystemInitialize for Chart: '<S168>/SDO read machine' */
  may23_SDOreadmachine_Init(&may23_B.sf_SDOreadmachine_f,
    &may23_DW.sf_SDOreadmachine_f);
}

/* Start for atomic system: '<S78>/SDO reading' */
void may23_SDOreading_b_Start(void)
{
  /* Start for Constant: '<S168>/readAddr' */
  may23_B.readAddr[0] = may23_P.readAddr_Value_b[0];
  may23_B.readAddr[1] = may23_P.readAddr_Value_b[1];
  may23_B.readAddr[2] = may23_P.readAddr_Value_b[2];
}

/* Outputs for atomic system: '<S78>/SDO reading' */
void may23_SDOreading_f(void)
{
  real_T tmp;

  /* Constant: '<S168>/readAddr' */
  may23_B.readAddr[0] = may23_P.readAddr_Value_b[0];
  may23_B.readAddr[1] = may23_P.readAddr_Value_b[1];
  may23_B.readAddr[2] = may23_P.readAddr_Value_b[2];

  /* DataTypeConversion: '<S168>/Conversion1' */
  tmp = floor(may23_B.readAddr[2]);
  if (rtIsNaN(tmp) || rtIsInf(tmp)) {
    tmp = 0.0;
  } else {
    tmp = fmod(tmp, 4.294967296E+9);
  }

  may23_B.Conversion1_o = tmp < 0.0 ? -(int32_T)(uint32_T)-tmp : (int32_T)
    (uint32_T)tmp;

  /* End of DataTypeConversion: '<S168>/Conversion1' */

  /* DataTypeConversion: '<S168>/Conversion2' */
  tmp = floor(may23_B.readAddr[1]);
  if (rtIsNaN(tmp) || rtIsInf(tmp)) {
    tmp = 0.0;
  } else {
    tmp = fmod(tmp, 4.294967296E+9);
  }

  may23_B.Conversion2_i = tmp < 0.0 ? -(int32_T)(uint32_T)-tmp : (int32_T)
    (uint32_T)tmp;

  /* End of DataTypeConversion: '<S168>/Conversion2' */

  /* Memory: '<S168>/Memory' */
  may23_B.Memory_ms[0] = may23_DW.Memory_PreviousInput_p[0];
  may23_B.Memory_ms[1] = may23_DW.Memory_PreviousInput_p[1];

  /* Chart: '<S168>/SDO read machine' */
  may23_SDOreadmachine(may23_B.readAddr[0], may23_B.Memory_ms,
                       &may23_B.sf_SDOreadmachine_f,
                       &may23_DW.sf_SDOreadmachine_f);

  /* Outputs for Atomic SubSystem: '<S168>/Read Drive 3 SDO' */
  may23_ReadDrive3SDO();

  /* End of Outputs for SubSystem: '<S168>/Read Drive 3 SDO' */

  /* Outputs for Atomic SubSystem: '<S168>/Read Drive 4 SDO' */
  may23_ReadDrive4SDO();

  /* End of Outputs for SubSystem: '<S168>/Read Drive 4 SDO' */

  /* DataTypeConversion: '<S168>/convert' */
  may23_B.convert_b = may23_B.sf_converter_f.uint32Out;

  /* DataTypeConversion: '<S168>/convert1' */
  may23_B.convert1 = may23_B.sf_converter_f.int32Out;

  /* DataTypeConversion: '<S168>/convert2' */
  may23_B.convert2 = may23_B.sf_converter_ai.uint32Out;

  /* DataTypeConversion: '<S168>/convert3' */
  may23_B.convert3 = may23_B.sf_converter_ai.int32Out;

  /* DataTypeConversion: '<S168>/status' */
  may23_B.status_f = may23_B.sf_SDOreadmachine_f.complete;

  /* MATLAB Function: '<S168>/values' */
  may23_values(may23_B.convert_b, may23_B.convert1,
               may23_B.sf_converter_f.doubleOut, &may23_B.sf_values_p);

  /* MATLAB Function: '<S168>/values2' */
  may23_values(may23_B.convert2, may23_B.convert3,
               may23_B.sf_converter_ai.doubleOut, &may23_B.sf_values2_a);
}

/* Update for atomic system: '<S78>/SDO reading' */
void may23_SDOreading_a_Update(void)
{
  /* Update for Memory: '<S168>/Memory' */
  may23_DW.Memory_PreviousInput_p[0] = may23_B.BKINEtherCATAsyncSDOUpload1_o2_g;
  may23_DW.Memory_PreviousInput_p[1] = may23_B.sf_MATLABFunction_f1.out_err_code;
}

/* Termination for atomic system: '<S78>/SDO reading' */
void may23_SDOreading_p_Term(void)
{
  /* Terminate for Atomic SubSystem: '<S168>/Read Drive 3 SDO' */
  may23_ReadDrive3SDO_Term();

  /* End of Terminate for SubSystem: '<S168>/Read Drive 3 SDO' */

  /* Terminate for Atomic SubSystem: '<S168>/Read Drive 4 SDO' */
  may23_ReadDrive4SDO_Term();

  /* End of Terminate for SubSystem: '<S168>/Read Drive 4 SDO' */
}

/* System initialize for atomic system: '<S78>/SDO writing' */
void may23_SDOwriting_b_Init(void)
{
  /* InitializeConditions for Memory: '<S169>/Memory' */
  may23_DW.Memory_PreviousInput_kj[0] = may23_P.Memory_InitialCondition_o;
  may23_DW.Memory_PreviousInput_kj[1] = may23_P.Memory_InitialCondition_o;

  /* SystemInitialize for Chart: '<S169>/SDO write machine' */
  may23_SDOwritemachine_Init(&may23_DW.sf_SDOwritemachine_g);
}

/* Start for atomic system: '<S78>/SDO writing' */
void may23_SDOwriting_j_Start(void)
{
  int32_T i;

  /* Start for Constant: '<S169>/writeData' */
  for (i = 0; i < 5; i++) {
    may23_B.writeData[i] = may23_P.writeData_Value_o[i];
  }

  /* End of Start for Constant: '<S169>/writeData' */
}

/* Outputs for atomic system: '<S78>/SDO writing' */
void may23_SDOwriting_l(void)
{
  int32_T i;
  real_T tmp;

  /* Constant: '<S169>/writeData' */
  for (i = 0; i < 5; i++) {
    may23_B.writeData[i] = may23_P.writeData_Value_o[i];
  }

  /* End of Constant: '<S169>/writeData' */

  /* MATLAB Function: '<S169>/convert' */
  may23_convert(may23_B.writeData[1], may23_B.writeData[2],
                &may23_B.sf_convert_n);

  /* Memory: '<S169>/Memory' */
  may23_B.Memory_oh[0] = may23_DW.Memory_PreviousInput_kj[0];
  may23_B.Memory_oh[1] = may23_DW.Memory_PreviousInput_kj[1];

  /* Chart: '<S169>/SDO write machine' */
  may23_SDOwritemachine(may23_B.writeData[0], may23_B.Memory_oh,
                        &may23_B.sf_SDOwritemachine_g,
                        &may23_DW.sf_SDOwritemachine_g);

  /* DataTypeConversion: '<S169>/Data Type Conversion2' */
  tmp = floor(may23_B.writeData[3]);
  if (rtIsNaN(tmp) || rtIsInf(tmp)) {
    tmp = 0.0;
  } else {
    tmp = fmod(tmp, 4.294967296E+9);
  }

  may23_B.DataTypeConversion2_i0 = tmp < 0.0 ? -(int32_T)(uint32_T)-tmp :
    (int32_T)(uint32_T)tmp;

  /* End of DataTypeConversion: '<S169>/Data Type Conversion2' */

  /* DataTypeConversion: '<S169>/Data Type Conversion1' */
  tmp = floor(may23_B.writeData[4]);
  if (rtIsNaN(tmp) || rtIsInf(tmp)) {
    tmp = 0.0;
  } else {
    tmp = fmod(tmp, 4.294967296E+9);
  }

  may23_B.DataTypeConversion1_du = tmp < 0.0 ? -(int32_T)(uint32_T)-tmp :
    (int32_T)(uint32_T)tmp;

  /* End of DataTypeConversion: '<S169>/Data Type Conversion1' */

  /* S-Function (BKINethercatasyncsdodownload): '<S169>/BKIN EtherCAT Async SDO Download' */
  {
    int8_T *sigInputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK[0];
    perror = &may23_B.BKINEtherCATAsyncSDODownload_o2;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDODownload_o1;
        sigInputPtr = (int8_T*)&may23_B.sf_convert_n.y;
        enInputPtr = &may23_B.sf_SDOwritemachine_g.enable;
        indexInputPtr = &may23_B.DataTypeConversion2_i0;
        subIndexInputPtr = &may23_B.DataTypeConversion1_du;
        if (may23_DW.BKINEtherCATAsyncSDODownload_IWORK[7] != 0) {
          res = ecatAsyncSDODownload(deviceIndex,
            1003,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigInputPtr,
            1*4,
            500,
            658983537,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        } else {
          *sigStatusPtr = 0;
        }

        may23_DW.BKINEtherCATAsyncSDODownload_IWORK[7] = 1;
        ;
      }
    }
  }

  /* MATLAB Function: '<S169>/MATLAB Function' */
  may23_MATLABFunction_b(may23_B.BKINEtherCATAsyncSDODownload_o2,
    &may23_B.sf_MATLABFunction_c);

  /* DataTypeConversion: '<S169>/status' */
  may23_B.status = may23_B.sf_SDOwritemachine_g.complete;
}

/* Update for atomic system: '<S78>/SDO writing' */
void may23_SDOwriting_g_Update(void)
{
  /* Update for Memory: '<S169>/Memory' */
  may23_DW.Memory_PreviousInput_kj[0] = may23_B.BKINEtherCATAsyncSDODownload_o1;
  may23_DW.Memory_PreviousInput_kj[1] = may23_B.sf_MATLABFunction_c.out_err_code;
}

/* Termination for atomic system: '<S78>/SDO writing' */
void may23_SDOwriting_k_Term(void)
{
  /* Terminate for S-Function (BKINethercatasyncsdodownload): '<S169>/BKIN EtherCAT Async SDO Download' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDODownload(658983537, deviceIndex);
        printf("SDO Download. Unregister device %d, slave addr: %d\n",
               deviceIndex, 1003);
      }
    }
  }
}

/* Output and update for atomic system: '<S172>/Read Drive 3 SDO' */
void may23_ReadDrive3SDO_d(void)
{
  /* S-Function (BKINethercatasyncsdoupload): '<S233>/BKIN EtherCAT Async SDO Upload1' */
  {
    int8_T *sigOutputPtr;
    int32_T *sigStatusPtr;
    uint32_T *perror;
    int32_T *enInputPtr;
    int_T deviceIndex;
    static int counter= 0;
    int_T actLen;
    int_T res;
    int_T state;
    int32_T *indexInputPtr;
    int32_T *subIndexInputPtr;
    deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK[0];
    perror = &may23_B.BKINEtherCATAsyncSDOUpload1_o3;
    *perror = 0;                       // preset to no error
    if (deviceIndex != NO_ETHERCAT) {
      state = xpcEtherCATgetState( deviceIndex );
      if (state >= 2 ) {
        sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload1_o1;
        sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload1_o2;
        enInputPtr = &may23_B.SDOCommand[0];
        indexInputPtr = &may23_B.SDOCommand[1];
        subIndexInputPtr = &may23_B.SDOCommand[2];
        if (may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK[7] != 0) {
          res = ecatAsyncSDOUpload(deviceIndex,
            1003,
            (unsigned short)*indexInputPtr,
            (unsigned char)*subIndexInputPtr,
            (void *)sigOutputPtr,
            1*4,
            &actLen,
            500,
            35091299,
            sigStatusPtr,
            *enInputPtr);
          *perror = res;
        }

        may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK[7] = 1;
        ;
      }
    }
  }

  /* MATLAB Function: '<S233>/MATLAB Function' */
  may23_MATLABFunction_b(may23_B.BKINEtherCATAsyncSDOUpload1_o3,
    &may23_B.sf_MATLABFunction_g3);

  /* MATLAB Function: '<S233>/converter' */
  may23_converter(may23_B.BKINEtherCATAsyncSDOUpload1_o1,
                  &may23_B.sf_converter_c);
}

/* Termination for atomic system: '<S172>/Read Drive 3 SDO' */
void may23_ReadDrive3SDO_j_Term(void)
{
  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S233>/BKIN EtherCAT Async SDO Upload1' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload1_IWORK[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(35091299, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1003);
      }
    }
  }
}

/*
 * Output and update for atomic system:
 *    '<S75>/splitKINData arm1'
 *    '<S75>/splitKINData arm2'
 */
void may23_splitKINDataarm1(const real_T rtu_robot_row[50],
  B_splitKINDataarm1_may23_T *localB)
{
  /* MATLAB Function 'DataLogging/Poll KINARM/make KINData bus/splitKINData arm1': '<S303>:1' */
  /* '<S303>:1:10' */
  localB->link_lengths[0] = rtu_robot_row[0];
  localB->link_lengths[1] = rtu_robot_row[1];

  /* '<S303>:1:11' */
  localB->pointer_offset = rtu_robot_row[2];

  /* '<S303>:1:12' */
  localB->shoulder_loc[0] = rtu_robot_row[3];
  localB->shoulder_loc[1] = rtu_robot_row[4];

  /* '<S303>:1:13' */
  localB->arm_orientation = rtu_robot_row[5];

  /* '<S303>:1:14' */
  localB->shoulder_ang = rtu_robot_row[6];

  /* '<S303>:1:15' */
  localB->elbow_ang = rtu_robot_row[7];

  /* '<S303>:1:16' */
  localB->shoulder_ang_velocity = rtu_robot_row[8];

  /* '<S303>:1:17' */
  localB->elbow_ang_velocity = rtu_robot_row[9];

  /* '<S303>:1:18' */
  localB->shoulder_ang_acceleration = rtu_robot_row[10];

  /* '<S303>:1:19' */
  localB->elbow_ang_acceleration = rtu_robot_row[11];

  /* '<S303>:1:20' */
  localB->joint_torque_cmd[0] = rtu_robot_row[12];
  localB->joint_torque_cmd[1] = rtu_robot_row[13];

  /* '<S303>:1:21' */
  localB->motor_torque_cmd[0] = rtu_robot_row[14];
  localB->motor_torque_cmd[1] = rtu_robot_row[15];

  /* '<S303>:1:23' */
  localB->link_angle[0] = rtu_robot_row[16];
  localB->link_angle[1] = rtu_robot_row[17];

  /* '<S303>:1:24' */
  localB->link_velocity[0] = rtu_robot_row[18];
  localB->link_velocity[1] = rtu_robot_row[19];

  /* '<S303>:1:25' */
  localB->link_acceleration[0] = rtu_robot_row[20];
  localB->link_acceleration[1] = rtu_robot_row[21];

  /* '<S303>:1:28' */
  localB->hand_position[0] = rtu_robot_row[22];
  localB->hand_position[1] = rtu_robot_row[23];

  /* '<S303>:1:29' */
  localB->hand_velocity[0] = rtu_robot_row[24];
  localB->hand_velocity[1] = rtu_robot_row[25];

  /* '<S303>:1:30' */
  localB->hand_acceleration[0] = rtu_robot_row[26];
  localB->hand_acceleration[1] = rtu_robot_row[27];

  /* '<S303>:1:32' */
  localB->elbow_position[0] = rtu_robot_row[28];
  localB->elbow_position[1] = rtu_robot_row[29];

  /* '<S303>:1:33' */
  localB->elbow_velocity[0] = rtu_robot_row[30];
  localB->elbow_velocity[1] = rtu_robot_row[31];

  /* '<S303>:1:34' */
  localB->elbow_acceleration[0] = rtu_robot_row[32];
  localB->elbow_acceleration[1] = rtu_robot_row[33];

  /* '<S303>:1:39' */
  localB->motor_status = rtu_robot_row[36];

  /* '<S303>:1:41' */
  localB->force_sensor_force_uvw[0] = rtu_robot_row[37];
  localB->force_sensor_force_uvw[1] = rtu_robot_row[38];
  localB->force_sensor_force_uvw[2] = rtu_robot_row[39];

  /* '<S303>:1:42' */
  localB->force_sensor_torque_uvw[0] = rtu_robot_row[40];
  localB->force_sensor_torque_uvw[1] = rtu_robot_row[41];
  localB->force_sensor_torque_uvw[2] = rtu_robot_row[42];

  /* '<S303>:1:44' */
  localB->force_sensor_force_xyz[0] = rtu_robot_row[43];
  localB->force_sensor_force_xyz[1] = rtu_robot_row[44];
  localB->force_sensor_force_xyz[2] = rtu_robot_row[45];

  /* '<S303>:1:45' */
  localB->force_sensor_torque_xyz[0] = rtu_robot_row[46];
  localB->force_sensor_torque_xyz[1] = rtu_robot_row[47];
  localB->force_sensor_torque_xyz[2] = rtu_robot_row[48];

  /* '<S303>:1:46' */
  localB->force_sensor_timestamp = rtu_robot_row[49];
}

/*
 * Output and update for atomic system:
 *    '<S76>/split_primary'
 *    '<S76>/split_primary1'
 */
void may23_split_primary(const real_T rtu_primary_data[6],
  B_split_primary_may23_T *localB)
{
  /* MATLAB Function 'DataLogging/Poll KINARM/split_primary/split_primary': '<S306>:1' */
  /* '<S306>:1:2' */
  localB->link_angles[0] = rtu_primary_data[0];
  localB->link_angles[1] = rtu_primary_data[1];

  /* '<S306>:1:3' */
  localB->link_velocities[0] = rtu_primary_data[2];
  localB->link_velocities[1] = rtu_primary_data[3];

  /* '<S306>:1:4' */
  localB->link_acceleration[0] = rtu_primary_data[4];
  localB->link_acceleration[1] = rtu_primary_data[5];
}

/* Function for Chart: '<S77>/SDO read machine' */
static void may23_clearValues(void)
{
  int32_T n;

  /* MATLAB Function 'clearValues': '<S93>:167' */
  /* '<S93>:167:2' */
  /* '<S93>:167:2' */
  /* '<S93>:167:3' */
  memset(&may23_B.intSDOValues_m[0], 0, 20U * sizeof(int32_T));

  /* '<S93>:167:6' */
  for (n = 0; n < 20; n++) {
    /* '<S93>:167:6' */
    /* '<S93>:167:7' */
    may23_B.floatSDOValues_d[n] = 0.0;
  }
}

/* Function for Chart: '<S78>/SDO read machine' */
static void may23_clearValues_p(void)
{
  int32_T n;

  /* MATLAB Function 'clearValues': '<S167>:167' */
  /* '<S167>:167:2' */
  /* '<S167>:167:2' */
  /* '<S167>:167:3' */
  memset(&may23_B.intSDOValues[0], 0, 20U * sizeof(int32_T));

  /* '<S167>:167:6' */
  for (n = 0; n < 20; n++) {
    /* '<S167>:167:6' */
    /* '<S167>:167:7' */
    may23_B.floatSDOValues[n] = 0.0;
  }
}

/* Function for MATLAB Function: '<S66>/latch_errors' */
static void may23_circshift_b(real_T a[12])
{
  int32_T k;
  real_T unusedU0_idx_0;
  real_T unusedU0_idx_1;
  unusedU0_idx_0 = a[10];
  unusedU0_idx_1 = a[11];
  for (k = 9; k >= 0; k--) {
    a[k + 2] = a[k];
  }

  a[0] = unusedU0_idx_0;
  a[1] = unusedU0_idx_1;
}

/* Function for MATLAB Function: '<S86>/create kinematics' */
static void may23_convertL1L2ToShoElb(const real_T L1L2[4], const real_T
  orientation[2], real_T shoElb[4])
{
  real_T L2;
  real_T L1;

  /* '<S244>:1:69' */
  shoElb[0] = L1L2[0];
  shoElb[2] = L1L2[2];

  /* '<S244>:1:70' */
  /* '<S244>:1:71' */
  /* '<S244>:1:72' */
  L2 = L1L2[1];

  /* '<S244>:1:73' */
  L1 = L1L2[0];
  if (orientation[0] == -1.0) {
    /* '<S244>:1:75' */
    /* '<S244>:1:76' */
    L2 = -L1L2[1] + 3.1415926535897931;

    /* '<S244>:1:77' */
    L1 = -L1L2[0] + 3.1415926535897931;

    /* '<S244>:1:78' */
    shoElb[0] = -L1L2[0] + 3.1415926535897931;
  }

  /* '<S244>:1:81' */
  shoElb[1] = L2 - L1;

  /* '<S244>:1:82' */
  /* '<S244>:1:71' */
  /* '<S244>:1:72' */
  L2 = L1L2[3];

  /* '<S244>:1:73' */
  L1 = L1L2[2];
  if (orientation[1] == -1.0) {
    /* '<S244>:1:75' */
    /* '<S244>:1:76' */
    L2 = -L1L2[3] + 3.1415926535897931;

    /* '<S244>:1:77' */
    L1 = -L1L2[2] + 3.1415926535897931;

    /* '<S244>:1:78' */
    shoElb[2] = -L1L2[2] + 3.1415926535897931;
  }

  /* '<S244>:1:81' */
  shoElb[3] = L2 - L1;

  /* '<S244>:1:82' */
}

/* Function for MATLAB Function: '<S86>/create kinematics' */
static void may23_reduce(const int32_T a_size[2], int32_T absp[2], boolean_T
  shiftright[2])
{
  int32_T b;
  boolean_T c;
  int32_T a_size_0;
  a_size_0 = a_size[0];
  b = 0;
  c = true;
  if (0 > a_size_0) {
    b = a_size_0 - 1;
    c = false;
  }

  absp[0] = b;
  shiftright[0] = c;
  a_size_0 = a_size[1];
  b = 1;
  c = true;
  if (1 > (a_size_0 >> 1)) {
    b = a_size_0 - 1;
    c = false;
  }

  absp[1] = b;
  shiftright[1] = c;
}

/* Function for MATLAB Function: '<S86>/create kinematics' */
static void may23_circshift_f5(real_T a_data[], const int32_T a_size[2])
{
  real_T buffer_data[50];
  int32_T ns;
  int32_T pagesize;
  int32_T absp[2];
  boolean_T shiftright[2];
  int32_T b;
  int32_T pageroot;
  int32_T i;
  int32_T e_k;
  int32_T c;
  int8_T npages_idx_0;
  if (a_size[1] != 0) {
    may23_reduce(a_size, absp, shiftright);
    npages_idx_0 = (int8_T)a_size[1];
    b = a_size[0];
    ns = absp[0] - 1;
    pagesize = a_size[0];
    if ((a_size[0] > 1) && (absp[0] > 0)) {
      for (i = 0; i < npages_idx_0; i++) {
        pageroot = i * pagesize;
        if (shiftright[0]) {
          for (e_k = -1; e_k < ns; e_k++) {
            c = e_k;
            buffer_data[c + 1] = a_data[((pageroot + c) + b) - ns];
          }

          for (c = b; c >= ns + 2; c--) {
            a_data[(pageroot + c) - 1] = a_data[((pageroot + c) - ns) - 2];
          }

          for (e_k = 0; e_k <= ns; e_k++) {
            c = e_k;
            a_data[pageroot + c] = buffer_data[c];
          }
        } else {
          for (e_k = 0; e_k <= ns; e_k++) {
            c = e_k;
            buffer_data[c] = a_data[pageroot + c];
          }

          c = b - ns;
          for (e_k = 0; e_k <= c - 2; e_k++) {
            a_data[pageroot + e_k] = a_data[((pageroot + e_k) + ns) + 1];
          }

          for (e_k = -1; e_k < ns; e_k++) {
            c = e_k;
            a_data[((pageroot + c) + b) - ns] = buffer_data[c + 1];
          }
        }
      }
    }

    b = a_size[1];
    ns = absp[1] - 1;
    if ((a_size[1] > 1) && (absp[1] > 0)) {
      for (pageroot = 0; pageroot < pagesize; pageroot++) {
        if (shiftright[1]) {
          for (e_k = -1; e_k < ns; e_k++) {
            c = e_k;
            buffer_data[c + 1] = a_data[((c + b) - ns) * pagesize + pageroot];
          }

          for (c = b; c >= ns + 2; c--) {
            a_data[pageroot + (c - 1) * pagesize] = a_data[((c - ns) - 2) *
              pagesize + pageroot];
          }

          for (e_k = 0; e_k <= ns; e_k++) {
            c = e_k;
            a_data[pageroot + c * pagesize] = buffer_data[c];
          }
        } else {
          for (e_k = 0; e_k <= ns; e_k++) {
            c = e_k;
            buffer_data[c] = a_data[c * pagesize + pageroot];
          }

          c = b - ns;
          for (e_k = 0; e_k <= c - 2; e_k++) {
            a_data[pageroot + e_k * pagesize] = a_data[((e_k + ns) + 1) *
              pagesize + pageroot];
          }

          for (e_k = -1; e_k < ns; e_k++) {
            c = e_k;
            a_data[pageroot + ((c + b) - ns) * pagesize] = buffer_data[c + 1];
          }
        }
      }
    }
  }
}

/* Function for MATLAB Function: '<S86>/create kinematics' */
static void may23_updatePosVel(const real_T oldPosData_data[], const int32_T
  oldPosData_size[2], const real_T oldVelData_data[], const int32_T
  oldVelData_size[2], const real_T L1L2Angs[4], real_T stepTime, const real_T
  robotOrientation[2], real_T posData_data[], int32_T posData_size[2], real_T
  velData_data[], int32_T velData_size[2])
{
  real_T shoElb[4];
  real_T dt;
  int32_T loop_ub;

  /* '<S244>:1:47' */
  may23_convertL1L2ToShoElb(L1L2Angs, robotOrientation, shoElb);

  /* '<S244>:1:48' */
  /* '<S244>:1:64' */
  posData_size[0] = 4;
  posData_size[1] = oldPosData_size[1];
  loop_ub = oldPosData_size[0] * oldPosData_size[1] - 1;
  if (0 <= loop_ub) {
    memcpy(&posData_data[0], &oldPosData_data[0], (loop_ub + 1) * sizeof(real_T));
  }

  may23_circshift_f5(posData_data, posData_size);

  /* '<S244>:1:65' */
  posData_data[0] = shoElb[0];
  posData_data[1] = shoElb[1];
  posData_data[2] = shoElb[2];
  posData_data[3] = shoElb[3];

  /* '<S244>:1:49' */
  /* '<S244>:1:103' */
  /* '<S244>:1:102' */
  dt = ((real_T)posData_size[1] - 1.0) * stepTime;

  /* '<S244>:1:103' */
  /* '<S244>:1:64' */
  velData_size[0] = 4;
  velData_size[1] = oldVelData_size[1];
  loop_ub = oldVelData_size[0] * oldVelData_size[1] - 1;
  if (0 <= loop_ub) {
    memcpy(&velData_data[0], &oldVelData_data[0], (loop_ub + 1) * sizeof(real_T));
  }

  may23_circshift_f5(velData_data, velData_size);

  /* '<S244>:1:65' */
  loop_ub = posData_size[1];
  velData_data[0] = (posData_data[0] - posData_data[(loop_ub - 1) << 2]) / dt;
  velData_data[1] = (posData_data[1] - posData_data[((loop_ub - 1) << 2) + 1]) /
    dt;
  velData_data[2] = (posData_data[2] - posData_data[((loop_ub - 1) << 2) + 2]) /
    dt;
  velData_data[3] = (posData_data[3] - posData_data[((loop_ub - 1) << 2) + 3]) /
    dt;
}

/* Function for MATLAB Function: '<S86>/create kinematics' */
static void may23_buildEncoderData(real_T queueSize, const real_T shoElb[4],
  real_T encData_data[], int32_T encData_size[2])
{
  real_T shoElb_0;
  real_T shoElb_1;
  real_T shoElb_2;
  real_T shoElb_3;
  int32_T i;
  int32_T tmp;
  int32_T tmp_0;
  int32_T tmp_1;
  int32_T tmp_2;

  /* '<S244>:1:58' */
  /* '<S244>:1:59' */
  tmp = (int32_T)queueSize;
  shoElb_0 = shoElb[0];
  tmp_0 = (int32_T)queueSize;
  shoElb_1 = shoElb[1];
  tmp_1 = (int32_T)queueSize;
  shoElb_2 = shoElb[2];
  tmp_2 = (int32_T)queueSize;
  shoElb_3 = shoElb[3];
  encData_size[0] = 4;
  encData_size[1] = tmp;
  for (i = 0; i < tmp; i++) {
    encData_data[i << 2] = shoElb_0;
  }

  for (i = 0; i < tmp_0; i++) {
    encData_data[(i << 2) + 1] = shoElb_1;
  }

  for (i = 0; i < tmp_1; i++) {
    encData_data[(i << 2) + 2] = shoElb_2;
  }

  for (i = 0; i < tmp_2; i++) {
    encData_data[(i << 2) + 3] = shoElb_3;
  }
}

/* Function for MATLAB Function: '<S86>/create kinematics' */
static void may23_buildEncoderData_k(real_T queueSize, real_T encData_data[],
  int32_T encData_size[2])
{
  int32_T i;
  int32_T tmp;
  int32_T tmp_0;
  int32_T tmp_1;
  int32_T tmp_2;

  /* '<S244>:1:58' */
  /* '<S244>:1:59' */
  tmp = (int32_T)queueSize;
  tmp_0 = (int32_T)queueSize;
  tmp_1 = (int32_T)queueSize;
  tmp_2 = (int32_T)queueSize;
  encData_size[0] = 4;
  encData_size[1] = tmp;
  for (i = 0; i < tmp; i++) {
    encData_data[i << 2] = 0.0;
  }

  for (i = 0; i < tmp_0; i++) {
    encData_data[(i << 2) + 1] = 0.0;
  }

  for (i = 0; i < tmp_1; i++) {
    encData_data[(i << 2) + 2] = 0.0;
  }

  for (i = 0; i < tmp_2; i++) {
    encData_data[(i << 2) + 3] = 0.0;
  }
}

/* Function for MATLAB Function: '<S86>/create kinematics' */
static void may23_buildKinematics(const real_T posData_data[], const real_T
  velData_data[], const int32_T velData_size[2], real_T stepTime, const uint32_T
  motorStatuses[4], real_T r1[10], real_T r2[10])
{
  real_T dt;
  int32_T velData;
  real_T r1_0;

  /* '<S244>:1:53' */
  /* '<S244>:1:89' */
  /* '<S244>:1:91' */
  /* '<S244>:1:92' */
  /* '<S244>:1:93' */
  /* '<S244>:1:103' */
  /* '<S244>:1:102' */
  dt = ((real_T)velData_size[1] - 1.0) * stepTime;

  /* '<S244>:1:103' */
  velData = velData_size[1];

  /* '<S244>:1:94' */
  /* '<S244>:1:95' */
  r1[0] = posData_data[0];
  r1[2] = velData_data[0];
  r1[4] = (velData_data[0] - velData_data[(velData - 1) << 2]) / dt;
  r1_0 = r1[2];
  r1[6] = r1_0;
  r1[8] = motorStatuses[0];
  r1[1] = posData_data[1];
  r1[3] = velData_data[1];
  r1[5] = (velData_data[1] - velData_data[((velData - 1) << 2) + 1]) / dt;
  r1_0 = r1[3];
  r1[7] = r1_0;
  r1[9] = motorStatuses[1];

  /* '<S244>:1:54' */
  /* '<S244>:1:89' */
  /* '<S244>:1:91' */
  /* '<S244>:1:92' */
  /* '<S244>:1:93' */
  /* '<S244>:1:103' */
  /* '<S244>:1:102' */
  dt = ((real_T)velData_size[1] - 1.0) * stepTime;

  /* '<S244>:1:103' */
  velData = velData_size[1];

  /* '<S244>:1:94' */
  /* '<S244>:1:95' */
  r2[0] = posData_data[2];
  r2[2] = velData_data[2];
  r2[4] = (velData_data[2] - velData_data[((velData - 1) << 2) + 2]) / dt;
  r1_0 = r2[2];
  r2[6] = r1_0;
  r2[8] = motorStatuses[2];
  r2[1] = posData_data[3];
  r2[3] = velData_data[3];
  r2[5] = (velData_data[3] - velData_data[((velData - 1) << 2) + 3]) / dt;
  r1_0 = r2[3];
  r2[7] = r1_0;
  r2[9] = motorStatuses[3];
}

/* Function for MATLAB Function: '<S243>/filter_velocities' */
static void may23_insertVal(real_T arr[3], real_T v)
{
  real_T a_idx_2;
  real_T a_idx_0;
  real_T a_idx_1;

  /* '<S250>:1:40' */
  a_idx_1 = arr[1];
  a_idx_2 = arr[2];
  a_idx_0 = a_idx_1;
  a_idx_1 = a_idx_2;
  a_idx_2 = arr[0];
  arr[0] = a_idx_0;
  arr[1] = a_idx_1;
  arr[2] = a_idx_2;

  /* '<S250>:1:41' */
  arr[2] = v;
}

/* System initialize for atomic system: '<S1>/Poll KINARM' */
void may23_PollKINARM_Init(void)
{
  int32_T i;

  /* InitializeConditions for UnitDelay: '<S275>/Output' */
  may23_DW.Output_DSTATE_p = may23_P.Output_InitialCondition_d;

  /* InitializeConditions for UnitDelay: '<S80>/Output' */
  may23_DW.Output_DSTATE_po = may23_P.Output_InitialCondition_p;

  /* InitializeConditions for RateTransition generated from: '<S69>/Data write' */
  for (i = 0; i < 20; i++) {
    may23_DW.TmpRTBAtDatawriteInport2_Buffer0[i] =
      may23_P.TmpRTBAtDatawriteInport2_InitialCondition;
  }

  /* End of InitializeConditions for RateTransition generated from: '<S69>/Data write' */

  /* InitializeConditions for RateTransition generated from: '<S69>/Data write' */
  for (i = 0; i < 12; i++) {
    may23_DW.TmpRTBAtDatawriteInport3_Buffer0[i] =
      may23_P.TmpRTBAtDatawriteInport3_InitialCondition;
  }

  /* End of InitializeConditions for RateTransition generated from: '<S69>/Data write' */

  /* InitializeConditions for RateTransition generated from: '<S69>/Data write' */
  may23_DW.TmpRTBAtDatawriteInport4_Buffer0 =
    may23_P.TmpRTBAtDatawriteInport4_InitialCondition;

  /* InitializeConditions for RateTransition generated from: '<S69>/Data write' */
  for (i = 0; i < 7; i++) {
    may23_DW.TmpRTBAtDatawriteInport5_Buffer0[i] =
      may23_P.TmpRTBAtDatawriteInport5_InitialCondition;
  }

  /* End of InitializeConditions for RateTransition generated from: '<S69>/Data write' */

  /* SystemInitialize for Chart: '<S82>/master_state' */
  may23_DW.sfEvent_p = -1;
  may23_DW.is_active_c10_ethercat = 0U;
  may23_DW.is_c10_ethercat = may23_IN_NO_ACTIVE_CHILD_mv;

  /* SystemInitialize for MATLAB Function: '<S81>/update digital outputs' */
  may23_DW.prevRunStatus = 0U;

  /* SystemInitialize for Atomic SubSystem: '<S30>/Force Sensor Control' */
  may23_ForceSensorControl_Init();

  /* End of SystemInitialize for SubSystem: '<S30>/Force Sensor Control' */

  /* SystemInitialize for Enabled SubSystem: '<S70>/Data receive' */
  /* InitializeConditions for UnitDelay: '<S286>/Output' */
  may23_DW.Output_DSTATE_a = may23_P.Output_InitialCondition_e;

  /* SystemInitialize for MATLAB Function: '<S283>/MATLAB Function' */
  may23_DW.r1Sho[0] = 0.0;
  may23_DW.r1Elb[0] = 0.0;
  may23_DW.r2Sho[0] = 0.0;
  may23_DW.r2Elb[0] = 0.0;
  may23_DW.last_tick[0] = 0.0;
  may23_DW.r1Sho[1] = 0.0;
  may23_DW.r1Elb[1] = 0.0;
  may23_DW.r2Sho[1] = 0.0;
  may23_DW.r2Elb[1] = 0.0;
  may23_DW.last_tick[1] = 0.0;
  may23_DW.r1Sho[2] = 0.0;
  may23_DW.r1Elb[2] = 0.0;
  may23_DW.r2Sho[2] = 0.0;
  may23_DW.r2Elb[2] = 0.0;
  may23_DW.last_tick[2] = 0.0;
  may23_DW.r1Sho[3] = 0.0;
  may23_DW.r1Elb[3] = 0.0;
  may23_DW.r2Sho[3] = 0.0;
  may23_DW.r2Elb[3] = 0.0;
  may23_DW.last_tick[3] = 0.0;

  /* SystemInitialize for Outport: '<S283>/servo counter' */
  may23_B.Output_d = may23_P.servocounter_Y0;

  /* SystemInitialize for Outport: '<S283>/EP calibration btn' */
  may23_B.Constant_d = may23_P.EPcalibrationbtn_Y0_f;

  /* SystemInitialize for Outport: '<S283>/Status bits' */
  for (i = 0; i < 7; i++) {
    may23_B.Constant1[i] = may23_P.Statusbits_Y0_l[i];
  }

  /* End of SystemInitialize for Outport: '<S283>/Status bits' */
  /* End of SystemInitialize for SubSystem: '<S70>/Data receive' */

  /* SystemInitialize for Enabled SubSystem: '<S68>/read_pmac' */
  may23_read_pmac_Init();

  /* End of SystemInitialize for SubSystem: '<S68>/read_pmac' */

  /* SystemInitialize for Enabled SubSystem: '<S66>/Arm 1' */
  /* InitializeConditions for Memory: '<S87>/Memory' */
  may23_DW.Memory_PreviousInput_k = may23_P.Memory_InitialCondition_p;

  /* InitializeConditions for Memory: '<S88>/Memory' */
  may23_DW.Memory_PreviousInput_d = may23_P.Memory_InitialCondition_ps;

  /* InitializeConditions for Memory: '<S97>/Memory' */
  may23_DW.Memory_PreviousInput_dp = may23_P.Memory_InitialCondition_h;

  /* InitializeConditions for Memory: '<S97>/Memory1' */
  may23_DW.Memory1_PreviousInput_j = may23_P.Memory1_InitialCondition_o;

  /* InitializeConditions for Memory: '<S97>/Memory2' */
  may23_DW.Memory2_PreviousInput_g5[0] = may23_P.Memory2_InitialCondition_j;

  /* InitializeConditions for Memory: '<S77>/Memory2' */
  may23_DW.Memory2_PreviousInput_j[0] = may23_P.Memory2_InitialCondition_h;

  /* InitializeConditions for Memory: '<S97>/Memory2' */
  may23_DW.Memory2_PreviousInput_g5[1] = may23_P.Memory2_InitialCondition_j;

  /* InitializeConditions for Memory: '<S77>/Memory2' */
  may23_DW.Memory2_PreviousInput_j[1] = may23_P.Memory2_InitialCondition_h;

  /* InitializeConditions for Memory: '<S77>/Memory3' */
  may23_DW.Memory3_PreviousInput_h = may23_P.Memory3_InitialCondition;

  /* SystemInitialize for Atomic SubSystem: '<S87>/EMCY Message pump' */
  may23_EMCYMessagepump_Init();

  /* End of SystemInitialize for SubSystem: '<S87>/EMCY Message pump' */

  /* SystemInitialize for Chart: '<S87>/Whistle state' */
  may23_Whistlestate_Init(&may23_DW.sf_Whistlestate);

  /* SystemInitialize for Atomic SubSystem: '<S88>/EMCY Message pump' */
  may23_EMCYMessagepump_l_Init();

  /* End of SystemInitialize for SubSystem: '<S88>/EMCY Message pump' */

  /* SystemInitialize for Chart: '<S88>/Whistle state' */
  may23_Whistlestate_Init(&may23_DW.sf_Whistlestate_a);

  /* SystemInitialize for Chart: '<S77>/SDO read machine' */
  may23_DW.sfEvent_k0 = -1;
  may23_DW.temporalCounter_i1_b = 0U;
  may23_DW.is_active_c37_ethercat = 0U;
  may23_DW.is_c37_ethercat = may23_IN_NO_ACTIVE_CHILD_mv;
  may23_DW.valueIdx_n = 0;
  may23_DW.lastTrigger_d = -1;
  may23_DW.valueCount_a = 0.0;
  may23_B.SDOCommand_j[0] = 0;
  may23_B.SDOCommand_j[1] = 0;
  may23_B.SDOCommand_j[2] = 0;
  memset(&may23_B.intSDOValues_m[0], 0, 20U * sizeof(int32_T));
  for (i = 0; i < 20; i++) {
    may23_B.floatSDOValues_d[i] = 0.0;
  }

  may23_B.complete_b = 0;

  /* End of SystemInitialize for Chart: '<S77>/SDO read machine' */

  /* SystemInitialize for MATLAB Function: '<S77>/forceEnableDisable' */
  may23_DW.lastRunningState_o = 0.0;
  may23_DW.faultResetCycles_i = 0.0;

  /* SystemInitialize for Enabled SubSystem: '<S77>/M1 AbsEnc Calibration' */
  /* InitializeConditions for Memory: '<S91>/Memory' */
  may23_DW.Memory_PreviousInput_l = may23_P.Memory_InitialCondition_b;

  /* InitializeConditions for Memory: '<S91>/Memory1' */
  may23_DW.Memory1_PreviousInput_p[0] = may23_P.Memory1_InitialCondition_a;
  may23_DW.Memory1_PreviousInput_p[1] = may23_P.Memory1_InitialCondition_a;

  /* SystemInitialize for Chart: '<S91>/AbsEncoder machine' */
  may23_AbsEncodermachine_Init(&may23_B.sf_AbsEncodermachine,
    &may23_DW.sf_AbsEncodermachine);

  /* End of SystemInitialize for SubSystem: '<S77>/M1 AbsEnc Calibration' */

  /* SystemInitialize for Enabled SubSystem: '<S77>/M2 AbsEnc Calibration' */
  /* InitializeConditions for Memory: '<S92>/Memory' */
  may23_DW.Memory_PreviousInput_kk = may23_P.Memory_InitialCondition_ba;

  /* InitializeConditions for Memory: '<S92>/Memory1' */
  may23_DW.Memory1_PreviousInput_i[0] = may23_P.Memory1_InitialCondition_nm;
  may23_DW.Memory1_PreviousInput_i[1] = may23_P.Memory1_InitialCondition_nm;

  /* SystemInitialize for Chart: '<S92>/AbsEncoder machine' */
  may23_AbsEncodermachine_Init(&may23_B.sf_AbsEncodermachine_l,
    &may23_DW.sf_AbsEncodermachine_l);

  /* End of SystemInitialize for SubSystem: '<S77>/M2 AbsEnc Calibration' */

  /* SystemInitialize for Atomic SubSystem: '<S77>/SDO reading' */
  may23_SDOreading_Init();

  /* End of SystemInitialize for SubSystem: '<S77>/SDO reading' */

  /* SystemInitialize for Atomic SubSystem: '<S77>/SDO writing' */
  may23_SDOwriting_Init();

  /* End of SystemInitialize for SubSystem: '<S77>/SDO writing' */
  /* End of SystemInitialize for SubSystem: '<S66>/Arm 1' */

  /* SystemInitialize for Enabled SubSystem: '<S66>/Arm 2' */
  /* InitializeConditions for Memory: '<S162>/Memory' */
  may23_DW.Memory_PreviousInput_c = may23_P.Memory_InitialCondition_d;

  /* InitializeConditions for Memory: '<S163>/Memory' */
  may23_DW.Memory_PreviousInput_g = may23_P.Memory_InitialCondition_ki;

  /* InitializeConditions for Memory: '<S172>/Memory' */
  may23_DW.Memory_PreviousInput_b = may23_P.Memory_InitialCondition_lc;

  /* InitializeConditions for Memory: '<S172>/Memory1' */
  may23_DW.Memory1_PreviousInput_n = may23_P.Memory1_InitialCondition_e;

  /* InitializeConditions for Memory: '<S172>/Memory2' */
  may23_DW.Memory2_PreviousInput_o[0] = may23_P.Memory2_InitialCondition_c;

  /* InitializeConditions for Memory: '<S78>/Memory2' */
  may23_DW.Memory2_PreviousInput_g[0] = may23_P.Memory2_InitialCondition_i;

  /* InitializeConditions for Memory: '<S172>/Memory2' */
  may23_DW.Memory2_PreviousInput_o[1] = may23_P.Memory2_InitialCondition_c;

  /* InitializeConditions for Memory: '<S78>/Memory2' */
  may23_DW.Memory2_PreviousInput_g[1] = may23_P.Memory2_InitialCondition_i;

  /* InitializeConditions for Memory: '<S78>/Memory3' */
  may23_DW.Memory3_PreviousInput_k = may23_P.Memory3_InitialCondition_o;

  /* SystemInitialize for Atomic SubSystem: '<S162>/EMCY Message pump' */
  may23_EMCYMessagepump_h_Init();

  /* End of SystemInitialize for SubSystem: '<S162>/EMCY Message pump' */

  /* SystemInitialize for Chart: '<S162>/Whistle state' */
  may23_Whistlestate_Init(&may23_DW.sf_Whistlestate_l);

  /* SystemInitialize for Atomic SubSystem: '<S163>/EMCY Message pump' */
  may23_EMCYMessagepump_a_Init();

  /* End of SystemInitialize for SubSystem: '<S163>/EMCY Message pump' */

  /* SystemInitialize for Chart: '<S163>/Whistle state' */
  may23_Whistlestate_Init(&may23_DW.sf_Whistlestate_m);

  /* SystemInitialize for Chart: '<S78>/SDO read machine' */
  may23_DW.sfEvent_k = -1;
  may23_DW.temporalCounter_i1_n4 = 0U;
  may23_DW.is_active_c95_ethercat = 0U;
  may23_DW.is_c95_ethercat = may23_IN_NO_ACTIVE_CHILD_mv;
  may23_DW.valueIdx = 0;
  may23_DW.lastTrigger = -1;
  may23_DW.valueCount = 0.0;
  may23_B.SDOCommand[0] = 0;
  may23_B.SDOCommand[1] = 0;
  may23_B.SDOCommand[2] = 0;
  memset(&may23_B.intSDOValues[0], 0, 20U * sizeof(int32_T));
  for (i = 0; i < 20; i++) {
    may23_B.floatSDOValues[i] = 0.0;
  }

  may23_B.complete = 0;

  /* End of SystemInitialize for Chart: '<S78>/SDO read machine' */

  /* SystemInitialize for MATLAB Function: '<S78>/forceEnableDisable' */
  may23_DW.lastRunningState = 0.0;
  may23_DW.faultResetCycles = 0.0;

  /* SystemInitialize for Enabled SubSystem: '<S78>/M1 AbsEnc Calibration' */
  /* InitializeConditions for Memory: '<S165>/Memory' */
  may23_DW.Memory_PreviousInput_a = may23_P.Memory_InitialCondition_ec;

  /* InitializeConditions for Memory: '<S165>/Memory1' */
  may23_DW.Memory1_PreviousInput_b[0] = may23_P.Memory1_InitialCondition_p;
  may23_DW.Memory1_PreviousInput_b[1] = may23_P.Memory1_InitialCondition_p;

  /* SystemInitialize for Chart: '<S165>/AbsEncoder machine' */
  may23_AbsEncodermachine_Init(&may23_B.sf_AbsEncodermachine_j,
    &may23_DW.sf_AbsEncodermachine_j);

  /* End of SystemInitialize for SubSystem: '<S78>/M1 AbsEnc Calibration' */

  /* SystemInitialize for Enabled SubSystem: '<S78>/M2 AbsEnc Calibration' */
  /* InitializeConditions for Memory: '<S166>/Memory' */
  may23_DW.Memory_PreviousInput_po = may23_P.Memory_InitialCondition_pu;

  /* InitializeConditions for Memory: '<S166>/Memory1' */
  may23_DW.Memory1_PreviousInput_ck[0] = may23_P.Memory1_InitialCondition_ai;
  may23_DW.Memory1_PreviousInput_ck[1] = may23_P.Memory1_InitialCondition_ai;

  /* SystemInitialize for Chart: '<S166>/AbsEncoder machine' */
  may23_AbsEncodermachine_Init(&may23_B.sf_AbsEncodermachine_n,
    &may23_DW.sf_AbsEncodermachine_n);

  /* End of SystemInitialize for SubSystem: '<S78>/M2 AbsEnc Calibration' */

  /* SystemInitialize for Atomic SubSystem: '<S78>/SDO reading' */
  may23_SDOreading_i_Init();

  /* End of SystemInitialize for SubSystem: '<S78>/SDO reading' */

  /* SystemInitialize for Atomic SubSystem: '<S78>/SDO writing' */
  may23_SDOwriting_b_Init();

  /* End of SystemInitialize for SubSystem: '<S78>/SDO writing' */
  /* End of SystemInitialize for SubSystem: '<S66>/Arm 2' */

  /* SystemInitialize for MATLAB Function: '<S66>/latch_errors' */
  may23_DW.enteredOpStep = 0U;
  may23_DW.sfEvent_l = -1;
  may23_DW.is_active_c58_General = 0U;
  may23_DW.is_c58_General = may23_IN_NO_ACTIVE_CHILD_mv;

  /* SystemInitialize for Chart: '<S30>/control read write' incorporates:
   *  SubSystem: '<S66>/update'
   */
  for (i = 0; i < 12; i++) {
    /* SystemInitialize for MATLAB Function: '<S66>/latch_errors' */
    may23_DW.latchedErrors[i] = 0.0;
    may23_DW.latchedDCErrors[i] = 0.0;

    /* SystemInitialize for MATLAB Function: '<S243>/filter_velocities' */
    may23_DW.rawVelocities_k[i] = 0.0;
    may23_DW.filtVelocities_d[i] = 0.0;
  }

  /* SystemInitialize for MATLAB Function: '<S86>/create kinematics' */
  may23_DW.secondaryPosData_not_empty = false;
  may23_DW.secondaryPosData.size[1] = 0;
  may23_DW.secondaryVelData.size[1] = 0;
  may23_DW.primaryPosData.size[1] = 0;
  may23_DW.primaryVelData.size[1] = 0;

  /* SystemInitialize for Chart: '<S30>/control read write' incorporates:
   *  SubSystem: '<S66>/update'
   */
  /* SystemInitialize for MATLAB Function: '<S86>/create servo counter' */
  may23_DW.servoCounter_not_empty = false;

  /* SystemInitialize for Chart: '<S30>/control read write' incorporates:
   *  SubSystem: '<S30>/createKINData'
   */
  may23_createKINData_Init();

  /* SystemInitialize for Enabled SubSystem: '<S69>/Data receive' */
  /* SystemInitialize for Outport: '<S276>/EP calibration btn' */
  may23_B.Constant_k = may23_P.EPcalibrationbtn_Y0;

  /* SystemInitialize for Outport: '<S276>/Status bits' */
  for (i = 0; i < 7; i++) {
    may23_B.Constant1_f[i] = may23_P.Statusbits_Y0[i];
  }

  /* End of SystemInitialize for Outport: '<S276>/Status bits' */

  /* SystemInitialize for Outport: '<S276>/Task control button' */
  may23_B.DataTypeConversion2_h = may23_P.Taskcontrolbutton_Y0;

  /* End of SystemInitialize for SubSystem: '<S69>/Data receive' */
}

/* Enable for atomic system: '<S1>/Poll KINARM' */
void may23_PollKINARM_Enable(void)
{
  /* Enable for Chart: '<S30>/control read write' incorporates:
   *  SubSystem: '<S30>/createKINData'
   */
  may23_createKINData_Enable();
}

/* Start for atomic system: '<S1>/Poll KINARM' */
void may23_PollKINARM_Start(void)
{
  int32_T i;

  /* Start for S-Function (BKINethercatinit): '<S66>/BKIN EtherCATinit1' incorporates:
   *  Constant: '<S66>/PCI Bus Slot'
   *  Constant: '<S66>/activation'
   */
  {
    static const struct ChipsetVendorId {
      uint16_T id;
      const char *descr;
      uint16_T additionalEcatUpdateDelay;
    } IntelChipSets[] = {
      { 0x1C5C, "H61", 0 },

      { 0x1E53, "C216", 0 },

      { 0xA303, "H310", 10 },

      { 0x069A, "H420E", 10 },

      { 0x0000, NULL, 0 }
    };

    const struct ChipsetVendorId *vend;
    int_T status = 1;
    static char_T *errMsg;
    xpcPCIDevice pciInfo;
    int_T j;
    uint8_T *DeviceType;

    /* From LinkOsLayer.h   Intel PRO-100 specific definitions */
    struct EtherCATDevices {
      uint16_T VendorID;
      uint16_T DeviceID;
      uint8_T *DeviceType;
    } EtherCATDeviceTable[] = {
      /* I8254x types */
      { 0x8086, 0xABB1, "I8254x" },    //

      { 0x8086, 0xABB2, "I8254x" },    //

      { 0x8086, 0x100E, "I8254x" },    //  PCI_DEVICE_I82540EM_DESKTOP

      { 0x8086, 0x1010, "I8254x" },    //  PCI_DEVICE_I82546EB_COPPER_DUAL

      { 0x8086, 0x1013, "I8254x" },    //  PCI_DEVICE_I82541EI_COPPER

      { 0x8086, 0x1019, "I8254x" },    //  PCI_DEVICE_I82547GI_COPPER

      { 0x8086, 0x1026, "I8254x" },    //  PCI_DEVICE_I82545GM_COPPER

      { 0x8086, 0x104A, "I8254x" },    //  PCI_DEVICE_I82566DM

      { 0x8086, 0x104D, "I8254x" },    //  PCI_DEVICE_I82566MC

      { 0x8086, 0x105E, "I8254x" },    //  PCI_DEVICE_N1E5132_SERVER

      { 0x8086, 0x1075, "I8254x" },    //  PCI_DEVICE_I82547EI

      { 0x8086, 0x1076, "I8254x" },    //  PCI_DEVICE_I82541GI_COPPER

      { 0x8086, 0x1078, "I8254x" },    //  PCI_DEVICE_I82541ER

      { 0x8086, 0x1079, "I8254x" },    //  PCI_DEVICE_I82546GB_COPPER_DUAL

      { 0x8086, 0x107C, "I8254x" },    //  PCI_DEVICE_I82541PI_DESKTOP

      { 0x8086, 0x107D, "I8254x" },    //  PCI_DEVICE_I82572EI

      { 0x8086, 0x108B, "I8254x" },    //  PCI_DEVICE_I82573E

      { 0x8086, 0x108C, "I8254x" },    //  PCI_DEVICE_I82573

      { 0x8086, 0x109A, "I8254x" },    //  PCI_DEVICE_I82573L

      { 0x8086, 0x10A4, "I8254x" },    //  PCI_DEVICE_I82571GB_QUAD

      { 0x8086, 0x10A7, "I8254x" },    //  PCI_DEVICE_I82575_ZOAR

      { 0x8086, 0x10B9, "I8254x" },    //  PCI_DEVICE_I82572GI

      { 0x8086, 0x10BC, "I8254x" },    //  PCI_DEVICE_I82571GB_QUAD_2

      { 0x8086, 0x10BD, "I8254x" },    //  PCI_DEVICE_I82566L

      { 0x8086, 0x10C9, "I8254x" },    //  PCI_DEVICE_I82576

      { 0x8086, 0x10CE, "I8254x" },    //  PCI_DEVICE_I82567V

      { 0x8086, 0x10D3, "I8254x" },    //  PCI_DEVICE_I82574L

      { 0x8086, 0x10DE, "I8254x" },    //  PCI_DEVICE_I82567LM3

      { 0x8086, 0x10EA, "I8254x" },    //  PCI_DEVICE_I82577LM

      { 0x8086, 0x10EB, "I8254x" },    //  PCI_DEVICE_I82577LC

      { 0x8086, 0x10EF, "I8254x" },    //  PCI_DEVICE_I82578DM

      { 0x8086, 0x10F0, "I8254x" },    //  PCI_DEVICE_I82578DC

      { 0x8086, 0x10F5, "I8254x" },    //  PCI_DEVICE_I82567LM

      { 0x8086, 0x1501, "I8254x" },    //  PCI_DEVICE_I82567V3

      { 0x8086, 0x1502, "I8254x" },    //  PCI_DEVICE_I82579LM

      { 0x8086, 0x1503, "I8254x" },    //  PCI_DEVICE_I82579V

      { 0x8086, 0x150C, "I8254x" },    //  PCI_DEVICE_I82583V

      { 0x8086, 0x150E, "I8254x" },    //  PCI_DEVICE_I82580_QUAD

      { 0x8086, 0x1521, "I8254x" },    //  PCI_DEVICE_I350

      { 0x8086, 0x1526, "I8254x" },    //  PCI_DEVICE_I82576_ET2

      { 0x8086, 0x1527, "I8254x" },    //  PCI_DEVICE_I82580_QUAD_FIBRE

      { 0x8086, 0x1533, "I8254x" },    //  PCI_DEVICE_I210_COPPER

      { 0x8086, 0x1539, "I8254x" },    //  PCI_DEVICE_I211AT

      { 0x8086, 0x157B, "I8254x" },    //  PCI_DEVICE_I210_COPPER_FLASHLESS

      { 0x8086, 0x153A, "I8254x" },    //  PCI_DEVICE_I217LM

      { 0x8086, 0x153B, "I8254x" },    //  PCI_DEVICE_I217V

      { 0x8086, 0x155A, "I8254x" },    //  PCI_DEVICE_I218LM

      { 0x8086, 0x1559, "I8254x" },    //  PCI_DEVICE_I218V

      { 0x8086, 0x15A3, "I8254x" },    //  PCI_DEVICE_I218V_2

      { 0x8086, 0x15B7, "I8254x" },    //  PCI_DEVICE_I219LM

      { 0x8086, 0x1570, "I8254x" },    //  PCI_DEVICE_I219V

      { 0x8086, 0x15BC, "I8254x" },    //  PCI_DEVICE_I219V

      /* I8255x types */
      { 0x8086, 0x103a, "I8255x" },
                       //  PCI device ID, Intel 82801DB(M) (ICH4) LAN Controller

      { 0x8086, 0x1229, "I8255x" },    //  82557 device ID

      { 0x8086, 0x1209, "I8255x" },    //  82557 ER device ID

      { 0x8086, 0x1050, "I8255x" },    //  PRO/100 VE device ID

      { 0x8086, 0x1039, "I8255x" },    //  82562 VE/VM device ID

      { 0x8086, 0x2449, "I8255x" },    //  82559 ER device ID

      { 0x8086, 0x27DC, "I8255x" },    //  PRO/100 VE device ID

      { 0x8086, 0x1059, "I8255x" },    //  Mobile version of 1229

      { 0x8086, 0x1092, "I8255x" }     //  PRO/100 VE3 device ID
    };

    if (!xpcIsModelInit()) {
      if (g_firstInitBlockToRunPlusOne == 0) {
        g_firstInitBlockToRunPlusOne = 1 + 1;
      }

      if (g_firstInitBlockToRunPlusOne == 1 + 1) {
        g_deviceIndex = NO_ETHERCAT;
        static char_T msg[256];
        int32_T NICerror;
        if (NICerror = registerNIC( (may23_P.PCIBusSlot_Value[0]),
             (may23_P.PCIBusSlot_Value[1]), 0, 3 ) ) {
          sprintf( msg, "EtherCAT Init: Ethernet port at [%d,%d,%d] in use by",
                  (may23_P.PCIBusSlot_Value[0]),(may23_P.PCIBusSlot_Value[1]),0 );
          switch ( NICerror )
          {
           case 1:
            sprintf( msg, "%s host-target communication.", msg );
            break;

           case 2:
            sprintf( msg, "%s Real-Time IP.", msg );
            break;

           case 3:
            sprintf( msg, "%s raw Ethernet.", msg );
            break;

           case 4:
            sprintf( msg, "%s EtherCAT.", msg );
            break;
          }

          rtmSetErrorStatus(may23_M, msg);
          return;
        }
      }

      may23_B.BKINEtherCATinit1_o2 = MC_TYPE_SIMULATION;
      may23_B.BKINEtherCATinit1_o3 = MC_TYPE_SIMULATION;

      /*  Initialize the first DWork vector so that by default EtherCAT for this EtherCAT network device is DISABLED */
      may23_DW.BKINEtherCATinit1_DWORK1 = 0;
      if (xpcGetPCIDeviceInfo( PMAC_VENDOR_ID, (uint16_T)PMAC_DEVICE_ID,
                              XPC_NO_SUB, XPC_NO_SUB, XPC_NO_BUS_SLOT,
                              XPC_NO_BUS_SLOT, &pciInfo ) ) {
        if (1 == g_firstInitBlockToRunPlusOne - 1 )
          printf("PMAC not found.\n");
      } else {
        if (1 == g_firstInitBlockToRunPlusOne - 1 )
          printf("PMAC found.\n");
        may23_B.BKINEtherCATinit1_o2 = may23_B.BKINEtherCATinit1_o2 + 1;
                                     // Bit 0 indicates if the PMAC is available
        if ((may23_P.activation_Value[0]) == MC_TYPE_PMAC) {
          may23_B.BKINEtherCATinit1_o3 = MC_TYPE_PMAC;
          printf("PMAC configuration enabled\n");
        }
      }

      status = slrtGetPciConfigAtFunction( (may23_P.PCIBusSlot_Value[0]),
        (may23_P.PCIBusSlot_Value[1]), 0, &pciInfo);
      if (status == -1) {
        rtmSetErrorStatus(may23_M,
                          "You must specify a bus/slot/function, not auto search.");
        return;
      }

      if (status == -2 && ((may23_P.activation_Value[0]) == MC_TYPE_ETHERCAT) )
      {
        printf("There is no Ethernet adapter at bus/slot/function: %d / %d / %d",
               (may23_P.PCIBusSlot_Value[0]), (may23_P.PCIBusSlot_Value[1]), 0);
        rtmSetErrorStatus(may23_M,
                          "There is no Ethernet adapter at the specified bus/slot/function.");
        return;
      }

      status = -1;                     // Preset to a failed search.
      DeviceType = "";
      for (j = 0 ; j < sizeof(EtherCATDeviceTable)/sizeof(struct EtherCATDevices)
           ; j++ ) {
        // Search through the device table for the matching vendor/device ID.
        if (( pciInfo.DeviceId == EtherCATDeviceTable[j].DeviceID )
            && ( pciInfo.VendorId == EtherCATDeviceTable[j].VendorID ) ) {
          status = 0;
          DeviceType = EtherCATDeviceTable[j].DeviceType;
          break;
        }
      }

      if (status ) {
        if (1 == g_firstInitBlockToRunPlusOne - 1 ) {
          printf("No valid EtherCAT NIC found at bus %d slot %d\n",
                 (may23_P.PCIBusSlot_Value[0]), (may23_P.PCIBusSlot_Value[1]));
        }
      } else {
        char *logfile = "c:\\dbglog.txt";
        may23_B.BKINEtherCATinit1_o2 = may23_B.BKINEtherCATinit1_o2 + 2;
                         // // Bit 1 indicates that the valid EtherCAT NIC found
        if (1 == g_firstInitBlockToRunPlusOne - 1) {
          printf("Valid EtherCAT NIC found at bus %d slot %d\n",
                 (may23_P.PCIBusSlot_Value[0]), (may23_P.PCIBusSlot_Value[1]));
          if (((may23_P.activation_Value[1]) >= MAX_NUMBER_ECAT_NETWORK_DEVICES )
              && ((may23_P.activation_Value[0]) == MC_TYPE_ETHERCAT) ) {
            printf("Requested EtherCAT Network device %d is greater then max allowable value of %d\n",
                   (may23_P.activation_Value[1]),
                   MAX_NUMBER_ECAT_NETWORK_DEVICES - 1 );
          }
        }

        if (( (may23_P.activation_Value[1]) == 1 ) &&
            ((may23_P.activation_Value[0]) == MC_TYPE_ETHERCAT) ) {
          may23_DW.BKINEtherCATinit1_RWORK.EXECRATIO = 0.00025 /
            slrteGetCurrentStepSize();
          mwNotifyClear( 1 );
          mwStateClear( 1 );
          status = xpcEtherCATinitialize(1, DeviceType,
            (may23_P.PCIBusSlot_Value[0]), (may23_P.PCIBusSlot_Value[1]), 0, 1,
            xmlecatArr_1, xmlecatArr_1_count,1048576,
            1, logfile, 0.00025, 2, 8 );
          if (status != XPC_ECAT_OK) {
            errMsg = xpcPrintEtherCATError(1, 0);
            rtmSetErrorStatus(may23_M, errMsg);
            return;
          }

          //printf("init status = %08x\n", status );
          may23_DW.BKINEtherCATinit1_DWORK1 = 1;
          // Indicate to the rest of this block that EtherCAT is enabled for THIS block
          may23_B.BKINEtherCATinit1_o3 = MC_TYPE_ETHERCAT;
          // Output that indicates that Motion Control Type of EtherCAT was requested and found (for this device)
          g_deviceIndex = 1;
          // Store the device index into this global variable for the other EtherCAT blocks to access
          printf("EtherCAT Network device %d configured.\n", 1);
        }
      }

      for (vend = IntelChipSets; vend->id > 0; vend++) {
        /* Want bus 0, device 31: LPC Interface Bridge */
        if (xpcGetPCIDeviceInfo(0x8086, vend->id, XPC_NO_SUB, XPC_NO_SUB,
             0, 31, &pciInfo) == 0) {  /* Bus 0, device 31 */
          break;
        }
      }

      /* if a supported chipset is not found, do not add any additional delay */
      if (vend->id == 0) {             /* not found */
        may23_DW.BKINEtherCATinit1_DWORK2 = 0.0;
      } else {
        may23_DW.BKINEtherCATinit1_DWORK2 = (double)
          vend->additionalEcatUpdateDelay * 1e-6;
      }
    }
  }

  /* Start for S-Function (BKINethercatinit): '<S66>/BKIN EtherCATinit' incorporates:
   *  Constant: '<S66>/PCI Bus Slot'
   *  Constant: '<S66>/activation'
   */
  {
    static const struct ChipsetVendorId {
      uint16_T id;
      const char *descr;
      uint16_T additionalEcatUpdateDelay;
    } IntelChipSets[] = {
      { 0x1C5C, "H61", 0 },

      { 0x1E53, "C216", 0 },

      { 0xA303, "H310", 10 },

      { 0x069A, "H420E", 10 },

      { 0x0000, NULL, 0 }
    };

    const struct ChipsetVendorId *vend;
    int_T status = 1;
    static char_T *errMsg;
    xpcPCIDevice pciInfo;
    int_T j;
    uint8_T *DeviceType;

    /* From LinkOsLayer.h   Intel PRO-100 specific definitions */
    struct EtherCATDevices {
      uint16_T VendorID;
      uint16_T DeviceID;
      uint8_T *DeviceType;
    } EtherCATDeviceTable[] = {
      /* I8254x types */
      { 0x8086, 0xABB1, "I8254x" },    //

      { 0x8086, 0xABB2, "I8254x" },    //

      { 0x8086, 0x100E, "I8254x" },    //  PCI_DEVICE_I82540EM_DESKTOP

      { 0x8086, 0x1010, "I8254x" },    //  PCI_DEVICE_I82546EB_COPPER_DUAL

      { 0x8086, 0x1013, "I8254x" },    //  PCI_DEVICE_I82541EI_COPPER

      { 0x8086, 0x1019, "I8254x" },    //  PCI_DEVICE_I82547GI_COPPER

      { 0x8086, 0x1026, "I8254x" },    //  PCI_DEVICE_I82545GM_COPPER

      { 0x8086, 0x104A, "I8254x" },    //  PCI_DEVICE_I82566DM

      { 0x8086, 0x104D, "I8254x" },    //  PCI_DEVICE_I82566MC

      { 0x8086, 0x105E, "I8254x" },    //  PCI_DEVICE_N1E5132_SERVER

      { 0x8086, 0x1075, "I8254x" },    //  PCI_DEVICE_I82547EI

      { 0x8086, 0x1076, "I8254x" },    //  PCI_DEVICE_I82541GI_COPPER

      { 0x8086, 0x1078, "I8254x" },    //  PCI_DEVICE_I82541ER

      { 0x8086, 0x1079, "I8254x" },    //  PCI_DEVICE_I82546GB_COPPER_DUAL

      { 0x8086, 0x107C, "I8254x" },    //  PCI_DEVICE_I82541PI_DESKTOP

      { 0x8086, 0x107D, "I8254x" },    //  PCI_DEVICE_I82572EI

      { 0x8086, 0x108B, "I8254x" },    //  PCI_DEVICE_I82573E

      { 0x8086, 0x108C, "I8254x" },    //  PCI_DEVICE_I82573

      { 0x8086, 0x109A, "I8254x" },    //  PCI_DEVICE_I82573L

      { 0x8086, 0x10A4, "I8254x" },    //  PCI_DEVICE_I82571GB_QUAD

      { 0x8086, 0x10A7, "I8254x" },    //  PCI_DEVICE_I82575_ZOAR

      { 0x8086, 0x10B9, "I8254x" },    //  PCI_DEVICE_I82572GI

      { 0x8086, 0x10BC, "I8254x" },    //  PCI_DEVICE_I82571GB_QUAD_2

      { 0x8086, 0x10BD, "I8254x" },    //  PCI_DEVICE_I82566L

      { 0x8086, 0x10C9, "I8254x" },    //  PCI_DEVICE_I82576

      { 0x8086, 0x10CE, "I8254x" },    //  PCI_DEVICE_I82567V

      { 0x8086, 0x10D3, "I8254x" },    //  PCI_DEVICE_I82574L

      { 0x8086, 0x10DE, "I8254x" },    //  PCI_DEVICE_I82567LM3

      { 0x8086, 0x10EA, "I8254x" },    //  PCI_DEVICE_I82577LM

      { 0x8086, 0x10EB, "I8254x" },    //  PCI_DEVICE_I82577LC

      { 0x8086, 0x10EF, "I8254x" },    //  PCI_DEVICE_I82578DM

      { 0x8086, 0x10F0, "I8254x" },    //  PCI_DEVICE_I82578DC

      { 0x8086, 0x10F5, "I8254x" },    //  PCI_DEVICE_I82567LM

      { 0x8086, 0x1501, "I8254x" },    //  PCI_DEVICE_I82567V3

      { 0x8086, 0x1502, "I8254x" },    //  PCI_DEVICE_I82579LM

      { 0x8086, 0x1503, "I8254x" },    //  PCI_DEVICE_I82579V

      { 0x8086, 0x150C, "I8254x" },    //  PCI_DEVICE_I82583V

      { 0x8086, 0x150E, "I8254x" },    //  PCI_DEVICE_I82580_QUAD

      { 0x8086, 0x1521, "I8254x" },    //  PCI_DEVICE_I350

      { 0x8086, 0x1526, "I8254x" },    //  PCI_DEVICE_I82576_ET2

      { 0x8086, 0x1527, "I8254x" },    //  PCI_DEVICE_I82580_QUAD_FIBRE

      { 0x8086, 0x1533, "I8254x" },    //  PCI_DEVICE_I210_COPPER

      { 0x8086, 0x1539, "I8254x" },    //  PCI_DEVICE_I211AT

      { 0x8086, 0x157B, "I8254x" },    //  PCI_DEVICE_I210_COPPER_FLASHLESS

      { 0x8086, 0x153A, "I8254x" },    //  PCI_DEVICE_I217LM

      { 0x8086, 0x153B, "I8254x" },    //  PCI_DEVICE_I217V

      { 0x8086, 0x155A, "I8254x" },    //  PCI_DEVICE_I218LM

      { 0x8086, 0x1559, "I8254x" },    //  PCI_DEVICE_I218V

      { 0x8086, 0x15A3, "I8254x" },    //  PCI_DEVICE_I218V_2

      { 0x8086, 0x15B7, "I8254x" },    //  PCI_DEVICE_I219LM

      { 0x8086, 0x1570, "I8254x" },    //  PCI_DEVICE_I219V

      { 0x8086, 0x15BC, "I8254x" },    //  PCI_DEVICE_I219V

      /* I8255x types */
      { 0x8086, 0x103a, "I8255x" },
                       //  PCI device ID, Intel 82801DB(M) (ICH4) LAN Controller

      { 0x8086, 0x1229, "I8255x" },    //  82557 device ID

      { 0x8086, 0x1209, "I8255x" },    //  82557 ER device ID

      { 0x8086, 0x1050, "I8255x" },    //  PRO/100 VE device ID

      { 0x8086, 0x1039, "I8255x" },    //  82562 VE/VM device ID

      { 0x8086, 0x2449, "I8255x" },    //  82559 ER device ID

      { 0x8086, 0x27DC, "I8255x" },    //  PRO/100 VE device ID

      { 0x8086, 0x1059, "I8255x" },    //  Mobile version of 1229

      { 0x8086, 0x1092, "I8255x" }     //  PRO/100 VE3 device ID
    };

    if (!xpcIsModelInit()) {
      if (g_firstInitBlockToRunPlusOne == 0) {
        g_firstInitBlockToRunPlusOne = 0 + 1;
      }

      if (g_firstInitBlockToRunPlusOne == 0 + 1) {
        g_deviceIndex = NO_ETHERCAT;
        static char_T msg[256];
        int32_T NICerror;
        if (NICerror = registerNIC( (may23_P.PCIBusSlot_Value[0]),
             (may23_P.PCIBusSlot_Value[1]), 0, 3 ) ) {
          sprintf( msg, "EtherCAT Init: Ethernet port at [%d,%d,%d] in use by",
                  (may23_P.PCIBusSlot_Value[0]),(may23_P.PCIBusSlot_Value[1]),0 );
          switch ( NICerror )
          {
           case 1:
            sprintf( msg, "%s host-target communication.", msg );
            break;

           case 2:
            sprintf( msg, "%s Real-Time IP.", msg );
            break;

           case 3:
            sprintf( msg, "%s raw Ethernet.", msg );
            break;

           case 4:
            sprintf( msg, "%s EtherCAT.", msg );
            break;
          }

          rtmSetErrorStatus(may23_M, msg);
          return;
        }
      }

      may23_B.BKINEtherCATinit_o2 = MC_TYPE_SIMULATION;
      may23_B.BKINEtherCATinit_o3 = MC_TYPE_SIMULATION;

      /*  Initialize the first DWork vector so that by default EtherCAT for this EtherCAT network device is DISABLED */
      may23_DW.BKINEtherCATinit_DWORK1 = 0;
      if (xpcGetPCIDeviceInfo( PMAC_VENDOR_ID, (uint16_T)PMAC_DEVICE_ID,
                              XPC_NO_SUB, XPC_NO_SUB, XPC_NO_BUS_SLOT,
                              XPC_NO_BUS_SLOT, &pciInfo ) ) {
        if (0 == g_firstInitBlockToRunPlusOne - 1 )
          printf("PMAC not found.\n");
      } else {
        if (0 == g_firstInitBlockToRunPlusOne - 1 )
          printf("PMAC found.\n");
        may23_B.BKINEtherCATinit_o2 = may23_B.BKINEtherCATinit_o2 + 1;
                                     // Bit 0 indicates if the PMAC is available
        if ((may23_P.activation_Value[0]) == MC_TYPE_PMAC) {
          may23_B.BKINEtherCATinit_o3 = MC_TYPE_PMAC;
          printf("PMAC configuration enabled\n");
        }
      }

      status = slrtGetPciConfigAtFunction( (may23_P.PCIBusSlot_Value[0]),
        (may23_P.PCIBusSlot_Value[1]), 0, &pciInfo);
      if (status == -1) {
        rtmSetErrorStatus(may23_M,
                          "You must specify a bus/slot/function, not auto search.");
        return;
      }

      if (status == -2 && ((may23_P.activation_Value[0]) == MC_TYPE_ETHERCAT) )
      {
        printf("There is no Ethernet adapter at bus/slot/function: %d / %d / %d",
               (may23_P.PCIBusSlot_Value[0]), (may23_P.PCIBusSlot_Value[1]), 0);
        rtmSetErrorStatus(may23_M,
                          "There is no Ethernet adapter at the specified bus/slot/function.");
        return;
      }

      status = -1;                     // Preset to a failed search.
      DeviceType = "";
      for (j = 0 ; j < sizeof(EtherCATDeviceTable)/sizeof(struct EtherCATDevices)
           ; j++ ) {
        // Search through the device table for the matching vendor/device ID.
        if (( pciInfo.DeviceId == EtherCATDeviceTable[j].DeviceID )
            && ( pciInfo.VendorId == EtherCATDeviceTable[j].VendorID ) ) {
          status = 0;
          DeviceType = EtherCATDeviceTable[j].DeviceType;
          break;
        }
      }

      if (status ) {
        if (0 == g_firstInitBlockToRunPlusOne - 1 ) {
          printf("No valid EtherCAT NIC found at bus %d slot %d\n",
                 (may23_P.PCIBusSlot_Value[0]), (may23_P.PCIBusSlot_Value[1]));
        }
      } else {
        char *logfile = "c:\\dbglog.txt";
        may23_B.BKINEtherCATinit_o2 = may23_B.BKINEtherCATinit_o2 + 2;
                         // // Bit 1 indicates that the valid EtherCAT NIC found
        if (0 == g_firstInitBlockToRunPlusOne - 1) {
          printf("Valid EtherCAT NIC found at bus %d slot %d\n",
                 (may23_P.PCIBusSlot_Value[0]), (may23_P.PCIBusSlot_Value[1]));
          if (((may23_P.activation_Value[1]) >= MAX_NUMBER_ECAT_NETWORK_DEVICES )
              && ((may23_P.activation_Value[0]) == MC_TYPE_ETHERCAT) ) {
            printf("Requested EtherCAT Network device %d is greater then max allowable value of %d\n",
                   (may23_P.activation_Value[1]),
                   MAX_NUMBER_ECAT_NETWORK_DEVICES - 1 );
          }
        }

        if (( (may23_P.activation_Value[1]) == 0 ) &&
            ((may23_P.activation_Value[0]) == MC_TYPE_ETHERCAT) ) {
          may23_DW.BKINEtherCATinit_RWORK.EXECRATIO = 0.00025 /
            slrteGetCurrentStepSize();
          mwNotifyClear( 0 );
          mwStateClear( 0 );
          status = xpcEtherCATinitialize(0, DeviceType,
            (may23_P.PCIBusSlot_Value[0]), (may23_P.PCIBusSlot_Value[1]), 0, 1,
            xmlecatArr_0, xmlecatArr_0_count,1048576,
            1, logfile, 0.00025, 2, 8 );
          if (status != XPC_ECAT_OK) {
            errMsg = xpcPrintEtherCATError(0, 0);
            rtmSetErrorStatus(may23_M, errMsg);
            return;
          }

          //printf("init status = %08x\n", status );
          may23_DW.BKINEtherCATinit_DWORK1 = 1;
          // Indicate to the rest of this block that EtherCAT is enabled for THIS block
          may23_B.BKINEtherCATinit_o3 = MC_TYPE_ETHERCAT;
          // Output that indicates that Motion Control Type of EtherCAT was requested and found (for this device)
          g_deviceIndex = 0;
          // Store the device index into this global variable for the other EtherCAT blocks to access
          printf("EtherCAT Network device %d configured.\n", 0);
        }
      }

      for (vend = IntelChipSets; vend->id > 0; vend++) {
        /* Want bus 0, device 31: LPC Interface Bridge */
        if (xpcGetPCIDeviceInfo(0x8086, vend->id, XPC_NO_SUB, XPC_NO_SUB,
             0, 31, &pciInfo) == 0) {  /* Bus 0, device 31 */
          break;
        }
      }

      /* if a supported chipset is not found, do not add any additional delay */
      if (vend->id == 0) {             /* not found */
        may23_DW.BKINEtherCATinit_DWORK2 = 0.0;
      } else {
        may23_DW.BKINEtherCATinit_DWORK2 = (double)
          vend->additionalEcatUpdateDelay * 1e-6;
      }
    }
  }

  /* Start for Constant: '<S66>/max errors to fault' */
  may23_B.max_errors_to_fault = may23_P.maxerrorstofault_Value;

  /* Start for Constant: '<S30>/system type' */
  may23_B.systemtype = may23_P.systemtype_Value;

  /* Start for Enabled SubSystem: '<S66>/Arm 1' */
  may23_DW.Arm1_MODE = false;

  /* Start for S-Function (BKINethercatpdorxElmoDrive): '<S102>/BKIN PDO Receive ElmoDrive' */
  /* Level2 S-Function Block: '<S102>/BKIN PDO Receive ElmoDrive' (BKINethercatpdorxElmoDrive) */
  {
    SimStruct *rts = may23_M->childSfunctions[7];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (BKINethercatpdotx): '<S87>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S87>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[8];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for Constant: '<S77>/readTrigger' */
  may23_B.readTrigger_l = may23_P.readTrigger_Value;

  /* Start for Atomic SubSystem: '<S87>/EMCY Message pump' */
  may23_EMCYMessagepump_Start();

  /* End of Start for SubSystem: '<S87>/EMCY Message pump' */

  /* Start for S-Function (BKINethercatpdorxElmoDrive): '<S122>/BKIN PDO Receive ElmoDrive' */
  /* Level2 S-Function Block: '<S122>/BKIN PDO Receive ElmoDrive' (BKINethercatpdorxElmoDrive) */
  {
    SimStruct *rts = may23_M->childSfunctions[9];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (BKINethercatpdotx): '<S88>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S88>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[10];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for Atomic SubSystem: '<S88>/EMCY Message pump' */
  may23_EMCYMessagepump_k_Start();

  /* End of Start for SubSystem: '<S88>/EMCY Message pump' */
  /* Start for Enabled SubSystem: '<S77>/M1 AbsEnc Calibration' */
  may23_DW.M1AbsEncCalibration_MODE_c = false;

  /* Start for Enabled SubSystem: '<S77>/M2 AbsEnc Calibration' */
  may23_DW.M2AbsEncCalibration_MODE_p = false;

  /* Start for S-Function (BKINethercatpdotx): '<S89>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S89>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[11];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (BKINethercatpdotx): '<S89>/BKIN EtherCAT PDO Transmit 1' */
  /* Level2 S-Function Block: '<S89>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[12];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for Atomic SubSystem: '<S77>/SDO reading' */
  may23_SDOreading_Start();

  /* End of Start for SubSystem: '<S77>/SDO reading' */

  /* Start for Atomic SubSystem: '<S77>/SDO writing' */
  may23_SDOwriting_Start();

  /* End of Start for SubSystem: '<S77>/SDO writing' */
  /* End of Start for SubSystem: '<S66>/Arm 1' */

  /* Start for Enabled SubSystem: '<S66>/Arm 2' */
  may23_DW.Arm2_MODE = false;

  /* Start for S-Function (BKINethercatpdorxElmoDrive): '<S177>/BKIN PDO Receive ElmoDrive' */
  /* Level2 S-Function Block: '<S177>/BKIN PDO Receive ElmoDrive' (BKINethercatpdorxElmoDrive) */
  {
    SimStruct *rts = may23_M->childSfunctions[13];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (BKINethercatpdotx): '<S162>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S162>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[14];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for Constant: '<S78>/readTrigger' */
  may23_B.readTrigger = may23_P.readTrigger_Value_a;

  /* Start for Atomic SubSystem: '<S162>/EMCY Message pump' */
  may23_EMCYMessagepump_h_Start();

  /* End of Start for SubSystem: '<S162>/EMCY Message pump' */

  /* Start for S-Function (BKINethercatpdorxElmoDrive): '<S197>/BKIN PDO Receive ElmoDrive' */
  /* Level2 S-Function Block: '<S197>/BKIN PDO Receive ElmoDrive' (BKINethercatpdorxElmoDrive) */
  {
    SimStruct *rts = may23_M->childSfunctions[15];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (BKINethercatpdotx): '<S163>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S163>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[16];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for Atomic SubSystem: '<S163>/EMCY Message pump' */
  may23_EMCYMessagepump_o_Start();

  /* End of Start for SubSystem: '<S163>/EMCY Message pump' */
  /* Start for Enabled SubSystem: '<S78>/M1 AbsEnc Calibration' */
  may23_DW.M1AbsEncCalibration_MODE = false;

  /* Start for Enabled SubSystem: '<S78>/M2 AbsEnc Calibration' */
  may23_DW.M2AbsEncCalibration_MODE = false;

  /* Start for Atomic SubSystem: '<S78>/SDO reading' */
  may23_SDOreading_b_Start();

  /* End of Start for SubSystem: '<S78>/SDO reading' */

  /* Start for Atomic SubSystem: '<S78>/SDO writing' */
  may23_SDOwriting_j_Start();

  /* End of Start for SubSystem: '<S78>/SDO writing' */

  /* Start for S-Function (BKINethercatpdotx): '<S170>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S170>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[17];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (BKINethercatpdotx): '<S170>/BKIN EtherCAT PDO Transmit 1' */
  /* Level2 S-Function Block: '<S170>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[18];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of Start for SubSystem: '<S66>/Arm 2' */

  /* Start for S-Function (BKINethercatpdotx): '<S81>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S81>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[29];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (BKINethercatpdotx): '<S81>/BKIN EtherCAT PDO Transmit 1' */
  /* Level2 S-Function Block: '<S81>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[30];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (BKINethercatpdotx): '<S81>/BKIN EtherCAT PDO Transmit 2' */
  /* Level2 S-Function Block: '<S81>/BKIN EtherCAT PDO Transmit 2' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[31];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for S-Function (BKINethercatpdotx): '<S81>/BKIN EtherCAT PDO Transmit 3' */
  /* Level2 S-Function Block: '<S81>/BKIN EtherCAT PDO Transmit 3' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[32];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* Start for Atomic SubSystem: '<S30>/Force Sensor Control' */
  may23_ForceSensorControl_Start();

  /* End of Start for SubSystem: '<S30>/Force Sensor Control' */

  /* Start for Enabled SubSystem: '<S70>/Data receive' */
  /* Start for S-Function (slrtUDPReceive): '<S283>/Receive' */
  /* Level2 S-Function Block: '<S283>/Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[28];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of Start for SubSystem: '<S70>/Data receive' */

  /* Start for Constant: '<S290>/Arm Orientation' */
  may23_B.ArmOrientation_f = may23_P.ArmOrientation_Value;

  /* Start for Constant: '<S290>/Arm Secondary Encoders' */
  may23_B.HasSecondaryEnc_n = may23_P.ArmSecondaryEncoders_Value;

  /* Start for Constant: '<S291>/Arm Orientation' */
  may23_B.ArmOrientation_m = may23_P.ArmOrientation_Value_g;

  /* Start for Constant: '<S291>/Arm Secondary Encoders' */
  may23_B.HasSecondaryEnc_c = may23_P.ArmSecondaryEncoders_Value_f;

  /* Start for Enabled SubSystem: '<S68>/read_pmac' */
  may23_read_pmac_Start();

  /* End of Start for SubSystem: '<S68>/read_pmac' */

  /* Start for RateTransition generated from: '<S69>/Data write' */
  for (i = 0; i < 20; i++) {
    may23_B.TmpRTBAtDatawriteInport2[i] =
      may23_P.TmpRTBAtDatawriteInport2_InitialCondition;
  }

  /* End of Start for RateTransition generated from: '<S69>/Data write' */

  /* Start for RateTransition generated from: '<S69>/Data write' */
  for (i = 0; i < 12; i++) {
    may23_B.TmpRTBAtDatawriteInport3[i] =
      may23_P.TmpRTBAtDatawriteInport3_InitialCondition;
  }

  /* End of Start for RateTransition generated from: '<S69>/Data write' */

  /* Start for RateTransition generated from: '<S69>/Data write' */
  may23_B.TmpRTBAtDatawriteInport4 =
    may23_P.TmpRTBAtDatawriteInport4_InitialCondition;

  /* Start for RateTransition generated from: '<S69>/Data write' */
  for (i = 0; i < 7; i++) {
    may23_B.TmpRTBAtDatawriteInport5[i] =
      may23_P.TmpRTBAtDatawriteInport5_InitialCondition;
  }

  /* End of Start for RateTransition generated from: '<S69>/Data write' */

  /* Start for Chart: '<S30>/control read write' incorporates:
   *  SubSystem: '<S30>/createKINData'
   */
  may23_createKINData_Start();

  /* Start for Constant: '<S290>/Arm robot type' */
  may23_B.robottype_a = may23_P.Armrobottype_Value;

  /* Start for Constant: '<S290>/Arm robot version' */
  may23_B.robotversion_h = may23_P.Armrobotversion_Value;

  /* Start for Constant: '<S291>/Arm robot type' */
  may23_B.robottype_j = may23_P.Armrobottype_Value_k;

  /* Start for Constant: '<S291>/Arm robot version' */
  may23_B.robotversion_f = may23_P.Armrobotversion_Value_e;

  /* Start for DataStoreMemory: '<S30>/ECAT Digital in' */
  for (i = 0; i < 8; i++) {
    may23_DW.ECATDigitalInput[i] = may23_P.ECATDigitalin_InitialValue[i];
  }

  /* End of Start for DataStoreMemory: '<S30>/ECAT Digital in' */

  /* Start for DataStoreMemory: '<S30>/ECAT Err Msgs' */
  memcpy(&may23_DW.ECATErrMsgs[0], &may23_P.ECATErrMsgs_InitialValue[0], 20U *
         sizeof(real_T));

  /* Start for DataStoreMemory: '<S30>/ECATTorque feedback' */
  memcpy(&may23_DW.ECATExtraData[0], &may23_P.ECATTorquefeedback_InitialValue[0],
         10U * sizeof(real_T));

  /* Start for DataStoreMemory: '<S30>/HW Settings' */
  memcpy(&may23_DW.HardwareSettings[0], &may23_P.HWSettings_InitialValue[0], 25U
         * sizeof(real_T));

  /* Start for DataStoreMemory: '<S30>/Kinematics' */
  memcpy(&may23_DW.Kinematics[0], &may23_P.Kinematics_InitialValue[0], 20U *
         sizeof(real_T));

  /* Start for DataStoreMemory: '<S30>/PrimaryEnc' */
  memcpy(&may23_DW.PrimaryEncoderData[0], &may23_P.PrimaryEnc_InitialValue[0],
         12U * sizeof(real_T));

  /* Start for DataStoreMemory: '<S30>/Robot Calib' */
  memcpy(&may23_DW.RobotCalibrations[0], &may23_P.RobotCalib_InitialValue[0],
         sizeof(real_T) << 4U);

  /* Start for DataStoreMemory: '<S30>/RobotRevision' */
  may23_DW.RobotRevision[0] = may23_P.RobotRevision_InitialValue[0];
  may23_DW.RobotRevision[1] = may23_P.RobotRevision_InitialValue[1];

  /* Start for DataStoreMemory: '<S30>/ServoUpdate' */
  may23_DW.ServoUpdate = may23_P.ServoUpdate_InitialValue;

  /* Start for DataStoreMemory: '<S30>/System status' */
  for (i = 0; i < 7; i++) {
    may23_DW.SystemStatus[i] = may23_P.Systemstatus_InitialValue[i];
  }

  /* End of Start for DataStoreMemory: '<S30>/System status' */

  /* Start for DataStoreMemory: '<S30>/calib button' */
  may23_DW.CalibrationButton = may23_P.calibbutton_InitialValue;

  /* Start for DataStoreMemory: '<S30>/delays' */
  may23_DW.DelayEstimates[0] = may23_P.delays_InitialValue[0];
  may23_DW.DelayEstimates[1] = may23_P.delays_InitialValue[1];
  may23_DW.DelayEstimates[2] = may23_P.delays_InitialValue[2];
  may23_DW.DelayEstimates[3] = may23_P.delays_InitialValue[3];

  /* Start for DataStoreMemory: '<S30>/has FT sensors' */
  may23_DW.ArmForceSensors[0] = may23_P.hasFTsensors_InitialValue[0];
  may23_DW.ArmForceSensors[1] = may23_P.hasFTsensors_InitialValue[1];
  may23_DW.ArmForceSensors[2] = may23_P.hasFTsensors_InitialValue[2];

  /* Start for Enabled SubSystem: '<S69>/Data receive' */
  /* Start for S-Function (kinarmfromfile): '<S276>/S-Function' */
  /* Level2 S-Function Block: '<S276>/S-Function' (kinarmfromfile) */
  {
    SimStruct *rts = may23_M->childSfunctions[27];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of Start for SubSystem: '<S69>/Data receive' */
}

/* Outputs for atomic system: '<S1>/Poll KINARM' */
void may23_PollKINARMTID0(void)
{
  int32_T status[8];
  real_T y;
  int32_T robotOrientation;
  int32_T orientation;
  int32_T b_orientation;
  int32_T c_orientation;
  int32_T d_orientation;
  real_T torque;
  real_T ticksPerRad;
  real_T r1Calibs[8];
  real_T r2Calibs[8];
  real_T r1SettingsOut[12];
  real_T r2SettingsOut[12];
  real_T queueSizePrimary;
  real_T secondaryShoElb[4];
  real_T primaryShoElb[4];
  real_T r1SecondaryKinematicsOut[10];
  real_T r2SecondaryKinematicsOut[10];
  real_T secondaryPosData_data[400];
  real_T secondaryVelData_data[400];
  real_T r1PrimaryKinematicsOut[10];
  real_T r2PrimaryKinematicsOut[10];
  real_T b[3];
  int32_T i;
  int32_T secondaryPosData_size[2];
  int32_T secondaryVelData_size[2];
  uint32_T q0;
  uint32_T qY;
  uint64_T tmp;
  static const int16_T tmp_0[24] = { 12032, 12032, 12032, 12032, 12032, 12032,
    12032, 12961, 12961, 12961, 12961, 12961, 1, 2, 3, 4, 5, 6, 7, 1, 2, 3, 4, 5
  };

  static const int16_T tmp_1[24] = { 12033, 12033, 12033, 12033, 12033, 12033,
    12033, 12033, 12033, 12033, 12033, 12033, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11,
    12 };

  boolean_T guard1 = false;
  boolean_T exitg1;

  {
    /* user code (Output function Header for TID0) */
    {
      int32_T data[6]= { 0 };

      int32_T ecatStatus;
      int32_T minPauseBeforeReadMicroSec = ECAT_MIN_PAUSE_BEFORE_READ_US;
      int32_T DCInitState;
      if (may23_DW.BKINEtherCATinit1_DWORK1) {
        /*------------ S-Function Block: <S66>/BKIN EtherCATinit1 Write Process Data ,Run Admin Tasks and then Write Acyclic Data------------*/
        xpcEtherCATWriteProcessData(1,NULL);
        xpcEtherCATExecAdminJobs(1);
        xpcEtherCATWriteAcyclicData(1);
        mwErrorGet((int_T)1,
                   &data[0], &data[1], &data[2], &data[3],&data[4],&data[5]);
        memcpy(&may23_B.BKINEtherCATinit1_o1[0], data,6*sizeof(int32_T));
        mwErrorClear( (int_T)1 );

        // Clear all momentary triggered values
        may23_DW.BKINEtherCATinit1_DWORK4 = xpcGetElapsedTime(NULL);
        ecatStatus = data[1];
        DCInitState = data[4];
        if (ecatStatus == ECAT_PREOP_STATE && DCInitState == 0) {
          may23_DW.BKINEtherCATinit1_DWORK3 = true;
        } else {
          may23_DW.BKINEtherCATinit1_DWORK3 = false;
        }

        if ((may23_P.activation_Value[0]) == ECAT_OP_PAUSE_TEST && ecatStatus ==
            ECAT_OP_STATE) {
          minPauseBeforeReadMicroSec = may23_P.activation_Value[1];
        }

        if (!may23_DW.BKINEtherCATinit1_DWORK3) {
          xpcBusyWait(minPauseBeforeReadMicroSec * 1e-6 +
                      may23_DW.BKINEtherCATinit1_DWORK2);
          xpcEtherCATReadProcessData(1,NULL);
        }

        uint32_T i;
        uint32_T Nfound;
        uint32_T values[MAX_SAVED_NOTIFY];
        int32_T valueSig[MAX_SAVED_NOTIFY + 1];
        int32_T firstNotificationVal;
        mwNotifyRead( 1, &Nfound, values );
        valueSig[0] = (int32_T)Nfound;
        for (i = 0 ; i < Nfound ; i++ )
          valueSig[i+1] = (int32_T)values[i];
        for (i = Nfound + 1; i < MAX_SAVED_NOTIFY + 1 ; i++ )
          valueSig[i] = (int32_T)0;
        memcpy(&may23_B.BKINEtherCATinit1_o4[0], valueSig, (MAX_SAVED_NOTIFY + 1)
               * sizeof(int32_T));
        if (Nfound == 0)
          firstNotificationVal = 0;
        else
          firstNotificationVal = (int32_T)values[0];
        memcpy(&may23_B.BKINEtherCATinit1_o1[0], &firstNotificationVal, sizeof
               (int32_T));
        mwNotifyClear( 1 );
      }
    }

    {
      int32_T data[6]= { 0 };

      int32_T ecatStatus;
      int32_T minPauseBeforeReadMicroSec = ECAT_MIN_PAUSE_BEFORE_READ_US;
      int32_T DCInitState;
      if (may23_DW.BKINEtherCATinit_DWORK1) {
        /*------------ S-Function Block: <S66>/BKIN EtherCATinit Write Process Data ,Run Admin Tasks and then Write Acyclic Data------------*/
        xpcEtherCATWriteProcessData(0,NULL);
        xpcEtherCATExecAdminJobs(0);
        xpcEtherCATWriteAcyclicData(0);
        mwErrorGet((int_T)0,
                   &data[0], &data[1], &data[2], &data[3],&data[4],&data[5]);
        memcpy(&may23_B.BKINEtherCATinit_o1[0], data,6*sizeof(int32_T));
        mwErrorClear( (int_T)0 );

        // Clear all momentary triggered values
        may23_DW.BKINEtherCATinit_DWORK4 = xpcGetElapsedTime(NULL);
        ecatStatus = data[1];
        DCInitState = data[4];
        if (ecatStatus == ECAT_PREOP_STATE && DCInitState == 0) {
          may23_DW.BKINEtherCATinit_DWORK3 = true;
        } else {
          may23_DW.BKINEtherCATinit_DWORK3 = false;
        }

        if ((may23_P.activation_Value[0]) == ECAT_OP_PAUSE_TEST && ecatStatus ==
            ECAT_OP_STATE) {
          minPauseBeforeReadMicroSec = may23_P.activation_Value[1];
        }

        if (!may23_DW.BKINEtherCATinit_DWORK3) {
          xpcBusyWait(minPauseBeforeReadMicroSec * 1e-6 +
                      may23_DW.BKINEtherCATinit_DWORK2);
          xpcEtherCATReadProcessData(0,NULL);
        }

        uint32_T i;
        uint32_T Nfound;
        uint32_T values[MAX_SAVED_NOTIFY];
        int32_T valueSig[MAX_SAVED_NOTIFY + 1];
        int32_T firstNotificationVal;
        mwNotifyRead( 0, &Nfound, values );
        valueSig[0] = (int32_T)Nfound;
        for (i = 0 ; i < Nfound ; i++ )
          valueSig[i+1] = (int32_T)values[i];
        for (i = Nfound + 1; i < MAX_SAVED_NOTIFY + 1 ; i++ )
          valueSig[i] = (int32_T)0;
        memcpy(&may23_B.BKINEtherCATinit_o4[0], valueSig, (MAX_SAVED_NOTIFY + 1)
               * sizeof(int32_T));
        if (Nfound == 0)
          firstNotificationVal = 0;
        else
          firstNotificationVal = (int32_T)values[0];
        memcpy(&may23_B.BKINEtherCATinit_o1[0], &firstNotificationVal, sizeof
               (int32_T));
        mwNotifyClear( 0 );
      }
    }

    /* MATLAB Function: '<S66>/sdo_addrs' */
    for (i = 0; i < 24; i++) {
      may23_B.intAddresses[i] = tmp_0[i];
    }

    for (i = 0; i < 24; i++) {
      may23_B.floatAddresses[i] = tmp_1[i];
    }

    /* End of MATLAB Function: '<S66>/sdo_addrs' */

    /* DataTypeConversion: '<S66>/Data Type Conversion' */
    /* MATLAB Function 'EtherCAT Subsystem/sdo_addrs': '<S84>:1' */
    /* '<S84>:1:3' */
    /* '<S84>:1:19' */
    may23_B.DataTypeConversion_pn = may23_B.Convert20;

    /* Switch: '<S66>/Switch' incorporates:
     *  Constant: '<S66>/activation'
     */
    for (i = 0; i < 6; i++) {
      if (may23_P.activation_Value[1] >= may23_P.Switch_Threshold_bk) {
        may23_B.Switch_f[i] = may23_B.BKINEtherCATinit1_o1[i];
      } else {
        may23_B.Switch_f[i] = may23_B.BKINEtherCATinit_o1[i];
      }
    }

    if (may23_P.activation_Value[1] >= may23_P.Switch_Threshold_bk) {
      may23_B.Switch_f[6] = may23_B.BKINEtherCATinit1_o2;
      may23_B.Switch_f[7] = may23_B.BKINEtherCATinit1_o3;
    } else {
      may23_B.Switch_f[6] = may23_B.BKINEtherCATinit_o2;
      may23_B.Switch_f[7] = may23_B.BKINEtherCATinit_o3;
    }

    /* End of Switch: '<S66>/Switch' */

    /* MATLAB Function: '<S82>/split init' */
    /* MATLAB Function 'EtherCAT Subsystem/Init to Bus/split init': '<S240>:1' */
    /* '<S240>:1:4' */
    may23_B.errVal = may23_B.Switch_f[0];

    /* '<S240>:1:5' */
    may23_B.masterState = may23_B.Switch_f[1];

    /* '<S240>:1:6' */
    may23_B.DCErrVal = may23_B.Switch_f[2];

    /* '<S240>:1:7' */
    may23_B.MasterToNetworkClkDiff = may23_B.Switch_f[3];

    /* '<S240>:1:8' */
    may23_B.DCInitState = may23_B.Switch_f[4];

    /* '<S240>:1:9' */
    may23_B.NetworkToSlaveClkDiff = may23_B.Switch_f[5];

    /* Chart: '<S82>/master_state' */
    /* Gateway: EtherCAT Subsystem/Init to Bus/master_state */
    may23_DW.sfEvent_p = -1;

    /* During: EtherCAT Subsystem/Init to Bus/master_state */
    if (may23_DW.is_active_c10_ethercat == 0U) {
      /* Entry: EtherCAT Subsystem/Init to Bus/master_state */
      may23_DW.is_active_c10_ethercat = 1U;

      /* Entry Internal: EtherCAT Subsystem/Init to Bus/master_state */
      /* Transition: '<S239>:231' */
      if (may23_B.masterState == 8) {
        /* Transition: '<S239>:228' */
        may23_DW.is_c10_ethercat = may23_IN_Wait_f;

        /* Entry 'Wait': '<S239>:227' */
        may23_B.MasterStateOut = 0;
      } else {
        /* Transition: '<S239>:230' */
        may23_DW.is_c10_ethercat = may23_IN_setup_em;

        /* Entry 'setup': '<S239>:139' */
        may23_B.MasterStateOut = may23_B.masterState;
      }
    } else if (may23_DW.is_c10_ethercat == may23_IN_Wait_f) {
      /* During 'Wait': '<S239>:227' */
      if (may23_B.masterState != 8) {
        /* Transition: '<S239>:232' */
        may23_DW.is_c10_ethercat = may23_IN_setup_em;

        /* Entry 'setup': '<S239>:139' */
        may23_B.MasterStateOut = may23_B.masterState;
      }
    } else {
      /* During 'setup': '<S239>:139' */
      may23_B.MasterStateOut = may23_B.masterState;
    }

    /* End of Chart: '<S82>/master_state' */

    /* MATLAB Function: '<S66>/setState' */
    /* MATLAB Function 'EtherCAT Subsystem/setState': '<S85>:1' */
    /* '<S85>:1:3' */
    /* '<S85>:1:5' */
    /* '<S85>:1:8' */
    may23_B.motorEnableState = true;
    if ((may23_B.MasterStateOut == 8) && ((may23_B.errVal == 65537) ||
         (may23_B.errVal == 65551))) {
      /* '<S85>:1:10' */
      /* '<S85>:1:11' */
      /* '<S85>:1:12' */
      may23_B.motorEnableState = false;
    }

    /* End of MATLAB Function: '<S66>/setState' */

    /* Constant: '<S66>/max errors to fault' */
    may23_B.max_errors_to_fault = may23_P.maxerrorstofault_Value;

    /* Constant: '<S30>/system type' */
    may23_B.systemtype = may23_P.systemtype_Value;

    /* RelationalOperator: '<S74>/Compare' incorporates:
     *  Constant: '<S74>/Constant'
     */
    may23_B.Compare_ny = (may23_B.systemtype == may23_P.isecat_const);

    /* Outputs for Enabled SubSystem: '<S66>/Arm 1' incorporates:
     *  EnablePort: '<S77>/Enable'
     */
    if (may23_B.Compare_ny) {
      may23_DW.Arm1_MODE = true;

      /* S-Function (BKINethercatpdorxElmoDrive): '<S102>/BKIN PDO Receive ElmoDrive' */

      /* Level2 S-Function Block: '<S102>/BKIN PDO Receive ElmoDrive' (BKINethercatpdorxElmoDrive) */
      {
        SimStruct *rts = may23_M->childSfunctions[7];
        sfcnOutputs(rts,1);
      }

      /* Switch: '<S109>/Switch' incorporates:
       *  Constant: '<S109>/Constant'
       */
      if (may23_B.MasterStateOut >= may23_P.Switch_Threshold_p) {
        may23_B.Switch_mm = may23_B.Statusword_d;
      } else {
        may23_B.Switch_mm = may23_P.Constant_Value_f;
      }

      /* End of Switch: '<S109>/Switch' */

      /* MATLAB Function: '<S87>/cleanword' */
      may23_cleanword(may23_B.Switch_mm, &may23_B.sf_cleanword);

      /* Switch: '<S108>/Switch' incorporates:
       *  Constant: '<S108>/Constant'
       */
      if (may23_B.MasterStateOut >= may23_P.Switch_Threshold_h2) {
        may23_B.Switch_d = may23_B.statusregister_n;
      } else {
        may23_B.Switch_d = may23_P.Constant_Value_pb;
      }

      /* End of Switch: '<S108>/Switch' */

      /* MATLAB Function: '<S102>/parse status register' */
      may23_parsestatusregister(may23_B.Switch_d,
        &may23_B.sf_parsestatusregister);

      /* RelationalOperator: '<S103>/Compare' incorporates:
       *  Constant: '<S103>/Constant'
       */
      may23_B.Compare_jc = (may23_B.MasterStateOut == may23_P.Compare_const);

      /* Memory: '<S87>/Memory' */
      may23_B.Memory_p = may23_DW.Memory_PreviousInput_k;

      /* Memory: '<S88>/Memory' */
      may23_B.Memory_jp = may23_DW.Memory_PreviousInput_d;

      /* SignalConversion generated from: '<S96>/ SFunction ' incorporates:
       *  MATLAB Function: '<S77>/forceEnableDisable'
       */
      may23_B.TmpSignalConversionAtSFunctionInport6_k[0] = may23_B.Memory_p;
      may23_B.TmpSignalConversionAtSFunctionInport6_k[1] = may23_B.Memory_jp;

      /* MATLAB Function: '<S77>/forceEnableDisable' incorporates:
       *  Constant: '<S77>/enableMotors'
       */
      /* MATLAB Function 'EtherCAT Subsystem/Arm 1/forceEnableDisable': '<S96>:1' */
      /* '<S96>:1:10' */
      may23_B.forceMotorState_o = 0.0;
      guard1 = false;
      if (may23_B.TmpSignalConversionAtSFunctionInport6_k[0] +
          may23_B.TmpSignalConversionAtSFunctionInport6_k[1] != 0.0) {
        /* '<S96>:1:13' */
        /* '<S96>:1:14' */
        may23_DW.faultResetCycles_i++;
        if (may23_DW.faultResetCycles_i > may23_B.max_errors_to_fault) {
          /* '<S96>:1:18' */
        } else {
          guard1 = true;
        }
      } else {
        guard1 = true;
      }

      if (guard1) {
        if ((!(may23_P.enableMotors_Value == 0.0)) && may23_B.motorEnableState &&
            (!(may23_B.Memory2 != 0.0))) {
          if ((may23_B.DataTypeConversion_pn == 2.0) ||
              (may23_B.DataTypeConversion_pn == 4.0)) {
            /* '<S96>:1:32' */
            /* '<S96>:1:35' */
            may23_B.forceMotorState_o = 1.0;

            /* '<S96>:1:36' */
            may23_DW.lastRunningState_o = 1.0;
          } else {
            if (may23_DW.lastRunningState_o == 1.0) {
              /* '<S96>:1:40' */
              y = may23_B.Memory_d[0];
              y += may23_B.Memory_d[1];
              y += may23_B.Memory_d[2];
              y += may23_B.Memory_d[3];
              if (y != 0.0) {
                /* '<S96>:1:41' */
                /* '<S96>:1:42' */
                may23_B.forceMotorState_o = 1.0;
              } else {
                /* '<S96>:1:44' */
                may23_DW.lastRunningState_o = 0.0;
              }
            }
          }
        } else {
          /* '<S96>:1:25' */
        }
      }

      /* Chart: '<S87>/Whistle state' */
      may23_Whistlestate(may23_B.sf_cleanword.out_val,
                         may23_B.sf_parsestatusregister.allOK,
                         may23_B.sf_parsestatusregister.motorOn,
                         may23_B.sf_parsestatusregister.eStopOut,
                         may23_B.Compare_jc, may23_B.forceMotorState_o,
                         may23_B.max_errors_to_fault, &may23_B.sf_Whistlestate,
                         &may23_DW.sf_Whistlestate);

      /* S-Function (BKINethercatpdotx): '<S87>/BKIN EtherCAT PDO Transmit ' */

      /* Level2 S-Function Block: '<S87>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
      {
        SimStruct *rts = may23_M->childSfunctions[8];
        sfcnOutputs(rts,1);
      }

      /* Constant: '<S77>/readTrigger' */
      may23_B.readTrigger_l = may23_P.readTrigger_Value;

      /* MATLAB Function: '<S77>/size' */
      may23_size(&may23_B.sf_size);

      /* Memory: '<S97>/Memory' */
      may23_B.Memory_k5 = may23_DW.Memory_PreviousInput_dp;

      /* MATLAB Function: '<S77>/size1' */
      may23_size(&may23_B.sf_size1);

      /* Memory: '<S97>/Memory1' */
      may23_B.Memory1_g = may23_DW.Memory1_PreviousInput_j;

      /* Memory: '<S97>/Memory2' */
      may23_B.Memory2_a[0] = may23_DW.Memory2_PreviousInput_g5[0];
      may23_B.Memory2_a[1] = may23_DW.Memory2_PreviousInput_g5[1];

      /* Chart: '<S77>/SDO read machine' */
      if (may23_DW.temporalCounter_i1_b < 511U) {
        may23_DW.temporalCounter_i1_b++;
      }

      /* Gateway: EtherCAT Subsystem/Arm 1/SDO read machine */
      may23_DW.sfEvent_k0 = -1;

      /* During: EtherCAT Subsystem/Arm 1/SDO read machine */
      if (may23_DW.is_active_c37_ethercat == 0U) {
        /* Entry: EtherCAT Subsystem/Arm 1/SDO read machine */
        may23_DW.is_active_c37_ethercat = 1U;

        /* Entry Internal: EtherCAT Subsystem/Arm 1/SDO read machine */
        /* Transition: '<S93>:230' */
        may23_DW.is_c37_ethercat = may23_IN_setup_a;

        /* Entry 'setup': '<S93>:139' */
        may23_DW.valueIdx_n = 0;
        may23_B.complete_b = 0;
        may23_clearValues();
        may23_DW.valueCount_a = may23_B.sf_size.count;
      } else {
        switch (may23_DW.is_c37_ethercat) {
         case may23_IN_Done_m:
          /* During 'Done': '<S93>:146' */
          if (may23_B.readTrigger_l != may23_DW.lastTrigger_d) {
            /* Transition: '<S93>:164' */
            may23_DW.is_c37_ethercat = may23_IN_setup_a;

            /* Entry 'setup': '<S93>:139' */
            may23_DW.valueIdx_n = 0;
            may23_B.complete_b = 0;
            may23_clearValues();
            may23_DW.valueCount_a = may23_B.sf_size.count;
          } else {
            may23_DW.lastTrigger_d = may23_B.readTrigger_l;
          }
          break;

         case may23_IN_Error:
          /* During 'Error': '<S93>:224' */
          if (may23_DW.temporalCounter_i1_b >= 400U) {
            /* Transition: '<S93>:222' */
            /*  ensure that Dex has enough time to readh this... */
            /* Transition: '<S93>:223' */
            /* Transition: '<S93>:214' */
            may23_DW.is_c37_ethercat = may23_IN_Done_m;

            /* Entry 'Done': '<S93>:146' */
            may23_DW.lastTrigger_d = may23_B.readTrigger_l;
          }
          break;

         case may23_IN_ReadNextFloat:
          /* During 'ReadNextFloat': '<S93>:184' */
          if (may23_B.Memory2_a[0] == 1) {
            /* Transition: '<S93>:187' */
            may23_DW.is_c37_ethercat = may23_IN_disableFloat;

            /* Entry 'disableFloat': '<S93>:186' */
            may23_B.SDOCommand_j[0] = 0;
          }
          break;

         case may23_IN_ReadNextInt:
          /* During 'ReadNextInt': '<S93>:141' */
          if (may23_B.Memory2_a[0] == 1) {
            /* Transition: '<S93>:157' */
            may23_DW.is_c37_ethercat = may23_IN_disableInt;

            /* Entry 'disableInt': '<S93>:156' */
            may23_B.SDOCommand_j[0] = 0;
          }
          break;

         case may23_IN_ReceivedFloat_h:
          /* During 'ReceivedFloat': '<S93>:188' */
          if (may23_DW.valueIdx_n + 1 > may23_DW.valueCount_a) {
            /* Transition: '<S93>:191' */
            may23_B.complete_b = 1;

            /* Transition: '<S93>:214' */
            may23_DW.is_c37_ethercat = may23_IN_Done_m;

            /* Entry 'Done': '<S93>:146' */
            may23_DW.lastTrigger_d = may23_B.readTrigger_l;
          } else {
            if (may23_B.Memory2_a[0] == 0) {
              /* Transition: '<S93>:192' */
              may23_DW.is_c37_ethercat = may23_IN_ReadNextFloat;

              /* Entry 'ReadNextFloat': '<S93>:184' */
              may23_DW.valueIdx_n++;
              may23_B.SDOCommand_j[0] = 1;
              may23_B.SDOCommand_j[1] = (int32_T)
                may23_B.floatAddresses[may23_DW.valueIdx_n - 1];
              may23_B.SDOCommand_j[2] = (int32_T)
                may23_B.floatAddresses[may23_DW.valueIdx_n + 11];
            }
          }
          break;

         case may23_IN_ReceivedInt:
          /* During 'ReceivedInt': '<S93>:142' */
          if (may23_DW.valueIdx_n + 1 > may23_DW.valueCount_a) {
            /* Transition: '<S93>:147' */
            may23_DW.is_c37_ethercat = may23_IN_startFloats;

            /* Entry 'startFloats': '<S93>:183' */
            may23_DW.valueCount_a = may23_B.sf_size1.count;
            may23_DW.valueIdx_n = 0;
          } else {
            if (may23_B.Memory2_a[0] == 0) {
              /* Transition: '<S93>:144' */
              may23_DW.is_c37_ethercat = may23_IN_ReadNextInt;

              /* Entry 'ReadNextInt': '<S93>:141' */
              may23_DW.valueIdx_n++;
              may23_B.SDOCommand_j[0] = 1;
              may23_B.SDOCommand_j[1] = (int32_T)
                may23_B.intAddresses[may23_DW.valueIdx_n - 1];
              may23_B.SDOCommand_j[2] = (int32_T)
                may23_B.intAddresses[may23_DW.valueIdx_n + 11];
            }
          }
          break;

         case may23_IN_disableFloat:
          /* During 'disableFloat': '<S93>:186' */
          if (may23_B.Memory2_a[0] == 2) {
            /* Transition: '<S93>:189' */
            may23_DW.is_c37_ethercat = may23_IN_ReceivedFloat_h;

            /* Entry 'ReceivedFloat': '<S93>:188' */
            may23_B.floatSDOValues_d[may23_DW.valueIdx_n - 1] =
              may23_B.Memory1_g;
          } else {
            if (may23_B.Memory2_a[0] == 3) {
              /* Transition: '<S93>:216' */
              if (may23_B.Memory2_a[1] == 0) {
                /* Transition: '<S93>:220' */
                may23_B.complete_b = -1;
              } else {
                /* Transition: '<S93>:226' */
                may23_B.complete_b = may23_B.Memory2_a[1];
              }

              may23_DW.is_c37_ethercat = may23_IN_Error;
              may23_DW.temporalCounter_i1_b = 0U;
            }
          }
          break;

         case may23_IN_disableInt:
          /* During 'disableInt': '<S93>:156' */
          if (may23_B.Memory2_a[0] == 3) {
            /* Transition: '<S93>:212' */
            /* Transition: '<S93>:218' */
            if (may23_B.Memory2_a[1] == 0) {
              /* Transition: '<S93>:220' */
              may23_B.complete_b = -1;
            } else {
              /* Transition: '<S93>:226' */
              may23_B.complete_b = may23_B.Memory2_a[1];
            }

            may23_DW.is_c37_ethercat = may23_IN_Error;
            may23_DW.temporalCounter_i1_b = 0U;
          } else {
            if (may23_B.Memory2_a[0] == 2) {
              /* Transition: '<S93>:143' */
              may23_DW.is_c37_ethercat = may23_IN_ReceivedInt;

              /* Entry 'ReceivedInt': '<S93>:142' */
              may23_B.intSDOValues_m[may23_DW.valueIdx_n - 1] =
                may23_B.Memory_k5;
            }
          }
          break;

         case may23_IN_setup_a:
          /* During 'setup': '<S93>:139' */
          if (may23_B.MasterStateOut >= 4) {
            /* Transition: '<S93>:145' */
            may23_DW.is_c37_ethercat = may23_IN_ReadNextInt;

            /* Entry 'ReadNextInt': '<S93>:141' */
            may23_DW.valueIdx_n++;
            may23_B.SDOCommand_j[0] = 1;
            may23_B.SDOCommand_j[1] = (int32_T)
              may23_B.intAddresses[may23_DW.valueIdx_n - 1];
            may23_B.SDOCommand_j[2] = (int32_T)
              may23_B.intAddresses[may23_DW.valueIdx_n + 11];
          }
          break;

         default:
          /* During 'startFloats': '<S93>:183' */
          /* Transition: '<S93>:185' */
          may23_DW.is_c37_ethercat = may23_IN_ReadNextFloat;

          /* Entry 'ReadNextFloat': '<S93>:184' */
          may23_DW.valueIdx_n++;
          may23_B.SDOCommand_j[0] = 1;
          may23_B.SDOCommand_j[1] = (int32_T)
            may23_B.floatAddresses[may23_DW.valueIdx_n - 1];
          may23_B.SDOCommand_j[2] = (int32_T)
            may23_B.floatAddresses[may23_DW.valueIdx_n + 11];
          break;
        }
      }

      /* End of Chart: '<S77>/SDO read machine' */

      /* MATLAB Function: '<S77>/split out constants1' incorporates:
       *  Constant: '<S66>/force primary only'
       */
      /* MATLAB Function 'EtherCAT Subsystem/Arm 1/split out constants1': '<S101>:1' */
      /* '<S101>:1:3' */
      /* '<S101>:1:4' */
      i = may23_B.intSDOValues_m[3] & 1;
      if (may23_P.forceprimaryonly_Value != 0.0) {
        /* '<S101>:1:6' */
        i = 0;
      }

      /* '<S101>:1:8' */
      /* '<S101>:1:9' */
      if ((may23_B.intSDOValues_m[3] >> 2 & 1U) == 0U) {
        /* '<S101>:1:13' */
        /* '<S101>:1:14' */
        robotOrientation = 1;
      } else {
        /* '<S101>:1:16' */
        robotOrientation = -1;
      }

      /* '<S101>:1:22' */
      if ((may23_B.intSDOValues_m[3] >> 3 & 1) == 1) {
        /* '<S101>:1:32' */
        /* '<S101>:1:33' */
        orientation = 1;
      } else {
        /* '<S101>:1:35' */
        orientation = -1;
      }

      if ((may23_B.intSDOValues_m[3] >> 4 & 1) == 1) {
        /* '<S101>:1:32' */
        /* '<S101>:1:33' */
        b_orientation = 1;
      } else {
        /* '<S101>:1:35' */
        b_orientation = -1;
      }

      /* '<S101>:1:25' */
      if ((may23_B.intSDOValues_m[3] >> 5 & 1) == 1) {
        /* '<S101>:1:32' */
        /* '<S101>:1:33' */
        c_orientation = 1;
      } else {
        /* '<S101>:1:35' */
        c_orientation = -1;
      }

      if ((may23_B.intSDOValues_m[3] >> 6 & 1) == 1) {
        /* '<S101>:1:32' */
        /* '<S101>:1:33' */
        d_orientation = 1;
      } else {
        /* '<S101>:1:35' */
        d_orientation = -1;
      }

      /* '<S101>:1:28' */
      may23_B.hasSecondary_l = i;
      may23_B.hasFT_c = may23_B.intSDOValues_m[3] >> 1 & 1;
      may23_B.robotOrientation_o = robotOrientation;
      may23_B.motorOrientation_j[0] = -(real_T)orientation;
      may23_B.motorOrientation_j[1] = -(real_T)b_orientation;
      may23_B.encOrientation_m[0] = c_orientation;
      may23_B.encOrientation_m[1] = d_orientation;
      may23_B.absEnc_m = may23_B.intSDOValues_m[3] >> 7 & 1;

      /* End of MATLAB Function: '<S77>/split out constants1' */

      /* MATLAB Function: '<S110>/MATLAB Function' */
      may23_MATLABFunction(may23_B.primaryposition_n,
                           may23_B.secondaryposition_k, may23_B.absEnc_m,
                           &may23_B.sf_MATLABFunction_k);

      /* DataTypeConversion: '<S102>/Data Type Conversion1' */
      may23_B.DataTypeConversion1_jv = may23_B.torque_f;

      /* DataTypeConversion: '<S102>/A1M1Convert' */
      may23_B.A1M1Convert[0] = may23_B.sf_MATLABFunction_k.prime_out;
      may23_B.A1M1Convert[1] = may23_B.sf_MATLABFunction_k.sec_out;
      may23_B.A1M1Convert[2] = may23_B.primaryvelocity_j;
      may23_B.A1M1Convert[3] = may23_B.DataTypeConversion1_jv;
      may23_B.A1M1Convert[4] = may23_B.digitalinputs;

      /* Outputs for Atomic SubSystem: '<S87>/EMCY Message pump' */
      may23_EMCYMessagepump();

      /* End of Outputs for SubSystem: '<S87>/EMCY Message pump' */

      /* MATLAB Function: '<S77>/split out constants' */
      /* MATLAB Function 'EtherCAT Subsystem/Arm 1/split out constants': '<S100>:1' */
      /* '<S100>:1:3' */
      /* '<S100>:1:4' */
      /* '<S100>:1:5' */
      /* '<S100>:1:6' */
      may23_B.encoderCounts_j[0] = 0.0;
      may23_B.calibPinAngles_i[0] = 0.0;
      may23_B.absAngOffsets_p[0] = 0.0;
      may23_B.linkLengths_p[0] = 0.0;
      may23_B.encoderCounts_j[1] = 0.0;
      may23_B.calibPinAngles_i[1] = 0.0;
      may23_B.absAngOffsets_p[1] = 0.0;
      may23_B.linkLengths_p[1] = 0.0;

      /* '<S100>:1:7' */
      may23_B.L2CalibPinOffset_e = 0.0;

      /* '<S100>:1:8' */
      may23_B.continuousTorques_m[0] = 0.0;
      may23_B.continuousTorques_m[1] = 0.0;

      /* '<S100>:1:9' */
      /* '<S100>:1:10' */
      /* '<S100>:1:11' */
      may23_B.gearRatios_j[0] = 0.0;
      may23_B.offsetRads_a[0] = 0.0;
      may23_B.offsetRadsPrimary_f[0] = 0.0;
      may23_B.gearRatios_j[1] = 0.0;
      may23_B.offsetRads_a[1] = 0.0;
      may23_B.offsetRadsPrimary_f[1] = 0.0;

      /* '<S100>:1:12' */
      may23_B.isCalibrated_j = 0.0;

      /* '<S100>:1:13' */
      may23_B.FTSensorOffset_k = 0.0;

      /* '<S100>:1:14' */
      may23_B.robotRevision_h = 0.0;

      /* '<S100>:1:16' */
      may23_B.constantsReady_p = may23_B.complete_b;
      if (may23_B.complete_b == 1) {
        /* '<S100>:1:22' */
        may23_B.encoderCounts_j[0] = may23_B.intSDOValues_m[4];
        may23_B.encoderCounts_j[1] = may23_B.intSDOValues_m[5];

        /* '<S100>:1:24' */
        may23_B.isCalibrated_j = may23_B.intSDOValues_m[7];

        /* '<S100>:1:25' */
        may23_B.offsetRads_a[0] = (real_T)may23_B.intSDOValues_m[8] / 1000.0;
        may23_B.offsetRads_a[1] = (real_T)may23_B.intSDOValues_m[9] / 1000.0;

        /* '<S100>:1:26' */
        may23_B.offsetRadsPrimary_f[0] = (real_T)may23_B.intSDOValues_m[10] /
          1000.0;
        may23_B.offsetRadsPrimary_f[1] = (real_T)may23_B.intSDOValues_m[11] /
          1000.0;

        /* '<S100>:1:28' */
        may23_B.FTSensorOffset_k = may23_B.floatSDOValues_d[0];

        /* '<S100>:1:29' */
        may23_B.calibPinAngles_i[0] = may23_B.floatSDOValues_d[1];
        may23_B.calibPinAngles_i[1] = may23_B.floatSDOValues_d[2];

        /* '<S100>:1:30' */
        may23_B.absAngOffsets_p[0] = may23_B.floatSDOValues_d[3];
        may23_B.absAngOffsets_p[1] = may23_B.floatSDOValues_d[4];

        /* '<S100>:1:31' */
        may23_B.linkLengths_p[0] = may23_B.floatSDOValues_d[5];
        may23_B.linkLengths_p[1] = may23_B.floatSDOValues_d[6];

        /* '<S100>:1:32' */
        may23_B.L2CalibPinOffset_e = may23_B.floatSDOValues_d[7];

        /* '<S100>:1:33' */
        may23_B.continuousTorques_m[0] = may23_B.floatSDOValues_d[8];
        may23_B.continuousTorques_m[1] = may23_B.floatSDOValues_d[9];

        /* '<S100>:1:34' */
        may23_B.gearRatios_j[0] = may23_B.floatSDOValues_d[10];
        may23_B.gearRatios_j[1] = may23_B.floatSDOValues_d[11];

        /* '<S100>:1:35' */
        may23_B.robotRevision_h = may23_B.intSDOValues_m[2];
      } else {
        /* '<S100>:1:18' */
      }

      /* End of MATLAB Function: '<S77>/split out constants' */

      /* Selector: '<S105>/L2 select' incorporates:
       *  Constant: '<S87>/MotorIdx'
       */
      may23_B.L2select_k = may23_B.offsetRads_a[(int32_T)may23_P.MotorIdx_Value
        - 1];

      /* Selector: '<S105>/L2 select1' incorporates:
       *  Constant: '<S87>/MotorIdx'
       */
      may23_B.L2select1_p = may23_B.encOrientation_m[(int32_T)
        may23_P.MotorIdx_Value - 1];

      /* Selector: '<S105>/L2 select2' incorporates:
       *  Constant: '<S87>/MotorIdx'
       */
      may23_B.L2select2_l = may23_B.motorOrientation_j[(int32_T)
        may23_P.MotorIdx_Value - 1];

      /* Selector: '<S105>/L2 select3' incorporates:
       *  Constant: '<S87>/MotorIdx'
       */
      may23_B.L2select3_a = may23_B.offsetRadsPrimary_f[(int32_T)
        may23_P.MotorIdx_Value - 1];

      /* Selector: '<S105>/L2 select4' incorporates:
       *  Constant: '<S87>/MotorIdx'
       */
      may23_B.L2select4_g = may23_B.gearRatios_j[(int32_T)may23_P.MotorIdx_Value
        - 1];

      /* Memory: '<S77>/Memory2' */
      may23_B.R1_maxContinuousTorque[0] = may23_DW.Memory2_PreviousInput_j[0];
      may23_B.R1_maxContinuousTorque[1] = may23_DW.Memory2_PreviousInput_j[1];

      /* Selector: '<S105>/L2 select5' incorporates:
       *  Constant: '<S87>/MotorIdx'
       */
      may23_B.L2select5_o = may23_B.R1_maxContinuousTorque[(int32_T)
        may23_P.MotorIdx_Value - 1];

      /* MATLAB Function: '<S77>/Find Robot type' incorporates:
       *  Constant: '<S66>/ep part nums'
       *  Constant: '<S66>/nhp part nums'
       */
      may23_FindRobottype(may23_B.intSDOValues_m, may23_P.eppartnums_Value,
                          may23_P.nhppartnums_Value, &may23_B.sf_FindRobottype);

      /* Memory: '<S77>/Memory3' */
      may23_B.R1_constantsReady = may23_DW.Memory3_PreviousInput_h;

      /* MATLAB Function: '<S105>/countsToRads' */
      /* MATLAB Function 'EtherCAT Subsystem/Arm 1/A1M1/PDO to Angles Subsystem/countsToRads': '<S121>:1' */
      /* '<S121>:1:3' */
      /* '<S121>:1:4' */
      /* '<S121>:1:7' */
      /* '<S121>:1:8' */
      /* '<S121>:1:11' */
      if (may23_B.R1_constantsReady != 1.0) {
        /* '<S121>:1:13' */
        /* '<S121>:1:14' */
        y = 0.0;

        /* '<S121>:1:15' */
        ticksPerRad = 0.0;

        /* '<S121>:1:16' */
        queueSizePrimary = 0.0;

        /* '<S121>:1:17' */
        torque = 0.0;
      } else {
        if (may23_B.hasSecondary_l != 0.0) {
          /* '<S121>:1:22' */
          /* '<S121>:1:32' */
          /* '<S121>:1:33' */
          /* '<S121>:1:34' */
          y = may23_B.A1M1Convert[1] / (may23_B.encoderCounts_j[1] /
            6.2831853071795862) * may23_B.L2select1_p + may23_B.L2select_k;
        } else {
          /* '<S121>:1:24' */
          /* '<S121>:1:32' */
          /* '<S121>:1:33' */
          /* '<S121>:1:34' */
          y = may23_B.A1M1Convert[0] / (may23_B.encoderCounts_j[0] *
            may23_B.L2select4_g / 6.2831853071795862) * may23_B.L2select2_l +
            may23_B.L2select3_a;
        }

        /* '<S121>:1:27' */
        /* '<S121>:1:32' */
        ticksPerRad = may23_B.encoderCounts_j[0] * may23_B.L2select4_g /
          6.2831853071795862;

        /* '<S121>:1:33' */
        /* '<S121>:1:34' */
        /* '<S121>:1:27' */
        queueSizePrimary = may23_B.A1M1Convert[0] / ticksPerRad *
          may23_B.L2select2_l + may23_B.L2select3_a;

        /* '<S121>:1:27' */
        ticksPerRad = may23_B.A1M1Convert[2] / ticksPerRad * may23_B.L2select2_l;

        /* '<S121>:1:28' */
        torque = may23_B.A1M1Convert[3] / 1000.0 * may23_B.L2select5_o *
          may23_B.L2select4_g * may23_B.L2select2_l;
      }

      may23_B.LinkAngle_b = y;
      may23_B.PrimaryLinkAngle_h = queueSizePrimary;
      may23_B.PrimaryLinkVel_b = ticksPerRad;
      may23_B.torque_l0 = torque;
      y = rt_roundd_snf((real_T)((uint64_T)rt_roundd_snf(may23_B.A1M1Convert[4])
        >> 20ULL));
      if (y < 1.8446744073709552E+19) {
        if (y >= 0.0) {
          tmp = (uint64_T)y;
        } else {
          tmp = 0ULL;
        }
      } else {
        tmp = MAX_uint64_T;
      }

      may23_B.digitalInputs_o[0] = (real_T)(tmp & 1ULL);
      y = rt_roundd_snf((real_T)((uint64_T)rt_roundd_snf(may23_B.A1M1Convert[4])
        >> 21ULL));
      if (y < 1.8446744073709552E+19) {
        if (y >= 0.0) {
          tmp = (uint64_T)y;
        } else {
          tmp = 0ULL;
        }
      } else {
        tmp = MAX_uint64_T;
      }

      may23_B.digitalInputs_o[1] = (real_T)(tmp & 1ULL);
      may23_B.digitalDiagnostics_a = may23_B.A1M1Convert[4];
      y = rt_roundd_snf((real_T)((uint64_T)rt_roundd_snf(may23_B.A1M1Convert[4])
        >> 16ULL));
      if (y < 1.8446744073709552E+19) {
        if (y >= 0.0) {
          tmp = (uint64_T)y;
        } else {
          tmp = 0ULL;
        }
      } else {
        tmp = MAX_uint64_T;
      }

      may23_B.calibrationButton_n = (real_T)(tmp & 1ULL);
      y = rt_roundd_snf((real_T)((uint64_T)rt_roundd_snf(may23_B.A1M1Convert[4])
        >> 19ULL));
      if (y < 1.8446744073709552E+19) {
        if (y >= 0.0) {
          tmp = (uint64_T)y;
        } else {
          tmp = 0ULL;
        }
      } else {
        tmp = MAX_uint64_T;
      }

      may23_B.epGripSensor_i = !((tmp & 1ULL) != 0.0);

      /* End of MATLAB Function: '<S105>/countsToRads' */

      /* S-Function (BKINethercatpdorxElmoDrive): '<S122>/BKIN PDO Receive ElmoDrive' */

      /* Level2 S-Function Block: '<S122>/BKIN PDO Receive ElmoDrive' (BKINethercatpdorxElmoDrive) */
      {
        SimStruct *rts = may23_M->childSfunctions[9];
        sfcnOutputs(rts,1);
      }

      /* Switch: '<S129>/Switch' incorporates:
       *  Constant: '<S129>/Constant'
       */
      if (may23_B.MasterStateOut >= may23_P.Switch_Threshold_jw) {
        may23_B.Switch_pj = may23_B.Statusword_n;
      } else {
        may23_B.Switch_pj = may23_P.Constant_Value_cg;
      }

      /* End of Switch: '<S129>/Switch' */

      /* MATLAB Function: '<S88>/cleanword' */
      may23_cleanword(may23_B.Switch_pj, &may23_B.sf_cleanword_k);

      /* Switch: '<S128>/Switch' incorporates:
       *  Constant: '<S128>/Constant'
       */
      if (may23_B.MasterStateOut >= may23_P.Switch_Threshold_c) {
        may23_B.Switch_p = may23_B.statusregister_h;
      } else {
        may23_B.Switch_p = may23_P.Constant_Value_l0;
      }

      /* End of Switch: '<S128>/Switch' */

      /* MATLAB Function: '<S122>/parse status register1' */
      may23_parsestatusregister(may23_B.Switch_p,
        &may23_B.sf_parsestatusregister1);

      /* RelationalOperator: '<S123>/Compare' incorporates:
       *  Constant: '<S123>/Constant'
       */
      may23_B.Compare_fs = (may23_B.MasterStateOut == may23_P.Compare_const_f);

      /* Chart: '<S88>/Whistle state' */
      may23_Whistlestate(may23_B.sf_cleanword_k.out_val,
                         may23_B.sf_parsestatusregister1.allOK,
                         may23_B.sf_parsestatusregister1.motorOn,
                         may23_B.sf_parsestatusregister1.eStopOut,
                         may23_B.Compare_fs, may23_B.forceMotorState_o,
                         may23_B.max_errors_to_fault, &may23_B.sf_Whistlestate_a,
                         &may23_DW.sf_Whistlestate_a);

      /* S-Function (BKINethercatpdotx): '<S88>/BKIN EtherCAT PDO Transmit ' */

      /* Level2 S-Function Block: '<S88>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
      {
        SimStruct *rts = may23_M->childSfunctions[10];
        sfcnOutputs(rts,1);
      }

      /* MATLAB Function: '<S130>/MATLAB Function' */
      may23_MATLABFunction(may23_B.primaryposition_o,
                           may23_B.secondaryposition_e, may23_B.absEnc_m,
                           &may23_B.sf_MATLABFunction_m0);

      /* DataTypeConversion: '<S122>/Data Type Conversion' */
      may23_B.DataTypeConversion_ch = may23_B.torque_m;

      /* DataTypeConversion: '<S122>/A1M2Convert' */
      may23_B.A1M2Convert[0] = may23_B.sf_MATLABFunction_m0.prime_out;
      may23_B.A1M2Convert[1] = may23_B.sf_MATLABFunction_m0.sec_out;
      may23_B.A1M2Convert[2] = may23_B.primaryvelocity_jy;
      may23_B.A1M2Convert[3] = may23_B.DataTypeConversion_ch;
      may23_B.A1M2Convert[4] = may23_B.digitalinputs_n;

      /* Outputs for Atomic SubSystem: '<S88>/EMCY Message pump' */
      may23_EMCYMessagepump_h();

      /* End of Outputs for SubSystem: '<S88>/EMCY Message pump' */

      /* Selector: '<S125>/L2 select' incorporates:
       *  Constant: '<S88>/MotorIdx'
       */
      may23_B.L2select_p = may23_B.offsetRads_a[(int32_T)
        may23_P.MotorIdx_Value_p - 1];

      /* Selector: '<S125>/L2 select1' incorporates:
       *  Constant: '<S88>/MotorIdx'
       */
      may23_B.L2select1_pl = may23_B.encOrientation_m[(int32_T)
        may23_P.MotorIdx_Value_p - 1];

      /* Selector: '<S125>/L2 select2' incorporates:
       *  Constant: '<S88>/MotorIdx'
       */
      may23_B.L2select2_mv = may23_B.motorOrientation_j[(int32_T)
        may23_P.MotorIdx_Value_p - 1];

      /* Selector: '<S125>/L2 select3' incorporates:
       *  Constant: '<S88>/MotorIdx'
       */
      may23_B.L2select3_i = may23_B.offsetRadsPrimary_f[(int32_T)
        may23_P.MotorIdx_Value_p - 1];

      /* Selector: '<S125>/L2 select4' incorporates:
       *  Constant: '<S88>/MotorIdx'
       */
      may23_B.L2select4_k = may23_B.gearRatios_j[(int32_T)
        may23_P.MotorIdx_Value_p - 1];

      /* Selector: '<S125>/L2 select5' incorporates:
       *  Constant: '<S88>/MotorIdx'
       */
      may23_B.L2select5_j = may23_B.R1_maxContinuousTorque[(int32_T)
        may23_P.MotorIdx_Value_p - 1];

      /* MATLAB Function: '<S125>/countsToRads' */
      /* MATLAB Function 'EtherCAT Subsystem/Arm 1/A1M2/PDO to Angles Subsystem/countsToRads': '<S141>:1' */
      /* '<S141>:1:4' */
      /* '<S141>:1:5' */
      /* '<S141>:1:8' */
      if (may23_B.R1_constantsReady != 1.0) {
        /* '<S141>:1:10' */
        /* '<S141>:1:11' */
        y = 0.0;

        /* '<S141>:1:12' */
        ticksPerRad = 0.0;

        /* '<S141>:1:13' */
        queueSizePrimary = 0.0;

        /* '<S141>:1:14' */
        torque = 0.0;
      } else {
        if (may23_B.hasSecondary_l != 0.0) {
          /* '<S141>:1:19' */
          /* '<S141>:1:29' */
          /* '<S141>:1:30' */
          /* '<S141>:1:31' */
          y = may23_B.A1M2Convert[1] / (may23_B.encoderCounts_j[1] /
            6.2831853071795862) * may23_B.L2select1_pl + may23_B.L2select_p;
        } else {
          /* '<S141>:1:21' */
          /* '<S141>:1:29' */
          /* '<S141>:1:30' */
          /* '<S141>:1:31' */
          y = may23_B.A1M2Convert[0] / (may23_B.encoderCounts_j[0] *
            may23_B.L2select4_k / 6.2831853071795862) * may23_B.L2select2_mv +
            may23_B.L2select3_i;
        }

        /* '<S141>:1:24' */
        /* '<S141>:1:29' */
        ticksPerRad = may23_B.encoderCounts_j[0] * may23_B.L2select4_k /
          6.2831853071795862;

        /* '<S141>:1:30' */
        /* '<S141>:1:31' */
        /* '<S141>:1:24' */
        queueSizePrimary = may23_B.A1M2Convert[0] / ticksPerRad *
          may23_B.L2select2_mv + may23_B.L2select3_i;

        /* '<S141>:1:24' */
        ticksPerRad = may23_B.A1M2Convert[2] / ticksPerRad *
          may23_B.L2select2_mv;

        /* '<S141>:1:25' */
        torque = may23_B.A1M2Convert[3] / 1000.0 * may23_B.L2select5_j *
          may23_B.L2select4_k * may23_B.L2select2_mv;
      }

      may23_B.LinkAngle_a = y;
      may23_B.PrimaryLinkAngle_f = queueSizePrimary;
      may23_B.PrimaryLinkVel_d = ticksPerRad;
      may23_B.torque_l = torque;
      y = rt_roundd_snf((real_T)((uint64_T)rt_roundd_snf(may23_B.A1M2Convert[4])
        >> 20ULL));
      if (y < 1.8446744073709552E+19) {
        if (y >= 0.0) {
          tmp = (uint64_T)y;
        } else {
          tmp = 0ULL;
        }
      } else {
        tmp = MAX_uint64_T;
      }

      may23_B.digitalInputs_p[0] = (real_T)(tmp & 1ULL);
      y = rt_roundd_snf((real_T)((uint64_T)rt_roundd_snf(may23_B.A1M2Convert[4])
        >> 21ULL));
      if (y < 1.8446744073709552E+19) {
        if (y >= 0.0) {
          tmp = (uint64_T)y;
        } else {
          tmp = 0ULL;
        }
      } else {
        tmp = MAX_uint64_T;
      }

      may23_B.digitalInputs_p[1] = (real_T)(tmp & 1ULL);
      may23_B.digitalDiagnostics_b = may23_B.A1M2Convert[4];

      /* End of MATLAB Function: '<S125>/countsToRads' */

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M1_LinkAngle = may23_B.LinkAngle_b;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M1_CurrentLimitEnabled =
        may23_B.sf_parsestatusregister.currentLimitEnabled;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M2_LinkAngle = may23_B.LinkAngle_a;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M2_PrimaryLinkAngle = may23_B.PrimaryLinkAngle_f;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M2_PrimaryLinkVelocity = may23_B.PrimaryLinkVel_d;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M2_RecordedTorque = may23_B.torque_l;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M2_digitalInputs[0] = may23_B.digitalInputs_p[0];
      may23_B.R1M2_digitalInputs[1] = may23_B.digitalInputs_p[1];

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M2_digitalDiagnostics = may23_B.digitalDiagnostics_b;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      for (i = 0; i < 5; i++) {
        may23_B.R1M2_EMCY_codes[i] = may23_B.sf_passemcy_b.EMCYMsg[i];
      }

      /* End of SignalConversion generated from: '<S77>/Signal Conversion' */

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M2_CurrentLimitEnabled =
        may23_B.sf_parsestatusregister1.currentLimitEnabled;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M1_PrimaryLinkAngle = may23_B.PrimaryLinkAngle_h;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M1_PrimaryLinkVelocity = may23_B.PrimaryLinkVel_b;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M1_RecordedTorque = may23_B.torque_l0;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M1_digitalInputs[0] = may23_B.digitalInputs_o[0];
      may23_B.R1M1_digitalInputs[1] = may23_B.digitalInputs_o[1];

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1M1_digitalDiagnostics = may23_B.digitalDiagnostics_a;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1_calibrationButton = may23_B.calibrationButton_n;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      may23_B.R1_EPGripSensor = may23_B.epGripSensor_i;

      /* SignalConversion generated from: '<S77>/Signal Conversion' */
      for (i = 0; i < 5; i++) {
        may23_B.R1M1_EMCY_codes[i] = may23_B.sf_passemcy.EMCYMsg[i];
      }

      /* End of SignalConversion generated from: '<S77>/Signal Conversion' */

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_RobotType = may23_B.sf_FindRobottype.robotType;

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_absAngleOffset[0] = may23_B.absAngOffsets_p[0];
      may23_B.R1_absAngleOffset[1] = may23_B.absAngOffsets_p[1];

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_LinkLength[0] = may23_B.linkLengths_p[0];
      may23_B.R1_LinkLength[1] = may23_B.linkLengths_p[1];

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_L2CalibPinOffset = may23_B.L2CalibPinOffset_e;

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_maxContinuousTorque_i[0] = may23_B.R1_maxContinuousTorque[0];

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_gearRatios[0] = may23_B.gearRatios_j[0];

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_maxContinuousTorque_i[1] = may23_B.R1_maxContinuousTorque[1];

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_gearRatios[1] = may23_B.gearRatios_j[1];

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_isCalibrated = may23_B.isCalibrated_j;

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_OffsetRads[0] = may23_B.offsetRads_a[0];
      may23_B.R1_OffsetRads[1] = may23_B.offsetRads_a[1];

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_OffsetRadsPrimary[0] = may23_B.offsetRadsPrimary_f[0];
      may23_B.R1_OffsetRadsPrimary[1] = may23_B.offsetRadsPrimary_f[1];

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_RobotRevision = may23_B.robotRevision_h;

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_constantsReady_p = may23_B.R1_constantsReady;

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_hasSecondary = may23_B.hasSecondary_l;

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_hasFT = may23_B.hasFT_c;

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_robotOrientation = may23_B.robotOrientation_o;

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_motorOrientation[0] = may23_B.motorOrientation_j[0];
      may23_B.R1_motorOrientation[1] = may23_B.motorOrientation_j[1];

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_encOrientation[0] = may23_B.encOrientation_m[0];
      may23_B.R1_encOrientation[1] = may23_B.encOrientation_m[1];

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_encodercounts[0] = may23_B.encoderCounts_j[0];
      may23_B.R1_encodercounts[1] = may23_B.encoderCounts_j[1];

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_FTSensorAngleOffset = may23_B.FTSensorOffset_k;

      /* SignalConversion generated from: '<S77>/Signal Conversion1' */
      may23_B.R1_calibPinAngle[0] = may23_B.calibPinAngles_i[0];
      may23_B.R1_calibPinAngle[1] = may23_B.calibPinAngles_i[1];

      /* Outputs for Atomic SubSystem: '<S97>/Read Drive 1 SDO' */
      may23_ReadDrive1SDO_c();

      /* End of Outputs for SubSystem: '<S97>/Read Drive 1 SDO' */

      /* RateTransition: '<S97>/Rate Transition' */
      may23_B.RateTransition_gd = may23_B.sf_converter_a.int32Out;

      /* RateTransition: '<S97>/Rate Transition1' */
      may23_B.RateTransition1_i = may23_B.sf_converter_a.doubleOut;

      /* RateTransition: '<S97>/Rate Transition2' */
      may23_B.RateTransition2_ph[0] = may23_B.BKINEtherCATAsyncSDOUpload1_o2_e;
      may23_B.RateTransition2_ph[1] = may23_B.sf_MATLABFunction_e.out_err_code;

      /* Outputs for Enabled SubSystem: '<S77>/M2 AbsEnc Calibration' incorporates:
       *  EnablePort: '<S92>/Enable'
       */
      /* Outputs for Enabled SubSystem: '<S77>/M1 AbsEnc Calibration' incorporates:
       *  EnablePort: '<S91>/Enable'
       */
      /* Constant: '<S77>/enableCalibration' */
      if (may23_P.enableCalibration_Value > 0.0) {
        if (!may23_DW.M1AbsEncCalibration_MODE_c) {
          /* InitializeConditions for Memory: '<S91>/Memory' */
          may23_DW.Memory_PreviousInput_l = may23_P.Memory_InitialCondition_b;

          /* InitializeConditions for Memory: '<S91>/Memory1' */
          may23_DW.Memory1_PreviousInput_p[0] =
            may23_P.Memory1_InitialCondition_a;
          may23_DW.Memory1_PreviousInput_p[1] =
            may23_P.Memory1_InitialCondition_a;

          /* SystemReset for Chart: '<S91>/AbsEncoder machine' */
          may23_AbsEncodermachine_Reset(&may23_B.sf_AbsEncodermachine,
            &may23_DW.sf_AbsEncodermachine);
          may23_DW.M1AbsEncCalibration_MODE_c = true;
        }

        /* MATLAB Function: '<S91>/set-up values' */
        may23_setupvalues(&may23_B.sf_setupvalues);

        /* Memory: '<S91>/Memory' */
        may23_B.Memory_my = may23_DW.Memory_PreviousInput_l;

        /* Memory: '<S91>/Memory1' */
        may23_B.Memory1_b[0] = may23_DW.Memory1_PreviousInput_p[0];
        may23_B.Memory1_b[1] = may23_DW.Memory1_PreviousInput_p[1];

        /* Chart: '<S91>/AbsEncoder machine' */
        may23_AbsEncodermachine(may23_B.sf_setupvalues.setupValues,
          may23_B.sf_setupvalues.setupValuesCount,
          may23_B.sf_setupvalues.pollValues,
          may23_B.sf_setupvalues.encoderValues,
          may23_B.sf_setupvalues.encoderValuesCount, may23_B.Memory_my,
          may23_B.Memory1_b, &may23_B.sf_AbsEncodermachine,
          &may23_DW.sf_AbsEncodermachine);

        /* S-Function (BKINethercatasyncsdodownload): '<S91>/BKIN EtherCAT Async SDO Download' */
        {
          int8_T *sigInputPtr;
          int32_T *sigStatusPtr;
          uint32_T *perror;
          int32_T *enInputPtr;
          int_T deviceIndex;
          int_T res;
          int_T state;
          int32_T *indexInputPtr;
          int32_T *subIndexInputPtr;
          deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_f[0];
          perror = &may23_B.BKINEtherCATAsyncSDODownload_o2_n;
          *perror = 0;                 // preset to no error
          if (deviceIndex != NO_ETHERCAT) {
            state = xpcEtherCATgetState( deviceIndex );
            if (state >= 2 ) {
              sigStatusPtr = &may23_B.BKINEtherCATAsyncSDODownload_o1_l;
              sigInputPtr = (int8_T*)&may23_B.sf_AbsEncodermachine.setupData[0];
              enInputPtr = &may23_B.sf_AbsEncodermachine.setupData[1];
              indexInputPtr = &may23_B.sf_AbsEncodermachine.setupData[2];
              subIndexInputPtr = &may23_B.sf_AbsEncodermachine.setupData[3];
              if (may23_DW.BKINEtherCATAsyncSDODownload_IWORK_f[7] != 0) {
                res = ecatAsyncSDODownload(deviceIndex,
                  1001,
                  (unsigned short)*indexInputPtr,
                  (unsigned char)*subIndexInputPtr,
                  (void *)sigInputPtr,
                  1*4,
                  500,
                  658981113,
                  sigStatusPtr,
                  *enInputPtr);
                *perror = res;
              } else {
                *sigStatusPtr = 0;
              }

              may23_DW.BKINEtherCATAsyncSDODownload_IWORK_f[7] = 1;
              ;
            }
          }
        }

        /* S-Function (BKINethercatasyncsdoupload): '<S91>/BKIN EtherCAT Async SDO Upload' */
        {
          int8_T *sigOutputPtr;
          int32_T *sigStatusPtr;
          uint32_T *perror;
          int32_T *enInputPtr;
          int_T deviceIndex;
          static int counter= 0;
          int_T actLen;
          int_T res;
          int_T state;
          int32_T *indexInputPtr;
          int32_T *subIndexInputPtr;
          deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_j0[0];
          perror = &may23_B.BKINEtherCATAsyncSDOUpload_o3_n;
          *perror = 0;                 // preset to no error
          if (deviceIndex != NO_ETHERCAT) {
            state = xpcEtherCATgetState( deviceIndex );
            if (state >= 2 ) {
              sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload_o1_kp;
              sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload_o2_pz;
              enInputPtr = &may23_B.sf_AbsEncodermachine.SDORequest[0];
              indexInputPtr = &may23_B.sf_AbsEncodermachine.SDORequest[1];
              subIndexInputPtr = &may23_B.sf_AbsEncodermachine.SDORequest[2];
              if (may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_j0[7] != 0) {
                res = ecatAsyncSDOUpload(deviceIndex,
                  1001,
                  (unsigned short)*indexInputPtr,
                  (unsigned char)*subIndexInputPtr,
                  (void *)sigOutputPtr,
                  1*4,
                  &actLen,
                  500,
                  658981114,
                  sigStatusPtr,
                  *enInputPtr);
                *perror = res;
              }

              may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_j0[7] = 1;
              ;
            }
          }
        }

        srUpdateBC(may23_DW.M1AbsEncCalibration_SubsysRanBC_o);
        if (!may23_DW.M2AbsEncCalibration_MODE_p) {
          /* InitializeConditions for Memory: '<S92>/Memory' */
          may23_DW.Memory_PreviousInput_kk = may23_P.Memory_InitialCondition_ba;

          /* InitializeConditions for Memory: '<S92>/Memory1' */
          may23_DW.Memory1_PreviousInput_i[0] =
            may23_P.Memory1_InitialCondition_nm;
          may23_DW.Memory1_PreviousInput_i[1] =
            may23_P.Memory1_InitialCondition_nm;

          /* SystemReset for Chart: '<S92>/AbsEncoder machine' */
          may23_AbsEncodermachine_Reset(&may23_B.sf_AbsEncodermachine_l,
            &may23_DW.sf_AbsEncodermachine_l);
          may23_DW.M2AbsEncCalibration_MODE_p = true;
        }

        /* MATLAB Function: '<S92>/set-up values' */
        may23_setupvalues(&may23_B.sf_setupvalues_b);

        /* Memory: '<S92>/Memory' */
        may23_B.Memory_ir = may23_DW.Memory_PreviousInput_kk;

        /* Memory: '<S92>/Memory1' */
        may23_B.Memory1_i[0] = may23_DW.Memory1_PreviousInput_i[0];
        may23_B.Memory1_i[1] = may23_DW.Memory1_PreviousInput_i[1];

        /* Chart: '<S92>/AbsEncoder machine' */
        may23_AbsEncodermachine(may23_B.sf_setupvalues_b.setupValues,
          may23_B.sf_setupvalues_b.setupValuesCount,
          may23_B.sf_setupvalues_b.pollValues,
          may23_B.sf_setupvalues_b.encoderValues,
          may23_B.sf_setupvalues_b.encoderValuesCount, may23_B.Memory_ir,
          may23_B.Memory1_i, &may23_B.sf_AbsEncodermachine_l,
          &may23_DW.sf_AbsEncodermachine_l);

        /* S-Function (BKINethercatasyncsdodownload): '<S92>/BKIN EtherCAT Async SDO Download' */
        {
          int8_T *sigInputPtr;
          int32_T *sigStatusPtr;
          uint32_T *perror;
          int32_T *enInputPtr;
          int_T deviceIndex;
          int_T res;
          int_T state;
          int32_T *indexInputPtr;
          int32_T *subIndexInputPtr;
          deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_p[0];
          perror = &may23_B.BKINEtherCATAsyncSDODownload_o2_b4;
          *perror = 0;                 // preset to no error
          if (deviceIndex != NO_ETHERCAT) {
            state = xpcEtherCATgetState( deviceIndex );
            if (state >= 2 ) {
              sigStatusPtr = &may23_B.BKINEtherCATAsyncSDODownload_o1_h1;
              sigInputPtr = (int8_T*)&may23_B.sf_AbsEncodermachine_l.setupData[0];
              enInputPtr = &may23_B.sf_AbsEncodermachine_l.setupData[1];
              indexInputPtr = &may23_B.sf_AbsEncodermachine_l.setupData[2];
              subIndexInputPtr = &may23_B.sf_AbsEncodermachine_l.setupData[3];
              if (may23_DW.BKINEtherCATAsyncSDODownload_IWORK_p[7] != 0) {
                res = ecatAsyncSDODownload(deviceIndex,
                  1002,
                  (unsigned short)*indexInputPtr,
                  (unsigned char)*subIndexInputPtr,
                  (void *)sigInputPtr,
                  1*4,
                  500,
                  658984267,
                  sigStatusPtr,
                  *enInputPtr);
                *perror = res;
              } else {
                *sigStatusPtr = 0;
              }

              may23_DW.BKINEtherCATAsyncSDODownload_IWORK_p[7] = 1;
              ;
            }
          }
        }

        /* S-Function (BKINethercatasyncsdoupload): '<S92>/BKIN EtherCAT Async SDO Upload' */
        {
          int8_T *sigOutputPtr;
          int32_T *sigStatusPtr;
          uint32_T *perror;
          int32_T *enInputPtr;
          int_T deviceIndex;
          static int counter= 0;
          int_T actLen;
          int_T res;
          int_T state;
          int32_T *indexInputPtr;
          int32_T *subIndexInputPtr;
          deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_lj[0];
          perror = &may23_B.BKINEtherCATAsyncSDOUpload_o3_k;
          *perror = 0;                 // preset to no error
          if (deviceIndex != NO_ETHERCAT) {
            state = xpcEtherCATgetState( deviceIndex );
            if (state >= 2 ) {
              sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload_o1_g;
              sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload_o2_b;
              enInputPtr = &may23_B.sf_AbsEncodermachine_l.SDORequest[0];
              indexInputPtr = &may23_B.sf_AbsEncodermachine_l.SDORequest[1];
              subIndexInputPtr = &may23_B.sf_AbsEncodermachine_l.SDORequest[2];
              if (may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_lj[7] != 0) {
                res = ecatAsyncSDOUpload(deviceIndex,
                  1002,
                  (unsigned short)*indexInputPtr,
                  (unsigned char)*subIndexInputPtr,
                  (void *)sigOutputPtr,
                  1*4,
                  &actLen,
                  500,
                  658984268,
                  sigStatusPtr,
                  *enInputPtr);
                *perror = res;
              }

              may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_lj[7] = 1;
              ;
            }
          }
        }

        srUpdateBC(may23_DW.M2AbsEncCalibration_SubsysRanBC_i);
      } else {
        may23_DW.M1AbsEncCalibration_MODE_c = false;
        may23_DW.M2AbsEncCalibration_MODE_p = false;
      }

      /* End of Constant: '<S77>/enableCalibration' */
      /* End of Outputs for SubSystem: '<S77>/M1 AbsEnc Calibration' */
      /* End of Outputs for SubSystem: '<S77>/M2 AbsEnc Calibration' */

      /* MATLAB Function: '<S89>/MATLAB Function1' incorporates:
       *  Constant: '<S89>/override_grip'
       */
      may23_MATLABFunction1(may23_B.epGripSensor_i,
                            may23_B.sf_FindRobottype.robotType,
                            may23_P.override_grip_Value, may23_B.Memory2,
                            &may23_B.sf_MATLABFunction1_k);

      /* S-Function (BKINethercatpdotx): '<S89>/BKIN EtherCAT PDO Transmit ' */

      /* Level2 S-Function Block: '<S89>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
      {
        SimStruct *rts = may23_M->childSfunctions[11];
        sfcnOutputs(rts,1);
      }

      /* S-Function (BKINethercatpdotx): '<S89>/BKIN EtherCAT PDO Transmit 1' */

      /* Level2 S-Function Block: '<S89>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
      {
        SimStruct *rts = may23_M->childSfunctions[12];
        sfcnOutputs(rts,1);
      }

      /* Outputs for Atomic SubSystem: '<S77>/SDO reading' */
      may23_SDOreading();

      /* End of Outputs for SubSystem: '<S77>/SDO reading' */

      /* Outputs for Atomic SubSystem: '<S77>/SDO writing' */
      may23_SDOwriting();

      /* End of Outputs for SubSystem: '<S77>/SDO writing' */
      srUpdateBC(may23_DW.Arm1_SubsysRanBC);
    } else {
      if (may23_DW.Arm1_MODE) {
        /* Disable for Enabled SubSystem: '<S77>/M1 AbsEnc Calibration' */
        may23_DW.M1AbsEncCalibration_MODE_c = false;

        /* End of Disable for SubSystem: '<S77>/M1 AbsEnc Calibration' */

        /* Disable for Enabled SubSystem: '<S77>/M2 AbsEnc Calibration' */
        may23_DW.M2AbsEncCalibration_MODE_p = false;

        /* End of Disable for SubSystem: '<S77>/M2 AbsEnc Calibration' */
        may23_DW.Arm1_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S66>/Arm 1' */

    /* Outputs for Enabled SubSystem: '<S66>/Arm 2' incorporates:
     *  EnablePort: '<S78>/Enable'
     */
    if (may23_B.Compare_ny) {
      may23_DW.Arm2_MODE = true;

      /* S-Function (BKINethercatpdorxElmoDrive): '<S177>/BKIN PDO Receive ElmoDrive' */

      /* Level2 S-Function Block: '<S177>/BKIN PDO Receive ElmoDrive' (BKINethercatpdorxElmoDrive) */
      {
        SimStruct *rts = may23_M->childSfunctions[13];
        sfcnOutputs(rts,1);
      }

      /* Switch: '<S184>/Switch' incorporates:
       *  Constant: '<S184>/Constant'
       */
      if (may23_B.MasterStateOut >= may23_P.Switch_Threshold_l) {
        may23_B.Switch_g3 = may23_B.Statusword;
      } else {
        may23_B.Switch_g3 = may23_P.Constant_Value_cq;
      }

      /* End of Switch: '<S184>/Switch' */

      /* MATLAB Function: '<S162>/cleanword' */
      may23_cleanword(may23_B.Switch_g3, &may23_B.sf_cleanword_e);

      /* Switch: '<S183>/Switch' incorporates:
       *  Constant: '<S183>/Constant'
       */
      if (may23_B.MasterStateOut >= may23_P.Switch_Threshold_eg) {
        may23_B.Switch_l = may23_B.BKINPDOReceiveElmoDrive_o2;
      } else {
        may23_B.Switch_l = may23_P.Constant_Value_cey;
      }

      /* End of Switch: '<S183>/Switch' */

      /* MATLAB Function: '<S177>/parse status register1' */
      may23_parsestatusregister(may23_B.Switch_l,
        &may23_B.sf_parsestatusregister1_g);

      /* RelationalOperator: '<S178>/Compare' incorporates:
       *  Constant: '<S178>/Constant'
       */
      may23_B.Compare_ew = (may23_B.MasterStateOut == may23_P.Compare_const_p);

      /* Memory: '<S162>/Memory' */
      may23_B.Memory_k = may23_DW.Memory_PreviousInput_c;

      /* Memory: '<S163>/Memory' */
      may23_B.Memory_j = may23_DW.Memory_PreviousInput_g;

      /* SignalConversion generated from: '<S171>/ SFunction ' incorporates:
       *  MATLAB Function: '<S78>/forceEnableDisable'
       */
      may23_B.TmpSignalConversionAtSFunctionInport6[0] = may23_B.Memory_k;
      may23_B.TmpSignalConversionAtSFunctionInport6[1] = may23_B.Memory_j;

      /* MATLAB Function: '<S78>/forceEnableDisable' incorporates:
       *  Constant: '<S78>/enableMotors'
       */
      /* MATLAB Function 'EtherCAT Subsystem/Arm 2/forceEnableDisable': '<S171>:1' */
      /* '<S171>:1:10' */
      may23_B.forceMotorState = 0.0;
      guard1 = false;
      if (may23_B.TmpSignalConversionAtSFunctionInport6[0] +
          may23_B.TmpSignalConversionAtSFunctionInport6[1] != 0.0) {
        /* '<S171>:1:13' */
        /* '<S171>:1:14' */
        may23_DW.faultResetCycles++;
        if (may23_DW.faultResetCycles > may23_B.max_errors_to_fault) {
          /* '<S171>:1:18' */
        } else {
          guard1 = true;
        }
      } else {
        guard1 = true;
      }

      if (guard1) {
        if ((!(may23_P.enableMotors_Value_h == 0.0)) && may23_B.motorEnableState
            && (!(may23_B.Memory2 != 0.0))) {
          if ((may23_B.DataTypeConversion_pn == 2.0) ||
              (may23_B.DataTypeConversion_pn == 4.0)) {
            /* '<S171>:1:32' */
            /* '<S171>:1:35' */
            may23_B.forceMotorState = 1.0;

            /* '<S171>:1:36' */
            may23_DW.lastRunningState = 1.0;
          } else {
            if (may23_DW.lastRunningState == 1.0) {
              /* '<S171>:1:40' */
              y = may23_B.Memory_d[0];
              y += may23_B.Memory_d[1];
              y += may23_B.Memory_d[2];
              y += may23_B.Memory_d[3];
              if (y != 0.0) {
                /* '<S171>:1:41' */
                /* '<S171>:1:42' */
                may23_B.forceMotorState = 1.0;
              } else {
                /* '<S171>:1:44' */
                may23_DW.lastRunningState = 0.0;
              }
            }
          }
        } else {
          /* '<S171>:1:25' */
        }
      }

      /* Chart: '<S162>/Whistle state' */
      may23_Whistlestate(may23_B.sf_cleanword_e.out_val,
                         may23_B.sf_parsestatusregister1_g.allOK,
                         may23_B.sf_parsestatusregister1_g.motorOn,
                         may23_B.sf_parsestatusregister1_g.eStopOut,
                         may23_B.Compare_ew, may23_B.forceMotorState,
                         may23_B.max_errors_to_fault, &may23_B.sf_Whistlestate_l,
                         &may23_DW.sf_Whistlestate_l);

      /* S-Function (BKINethercatpdotx): '<S162>/BKIN EtherCAT PDO Transmit ' */

      /* Level2 S-Function Block: '<S162>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
      {
        SimStruct *rts = may23_M->childSfunctions[14];
        sfcnOutputs(rts,1);
      }

      /* Constant: '<S78>/readTrigger' */
      may23_B.readTrigger = may23_P.readTrigger_Value_a;

      /* MATLAB Function: '<S78>/size' */
      may23_size(&may23_B.sf_size_l);

      /* Memory: '<S172>/Memory' */
      may23_B.Memory_o = may23_DW.Memory_PreviousInput_b;

      /* MATLAB Function: '<S78>/size1' */
      may23_size(&may23_B.sf_size1_b);

      /* Memory: '<S172>/Memory1' */
      may23_B.Memory1_ew = may23_DW.Memory1_PreviousInput_n;

      /* Memory: '<S172>/Memory2' */
      may23_B.Memory2_p[0] = may23_DW.Memory2_PreviousInput_o[0];
      may23_B.Memory2_p[1] = may23_DW.Memory2_PreviousInput_o[1];

      /* Chart: '<S78>/SDO read machine' */
      if (may23_DW.temporalCounter_i1_n4 < 511U) {
        may23_DW.temporalCounter_i1_n4++;
      }

      /* Gateway: EtherCAT Subsystem/Arm 2/SDO read machine */
      may23_DW.sfEvent_k = -1;

      /* During: EtherCAT Subsystem/Arm 2/SDO read machine */
      if (may23_DW.is_active_c95_ethercat == 0U) {
        /* Entry: EtherCAT Subsystem/Arm 2/SDO read machine */
        may23_DW.is_active_c95_ethercat = 1U;

        /* Entry Internal: EtherCAT Subsystem/Arm 2/SDO read machine */
        /* Transition: '<S167>:232' */
        may23_DW.is_c95_ethercat = may23_IN_setup_a;

        /* Entry 'setup': '<S167>:139' */
        may23_DW.valueIdx = 0;
        may23_B.complete = 0;
        may23_clearValues_p();
        may23_DW.valueCount = may23_B.sf_size_l.count;
      } else {
        switch (may23_DW.is_c95_ethercat) {
         case may23_IN_Done_m:
          /* During 'Done': '<S167>:146' */
          if (may23_B.readTrigger != may23_DW.lastTrigger) {
            /* Transition: '<S167>:164' */
            may23_DW.is_c95_ethercat = may23_IN_setup_a;

            /* Entry 'setup': '<S167>:139' */
            may23_DW.valueIdx = 0;
            may23_B.complete = 0;
            may23_clearValues_p();
            may23_DW.valueCount = may23_B.sf_size_l.count;
          } else {
            may23_DW.lastTrigger = may23_B.readTrigger;
          }
          break;

         case may23_IN_Error:
          /* During 'Error': '<S167>:224' */
          if (may23_DW.temporalCounter_i1_n4 >= 400U) {
            /* Transition: '<S167>:222' */
            /*  ensure that Dex has enough time to readh this... */
            /* Transition: '<S167>:223' */
            /* Transition: '<S167>:214' */
            may23_DW.is_c95_ethercat = may23_IN_Done_m;

            /* Entry 'Done': '<S167>:146' */
            may23_DW.lastTrigger = may23_B.readTrigger;
          }
          break;

         case may23_IN_ReadNextFloat:
          /* During 'ReadNextFloat': '<S167>:184' */
          if (may23_B.Memory2_p[0] == 1) {
            /* Transition: '<S167>:187' */
            may23_DW.is_c95_ethercat = may23_IN_disableFloat;

            /* Entry 'disableFloat': '<S167>:186' */
            may23_B.SDOCommand[0] = 0;
          }
          break;

         case may23_IN_ReadNextInt:
          /* During 'ReadNextInt': '<S167>:141' */
          if (may23_B.Memory2_p[0] == 1) {
            /* Transition: '<S167>:157' */
            may23_DW.is_c95_ethercat = may23_IN_disableInt;

            /* Entry 'disableInt': '<S167>:156' */
            may23_B.SDOCommand[0] = 0;
          }
          break;

         case may23_IN_ReceivedFloat_h:
          /* During 'ReceivedFloat': '<S167>:188' */
          if (may23_DW.valueIdx + 1 > may23_DW.valueCount) {
            /* Transition: '<S167>:191' */
            may23_B.complete = 1;

            /* Transition: '<S167>:214' */
            may23_DW.is_c95_ethercat = may23_IN_Done_m;

            /* Entry 'Done': '<S167>:146' */
            may23_DW.lastTrigger = may23_B.readTrigger;
          } else {
            if (may23_B.Memory2_p[0] == 0) {
              /* Transition: '<S167>:192' */
              may23_DW.is_c95_ethercat = may23_IN_ReadNextFloat;

              /* Entry 'ReadNextFloat': '<S167>:184' */
              may23_DW.valueIdx++;
              may23_B.SDOCommand[0] = 1;
              may23_B.SDOCommand[1] = (int32_T)
                may23_B.floatAddresses[may23_DW.valueIdx - 1];
              may23_B.SDOCommand[2] = (int32_T)
                may23_B.floatAddresses[may23_DW.valueIdx + 11];
            }
          }
          break;

         case may23_IN_ReceivedInt:
          /* During 'ReceivedInt': '<S167>:142' */
          if (may23_DW.valueIdx + 1 > may23_DW.valueCount) {
            /* Transition: '<S167>:147' */
            may23_DW.is_c95_ethercat = may23_IN_startFloats;

            /* Entry 'startFloats': '<S167>:183' */
            may23_DW.valueCount = may23_B.sf_size1_b.count;
            may23_DW.valueIdx = 0;
          } else {
            if (may23_B.Memory2_p[0] == 0) {
              /* Transition: '<S167>:144' */
              may23_DW.is_c95_ethercat = may23_IN_ReadNextInt;

              /* Entry 'ReadNextInt': '<S167>:141' */
              may23_DW.valueIdx++;
              may23_B.SDOCommand[0] = 1;
              may23_B.SDOCommand[1] = (int32_T)
                may23_B.intAddresses[may23_DW.valueIdx - 1];
              may23_B.SDOCommand[2] = (int32_T)
                may23_B.intAddresses[may23_DW.valueIdx + 11];
            }
          }
          break;

         case may23_IN_disableFloat:
          /* During 'disableFloat': '<S167>:186' */
          if (may23_B.Memory2_p[0] == 2) {
            /* Transition: '<S167>:189' */
            may23_DW.is_c95_ethercat = may23_IN_ReceivedFloat_h;

            /* Entry 'ReceivedFloat': '<S167>:188' */
            may23_B.floatSDOValues[may23_DW.valueIdx - 1] = may23_B.Memory1_ew;
          } else {
            if (may23_B.Memory2_p[0] == 3) {
              /* Transition: '<S167>:216' */
              if (may23_B.Memory2_p[1] == 0) {
                /* Transition: '<S167>:220' */
                may23_B.complete = -1;
              } else {
                /* Transition: '<S167>:226' */
                may23_B.complete = may23_B.Memory2_p[1];
              }

              may23_DW.is_c95_ethercat = may23_IN_Error;
              may23_DW.temporalCounter_i1_n4 = 0U;
            }
          }
          break;

         case may23_IN_disableInt:
          /* During 'disableInt': '<S167>:156' */
          if (may23_B.Memory2_p[0] == 3) {
            /* Transition: '<S167>:212' */
            /* Transition: '<S167>:218' */
            if (may23_B.Memory2_p[1] == 0) {
              /* Transition: '<S167>:220' */
              may23_B.complete = -1;
            } else {
              /* Transition: '<S167>:226' */
              may23_B.complete = may23_B.Memory2_p[1];
            }

            may23_DW.is_c95_ethercat = may23_IN_Error;
            may23_DW.temporalCounter_i1_n4 = 0U;
          } else {
            if (may23_B.Memory2_p[0] == 2) {
              /* Transition: '<S167>:143' */
              may23_DW.is_c95_ethercat = may23_IN_ReceivedInt;

              /* Entry 'ReceivedInt': '<S167>:142' */
              may23_B.intSDOValues[may23_DW.valueIdx - 1] = may23_B.Memory_o;
            }
          }
          break;

         case may23_IN_setup_a:
          /* During 'setup': '<S167>:139' */
          if (may23_B.MasterStateOut >= 4) {
            /* Transition: '<S167>:145' */
            may23_DW.is_c95_ethercat = may23_IN_ReadNextInt;

            /* Entry 'ReadNextInt': '<S167>:141' */
            may23_DW.valueIdx++;
            may23_B.SDOCommand[0] = 1;
            may23_B.SDOCommand[1] = (int32_T)
              may23_B.intAddresses[may23_DW.valueIdx - 1];
            may23_B.SDOCommand[2] = (int32_T)
              may23_B.intAddresses[may23_DW.valueIdx + 11];
          }
          break;

         default:
          /* During 'startFloats': '<S167>:183' */
          /* Transition: '<S167>:185' */
          may23_DW.is_c95_ethercat = may23_IN_ReadNextFloat;

          /* Entry 'ReadNextFloat': '<S167>:184' */
          may23_DW.valueIdx++;
          may23_B.SDOCommand[0] = 1;
          may23_B.SDOCommand[1] = (int32_T)
            may23_B.floatAddresses[may23_DW.valueIdx - 1];
          may23_B.SDOCommand[2] = (int32_T)
            may23_B.floatAddresses[may23_DW.valueIdx + 11];
          break;
        }
      }

      /* End of Chart: '<S78>/SDO read machine' */

      /* MATLAB Function: '<S78>/split out constants1' incorporates:
       *  Constant: '<S66>/force primary only'
       */
      /* MATLAB Function 'EtherCAT Subsystem/Arm 2/split out constants1': '<S176>:1' */
      /* '<S176>:1:3' */
      /* '<S176>:1:4' */
      i = may23_B.intSDOValues[3] & 1;
      if (may23_P.forceprimaryonly_Value != 0.0) {
        /* '<S176>:1:6' */
        i = 0;
      }

      /* '<S176>:1:8' */
      /* '<S176>:1:9' */
      if ((may23_B.intSDOValues[3] >> 2 & 1U) == 0U) {
        /* '<S176>:1:13' */
        /* '<S176>:1:14' */
        robotOrientation = 1;
      } else {
        /* '<S176>:1:16' */
        robotOrientation = -1;
      }

      /* '<S176>:1:22' */
      if ((may23_B.intSDOValues[3] >> 3 & 1) == 1) {
        /* '<S176>:1:32' */
        /* '<S176>:1:33' */
        orientation = 1;
      } else {
        /* '<S176>:1:35' */
        orientation = -1;
      }

      if ((may23_B.intSDOValues[3] >> 4 & 1) == 1) {
        /* '<S176>:1:32' */
        /* '<S176>:1:33' */
        b_orientation = 1;
      } else {
        /* '<S176>:1:35' */
        b_orientation = -1;
      }

      /* '<S176>:1:25' */
      if ((may23_B.intSDOValues[3] >> 5 & 1) == 1) {
        /* '<S176>:1:32' */
        /* '<S176>:1:33' */
        c_orientation = 1;
      } else {
        /* '<S176>:1:35' */
        c_orientation = -1;
      }

      if ((may23_B.intSDOValues[3] >> 6 & 1) == 1) {
        /* '<S176>:1:32' */
        /* '<S176>:1:33' */
        d_orientation = 1;
      } else {
        /* '<S176>:1:35' */
        d_orientation = -1;
      }

      /* '<S176>:1:28' */
      may23_B.hasSecondary = i;
      may23_B.hasFT = may23_B.intSDOValues[3] >> 1 & 1;
      may23_B.robotOrientation = robotOrientation;
      may23_B.motorOrientation[0] = -(real_T)orientation;
      may23_B.motorOrientation[1] = -(real_T)b_orientation;
      may23_B.encOrientation[0] = c_orientation;
      may23_B.encOrientation[1] = d_orientation;
      may23_B.absEnc = may23_B.intSDOValues[3] >> 7 & 1;

      /* End of MATLAB Function: '<S78>/split out constants1' */

      /* MATLAB Function: '<S185>/MATLAB Function' */
      may23_MATLABFunction(may23_B.primaryposition, may23_B.secondaryposition,
                           may23_B.absEnc, &may23_B.sf_MATLABFunction_o);

      /* DataTypeConversion: '<S177>/Data Type Conversion' */
      may23_B.DataTypeConversion_mme = may23_B.torque_b;

      /* DataTypeConversion: '<S177>/A2M1Convert' */
      may23_B.A2M1Convert[0] = may23_B.sf_MATLABFunction_o.prime_out;
      may23_B.A2M1Convert[1] = may23_B.sf_MATLABFunction_o.sec_out;
      may23_B.A2M1Convert[2] = may23_B.primaryvelocity;
      may23_B.A2M1Convert[3] = may23_B.DataTypeConversion_mme;
      may23_B.A2M1Convert[4] = may23_B.digitalinput;

      /* Outputs for Atomic SubSystem: '<S162>/EMCY Message pump' */
      may23_EMCYMessagepump_p();

      /* End of Outputs for SubSystem: '<S162>/EMCY Message pump' */

      /* MATLAB Function: '<S78>/split out constants' */
      /* MATLAB Function 'EtherCAT Subsystem/Arm 2/split out constants': '<S175>:1' */
      /* '<S175>:1:3' */
      /* '<S175>:1:4' */
      /* '<S175>:1:5' */
      /* '<S175>:1:6' */
      may23_B.encoderCounts[0] = 0.0;
      may23_B.calibPinAngles[0] = 0.0;
      may23_B.absAngOffsets[0] = 0.0;
      may23_B.linkLengths[0] = 0.0;
      may23_B.encoderCounts[1] = 0.0;
      may23_B.calibPinAngles[1] = 0.0;
      may23_B.absAngOffsets[1] = 0.0;
      may23_B.linkLengths[1] = 0.0;

      /* '<S175>:1:7' */
      may23_B.L2CalibPinOffset = 0.0;

      /* '<S175>:1:8' */
      may23_B.continuousTorques[0] = 0.0;
      may23_B.continuousTorques[1] = 0.0;

      /* '<S175>:1:9' */
      /* '<S175>:1:10' */
      /* '<S175>:1:11' */
      may23_B.gearRatios[0] = 0.0;
      may23_B.offsetRads[0] = 0.0;
      may23_B.offsetRadsPrimary[0] = 0.0;
      may23_B.gearRatios[1] = 0.0;
      may23_B.offsetRads[1] = 0.0;
      may23_B.offsetRadsPrimary[1] = 0.0;

      /* '<S175>:1:12' */
      may23_B.isCalibrated = 0.0;

      /* '<S175>:1:13' */
      may23_B.FTSensorOffset = 0.0;

      /* '<S175>:1:14' */
      may23_B.robotRevision_g = 0.0;

      /* '<S175>:1:16' */
      may23_B.constantsReady = may23_B.complete;
      if (may23_B.complete > 0) {
        /* '<S175>:1:22' */
        may23_B.encoderCounts[0] = may23_B.intSDOValues[4];
        may23_B.encoderCounts[1] = may23_B.intSDOValues[5];

        /* '<S175>:1:24' */
        may23_B.isCalibrated = may23_B.intSDOValues[7];

        /* '<S175>:1:25' */
        may23_B.offsetRads[0] = (real_T)may23_B.intSDOValues[8] / 1000.0;
        may23_B.offsetRads[1] = (real_T)may23_B.intSDOValues[9] / 1000.0;

        /* '<S175>:1:26' */
        may23_B.offsetRadsPrimary[0] = (real_T)may23_B.intSDOValues[10] / 1000.0;
        may23_B.offsetRadsPrimary[1] = (real_T)may23_B.intSDOValues[11] / 1000.0;

        /* '<S175>:1:28' */
        may23_B.FTSensorOffset = may23_B.floatSDOValues[0];

        /* '<S175>:1:29' */
        may23_B.calibPinAngles[0] = may23_B.floatSDOValues[1];
        may23_B.calibPinAngles[1] = may23_B.floatSDOValues[2];

        /* '<S175>:1:30' */
        may23_B.absAngOffsets[0] = may23_B.floatSDOValues[3];
        may23_B.absAngOffsets[1] = may23_B.floatSDOValues[4];

        /* '<S175>:1:31' */
        may23_B.linkLengths[0] = may23_B.floatSDOValues[5];
        may23_B.linkLengths[1] = may23_B.floatSDOValues[6];

        /* '<S175>:1:32' */
        may23_B.L2CalibPinOffset = may23_B.floatSDOValues[7];

        /* '<S175>:1:33' */
        may23_B.continuousTorques[0] = may23_B.floatSDOValues[8];
        may23_B.continuousTorques[1] = may23_B.floatSDOValues[9];

        /* '<S175>:1:34' */
        may23_B.gearRatios[0] = may23_B.floatSDOValues[10];
        may23_B.gearRatios[1] = may23_B.floatSDOValues[11];

        /* '<S175>:1:35' */
        may23_B.robotRevision_g = may23_B.intSDOValues[2];
      } else {
        /* '<S175>:1:18' */
      }

      /* End of MATLAB Function: '<S78>/split out constants' */

      /* Selector: '<S180>/L2 select' incorporates:
       *  Constant: '<S162>/MotorIdx'
       */
      may23_B.offsetrads = may23_B.offsetRads[(int32_T)may23_P.MotorIdx_Value_f
        - 1];

      /* Selector: '<S180>/L2 select1' incorporates:
       *  Constant: '<S162>/MotorIdx'
       */
      may23_B.encorient = may23_B.encOrientation[(int32_T)
        may23_P.MotorIdx_Value_f - 1];

      /* Selector: '<S180>/L2 select2' incorporates:
       *  Constant: '<S162>/MotorIdx'
       */
      may23_B.L2select2 = may23_B.motorOrientation[(int32_T)
        may23_P.MotorIdx_Value_f - 1];

      /* Selector: '<S180>/L2 select3' incorporates:
       *  Constant: '<S162>/MotorIdx'
       */
      may23_B.L2select3 = may23_B.offsetRadsPrimary[(int32_T)
        may23_P.MotorIdx_Value_f - 1];

      /* Selector: '<S180>/L2 select4' incorporates:
       *  Constant: '<S162>/MotorIdx'
       */
      may23_B.L2select4 = may23_B.gearRatios[(int32_T)may23_P.MotorIdx_Value_f -
        1];

      /* Memory: '<S78>/Memory2' */
      may23_B.R2_maxContinuousTorque[0] = may23_DW.Memory2_PreviousInput_g[0];
      may23_B.R2_maxContinuousTorque[1] = may23_DW.Memory2_PreviousInput_g[1];

      /* Selector: '<S180>/L2 select5' incorporates:
       *  Constant: '<S162>/MotorIdx'
       */
      may23_B.L2select5 = may23_B.R2_maxContinuousTorque[(int32_T)
        may23_P.MotorIdx_Value_f - 1];

      /* MATLAB Function: '<S78>/Find Robot type' incorporates:
       *  Constant: '<S66>/ep part nums'
       *  Constant: '<S66>/nhp part nums'
       */
      may23_FindRobottype(may23_B.intSDOValues, may23_P.eppartnums_Value,
                          may23_P.nhppartnums_Value, &may23_B.sf_FindRobottype_i);

      /* Memory: '<S78>/Memory3' */
      may23_B.R2_constantsReady = may23_DW.Memory3_PreviousInput_k;

      /* MATLAB Function: '<S180>/countsToRads' */
      /* MATLAB Function 'EtherCAT Subsystem/Arm 2/A2M1/PDO to Angles Subsystem/countsToRads': '<S196>:1' */
      /* '<S196>:1:3' */
      /* '<S196>:1:4' */
      /* '<S196>:1:8' */
      /* '<S196>:1:9' */
      /* '<S196>:1:12' */
      if (may23_B.R2_constantsReady != 1.0) {
        /* '<S196>:1:14' */
        /* '<S196>:1:15' */
        y = 0.0;

        /* '<S196>:1:16' */
        ticksPerRad = 0.0;

        /* '<S196>:1:17' */
        queueSizePrimary = 0.0;

        /* '<S196>:1:18' */
        torque = 0.0;
      } else {
        if (may23_B.hasSecondary != 0.0) {
          /* '<S196>:1:23' */
          /* '<S196>:1:33' */
          /* '<S196>:1:34' */
          /* '<S196>:1:35' */
          y = may23_B.A2M1Convert[1] / (may23_B.encoderCounts[1] /
            6.2831853071795862) * may23_B.encorient + may23_B.offsetrads;
        } else {
          /* '<S196>:1:25' */
          /* '<S196>:1:33' */
          /* '<S196>:1:34' */
          /* '<S196>:1:35' */
          y = may23_B.A2M1Convert[0] / (may23_B.encoderCounts[0] *
            may23_B.L2select4 / 6.2831853071795862) * may23_B.L2select2 +
            may23_B.L2select3;
        }

        /* '<S196>:1:28' */
        /* '<S196>:1:33' */
        ticksPerRad = may23_B.encoderCounts[0] * may23_B.L2select4 /
          6.2831853071795862;

        /* '<S196>:1:34' */
        /* '<S196>:1:35' */
        /* '<S196>:1:28' */
        queueSizePrimary = may23_B.A2M1Convert[0] / ticksPerRad *
          may23_B.L2select2 + may23_B.L2select3;

        /* '<S196>:1:28' */
        ticksPerRad = may23_B.A2M1Convert[2] / ticksPerRad * may23_B.L2select2;

        /* '<S196>:1:29' */
        torque = may23_B.A2M1Convert[3] / 1000.0 * may23_B.L2select5 *
          may23_B.L2select4 * may23_B.L2select2;
      }

      may23_B.LinkAngle_i = y;
      may23_B.PrimaryLinkAngle_j = queueSizePrimary;
      may23_B.PrimaryLinkVel_k = ticksPerRad;
      may23_B.torque_h = torque;
      y = rt_roundd_snf((real_T)((uint64_T)rt_roundd_snf(may23_B.A2M1Convert[4])
        >> 20ULL));
      if (y < 1.8446744073709552E+19) {
        if (y >= 0.0) {
          tmp = (uint64_T)y;
        } else {
          tmp = 0ULL;
        }
      } else {
        tmp = MAX_uint64_T;
      }

      may23_B.digitalInputs_g[0] = (real_T)(tmp & 1ULL);
      y = rt_roundd_snf((real_T)((uint64_T)rt_roundd_snf(may23_B.A2M1Convert[4])
        >> 21ULL));
      if (y < 1.8446744073709552E+19) {
        if (y >= 0.0) {
          tmp = (uint64_T)y;
        } else {
          tmp = 0ULL;
        }
      } else {
        tmp = MAX_uint64_T;
      }

      may23_B.digitalInputs_g[1] = (real_T)(tmp & 1ULL);
      may23_B.digitalDiagnostics_p = may23_B.A2M1Convert[4];
      y = rt_roundd_snf((real_T)((uint64_T)rt_roundd_snf(may23_B.A2M1Convert[4])
        >> 16ULL));
      if (y < 1.8446744073709552E+19) {
        if (y >= 0.0) {
          tmp = (uint64_T)y;
        } else {
          tmp = 0ULL;
        }
      } else {
        tmp = MAX_uint64_T;
      }

      may23_B.calibrationButton = (real_T)(tmp & 1ULL);
      y = rt_roundd_snf((real_T)((uint64_T)rt_roundd_snf(may23_B.A2M1Convert[4])
        >> 19ULL));
      if (y < 1.8446744073709552E+19) {
        if (y >= 0.0) {
          tmp = (uint64_T)y;
        } else {
          tmp = 0ULL;
        }
      } else {
        tmp = MAX_uint64_T;
      }

      may23_B.epGripSensor = !((tmp & 1ULL) != 0.0);

      /* End of MATLAB Function: '<S180>/countsToRads' */

      /* S-Function (BKINethercatpdorxElmoDrive): '<S197>/BKIN PDO Receive ElmoDrive' */

      /* Level2 S-Function Block: '<S197>/BKIN PDO Receive ElmoDrive' (BKINethercatpdorxElmoDrive) */
      {
        SimStruct *rts = may23_M->childSfunctions[15];
        sfcnOutputs(rts,1);
      }

      /* Switch: '<S204>/Switch' incorporates:
       *  Constant: '<S204>/Constant'
       */
      if (may23_B.MasterStateOut >= may23_P.Switch_Threshold_pr) {
        may23_B.Switch_mq = may23_B.statusword;
      } else {
        may23_B.Switch_mq = may23_P.Constant_Value_cc;
      }

      /* End of Switch: '<S204>/Switch' */

      /* MATLAB Function: '<S163>/cleanword' */
      may23_cleanword(may23_B.Switch_mq, &may23_B.sf_cleanword_i);

      /* Switch: '<S203>/Switch' incorporates:
       *  Constant: '<S203>/Constant'
       */
      if (may23_B.MasterStateOut >= may23_P.Switch_Threshold_kt) {
        may23_B.Switch_j = may23_B.statusregister;
      } else {
        may23_B.Switch_j = may23_P.Constant_Value_e;
      }

      /* End of Switch: '<S203>/Switch' */

      /* MATLAB Function: '<S197>/parse status register1' */
      may23_parsestatusregister(may23_B.Switch_j,
        &may23_B.sf_parsestatusregister1_d);

      /* RelationalOperator: '<S198>/Compare' incorporates:
       *  Constant: '<S198>/Constant'
       */
      may23_B.Compare_c = (may23_B.MasterStateOut == may23_P.Compare_const_d);

      /* Chart: '<S163>/Whistle state' */
      may23_Whistlestate(may23_B.sf_cleanword_i.out_val,
                         may23_B.sf_parsestatusregister1_d.allOK,
                         may23_B.sf_parsestatusregister1_d.motorOn,
                         may23_B.sf_parsestatusregister1_d.eStopOut,
                         may23_B.Compare_c, may23_B.forceMotorState,
                         may23_B.max_errors_to_fault, &may23_B.sf_Whistlestate_m,
                         &may23_DW.sf_Whistlestate_m);

      /* S-Function (BKINethercatpdotx): '<S163>/BKIN EtherCAT PDO Transmit ' */

      /* Level2 S-Function Block: '<S163>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
      {
        SimStruct *rts = may23_M->childSfunctions[16];
        sfcnOutputs(rts,1);
      }

      /* MATLAB Function: '<S205>/MATLAB Function' */
      may23_MATLABFunction(may23_B.positionprimary, may23_B.positionsecondary,
                           may23_B.absEnc, &may23_B.sf_MATLABFunction_ac);

      /* DataTypeConversion: '<S197>/Data Type Conversion' */
      may23_B.DataTypeConversion_ex = may23_B.torque_i;

      /* DataTypeConversion: '<S197>/A2M2Convert' */
      may23_B.A2M2Convert[0] = may23_B.sf_MATLABFunction_ac.prime_out;
      may23_B.A2M2Convert[1] = may23_B.sf_MATLABFunction_ac.sec_out;
      may23_B.A2M2Convert[2] = may23_B.velocityprimary;
      may23_B.A2M2Convert[3] = may23_B.DataTypeConversion_ex;
      may23_B.A2M2Convert[4] = may23_B.digitalinput_o;

      /* Outputs for Atomic SubSystem: '<S163>/EMCY Message pump' */
      may23_EMCYMessagepump_hr();

      /* End of Outputs for SubSystem: '<S163>/EMCY Message pump' */

      /* Selector: '<S200>/L2 select' incorporates:
       *  Constant: '<S163>/MotorIdx'
       */
      may23_B.L2select = may23_B.offsetRads[(int32_T)may23_P.MotorIdx_Value_b -
        1];

      /* Selector: '<S200>/L2 select1' incorporates:
       *  Constant: '<S163>/MotorIdx'
       */
      may23_B.L2select1 = may23_B.encOrientation[(int32_T)
        may23_P.MotorIdx_Value_b - 1];

      /* Selector: '<S200>/L2 select2' incorporates:
       *  Constant: '<S163>/MotorIdx'
       */
      may23_B.L2select2_m = may23_B.motorOrientation[(int32_T)
        may23_P.MotorIdx_Value_b - 1];

      /* Selector: '<S200>/L2 select3' incorporates:
       *  Constant: '<S163>/MotorIdx'
       */
      may23_B.L2select3_l = may23_B.offsetRadsPrimary[(int32_T)
        may23_P.MotorIdx_Value_b - 1];

      /* Selector: '<S200>/L2 select4' incorporates:
       *  Constant: '<S163>/MotorIdx'
       */
      may23_B.L2select4_o = may23_B.gearRatios[(int32_T)may23_P.MotorIdx_Value_b
        - 1];

      /* Selector: '<S200>/L2 select5' incorporates:
       *  Constant: '<S163>/MotorIdx'
       */
      may23_B.L2select5_k = may23_B.R2_maxContinuousTorque[(int32_T)
        may23_P.MotorIdx_Value_b - 1];

      /* MATLAB Function: '<S200>/countsToRads' */
      /* MATLAB Function 'EtherCAT Subsystem/Arm 2/A2M2/PDO to Angles Subsystem/countsToRads': '<S216>:1' */
      /* '<S216>:1:3' */
      /* '<S216>:1:4' */
      /* '<S216>:1:8' */
      if (may23_B.R2_constantsReady != 1.0) {
        /* '<S216>:1:10' */
        /* '<S216>:1:11' */
        y = 0.0;

        /* '<S216>:1:12' */
        ticksPerRad = 0.0;

        /* '<S216>:1:13' */
        queueSizePrimary = 0.0;

        /* '<S216>:1:14' */
        torque = 0.0;
      } else {
        if (may23_B.hasSecondary != 0.0) {
          /* '<S216>:1:19' */
          /* '<S216>:1:29' */
          /* '<S216>:1:30' */
          /* '<S216>:1:31' */
          y = may23_B.A2M2Convert[1] / (may23_B.encoderCounts[1] /
            6.2831853071795862) * may23_B.L2select1 + may23_B.L2select;
        } else {
          /* '<S216>:1:21' */
          /* '<S216>:1:29' */
          /* '<S216>:1:30' */
          /* '<S216>:1:31' */
          y = may23_B.A2M2Convert[0] / (may23_B.encoderCounts[0] *
            may23_B.L2select4_o / 6.2831853071795862) * may23_B.L2select2_m +
            may23_B.L2select3_l;
        }

        /* '<S216>:1:24' */
        /* '<S216>:1:29' */
        ticksPerRad = may23_B.encoderCounts[0] * may23_B.L2select4_o /
          6.2831853071795862;

        /* '<S216>:1:30' */
        /* '<S216>:1:31' */
        /* '<S216>:1:24' */
        queueSizePrimary = may23_B.A2M2Convert[0] / ticksPerRad *
          may23_B.L2select2_m + may23_B.L2select3_l;

        /* '<S216>:1:24' */
        ticksPerRad = may23_B.A2M2Convert[2] / ticksPerRad * may23_B.L2select2_m;

        /* '<S216>:1:25' */
        torque = may23_B.A2M2Convert[3] / 1000.0 * may23_B.L2select5_k *
          may23_B.L2select4_o * may23_B.L2select2_m;
      }

      may23_B.LinkAngle = y;
      may23_B.PrimaryLinkAngle = queueSizePrimary;
      may23_B.PrimaryLinkVel = ticksPerRad;
      may23_B.torque = torque;
      y = rt_roundd_snf((real_T)((uint64_T)rt_roundd_snf(may23_B.A2M2Convert[4])
        >> 20ULL));
      if (y < 1.8446744073709552E+19) {
        if (y >= 0.0) {
          tmp = (uint64_T)y;
        } else {
          tmp = 0ULL;
        }
      } else {
        tmp = MAX_uint64_T;
      }

      may23_B.digitalInputs[0] = (real_T)(tmp & 1ULL);
      y = rt_roundd_snf((real_T)((uint64_T)rt_roundd_snf(may23_B.A2M2Convert[4])
        >> 21ULL));
      if (y < 1.8446744073709552E+19) {
        if (y >= 0.0) {
          tmp = (uint64_T)y;
        } else {
          tmp = 0ULL;
        }
      } else {
        tmp = MAX_uint64_T;
      }

      may23_B.digitalInputs[1] = (real_T)(tmp & 1ULL);
      may23_B.digitalDiagnostics = may23_B.A2M2Convert[4];

      /* End of MATLAB Function: '<S200>/countsToRads' */

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M1_LinkAngle = may23_B.LinkAngle_i;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M1_CurrentLimitEnabled =
        may23_B.sf_parsestatusregister1_g.currentLimitEnabled;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M2_LinkAngle = may23_B.LinkAngle;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M2_PrimaryLinkAngle = may23_B.PrimaryLinkAngle;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M2_PrimaryLinkVelocity = may23_B.PrimaryLinkVel;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M2_RecordedTorque = may23_B.torque;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M2_digitalInputs[0] = may23_B.digitalInputs[0];
      may23_B.R2M2_digitalInputs[1] = may23_B.digitalInputs[1];

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M2_digitalDiagnostics = may23_B.digitalDiagnostics;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      for (i = 0; i < 5; i++) {
        may23_B.R2M2_EMCY_codes[i] = may23_B.sf_passemcy_e.EMCYMsg[i];
      }

      /* End of SignalConversion generated from: '<S78>/Signal Conversion' */

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M2_CurrentLimitEnabled =
        may23_B.sf_parsestatusregister1_d.currentLimitEnabled;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M1_PrimaryLinkAngle = may23_B.PrimaryLinkAngle_j;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M1_PrimaryLinkVelocity = may23_B.PrimaryLinkVel_k;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M1_RecordedTorque = may23_B.torque_h;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M1_digitalInputs[0] = may23_B.digitalInputs_g[0];
      may23_B.R2M1_digitalInputs[1] = may23_B.digitalInputs_g[1];

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2M1_digitalDiagnostics = may23_B.digitalDiagnostics_p;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2_calibrationButton = may23_B.calibrationButton;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      may23_B.R2_EPGripSensor = may23_B.epGripSensor;

      /* SignalConversion generated from: '<S78>/Signal Conversion' */
      for (i = 0; i < 5; i++) {
        may23_B.R2M1_EMCY_codes[i] = may23_B.sf_passemcy_c.EMCYMsg[i];
      }

      /* End of SignalConversion generated from: '<S78>/Signal Conversion' */

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_RobotType = may23_B.sf_FindRobottype_i.robotType;

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_absAngleOffset[0] = may23_B.absAngOffsets[0];
      may23_B.R2_absAngleOffset[1] = may23_B.absAngOffsets[1];

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_LinkLength[0] = may23_B.linkLengths[0];
      may23_B.R2_LinkLength[1] = may23_B.linkLengths[1];

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_L2CalibPinOffset = may23_B.L2CalibPinOffset;

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_maxContinuousTorque_c[0] = may23_B.R2_maxContinuousTorque[0];

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_gearRatios[0] = may23_B.gearRatios[0];

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_maxContinuousTorque_c[1] = may23_B.R2_maxContinuousTorque[1];

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_gearRatios[1] = may23_B.gearRatios[1];

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_isCalibrated = may23_B.isCalibrated;

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_OffsetRads[0] = may23_B.offsetRads[0];
      may23_B.R2_OffsetRads[1] = may23_B.offsetRads[1];

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_OffsetRadsPrimary[0] = may23_B.offsetRadsPrimary[0];
      may23_B.R2_OffsetRadsPrimary[1] = may23_B.offsetRadsPrimary[1];

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_RobotRevision = may23_B.robotRevision_g;

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_constantsReady_b = may23_B.R2_constantsReady;

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_hasSecondary = may23_B.hasSecondary;

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_hasFT = may23_B.hasFT;

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_robotOrientation = may23_B.robotOrientation;

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_motorOrientation[0] = may23_B.motorOrientation[0];
      may23_B.R2_motorOrientation[1] = may23_B.motorOrientation[1];

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_encOrientation[0] = may23_B.encOrientation[0];
      may23_B.R2_encOrientation[1] = may23_B.encOrientation[1];

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_encodercounts[0] = may23_B.encoderCounts[0];
      may23_B.R2_encodercounts[1] = may23_B.encoderCounts[1];

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_FTSensorAngleOffset = may23_B.FTSensorOffset;

      /* SignalConversion generated from: '<S78>/Signal Conversion1' */
      may23_B.R2_calibPinAngle[0] = may23_B.calibPinAngles[0];
      may23_B.R2_calibPinAngle[1] = may23_B.calibPinAngles[1];

      /* Outputs for Atomic SubSystem: '<S172>/Read Drive 3 SDO' */
      may23_ReadDrive3SDO_d();

      /* End of Outputs for SubSystem: '<S172>/Read Drive 3 SDO' */

      /* RateTransition: '<S172>/Rate Transition' */
      may23_B.RateTransition_ep = may23_B.sf_converter_c.int32Out;

      /* RateTransition: '<S172>/Rate Transition1' */
      may23_B.RateTransition1_p = may23_B.sf_converter_c.doubleOut;

      /* RateTransition: '<S172>/Rate Transition2' */
      may23_B.RateTransition2_j[0] = may23_B.BKINEtherCATAsyncSDOUpload1_o2;
      may23_B.RateTransition2_j[1] = may23_B.sf_MATLABFunction_g3.out_err_code;

      /* Outputs for Enabled SubSystem: '<S78>/M2 AbsEnc Calibration' incorporates:
       *  EnablePort: '<S166>/Enable'
       */
      /* Outputs for Enabled SubSystem: '<S78>/M1 AbsEnc Calibration' incorporates:
       *  EnablePort: '<S165>/Enable'
       */
      /* Constant: '<S78>/enableCalibration' */
      if (may23_P.enableCalibration_Value_k > 0.0) {
        if (!may23_DW.M1AbsEncCalibration_MODE) {
          /* InitializeConditions for Memory: '<S165>/Memory' */
          may23_DW.Memory_PreviousInput_a = may23_P.Memory_InitialCondition_ec;

          /* InitializeConditions for Memory: '<S165>/Memory1' */
          may23_DW.Memory1_PreviousInput_b[0] =
            may23_P.Memory1_InitialCondition_p;
          may23_DW.Memory1_PreviousInput_b[1] =
            may23_P.Memory1_InitialCondition_p;

          /* SystemReset for Chart: '<S165>/AbsEncoder machine' */
          may23_AbsEncodermachine_Reset(&may23_B.sf_AbsEncodermachine_j,
            &may23_DW.sf_AbsEncodermachine_j);
          may23_DW.M1AbsEncCalibration_MODE = true;
        }

        /* MATLAB Function: '<S165>/set-up values' */
        may23_setupvalues(&may23_B.sf_setupvalues_p);

        /* Memory: '<S165>/Memory' */
        may23_B.Memory_pj = may23_DW.Memory_PreviousInput_a;

        /* Memory: '<S165>/Memory1' */
        may23_B.Memory1_lg[0] = may23_DW.Memory1_PreviousInput_b[0];
        may23_B.Memory1_lg[1] = may23_DW.Memory1_PreviousInput_b[1];

        /* Chart: '<S165>/AbsEncoder machine' */
        may23_AbsEncodermachine(may23_B.sf_setupvalues_p.setupValues,
          may23_B.sf_setupvalues_p.setupValuesCount,
          may23_B.sf_setupvalues_p.pollValues,
          may23_B.sf_setupvalues_p.encoderValues,
          may23_B.sf_setupvalues_p.encoderValuesCount, may23_B.Memory_pj,
          may23_B.Memory1_lg, &may23_B.sf_AbsEncodermachine_j,
          &may23_DW.sf_AbsEncodermachine_j);

        /* S-Function (BKINethercatasyncsdodownload): '<S165>/BKIN EtherCAT Async SDO Download' */
        {
          int8_T *sigInputPtr;
          int32_T *sigStatusPtr;
          uint32_T *perror;
          int32_T *enInputPtr;
          int_T deviceIndex;
          int_T res;
          int_T state;
          int32_T *indexInputPtr;
          int32_T *subIndexInputPtr;
          deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_a[0];
          perror = &may23_B.BKINEtherCATAsyncSDODownload_o2_g;
          *perror = 0;                 // preset to no error
          if (deviceIndex != NO_ETHERCAT) {
            state = xpcEtherCATgetState( deviceIndex );
            if (state >= 2 ) {
              sigStatusPtr = &may23_B.BKINEtherCATAsyncSDODownload_o1_d;
              sigInputPtr = (int8_T*)&may23_B.sf_AbsEncodermachine_j.setupData[0];
              enInputPtr = &may23_B.sf_AbsEncodermachine_j.setupData[1];
              indexInputPtr = &may23_B.sf_AbsEncodermachine_j.setupData[2];
              subIndexInputPtr = &may23_B.sf_AbsEncodermachine_j.setupData[3];
              if (may23_DW.BKINEtherCATAsyncSDODownload_IWORK_a[7] != 0) {
                res = ecatAsyncSDODownload(deviceIndex,
                  1003,
                  (unsigned short)*indexInputPtr,
                  (unsigned char)*subIndexInputPtr,
                  (void *)sigInputPtr,
                  1*4,
                  500,
                  658984277,
                  sigStatusPtr,
                  *enInputPtr);
                *perror = res;
              } else {
                *sigStatusPtr = 0;
              }

              may23_DW.BKINEtherCATAsyncSDODownload_IWORK_a[7] = 1;
              ;
            }
          }
        }

        /* S-Function (BKINethercatasyncsdoupload): '<S165>/BKIN EtherCAT Async SDO Upload' */
        {
          int8_T *sigOutputPtr;
          int32_T *sigStatusPtr;
          uint32_T *perror;
          int32_T *enInputPtr;
          int_T deviceIndex;
          static int counter= 0;
          int_T actLen;
          int_T res;
          int_T state;
          int32_T *indexInputPtr;
          int32_T *subIndexInputPtr;
          deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_g[0];
          perror = &may23_B.BKINEtherCATAsyncSDOUpload_o3_c;
          *perror = 0;                 // preset to no error
          if (deviceIndex != NO_ETHERCAT) {
            state = xpcEtherCATgetState( deviceIndex );
            if (state >= 2 ) {
              sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload_o1_d2;
              sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload_o2_f;
              enInputPtr = &may23_B.sf_AbsEncodermachine_j.SDORequest[0];
              indexInputPtr = &may23_B.sf_AbsEncodermachine_j.SDORequest[1];
              subIndexInputPtr = &may23_B.sf_AbsEncodermachine_j.SDORequest[2];
              if (may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_g[7] != 0) {
                res = ecatAsyncSDOUpload(deviceIndex,
                  1003,
                  (unsigned short)*indexInputPtr,
                  (unsigned char)*subIndexInputPtr,
                  (void *)sigOutputPtr,
                  1*4,
                  &actLen,
                  500,
                  658984278,
                  sigStatusPtr,
                  *enInputPtr);
                *perror = res;
              }

              may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_g[7] = 1;
              ;
            }
          }
        }

        srUpdateBC(may23_DW.M1AbsEncCalibration_SubsysRanBC);
        if (!may23_DW.M2AbsEncCalibration_MODE) {
          /* InitializeConditions for Memory: '<S166>/Memory' */
          may23_DW.Memory_PreviousInput_po = may23_P.Memory_InitialCondition_pu;

          /* InitializeConditions for Memory: '<S166>/Memory1' */
          may23_DW.Memory1_PreviousInput_ck[0] =
            may23_P.Memory1_InitialCondition_ai;
          may23_DW.Memory1_PreviousInput_ck[1] =
            may23_P.Memory1_InitialCondition_ai;

          /* SystemReset for Chart: '<S166>/AbsEncoder machine' */
          may23_AbsEncodermachine_Reset(&may23_B.sf_AbsEncodermachine_n,
            &may23_DW.sf_AbsEncodermachine_n);
          may23_DW.M2AbsEncCalibration_MODE = true;
        }

        /* MATLAB Function: '<S166>/set-up values' */
        may23_setupvalues(&may23_B.sf_setupvalues_o);

        /* Memory: '<S166>/Memory' */
        may23_B.Memory_i = may23_DW.Memory_PreviousInput_po;

        /* Memory: '<S166>/Memory1' */
        may23_B.Memory1_n[0] = may23_DW.Memory1_PreviousInput_ck[0];
        may23_B.Memory1_n[1] = may23_DW.Memory1_PreviousInput_ck[1];

        /* Chart: '<S166>/AbsEncoder machine' */
        may23_AbsEncodermachine(may23_B.sf_setupvalues_o.setupValues,
          may23_B.sf_setupvalues_o.setupValuesCount,
          may23_B.sf_setupvalues_o.pollValues,
          may23_B.sf_setupvalues_o.encoderValues,
          may23_B.sf_setupvalues_o.encoderValuesCount, may23_B.Memory_i,
          may23_B.Memory1_n, &may23_B.sf_AbsEncodermachine_n,
          &may23_DW.sf_AbsEncodermachine_n);

        /* S-Function (BKINethercatasyncsdodownload): '<S166>/BKIN EtherCAT Async SDO Download' */
        {
          int8_T *sigInputPtr;
          int32_T *sigStatusPtr;
          uint32_T *perror;
          int32_T *enInputPtr;
          int_T deviceIndex;
          int_T res;
          int_T state;
          int32_T *indexInputPtr;
          int32_T *subIndexInputPtr;
          deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_g[0];
          perror = &may23_B.BKINEtherCATAsyncSDODownload_o2_f;
          *perror = 0;                 // preset to no error
          if (deviceIndex != NO_ETHERCAT) {
            state = xpcEtherCATgetState( deviceIndex );
            if (state >= 2 ) {
              sigStatusPtr = &may23_B.BKINEtherCATAsyncSDODownload_o1_f;
              sigInputPtr = (int8_T*)&may23_B.sf_AbsEncodermachine_n.setupData[0];
              enInputPtr = &may23_B.sf_AbsEncodermachine_n.setupData[1];
              indexInputPtr = &may23_B.sf_AbsEncodermachine_n.setupData[2];
              subIndexInputPtr = &may23_B.sf_AbsEncodermachine_n.setupData[3];
              if (may23_DW.BKINEtherCATAsyncSDODownload_IWORK_g[7] != 0) {
                res = ecatAsyncSDODownload(deviceIndex,
                  1004,
                  (unsigned short)*indexInputPtr,
                  (unsigned char)*subIndexInputPtr,
                  (void *)sigInputPtr,
                  1*4,
                  500,
                  658984287,
                  sigStatusPtr,
                  *enInputPtr);
                *perror = res;
              } else {
                *sigStatusPtr = 0;
              }

              may23_DW.BKINEtherCATAsyncSDODownload_IWORK_g[7] = 1;
              ;
            }
          }
        }

        /* S-Function (BKINethercatasyncsdoupload): '<S166>/BKIN EtherCAT Async SDO Upload' */
        {
          int8_T *sigOutputPtr;
          int32_T *sigStatusPtr;
          uint32_T *perror;
          int32_T *enInputPtr;
          int_T deviceIndex;
          static int counter= 0;
          int_T actLen;
          int_T res;
          int_T state;
          int32_T *indexInputPtr;
          int32_T *subIndexInputPtr;
          deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK[0];
          perror = &may23_B.BKINEtherCATAsyncSDOUpload_o3;
          *perror = 0;                 // preset to no error
          if (deviceIndex != NO_ETHERCAT) {
            state = xpcEtherCATgetState( deviceIndex );
            if (state >= 2 ) {
              sigOutputPtr = (int8_T*)&may23_B.BKINEtherCATAsyncSDOUpload_o1_k1;
              sigStatusPtr = &may23_B.BKINEtherCATAsyncSDOUpload_o2;
              enInputPtr = &may23_B.sf_AbsEncodermachine_n.SDORequest[0];
              indexInputPtr = &may23_B.sf_AbsEncodermachine_n.SDORequest[1];
              subIndexInputPtr = &may23_B.sf_AbsEncodermachine_n.SDORequest[2];
              if (may23_DW.BKINEtherCATAsyncSDOUpload_IWORK[7] != 0) {
                res = ecatAsyncSDOUpload(deviceIndex,
                  1004,
                  (unsigned short)*indexInputPtr,
                  (unsigned char)*subIndexInputPtr,
                  (void *)sigOutputPtr,
                  1*4,
                  &actLen,
                  500,
                  658984288,
                  sigStatusPtr,
                  *enInputPtr);
                *perror = res;
              }

              may23_DW.BKINEtherCATAsyncSDOUpload_IWORK[7] = 1;
              ;
            }
          }
        }

        srUpdateBC(may23_DW.M2AbsEncCalibration_SubsysRanBC);
      } else {
        may23_DW.M1AbsEncCalibration_MODE = false;
        may23_DW.M2AbsEncCalibration_MODE = false;
      }

      /* End of Constant: '<S78>/enableCalibration' */
      /* End of Outputs for SubSystem: '<S78>/M1 AbsEnc Calibration' */
      /* End of Outputs for SubSystem: '<S78>/M2 AbsEnc Calibration' */

      /* Outputs for Atomic SubSystem: '<S78>/SDO reading' */
      may23_SDOreading_f();

      /* End of Outputs for SubSystem: '<S78>/SDO reading' */

      /* Outputs for Atomic SubSystem: '<S78>/SDO writing' */
      may23_SDOwriting_l();

      /* End of Outputs for SubSystem: '<S78>/SDO writing' */

      /* MATLAB Function: '<S170>/MATLAB Function1' incorporates:
       *  Constant: '<S170>/override_grip'
       */
      may23_MATLABFunction1(may23_B.epGripSensor,
                            may23_B.sf_FindRobottype_i.robotType,
                            may23_P.override_grip_Value_p, may23_B.Memory2,
                            &may23_B.sf_MATLABFunction1_c);

      /* S-Function (BKINethercatpdotx): '<S170>/BKIN EtherCAT PDO Transmit ' */

      /* Level2 S-Function Block: '<S170>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
      {
        SimStruct *rts = may23_M->childSfunctions[17];
        sfcnOutputs(rts,1);
      }

      /* S-Function (BKINethercatpdotx): '<S170>/BKIN EtherCAT PDO Transmit 1' */

      /* Level2 S-Function Block: '<S170>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
      {
        SimStruct *rts = may23_M->childSfunctions[18];
        sfcnOutputs(rts,1);
      }

      srUpdateBC(may23_DW.Arm2_SubsysRanBC);
    } else {
      if (may23_DW.Arm2_MODE) {
        /* Disable for Enabled SubSystem: '<S78>/M1 AbsEnc Calibration' */
        may23_DW.M1AbsEncCalibration_MODE = false;

        /* End of Disable for SubSystem: '<S78>/M1 AbsEnc Calibration' */

        /* Disable for Enabled SubSystem: '<S78>/M2 AbsEnc Calibration' */
        may23_DW.M2AbsEncCalibration_MODE = false;

        /* End of Disable for SubSystem: '<S78>/M2 AbsEnc Calibration' */
        may23_DW.Arm2_MODE = false;
      }
    }

    /* End of Outputs for SubSystem: '<S66>/Arm 2' */

    /* DataStoreWrite: '<S66>/Data Store Write' */
    may23_DW.ECATHardware[8] = may23_B.R1_robotOrientation;
    may23_DW.ECATHardware[9] = may23_B.R2_robotOrientation;

    /* DataTypeConversion: '<S82>/convert' */
    may23_B.convert[0] = may23_B.errVal;
    may23_B.convert[1] = may23_B.MasterStateOut;
    may23_B.convert[2] = may23_B.DCErrVal;
    may23_B.convert[3] = may23_B.MasterToNetworkClkDiff;
    may23_B.convert[4] = may23_B.DCInitState;
    may23_B.convert[5] = may23_B.NetworkToSlaveClkDiff;

    /* DataStoreWrite: '<S66>/Data Store Write' */
    may23_DW.ECATHardware[0] = may23_B.R1_maxContinuousTorque_i[0];
    may23_DW.ECATHardware[2] = may23_B.R2_maxContinuousTorque_c[0];
    may23_DW.ECATHardware[4] = may23_B.R1_gearRatios[0];
    may23_DW.ECATHardware[6] = may23_B.R2_gearRatios[0];
    may23_DW.ECATHardware[10] = may23_B.R1_motorOrientation[0];
    may23_DW.ECATHardware[12] = may23_B.R2_motorOrientation[0];

    /* DataTypeConversion: '<S82>/convert' */
    may23_B.convert[6] = may23_B.Switch_f[6];

    /* DataStoreWrite: '<S66>/Data Store Write' */
    may23_DW.ECATHardware[1] = may23_B.R1_maxContinuousTorque_i[1];
    may23_DW.ECATHardware[3] = may23_B.R2_maxContinuousTorque_c[1];
    may23_DW.ECATHardware[5] = may23_B.R1_gearRatios[1];
    may23_DW.ECATHardware[7] = may23_B.R2_gearRatios[1];
    may23_DW.ECATHardware[11] = may23_B.R1_motorOrientation[1];
    may23_DW.ECATHardware[13] = may23_B.R2_motorOrientation[1];

    /* DataTypeConversion: '<S82>/convert' */
    may23_B.convert[7] = may23_B.Switch_f[7];

    /* DataStoreWrite: '<S82>/ECat status write' */
    memcpy(&may23_DW.ECATStatus[0], &may23_B.convert[0], sizeof(real_T) << 3U);

    /* RelationalOperator: '<S79>/Compare' incorporates:
     *  Constant: '<S79>/Constant'
     */
    may23_B.Compare_k = (uint8_T)(may23_B.Convert20 == may23_P.Compare_const_i);

    /* MATLAB Function: '<S81>/update digital outputs' incorporates:
     *  Constant: '<S1>/ZeroDigOut'
     */
    /* MATLAB Function 'EtherCAT Subsystem/Digital output/update digital outputs': '<S238>:1' */
    /* '<S238>:1:9' */
    i = 0;
    if ((may23_B.Compare_k == 1) && (may23_B.Compare_k != may23_DW.prevRunStatus))
    {
      /* '<S238>:1:10' */
      /* '<S238>:1:13' */
      i = 1;
    }

    /* '<S238>:1:15' */
    may23_DW.prevRunStatus = may23_B.Compare_k;

    /* '<S238>:1:17' */
    /* '<S238>:1:25' */
    may23_B.drive1 = 0U;
    if (i != 0) {
      /* '<S238>:1:35' */
      /* '<S238>:1:36' */
      q0 = may23_B.drive1;
      qY = q0 + 262144U;
      if (qY < q0) {
        qY = MAX_uint32_T;
      }

      may23_B.drive1 = qY;
    }

    if (may23_P.ZeroDigOut_Value[0] != 0.0) {
      /* '<S238>:1:39' */
      /* '<S238>:1:40' */
      q0 = may23_B.drive1;
      qY = q0 + 524288U;
      if (qY < q0) {
        qY = MAX_uint32_T;
      }

      may23_B.drive1 = qY;
    }

    /* '<S238>:1:18' */
    /* '<S238>:1:25' */
    may23_B.drive2 = 0U;
    if (may23_P.ZeroDigOut_Value[1] != 0.0) {
      /* '<S238>:1:39' */
      /* '<S238>:1:40' */
      q0 = may23_B.drive2;
      qY = q0 + 524288U;
      if (qY < q0) {
        qY = MAX_uint32_T;
      }

      may23_B.drive2 = qY;
    }

    /* '<S238>:1:19' */
    /* '<S238>:1:25' */
    may23_B.drive3 = 0U;
    if (may23_P.ZeroDigOut_Value[2] != 0.0) {
      /* '<S238>:1:39' */
      /* '<S238>:1:40' */
      q0 = may23_B.drive3;
      qY = q0 + 524288U;
      if (qY < q0) {
        qY = MAX_uint32_T;
      }

      may23_B.drive3 = qY;
    }

    /* '<S238>:1:20' */
    /* '<S238>:1:25' */
    may23_B.drive4 = 0U;
    if (may23_P.ZeroDigOut_Value[3] != 0.0) {
      /* '<S238>:1:39' */
      /* '<S238>:1:40' */
      q0 = may23_B.drive4;
      qY = q0 + 524288U;
      if (qY < q0) {
        qY = MAX_uint32_T;
      }

      may23_B.drive4 = qY;
    }

    /* End of MATLAB Function: '<S81>/update digital outputs' */

    /* S-Function (BKINethercatpdotx): '<S81>/BKIN EtherCAT PDO Transmit ' */

    /* Level2 S-Function Block: '<S81>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[29];
      sfcnOutputs(rts,1);
    }

    /* S-Function (BKINethercatpdotx): '<S81>/BKIN EtherCAT PDO Transmit 1' */

    /* Level2 S-Function Block: '<S81>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[30];
      sfcnOutputs(rts,1);
    }

    /* S-Function (BKINethercatpdotx): '<S81>/BKIN EtherCAT PDO Transmit 2' */

    /* Level2 S-Function Block: '<S81>/BKIN EtherCAT PDO Transmit 2' (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[31];
      sfcnOutputs(rts,1);
    }

    /* S-Function (BKINethercatpdotx): '<S81>/BKIN EtherCAT PDO Transmit 3' */

    /* Level2 S-Function Block: '<S81>/BKIN EtherCAT PDO Transmit 3' (BKINethercatpdotx) */
    {
      SimStruct *rts = may23_M->childSfunctions[32];
      sfcnOutputs(rts,1);
    }

    /* DataStoreRead: '<S30>/Read HasFT' */
    may23_B.ReadHasFT[0] = may23_DW.ArmForceSensors[0];
    may23_B.ReadHasFT[1] = may23_DW.ArmForceSensors[1];
    may23_B.ReadHasFT[2] = may23_DW.ArmForceSensors[2];

    /* Outputs for Atomic SubSystem: '<S30>/Force Sensor Control' */
    may23_ForceSensorControl();

    /* End of Outputs for SubSystem: '<S30>/Force Sensor Control' */

    /* RelationalOperator: '<S285>/Compare' incorporates:
     *  Constant: '<S285>/Constant'
     */
    may23_B.Compare_e2 = (may23_B.systemtype == may23_P.ispmac1_const);

    /* Outputs for Enabled SubSystem: '<S70>/Data receive' incorporates:
     *  EnablePort: '<S283>/Enable'
     */
    if (may23_B.Compare_e2) {
      /* UnitDelay: '<S286>/Output' */
      may23_B.Output_d = may23_DW.Output_DSTATE_a;

      /* Sum: '<S288>/FixPt Sum1' incorporates:
       *  Constant: '<S288>/FixPt Constant'
       */
      may23_B.FixPtSum1_g = may23_B.Output_d + may23_P.FixPtConstant_Value_h;

      /* Switch: '<S289>/FixPt Switch' incorporates:
       *  Constant: '<S289>/Constant'
       */
      if (may23_B.FixPtSum1_g > may23_P.WrapToZero_Threshold_h) {
        may23_B.FixPtSwitch_o = may23_P.Constant_Value_pz;
      } else {
        may23_B.FixPtSwitch_o = may23_B.FixPtSum1_g;
      }

      /* End of Switch: '<S289>/FixPt Switch' */

      /* S-Function (slrtUDPReceive): '<S283>/Receive' */

      /* Level2 S-Function Block: '<S283>/Receive' (slrtUDPReceive) */
      {
        SimStruct *rts = may23_M->childSfunctions[28];
        sfcnOutputs(rts,1);
      }

      /* S-Function (xpcbytepacking): '<S283>/Unpack' */

      /* Byte Unpacking: <S283>/Unpack */
      (void)memcpy((uint8_T*)&may23_B.Unpack_o1_n[0], (uint8_T*)
                   &may23_B.Receive_o1_i[0] + 0, 8);
      (void)memcpy((uint8_T*)&may23_B.Unpack_o2[0], (uint8_T*)
                   &may23_B.Receive_o1_i[0] + 8, 8);

      /* DataTypeConversion: '<S283>/Data Type Conversion' */
      may23_B.DataTypeConversion_o[0] = may23_B.Unpack_o1_n[0];
      may23_B.DataTypeConversion_o[1] = may23_B.Unpack_o1_n[1];

      /* DataTypeConversion: '<S283>/Data Type Conversion1' */
      may23_B.DataTypeConversion1_j[0] = may23_B.Unpack_o2[0];
      may23_B.DataTypeConversion1_j[1] = may23_B.Unpack_o2[1];

      /* DataTypeConversion: '<S283>/Data Type Conversion2' */
      may23_B.DataTypeConversion2_f = may23_B.Output_d;

      /* MATLAB Function: '<S283>/MATLAB Function' */
      /* MATLAB Function 'DataLogging/Poll KINARM/bkin_internal_testing/Data receive/MATLAB Function': '<S287>:1' */
      if (may23_B.Receive_o2_l > 0.0) {
        /* '<S287>:1:14' */
        /* '<S287>:1:15' */
        y = may23_DW.r1Sho[0];
        ticksPerRad = may23_DW.r1Sho[1];
        queueSizePrimary = may23_DW.r1Sho[2];
        may23_DW.r1Sho[1] = y;
        may23_DW.r1Sho[2] = ticksPerRad;
        may23_DW.r1Sho[3] = queueSizePrimary;

        /* '<S287>:1:16' */
        y = may23_DW.r1Elb[0];
        ticksPerRad = may23_DW.r1Elb[1];
        queueSizePrimary = may23_DW.r1Elb[2];
        may23_DW.r1Elb[1] = y;
        may23_DW.r1Elb[2] = ticksPerRad;
        may23_DW.r1Elb[3] = queueSizePrimary;

        /* '<S287>:1:17' */
        y = may23_DW.r2Sho[0];
        ticksPerRad = may23_DW.r2Sho[1];
        queueSizePrimary = may23_DW.r2Sho[2];
        may23_DW.r2Sho[1] = y;
        may23_DW.r2Sho[2] = ticksPerRad;
        may23_DW.r2Sho[3] = queueSizePrimary;

        /* '<S287>:1:18' */
        y = may23_DW.r2Elb[0];
        ticksPerRad = may23_DW.r2Elb[1];
        queueSizePrimary = may23_DW.r2Elb[2];
        may23_DW.r2Elb[1] = y;
        may23_DW.r2Elb[2] = ticksPerRad;
        may23_DW.r2Elb[3] = queueSizePrimary;

        /* '<S287>:1:20' */
        may23_DW.r1Sho[0] = may23_B.DataTypeConversion_o[0];

        /* '<S287>:1:21' */
        may23_DW.r1Elb[0] = may23_B.DataTypeConversion_o[1];

        /* '<S287>:1:22' */
        may23_DW.r2Sho[0] = may23_B.DataTypeConversion1_j[0];

        /* '<S287>:1:23' */
        may23_DW.r2Elb[0] = may23_B.DataTypeConversion1_j[1];

        /* '<S287>:1:25' */
        y = may23_DW.last_tick[0];
        ticksPerRad = may23_DW.last_tick[1];
        queueSizePrimary = may23_DW.last_tick[2];
        may23_DW.last_tick[1] = y;
        may23_DW.last_tick[2] = ticksPerRad;
        may23_DW.last_tick[3] = queueSizePrimary;

        /* '<S287>:1:26' */
        may23_DW.last_tick[0] = may23_B.DataTypeConversion2_f *
          may23_P.BKIN_STEP_TIME;
      }

      /* '<S287>:1:29' */
      for (i = 0; i < 20; i++) {
        may23_B.kinematics[i] = 0.0;
      }

      /* '<S287>:1:30' */
      for (i = 0; i < 12; i++) {
        may23_B.primary[i] = 0.0;
      }

      /* '<S287>:1:32' */
      may23_B.kinematics[0] = may23_DW.r1Sho[0];
      may23_B.kinematics[1] = may23_DW.r1Elb[0];

      /* '<S287>:1:37' */
      may23_B.kinematics[10] = may23_DW.r2Sho[0];
      may23_B.kinematics[11] = may23_DW.r2Elb[0];

      /* '<S287>:1:42' */
      /* '<S287>:1:43' */
      for (i = 0; i < 6; i++) {
        may23_B.primary[i] = may23_B.kinematics[i];
        may23_B.primary[i + 6] = may23_B.kinematics[i + 10];
      }

      /* End of MATLAB Function: '<S283>/MATLAB Function' */

      /* Constant: '<S283>/Constant' */
      may23_B.Constant_d = may23_P.Constant_Value_h;

      /* Constant: '<S283>/Constant1' */
      for (i = 0; i < 7; i++) {
        may23_B.Constant1[i] = may23_P.Constant1_Value_nm[i];
      }

      /* End of Constant: '<S283>/Constant1' */
      srUpdateBC(may23_DW.Datareceive_SubsysRanBC);
    }

    /* End of Outputs for SubSystem: '<S70>/Data receive' */

    /* RelationalOperator: '<S278>/Compare' incorporates:
     *  Constant: '<S278>/Constant'
     */
    may23_B.Compare_h = (may23_B.Convert20 == may23_P.is_running_const);

    /* RelationalOperator: '<S279>/Compare' incorporates:
     *  Constant: '<S279>/Constant'
     */
    may23_B.Compare_ec = (may23_B.systemtype == may23_P.ispmac1_const_o);

    /* Logic: '<S69>/Logical Operator' */
    may23_B.LogicalOperator = (may23_B.Compare_h && may23_B.Compare_ec);

    /* UnitDelay: '<S275>/Output' */
    may23_B.Output_n = may23_DW.Output_DSTATE_p;

    /* Constant: '<S290>/Arm Orientation' */
    may23_B.ArmOrientation_f = may23_P.ArmOrientation_Value;

    /* Constant: '<S290>/Arm Motor1 Orientation' */
    may23_B.M1orientation_b = may23_P.ArmMotor1Orientation_Value;

    /* Constant: '<S290>/Arm Motor2 Orientation' */
    may23_B.M2Orientation_k = may23_P.ArmMotor2Orientation_Value;

    /* Constant: '<S290>/Arm Motor1 Gear Ratio' */
    may23_B.M1GearRatio_p = may23_P.ArmMotor1GearRatio_Value;

    /* Constant: '<S290>/Arm Motor2 Gear Ratio' */
    may23_B.M2GearRatio_i = may23_P.ArmMotor2GearRatio_Value;

    /* Constant: '<S290>/Arm Secondary Encoders' */
    may23_B.HasSecondaryEnc_n = may23_P.ArmSecondaryEncoders_Value;

    /* Constant: '<S291>/Arm Orientation' */
    may23_B.ArmOrientation_m = may23_P.ArmOrientation_Value_g;

    /* Constant: '<S291>/Arm Motor1 Orientation' */
    may23_B.M1orientation_f = may23_P.ArmMotor1Orientation_Value_j;

    /* Constant: '<S291>/Arm Motor2 Orientation' */
    may23_B.M2Orientation_c = may23_P.ArmMotor2Orientation_Value_o;

    /* Constant: '<S291>/Arm Motor1 Gear Ratio' */
    may23_B.M1GearRatio_a = may23_P.ArmMotor1GearRatio_Value_b;

    /* Constant: '<S291>/Arm Motor2 Gear Ratio' */
    may23_B.M2GearRatio_ie = may23_P.ArmMotor2GearRatio_Value_a;

    /* Constant: '<S291>/Arm Secondary Encoders' */
    may23_B.HasSecondaryEnc_c = may23_P.ArmSecondaryEncoders_Value_f;

    /* RelationalOperator: '<S261>/Compare' incorporates:
     *  Constant: '<S261>/Constant'
     */
    may23_B.Compare_f = (may23_B.systemtype == may23_P.ispmac_const);

    /* Outputs for Enabled SubSystem: '<S68>/read_pmac' */
    may23_read_pmac();

    /* End of Outputs for SubSystem: '<S68>/read_pmac' */

    /* UnitDelay: '<S80>/Output' */
    may23_B.Output_hd = may23_DW.Output_DSTATE_po;

    /* MATLAB Function: '<S66>/latch_errors' */
    for (i = 0; i < 8; i++) {
      status[i] = may23_B.Switch_f[i];
    }

    /* MATLAB Function 'EtherCAT Subsystem/latch_errors': '<S83>:1' */
    if ((may23_B.Switch_f[1] == 8) && (may23_DW.enteredOpStep == 0U)) {
      /* '<S83>:1:12' */
      /* '<S83>:1:13' */
      may23_DW.enteredOpStep = may23_B.Output_hd;
    }

    if ((may23_B.Switch_f[0] == 65551) || (may23_B.Switch_f[0] == 65569)) {
      /* '<S83>:1:18' */
      q0 = may23_B.Output_hd;
      qY = q0 - may23_DW.enteredOpStep;
      if (qY > q0) {
        qY = 0U;
      }

      if ((may23_DW.enteredOpStep == 0U) || (qY < 10U)) {
        /* '<S83>:1:19' */
        /* '<S83>:1:20' */
        status[0] = 22;
      }
    }

    if ((may23_DW.latchedErrors[0] != status[0]) && (status[0] != 0)) {
      /* '<S83>:1:24' */
      /* '<S83>:1:25' */
      may23_circshift_b(may23_DW.latchedErrors);

      /* '<S83>:1:26' */
      may23_DW.latchedErrors[0] = status[0];

      /* '<S83>:1:27' */
      may23_DW.latchedErrors[1] = may23_B.Output_hd;
    }

    if ((may23_DW.latchedDCErrors[0] != may23_B.Switch_f[2]) &&
        (may23_B.Switch_f[2] != 0)) {
      /* '<S83>:1:30' */
      /* '<S83>:1:31' */
      may23_circshift_b(may23_DW.latchedDCErrors);

      /* '<S83>:1:32' */
      may23_DW.latchedDCErrors[0] = may23_B.Switch_f[2];

      /* '<S83>:1:33' */
      may23_DW.latchedDCErrors[1] = may23_B.Output_hd;
    }

    /* '<S83>:1:36' */
    memcpy(&may23_B.errVals[0], &may23_DW.latchedErrors[0], 12U * sizeof(real_T));

    /* '<S83>:1:37' */
    memcpy(&may23_B.DCErrVals[0], &may23_DW.latchedDCErrors[0], 12U * sizeof
           (real_T));

    /* End of MATLAB Function: '<S66>/latch_errors' */

    /* Bias: '<S66>/Bias' incorporates:
     *  Constant: '<S66>/activation'
     */
    may23_B.Bias = may23_P.activation_Value[1] + may23_P.Bias_Bias;

    /* DataTypeConversion: '<S66>/convert1' */
    may23_B.convert1_l = may23_B.Bias;

    /* RateTransition generated from: '<S69>/Data write' */
    if (may23_M->Timing.RateInteraction.TID1_3) {
      memcpy(&may23_B.TmpRTBAtDatawriteInport2[0],
             &may23_DW.TmpRTBAtDatawriteInport2_Buffer0[0], 20U * sizeof(real_T));

      /* RateTransition generated from: '<S69>/Data write' */
      memcpy(&may23_B.TmpRTBAtDatawriteInport3[0],
             &may23_DW.TmpRTBAtDatawriteInport3_Buffer0[0], 12U * sizeof(real_T));

      /* RateTransition generated from: '<S69>/Data write' */
      may23_B.TmpRTBAtDatawriteInport4 =
        may23_DW.TmpRTBAtDatawriteInport4_Buffer0;

      /* RateTransition generated from: '<S69>/Data write' */
      for (i = 0; i < 7; i++) {
        may23_B.TmpRTBAtDatawriteInport5[i] =
          may23_DW.TmpRTBAtDatawriteInport5_Buffer0[i];
      }

      /* End of RateTransition generated from: '<S69>/Data write' */
    }

    /* End of RateTransition generated from: '<S69>/Data write' */

    /* Chart: '<S30>/control read write' */
    /* Gateway: DataLogging/Poll KINARM/control read write */
    may23_DW.sfEvent_l = -1;

    /* During: DataLogging/Poll KINARM/control read write */
    if (may23_DW.is_active_c58_General == 0U) {
      /* Entry: DataLogging/Poll KINARM/control read write */
      may23_DW.is_active_c58_General = 1U;

      /* Entry Internal: DataLogging/Poll KINARM/control read write */
      /* Transition: '<S72>:215' */
      if (may23_B.systemtype == 1.0) {
        /* Transition: '<S72>:222' */
        may23_DW.is_c58_General = may23_IN_RunPMAC;
      } else {
        /* Transition: '<S72>:230' */
        if (may23_B.systemtype == 2.0) {
          /* Transition: '<S72>:220' */
          may23_DW.is_c58_General = may23_IN_RunECat;
        } else {
          /* Transition: '<S72>:231' */
          if (may23_B.systemtype == 3.0) {
            /* Transition: '<S72>:218' */
            may23_DW.is_c58_General = may23_IN_RunSim;
          } else {
            /* Transition: '<S72>:232' */
            /* Transition: '<S72>:233' */
            may23_DW.is_c58_General = may23_IN_File_input;
          }
        }
      }
    } else {
      switch (may23_DW.is_c58_General) {
       case may23_IN_File_input:
        /* Outputs for Function Call SubSystem: '<S69>/Data write' */
        /* During 'File_input': '<S72>:226' */
        /* Event: '<S72>:225' */
        for (i = 0; i < 10; i++) {
          /* Switch: '<S277>/Switch' incorporates:
           *  Constant: '<S277>/Constant1'
           *  Constant: '<S277>/Constant2'
           */
          if (may23_B.LogicalOperator) {
            may23_B.Switch_g[i] = may23_P.Constant2_Value[i];
          } else {
            may23_B.Switch_g[i] = may23_P.Constant1_Value_h[i];
          }

          /* End of Switch: '<S277>/Switch' */

          /* DataStoreWrite: '<S277>/Data Store Write' */
          may23_DW.DataReadyStatus[i] = may23_B.Switch_g[i];
        }

        /* DataStoreWrite: '<S277>/Data Store Write1' */
        memcpy(&may23_DW.Kinematics[0], &may23_B.TmpRTBAtDatawriteInport2[0],
               20U * sizeof(real_T));

        /* DataStoreWrite: '<S277>/Data Store Write4' */
        memcpy(&may23_DW.PrimaryEncoderData[0],
               &may23_B.TmpRTBAtDatawriteInport3[0], 12U * sizeof(real_T));

        /* DataStoreWrite: '<S277>/Data Store Write5' */
        may23_DW.CalibrationButton = may23_B.TmpRTBAtDatawriteInport4;

        /* DataStoreWrite: '<S277>/Data Store Write7' */
        for (i = 0; i < 7; i++) {
          may23_DW.SystemStatus[i] = may23_B.TmpRTBAtDatawriteInport5[i];
        }

        /* End of DataStoreWrite: '<S277>/Data Store Write7' */

        /* DataStoreWrite: '<S277>/Data Store Write2' */
        may23_DW.ServoUpdate = may23_B.Output_n;

        /* DataStoreWrite: '<S277>/Data Store Write3' incorporates:
         *  Constant: '<S277>/Constant'
         */
        may23_DW.DelayEstimates[0] = may23_P.Constant_Value_mg[0];
        may23_DW.DelayEstimates[1] = may23_P.Constant_Value_mg[1];
        may23_DW.DelayEstimates[2] = may23_P.Constant_Value_mg[2];
        may23_DW.DelayEstimates[3] = may23_P.Constant_Value_mg[3];
        may23_DW.Datawrite_SubsysRanBC = 4;

        /* End of Outputs for SubSystem: '<S69>/Data write' */

        /* Outputs for Function Call SubSystem: '<S30>/createKINData' */
        /* Event: '<S72>:209' */
        may23_createKINData();

        /* End of Outputs for SubSystem: '<S30>/createKINData' */
        break;

       case may23_IN_RunECat:
        /* Outputs for Function Call SubSystem: '<S66>/update' */
        /* DataTypeConversion: '<S86>/Data Type Conversion1' */
        /* During 'RunECat': '<S72>:219' */
        /* Event: '<S72>:207' */
        y = floor(may23_B.R1_calibrationButton);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion1_b[0] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;
        y = floor(may23_B.R2_calibrationButton);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion1_b[1] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;

        /* End of DataTypeConversion: '<S86>/Data Type Conversion1' */

        /* MATLAB Function: '<S86>/convert to bit field' */
        /* MATLAB Function 'EtherCAT Subsystem/update/convert to bit field': '<S242>:1' */
        /* '<S242>:1:3' */
        q0 = may23_B.DataTypeConversion1_b[0];
        qY = (may23_B.DataTypeConversion1_b[1] << 1U) + q0;
        if (qY < q0) {
          qY = MAX_uint32_T;
        }

        may23_B.bitField = qY;

        /* End of MATLAB Function: '<S86>/convert to bit field' */

        /* DataStoreWrite: '<S86>/Calib write' */
        may23_DW.CalibrationButton = may23_B.bitField;

        /* DataTypeConversion: '<S86>/Data Type Conversion' */
        y = floor(may23_B.R1M1_digitalInputs[0]);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion_g0[0] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;
        y = floor(may23_B.R1M2_digitalInputs[0]);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion_g0[2] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;
        y = floor(may23_B.R2M1_digitalInputs[0]);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion_g0[4] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;
        y = floor(may23_B.R2M2_digitalInputs[0]);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion_g0[6] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;
        y = floor(may23_B.R1M1_digitalInputs[1]);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion_g0[1] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;
        y = floor(may23_B.R1M2_digitalInputs[1]);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion_g0[3] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;
        y = floor(may23_B.R2M1_digitalInputs[1]);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion_g0[5] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;
        y = floor(may23_B.R2M2_digitalInputs[1]);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion_g0[7] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;

        /* End of DataTypeConversion: '<S86>/Data Type Conversion' */

        /* DataStoreWrite: '<S86>/Data Store Write' */
        for (i = 0; i < 8; i++) {
          may23_DW.ECATDigitalInput[i] = may23_B.DataTypeConversion_g0[i];
        }

        /* End of DataStoreWrite: '<S86>/Data Store Write' */

        /* DataStoreWrite: '<S86>/Data Store Write6' */
        may23_DW.RobotRevision[0] = may23_B.R1_RobotRevision;
        may23_DW.RobotRevision[1] = may23_B.R2_RobotRevision;

        /* DataTypeConversion: '<S86>/Data Type Conversion4' */
        y = floor(may23_B.R1M1_digitalDiagnostics);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion4_l[0] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;
        y = floor(may23_B.R1M2_digitalDiagnostics);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion4_l[1] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;
        y = floor(may23_B.R2M1_digitalDiagnostics);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion4_l[2] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;
        y = floor(may23_B.R2M2_digitalDiagnostics);
        if (rtIsNaN(y) || rtIsInf(y)) {
          y = 0.0;
        } else {
          y = fmod(y, 4.294967296E+9);
        }

        may23_B.DataTypeConversion4_l[3] = y < 0.0 ? (uint32_T)-(int32_T)
          (uint32_T)-y : (uint32_T)y;

        /* End of DataTypeConversion: '<S86>/Data Type Conversion4' */

        /* DataStoreWrite: '<S86>/ECat status write' */
        may23_DW.ECATDigDiagnostic[0] = may23_B.DataTypeConversion4_l[0];
        may23_DW.ECATDigDiagnostic[1] = may23_B.DataTypeConversion4_l[1];
        may23_DW.ECATDigDiagnostic[2] = may23_B.DataTypeConversion4_l[2];
        may23_DW.ECATDigDiagnostic[3] = may23_B.DataTypeConversion4_l[3];

        /* SignalConversion generated from: '<S241>/ SFunction ' incorporates:
         *  MATLAB Function: '<S86>/MATLAB Function'
         */
        may23_B.TmpSignalConversionAtSFunctionInport1_me[0] = may23_B.R1_hasFT;
        may23_B.TmpSignalConversionAtSFunctionInport1_me[1] = may23_B.R2_hasFT;

        /* SignalConversion generated from: '<S241>/ SFunction ' incorporates:
         *  MATLAB Function: '<S86>/MATLAB Function'
         */
        may23_B.TmpSignalConversionAtSFunctionInport2_l[0] =
          may23_B.R1_robotOrientation;
        may23_B.TmpSignalConversionAtSFunctionInport2_l[1] =
          may23_B.R2_robotOrientation;

        /* MATLAB Function: '<S86>/MATLAB Function' */
        /* MATLAB Function 'EtherCAT Subsystem/update/MATLAB Function': '<S241>:1' */
        /* '<S241>:1:4' */
        may23_B.swap_order = 0.0;
        if ((may23_B.TmpSignalConversionAtSFunctionInport1_me[0] +
             may23_B.TmpSignalConversionAtSFunctionInport1_me[1] > 0.0) &&
            (may23_B.TmpSignalConversionAtSFunctionInport2_l[0] == 1.0)) {
          /* '<S241>:1:7' */
          /* '<S241>:1:8' */
          may23_B.swap_order = 1.0;
        }

        /* DataStoreWrite: '<S86>/Force sensor write' */
        may23_DW.ArmForceSensors[0] = may23_B.R1_hasFT;
        may23_DW.ArmForceSensors[1] = may23_B.R2_hasFT;
        may23_DW.ArmForceSensors[2] = may23_B.swap_order;

        /* DataTypeConversion: '<S86>/Data Type Conversion2' */
        may23_B.DataTypeConversion2_h2 = (uint32_T)may23_B.MasterStateOut;

        /* DataStoreWrite: '<S86>/Status write' incorporates:
         *  Constant: '<S86>/Constant1'
         */
        may23_DW.SystemStatus[0] = may23_B.sf_Whistlestate.motorStatus;
        may23_DW.SystemStatus[1] = may23_B.sf_Whistlestate_a.motorStatus;
        may23_DW.SystemStatus[2] = may23_B.sf_Whistlestate_l.motorStatus;
        may23_DW.SystemStatus[3] = may23_B.sf_Whistlestate_m.motorStatus;
        may23_DW.SystemStatus[4] = may23_P.Constant1_Value_oq;
        may23_DW.SystemStatus[5] = may23_B.DataTypeConversion2_h2;
        may23_DW.SystemStatus[6] = may23_B.sf_parsestatusregister.eStopOut;

        /* DataStoreRead: '<S86>/Data Store' */
        memcpy(&may23_B.DataStore[0], &may23_DW.RobotCalibrations[0], sizeof
               (real_T) << 4U);

        /* SignalConversion generated from: '<S249>/ SFunction ' incorporates:
         *  MATLAB Function: '<S86>/update calibrations'
         */
        may23_B.TmpSignalConversionAtSFunctionInport2_a[0] =
          may23_B.R1_LinkLength[0];
        may23_B.TmpSignalConversionAtSFunctionInport2_a[2] =
          may23_B.R2_LinkLength[0];
        may23_B.TmpSignalConversionAtSFunctionInport2_a[1] =
          may23_B.R1_LinkLength[1];
        may23_B.TmpSignalConversionAtSFunctionInport2_a[3] =
          may23_B.R2_LinkLength[1];

        /* SignalConversion generated from: '<S249>/ SFunction ' incorporates:
         *  MATLAB Function: '<S86>/update calibrations'
         */
        may23_B.TmpSignalConversionAtSFunctionInport4[0] = may23_B.R1_RobotType;
        may23_B.TmpSignalConversionAtSFunctionInport4[1] = may23_B.R2_RobotType;

        /* MATLAB Function: '<S86>/update calibrations' */
        /* MATLAB Function 'EtherCAT Subsystem/update/update calibrations': '<S249>:1' */
        /* '<S249>:1:3' */
        /* '<S249>:1:4' */
        memcpy(&r1Calibs[0], &may23_B.DataStore[0], sizeof(real_T) << 3U);
        memcpy(&r2Calibs[0], &may23_B.DataStore[8], sizeof(real_T) << 3U);
        if (may23_B.TmpSignalConversionAtSFunctionInport4[0] == 1.0) {
          /* '<S249>:1:7' */
          /* '<S249>:1:8' */
          r1Calibs[4] = may23_B.TmpSignalConversionAtSFunctionInport2_a[0];

          /* '<S249>:1:9' */
          r1Calibs[5] = may23_B.TmpSignalConversionAtSFunctionInport2_a[1];
        }

        if (may23_B.TmpSignalConversionAtSFunctionInport4[1] == 1.0) {
          /* '<S249>:1:13' */
          /* '<S249>:1:14' */
          r2Calibs[4] = may23_B.TmpSignalConversionAtSFunctionInport2_a[0];

          /* '<S249>:1:15' */
          r2Calibs[5] = may23_B.TmpSignalConversionAtSFunctionInport2_a[1];
        }

        /* '<S249>:1:17' */
        for (i = 0; i < 8; i++) {
          may23_B.calibrationsOut[i] = r1Calibs[i];
          may23_B.calibrationsOut[i + 8] = r2Calibs[i];
        }

        /* DataStoreWrite: '<S86>/calib write' */
        memcpy(&may23_DW.RobotCalibrations[0], &may23_B.calibrationsOut[0],
               sizeof(real_T) << 4U);

        /* DataStoreRead: '<S86>/Data Store1' */
        memcpy(&may23_B.DataStore1[0], &may23_DW.HardwareSettings[0], 25U *
               sizeof(real_T));

        /* SignalConversion generated from: '<S246>/ SFunction ' incorporates:
         *  MATLAB Function: '<S86>/create servo counter1'
         */
        may23_B.TmpSignalConversionAtSFunctionInport1_e[0] =
          may23_B.R1_constantsReady_p;
        may23_B.TmpSignalConversionAtSFunctionInport1_e[1] =
          may23_B.R2_constantsReady_b;

        /* MATLAB Function: '<S86>/create servo counter1' */
        /* MATLAB Function 'EtherCAT Subsystem/update/create servo counter1': '<S246>:1' */
        /* '<S246>:1:3' */
        for (i = 0; i < 10; i++) {
          may23_B.dataReadyStatus[i] = 0.0;
        }

        if ((may23_B.TmpSignalConversionAtSFunctionInport1_e[0] +
             may23_B.TmpSignalConversionAtSFunctionInport1_e[1] ==
             may23_B.convert1_l) && (may23_B.MasterStateOut >= 4)) {
          /* '<S246>:1:7' */
          /* '<S246>:1:8' */
          may23_B.dataReadyStatus[0] = 1.0;
        }

        /* SignalConversion generated from: '<S248>/ SFunction ' incorporates:
         *  MATLAB Function: '<S86>/update HW settings'
         */
        may23_B.TmpSignalConversionAtSFunctionInport2_ny[0] =
          may23_B.R1_RobotType;
        may23_B.TmpSignalConversionAtSFunctionInport2_ny[1] =
          may23_B.R2_RobotType;

        /* SignalConversion generated from: '<S248>/ SFunction ' incorporates:
         *  MATLAB Function: '<S86>/update HW settings'
         */
        may23_B.TmpSignalConversionAtSFunctionInport3_c[0] =
          may23_B.R1_FTSensorAngleOffset;
        may23_B.TmpSignalConversionAtSFunctionInport3_c[1] =
          may23_B.R2_FTSensorAngleOffset;

        /* SignalConversion generated from: '<S248>/ SFunction ' incorporates:
         *  MATLAB Function: '<S86>/update HW settings'
         */
        may23_B.TmpSignalConversionAtSFunctionInport4_m[0] =
          may23_B.R1_robotOrientation;
        may23_B.TmpSignalConversionAtSFunctionInport4_m[1] =
          may23_B.R2_robotOrientation;

        /* MATLAB Function: '<S86>/update HW settings' */
        /* MATLAB Function 'EtherCAT Subsystem/update/update HW settings': '<S248>:1' */
        /* '<S248>:1:3' */
        /* '<S248>:1:4' */
        memcpy(&r1SettingsOut[0], &may23_B.DataStore1[0], 12U * sizeof(real_T));
        memcpy(&r2SettingsOut[0], &may23_B.DataStore1[12], 12U * sizeof(real_T));

        /* '<S248>:1:5' */
        r1SettingsOut[0] = may23_B.TmpSignalConversionAtSFunctionInport2_ny[0];

        /* '<S248>:1:6' */
        r2SettingsOut[0] = may23_B.TmpSignalConversionAtSFunctionInport2_ny[1];

        /* '<S248>:1:7' */
        r1SettingsOut[4] = may23_B.TmpSignalConversionAtSFunctionInport3_c[0];

        /* '<S248>:1:8' */
        r2SettingsOut[4] = may23_B.TmpSignalConversionAtSFunctionInport3_c[1];

        /* '<S248>:1:9' */
        r1SettingsOut[6] = may23_B.TmpSignalConversionAtSFunctionInport4_m[0];

        /* '<S248>:1:10' */
        r2SettingsOut[6] = may23_B.TmpSignalConversionAtSFunctionInport4_m[1];

        /* '<S248>:1:12' */
        for (i = 0; i < 12; i++) {
          may23_B.settingsOut[i] = r1SettingsOut[i];
          may23_B.settingsOut[i + 12] = r2SettingsOut[i];
        }

        may23_B.settingsOut[24] = may23_B.dataReadyStatus[0];

        /* DataStoreWrite: '<S86>/hardware write' */
        memcpy(&may23_DW.HardwareSettings[0], &may23_B.settingsOut[0], 25U *
               sizeof(real_T));

        /* SignalConversion generated from: '<S244>/ SFunction ' incorporates:
         *  MATLAB Function: '<S86>/create kinematics'
         */
        may23_B.TmpSignalConversionAtSFunctionInport1_p[0] =
          may23_B.R1M1_LinkAngle;
        may23_B.TmpSignalConversionAtSFunctionInport1_p[1] =
          may23_B.R1M2_LinkAngle;
        may23_B.TmpSignalConversionAtSFunctionInport1_p[2] =
          may23_B.R2M1_LinkAngle;
        may23_B.TmpSignalConversionAtSFunctionInport1_p[3] =
          may23_B.R2M2_LinkAngle;

        /* SignalConversion generated from: '<S244>/ SFunction ' incorporates:
         *  MATLAB Function: '<S86>/create kinematics'
         */
        may23_B.TmpSignalConversionAtSFunctionInport2_d[0] =
          may23_B.R1M1_PrimaryLinkAngle;
        may23_B.TmpSignalConversionAtSFunctionInport2_d[1] =
          may23_B.R1M2_PrimaryLinkAngle;
        may23_B.TmpSignalConversionAtSFunctionInport2_d[2] =
          may23_B.R2M1_PrimaryLinkAngle;
        may23_B.TmpSignalConversionAtSFunctionInport2_d[3] =
          may23_B.R2M2_PrimaryLinkAngle;

        /* SignalConversion generated from: '<S244>/ SFunction ' incorporates:
         *  MATLAB Function: '<S86>/create kinematics'
         */
        may23_B.TmpSignalConversionAtSFunctionInport3_m[0] =
          may23_B.R1_hasSecondary;
        may23_B.TmpSignalConversionAtSFunctionInport3_m[1] =
          may23_B.R2_hasSecondary;

        /* SignalConversion generated from: '<S244>/ SFunction ' incorporates:
         *  MATLAB Function: '<S86>/create kinematics'
         */
        may23_B.TmpSignalConversionAtSFunctionInport4_c[0] =
          may23_B.sf_Whistlestate.motorStatus;
        may23_B.TmpSignalConversionAtSFunctionInport4_c[1] =
          may23_B.sf_Whistlestate_a.motorStatus;
        may23_B.TmpSignalConversionAtSFunctionInport4_c[2] =
          may23_B.sf_Whistlestate_l.motorStatus;
        may23_B.TmpSignalConversionAtSFunctionInport4_c[3] =
          may23_B.sf_Whistlestate_m.motorStatus;

        /* SignalConversion generated from: '<S244>/ SFunction ' incorporates:
         *  MATLAB Function: '<S86>/create kinematics'
         */
        may23_B.TmpSignalConversionAtSFunctionInport5[0] =
          may23_B.R1_robotOrientation;
        may23_B.TmpSignalConversionAtSFunctionInport5[1] =
          may23_B.R2_robotOrientation;

        /* MATLAB Function: '<S86>/create kinematics' incorporates:
         *  Constant: '<S86>/Constant'
         */
        may23_B.delays[0] = 0.001;
        may23_B.delays[1] = 0.002;
        may23_B.delays[2] = 0.0005;
        may23_B.delays[3] = 0.001;
        y = may23_P.BKIN_STEP_TIME;

        /* MATLAB Function 'EtherCAT Subsystem/update/create kinematics': '<S244>:1' */
        /* '<S244>:1:5' */
        if (may23_B.dataReadyStatus[0] == 0.0) {
          /* '<S244>:1:10' */
          /* '<S244>:1:11' */
          for (i = 0; i < 20; i++) {
            may23_B.kinematicsOut[i] = 0.0;
          }

          /* '<S244>:1:12' */
          for (i = 0; i < 12; i++) {
            may23_B.kinematicsOutPrimary[i] = 0.0;
          }
        } else {
          if (!may23_DW.secondaryPosData_not_empty) {
            /* '<S244>:1:16' */
            /* '<S244>:1:18' */
            queueSizePrimary = 0.002 / may23_P.BKIN_STEP_TIME + 1.0;
            if (!(queueSizePrimary < 100.0)) {
              queueSizePrimary = 100.0;
            }

            /* '<S244>:1:19' */
            ticksPerRad = 0.001 / may23_P.BKIN_STEP_TIME + 1.0;
            if (!(ticksPerRad < 100.0)) {
              ticksPerRad = 100.0;
            }

            /* '<S244>:1:20' */
            may23_convertL1L2ToShoElb
              (may23_B.TmpSignalConversionAtSFunctionInport1_p,
               may23_B.TmpSignalConversionAtSFunctionInport5, secondaryShoElb);

            /* '<S244>:1:21' */
            may23_convertL1L2ToShoElb
              (may23_B.TmpSignalConversionAtSFunctionInport2_d,
               may23_B.TmpSignalConversionAtSFunctionInport5, primaryShoElb);

            /* '<S244>:1:23' */
            may23_buildEncoderData(ticksPerRad, secondaryShoElb,
              may23_DW.secondaryPosData.data, may23_DW.secondaryPosData.size);
            may23_DW.secondaryPosData_not_empty =
              (may23_DW.secondaryPosData.size[1] != 0);

            /* '<S244>:1:24' */
            may23_buildEncoderData_k(ticksPerRad, may23_DW.secondaryVelData.data,
              may23_DW.secondaryVelData.size);

            /* '<S244>:1:25' */
            may23_buildEncoderData(queueSizePrimary, primaryShoElb,
              may23_DW.primaryPosData.data, may23_DW.primaryPosData.size);

            /* '<S244>:1:26' */
            may23_buildEncoderData_k(queueSizePrimary,
              may23_DW.primaryVelData.data, may23_DW.primaryVelData.size);
          } else {
            /* '<S244>:1:28' */
            may23_updatePosVel(may23_DW.secondaryPosData.data,
                               may23_DW.secondaryPosData.size,
                               may23_DW.secondaryVelData.data,
                               may23_DW.secondaryVelData.size,
                               may23_B.TmpSignalConversionAtSFunctionInport1_p,
                               may23_P.BKIN_STEP_TIME,
                               may23_B.TmpSignalConversionAtSFunctionInport5,
                               secondaryPosData_data, secondaryPosData_size,
                               secondaryVelData_data, secondaryVelData_size);

            /* '<S244>:1:28' */
            may23_DW.secondaryPosData.size[0] = 4;
            may23_DW.secondaryPosData.size[1] = secondaryPosData_size[1];
            i = secondaryPosData_size[0] * secondaryPosData_size[1] - 1;
            if (0 <= i) {
              memcpy(&may23_DW.secondaryPosData.data[0], &secondaryPosData_data
                     [0], (i + 1) * sizeof(real_T));
            }

            may23_DW.secondaryPosData_not_empty =
              (may23_DW.secondaryPosData.size[1] != 0);

            /* '<S244>:1:28' */
            may23_DW.secondaryVelData.size[0] = 4;
            may23_DW.secondaryVelData.size[1] = secondaryVelData_size[1];
            i = secondaryVelData_size[0] * secondaryVelData_size[1] - 1;
            if (0 <= i) {
              memcpy(&may23_DW.secondaryVelData.data[0], &secondaryVelData_data
                     [0], (i + 1) * sizeof(real_T));
            }

            /* '<S244>:1:29' */
            may23_updatePosVel(may23_DW.primaryPosData.data,
                               may23_DW.primaryPosData.size,
                               may23_DW.primaryVelData.data,
                               may23_DW.primaryVelData.size,
                               may23_B.TmpSignalConversionAtSFunctionInport2_d,
                               y, may23_B.TmpSignalConversionAtSFunctionInport5,
                               secondaryPosData_data, secondaryPosData_size,
                               secondaryVelData_data, secondaryVelData_size);

            /* '<S244>:1:29' */
            may23_DW.primaryPosData.size[0] = 4;
            may23_DW.primaryPosData.size[1] = secondaryPosData_size[1];
            i = secondaryPosData_size[0] * secondaryPosData_size[1] - 1;
            if (0 <= i) {
              memcpy(&may23_DW.primaryPosData.data[0], &secondaryPosData_data[0],
                     (i + 1) * sizeof(real_T));
            }

            /* '<S244>:1:29' */
            may23_DW.primaryVelData.size[0] = 4;
            may23_DW.primaryVelData.size[1] = secondaryVelData_size[1];
            i = secondaryVelData_size[0] * secondaryVelData_size[1] - 1;
            if (0 <= i) {
              memcpy(&may23_DW.primaryVelData.data[0], &secondaryVelData_data[0],
                     (i + 1) * sizeof(real_T));
            }
          }

          /* '<S244>:1:32' */
          may23_buildKinematics(may23_DW.secondaryPosData.data,
                                may23_DW.secondaryVelData.data,
                                may23_DW.secondaryVelData.size, y,
                                may23_B.TmpSignalConversionAtSFunctionInport4_c,
                                r1SecondaryKinematicsOut,
                                r2SecondaryKinematicsOut);

          /* '<S244>:1:32' */
          /* '<S244>:1:33' */
          may23_buildKinematics(may23_DW.primaryPosData.data,
                                may23_DW.primaryVelData.data,
                                may23_DW.primaryVelData.size, y,
                                may23_B.TmpSignalConversionAtSFunctionInport4_c,
                                r1PrimaryKinematicsOut, r2PrimaryKinematicsOut);
          if (may23_B.TmpSignalConversionAtSFunctionInport3_m[0] != 1.0) {
            /* '<S244>:1:35' */
            /* '<S244>:1:36' */
            memcpy(&r1SecondaryKinematicsOut[0], &r1PrimaryKinematicsOut[0], 10U
                   * sizeof(real_T));
          }

          if (may23_B.TmpSignalConversionAtSFunctionInport3_m[1] != 1.0) {
            /* '<S244>:1:38' */
            /* '<S244>:1:39' */
            memcpy(&r2SecondaryKinematicsOut[0], &r2PrimaryKinematicsOut[0], 10U
                   * sizeof(real_T));
          }

          /* '<S244>:1:42' */
          for (i = 0; i < 10; i++) {
            may23_B.kinematicsOut[i] = r1SecondaryKinematicsOut[i];
            may23_B.kinematicsOut[i + 10] = r2SecondaryKinematicsOut[i];
          }

          /* '<S244>:1:43' */
          for (i = 0; i < 6; i++) {
            may23_B.kinematicsOutPrimary[i] = r1PrimaryKinematicsOut[i];
            may23_B.kinematicsOutPrimary[i + 6] = r2PrimaryKinematicsOut[i];
          }
        }

        /* SignalConversion generated from: '<S250>/ SFunction ' incorporates:
         *  MATLAB Function: '<S243>/filter_velocities'
         */
        may23_B.TmpSignalConversionAtSFunctionInport1_m[0] =
          may23_B.kinematicsOut[2];
        may23_B.TmpSignalConversionAtSFunctionInport1_m[2] =
          may23_B.kinematicsOut[12];
        may23_B.TmpSignalConversionAtSFunctionInport1_m[1] =
          may23_B.kinematicsOut[3];
        may23_B.TmpSignalConversionAtSFunctionInport1_m[3] =
          may23_B.kinematicsOut[13];

        /* MATLAB Function: '<S243>/filter_velocities' incorporates:
         *  Constant: '<S243>/2nd order butterworth, 4Khz, 10hz cutoff'
         */
        /* MATLAB Function 'EtherCAT Subsystem/update/create filtered velocities/filter_velocities': '<S250>:1' */
        /* '<S250>:1:20' */
        /* '<S250>:1:1' */
        /* '<S250>:1:18' */
        for (i = 0; i < 4; i++) {
          /* '<S250>:1:18' */
          /* '<S250>:1:19' */
          /* '<S250>:1:20' */
          b[0] = may23_DW.rawVelocities_k[i];
          b[1] = may23_DW.rawVelocities_k[i + 4];
          b[2] = may23_DW.rawVelocities_k[i + 8];
          may23_insertVal(b, may23_B.TmpSignalConversionAtSFunctionInport1_m[i] /
                          may23_P.undorderbutterworth4Khz10hzcutoff_Value[0]);

          /* '<S250>:1:21' */
          may23_DW.rawVelocities_k[i] = b[0];
          b[0] = may23_DW.filtVelocities_d[i];
          may23_DW.rawVelocities_k[i + 4] = b[1];
          b[1] = may23_DW.filtVelocities_d[i + 4];
          may23_DW.rawVelocities_k[i + 8] = b[2];
          b[2] = may23_DW.filtVelocities_d[i + 8];
          may23_insertVal(b, 0.0);
          may23_DW.filtVelocities_d[i] = b[0];
          may23_DW.filtVelocities_d[i + 4] = b[1];
          may23_DW.filtVelocities_d[i + 8] = b[2];

          /* '<S250>:1:22' */
          /* '<S250>:1:29' */
          y = (((may23_DW.rawVelocities_k[i + 4] * 2.0 +
                 may23_DW.rawVelocities_k[i]) + may23_DW.rawVelocities_k[i + 8])
               + may23_DW.filtVelocities_d[i] *
               may23_P.undorderbutterworth4Khz10hzcutoff_Value[1]) +
            may23_DW.filtVelocities_d[i + 4] *
            may23_P.undorderbutterworth4Khz10hzcutoff_Value[2];
          if (rtIsNaN(y) || rtIsInf(y)) {
            /* '<S250>:1:34' */
            /* '<S250>:1:35' */
            y = 0.0;
          }

          may23_DW.filtVelocities_d[i + 8] = y;

          /* '<S250>:1:23' */
          may23_B.filteredVels[i] = may23_DW.filtVelocities_d[i + 8];
        }

        /* MATLAB Function: '<S243>/rebuild' */
        /* MATLAB Function 'EtherCAT Subsystem/update/create filtered velocities/rebuild': '<S251>:1' */
        /* '<S251>:1:2' */
        memcpy(&may23_B.outVals[0], &may23_B.kinematicsOut[0], 20U * sizeof
               (real_T));

        /* '<S251>:1:3' */
        /* '<S251>:1:4' */
        may23_B.outVals[6] = may23_B.filteredVels[0];
        may23_B.outVals[16] = may23_B.filteredVels[2];
        may23_B.outVals[7] = may23_B.filteredVels[1];
        may23_B.outVals[17] = may23_B.filteredVels[3];

        /* DataStoreWrite: '<S86>/kin write' */
        memcpy(&may23_DW.Kinematics[0], &may23_B.outVals[0], 20U * sizeof(real_T));

        /* DataStoreWrite: '<S86>/primary write' */
        memcpy(&may23_DW.PrimaryEncoderData[0], &may23_B.kinematicsOutPrimary[0],
               12U * sizeof(real_T));

        /* DataStoreWrite: '<S86>/readyStat' */
        memcpy(&may23_DW.DataReadyStatus[0], &may23_B.dataReadyStatus[0], 10U *
               sizeof(real_T));

        /* DataStoreWrite: '<S86>/write delays' */
        may23_DW.DelayEstimates[0] = may23_B.delays[0];
        may23_DW.DelayEstimates[1] = may23_B.delays[1];
        may23_DW.DelayEstimates[2] = may23_B.delays[2];
        may23_DW.DelayEstimates[3] = may23_B.delays[3];

        /* MATLAB Function: '<S86>/robottype1' */
        /* MATLAB Function 'EtherCAT Subsystem/update/robottype1': '<S247>:1' */
        /* '<S247>:1:3' */
        for (i = 0; i < 5; i++) {
          may23_B.outMem[i << 2] = may23_B.R1M1_EMCY_codes[i];
          may23_B.outMem[(i << 2) + 1] = may23_B.R1M2_EMCY_codes[i];
          may23_B.outMem[(i << 2) + 2] = may23_B.R2M1_EMCY_codes[i];
          may23_B.outMem[(i << 2) + 3] = may23_B.R2M2_EMCY_codes[i];
        }

        /* End of MATLAB Function: '<S86>/robottype1' */

        /* DataStoreWrite: '<S86>/write errs' */
        memcpy(&may23_DW.ECATErrMsgs[0], &may23_B.outMem[0], 20U * sizeof(real_T));

        /* DataTypeConversion: '<S86>/Data Type Conversion3' */
        may23_B.DataTypeConversion3_o[0] = may23_B.R1M1_CurrentLimitEnabled;
        may23_B.DataTypeConversion3_o[1] = may23_B.R1M2_CurrentLimitEnabled;
        may23_B.DataTypeConversion3_o[2] = may23_B.R2M1_CurrentLimitEnabled;
        may23_B.DataTypeConversion3_o[3] = may23_B.R2M2_CurrentLimitEnabled;

        /* DataTypeConversion: '<S86>/Data Type Conversion5' */
        may23_B.DataTypeConversion5_c[0] = may23_B.R1_EPGripSensor;
        may23_B.DataTypeConversion5_c[1] = may23_B.R2_EPGripSensor;

        /* DataStoreWrite: '<S86>/write torque' */
        may23_DW.ECATExtraData[0] = may23_B.R1M1_RecordedTorque;
        may23_DW.ECATExtraData[1] = may23_B.R1M2_RecordedTorque;
        may23_DW.ECATExtraData[2] = may23_B.R2M1_RecordedTorque;
        may23_DW.ECATExtraData[3] = may23_B.R2M2_RecordedTorque;
        may23_DW.ECATExtraData[4] = may23_B.DataTypeConversion3_o[0];
        may23_DW.ECATExtraData[5] = may23_B.DataTypeConversion3_o[1];
        may23_DW.ECATExtraData[6] = may23_B.DataTypeConversion3_o[2];
        may23_DW.ECATExtraData[7] = may23_B.DataTypeConversion3_o[3];
        may23_DW.ECATExtraData[8] = may23_B.DataTypeConversion5_c[0];
        may23_DW.ECATExtraData[9] = may23_B.DataTypeConversion5_c[1];

        /* MATLAB Function: '<S86>/create servo counter' */
        /* MATLAB Function 'EtherCAT Subsystem/update/create servo counter': '<S245>:1' */
        /* '<S245>:1:20' */
        /* '<S245>:1:9' */
        /* '<S245>:1:15' */
        /* '<S245>:1:50' */
        memcpy(&r1SettingsOut[0], &may23_B.errVals[0], 12U * sizeof(real_T));

        /* '<S245>:1:52' */
        i = 0;
        exitg1 = false;
        while ((!exitg1) && (i < 5)) {
          /* '<S245>:1:52' */
          robotOrientation = i << 1;
          if ((may23_B.errVals[robotOrientation] == 65569.0) &&
              (may23_B.errVals[robotOrientation + 2] == 65551.0) &&
              (may23_B.errVals[robotOrientation + 1] - 1.0 ==
               may23_B.errVals[robotOrientation + 3])) {
            /* '<S245>:1:54' */
            /* '<S245>:1:55' */
            r1SettingsOut[robotOrientation] = 0.0;

            /* '<S245>:1:56' */
            r1SettingsOut[robotOrientation + 2] = 0.0;
            exitg1 = true;
          } else {
            i++;
          }
        }

        if (!may23_DW.servoCounter_not_empty) {
          /* '<S245>:1:22' */
          /* '<S245>:1:23' */
          may23_DW.servoCounter = 131072U;
          may23_DW.servoCounter_not_empty = true;
        } else {
          i = 0;
          if (65551.0 == r1SettingsOut[0]) {
            /* '<S245>:1:26' */
            i = 1;
          }

          if (65552.0 == r1SettingsOut[0]) {
            /* '<S245>:1:26' */
            i++;
          }

          if (65537.0 == r1SettingsOut[0]) {
            /* '<S245>:1:26' */
            i++;
          }

          if (i != 0) {
            /* '<S245>:1:26' */
            /* '<S245>:1:29' */
            y = rt_roundd_snf(r1SettingsOut[0]);
            if (y < 4.294967296E+9) {
              if (y >= 0.0) {
                q0 = (uint32_T)y;
              } else {
                q0 = 0U;
              }
            } else {
              q0 = MAX_uint32_T;
            }

            may23_DW.servoCounter = q0;
          } else {
            if (65551.0 == r1SettingsOut[2]) {
              /* '<S245>:1:30' */
              i = 1;
            }

            if (65552.0 == r1SettingsOut[2]) {
              /* '<S245>:1:30' */
              i++;
            }

            if (i != 0) {
              /* '<S245>:1:30' */
              /* '<S245>:1:33' */
              y = rt_roundd_snf(r1SettingsOut[2]);
              if (y < 4.294967296E+9) {
                if (y >= 0.0) {
                  q0 = (uint32_T)y;
                } else {
                  q0 = 0U;
                }
              } else {
                q0 = MAX_uint32_T;
              }

              may23_DW.servoCounter = q0;
            } else {
              if (65551.0 == r1SettingsOut[4]) {
                /* '<S245>:1:34' */
                i = 1;
              }

              if (65552.0 == r1SettingsOut[4]) {
                /* '<S245>:1:34' */
                i++;
              }

              if (i != 0) {
                /* '<S245>:1:34' */
                /* '<S245>:1:37' */
                y = rt_roundd_snf(r1SettingsOut[4]);
                if (y < 4.294967296E+9) {
                  if (y >= 0.0) {
                    q0 = (uint32_T)y;
                  } else {
                    q0 = 0U;
                  }
                } else {
                  q0 = MAX_uint32_T;
                }

                may23_DW.servoCounter = q0;
              } else if (may23_DW.servoCounter == 2147483648U) {
                /* '<S245>:1:39' */
                /* '<S245>:1:40' */
                may23_DW.servoCounter = 131072U;
              } else {
                /* '<S245>:1:42' */
                q0 = may23_DW.servoCounter;
                qY = q0 + 1U;
                if (qY < q0) {
                  qY = MAX_uint32_T;
                }

                may23_DW.servoCounter = qY;
              }
            }
          }
        }

        /* '<S245>:1:46' */
        may23_B.servoCounterOut = may23_DW.servoCounter;

        /* End of MATLAB Function: '<S86>/create servo counter' */

        /* DataStoreWrite: '<S86>/Servo Write' */
        may23_DW.ServoUpdate = may23_B.servoCounterOut;
        may23_DW.update_SubsysRanBC = 4;

        /* End of Outputs for SubSystem: '<S66>/update' */

        /* Outputs for Function Call SubSystem: '<S30>/createKINData' */
        /* Event: '<S72>:209' */
        may23_createKINData();

        /* End of Outputs for SubSystem: '<S30>/createKINData' */
        break;

       case may23_IN_RunPMAC:
        /* Outputs for Function Call SubSystem: '<S68>/update settings' */
        /* DataStoreWrite: '<S263>/Data Store Write1' */
        /* During 'RunPMAC': '<S72>:221' */
        /* Event: '<S72>:208' */
        memcpy(&may23_DW.Kinematics[0], &may23_B.robot1DataOut[0], 10U * sizeof
               (real_T));
        memcpy(&may23_DW.Kinematics[10], &may23_B.robot2DataOut[0], 10U * sizeof
               (real_T));

        /* DataStoreWrite: '<S263>/Data Store Write2' */
        may23_DW.ServoUpdate = may23_B.MinMax1;

        /* DataStoreWrite: '<S263>/Data Store Write3' */
        may23_DW.DelayEstimates[0] = may23_B.Conversion7[0];
        may23_DW.DelayEstimates[1] = may23_B.Conversion7[1];
        may23_DW.DelayEstimates[2] = may23_B.Conversion7[2];
        may23_DW.DelayEstimates[3] = may23_B.Conversion7[3];

        /* DataStoreWrite: '<S263>/Data Store Write4' */
        for (i = 0; i < 6; i++) {
          may23_DW.PrimaryEncoderData[i] = may23_B.robot1PrimaryEncDataOut[i];
        }

        for (i = 0; i < 6; i++) {
          may23_DW.PrimaryEncoderData[i + 6] = may23_B.robot2PrimaryEncDataOut[i];
        }

        /* End of DataStoreWrite: '<S263>/Data Store Write4' */

        /* DataStoreWrite: '<S263>/Data Store Write5' */
        may23_DW.CalibrationButton = may23_B.SFunction_o7;

        /* MATLAB Function: '<S263>/update status format' */
        /* MATLAB Function 'DataLogging/Poll KINARM/PMAC Subsystem/update settings/update status format': '<S274>:1' */
        /* '<S274>:1:4' */
        for (i = 0; i < 7; i++) {
          may23_B.outStatus[i] = 0U;
        }

        /* '<S274>:1:5' */
        may23_B.outStatus[4] = may23_B.Convert2_o[1];
        may23_B.outStatus[5] = may23_B.Convert2_o[2];

        /* '<S274>:1:7' */
        /* '<S274>:1:9' */
        /* '<S274>:1:12' */
        /* '<S274>:1:13' */
        q0 = may23_B.Convert2_o[0];
        if ((int32_T)(q0 & 1U) == 1) {
          /* '<S274>:1:14' */
          /* '<S274>:1:15' */
          may23_B.outStatus[0] = 2U;
        } else {
          /* '<S274>:1:17' */
          may23_B.outStatus[0] = 0U;
        }

        /* '<S274>:1:12' */
        /* '<S274>:1:13' */
        q0 = may23_B.Convert2_o[0] >> 1U;
        if ((int32_T)(q0 & 1U) == 1) {
          /* '<S274>:1:14' */
          /* '<S274>:1:15' */
          may23_B.outStatus[1] = 2U;
        } else {
          /* '<S274>:1:17' */
          may23_B.outStatus[1] = 0U;
        }

        /* '<S274>:1:12' */
        /* '<S274>:1:13' */
        q0 = may23_B.Convert2_o[0] >> 2U;
        if ((int32_T)(q0 & 1U) == 1) {
          /* '<S274>:1:14' */
          /* '<S274>:1:15' */
          may23_B.outStatus[2] = 2U;
        } else {
          /* '<S274>:1:17' */
          may23_B.outStatus[2] = 0U;
        }

        /* '<S274>:1:12' */
        /* '<S274>:1:13' */
        q0 = may23_B.Convert2_o[0] >> 3U;
        if ((int32_T)(q0 & 1U) == 1) {
          /* '<S274>:1:14' */
          /* '<S274>:1:15' */
          may23_B.outStatus[3] = 2U;
        } else {
          /* '<S274>:1:17' */
          may23_B.outStatus[3] = 0U;
        }

        /* End of MATLAB Function: '<S263>/update status format' */

        /* DataStoreWrite: '<S263>/Data Store Write7' */
        for (i = 0; i < 7; i++) {
          may23_DW.SystemStatus[i] = may23_B.outStatus[i];
        }

        /* End of DataStoreWrite: '<S263>/Data Store Write7' */

        /* DataStoreWrite: '<S263>/Data Store Write' incorporates:
         *  Constant: '<S263>/Constant'
         */
        memcpy(&may23_DW.DataReadyStatus[0], &may23_P.Constant_Value_mh[0], 10U *
               sizeof(real_T));
        may23_DW.updatesettings_SubsysRanBC = 4;

        /* End of Outputs for SubSystem: '<S68>/update settings' */

        /* Outputs for Function Call SubSystem: '<S30>/createKINData' */
        /* Event: '<S72>:209' */
        may23_createKINData();

        /* End of Outputs for SubSystem: '<S30>/createKINData' */
        break;

       default:
        /* Outputs for Function Call SubSystem: '<S70>/Data write' */
        /* DataStoreWrite: '<S284>/Data Store Write1' */
        /* During 'RunSim': '<S72>:217' */
        /* Event: '<S72>:206' */
        memcpy(&may23_DW.Kinematics[0], &may23_B.kinematics[0], 20U * sizeof
               (real_T));

        /* DataStoreWrite: '<S284>/Data Store Write4' */
        memcpy(&may23_DW.PrimaryEncoderData[0], &may23_B.primary[0], 12U *
               sizeof(real_T));

        /* DataStoreWrite: '<S284>/Data Store Write2' */
        may23_DW.ServoUpdate = may23_B.Output_d;

        /* DataStoreWrite: '<S284>/Data Store Write5' */
        may23_DW.CalibrationButton = may23_B.Constant_d;

        /* DataStoreWrite: '<S284>/Data Store Write7' */
        for (i = 0; i < 7; i++) {
          may23_DW.SystemStatus[i] = may23_B.Constant1[i];
        }

        /* End of DataStoreWrite: '<S284>/Data Store Write7' */

        /* DataStoreWrite: '<S284>/Data Store Write3' incorporates:
         *  Constant: '<S284>/Constant'
         */
        may23_DW.DelayEstimates[0] = may23_P.Constant_Value_m[0];
        may23_DW.DelayEstimates[1] = may23_P.Constant_Value_m[1];
        may23_DW.DelayEstimates[2] = may23_P.Constant_Value_m[2];
        may23_DW.DelayEstimates[3] = may23_P.Constant_Value_m[3];

        /* DataStoreWrite: '<S284>/Data Store Write' incorporates:
         *  Constant: '<S284>/Constant1'
         */
        memcpy(&may23_DW.DataReadyStatus[0], &may23_P.Constant1_Value_f[0], 10U *
               sizeof(real_T));
        may23_DW.Datawrite_SubsysRanBC_h = 4;

        /* End of Outputs for SubSystem: '<S70>/Data write' */

        /* Outputs for Function Call SubSystem: '<S30>/createKINData' */
        /* Event: '<S72>:209' */
        may23_createKINData();

        /* End of Outputs for SubSystem: '<S30>/createKINData' */
        break;
      }
    }

    /* End of Chart: '<S30>/control read write' */

    /* Sum: '<S236>/FixPt Sum1' incorporates:
     *  Constant: '<S236>/FixPt Constant'
     */
    may23_B.FixPtSum1_j = may23_B.Output_hd + may23_P.FixPtConstant_Value_j;

    /* Switch: '<S237>/FixPt Switch' incorporates:
     *  Constant: '<S237>/Constant'
     */
    if (may23_B.FixPtSum1_j > may23_P.WrapToZero_Threshold_d) {
      may23_B.FixPtSwitch_e = may23_P.Constant_Value_mv;
    } else {
      may23_B.FixPtSwitch_e = may23_B.FixPtSum1_j;
    }

    /* End of Switch: '<S237>/FixPt Switch' */

    /* Switch: '<S66>/Switch1' incorporates:
     *  Constant: '<S66>/activation'
     */
    if (may23_P.activation_Value[1] >= may23_P.Switch1_Threshold_m) {
      memcpy(&may23_B.Switch1_b[0], &may23_B.BKINEtherCATinit1_o4[0], 21U *
             sizeof(int32_T));
    } else {
      memcpy(&may23_B.Switch1_b[0], &may23_B.BKINEtherCATinit_o4[0], 21U *
             sizeof(int32_T));
    }

    /* End of Switch: '<S66>/Switch1' */

    /* Sum: '<S280>/FixPt Sum1' incorporates:
     *  Constant: '<S280>/FixPt Constant'
     */
    may23_B.FixPtSum1_l = may23_B.Output_n + may23_P.FixPtConstant_Value_a;

    /* Switch: '<S281>/FixPt Switch' incorporates:
     *  Constant: '<S281>/Constant'
     */
    if (may23_B.FixPtSum1_l > may23_P.WrapToZero_Threshold_c) {
      may23_B.FixPtSwitch_f = may23_P.Constant_Value_i;
    } else {
      may23_B.FixPtSwitch_f = may23_B.FixPtSum1_l;
    }

    /* End of Switch: '<S281>/FixPt Switch' */

    /* RateTransition: '<S69>/Rate Transition' */
    if (may23_M->Timing.RateInteraction.TID1_3) {
      may23_DW.RateTransition_Buffer_h = may23_B.LogicalOperator;
    }

    /* End of RateTransition: '<S69>/Rate Transition' */

    /* Selector: '<S75>/Selector' */
    for (i = 0; i < 50; i++) {
      may23_B.Selector_i2[i] = may23_B.kinarm_data[3 * i];
    }

    /* End of Selector: '<S75>/Selector' */

    /* Selector: '<S75>/Selector1' */
    for (i = 0; i < 50; i++) {
      may23_B.Selector1_b[i] = may23_B.kinarm_data[3 * i + 1];
    }

    /* End of Selector: '<S75>/Selector1' */

    /* Selector: '<S75>/Selector2' */
    for (i = 0; i < 50; i++) {
      may23_B.Selector2_e[i] = may23_B.kinarm_data[3 * i + 2];
    }

    /* End of Selector: '<S75>/Selector2' */

    /* MATLAB Function: '<S75>/splitKINData arm1' */
    may23_splitKINDataarm1(may23_B.Selector_i2, &may23_B.sf_splitKINDataarm1);

    /* MATLAB Function: '<S75>/splitKINData arm2' */
    may23_splitKINDataarm1(may23_B.Selector1_b, &may23_B.sf_splitKINDataarm2);

    /* MATLAB Function: '<S75>/splitKINDataGeneral' incorporates:
     *  Constant: '<S75>/Subject_Arm'
     */
    /* MATLAB Function 'DataLogging/Poll KINARM/make KINData bus/splitKINDataGeneral': '<S305>:1' */
    /* '<S305>:1:5' */
    /* '<S305>:1:6' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.general.robot_arm
      = may23_B.Selector2_e[0];

    /* '<S305>:1:7' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.general.subject_arm
      = may23_P.Subject_Arm_Value;

    /* '<S305>:1:8' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.hand_feedback.feed_forward
      = may23_B.Selector2_e[1];

    /* '<S305>:1:9' */
    may23_B.handFF_Dex = may23_B.Selector2_e[6];

    /* '<S305>:1:10' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.hand_feedback.arm
      = may23_B.Selector2_e[2];

    /* '<S305>:1:11' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.hand_feedback.control
      = may23_B.Selector2_e[3];

    /* '<S305>:1:12' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.hand_feedback.color
      = may23_B.Selector2_e[4];

    /* '<S305>:1:13' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.hand_feedback.rad
      = may23_B.Selector2_e[5];

    /* '<S305>:1:15' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.general.delay_estimates
      [0] = may23_B.Selector2_e[7];
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.general.delay_estimates
      [1] = may23_B.Selector2_e[8];
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.general.delay_estimates
      [2] = may23_B.Selector2_e[9];
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.general.delay_estimates
      [3] = may23_B.Selector2_e[10];

    /* '<S305>:1:16' */
    may23_B.servoCounter = may23_B.Selector2_e[11];

    /* '<S305>:1:17' */
    may23_B.calibrationButtonBits = may23_B.Selector2_e[12];

    /* '<S305>:1:20' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.has_gaze
      = may23_B.Selector2_e[13];

    /* '<S305>:1:21' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.feedback_control
      = may23_B.Selector2_e[14];

    /* '<S305>:1:23' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.location
      [0] = may23_B.Selector2_e[15];
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.location
      [1] = may23_B.Selector2_e[16];

    /* '<S305>:1:24' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.timestamp
      = may23_B.Selector2_e[17];

    /* '<S305>:1:25' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.pupil_area
      = may23_B.Selector2_e[18];

    /* '<S305>:1:26' */
    /* '<S305>:1:27' */
    /* '<S305>:1:28' */
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.event
      [0] = may23_B.Selector2_e[19];
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.gaze_vector
      [0] = may23_B.Selector2_e[22];
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.pupil_locatoin
      [0] = may23_B.Selector2_e[25];
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.event
      [1] = may23_B.Selector2_e[20];
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.gaze_vector
      [1] = may23_B.Selector2_e[23];
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.pupil_locatoin
      [1] = may23_B.Selector2_e[26];
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.event
      [2] = may23_B.Selector2_e[21];
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.gaze_vector
      [2] = may23_B.Selector2_e[24];
    may23_B.BusConversion_InsertedFor_Forces_to_Torques_at_inport_1_BusCrea.gaze.pupil_locatoin
      [2] = may23_B.Selector2_e[27];
    may23_B.active_arm = may23_B.Selector2_e[0];

    /* Selector: '<S76>/Selector1' */
    for (i = 0; i < 6; i++) {
      may23_B.Selector1_e[i] = may23_B.primary_encoder_data_out[(i << 1) + 1];
    }

    /* End of Selector: '<S76>/Selector1' */

    /* Selector: '<S76>/Selector2' */
    for (i = 0; i < 6; i++) {
      may23_B.Selector2_l[i] = may23_B.primary_encoder_data_out[i << 1];
    }

    /* End of Selector: '<S76>/Selector2' */

    /* MATLAB Function: '<S76>/split_primary' */
    may23_split_primary(may23_B.Selector2_l, &may23_B.sf_split_primary);

    /* MATLAB Function: '<S76>/split_primary1' */
    may23_split_primary(may23_B.Selector1_e, &may23_B.sf_split_primary1);

    /* Constant: '<S290>/Arm Shoulder Angle Offset' */
    may23_B.shoulderangleoffset = may23_P.ArmShoulderAngleOffset_Value;

    /* Constant: '<S290>/Arm Elbow Angle Offset' */
    may23_B.elbowangleoffset = may23_P.ArmElbowAngleOffset_Value;

    /* Constant: '<S290>/Arm Shoulder X' */
    may23_B.ShoulderX = may23_P.ArmShoulderX_Value;

    /* Constant: '<S290>/Arm Shoulder Y' */
    may23_B.ShoulderY = may23_P.ArmShoulderY_Value;

    /* Constant: '<S290>/Arm L1' */
    may23_B.L1 = may23_P.ArmL1_Value;

    /* Constant: '<S290>/Arm L2' */
    may23_B.L2 = may23_P.ArmL2_Value;

    /* Constant: '<S290>/Arm Pointer Offset' */
    may23_B.Pointeroffset = may23_P.ArmPointerOffset_Value;

    /* Constant: '<S290>/Arm L3 Error' */
    may23_B.L3Error = may23_P.ArmL3Error_Value;

    /* Constant: '<S290>/Arm robot type' */
    may23_B.robottype_a = may23_P.Armrobottype_Value;

    /* Constant: '<S290>/Arm Torque Constant' */
    may23_B.torqueconstant_bz = may23_P.ArmTorqueConstant_Value;

    /* Constant: '<S290>/Arm robot version' */
    may23_B.robotversion_h = may23_P.Armrobotversion_Value;

    /* Constant: '<S291>/Arm Shoulder Angle Offset' */
    may23_B.shoulderangleoffset_j = may23_P.ArmShoulderAngleOffset_Value_i;

    /* Constant: '<S291>/Arm Elbow Angle Offset' */
    may23_B.elbowangleoffset_o = may23_P.ArmElbowAngleOffset_Value_g;

    /* Constant: '<S291>/Arm Shoulder X' */
    may23_B.ShoulderX_b = may23_P.ArmShoulderX_Value_l;

    /* Constant: '<S291>/Arm Shoulder Y' */
    may23_B.ShoulderY_n = may23_P.ArmShoulderY_Value_e;

    /* Constant: '<S291>/Arm L1' */
    may23_B.L1_e = may23_P.ArmL1_Value_f;

    /* Constant: '<S291>/Arm L2' */
    may23_B.L2_j = may23_P.ArmL2_Value_g;

    /* Constant: '<S291>/Arm Pointer Offset' */
    may23_B.Pointeroffset_a = may23_P.ArmPointerOffset_Value_g;

    /* Constant: '<S291>/Arm L3 Error' */
    may23_B.L3Error_a = may23_P.ArmL3Error_Value_g;

    /* Constant: '<S291>/Arm robot type' */
    may23_B.robottype_j = may23_P.Armrobottype_Value_k;

    /* Constant: '<S291>/Arm Torque Constant' */
    may23_B.torqueconstant_l = may23_P.ArmTorqueConstant_Value_g;

    /* Constant: '<S291>/Arm robot version' */
    may23_B.robotversion_f = may23_P.Armrobotversion_Value_e;

    /* Outputs for Enabled SubSystem: '<S71>/update constants subsystem' incorporates:
     *  EnablePort: '<S292>/Enable'
     */
    /* Constant: '<S71>/update constants' */
    if (may23_P.updateconstants_Value > 0.0) {
      /* DataStoreWrite: '<S292>/Data Store Write' */
      may23_DW.RobotCalibrations[0] = may23_B.shoulderangleoffset;
      may23_DW.RobotCalibrations[1] = may23_B.elbowangleoffset;
      may23_DW.RobotCalibrations[2] = may23_B.ShoulderX;
      may23_DW.RobotCalibrations[3] = may23_B.ShoulderY;
      may23_DW.RobotCalibrations[4] = may23_B.L1;
      may23_DW.RobotCalibrations[5] = may23_B.L2;
      may23_DW.RobotCalibrations[6] = may23_B.Pointeroffset;
      may23_DW.RobotCalibrations[7] = may23_B.L3Error;
      may23_DW.RobotCalibrations[8] = may23_B.shoulderangleoffset_j;
      may23_DW.RobotCalibrations[9] = may23_B.elbowangleoffset_o;
      may23_DW.RobotCalibrations[10] = may23_B.ShoulderX_b;
      may23_DW.RobotCalibrations[11] = may23_B.ShoulderY_n;
      may23_DW.RobotCalibrations[12] = may23_B.L1_e;
      may23_DW.RobotCalibrations[13] = may23_B.L2_j;
      may23_DW.RobotCalibrations[14] = may23_B.Pointeroffset_a;
      may23_DW.RobotCalibrations[15] = may23_B.L3Error_a;

      /* DataStoreWrite: '<S292>/Data Store Write1' incorporates:
       *  Constant: '<S290>/Arm Force Sensor Angle Offset'
       *  Constant: '<S290>/Arm L2 L5 Angle'
       *  Constant: '<S290>/Arm L5'
       *  Constant: '<S291>/Arm Force Sensor Angle Offset'
       *  Constant: '<S291>/Arm L2 L5 Angle'
       *  Constant: '<S291>/Arm L5'
       *  Constant: '<S292>/Ready'
       */
      may23_DW.HardwareSettings[0] = may23_B.robottype_a;
      may23_DW.HardwareSettings[1] = may23_B.torqueconstant_bz;
      may23_DW.HardwareSettings[2] = may23_P.ArmL5_Value;
      may23_DW.HardwareSettings[3] = may23_P.ArmL2L5Angle_Value;
      may23_DW.HardwareSettings[4] = may23_P.ArmForceSensorAngleOffset_Value;
      may23_DW.HardwareSettings[5] = may23_B.ArmOrientation_f;
      may23_DW.HardwareSettings[6] = may23_B.M1orientation_b;
      may23_DW.HardwareSettings[7] = may23_B.M2Orientation_k;
      may23_DW.HardwareSettings[8] = may23_B.M1GearRatio_p;
      may23_DW.HardwareSettings[9] = may23_B.M2GearRatio_i;
      may23_DW.HardwareSettings[10] = may23_B.HasSecondaryEnc_n;
      may23_DW.HardwareSettings[11] = may23_B.robotversion_h;
      may23_DW.HardwareSettings[12] = may23_B.robottype_j;
      may23_DW.HardwareSettings[13] = may23_B.torqueconstant_l;
      may23_DW.HardwareSettings[14] = may23_P.ArmL5_Value_j;
      may23_DW.HardwareSettings[15] = may23_P.ArmL2L5Angle_Value_h;
      may23_DW.HardwareSettings[16] = may23_P.ArmForceSensorAngleOffset_Value_l;
      may23_DW.HardwareSettings[17] = may23_B.ArmOrientation_m;
      may23_DW.HardwareSettings[18] = may23_B.M1orientation_f;
      may23_DW.HardwareSettings[19] = may23_B.M2Orientation_c;
      may23_DW.HardwareSettings[20] = may23_B.M1GearRatio_a;
      may23_DW.HardwareSettings[21] = may23_B.M2GearRatio_ie;
      may23_DW.HardwareSettings[22] = may23_B.HasSecondaryEnc_c;
      may23_DW.HardwareSettings[23] = may23_B.robotversion_f;
      may23_DW.HardwareSettings[24] = may23_P.Ready_Value;

      /* DataStoreWrite: '<S292>/Data Store Write8' incorporates:
       *  Constant: '<S292>/Arm Force Sensors'
       */
      may23_DW.ArmForceSensors[0] = may23_P.ArmForceSensors_Value[0];
      may23_DW.ArmForceSensors[1] = may23_P.ArmForceSensors_Value[1];
      may23_DW.ArmForceSensors[2] = may23_P.ArmForceSensors_Value[2];
      srUpdateBC(may23_DW.updateconstantssubsystem_SubsysRanBC);
    }

    /* End of Constant: '<S71>/update constants' */
    /* End of Outputs for SubSystem: '<S71>/update constants subsystem' */

    /* DataStoreRead: '<S290>/Status read1' */
    may23_B.Statusread1[0] = may23_DW.RobotRevision[0];
    may23_B.Statusread1[1] = may23_DW.RobotRevision[1];

    /* MATLAB Function: '<S290>/decode robot' */
    /* MATLAB Function 'DataLogging/Poll KINARM/constants/arm1/decode robot': '<S293>:1' */
    /* '<S293>:1:3' */
    may23_B.isEP_a = 0.0;

    /* '<S293>:1:4' */
    may23_B.isHumanEXO_c = 0.0;

    /* '<S293>:1:5' */
    may23_B.isNHPEXO_p = 0.0;

    /* '<S293>:1:6' */
    may23_B.isClassicExo_n = 0.0;

    /* '<S293>:1:7' */
    may23_B.isUTSEXO_k = 0.0;

    /* '<S293>:1:8' */
    may23_B.isPMAC_c = 0.0;

    /* '<S293>:1:9' */
    may23_B.isECAT_b = 0.0;
    if (may23_B.robottype_a == 0.0) {
      /* '<S293>:1:11' */
      /* '<S293>:1:12' */
      may23_B.isHumanEXO_c = 1.0;
      if (may23_B.robotversion_h == 1.0) {
        /* '<S293>:1:13' */
        /* '<S293>:1:14' */
        may23_B.isClassicExo_n = 1.0;
      } else {
        if (may23_B.robotversion_h == 2.0) {
          /* '<S293>:1:15' */
          /* '<S293>:1:16' */
          may23_B.isUTSEXO_k = 1.0;
        }
      }
    } else if (may23_B.robottype_a == 1.0) {
      /* '<S293>:1:18' */
      /* '<S293>:1:19' */
      may23_B.isEP_a = 1.0;
    } else {
      if (may23_B.robottype_a == 2.0) {
        /* '<S293>:1:20' */
        /* '<S293>:1:21' */
        may23_B.isNHPEXO_p = 1.0;
        if (may23_B.robotversion_h == 1.0) {
          /* '<S293>:1:22' */
          /* '<S293>:1:23' */
          may23_B.isClassicExo_n = 1.0;
        } else {
          if (may23_B.robotversion_h == 2.0) {
            /* '<S293>:1:24' */
            /* '<S293>:1:25' */
            may23_B.isUTSEXO_k = 1.0;
          }
        }
      }
    }

    if (may23_B.systemtype == 1.0) {
      /* '<S293>:1:29' */
      /* '<S293>:1:30' */
      may23_B.isPMAC_c = 1.0;
    } else {
      if (may23_B.systemtype == 2.0) {
        /* '<S293>:1:31' */
        /* '<S293>:1:32' */
        may23_B.isECAT_b = 1.0;
      }
    }

    /* End of MATLAB Function: '<S290>/decode robot' */

    /* DataStoreRead: '<S291>/Status read1' */
    may23_B.Statusread1_c[0] = may23_DW.RobotRevision[0];
    may23_B.Statusread1_c[1] = may23_DW.RobotRevision[1];

    /* MATLAB Function: '<S291>/decode robot' */
    /* MATLAB Function 'DataLogging/Poll KINARM/constants/arm2/decode robot': '<S294>:1' */
    /* '<S294>:1:3' */
    may23_B.isEP_e = 0.0;

    /* '<S294>:1:4' */
    may23_B.isHumanEXO = 0.0;

    /* '<S294>:1:5' */
    may23_B.isNHPEXO = 0.0;

    /* '<S294>:1:6' */
    may23_B.isClassicExo_e = 0.0;

    /* '<S294>:1:7' */
    may23_B.isUTSEXO = 0.0;

    /* '<S294>:1:8' */
    may23_B.isPMAC_a = 0.0;

    /* '<S294>:1:9' */
    may23_B.isECAT_i = 0.0;
    if (may23_B.robottype_j == 0.0) {
      /* '<S294>:1:11' */
      /* '<S294>:1:12' */
      may23_B.isHumanEXO = 1.0;
      if (may23_B.robotversion_f == 1.0) {
        /* '<S294>:1:13' */
        /* '<S294>:1:14' */
        may23_B.isClassicExo_e = 1.0;
      } else {
        if (may23_B.robotversion_f == 2.0) {
          /* '<S294>:1:15' */
          /* '<S294>:1:16' */
          may23_B.isUTSEXO = 1.0;
        }
      }
    } else if (may23_B.robottype_j == 1.0) {
      /* '<S294>:1:18' */
      /* '<S294>:1:19' */
      may23_B.isEP_e = 1.0;
    } else {
      if (may23_B.robottype_j == 2.0) {
        /* '<S294>:1:20' */
        /* '<S294>:1:21' */
        may23_B.isNHPEXO = 1.0;
        if (may23_B.robotversion_f == 1.0) {
          /* '<S294>:1:22' */
          /* '<S294>:1:23' */
          may23_B.isClassicExo_e = 1.0;
        } else {
          if (may23_B.robotversion_f == 2.0) {
            /* '<S294>:1:24' */
            /* '<S294>:1:25' */
            may23_B.isUTSEXO = 1.0;
          }
        }
      }
    }

    if (may23_B.systemtype == 1.0) {
      /* '<S294>:1:29' */
      /* '<S294>:1:30' */
      may23_B.isPMAC_a = 1.0;
    } else {
      if (may23_B.systemtype == 2.0) {
        /* '<S294>:1:31' */
        /* '<S294>:1:32' */
        may23_B.isECAT_i = 1.0;
      }
    }

    /* End of MATLAB Function: '<S291>/decode robot' */
    /* user code (Output function Trailer for TID0) */
    {
      /*------------ S-Function Block: <S66>/BKIN EtherCATinit1 Process Received Frames ------------*/
      real_T pauseDuration;
      real_T elapsedTime;
      real_T minDCSyncPauseDuration;
      int32_T minDCSyncPauseDurationMicroSec =
        ECAT_MIN_PAUSE_BEFORE_READ_PREOP_US;
      if ((may23_P.activation_Value[0]) == ECAT_PREOP_PAUSE_TEST) {
        minDCSyncPauseDurationMicroSec = may23_P.activation_Value[1];
      }

      if (may23_DW.BKINEtherCATinit1_DWORK3) {
        minDCSyncPauseDuration = minDCSyncPauseDurationMicroSec * 1e-6;
        elapsedTime = xpcGetElapsedTime(NULL) -
          may23_DW.BKINEtherCATinit1_DWORK4;
        if (elapsedTime < minDCSyncPauseDuration) {
          pauseDuration = minDCSyncPauseDuration - elapsedTime;
          xpcBusyWait(pauseDuration);
        }

        xpcEtherCATReadProcessData(1,NULL);
      }
    }

    {
      /*------------ S-Function Block: <S66>/BKIN EtherCATinit Process Received Frames ------------*/
      real_T pauseDuration;
      real_T elapsedTime;
      real_T minDCSyncPauseDuration;
      int32_T minDCSyncPauseDurationMicroSec =
        ECAT_MIN_PAUSE_BEFORE_READ_PREOP_US;
      if ((may23_P.activation_Value[0]) == ECAT_PREOP_PAUSE_TEST) {
        minDCSyncPauseDurationMicroSec = may23_P.activation_Value[1];
      }

      if (may23_DW.BKINEtherCATinit_DWORK3) {
        minDCSyncPauseDuration = minDCSyncPauseDurationMicroSec * 1e-6;
        elapsedTime = xpcGetElapsedTime(NULL) - may23_DW.BKINEtherCATinit_DWORK4;
        if (elapsedTime < minDCSyncPauseDuration) {
          pauseDuration = minDCSyncPauseDuration - elapsedTime;
          xpcBusyWait(pauseDuration);
        }

        xpcEtherCATReadProcessData(0,NULL);
      }
    }
  }
}

/* Outputs for atomic system: '<S1>/Poll KINARM' */
void may23_PollKINARMTID3(void)
{
  int32_T i;

  /* RateTransition: '<S69>/Rate Transition' */
  may23_B.RateTransition_b = may23_DW.RateTransition_Buffer_h;

  /* Outputs for Enabled SubSystem: '<S69>/Data receive' incorporates:
   *  EnablePort: '<S276>/Enable'
   */
  if (may23_B.RateTransition_b) {
    /* S-Function (kinarmfromfile): '<S276>/S-Function' */

    /* Level2 S-Function Block: '<S276>/S-Function' (kinarmfromfile) */
    {
      SimStruct *rts = may23_M->childSfunctions[27];
      sfcnOutputs(rts,3);
    }

    /* S-Function (xpcbytepacking): '<S276>/Unpack' */

    /* Byte Unpacking: <S276>/Unpack */
    (void)memcpy((uint8_T*)&may23_B.Unpack_o[0], (uint8_T*)&may23_B.SFunction[0]
                 + 0, 52);

    /* DataTypeConversion: '<S276>/Data Type Conversion' */
    for (i = 0; i < 6; i++) {
      may23_B.DataTypeConversion_m[i] = may23_B.Unpack_o[i];
    }

    /* End of DataTypeConversion: '<S276>/Data Type Conversion' */

    /* DataTypeConversion: '<S276>/Data Type Conversion1' */
    for (i = 0; i < 6; i++) {
      may23_B.DataTypeConversion1_i[i] = may23_B.Unpack_o[i + 6];
    }

    /* End of DataTypeConversion: '<S276>/Data Type Conversion1' */

    /* DataTypeConversion: '<S276>/Data Type Conversion2' */
    may23_B.DataTypeConversion2_h = may23_B.Unpack_o[12];

    /* MATLAB Function: '<S276>/MATLAB Function' */
    /* MATLAB Function 'DataLogging/Poll KINARM/bkin_file_source/Data receive/MATLAB Function': '<S282>:1' */
    /* '<S282>:1:4' */
    may23_B.kinematics_l[6] = may23_B.DataTypeConversion_m[2];
    may23_B.kinematics_l[7] = may23_B.DataTypeConversion_m[3];
    may23_B.kinematics_l[8] = 0.0;
    may23_B.kinematics_l[9] = 0.0;
    may23_B.kinematics_l[16] = may23_B.DataTypeConversion1_i[2];
    may23_B.kinematics_l[17] = may23_B.DataTypeConversion1_i[3];
    may23_B.kinematics_l[18] = 0.0;
    may23_B.kinematics_l[19] = 0.0;

    /* '<S282>:1:5' */
    for (i = 0; i < 6; i++) {
      may23_B.kinematics_l[i] = may23_B.DataTypeConversion_m[i];
      may23_B.kinematics_l[i + 10] = may23_B.DataTypeConversion1_i[i];
      may23_B.primary_o[i] = may23_B.DataTypeConversion_m[i];
      may23_B.primary_o[i + 6] = may23_B.DataTypeConversion1_i[i];
    }

    /* End of MATLAB Function: '<S276>/MATLAB Function' */

    /* Constant: '<S276>/Constant' */
    may23_B.Constant_k = may23_P.Constant_Value_jt;

    /* Constant: '<S276>/Constant1' */
    for (i = 0; i < 7; i++) {
      may23_B.Constant1_f[i] = may23_P.Constant1_Value_pc[i];
    }

    /* End of Constant: '<S276>/Constant1' */
    srUpdateBC(may23_DW.Datareceive_SubsysRanBC_n);
  }

  /* End of Outputs for SubSystem: '<S69>/Data receive' */

  /* RateTransition generated from: '<S69>/Data write' */
  memcpy(&may23_DW.TmpRTBAtDatawriteInport2_Buffer0[0], &may23_B.kinematics_l[0],
         20U * sizeof(real_T));

  /* RateTransition generated from: '<S69>/Data write' */
  memcpy(&may23_DW.TmpRTBAtDatawriteInport3_Buffer0[0], &may23_B.primary_o[0],
         12U * sizeof(real_T));

  /* RateTransition generated from: '<S69>/Data write' */
  may23_DW.TmpRTBAtDatawriteInport4_Buffer0 = may23_B.Constant_k;

  /* RateTransition generated from: '<S69>/Data write' */
  for (i = 0; i < 7; i++) {
    may23_DW.TmpRTBAtDatawriteInport5_Buffer0[i] = may23_B.Constant1_f[i];
  }

  /* End of RateTransition generated from: '<S69>/Data write' */
}

/* Update for atomic system: '<S1>/Poll KINARM' */
void may23_PollKINARM_UpdateTID0(void)
{
  /* Update for Enabled SubSystem: '<S66>/Arm 1' incorporates:
   *  EnablePort: '<S77>/Enable'
   */
  if (may23_DW.Arm1_MODE) {
    /* Update for Memory: '<S87>/Memory' */
    may23_DW.Memory_PreviousInput_k = may23_B.sf_Whistlestate.isPermFaulted;

    /* Update for Memory: '<S88>/Memory' */
    may23_DW.Memory_PreviousInput_d = may23_B.sf_Whistlestate_a.isPermFaulted;

    /* Update for Memory: '<S97>/Memory' */
    may23_DW.Memory_PreviousInput_dp = may23_B.RateTransition_gd;

    /* Update for Memory: '<S97>/Memory1' */
    may23_DW.Memory1_PreviousInput_j = may23_B.RateTransition1_i;

    /* Update for Memory: '<S97>/Memory2' */
    may23_DW.Memory2_PreviousInput_g5[0] = may23_B.RateTransition2_ph[0];
    may23_DW.Memory2_PreviousInput_g5[1] = may23_B.RateTransition2_ph[1];

    /* Update for Atomic SubSystem: '<S87>/EMCY Message pump' */
    may23_EMCYMessagepump_Update();

    /* End of Update for SubSystem: '<S87>/EMCY Message pump' */

    /* Update for Memory: '<S77>/Memory2' */
    may23_DW.Memory2_PreviousInput_j[0] = may23_B.continuousTorques_m[0];
    may23_DW.Memory2_PreviousInput_j[1] = may23_B.continuousTorques_m[1];

    /* Update for Memory: '<S77>/Memory3' */
    may23_DW.Memory3_PreviousInput_h = may23_B.constantsReady_p;

    /* Update for Atomic SubSystem: '<S88>/EMCY Message pump' */
    may23_EMCYMessagepump_h_Update();

    /* End of Update for SubSystem: '<S88>/EMCY Message pump' */

    /* Update for Enabled SubSystem: '<S77>/M1 AbsEnc Calibration' incorporates:
     *  EnablePort: '<S91>/Enable'
     */
    if (may23_DW.M1AbsEncCalibration_MODE_c) {
      /* Update for Memory: '<S91>/Memory' */
      may23_DW.Memory_PreviousInput_l =
        may23_B.BKINEtherCATAsyncSDODownload_o1_l;

      /* Update for Memory: '<S91>/Memory1' */
      may23_DW.Memory1_PreviousInput_p[0] =
        may23_B.BKINEtherCATAsyncSDOUpload_o1_kp;
      may23_DW.Memory1_PreviousInput_p[1] =
        may23_B.BKINEtherCATAsyncSDOUpload_o2_pz;
    }

    /* End of Update for SubSystem: '<S77>/M1 AbsEnc Calibration' */

    /* Update for Enabled SubSystem: '<S77>/M2 AbsEnc Calibration' incorporates:
     *  EnablePort: '<S92>/Enable'
     */
    if (may23_DW.M2AbsEncCalibration_MODE_p) {
      /* Update for Memory: '<S92>/Memory' */
      may23_DW.Memory_PreviousInput_kk =
        may23_B.BKINEtherCATAsyncSDODownload_o1_h1;

      /* Update for Memory: '<S92>/Memory1' */
      may23_DW.Memory1_PreviousInput_i[0] =
        may23_B.BKINEtherCATAsyncSDOUpload_o1_g;
      may23_DW.Memory1_PreviousInput_i[1] =
        may23_B.BKINEtherCATAsyncSDOUpload_o2_b;
    }

    /* End of Update for SubSystem: '<S77>/M2 AbsEnc Calibration' */

    /* Update for Atomic SubSystem: '<S77>/SDO reading' */
    may23_SDOreading_Update();

    /* End of Update for SubSystem: '<S77>/SDO reading' */

    /* Update for Atomic SubSystem: '<S77>/SDO writing' */
    may23_SDOwriting_Update();

    /* End of Update for SubSystem: '<S77>/SDO writing' */
  }

  /* End of Update for SubSystem: '<S66>/Arm 1' */

  /* Update for Enabled SubSystem: '<S66>/Arm 2' incorporates:
   *  EnablePort: '<S78>/Enable'
   */
  if (may23_DW.Arm2_MODE) {
    /* Update for Memory: '<S162>/Memory' */
    may23_DW.Memory_PreviousInput_c = may23_B.sf_Whistlestate_l.isPermFaulted;

    /* Update for Memory: '<S163>/Memory' */
    may23_DW.Memory_PreviousInput_g = may23_B.sf_Whistlestate_m.isPermFaulted;

    /* Update for Memory: '<S172>/Memory' */
    may23_DW.Memory_PreviousInput_b = may23_B.RateTransition_ep;

    /* Update for Memory: '<S172>/Memory1' */
    may23_DW.Memory1_PreviousInput_n = may23_B.RateTransition1_p;

    /* Update for Memory: '<S172>/Memory2' */
    may23_DW.Memory2_PreviousInput_o[0] = may23_B.RateTransition2_j[0];
    may23_DW.Memory2_PreviousInput_o[1] = may23_B.RateTransition2_j[1];

    /* Update for Atomic SubSystem: '<S162>/EMCY Message pump' */
    may23_EMCYMessagepump_k_Update();

    /* End of Update for SubSystem: '<S162>/EMCY Message pump' */

    /* Update for Memory: '<S78>/Memory2' */
    may23_DW.Memory2_PreviousInput_g[0] = may23_B.continuousTorques[0];
    may23_DW.Memory2_PreviousInput_g[1] = may23_B.continuousTorques[1];

    /* Update for Memory: '<S78>/Memory3' */
    may23_DW.Memory3_PreviousInput_k = may23_B.constantsReady;

    /* Update for Atomic SubSystem: '<S163>/EMCY Message pump' */
    may23_EMCYMessagepump_hc_Update();

    /* End of Update for SubSystem: '<S163>/EMCY Message pump' */

    /* Update for Enabled SubSystem: '<S78>/M1 AbsEnc Calibration' incorporates:
     *  EnablePort: '<S165>/Enable'
     */
    if (may23_DW.M1AbsEncCalibration_MODE) {
      /* Update for Memory: '<S165>/Memory' */
      may23_DW.Memory_PreviousInput_a =
        may23_B.BKINEtherCATAsyncSDODownload_o1_d;

      /* Update for Memory: '<S165>/Memory1' */
      may23_DW.Memory1_PreviousInput_b[0] =
        may23_B.BKINEtherCATAsyncSDOUpload_o1_d2;
      may23_DW.Memory1_PreviousInput_b[1] =
        may23_B.BKINEtherCATAsyncSDOUpload_o2_f;
    }

    /* End of Update for SubSystem: '<S78>/M1 AbsEnc Calibration' */

    /* Update for Enabled SubSystem: '<S78>/M2 AbsEnc Calibration' incorporates:
     *  EnablePort: '<S166>/Enable'
     */
    if (may23_DW.M2AbsEncCalibration_MODE) {
      /* Update for Memory: '<S166>/Memory' */
      may23_DW.Memory_PreviousInput_po =
        may23_B.BKINEtherCATAsyncSDODownload_o1_f;

      /* Update for Memory: '<S166>/Memory1' */
      may23_DW.Memory1_PreviousInput_ck[0] =
        may23_B.BKINEtherCATAsyncSDOUpload_o1_k1;
      may23_DW.Memory1_PreviousInput_ck[1] =
        may23_B.BKINEtherCATAsyncSDOUpload_o2;
    }

    /* End of Update for SubSystem: '<S78>/M2 AbsEnc Calibration' */

    /* Update for Atomic SubSystem: '<S78>/SDO reading' */
    may23_SDOreading_a_Update();

    /* End of Update for SubSystem: '<S78>/SDO reading' */

    /* Update for Atomic SubSystem: '<S78>/SDO writing' */
    may23_SDOwriting_g_Update();

    /* End of Update for SubSystem: '<S78>/SDO writing' */
  }

  /* End of Update for SubSystem: '<S66>/Arm 2' */

  /* Update for Atomic SubSystem: '<S30>/Force Sensor Control' */
  may23_ForceSensorControl_Update();

  /* End of Update for SubSystem: '<S30>/Force Sensor Control' */

  /* Update for Enabled SubSystem: '<S70>/Data receive' incorporates:
   *  EnablePort: '<S283>/Enable'
   */
  if (may23_B.Compare_e2) {
    /* Update for UnitDelay: '<S286>/Output' */
    may23_DW.Output_DSTATE_a = may23_B.FixPtSwitch_o;
  }

  /* End of Update for SubSystem: '<S70>/Data receive' */

  /* Update for UnitDelay: '<S275>/Output' */
  may23_DW.Output_DSTATE_p = may23_B.FixPtSwitch_f;

  /* Update for Enabled SubSystem: '<S68>/read_pmac' */
  may23_read_pmac_Update();

  /* End of Update for SubSystem: '<S68>/read_pmac' */

  /* Update for UnitDelay: '<S80>/Output' */
  may23_DW.Output_DSTATE_po = may23_B.FixPtSwitch_e;
}

/* Termination for atomic system: '<S1>/Poll KINARM' */
void may23_PollKINARM_Term(void)
{
  /* Terminate for Enabled SubSystem: '<S66>/Arm 1' */
  /* Terminate for S-Function (BKINethercatpdorxElmoDrive): '<S102>/BKIN PDO Receive ElmoDrive' */
  /* Level2 S-Function Block: '<S102>/BKIN PDO Receive ElmoDrive' (BKINethercatpdorxElmoDrive) */
  {
    SimStruct *rts = may23_M->childSfunctions[7];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (BKINethercatpdotx): '<S87>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S87>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[8];
    sfcnTerminate(rts);
  }

  /* Terminate for Atomic SubSystem: '<S87>/EMCY Message pump' */
  may23_EMCYMessagepump_Term();

  /* End of Terminate for SubSystem: '<S87>/EMCY Message pump' */

  /* Terminate for S-Function (BKINethercatpdorxElmoDrive): '<S122>/BKIN PDO Receive ElmoDrive' */
  /* Level2 S-Function Block: '<S122>/BKIN PDO Receive ElmoDrive' (BKINethercatpdorxElmoDrive) */
  {
    SimStruct *rts = may23_M->childSfunctions[9];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (BKINethercatpdotx): '<S88>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S88>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[10];
    sfcnTerminate(rts);
  }

  /* Terminate for Atomic SubSystem: '<S88>/EMCY Message pump' */
  may23_EMCYMessagepump_k_Term();

  /* End of Terminate for SubSystem: '<S88>/EMCY Message pump' */

  /* Terminate for Atomic SubSystem: '<S97>/Read Drive 1 SDO' */
  may23_ReadDrive1SDO_g_Term();

  /* End of Terminate for SubSystem: '<S97>/Read Drive 1 SDO' */

  /* Terminate for Enabled SubSystem: '<S77>/M1 AbsEnc Calibration' */
  /* Terminate for S-Function (BKINethercatasyncsdodownload): '<S91>/BKIN EtherCAT Async SDO Download' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_f[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDODownload(658981113, deviceIndex);
        printf("SDO Download. Unregister device %d, slave addr: %d\n",
               deviceIndex, 1001);
      }
    }
  }

  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S91>/BKIN EtherCAT Async SDO Upload' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_j0[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658981114, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1001);
      }
    }
  }

  /* End of Terminate for SubSystem: '<S77>/M1 AbsEnc Calibration' */

  /* Terminate for Enabled SubSystem: '<S77>/M2 AbsEnc Calibration' */
  /* Terminate for S-Function (BKINethercatasyncsdodownload): '<S92>/BKIN EtherCAT Async SDO Download' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_p[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDODownload(658984267, deviceIndex);
        printf("SDO Download. Unregister device %d, slave addr: %d\n",
               deviceIndex, 1002);
      }
    }
  }

  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S92>/BKIN EtherCAT Async SDO Upload' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_lj[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658984268, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1002);
      }
    }
  }

  /* End of Terminate for SubSystem: '<S77>/M2 AbsEnc Calibration' */

  /* Terminate for S-Function (BKINethercatpdotx): '<S89>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S89>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[11];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (BKINethercatpdotx): '<S89>/BKIN EtherCAT PDO Transmit 1' */
  /* Level2 S-Function Block: '<S89>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[12];
    sfcnTerminate(rts);
  }

  /* Terminate for Atomic SubSystem: '<S77>/SDO reading' */
  may23_SDOreading_Term();

  /* End of Terminate for SubSystem: '<S77>/SDO reading' */

  /* Terminate for Atomic SubSystem: '<S77>/SDO writing' */
  may23_SDOwriting_Term();

  /* End of Terminate for SubSystem: '<S77>/SDO writing' */
  /* End of Terminate for SubSystem: '<S66>/Arm 1' */

  /* Terminate for Enabled SubSystem: '<S66>/Arm 2' */
  /* Terminate for S-Function (BKINethercatpdorxElmoDrive): '<S177>/BKIN PDO Receive ElmoDrive' */
  /* Level2 S-Function Block: '<S177>/BKIN PDO Receive ElmoDrive' (BKINethercatpdorxElmoDrive) */
  {
    SimStruct *rts = may23_M->childSfunctions[13];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (BKINethercatpdotx): '<S162>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S162>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[14];
    sfcnTerminate(rts);
  }

  /* Terminate for Atomic SubSystem: '<S162>/EMCY Message pump' */
  may23_EMCYMessagepump_m_Term();

  /* End of Terminate for SubSystem: '<S162>/EMCY Message pump' */

  /* Terminate for S-Function (BKINethercatpdorxElmoDrive): '<S197>/BKIN PDO Receive ElmoDrive' */
  /* Level2 S-Function Block: '<S197>/BKIN PDO Receive ElmoDrive' (BKINethercatpdorxElmoDrive) */
  {
    SimStruct *rts = may23_M->childSfunctions[15];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (BKINethercatpdotx): '<S163>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S163>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[16];
    sfcnTerminate(rts);
  }

  /* Terminate for Atomic SubSystem: '<S163>/EMCY Message pump' */
  may23_EMCYMessagepump_n_Term();

  /* End of Terminate for SubSystem: '<S163>/EMCY Message pump' */

  /* Terminate for Atomic SubSystem: '<S172>/Read Drive 3 SDO' */
  may23_ReadDrive3SDO_j_Term();

  /* End of Terminate for SubSystem: '<S172>/Read Drive 3 SDO' */

  /* Terminate for Enabled SubSystem: '<S78>/M1 AbsEnc Calibration' */
  /* Terminate for S-Function (BKINethercatasyncsdodownload): '<S165>/BKIN EtherCAT Async SDO Download' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_a[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDODownload(658984277, deviceIndex);
        printf("SDO Download. Unregister device %d, slave addr: %d\n",
               deviceIndex, 1003);
      }
    }
  }

  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S165>/BKIN EtherCAT Async SDO Upload' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK_g[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658984278, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1003);
      }
    }
  }

  /* End of Terminate for SubSystem: '<S78>/M1 AbsEnc Calibration' */

  /* Terminate for Enabled SubSystem: '<S78>/M2 AbsEnc Calibration' */
  /* Terminate for S-Function (BKINethercatasyncsdodownload): '<S166>/BKIN EtherCAT Async SDO Download' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDODownload_IWORK_g[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDODownload(658984287, deviceIndex);
        printf("SDO Download. Unregister device %d, slave addr: %d\n",
               deviceIndex, 1004);
      }
    }
  }

  /* Terminate for S-Function (BKINethercatasyncsdoupload): '<S166>/BKIN EtherCAT Async SDO Upload' */
  {
    int_T deviceIndex;
    if (!xpcIsModelInit()) {
      deviceIndex = may23_DW.BKINEtherCATAsyncSDOUpload_IWORK[0];
      if (deviceIndex != NO_ETHERCAT) {
        unregisterAsyncSDOUpload(658984288, deviceIndex);
        printf("SDO Upload. Unregister device %d, slave addr: %d\n", deviceIndex,
               1004);
      }
    }
  }

  /* End of Terminate for SubSystem: '<S78>/M2 AbsEnc Calibration' */

  /* Terminate for Atomic SubSystem: '<S78>/SDO reading' */
  may23_SDOreading_p_Term();

  /* End of Terminate for SubSystem: '<S78>/SDO reading' */

  /* Terminate for Atomic SubSystem: '<S78>/SDO writing' */
  may23_SDOwriting_k_Term();

  /* End of Terminate for SubSystem: '<S78>/SDO writing' */

  /* Terminate for S-Function (BKINethercatpdotx): '<S170>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S170>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[17];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (BKINethercatpdotx): '<S170>/BKIN EtherCAT PDO Transmit 1' */
  /* Level2 S-Function Block: '<S170>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[18];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S66>/Arm 2' */

  /* Terminate for S-Function (BKINethercatpdotx): '<S81>/BKIN EtherCAT PDO Transmit ' */
  /* Level2 S-Function Block: '<S81>/BKIN EtherCAT PDO Transmit ' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[29];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (BKINethercatpdotx): '<S81>/BKIN EtherCAT PDO Transmit 1' */
  /* Level2 S-Function Block: '<S81>/BKIN EtherCAT PDO Transmit 1' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[30];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (BKINethercatpdotx): '<S81>/BKIN EtherCAT PDO Transmit 2' */
  /* Level2 S-Function Block: '<S81>/BKIN EtherCAT PDO Transmit 2' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[31];
    sfcnTerminate(rts);
  }

  /* Terminate for S-Function (BKINethercatpdotx): '<S81>/BKIN EtherCAT PDO Transmit 3' */
  /* Level2 S-Function Block: '<S81>/BKIN EtherCAT PDO Transmit 3' (BKINethercatpdotx) */
  {
    SimStruct *rts = may23_M->childSfunctions[32];
    sfcnTerminate(rts);
  }

  /* Terminate for Atomic SubSystem: '<S30>/Force Sensor Control' */
  may23_ForceSensorControl_Term();

  /* End of Terminate for SubSystem: '<S30>/Force Sensor Control' */

  /* Terminate for Enabled SubSystem: '<S70>/Data receive' */
  /* Terminate for S-Function (slrtUDPReceive): '<S283>/Receive' */
  /* Level2 S-Function Block: '<S283>/Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[28];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S70>/Data receive' */

  /* Terminate for Enabled SubSystem: '<S68>/read_pmac' */
  may23_read_pmac_Term();

  /* End of Terminate for SubSystem: '<S68>/read_pmac' */

  /* Terminate for Enabled SubSystem: '<S69>/Data receive' */
  /* Terminate for S-Function (kinarmfromfile): '<S276>/S-Function' */
  /* Level2 S-Function Block: '<S276>/S-Function' (kinarmfromfile) */
  {
    SimStruct *rts = may23_M->childSfunctions[27];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S69>/Data receive' */
}
