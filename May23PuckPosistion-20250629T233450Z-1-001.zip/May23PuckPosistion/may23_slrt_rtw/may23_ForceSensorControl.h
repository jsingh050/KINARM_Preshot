/*
 * Code generation for system system '<S30>/Force Sensor Control'
 * For more details, see corresponding source file may23_ForceSensorControl.c
 *
 */

#ifndef RTW_HEADER_may23_ForceSensorControl_h_
#define RTW_HEADER_may23_ForceSensorControl_h_
#include <stddef.h>
#include <string.h>
#ifndef may23_COMMON_INCLUDES_
# define may23_COMMON_INCLUDES_
#include <stdio.h>
#include <string.h>
#include <xpcimports.h>
#include <xpcdatatypes.h>
#include "rtwtypes.h"
#include "zero_crossing_types.h"
#include "simstruc.h"
#include "fixedpoint.h"
#include "rt_logging.h"
#include "xpcimports.h"
#include "stddef.h"
#include "stdlib.h"
#include "xpcethercatutils.h"
#include "xpctarget.h"
#include "BKINethercat.h"
#endif                                 /* may23_COMMON_INCLUDES_ */

#include "may23_types.h"

/* Shared type includes */
#include "multiword_types.h"

/* Block signals for system '<S252>/Create timestamp' */
typedef struct {
  real_T timestamp_out;                /* '<S252>/Create timestamp' */
} B_Createtimestamp_may23_T;

/* Block states (default storage) for system '<S252>/Create timestamp' */
typedef struct {
  uint32_T start_time;                 /* '<S252>/Create timestamp' */
  uint32_T last_time;                  /* '<S252>/Create timestamp' */
} DW_Createtimestamp_may23_T;

extern void may23_Createtimestamp_Init(DW_Createtimestamp_may23_T *localDW);
extern void may23_Createtimestamp(const uint32_T rtu_times_in[3],
  B_Createtimestamp_may23_T *localB, DW_Createtimestamp_may23_T *localDW);
extern void may23_ForceSensorControl_Init(void);
extern void may23_ForceSensorControl_Start(void);
extern void may23_ForceSensorControl_Update(void);
extern void may23_ForceSensorControl(void);
extern void may23_ForceSensorControl_Term(void);

#endif                              /* RTW_HEADER_may23_ForceSensorControl_h_ */
