/*
 * Code generation for system system '<S9>/PVC_core'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_PVC_core.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/* Forward declaration for local functions */
static void may23_isPermTarget(const real_T VCODE[70], boolean_T *perm,
  boolean_T *isValidID);
static boolean_T may23_containsLargerABS1(const real_T VCODE[70], real_T count);
static int32_T may23_packValues(real_T v1, real_T v2, boolean_T bUse10m);
static void may23_pack_args(const real_T VCODE[70], uint32_T shape, real_T
  packed_args[2], real_T *packed_length);
static uint32_T may23_toBitField(const boolean_T field[13]);
static void may23_pack_code(const real_T VCODE[70], int32_T packed_code[34],
  real_T *b_index, boolean_T *isPerm, real_T *errID);

/* Function for MATLAB Function: '<S383>/Pack VCodeFrame2' */
static void may23_isPermTarget(const real_T VCODE[70], boolean_T *perm,
  boolean_T *isValidID)
{
  /* '<S385>:1:432' */
  /* '<S385>:1:433' */
  /* '<S385>:1:435' */
  *perm = ((VCODE[0] > 100.0) && (VCODE[0] < 130.0));

  /* '<S385>:1:436' */
  *isValidID = (((VCODE[7] > 0.0) && (VCODE[7] < 500.0)) || (VCODE[7] == 15360.0));
}

/* Function for MATLAB Function: '<S383>/Pack VCodeFrame2' */
static boolean_T may23_containsLargerABS1(const real_T VCODE[70], real_T count)
{
  boolean_T x_data[50];
  int32_T k;
  int32_T idx;
  int32_T b_ii;
  int32_T x_size_idx_0;
  boolean_T exitg1;
  if (17.0 > count) {
    k = 0;
    idx = 0;
  } else {
    k = 16;
    idx = (int32_T)count;
  }

  /* '<S385>:1:416' */
  x_size_idx_0 = idx - k;
  idx -= k;
  for (b_ii = 0; b_ii < idx; b_ii++) {
    x_data[b_ii] = ((VCODE[k + b_ii] > 1.0) || (VCODE[k + b_ii] < -1.0));
  }

  k = (1 <= x_size_idx_0);
  idx = 0;
  b_ii = 0;
  exitg1 = false;
  while ((!exitg1) && (b_ii <= x_size_idx_0 - 1)) {
    if (x_data[b_ii]) {
      idx++;
      if (idx >= k) {
        exitg1 = true;
      } else {
        b_ii++;
      }
    } else {
      b_ii++;
    }
  }

  if (k == 1) {
    if (idx == 0) {
      k = 0;
    }
  } else {
    k = (1 <= idx);
  }

  /* '<S385>:1:417' */
  return k != 0;
}

real_T rt_remd_snf(real_T u0, real_T u1)
{
  real_T y;
  real_T q;
  if (rtIsNaN(u0) || rtIsNaN(u1) || rtIsInf(u0)) {
    y = (rtNaN);
  } else if (rtIsInf(u1)) {
    y = u0;
  } else {
    if (u1 < 0.0) {
      y = ceil(u1);
    } else {
      y = floor(u1);
    }

    if ((u1 != 0.0) && (u1 != y)) {
      q = fabs(u0 / u1);
      if (!(fabs(q - floor(q + 0.5)) > DBL_EPSILON * q)) {
        y = 0.0 * u0;
      } else {
        y = fmod(u0, u1);
      }
    } else {
      y = fmod(u0, u1);
    }
  }

  return y;
}

/* Function for MATLAB Function: '<S383>/Pack VCodeFrame2' */
static int32_T may23_packValues(real_T v1, real_T v2, boolean_T bUse10m)
{
  int32_T packed;
  real_T tickSize;
  int32_T v1Ticks;
  int32_T v2Ticks;

  /* '<S385>:1:362' */
  tickSize = 3.0517578125E-5;
  if (bUse10m) {
    /* '<S385>:1:363' */
    /* '<S385>:1:364' */
    tickSize = 0.00030517578125;
  }

  /* '<S385>:1:366' */
  v1Ticks = (int32_T)rt_roundd_snf(v1 / tickSize);

  /* '<S385>:1:367' */
  v2Ticks = (int32_T)rt_roundd_snf(v2 / tickSize);
  if (v1Ticks > 32767) {
    /* '<S385>:1:370' */
    /* '<S385>:1:371' */
    v1Ticks = 32767;
  } else {
    if (v1Ticks < -32767) {
      /* '<S385>:1:372' */
      /* '<S385>:1:373' */
      v1Ticks = -32767;
    }
  }

  if (v2Ticks > 32767) {
    /* '<S385>:1:376' */
    /* '<S385>:1:377' */
    v2Ticks = 32767;
  } else {
    if (v2Ticks < -32767) {
      /* '<S385>:1:378' */
      /* '<S385>:1:379' */
      v2Ticks = -32767;
    }
  }

  /* '<S385>:1:386' */
  packed = (v1Ticks << 16) + v2Ticks;
  return packed;
}

/* Function for MATLAB Function: '<S383>/Pack VCodeFrame2' */
static void may23_pack_args(const real_T VCODE[70], uint32_T shape, real_T
  packed_args[2], real_T *packed_length)
{
  int32_T b_packed;
  real_T b_rads;

  /* '<S385>:1:502' */
  packed_args[0] = 0.0;
  packed_args[1] = 0.0;

  /* '<S385>:1:503' */
  *packed_length = 1.0;
  if (shape == 1U) {
    /* '<S385>:1:505' */
    /* '<S385>:1:506' */
    packed_args[0] = may23_packValues(VCODE[9], 0.0, false);
  } else if ((shape == 3U) || (shape == 2U)) {
    /* '<S385>:1:507' */
    /* '<S385>:1:508' */
    packed_args[0] = may23_packValues(VCODE[9], VCODE[10], false);

    /* '<S385>:1:509' */
    b_rads = VCODE[11];
    if ((VCODE[11] > 6.2831853071795862) || (VCODE[11] < -6.2831853071795862)) {
      /* '<S385>:1:394' */
      /* '<S385>:1:395' */
      b_rads = rt_remd_snf(VCODE[11], 6.2831853071795862);
    }

    if (b_rads == 0.0) {
      /* '<S385>:1:398' */
      /* '<S385>:1:399' */
      b_packed = 0;
    } else {
      /* '<S385>:1:402' */
      b_packed = (int32_T)rt_roundd_snf(5215.0300202921344 * b_rads);
    }

    packed_args[1] = b_packed;

    /* '<S385>:1:510' */
    *packed_length = 2.0;
  } else if (shape == 4U) {
    /* '<S385>:1:511' */
    /* '<S385>:1:512' */
    packed_args[0] = may23_packValues(VCODE[9], VCODE[10], false);
  } else if (shape == 5U) {
    /* '<S385>:1:513' */
    /* '<S385>:1:514' */
    packed_args[0] = may23_packValues(VCODE[9], VCODE[10], false);

    /* '<S385>:1:515' */
    b_rads = VCODE[12];
    if ((VCODE[12] > 6.2831853071795862) || (VCODE[12] < -6.2831853071795862)) {
      /* '<S385>:1:394' */
      /* '<S385>:1:395' */
      b_rads = rt_remd_snf(VCODE[12], 6.2831853071795862);
    }

    if (b_rads == 0.0) {
      /* '<S385>:1:398' */
      /* '<S385>:1:399' */
      b_packed = 0;
    } else {
      /* '<S385>:1:402' */
      b_packed = (int32_T)rt_roundd_snf(5215.0300202921344 * b_rads);
    }

    packed_args[1] = may23_packValues(VCODE[11], 0.0, false) + b_packed;

    /* '<S385>:1:516' */
    *packed_length = 2.0;
  } else if (shape == 6U) {
    /* '<S385>:1:517' */
    /* '<S385>:1:519' */
    *packed_length = 0.0;
  } else {
    if (shape == 7U) {
      /* '<S385>:1:520' */
      /* '<S385>:1:521' */
      b_rads = VCODE[9];
      if ((VCODE[9] > 6.2831853071795862) || (VCODE[9] < -6.2831853071795862)) {
        /* '<S385>:1:394' */
        /* '<S385>:1:395' */
        b_rads = rt_remd_snf(VCODE[9], 6.2831853071795862);
      }

      if (b_rads == 0.0) {
        /* '<S385>:1:398' */
        /* '<S385>:1:399' */
        b_packed = 0;
      } else {
        /* '<S385>:1:402' */
        b_packed = (int32_T)rt_roundd_snf(5215.0300202921344 * b_rads);
      }

      packed_args[0] = b_packed;
    }
  }
}

/* Function for MATLAB Function: '<S383>/Pack VCodeFrame2' */
static uint32_T may23_toBitField(const boolean_T field[13])
{
  uint32_T bits;
  int32_T i;
  int8_T b_field;

  /* '<S385>:1:317' */
  bits = 0U;

  /* '<S385>:1:318' */
  /* '<S385>:1:320' */
  for (i = 0; i < 13; i++) {
    b_field = (int8_T)field[i];

    /* '<S385>:1:320' */
    /* '<S385>:1:321' */
    bits += (uint32_T)b_field << (uint32_T)i;
  }

  return bits;
}

/* Function for MATLAB Function: '<S383>/Pack VCodeFrame2' */
static void may23_pack_code(const real_T VCODE[70], int32_T packed_code[34],
  real_T *b_index, boolean_T *isPerm, real_T *errID)
{
  uint32_T code_type;
  uint32_T displayWhere;
  int32_T shape;
  int32_T lowerCode;
  boolean_T isMultiCode;
  boolean_T isLabel;
  boolean_T hasFillColor;
  boolean_T hasStroke;
  real_T multiCodeRepeats;
  boolean_T use10mPositionResolution;
  boolean_T isFillAnImage;
  boolean_T isStrokeAnImage;
  real_T alpha;
  real_T extraLen;
  int32_T strAsInts_data[169];
  real_T intCount;
  int32_T b_strAsInts[13];
  real_T args[2];
  boolean_T x[34];
  int32_T c1;
  int32_T c3;
  int32_T c4;
  int32_T idx;
  int32_T i;
  boolean_T displayWhere_0[13];
  uint32_T y;
  static const int8_T all_types[34] = { 1, 2, 3, 4, 5, 6, 7, 11, 12, 13, 14, 15,
    21, 22, 23, 24, 25, 101, 102, 103, 104, 105, 106, 107, 111, 112, 113, 114,
    115, 121, 122, 123, 124, 125 };

  boolean_T guard1 = false;
  boolean_T exitg1;

  /* '<S385>:1:167' */
  /* '<S385>:1:164' */
  *errID = 0.0;

  /* '<S385>:1:167' */
  /* '<S385>:1:168' */
  code_type = (uint32_T)rt_roundd_snf(VCODE[0]);

  /* '<S385>:1:170' */
  displayWhere = (uint32_T)rt_roundd_snf(VCODE[1]);

  /* '<S385>:1:171' */
  y = code_type % 10U;
  shape = (int32_T)y;

  /* '<S385>:1:172' */
  y = code_type % 100U;
  lowerCode = (int32_T)y;

  /* '<S385>:1:174' */
  /* '<S385>:1:175' */
  *b_index = 0.0;

  /* '<S385>:1:176' */
  *isPerm = false;
  for (i = 0; i < 34; i++) {
    packed_code[i] = 0;
    x[i] = ((uint32_T)all_types[i] == code_type);
  }

  idx = 0;
  c1 = 0;
  exitg1 = false;
  while ((!exitg1) && (c1 < 34)) {
    if (x[c1]) {
      idx = 1;
      exitg1 = true;
    } else {
      c1++;
    }
  }

  if (idx == 0) {
    /* '<S385>:1:180' */
    *errID = 2.0;
  } else {
    if ((VCODE[1] < 0.0) || (displayWhere > 3U)) {
      /* '<S385>:1:185' */
      /* '<S385>:1:186' */
      displayWhere = 1U;
    }

    /* '<S385>:1:189' */
    /* '<S385>:1:190' */
    /* '<S385>:1:191' */
    isMultiCode = (((lowerCode > 20) && (lowerCode < 30)) || (shape == 6) ||
                   (shape == 7));

    /* '<S385>:1:192' */
    isLabel = ((lowerCode > 10) && (lowerCode < 20) && (!isMultiCode));

    /* '<S385>:1:193' */
    may23_isPermTarget(VCODE, isPerm, &hasFillColor);

    /* '<S385>:1:193' */
    /* '<S385>:1:313' */
    /* '<S385>:1:194' */
    hasFillColor = ((VCODE[4] != -2.147483648E+9) && (VCODE[4] != 1.6777216E+7) &&
                    (shape != 6) && (shape != 4));

    /* '<S385>:1:313' */
    /* '<S385>:1:195' */
    hasStroke = ((VCODE[5] != -2.147483648E+9) && (VCODE[5] != 1.6777216E+7) &&
                 (VCODE[6] > 0.0));

    /* '<S385>:1:198' */
    /* '<S385>:1:199' */
    /* '<S385>:1:201' */
    multiCodeRepeats = 0.0;
    guard1 = false;
    if (isMultiCode) {
      /* '<S385>:1:202' */
      /* '<S385>:1:203' */
      multiCodeRepeats = rt_roundd_snf(VCODE[15]);
      if (multiCodeRepeats == 0.0) {
        /* '<S385>:1:206' */
      } else if ((multiCodeRepeats < 1.0) || (multiCodeRepeats > 25.0)) {
        /* '<S385>:1:209' */
        /* '<S385>:1:210' */
        *errID = 3.0;
      } else {
        guard1 = true;
      }
    } else {
      guard1 = true;
    }

    if (guard1) {
      /* '<S385>:1:215' */
      use10mPositionResolution = ((VCODE[2] > 1.0) || (VCODE[3] > 1.0) ||
        (VCODE[2] < -1.0) || (VCODE[3] < -1.0));
      if (isMultiCode && (!use10mPositionResolution) && (multiCodeRepeats > 0.0))
      {
        /* '<S385>:1:217' */
        /* '<S385>:1:218' */
        use10mPositionResolution = may23_containsLargerABS1(VCODE,
          multiCodeRepeats * 2.0);
      }

      /* '<S385>:1:223' */
      isFillAnImage = (hasFillColor && (VCODE[4] < 0.0));

      /* '<S385>:1:224' */
      isStrokeAnImage = (hasStroke && (VCODE[5] < 0.0));

      /* '<S385>:1:226' */
      /* '<S385>:1:229' */
      /* '<S385>:1:232' */
      alpha = VCODE[8];
      if (VCODE[8] > 100.0) {
        /* '<S385>:1:233' */
        /* '<S385>:1:234' */
        alpha = 100.0;
      } else {
        if (VCODE[8] < 0.0) {
          /* '<S385>:1:235' */
          /* '<S385>:1:236' */
          alpha = 0.0;
        }
      }

      /* '<S385>:1:239' */
      *b_index = 2.0;

      /* '<S385>:1:240' */
      extraLen = 0.0;

      /* '<S385>:1:241' */
      for (c1 = 0; c1 < 13; c1++) {
        strAsInts_data[c1] = 0;
      }

      /* '<S385>:1:242' */
      intCount = 0.0;
      if (isMultiCode || isLabel || (*isPerm)) {
        /* '<S385>:1:244' */
        /* '<S385>:1:193' */
        if (isLabel) {
          /* '<S385>:1:245' */
          /* '<S385>:1:246' */
          /* '<S385>:1:326' */
          /* '<S385>:1:327' */
          lowerCode = 0;

          /* '<S385>:1:328' */
          idx = 15;

          /* '<S385>:1:329' */
          for (i = 0; i < 13; i++) {
            b_strAsInts[i] = 0;
          }

          exitg1 = false;
          while ((!exitg1) && (lowerCode < 13)) {
            /* '<S385>:1:331' */
            /* '<S385>:1:332' */
            c1 = (int32_T)rt_roundd_snf(VCODE[idx - 1]);

            /* '<S385>:1:333' */
            i = (int32_T)rt_roundd_snf(VCODE[idx]);
            if (lowerCode < 12) {
              /* '<S385>:1:335' */
              /* '<S385>:1:336' */
              c3 = (int32_T)rt_roundd_snf(VCODE[idx + 1]);

              /* '<S385>:1:337' */
              c4 = (int32_T)rt_roundd_snf(VCODE[idx + 2]);
            } else {
              /* '<S385>:1:339' */
              c3 = 0;

              /* '<S385>:1:340' */
              c4 = 0;
            }

            /* '<S385>:1:343' */
            b_strAsInts[lowerCode] = (((c1 << 24) + (i << 16)) + (c3 << 8)) + c4;

            /* '<S385>:1:344' */
            extraLen = ((((real_T)(c1 != 0) + extraLen) + (real_T)(i != 0)) +
                        (real_T)(c3 != 0)) + (real_T)(c4 != 0);
            if ((c1 == 0) || (i == 0) || (c3 == 0) || (c4 == 0)) {
              /* '<S385>:1:346' */
              exitg1 = true;
            } else {
              /* '<S385>:1:350' */
              lowerCode++;

              /* '<S385>:1:351' */
              idx += 4;
            }
          }

          /* '<S385>:1:354' */
          /* '<S385>:1:246' */
          for (c1 = 0; c1 < 13; c1++) {
            strAsInts_data[c1] = b_strAsInts[c1];
          }

          /* '<S385>:1:246' */
          intCount = ceil(extraLen / 4.0);

          /* '<S385>:1:247' */
        } else {
          if (isMultiCode) {
            /* '<S385>:1:248' */
            if (shape == 7) {
              /* '<S385>:1:249' */
              /* '<S385>:1:250' */
              extraLen = multiCodeRepeats + 1.0;
            } else {
              /* '<S385>:1:252' */
              extraLen = multiCodeRepeats;
            }
          }
        }

        /* '<S385>:1:256' */
        /* '<S385>:1:257' */
        packed_code[1] = (int32_T)(uint32_T)((real_T)((uint32_T)rt_roundd_snf
          (VCODE[7]) << 16U) + extraLen);

        /* '<S385>:1:258' */
        *b_index = 3.0;
      }

      if (hasFillColor) {
        /* '<S385>:1:261' */
        /* '<S385>:1:262' */
        extraLen = VCODE[4];
        if (isFillAnImage) {
          /* '<S385>:1:263' */
          /* '<S385>:1:264' */
          extraLen = -VCODE[4];
        }

        /* '<S385>:1:266' */
        /* '<S385>:1:407' */
        /* '<S385>:1:408' */
        /* '<S385>:1:409' */
        packed_code[(int32_T)*b_index - 1] = ((int32_T)rt_roundd_snf(alpha /
          100.0 * 255.0) << 24) + ((int32_T)rt_roundd_snf(extraLen) & 16777215);

        /* '<S385>:1:267' */
        (*b_index)++;
      }

      if (hasStroke) {
        /* '<S385>:1:270' */
        /* '<S385>:1:271' */
        extraLen = VCODE[5];
        if (isStrokeAnImage) {
          /* '<S385>:1:272' */
          /* '<S385>:1:273' */
          extraLen = -VCODE[5];
        }

        /* '<S385>:1:275' */
        /* '<S385>:1:407' */
        /* '<S385>:1:408' */
        /* '<S385>:1:409' */
        packed_code[(int32_T)*b_index - 1] = ((int32_T)rt_roundd_snf(alpha /
          100.0 * 255.0) << 24) + ((int32_T)rt_roundd_snf(extraLen) & 16777215);

        /* '<S385>:1:276' */
        /* '<S385>:1:366' */
        lowerCode = (int32_T)rt_roundd_snf(VCODE[6] / 3.0517578125E-5);
        if (lowerCode > 32767) {
          /* '<S385>:1:370' */
          /* '<S385>:1:371' */
          lowerCode = 32767;
        } else {
          if (lowerCode < -32767) {
            /* '<S385>:1:372' */
            /* '<S385>:1:373' */
            lowerCode = -32767;
          }
        }

        /* '<S385>:1:386' */
        packed_code[(int32_T)*b_index] = lowerCode << 16;

        /* '<S385>:1:277' */
        *b_index += 2.0;
      }

      /* '<S385>:1:280' */
      may23_pack_args(VCODE, (uint32_T)shape, args, &extraLen);

      /* '<S385>:1:281' */
      packed_code[(int32_T)*b_index - 1] = (int32_T)rt_roundd_snf(args[0]);

      /* '<S385>:1:282' */
      packed_code[(int32_T)*b_index] = (int32_T)rt_roundd_snf(args[1]);

      /* '<S385>:1:283' */
      *b_index += extraLen;
      if ((!isMultiCode) || (shape == 7)) {
        /* '<S385>:1:285' */
        /* '<S385>:1:286' */
        packed_code[(int32_T)*b_index - 1] = may23_packValues(VCODE[2], VCODE[3],
          use10mPositionResolution);

        /* '<S385>:1:287' */
        (*b_index)++;
      }

      if (isMultiCode) {
        /* '<S385>:1:290' */
        /* '<S385>:1:291' */
        extraLen = 17.0;

        /* '<S385>:1:292' */
        for (lowerCode = 0; lowerCode < (int32_T)multiCodeRepeats; lowerCode++)
        {
          /* '<S385>:1:292' */
          /* '<S385>:1:293' */
          packed_code[(int32_T)*b_index - 1] = may23_packValues(VCODE[(int32_T)
            extraLen - 1], VCODE[(int32_T)(extraLen + 1.0) - 1],
            use10mPositionResolution);

          /* '<S385>:1:294' */
          (*b_index)++;

          /* '<S385>:1:295' */
          extraLen += 2.0;
        }
      }

      if (isLabel) {
        /* '<S385>:1:299' */
        if (1.0 > intCount) {
          lowerCode = -1;
        } else {
          lowerCode = (int32_T)intCount - 1;
        }

        multiCodeRepeats = (*b_index + intCount) + 1.0;
        if (*b_index > multiCodeRepeats) {
          idx = 1;
        } else {
          idx = (int32_T)*b_index;
        }

        /* '<S385>:1:407' */
        /* '<S385>:1:408' */
        /* '<S385>:1:409' */
        /* '<S385>:1:366' */
        i = (int32_T)rt_roundd_snf(VCODE[65] / 3.0517578125E-5);
        if (i > 32767) {
          /* '<S385>:1:370' */
          /* '<S385>:1:371' */
          i = 32767;
        } else {
          if (i < -32767) {
            /* '<S385>:1:372' */
            /* '<S385>:1:373' */
            i = -32767;
          }
        }

        /* '<S385>:1:386' */
        /* '<S385>:1:300' */
        for (c1 = 0; c1 <= lowerCode; c1++) {
          packed_code[(idx + c1) - 1] = strAsInts_data[c1];
        }

        packed_code[idx + lowerCode] = ((int32_T)rt_roundd_snf(alpha / 100.0 *
          255.0) << 24) + ((int32_T)rt_roundd_snf(VCODE[64]) & 16777215);
        packed_code[(idx + lowerCode) + 1] = i << 16;

        /* '<S385>:1:301' */
        *b_index = (*b_index + intCount) + 2.0;
      }

      /* '<S385>:1:304' */
      (*b_index)--;

      /* '<S385>:1:305' */
      displayWhere_0[0] = (((int32_T)displayWhere == 1) || ((int32_T)
        displayWhere == 3));
      displayWhere_0[1] = (((int32_T)displayWhere == 1) || ((int32_T)
        displayWhere == 2));
      displayWhere_0[2] = isMultiCode;
      displayWhere_0[3] = isLabel;
      displayWhere_0[4] = *isPerm;
      displayWhere_0[5] = hasFillColor;
      displayWhere_0[6] = hasStroke;
      displayWhere_0[7] = ((shape == 3) || (shape == 2) || (shape == 5) ||
                           (shape == 7));
      displayWhere_0[8] = (shape == 5);
      displayWhere_0[9] = use10mPositionResolution;
      displayWhere_0[10] = false;
      displayWhere_0[11] = isFillAnImage;
      displayWhere_0[12] = isStrokeAnImage;
      packed_code[0] = (int32_T)((((uint32_T)rt_roundd_snf(*b_index) << 24U) +
        ((uint32_T)shape << 16U)) + may23_toBitField(displayWhere_0));

      /* '<S385>:1:309' */
    }
  }
}

/* System initialize for atomic system: '<S9>/PVC_core' */
void may23_PVC_core_Init(void)
{
  /* InitializeConditions for RateTransition: '<S383>/Rate Transition1' */
  may23_DW.RateTransition1_Buffer0 = may23_P.RateTransition1_InitialCondition;

  /* SystemInitialize for MATLAB Function: '<S383>/Pack VCodeFrame2' */
  may23_DW.frame_count = 0U;
}

/* Start for atomic system: '<S9>/PVC_core' */
void may23_PVC_core_Start(void)
{
  /* Start for RateTransition: '<S383>/Rate Transition1' */
  may23_B.RateTransition1_o = may23_P.RateTransition1_InitialCondition;
}

/* Output and update for atomic system: '<S9>/PVC_core' */
void may23_PVC_coreTID0(void)
{
  /* RateTransition: '<S383>/Rate Transition1' */
  if (may23_M->Timing.RateInteraction.TID1_3) {
    may23_B.RateTransition1_o = may23_DW.RateTransition1_Buffer0;
  }

  /* End of RateTransition: '<S383>/Rate Transition1' */
}

/* Output and update for atomic system: '<S9>/PVC_core' */
void may23_PVC_coreTID3(void)
{
  int32_T vis_cmd_cropped;
  uint32_T frame_number;
  real_T vcode_err_id;
  real_T b_index;
  int32_T added_code_counter;
  boolean_T containsPerm;
  real_T m;
  int32_T errID;
  int32_T packed[34];
  real_T codelen;
  int32_T i;
  boolean_T b_isPerm;
  boolean_T isValidID;
  boolean_T b;
  boolean_T exitg1;

  /* MATLAB Function: '<S383>/Pack VCodeFrame2' */
  /* MATLAB Function 'Process_Video_CMD/PVC_core/Pack VCodeFrame2': '<S385>:1' */
  /* '<S385>:1:81' */
  /* '<S385>:1:24' */
  may23_DW.frame_count++;

  /* '<S385>:1:25' */
  frame_number = may23_DW.frame_count;

  /* '<S385>:1:26' */
  vcode_err_id = 0.0;

  /* '<S385>:1:50' */
  memset(&may23_B.vis_cmd[0], 0, 6810U * sizeof(int32_T));

  /* '<S385>:1:51' */
  vis_cmd_cropped = 0;

  /* '<S385>:1:60' */
  /* '<S385>:1:123' */
  if (may23_DW.frame_count > 2147483648U) {
    /* '<S385>:1:119' */
    /* '<S385>:1:120' */
    /* '<S385>:1:121' */
    added_code_counter = (int32_T)may23_DW.frame_count;
  } else {
    /* '<S385>:1:123' */
    added_code_counter = (int32_T)may23_DW.frame_count;
  }

  may23_B.vis_cmd[0] = 620756992;
  may23_B.vis_cmd[1] = added_code_counter;

  /* '<S385>:1:61' */
  b_index = 3.0;

  /* '<S385>:1:68' */
  added_code_counter = 0;

  /* '<S385>:1:69' */
  containsPerm = false;

  /* '<S385>:1:71' */
  i = 0;
  exitg1 = false;
  while ((!exitg1) && (i < 16)) {
    /* '<S385>:1:71' */
    /* '<S385>:1:73' */
    /* '<S385>:1:449' */
    /* '<S385>:1:440' */
    /* '<S385>:1:441' */
    /* '<S385>:1:443' */
    b_isPerm = ((may23_B.MatrixConcatenate_d[70 * i] > 100.0) &&
                (may23_B.MatrixConcatenate_d[70 * i] < 130.0));

    /* '<S385>:1:444' */
    isValidID = (((may23_B.MatrixConcatenate_d[70 * i + 7] > 0.0) &&
                  (may23_B.MatrixConcatenate_d[70 * i + 7] < 500.0)) ||
                 (may23_B.MatrixConcatenate_d[70 * i + 7] == 15360.0));

    /* '<S385>:1:454' */
    if (b_isPerm && (!isValidID)) {
      /* '<S385>:1:449' */
      /* '<S385>:1:455' */
      b = true;
    } else {
      b = false;
    }

    /* '<S385>:1:455' */
    b = ((!b) && (((may23_B.MatrixConcatenate_d[70 * i] > 0.0) &&
                   (may23_B.MatrixConcatenate_d[70 * i + 1] != 0.0)) || b_isPerm));

    /* '<S385>:1:457' */
    errID = 0;
    if ((!b) && b_isPerm && (!isValidID)) {
      /* '<S385>:1:458' */
      /* '<S385>:1:449' */
      /* '<S385>:1:459' */
      /* '<S385>:1:460' */
      errID = 1;
    }

    if (!b) {
      /* '<S385>:1:74' */
      if (errID != 0) {
        /* '<S385>:1:75' */
        /* '<S385>:1:76' */
        vcode_err_id = 1.0;
      }

      i++;
    } else {
      /* '<S385>:1:81' */
      may23_pack_code(&may23_B.MatrixConcatenate_d[70 * i], packed, &codelen,
                      &b_isPerm, &m);
      if (codelen == 0.0) {
        /* '<S385>:1:82' */
        if (m != 0.0) {
          /* '<S385>:1:83' */
          /* '<S385>:1:84' */
          vcode_err_id = m;
        }

        i++;
      } else {
        /* '<S385>:1:89' */
        containsPerm = (containsPerm || b_isPerm);

        /* '<S385>:1:91' */
        m = b_index;

        /* '<S385>:1:92' */
        for (errID = 0; errID < (int32_T)codelen; errID++) {
          /* '<S385>:1:92' */
          /* '<S385>:1:93' */
          may23_B.vis_cmd[(int32_T)m - 1] = packed[errID];

          /* '<S385>:1:94' */
          m++;
        }

        /* '<S385>:1:97' */
        b_index += codelen;

        /* '<S385>:1:98' */
        added_code_counter++;
        if ((b_index + 34.0) + 1.0 >= 6810.0) {
          /* '<S385>:1:101' */
          /* '<S385>:1:102' */
          vis_cmd_cropped = 1;

          /* '<S385>:1:103' */
          vcode_err_id = 4.0;
          exitg1 = true;
        } else {
          i++;
        }
      }
    }
  }

  /* '<S385>:1:109' */
  /* '<S385>:1:318' */
  /* '<S385>:1:321' */
  /* '<S385>:1:111' */
  may23_B.vis_cmd[0] = ((int32_T)((uint32_T)containsPerm << 16U) +
                        may23_B.vis_cmd[0]) + added_code_counter;

  /* '<S385>:1:113' */
  /* '<S385>:1:119' */
  /* '<S385>:1:120' */
  /* '<S385>:1:121' */
  may23_B.vis_cmd[(int32_T)b_index - 1] = -65536;

  /* '<S385>:1:114' */
  may23_B.vis_cmd_len = (b_index + 1.0) * 4.0;
  may23_B.vis_cmd_cropped = vis_cmd_cropped;
  may23_B.frame_number = frame_number;
  may23_B.vcode_err_id = vcode_err_id;

  /* End of MATLAB Function: '<S383>/Pack VCodeFrame2' */

  /* DataTypeConversion: '<S383>/Convert' */
  may23_B.Convert_j = may23_B.frame_number;

  /* RateTransition: '<S383>/Rate Transition1' */
  may23_DW.RateTransition1_Buffer0 = may23_B.Convert_j;
}
