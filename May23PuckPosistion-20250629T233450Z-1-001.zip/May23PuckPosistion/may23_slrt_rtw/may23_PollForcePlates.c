/*
 * Code generation for system system '<S1>/Poll Force Plates'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_PollForcePlates.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/* Start for atomic system: '<S1>/Poll Force Plates' */
void may23_PollForcePlates_Start(void)
{
  /* Start for Enabled SubSystem: '<S29>/plate1' */

  /* Start for S-Function (slrtUDPReceive): '<S60>/Receive' */
  /* Level2 S-Function Block: '<S60>/Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[3];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of Start for SubSystem: '<S29>/plate1' */

  /* Start for Enabled SubSystem: '<S29>/plate2' */

  /* Start for S-Function (slrtUDPReceive): '<S61>/Receive1' */
  /* Level2 S-Function Block: '<S61>/Receive1' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[4];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of Start for SubSystem: '<S29>/plate2' */

  /* Start for Enabled SubSystem: '<S29>/send poll 1' */

  /* Start for S-Function (slrtUDPSend): '<S62>/Send' */
  /* Level2 S-Function Block: '<S62>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[5];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of Start for SubSystem: '<S29>/send poll 1' */

  /* Start for Enabled SubSystem: '<S29>/send poll 2' */

  /* Start for S-Function (slrtUDPSend): '<S63>/Send1' */
  /* Level2 S-Function Block: '<S63>/Send1' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[6];
    sfcnStart(rts);
    if (ssGetErrorStatus(rts) != (NULL))
      return;
  }

  /* End of Start for SubSystem: '<S29>/send poll 2' */
}

/* Output and update for atomic system: '<S1>/Poll Force Plates' */
void may23_PollForcePlatesTID0(void)
{
  real_T voltages[8];
  real_T values[6];
  real_T y;
  int32_T n;
  int32_T offset;
  real_T voltages_0[8];
  uint32_T timers_idx_0;

  /* Outputs for Enabled SubSystem: '<S29>/plate1' incorporates:
   *  EnablePort: '<S60>/Enable'
   */
  /* Constant: '<S29>/enable_plate1' */
  if (may23_P.enable_plate1_Value > 0.0) {
    /* S-Function (slrtUDPReceive): '<S60>/Receive' */

    /* Level2 S-Function Block: '<S60>/Receive' (slrtUDPReceive) */
    {
      SimStruct *rts = may23_M->childSfunctions[3];
      sfcnOutputs(rts,1);
    }

    /* MATLAB Function: '<S60>/parse packet 1' incorporates:
     *  Constant: '<S29>/ain_offset1'
     *  Constant: '<S29>/ain_slope1'
     *  Constant: '<S29>/calibration_matrix1'
     *  Constant: '<S29>/gain'
     *  Constant: '<S29>/orientation1'
     *  Constant: '<S29>/zero_voltage'
     */
    /* MATLAB Function 'DataLogging/Poll Force Plates/plate1/parse packet 1': '<S64>:1' */
    /* '<S64>:1:5' */
    /* '<S64>:1:8' */
    for (n = 0; n < 8; n++) {
      /* '<S64>:1:8' */
      /* '<S64>:1:9' */
      offset = (n << 1) + 12;

      /* '<S64>:1:59' */
      /* '<S64>:1:60' */
      /* '<S64>:1:61' */
      /* '<S64>:1:10' */
      /* '<S64>:1:73' */
      voltages[n] = (real_T)((int32_T)((uint32_T)may23_B.Receive_o1_p[offset + 1]
        << 8) + may23_B.Receive_o1_p[offset]) * may23_P.ain_slope1_Value +
        may23_P.ain_offset1_Value;
    }

    /* '<S64>:1:6' */
    /* '<S64>:1:13' */
    /* '<S64>:1:14' */
    /* '<S64>:1:65' */
    /* '<S64>:1:66' */
    /* '<S64>:1:67' */
    /* '<S64>:1:68' */
    /* '<S64>:1:69' */
    timers_idx_0 = ((((uint32_T)may23_B.Receive_o1_p[53] << 8) +
                     may23_B.Receive_o1_p[52]) + ((uint32_T)
      may23_B.Receive_o1_p[54] << 16)) + ((uint32_T)may23_B.Receive_o1_p[55] <<
      24);

    /* '<S64>:1:13' */
    /* '<S64>:1:14' */
    /* '<S64>:1:65' */
    /* '<S64>:1:66' */
    /* '<S64>:1:67' */
    /* '<S64>:1:68' */
    /* '<S64>:1:69' */
    /* '<S64>:1:18' */
    /* '<S64>:1:21' */
    /* '<S64>:1:22' */
    /* '<S64>:1:25' */
    for (n = 0; n < 8; n++) {
      y = voltages[n];
      y -= may23_P.zero_voltage_Value;
      voltages_0[n] = y / may23_P.gain_Value;
      voltages[n] = y;
    }

    for (n = 0; n < 6; n++) {
      values[n] = 0.0;
      for (offset = 0; offset < 8; offset++) {
        y = values[n];
        y += may23_P.calibration_matrix1_Value[6 * offset + n] *
          voltages_0[offset];
        values[n] = y;
      }
    }

    /* '<S64>:1:26' */
    /* '<S64>:1:27' */
    may23_B.forces_e[0] = values[0];
    may23_B.moments_i[0] = values[3];
    may23_B.forces_e[1] = values[1];
    may23_B.moments_i[1] = values[4];
    may23_B.forces_e[2] = values[2];
    may23_B.moments_i[2] = values[5];

    /* '<S64>:1:30' */
    may23_B.forces_e[2] = -may23_B.forces_e[2];
    if (may23_P.orientation1_Value == 0.0) {
      /* '<S64>:1:33' */
      /* '<S64>:1:34' */
      may23_B.forces_e[1] = -may23_B.forces_e[1];

      /* '<S64>:1:35' */
      may23_B.moments_i[1] = -may23_B.moments_i[1];
    } else if (may23_P.orientation1_Value == 90.0) {
      /* '<S64>:1:36' */
      /* '<S64>:1:37' */
      y = may23_B.forces_e[1];

      /* '<S64>:1:38' */
      may23_B.forces_e[1] = -may23_B.forces_e[0];

      /* '<S64>:1:39' */
      may23_B.forces_e[0] = -y;

      /* '<S64>:1:41' */
      y = may23_B.moments_i[1];

      /* '<S64>:1:42' */
      may23_B.moments_i[1] = -may23_B.moments_i[0];

      /* '<S64>:1:43' */
      may23_B.moments_i[0] = -y;
    } else if (may23_P.orientation1_Value == 180.0) {
      /* '<S64>:1:44' */
      /* '<S64>:1:45' */
      may23_B.forces_e[0] = -may23_B.forces_e[0];

      /* '<S64>:1:46' */
      may23_B.moments_i[0] = -may23_B.moments_i[0];
    } else {
      if (may23_P.orientation1_Value == 270.0) {
        /* '<S64>:1:47' */
        /* '<S64>:1:48' */
        y = may23_B.forces_e[1];

        /* '<S64>:1:49' */
        may23_B.forces_e[1] = may23_B.forces_e[0];

        /* '<S64>:1:50' */
        may23_B.forces_e[0] = y;

        /* '<S64>:1:52' */
        y = may23_B.moments_i[1];

        /* '<S64>:1:53' */
        may23_B.moments_i[1] = may23_B.moments_i[0];

        /* '<S64>:1:54' */
        may23_B.moments_i[0] = y;
      }
    }

    may23_B.timer_a = (real_T)timers_idx_0 / 750000.0;

    /* End of MATLAB Function: '<S60>/parse packet 1' */
    srUpdateBC(may23_DW.plate1_SubsysRanBC);
  }

  /* End of Outputs for SubSystem: '<S29>/plate1' */

  /* Outputs for Enabled SubSystem: '<S29>/plate2' incorporates:
   *  EnablePort: '<S61>/Enable'
   */
  /* Constant: '<S29>/enable_plate2' */
  if (may23_P.enable_plate2_Value > 0.0) {
    /* S-Function (slrtUDPReceive): '<S61>/Receive1' */

    /* Level2 S-Function Block: '<S61>/Receive1' (slrtUDPReceive) */
    {
      SimStruct *rts = may23_M->childSfunctions[4];
      sfcnOutputs(rts,1);
    }

    /* MATLAB Function: '<S61>/parse packet 1' incorporates:
     *  Constant: '<S29>/ain_offset2'
     *  Constant: '<S29>/ain_slope2'
     *  Constant: '<S29>/calibration_matrix2'
     *  Constant: '<S29>/gain'
     *  Constant: '<S29>/orientation2'
     *  Constant: '<S29>/zero_voltage'
     */
    /* MATLAB Function 'DataLogging/Poll Force Plates/plate2/parse packet 1': '<S65>:1' */
    /* '<S65>:1:5' */
    /* '<S65>:1:8' */
    for (n = 0; n < 8; n++) {
      /* '<S65>:1:8' */
      /* '<S65>:1:9' */
      offset = (n << 1) + 12;

      /* '<S65>:1:59' */
      /* '<S65>:1:60' */
      /* '<S65>:1:61' */
      /* '<S65>:1:10' */
      /* '<S65>:1:73' */
      voltages[n] = (real_T)((int32_T)((uint32_T)may23_B.Receive1_o1[offset + 1]
        << 8) + may23_B.Receive1_o1[offset]) * may23_P.ain_slope2_Value +
        may23_P.ain_offset2_Value;
    }

    /* '<S65>:1:6' */
    /* '<S65>:1:13' */
    /* '<S65>:1:14' */
    /* '<S65>:1:65' */
    /* '<S65>:1:66' */
    /* '<S65>:1:67' */
    /* '<S65>:1:68' */
    /* '<S65>:1:69' */
    timers_idx_0 = ((((uint32_T)may23_B.Receive1_o1[53] << 8) +
                     may23_B.Receive1_o1[52]) + ((uint32_T)may23_B.Receive1_o1
      [54] << 16)) + ((uint32_T)may23_B.Receive1_o1[55] << 24);

    /* '<S65>:1:13' */
    /* '<S65>:1:14' */
    /* '<S65>:1:65' */
    /* '<S65>:1:66' */
    /* '<S65>:1:67' */
    /* '<S65>:1:68' */
    /* '<S65>:1:69' */
    /* '<S65>:1:18' */
    /* '<S65>:1:21' */
    /* '<S65>:1:22' */
    /* '<S65>:1:25' */
    for (n = 0; n < 8; n++) {
      y = voltages[n];
      y -= may23_P.zero_voltage_Value;
      voltages_0[n] = y / may23_P.gain_Value;
      voltages[n] = y;
    }

    for (n = 0; n < 6; n++) {
      values[n] = 0.0;
      for (offset = 0; offset < 8; offset++) {
        y = values[n];
        y += may23_P.calibration_matrix2_Value[6 * offset + n] *
          voltages_0[offset];
        values[n] = y;
      }
    }

    /* '<S65>:1:26' */
    /* '<S65>:1:27' */
    may23_B.forces[0] = values[0];
    may23_B.moments[0] = values[3];
    may23_B.forces[1] = values[1];
    may23_B.moments[1] = values[4];
    may23_B.forces[2] = values[2];
    may23_B.moments[2] = values[5];

    /* '<S65>:1:30' */
    may23_B.forces[2] = -may23_B.forces[2];
    if (may23_P.orientation2_Value == 0.0) {
      /* '<S65>:1:33' */
      /* '<S65>:1:34' */
      may23_B.forces[1] = -may23_B.forces[1];

      /* '<S65>:1:35' */
      may23_B.moments[1] = -may23_B.moments[1];
    } else if (may23_P.orientation2_Value == 90.0) {
      /* '<S65>:1:36' */
      /* '<S65>:1:37' */
      y = may23_B.forces[1];

      /* '<S65>:1:38' */
      may23_B.forces[1] = -may23_B.forces[0];

      /* '<S65>:1:39' */
      may23_B.forces[0] = -y;

      /* '<S65>:1:41' */
      y = may23_B.moments[1];

      /* '<S65>:1:42' */
      may23_B.moments[1] = -may23_B.moments[0];

      /* '<S65>:1:43' */
      may23_B.moments[0] = -y;
    } else if (may23_P.orientation2_Value == 180.0) {
      /* '<S65>:1:44' */
      /* '<S65>:1:45' */
      may23_B.forces[0] = -may23_B.forces[0];

      /* '<S65>:1:46' */
      may23_B.moments[0] = -may23_B.moments[0];
    } else {
      if (may23_P.orientation2_Value == 270.0) {
        /* '<S65>:1:47' */
        /* '<S65>:1:48' */
        y = may23_B.forces[1];

        /* '<S65>:1:49' */
        may23_B.forces[1] = may23_B.forces[0];

        /* '<S65>:1:50' */
        may23_B.forces[0] = y;

        /* '<S65>:1:52' */
        y = may23_B.moments[1];

        /* '<S65>:1:53' */
        may23_B.moments[1] = may23_B.moments[0];

        /* '<S65>:1:54' */
        may23_B.moments[0] = y;
      }
    }

    may23_B.timer = (real_T)timers_idx_0 / 750000.0;

    /* End of MATLAB Function: '<S61>/parse packet 1' */
    srUpdateBC(may23_DW.plate2_SubsysRanBC);
  }

  /* End of Outputs for SubSystem: '<S29>/plate2' */

  /* DataTypeConversion: '<S29>/Convert19' */
  may23_B.Convert19_h[0] = may23_B.forces_e[0];
  may23_B.Convert19_h[1] = may23_B.forces_e[1];
  may23_B.Convert19_h[2] = may23_B.forces_e[2];
  may23_B.Convert19_h[3] = may23_B.moments_i[0];
  may23_B.Convert19_h[4] = may23_B.moments_i[1];
  may23_B.Convert19_h[5] = may23_B.moments_i[2];
  may23_B.Convert19_h[6] = may23_B.timer_a;
  may23_B.Convert19_h[7] = may23_B.forces[0];
  may23_B.Convert19_h[8] = may23_B.forces[1];
  may23_B.Convert19_h[9] = may23_B.forces[2];
  may23_B.Convert19_h[10] = may23_B.moments[0];
  may23_B.Convert19_h[11] = may23_B.moments[1];
  may23_B.Convert19_h[12] = may23_B.moments[2];
  may23_B.Convert19_h[13] = may23_B.timer;

  /* RateTransition: '<S29>/Rate Transition' incorporates:
   *  Constant: '<S29>/enable_plate1'
   */
  if (may23_M->Timing.RateInteraction.TID1_2) {
    may23_DW.RateTransition_Buffer_l = may23_P.enable_plate1_Value;

    /* RateTransition: '<S29>/Rate Transition1' incorporates:
     *  Constant: '<S29>/enable_plate1'
     *  Constant: '<S29>/enable_plate2'
     */
    may23_DW.RateTransition1_Buffer_kz = may23_P.enable_plate2_Value;
  }

  /* End of RateTransition: '<S29>/Rate Transition' */
}

/* Output and update for atomic system: '<S1>/Poll Force Plates' */
void may23_PollForcePlatesTID2(void)
{
  int32_T i;

  /* DataTypeConversion: '<S29>/Convert1' incorporates:
   *  Constant: '<S29>/request_packet'
   */
  for (i = 0; i < 34; i++) {
    may23_B.Convert1_a[i] = (uint8_T)may23_P.request_packet_Value[i];
  }

  /* End of DataTypeConversion: '<S29>/Convert1' */

  /* RateTransition: '<S29>/Rate Transition' */
  may23_B.RateTransition_a = may23_DW.RateTransition_Buffer_l;

  /* Outputs for Enabled SubSystem: '<S29>/send poll 1' incorporates:
   *  EnablePort: '<S62>/Enable'
   */
  if (may23_B.RateTransition_a > 0.0) {
    /* S-Function (slrtUDPSend): '<S62>/Send' */

    /* Level2 S-Function Block: '<S62>/Send' (slrtUDPSend) */
    {
      SimStruct *rts = may23_M->childSfunctions[5];
      sfcnOutputs(rts,2);
    }

    srUpdateBC(may23_DW.sendpoll1_SubsysRanBC);
  }

  /* End of Outputs for SubSystem: '<S29>/send poll 1' */

  /* RateTransition: '<S29>/Rate Transition1' */
  may23_B.RateTransition1_ot = may23_DW.RateTransition1_Buffer_kz;

  /* Outputs for Enabled SubSystem: '<S29>/send poll 2' incorporates:
   *  EnablePort: '<S63>/Enable'
   */
  if (may23_B.RateTransition1_ot > 0.0) {
    /* S-Function (slrtUDPSend): '<S63>/Send1' */

    /* Level2 S-Function Block: '<S63>/Send1' (slrtUDPSend) */
    {
      SimStruct *rts = may23_M->childSfunctions[6];
      sfcnOutputs(rts,2);
    }

    srUpdateBC(may23_DW.sendpoll2_SubsysRanBC);
  }

  /* End of Outputs for SubSystem: '<S29>/send poll 2' */
}

/* Termination for atomic system: '<S1>/Poll Force Plates' */
void may23_PollForcePlates_Term(void)
{
  /* Terminate for Enabled SubSystem: '<S29>/plate1' */

  /* Terminate for S-Function (slrtUDPReceive): '<S60>/Receive' */
  /* Level2 S-Function Block: '<S60>/Receive' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[3];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S29>/plate1' */

  /* Terminate for Enabled SubSystem: '<S29>/plate2' */

  /* Terminate for S-Function (slrtUDPReceive): '<S61>/Receive1' */
  /* Level2 S-Function Block: '<S61>/Receive1' (slrtUDPReceive) */
  {
    SimStruct *rts = may23_M->childSfunctions[4];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S29>/plate2' */

  /* Terminate for Enabled SubSystem: '<S29>/send poll 1' */

  /* Terminate for S-Function (slrtUDPSend): '<S62>/Send' */
  /* Level2 S-Function Block: '<S62>/Send' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[5];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S29>/send poll 1' */

  /* Terminate for Enabled SubSystem: '<S29>/send poll 2' */

  /* Terminate for S-Function (slrtUDPSend): '<S63>/Send1' */
  /* Level2 S-Function Block: '<S63>/Send1' (slrtUDPSend) */
  {
    SimStruct *rts = may23_M->childSfunctions[6];
    sfcnTerminate(rts);
  }

  /* End of Terminate for SubSystem: '<S29>/send poll 2' */
}
