/*
 * Code generation for system system '<S7>/Embedded MATLAB InsideTarget'
 *
 * Model                      : may23
 * Model version              : 1.3688
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri May 23 14:42:33 2025
 *
 * Note that the functions contained in this file are part of a Simulink
 * model, and are not self-contained algorithms.
 */

#include "may23_EmbeddedMATLABInsideTarget_d.h"

/* Include model header file for global data */
#include "may23.h"
#include "may23_private.h"

/* Forward declaration for local functions */
static void may23_sin_m(real_T x[64]);
static void may23_cos_b(real_T x[64]);
static void may23_atan2_n(const real_T y[64], const real_T x[64], real_T r[64]);
static void may23_power_d(const real_T a[64], real_T y[64]);
static void may23_sqrt_l(real_T x[64]);
static void may23_abs_h(const real_T x[64], real_T y[64]);

/* Function for MATLAB Function: '<S7>/Embedded MATLAB InsideTarget' */
static void may23_sin_m(real_T x[64])
{
  int32_T k;
  for (k = 0; k < 64; k++) {
    x[k] = sin(x[k]);
  }
}

/* Function for MATLAB Function: '<S7>/Embedded MATLAB InsideTarget' */
static void may23_cos_b(real_T x[64])
{
  int32_T k;
  for (k = 0; k < 64; k++) {
    x[k] = cos(x[k]);
  }
}

/* Function for MATLAB Function: '<S7>/Embedded MATLAB InsideTarget' */
static void may23_atan2_n(const real_T y[64], const real_T x[64], real_T r[64])
{
  int32_T k;
  for (k = 0; k < 64; k++) {
    r[k] = rt_atan2d_snf(y[k], x[k]);
  }
}

/* Function for MATLAB Function: '<S7>/Embedded MATLAB InsideTarget' */
static void may23_power_d(const real_T a[64], real_T y[64])
{
  int32_T k;
  real_T a_0;
  for (k = 0; k < 64; k++) {
    a_0 = a[k];
    y[k] = a_0 * a_0;
  }
}

/* Function for MATLAB Function: '<S7>/Embedded MATLAB InsideTarget' */
static void may23_sqrt_l(real_T x[64])
{
  int32_T k;
  for (k = 0; k < 64; k++) {
    x[k] = sqrt(x[k]);
  }
}

/* Function for MATLAB Function: '<S7>/Embedded MATLAB InsideTarget' */
static void may23_abs_h(const real_T x[64], real_T y[64])
{
  int32_T k;
  for (k = 0; k < 64; k++) {
    y[k] = fabs(x[k]);
  }
}

/* Output and update for atomic system: '<S7>/Embedded MATLAB InsideTarget' */
void may23_EmbeddedMATLABInsideTarget_d(void)
{
  real_T deltax[64];
  real_T deltay[64];
  real_T t[64];
  real_T sint[64];
  real_T w[64];
  real_T h[64];
  real_T p[64];
  real_T A[128];
  real_T v0[128];
  real_T v1[128];
  real_T v2[128];
  real_T dot02[64];
  real_T dot11[64];
  int32_T e_target;
  int32_T i;
  real_T dot02_0[64];
  real_T tmp[64];
  int32_T i_0;
  int32_T i_1;
  real_T deltax_0;
  real_T t_0;
  real_T deltay_0;
  real_T sint_0;
  real_T w_0;
  real_T p_0;
  real_T h_0;

  /* SignalConversion generated from: '<S373>/ SFunction ' incorporates:
   *  Constant: '<S7>/attribcol1'
   *  Constant: '<S7>/attribcol2'
   *  Constant: '<S7>/attribcol3'
   *  Constant: '<S7>/attribcol4'
   *  Constant: '<S7>/attribcol5'
   */
  may23_B.TmpSignalConversionAtSFunctionInport3_n[0] =
    may23_P.KINARM_HandInTarget_attribcol1;
  may23_B.TmpSignalConversionAtSFunctionInport3_n[1] = may23_P.attribcol2_Value;
  may23_B.TmpSignalConversionAtSFunctionInport3_n[2] = may23_P.attribcol3_Value;
  may23_B.TmpSignalConversionAtSFunctionInport3_n[3] = may23_P.attribcol4_Value;
  may23_B.TmpSignalConversionAtSFunctionInport3_n[4] = may23_P.attribcol5_Value;

  /* MATLAB Function 'KINARM_HandInTarget/Embedded MATLAB InsideTarget': '<S373>:1' */
  /* '<S373>:1:31' */
  /* '<S373>:1:26' */
  /* '<S373>:1:27' */
  /* '<S373>:1:29' */
  for (i = 0; i < 320; i++) {
    may23_B.intarget_d[i] = 0.0;
  }

  /* '<S373>:1:31' */
  /* '<S373>:1:32' */
  /* '<S373>:1:34' */
  h_0 = may23_B.Switch[0];
  for (i = 0; i < 64; i++) {
    deltax[i] = h_0 - may23_B.TargetTable[i] * 0.01;
  }

  /* '<S373>:1:35' */
  h_0 = may23_B.Switch[1];
  for (i = 0; i < 64; i++) {
    deltay[i] = h_0 - may23_B.TargetTable[i + 64] * 0.01;
  }

  /* Constant: '<S7>/Target_Type' */
  if (may23_P.KINARM_HandInTarget_target_type == 1.0) {
    /* Constant: '<S7>/num_states' */
    /* '<S373>:1:37' */
    /* '<S373>:1:38' */
    if (0 <= (int32_T)may23_P.KINARM_HandInTarget_num_states - 1) {
      may23_power_d(deltax, tmp);
      may23_power_d(deltay, w);
    }

    /* Constant: '<S7>/num_states' */
    for (e_target = 0; e_target < (int32_T)
         may23_P.KINARM_HandInTarget_num_states; e_target++) {
      /* '<S373>:1:38' */
      /* '<S373>:1:39' */
      /* '<S373>:1:41' */
      /* '<S373>:1:42' */
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[e_target];
      for (i_0 = 0; i_0 < 64; i_0++) {
        t[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
      }

      may23_power_d(t, sint);
      for (i = 0; i < 64; i++) {
        may23_B.intarget_d[i + (e_target << 6)] = (tmp[i] + w[i] <= sint[i]);
      }
    }
  } else if (may23_P.KINARM_HandInTarget_target_type == 2.0) {
    /* '<S373>:1:44' */
    /* '<S373>:1:45' */
    /* Constant: '<S7>/num_states' */
    for (e_target = 1; e_target - 1 < (int32_T)
         may23_P.KINARM_HandInTarget_num_states; e_target++) {
      /* '<S373>:1:45' */
      /* '<S373>:1:46' */
      /* '<S373>:1:47' */
      /* '<S373>:1:48' */
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[e_target * 3
        - 1];
      for (i_0 = 0; i_0 < 64; i_0++) {
        t[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] *
          0.017453292519943295;
      }

      /* '<S373>:1:49' */
      memcpy(&sint[0], &t[0], sizeof(real_T) << 6U);
      may23_sin_m(sint);

      /* '<S373>:1:50' */
      may23_cos_b(t);

      /* '<S373>:1:51' */
      /* '<S373>:1:52' */
      for (i = 0; i < 64; i++) {
        w[i] = -deltax[i] * sint[i] + deltay[i] * t[i];
      }

      /* '<S373>:1:53' */
      /* '<S373>:1:54' */
      /* '<S373>:1:55' */
      may23_power_d(w, tmp);
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[e_target * 3
        - 3];
      for (i_0 = 0; i_0 < 64; i_0++) {
        h[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01 * (w[i_0] /
          (deltax[i_0] * t[i_0] + deltay[i_0] * sint[i_0]));
      }

      may23_power_d(h, w);
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[e_target * 3
        - 2];
      for (i_0 = 0; i_0 < 64; i_0++) {
        t[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
      }

      may23_power_d(t, sint);
      for (i = 0; i < 64; i++) {
        may23_B.intarget_d[i + ((e_target - 1) << 6)] = (tmp[i] <= 1.0 / (1.0 /
          w[i] + 1.0 / sint[i]));
      }
    }
  } else if (may23_P.KINARM_HandInTarget_target_type == 3.0) {
    /* '<S373>:1:57' */
    /* '<S373>:1:58' */
    /* Constant: '<S7>/num_states' */
    for (e_target = 1; e_target - 1 < (int32_T)
         may23_P.KINARM_HandInTarget_num_states; e_target++) {
      /* '<S373>:1:58' */
      /* '<S373>:1:59' */
      /* '<S373>:1:60' */
      if (may23_B.TmpSignalConversionAtSFunctionInport3_n[e_target * 3 - 1] >
          0.0) {
        /* '<S373>:1:62' */
        /* '<S373>:1:63' */
        i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[e_target *
          3 - 1];
        for (i_0 = 0; i_0 < 64; i_0++) {
          t[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] *
            0.017453292519943295;
        }
      } else {
        /* '<S373>:1:65' */
        for (i = 0; i < 64; i++) {
          t[i] = 0.0;
        }
      }

      /* '<S373>:1:68' */
      memcpy(&sint[0], &t[0], sizeof(real_T) << 6U);
      may23_sin_m(sint);

      /* '<S373>:1:69' */
      may23_cos_b(t);

      /* '<S373>:1:71' */
      /* '<S373>:1:72' */
      /* '<S373>:1:74' */
      for (i = 0; i < 64; i++) {
        h[i] = deltax[i] * t[i] + deltay[i] * sint[i];
      }

      may23_abs_h(h, tmp);
      for (i = 0; i < 64; i++) {
        h[i] = -deltax[i] * sint[i] + deltay[i] * t[i];
      }

      may23_abs_h(h, w);
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[e_target * 3
        - 3];
      i_0 = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[e_target *
        3 - 2];
      for (i_1 = 0; i_1 < 64; i_1++) {
        may23_B.intarget_d[i_1 + ((e_target - 1) << 6)] = ((tmp[i_1] <=
          may23_B.TargetTable[((i - 1) << 6) + i_1] * 0.01 / 2.0) && (w[i_1] <=
          may23_B.TargetTable[((i_0 - 1) << 6) + i_1] * 0.01 / 2.0));
      }
    }
  } else if (may23_P.KINARM_HandInTarget_target_type == 4.0) {
    /* '<S373>:1:76' */
    /* '<S373>:1:77' */
    /* Constant: '<S7>/num_states' */
    for (e_target = 1; e_target - 1 < (int32_T)
         may23_P.KINARM_HandInTarget_num_states; e_target++) {
      /* '<S373>:1:77' */
      if (may23_B.TmpSignalConversionAtSFunctionInport3_n[e_target * 3 - 3] ==
          0.0) {
        /* '<S373>:1:80' */
        /* '<S373>:1:81' */
        for (i = 0; i < 64; i++) {
          h[i] = 0.0;
        }
      } else if (may23_B.TmpSignalConversionAtSFunctionInport3_n[e_target * 3 -
                 3] < 0.0) {
        /* '<S373>:1:82' */
        /* '<S373>:1:83' */
        for (i = 0; i < 64; i++) {
          h[i] = 0.001;
        }
      } else {
        /* '<S373>:1:85' */
        i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[e_target *
          3 - 3];
        for (i_0 = 0; i_0 < 64; i_0++) {
          h[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
        }
      }

      /* '<S373>:1:88' */
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[e_target * 3
        - 2];
      for (i_0 = 0; i_0 < 64; i_0++) {
        w[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
      }

      /* '<S373>:1:89' */
      i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[e_target * 3
        - 1];
      for (i_0 = 0; i_0 < 64; i_0++) {
        p[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
      }

      /* '<S373>:1:91' */
      /* '<S373>:1:94' */
      /* '<S373>:1:95' */
      /* '<S373>:1:97' */
      may23_atan2_n(p, w, t);

      /* '<S373>:1:98' */
      for (i = 0; i < 64; i++) {
        dot02[i] = deltax[i] - w[i] / 2.0;
        dot11[i] = deltay[i] - p[i] / 2.0;
        sint[i] = t[i];
      }

      may23_sin_m(sint);

      /* '<S373>:1:99' */
      may23_cos_b(t);

      /* '<S373>:1:101' */
      /* '<S373>:1:102' */
      /* '<S373>:1:104' */
      may23_power_d(w, tmp);
      may23_power_d(p, w);
      for (i = 0; i < 64; i++) {
        p[i] = tmp[i] + w[i];
      }

      may23_sqrt_l(p);
      for (i = 0; i < 64; i++) {
        dot02_0[i] = dot02[i] * t[i] + dot11[i] * sint[i];
      }

      may23_abs_h(dot02_0, tmp);
      for (i = 0; i < 64; i++) {
        dot02_0[i] = -dot02[i] * sint[i] + dot11[i] * t[i];
      }

      may23_abs_h(dot02_0, w);
      for (i = 0; i < 64; i++) {
        may23_B.intarget_d[i + ((e_target - 1) << 6)] = ((tmp[i] <= p[i] / 2.0) &&
          (w[i] <= h[i] / 2.0));
      }
    }
  } else {
    if (may23_P.KINARM_HandInTarget_target_type == 5.0) {
      /* '<S373>:1:106' */
      /* '<S373>:1:107' */
      /* Constant: '<S7>/num_states' */
      for (e_target = 1; e_target - 1 < (int32_T)
           may23_P.KINARM_HandInTarget_num_states; e_target++) {
        /* '<S373>:1:107' */
        /* '<S373>:1:108' */
        i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[(e_target <<
          2) - 4];
        for (i_0 = 0; i_0 < 64; i_0++) {
          w[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
        }

        if (may23_B.TmpSignalConversionAtSFunctionInport3_n[(e_target << 2) - 3]
            > 0.0) {
          /* '<S373>:1:112' */
          /* '<S373>:1:113' */
          i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[(e_target
            << 2) - 3];
          for (i_0 = 0; i_0 < 64; i_0++) {
            h[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
          }

          /* '<S373>:1:114' */
          i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[(e_target
            << 2) - 2];
          for (i_0 = 0; i_0 < 64; i_0++) {
            p[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] * 0.01;
          }
        } else {
          /* '<S373>:1:116' */
          /* '<S373>:1:117' */
          for (i = 0; i < 64; i++) {
            h[i] = w[i] * 0.8660254037844386;
            p[i] = 0.0;
          }
        }

        if (may23_B.TmpSignalConversionAtSFunctionInport3_n[(e_target << 2) - 1]
            > 0.0) {
          /* '<S373>:1:120' */
          /* '<S373>:1:121' */
          i = (int32_T)may23_B.TmpSignalConversionAtSFunctionInport3_n[(e_target
            << 2) - 1];
          for (i_0 = 0; i_0 < 64; i_0++) {
            t[i_0] = may23_B.TargetTable[((i - 1) << 6) + i_0] *
              0.017453292519943295;
          }
        } else {
          /* '<S373>:1:123' */
          for (i = 0; i < 64; i++) {
            t[i] = 0.0;
          }
        }

        /* '<S373>:1:126' */
        memcpy(&sint[0], &t[0], sizeof(real_T) << 6U);
        may23_sin_m(sint);

        /* '<S373>:1:127' */
        may23_cos_b(t);

        /* '<S373>:1:129' */
        /* '<S373>:1:130' */
        /* '<S373>:1:133' */
        /* '<S373>:1:134' */
        /* '<S373>:1:135' */
        /* '<S373>:1:137' */
        /* '<S373>:1:138' */
        /* '<S373>:1:139' */
        /* '<S373>:1:141' */
        /* '<S373>:1:142' */
        /* '<S373>:1:143' */
        /* '<S373>:1:144' */
        /* '<S373>:1:145' */
        /* '<S373>:1:147' */
        /* '<S373>:1:148' */
        /* '<S373>:1:149' */
        for (i = 0; i < 64; i++) {
          h_0 = h[i];
          p_0 = p[i];
          w_0 = w[i];
          A[i] = -w_0 / 2.0 - p_0 / 3.0;
          A[i + 64] = -h_0 / 3.0;
          sint_0 = sint[i];
          deltay_0 = deltay[i];
          t_0 = t[i];
          deltax_0 = deltax[i];
          v0[i] = (w_0 / 2.0 - p_0 / 3.0) - A[i];
          v0[i + 64] = -h_0 / 3.0 - A[i + 64];
          v1[i] = 2.0 * p_0 / 3.0 - A[i];
          v1[i + 64] = 2.0 * h_0 / 3.0 - A[i + 64];
          v2[i] = (deltax_0 * t_0 + deltay_0 * sint_0) - A[i];
          v2[i + 64] = (-deltax_0 * sint_0 + deltay_0 * t_0) - A[i + 64];
          w_0 = v0[i + 64] * v0[i + 64] + v0[i] * v0[i];
          p_0 = v0[i + 64] * v1[i + 64] + v0[i] * v1[i];
          sint_0 = v0[i + 64] * v2[i + 64] + v0[i] * v2[i];
          deltay_0 = v1[i + 64] * v1[i + 64] + v1[i] * v1[i];
          t_0 = v1[i + 64] * v2[i + 64] + v1[i] * v2[i];
          h_0 = 1.0 / (w_0 * deltay_0 - p_0 * p_0);
          deltay_0 = (deltay_0 * sint_0 - p_0 * t_0) * h_0;
          w_0 = (w_0 * t_0 - p_0 * sint_0) * h_0;
          dot11[i] = deltay_0;
          w[i] = w_0;
          p[i] = p_0;
          h[i] = h_0;
        }

        /* '<S373>:1:151' */
        for (i = 0; i < 64; i++) {
          w_0 = w[i];
          deltay_0 = dot11[i];
          may23_B.intarget_d[i + ((e_target - 1) << 6)] = ((deltay_0 > 0.0) &&
            (w_0 > 0.0) && (deltay_0 + w_0 < 1.0));
        }
      }
    }
  }

  /* End of Constant: '<S7>/Target_Type' */
}
