/* Include files */

#include "General_sfun.h"
#include "c42_General.h"
#include <stdlib.h>
#include "mwmathutil.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(S);
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

/* Type Definitions */

/* Named Constants */
#define c42_event_e_clk                (0)
#define c42_event_e_trial_over         (1)
#define CALL_EVENT                     (-1)
#define c42_IN_NO_ACTIVE_CHILD         ((uint8_T)0U)
#define c42_IN_Finished                ((uint8_T)1U)
#define c42_IN_Finished1               ((uint8_T)2U)
#define c42_IN_InTrial                 ((uint8_T)3U)
#define c42_IN_InTrial1                ((uint8_T)4U)
#define c42_IN_PausedBetweenBlocks     ((uint8_T)5U)
#define c42_IN_PausedBetweenTrials     ((uint8_T)6U)
#define c42_IN_PausedBetweenTrials1    ((uint8_T)7U)
#define c42_IN_Ready                   ((uint8_T)8U)
#define c42_IN_Paused1                 ((uint8_T)1U)
#define c42_IN_RepeatTrialLater1       ((uint8_T)2U)
#define c42_IN_RepeatTrialNow1         ((uint8_T)3U)
#define c42_IN_Running1                ((uint8_T)4U)
#define c42_IN_SkipTrial1              ((uint8_T)5U)
#define c42_IN_Paused                  ((uint8_T)1U)
#define c42_IN_RepeatTrialLater        ((uint8_T)2U)
#define c42_IN_RepeatTrialNow          ((uint8_T)3U)
#define c42_IN_Running                 ((uint8_T)4U)
#define c42_IN_SkipTrial               ((uint8_T)5U)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;

/* Function Declarations */
static void initialize_c42_General(SFc42_GeneralInstanceStruct *chartInstance);
static void initialize_params_c42_General(SFc42_GeneralInstanceStruct
  *chartInstance);
static void enable_c42_General(SFc42_GeneralInstanceStruct *chartInstance);
static void disable_c42_General(SFc42_GeneralInstanceStruct *chartInstance);
static void c42_update_jit_animation_state_c42_General
  (SFc42_GeneralInstanceStruct *chartInstance);
static void c42_do_animation_call_c42_General(SFc42_GeneralInstanceStruct
  *chartInstance);
static void ext_mode_exec_c42_General(SFc42_GeneralInstanceStruct *chartInstance);
static const mxArray *get_sim_state_c42_General(SFc42_GeneralInstanceStruct
  *chartInstance);
static void set_sim_state_c42_General(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_st);
static void c42_set_sim_state_side_effects_c42_General
  (SFc42_GeneralInstanceStruct *chartInstance);
static void finalize_c42_General(SFc42_GeneralInstanceStruct *chartInstance);
static void sf_gateway_c42_General(SFc42_GeneralInstanceStruct *chartInstance);
static void mdl_start_c42_General(SFc42_GeneralInstanceStruct *chartInstance);
static void c42_chartstep_c42_General(SFc42_GeneralInstanceStruct *chartInstance);
static void initSimStructsc42_General(SFc42_GeneralInstanceStruct *chartInstance);
static void c42_Ready(SFc42_GeneralInstanceStruct *chartInstance);
static void c42_PausedBetweenBlocks(SFc42_GeneralInstanceStruct *chartInstance);
static void c42_InTrial(SFc42_GeneralInstanceStruct *chartInstance);
static void c42_Paused(SFc42_GeneralInstanceStruct *chartInstance);
static uint32_T c42_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_b_block_idx, const char_T *c42_identifier);
static uint32_T c42_b_emlrt_marshallIn(SFc42_GeneralInstanceStruct
  *chartInstance, const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId);
static void c42_c_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_b_extra_trials, const char_T *c42_identifier, real_T c42_y
  [2]);
static void c42_d_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId, real_T c42_y[2]);
static real_T c42_e_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_b_repeat_last_trial, const char_T *c42_identifier);
static real_T c42_f_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId);
static void c42_g_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_b_repeat_list, const char_T *c42_identifier, real_T c42_y
  [499]);
static void c42_h_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId, real_T c42_y[499]);
static boolean_T c42_i_emlrt_marshallIn(SFc42_GeneralInstanceStruct
  *chartInstance, const mxArray *c42_b_e_exit_trial, const char_T
  *c42_identifier);
static boolean_T c42_j_emlrt_marshallIn(SFc42_GeneralInstanceStruct
  *chartInstance, const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId);
static uint8_T c42_k_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_b_is_active_c42_General, const char_T *c42_identifier);
static uint8_T c42_l_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId);
static const mxArray *c42_m_emlrt_marshallIn(SFc42_GeneralInstanceStruct
  *chartInstance, const mxArray *c42_b_setSimStateSideEffectsInfo, const char_T *
  c42_identifier);
static const mxArray *c42_n_emlrt_marshallIn(SFc42_GeneralInstanceStruct
  *chartInstance, const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId);
static uint8_T c42__u8_u32_(SFc42_GeneralInstanceStruct *chartInstance, uint32_T
  c42_b, int32_T c42_EMLOvCount_src_loc, uint32_T c42_ssid_src_loc, int32_T
  c42_offset_src_loc, int32_T c42_length_src_loc);
static int32_T c42__s32_d_(SFc42_GeneralInstanceStruct *chartInstance, real_T
  c42_b, int32_T c42_EMLOvCount_src_loc, uint32_T c42_ssid_src_loc, int32_T
  c42_offset_src_loc, int32_T c42_length_src_loc);
static uint32_T c42__u32_d_(SFc42_GeneralInstanceStruct *chartInstance, real_T
  c42_b, int32_T c42_EMLOvCount_src_loc, uint32_T c42_ssid_src_loc, int32_T
  c42_offset_src_loc, int32_T c42_length_src_loc);
static uint32_T c42__u32_add__(SFc42_GeneralInstanceStruct *chartInstance,
  uint32_T c42_b, uint32_T c42_c, int32_T c42_EMLOvCount_src_loc, uint32_T
  c42_ssid_src_loc, int32_T c42_offset_src_loc, int32_T c42_length_src_loc);
static uint32_T c42__u32_minus__(SFc42_GeneralInstanceStruct *chartInstance,
  uint32_T c42_b, uint32_T c42_c, int32_T c42_EMLOvCount_src_loc, uint32_T
  c42_ssid_src_loc, int32_T c42_offset_src_loc, int32_T c42_length_src_loc);
static void init_dsm_address_info(SFc42_GeneralInstanceStruct *chartInstance);
static void init_simulink_io_address(SFc42_GeneralInstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c42_General(SFc42_GeneralInstanceStruct *chartInstance)
{
  int32_T c42_b_i;
  sim_mode_is_external(chartInstance->S);
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c42_doSetSimStateSideEffects = 0U;
  chartInstance->c42_setSimStateSideEffectsInfo = NULL;
  *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
  *chartInstance->c42_is_InTrial1 = c42_IN_NO_ACTIVE_CHILD;
  *chartInstance->c42_temporalCounter_i1 = 0U;
  *chartInstance->c42_is_active_c42_General = 0U;
  *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
  for (c42_b_i = 0; c42_b_i < 499; c42_b_i++) {
    (*chartInstance->c42_trial_queue)[c42_b_i] = 0.0;
    (*chartInstance->c42_repeat_list)[c42_b_i] = 0.0;
  }

  *chartInstance->c42_repeat_list_length = 0U;
  *chartInstance->c42_i = 1U;
  *chartInstance->c42_swap_index = 0U;
  *chartInstance->c42_temp = 0U;
  *chartInstance->c42_trial_queue_length = 499U;
  *chartInstance->c42_trial_in_mini_block = 0U;
  *chartInstance->c42_EXAM = 1.0;
  *chartInstance->c42_BLOCK = 2.0;
  *chartInstance->c42_block = 0.0;
  if (sf_get_output_port_reusable(chartInstance->S, 1) == 0) {
    *chartInstance->c42_task_status = 0U;
  }

  if (sf_get_output_port_reusable(chartInstance->S, 2) == 0) {
    *chartInstance->c42_tp = 0U;
  }

  if (sf_get_output_port_reusable(chartInstance->S, 3) == 0) {
    *chartInstance->c42_block_idx = 0U;
  }

  if (sf_get_output_port_reusable(chartInstance->S, 4) == 0) {
    *chartInstance->c42_trial_in_block = 0U;
  }

  if (sf_get_output_port_reusable(chartInstance->S, 5) == 0) {
    *chartInstance->c42_block_in_set = 0U;
  }

  if (sf_get_output_port_reusable(chartInstance->S, 6) == 0) {
    *chartInstance->c42_trial_in_set = 0U;
  }

  if (sf_get_output_port_reusable(chartInstance->S, 7) == 0) {
    *chartInstance->c42_repeat_last_trial = 0.0;
  }

  if (sf_get_output_port_reusable(chartInstance->S, 8) == 0) {
    for (c42_b_i = 0; c42_b_i < 2; c42_b_i++) {
      (*chartInstance->c42_extra_trials)[c42_b_i] = 0.0;
    }
  }

  *chartInstance->c42_e_exit_trialEventCounter = 0U;
  *chartInstance->c42_e_exit_trial = false;
}

static void initialize_params_c42_General(SFc42_GeneralInstanceStruct
  *chartInstance)
{
  (void)chartInstance;
}

static void enable_c42_General(SFc42_GeneralInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c42_General(SFc42_GeneralInstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void c42_update_jit_animation_state_c42_General
  (SFc42_GeneralInstanceStruct *chartInstance)
{
  chartInstance->c42_JITStateAnimation[0U] = (uint8_T)
    (*chartInstance->c42_is_InTrial == c42_IN_Running);
  chartInstance->c42_JITStateAnimation[1U] = (uint8_T)
    (*chartInstance->c42_is_InTrial == c42_IN_SkipTrial);
  chartInstance->c42_JITStateAnimation[2U] = (uint8_T)
    (*chartInstance->c42_is_c42_General == c42_IN_PausedBetweenTrials);
  chartInstance->c42_JITStateAnimation[3U] = (uint8_T)
    (*chartInstance->c42_is_c42_General == c42_IN_Finished);
  chartInstance->c42_JITStateAnimation[4U] = (uint8_T)
    (*chartInstance->c42_is_c42_General == c42_IN_PausedBetweenBlocks);
  chartInstance->c42_JITStateAnimation[5U] = (uint8_T)
    (*chartInstance->c42_is_InTrial == c42_IN_Paused);
  chartInstance->c42_JITStateAnimation[6U] = (uint8_T)
    (*chartInstance->c42_is_InTrial == c42_IN_RepeatTrialLater);
  chartInstance->c42_JITStateAnimation[7U] = (uint8_T)
    (*chartInstance->c42_is_c42_General == c42_IN_InTrial);
  chartInstance->c42_JITStateAnimation[8U] = (uint8_T)
    (*chartInstance->c42_is_InTrial == c42_IN_RepeatTrialNow);
  chartInstance->c42_JITStateAnimation[9U] = (uint8_T)
    (*chartInstance->c42_is_c42_General == c42_IN_Ready);
  chartInstance->c42_JITStateAnimation[10U] = (uint8_T)
    (*chartInstance->c42_is_c42_General == c42_IN_PausedBetweenTrials1);
  chartInstance->c42_JITStateAnimation[11U] = (uint8_T)
    (*chartInstance->c42_is_c42_General == c42_IN_InTrial1);
  chartInstance->c42_JITStateAnimation[12U] = (uint8_T)
    (*chartInstance->c42_is_InTrial1 == c42_IN_RepeatTrialLater1);
  chartInstance->c42_JITStateAnimation[13U] = (uint8_T)
    (*chartInstance->c42_is_InTrial1 == c42_IN_Paused1);
  chartInstance->c42_JITStateAnimation[14U] = (uint8_T)
    (*chartInstance->c42_is_InTrial1 == c42_IN_Running1);
  chartInstance->c42_JITStateAnimation[15U] = (uint8_T)
    (*chartInstance->c42_is_InTrial1 == c42_IN_RepeatTrialNow1);
  chartInstance->c42_JITStateAnimation[16U] = (uint8_T)
    (*chartInstance->c42_is_InTrial1 == c42_IN_SkipTrial1);
  chartInstance->c42_JITStateAnimation[17U] = (uint8_T)
    (*chartInstance->c42_is_c42_General == c42_IN_Finished1);
}

static void c42_do_animation_call_c42_General(SFc42_GeneralInstanceStruct
  *chartInstance)
{
  sfDoAnimationWrapper(chartInstance->S, false, true);
  sfDoAnimationWrapper(chartInstance->S, false, false);
}

static void ext_mode_exec_c42_General(SFc42_GeneralInstanceStruct *chartInstance)
{
  c42_update_jit_animation_state_c42_General(chartInstance);
  c42_do_animation_call_c42_General(chartInstance);
}

static const mxArray *get_sim_state_c42_General(SFc42_GeneralInstanceStruct
  *chartInstance)
{
  const mxArray *c42_st;
  const mxArray *c42_y = NULL;
  const mxArray *c42_b_y = NULL;
  const mxArray *c42_c_y = NULL;
  const mxArray *c42_d_y = NULL;
  const mxArray *c42_e_y = NULL;
  const mxArray *c42_f_y = NULL;
  const mxArray *c42_g_y = NULL;
  const mxArray *c42_h_y = NULL;
  const mxArray *c42_i_y = NULL;
  const mxArray *c42_j_y = NULL;
  const mxArray *c42_k_y = NULL;
  const mxArray *c42_l_y = NULL;
  const mxArray *c42_m_y = NULL;
  const mxArray *c42_n_y = NULL;
  const mxArray *c42_o_y = NULL;
  const mxArray *c42_p_y = NULL;
  const mxArray *c42_q_y = NULL;
  const mxArray *c42_r_y = NULL;
  const mxArray *c42_s_y = NULL;
  const mxArray *c42_t_y = NULL;
  const mxArray *c42_u_y = NULL;
  const mxArray *c42_v_y = NULL;
  const mxArray *c42_w_y = NULL;
  const mxArray *c42_x_y = NULL;
  const mxArray *c42_y_y = NULL;
  const mxArray *c42_ab_y = NULL;
  const mxArray *c42_bb_y = NULL;
  c42_st = NULL;
  c42_st = NULL;
  c42_y = NULL;
  sf_mex_assign(&c42_y, sf_mex_createcellmatrix(26, 1), false);
  c42_b_y = NULL;
  sf_mex_assign(&c42_b_y, sf_mex_create("y", chartInstance->c42_block_idx, 7, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 0, c42_b_y);
  c42_c_y = NULL;
  sf_mex_assign(&c42_c_y, sf_mex_create("y", chartInstance->c42_block_in_set, 7,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 1, c42_c_y);
  c42_d_y = NULL;
  sf_mex_assign(&c42_d_y, sf_mex_create("y", *chartInstance->c42_extra_trials, 0,
    0U, 1U, 0U, 1, 2), false);
  sf_mex_setcell(c42_y, 2, c42_d_y);
  c42_e_y = NULL;
  sf_mex_assign(&c42_e_y, sf_mex_create("y",
    chartInstance->c42_repeat_last_trial, 0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 3, c42_e_y);
  c42_f_y = NULL;
  sf_mex_assign(&c42_f_y, sf_mex_create("y", chartInstance->c42_task_status, 7,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 4, c42_f_y);
  c42_g_y = NULL;
  sf_mex_assign(&c42_g_y, sf_mex_create("y", chartInstance->c42_tp, 7, 0U, 0U,
    0U, 0), false);
  sf_mex_setcell(c42_y, 5, c42_g_y);
  c42_h_y = NULL;
  sf_mex_assign(&c42_h_y, sf_mex_create("y", chartInstance->c42_trial_in_block,
    7, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 6, c42_h_y);
  c42_i_y = NULL;
  sf_mex_assign(&c42_i_y, sf_mex_create("y", chartInstance->c42_trial_in_set, 7,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 7, c42_i_y);
  c42_j_y = NULL;
  sf_mex_assign(&c42_j_y, sf_mex_create("y", chartInstance->c42_BLOCK, 0, 0U, 0U,
    0U, 0), false);
  sf_mex_setcell(c42_y, 8, c42_j_y);
  c42_k_y = NULL;
  sf_mex_assign(&c42_k_y, sf_mex_create("y", chartInstance->c42_EXAM, 0, 0U, 0U,
    0U, 0), false);
  sf_mex_setcell(c42_y, 9, c42_k_y);
  c42_l_y = NULL;
  sf_mex_assign(&c42_l_y, sf_mex_create("y", chartInstance->c42_block, 0, 0U, 0U,
    0U, 0), false);
  sf_mex_setcell(c42_y, 10, c42_l_y);
  c42_m_y = NULL;
  sf_mex_assign(&c42_m_y, sf_mex_create("y", chartInstance->c42_i, 7, 0U, 0U, 0U,
    0), false);
  sf_mex_setcell(c42_y, 11, c42_m_y);
  c42_n_y = NULL;
  sf_mex_assign(&c42_n_y, sf_mex_create("y", *chartInstance->c42_repeat_list, 0,
    0U, 1U, 0U, 1, 499), false);
  sf_mex_setcell(c42_y, 12, c42_n_y);
  c42_o_y = NULL;
  sf_mex_assign(&c42_o_y, sf_mex_create("y",
    chartInstance->c42_repeat_list_length, 7, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 13, c42_o_y);
  c42_p_y = NULL;
  sf_mex_assign(&c42_p_y, sf_mex_create("y", chartInstance->c42_swap_index, 7,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 14, c42_p_y);
  c42_q_y = NULL;
  sf_mex_assign(&c42_q_y, sf_mex_create("y", chartInstance->c42_temp, 7, 0U, 0U,
    0U, 0), false);
  sf_mex_setcell(c42_y, 15, c42_q_y);
  c42_r_y = NULL;
  sf_mex_assign(&c42_r_y, sf_mex_create("y",
    chartInstance->c42_trial_in_mini_block, 7, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 16, c42_r_y);
  c42_s_y = NULL;
  sf_mex_assign(&c42_s_y, sf_mex_create("y", *chartInstance->c42_trial_queue, 0,
    0U, 1U, 0U, 1, 499), false);
  sf_mex_setcell(c42_y, 17, c42_s_y);
  c42_t_y = NULL;
  sf_mex_assign(&c42_t_y, sf_mex_create("y",
    chartInstance->c42_trial_queue_length, 7, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 18, c42_t_y);
  c42_u_y = NULL;
  sf_mex_assign(&c42_u_y, sf_mex_create("y", chartInstance->c42_e_exit_trial, 11,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 19, c42_u_y);
  c42_v_y = NULL;
  sf_mex_assign(&c42_v_y, sf_mex_create("y",
    chartInstance->c42_e_exit_trialEventCounter, 7, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 20, c42_v_y);
  c42_w_y = NULL;
  sf_mex_assign(&c42_w_y, sf_mex_create("y",
    chartInstance->c42_is_active_c42_General, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 21, c42_w_y);
  c42_x_y = NULL;
  sf_mex_assign(&c42_x_y, sf_mex_create("y", chartInstance->c42_is_c42_General,
    3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 22, c42_x_y);
  c42_y_y = NULL;
  sf_mex_assign(&c42_y_y, sf_mex_create("y", chartInstance->c42_is_InTrial, 3,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 23, c42_y_y);
  c42_ab_y = NULL;
  sf_mex_assign(&c42_ab_y, sf_mex_create("y", chartInstance->c42_is_InTrial1, 3,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 24, c42_ab_y);
  c42_bb_y = NULL;
  sf_mex_assign(&c42_bb_y, sf_mex_create("y",
    chartInstance->c42_temporalCounter_i1, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c42_y, 25, c42_bb_y);
  sf_mex_assign(&c42_st, c42_y, false);
  return c42_st;
}

static void set_sim_state_c42_General(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_st)
{
  const mxArray *c42_u;
  c42_u = sf_mex_dup(c42_st);
  *chartInstance->c42_block_idx = c42_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c42_u, 0)), "block_idx");
  *chartInstance->c42_block_in_set = c42_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 1)), "block_in_set");
  c42_c_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c42_u, 2)),
    "extra_trials", *chartInstance->c42_extra_trials);
  *chartInstance->c42_repeat_last_trial = c42_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 3)), "repeat_last_trial");
  *chartInstance->c42_task_status = c42_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 4)), "task_status");
  *chartInstance->c42_tp = c42_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c42_u, 5)), "tp");
  *chartInstance->c42_trial_in_block = c42_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 6)), "trial_in_block");
  *chartInstance->c42_trial_in_set = c42_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 7)), "trial_in_set");
  *chartInstance->c42_BLOCK = c42_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c42_u, 8)), "BLOCK");
  *chartInstance->c42_EXAM = c42_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c42_u, 9)), "EXAM");
  *chartInstance->c42_block = c42_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c42_u, 10)), "block");
  *chartInstance->c42_i = c42_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c42_u, 11)), "i");
  c42_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c42_u, 12)),
    "repeat_list", *chartInstance->c42_repeat_list);
  *chartInstance->c42_repeat_list_length = c42_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 13)), "repeat_list_length");
  *chartInstance->c42_swap_index = c42_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 14)), "swap_index");
  *chartInstance->c42_temp = c42_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c42_u, 15)), "temp");
  *chartInstance->c42_trial_in_mini_block = c42_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 16)), "trial_in_mini_block");
  c42_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c42_u, 17)),
    "trial_queue", *chartInstance->c42_trial_queue);
  *chartInstance->c42_trial_queue_length = c42_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 18)), "trial_queue_length");
  *chartInstance->c42_e_exit_trial = c42_i_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 19)), "e_exit_trial");
  *chartInstance->c42_e_exit_trialEventCounter = c42_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c42_u, 20)),
     "e_exit_trialEventCounter");
  *chartInstance->c42_is_active_c42_General = c42_k_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c42_u, 21)),
     "is_active_c42_General");
  *chartInstance->c42_is_c42_General = c42_k_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 22)), "is_c42_General");
  *chartInstance->c42_is_InTrial = c42_k_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 23)), "is_InTrial");
  *chartInstance->c42_is_InTrial1 = c42_k_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 24)), "is_InTrial1");
  *chartInstance->c42_temporalCounter_i1 = c42_k_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c42_u, 25)), "temporalCounter_i1");
  sf_mex_assign(&chartInstance->c42_setSimStateSideEffectsInfo,
                c42_m_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c42_u, 26)), "setSimStateSideEffectsInfo"), true);
  sf_mex_destroy(&c42_u);
  chartInstance->c42_doSetSimStateSideEffects = 1U;
  c42_update_jit_animation_state_c42_General(chartInstance);
  sf_mex_destroy(&c42_st);
}

static void c42_set_sim_state_side_effects_c42_General
  (SFc42_GeneralInstanceStruct *chartInstance)
{
  if (chartInstance->c42_doSetSimStateSideEffects != 0) {
    if ((*chartInstance->c42_is_c42_General == c42_IN_PausedBetweenTrials1) &&
        (sf_mex_sub(chartInstance->c42_setSimStateSideEffectsInfo,
                    "setSimStateSideEffectsInfo", 1, 18) == 0.0)) {
      *chartInstance->c42_temporalCounter_i1 = 0U;
    }

    chartInstance->c42_doSetSimStateSideEffects = 0U;
  }
}

static void finalize_c42_General(SFc42_GeneralInstanceStruct *chartInstance)
{
  sf_mex_destroy(&chartInstance->c42_setSimStateSideEffectsInfo);
}

static void sf_gateway_c42_General(SFc42_GeneralInstanceStruct *chartInstance)
{
  int32_T c42_inputEventFiredFlag;
  c42_set_sim_state_side_effects_c42_General(chartInstance);
  chartInstance->c42_JITTransitionAnimation[0] = 0U;
  chartInstance->c42_JITTransitionAnimation[1] = 0U;
  chartInstance->c42_JITTransitionAnimation[2] = 0U;
  chartInstance->c42_JITTransitionAnimation[3] = 0U;
  chartInstance->c42_JITTransitionAnimation[4] = 0U;
  chartInstance->c42_JITTransitionAnimation[5] = 0U;
  chartInstance->c42_JITTransitionAnimation[6] = 0U;
  chartInstance->c42_JITTransitionAnimation[7] = 0U;
  chartInstance->c42_JITTransitionAnimation[8] = 0U;
  chartInstance->c42_JITTransitionAnimation[9] = 0U;
  chartInstance->c42_JITTransitionAnimation[10] = 0U;
  chartInstance->c42_JITTransitionAnimation[11] = 0U;
  chartInstance->c42_JITTransitionAnimation[12] = 0U;
  chartInstance->c42_JITTransitionAnimation[13] = 0U;
  chartInstance->c42_JITTransitionAnimation[14] = 0U;
  chartInstance->c42_JITTransitionAnimation[15] = 0U;
  chartInstance->c42_JITTransitionAnimation[16] = 0U;
  chartInstance->c42_JITTransitionAnimation[17] = 0U;
  chartInstance->c42_JITTransitionAnimation[18] = 0U;
  chartInstance->c42_JITTransitionAnimation[19] = 0U;
  chartInstance->c42_JITTransitionAnimation[20] = 0U;
  chartInstance->c42_JITTransitionAnimation[21] = 0U;
  chartInstance->c42_JITTransitionAnimation[22] = 0U;
  chartInstance->c42_JITTransitionAnimation[23] = 0U;
  chartInstance->c42_JITTransitionAnimation[24] = 0U;
  chartInstance->c42_JITTransitionAnimation[25] = 0U;
  chartInstance->c42_JITTransitionAnimation[26] = 0U;
  chartInstance->c42_JITTransitionAnimation[27] = 0U;
  chartInstance->c42_JITTransitionAnimation[28] = 0U;
  chartInstance->c42_JITTransitionAnimation[29] = 0U;
  chartInstance->c42_JITTransitionAnimation[30] = 0U;
  chartInstance->c42_JITTransitionAnimation[31] = 0U;
  chartInstance->c42_JITTransitionAnimation[32] = 0U;
  chartInstance->c42_JITTransitionAnimation[33] = 0U;
  chartInstance->c42_JITTransitionAnimation[34] = 0U;
  chartInstance->c42_JITTransitionAnimation[35] = 0U;
  chartInstance->c42_JITTransitionAnimation[36] = 0U;
  chartInstance->c42_JITTransitionAnimation[37] = 0U;
  chartInstance->c42_JITTransitionAnimation[38] = 0U;
  chartInstance->c42_JITTransitionAnimation[39] = 0U;
  chartInstance->c42_JITTransitionAnimation[40] = 0U;
  chartInstance->c42_JITTransitionAnimation[41] = 0U;
  chartInstance->c42_JITTransitionAnimation[42] = 0U;
  chartInstance->c42_JITTransitionAnimation[43] = 0U;
  chartInstance->c42_JITTransitionAnimation[44] = 0U;
  chartInstance->c42_JITTransitionAnimation[45] = 0U;
  chartInstance->c42_JITTransitionAnimation[46] = 0U;
  chartInstance->c42_JITTransitionAnimation[47] = 0U;
  chartInstance->c42_JITTransitionAnimation[48] = 0U;
  chartInstance->c42_JITTransitionAnimation[49] = 0U;
  chartInstance->c42_JITTransitionAnimation[50] = 0U;
  chartInstance->c42_JITTransitionAnimation[51] = 0U;
  chartInstance->c42_JITTransitionAnimation[52] = 0U;
  chartInstance->c42_JITTransitionAnimation[53] = 0U;
  chartInstance->c42_JITTransitionAnimation[54] = 0U;
  chartInstance->c42_JITTransitionAnimation[55] = 0U;
  chartInstance->c42_JITTransitionAnimation[56] = 0U;
  chartInstance->c42_JITTransitionAnimation[57] = 0U;
  chartInstance->c42_JITTransitionAnimation[58] = 0U;
  chartInstance->c42_JITTransitionAnimation[59] = 0U;
  chartInstance->c42_JITTransitionAnimation[60] = 0U;
  chartInstance->c42_JITTransitionAnimation[61] = 0U;
  chartInstance->c42_JITTransitionAnimation[62] = 0U;
  chartInstance->c42_JITTransitionAnimation[63] = 0U;
  chartInstance->c42_JITTransitionAnimation[64] = 0U;
  chartInstance->c42_JITTransitionAnimation[65] = 0U;
  chartInstance->c42_JITTransitionAnimation[66] = 0U;
  chartInstance->c42_JITTransitionAnimation[67] = 0U;
  chartInstance->c42_JITTransitionAnimation[68] = 0U;
  chartInstance->c42_JITTransitionAnimation[69] = 0U;
  chartInstance->c42_JITTransitionAnimation[70] = 0U;
  chartInstance->c42_JITTransitionAnimation[71] = 0U;
  chartInstance->c42_JITTransitionAnimation[72] = 0U;
  _sfTime_ = sf_get_time(chartInstance->S);
  c42_inputEventFiredFlag = 0;
  if (*chartInstance->c42_e_clk != 0) {
    c42_inputEventFiredFlag = 1;
    if (*chartInstance->c42_temporalCounter_i1 < 3U) {
      *chartInstance->c42_temporalCounter_i1 = c42__u8_u32_(chartInstance,
        (uint32_T)*chartInstance->c42_temporalCounter_i1 + 1U, 0, 0U, 0, 0);
    }

    *chartInstance->c42_sfEvent = c42_event_e_clk;
    c42_chartstep_c42_General(chartInstance);
  }

  if (*chartInstance->c42_e_trial_over != 0) {
    c42_inputEventFiredFlag = 1;
    *chartInstance->c42_sfEvent = c42_event_e_trial_over;
    c42_chartstep_c42_General(chartInstance);
  }

  if ((c42_inputEventFiredFlag != 0) &&
      (*chartInstance->c42_e_exit_trialEventCounter > 0U)) {
    *chartInstance->c42_e_exit_trial = !*chartInstance->c42_e_exit_trial;
    (*chartInstance->c42_e_exit_trialEventCounter)--;
  }

  c42_update_jit_animation_state_c42_General(chartInstance);
  c42_do_animation_call_c42_General(chartInstance);
}

static void mdl_start_c42_General(SFc42_GeneralInstanceStruct *chartInstance)
{
  setLegacyDebuggerFlag(chartInstance->S, false);
  setDebuggerFlag(chartInstance->S, true);
  sim_mode_is_external(chartInstance->S);
}

static void c42_chartstep_c42_General(SFc42_GeneralInstanceStruct *chartInstance)
{
  boolean_T c42_b_temp;
  real_T c42_d;
  if (*chartInstance->c42_is_active_c42_General == 0U) {
    *chartInstance->c42_is_active_c42_General = 1U;
    chartInstance->c42_JITTransitionAnimation[43U] = 1U;
    *chartInstance->c42_is_c42_General = c42_IN_Ready;
    *chartInstance->c42_task_status = 1U;
    *chartInstance->c42_tp = 0U;
    *chartInstance->c42_block = 0.0;
    *chartInstance->c42_trial_in_block = 0U;
    *chartInstance->c42_block_in_set = 0U;
    *chartInstance->c42_trial_in_set = 0U;
    *chartInstance->c42_trial_in_mini_block = 0U;
    (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
      chartInstance->S, 57U, 0, 0, 28U, c42__s32_d_(chartInstance,
      *chartInstance->c42_EXAM - 1.0, 0, 10U, 147, 4), 1, 2)] = 0.0;
    (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
      chartInstance->S, 57U, 0, 0, 28U, c42__s32_d_(chartInstance,
      *chartInstance->c42_BLOCK - 1.0, 0, 10U, 171, 5), 1, 2)] = 0.0;
    c42_d = (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
      chartInstance->S, 10U, 158, 12, 28U, c42__s32_d_(chartInstance,
      *chartInstance->c42_BLOCK - 1.0, 0, 10U, 158, 12), 1, 2)];
    sf_mex_printf("%s =\\n", "extra_trials[BLOCK]");
    sf_mex_call(chartInstance->c42_fEmlrtCtx, "disp", 0U, 1U, 6, c42_d);
  } else {
    switch (*chartInstance->c42_is_c42_General) {
     case c42_IN_Finished:
      *chartInstance->c42_task_status = 4U;
      break;

     case c42_IN_Finished1:
      *chartInstance->c42_task_status = 4U;
      break;

     case c42_IN_InTrial:
      c42_InTrial(chartInstance);
      break;

     case c42_IN_InTrial1:
      if (*chartInstance->c42_sfEvent == c42_event_e_trial_over) {
        chartInstance->c42_JITTransitionAnimation[71U] = 1U;
        *chartInstance->c42_is_InTrial1 = c42_IN_NO_ACTIVE_CHILD;
        *chartInstance->c42_is_InTrial1 = c42_IN_NO_ACTIVE_CHILD;
        *chartInstance->c42_is_InTrial1 = c42_IN_NO_ACTIVE_CHILD;
        *chartInstance->c42_is_InTrial1 = c42_IN_NO_ACTIVE_CHILD;
        *chartInstance->c42_is_InTrial1 = c42_IN_NO_ACTIVE_CHILD;
        *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
        *chartInstance->c42_is_c42_General = c42_IN_PausedBetweenTrials1;
        *chartInstance->c42_temporalCounter_i1 = 0U;
        *chartInstance->c42_task_status = 3U;
      } else {
        switch (*chartInstance->c42_is_InTrial1) {
         case c42_IN_Paused1:
          *chartInstance->c42_task_status = 3U;
          if (*chartInstance->c42_run_command == 1) {
            chartInstance->c42_JITTransitionAnimation[65U] = 1U;
            *chartInstance->c42_is_InTrial1 = c42_IN_NO_ACTIVE_CHILD;
            *chartInstance->c42_is_InTrial1 = c42_IN_Running1;
            *chartInstance->c42_task_status = 2U;
          }
          break;

         case c42_IN_RepeatTrialLater1:
         case c42_IN_RepeatTrialNow1:
         case c42_IN_SkipTrial1:
          break;

         case c42_IN_Running1:
          *chartInstance->c42_task_status = 2U;
          c42_b_temp = (*chartInstance->c42_run_command != 1);
          if (c42_b_temp) {
            c42_b_temp = (*chartInstance->c42_pause_type > 0.0);
          }

          if (c42_b_temp) {
            chartInstance->c42_JITTransitionAnimation[70U] = 1U;
            if (*chartInstance->c42_pause_type == 1.0) {
              chartInstance->c42_JITTransitionAnimation[63U] = 1U;
              *chartInstance->c42_is_InTrial1 = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_InTrial1 = c42_IN_SkipTrial1;
              *chartInstance->c42_e_exit_trialEventCounter = c42__u32_add__
                (chartInstance, *chartInstance->c42_e_exit_trialEventCounter, 1U,
                 0, 165U, 19, 12);
            } else {
              chartInstance->c42_JITTransitionAnimation[67U] = 1U;
              if (*chartInstance->c42_pause_type == 2.0) {
                chartInstance->c42_JITTransitionAnimation[66U] = 1U;
                *chartInstance->c42_is_InTrial1 = c42_IN_NO_ACTIVE_CHILD;
                *chartInstance->c42_is_InTrial1 = c42_IN_RepeatTrialNow1;
                *chartInstance->c42_e_exit_trialEventCounter = c42__u32_add__
                  (chartInstance, *chartInstance->c42_e_exit_trialEventCounter,
                   1U, 0, 163U, 24, 12);
              } else {
                chartInstance->c42_JITTransitionAnimation[61U] = 1U;
                if (*chartInstance->c42_pause_type == 3.0) {
                  chartInstance->c42_JITTransitionAnimation[68U] = 1U;
                  *chartInstance->c42_is_InTrial1 = c42_IN_NO_ACTIVE_CHILD;
                  *chartInstance->c42_is_InTrial1 = c42_IN_RepeatTrialLater1;
                  *chartInstance->c42_e_exit_trialEventCounter = c42__u32_add__
                    (chartInstance, *chartInstance->c42_e_exit_trialEventCounter,
                     1U, 0, 156U, 26, 12);
                } else {
                  chartInstance->c42_JITTransitionAnimation[69U] = 1U;
                  chartInstance->c42_JITTransitionAnimation[64U] = 1U;
                  *chartInstance->c42_is_InTrial1 = c42_IN_NO_ACTIVE_CHILD;
                  *chartInstance->c42_is_InTrial1 = c42_IN_Paused1;
                  *chartInstance->c42_task_status = 3U;
                }
              }
            }
          }
          break;

         default:
          /* Unreachable state, for coverage only */
          *chartInstance->c42_is_InTrial1 = c42_IN_NO_ACTIVE_CHILD;
          break;
        }
      }
      break;

     case c42_IN_PausedBetweenBlocks:
      c42_PausedBetweenBlocks(chartInstance);
      break;

     case c42_IN_PausedBetweenTrials:
      *chartInstance->c42_task_status = 3U;
      if (*chartInstance->c42_run_command == 1) {
        chartInstance->c42_JITTransitionAnimation[19U] = 1U;
        *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
        *chartInstance->c42_is_c42_General = c42_IN_InTrial;
        *chartInstance->c42_trial_in_set = c42__u32_add__(chartInstance,
          *chartInstance->c42_trial_in_set, 1U, 0, 8U, 16, 14);
        *chartInstance->c42_trial_in_block = c42__u32_add__(chartInstance,
          *chartInstance->c42_trial_in_block, 1U, 0, 8U, 32, 16);
        *chartInstance->c42_trial_in_mini_block = c42__u32_add__(chartInstance, *
          chartInstance->c42_trial_in_mini_block, 1U, 0, 8U, 51, 21);
        *chartInstance->c42_tp = c42__u32_d_(chartInstance,
          (*chartInstance->c42_trial_queue)[(uint32_T)sf_array_bounds_check(NULL,
          chartInstance->S, 8U, 80, 11, 9U, (int32_T)c42__u32_minus__
          (chartInstance, *chartInstance->c42_trial_in_mini_block, 1U, 0, 8U, 80,
           11), 1, 499)], 0, 8U, 80, 11);
        chartInstance->c42_JITTransitionAnimation[33U] = 1U;
        *chartInstance->c42_is_InTrial = c42_IN_Running;
        *chartInstance->c42_task_status = 2U;
      }
      break;

     case c42_IN_PausedBetweenTrials1:
      *chartInstance->c42_task_status = 3U;
      if (*chartInstance->c42_next_custom_tp < 1.0) {
        chartInstance->c42_JITTransitionAnimation[72U] = 1U;
        *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
        *chartInstance->c42_is_c42_General = c42_IN_Finished1;
        *chartInstance->c42_task_status = 4U;
      } else {
        c42_b_temp = (*chartInstance->c42_temporalCounter_i1 >= 2);
        if (c42_b_temp) {
          c42_b_temp = (*chartInstance->c42_run_command == 1);
        }

        if (c42_b_temp) {
          chartInstance->c42_JITTransitionAnimation[59U] = 1U;
          *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
          *chartInstance->c42_is_c42_General = c42_IN_InTrial1;
          *chartInstance->c42_trial_in_set = c42__u32_add__(chartInstance,
            *chartInstance->c42_trial_in_set, 1U, 0, 149U, 17, 14);
          *chartInstance->c42_trial_in_block = c42__u32_add__(chartInstance,
            *chartInstance->c42_trial_in_block, 1U, 0, 149U, 33, 16);
          *chartInstance->c42_tp = c42__u32_d_(chartInstance,
            *chartInstance->c42_next_custom_tp, 0, 149U, 58, 14);
          chartInstance->c42_JITTransitionAnimation[62U] = 1U;
          *chartInstance->c42_is_InTrial1 = c42_IN_Running1;
          *chartInstance->c42_task_status = 2U;
        }
      }
      break;

     case c42_IN_Ready:
      c42_Ready(chartInstance);
      break;

     default:
      /* Unreachable state, for coverage only */
      *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
      break;
    }
  }
}

static void initSimStructsc42_General(SFc42_GeneralInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c42_Ready(SFc42_GeneralInstanceStruct *chartInstance)
{
  int32_T c42_exitg1;
  int32_T c42_exitg2;
  boolean_T c42_b_temp;
  *chartInstance->c42_task_status = 1U;
  if (*chartInstance->c42_run_command == 1) {
    chartInstance->c42_JITTransitionAnimation[27U] = 1U;
    srand(*chartInstance->c42_seed);
    if (*chartInstance->c42_is_custom_tp_sequence == 1.0) {
      chartInstance->c42_JITTransitionAnimation[57U] = 1U;
      chartInstance->c42_JITTransitionAnimation[58U] = 1U;
      *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_c42_General = c42_IN_PausedBetweenTrials1;
      *chartInstance->c42_temporalCounter_i1 = 0U;
      *chartInstance->c42_task_status = 3U;
    } else {
      chartInstance->c42_JITTransitionAnimation[16U] = 1U;
      do {
        c42_exitg1 = 0;
        chartInstance->c42_JITTransitionAnimation[41U] = 1U;
        chartInstance->c42_JITTransitionAnimation[36U] = 1U;
        *chartInstance->c42_i = 1U;
        *chartInstance->c42_temp = c42__u32_d_(chartInstance,
          (*chartInstance->c42_task_protocol_block_sequence)[1000], 0, 50U, 16,
          28);
        do {
          c42_exitg2 = 0;
          chartInstance->c42_JITTransitionAnimation[15U] = 1U;
          if ((*chartInstance->c42_temp <= *chartInstance->c42_block_in_set) &&
              (*chartInstance->c42_i <
               *chartInstance->c42_task_protocol_block_sequence_length)) {
            chartInstance->c42_JITTransitionAnimation[13U] = 1U;
            *chartInstance->c42_i = c42__u32_add__(chartInstance,
              *chartInstance->c42_i, 1U, 0, 25U, 73, 3);
            *chartInstance->c42_temp = c42__u32_d_(chartInstance, (real_T)
              *chartInstance->c42_temp +
              (*chartInstance->c42_task_protocol_block_sequence)[1000 +
              sf_array_bounds_check(NULL, chartInstance->S, 25U, 92, 28, 17U,
              (int32_T)c42__u32_minus__(chartInstance, *chartInstance->c42_i, 1U,
              0, 25U, 92, 28), 1, 1000)], 0, 25U, 90, 1);
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          } else {
            c42_exitg2 = 1;
          }
        } while (c42_exitg2 == 0);

        chartInstance->c42_JITTransitionAnimation[1U] = 1U;
        if ((*chartInstance->c42_i ==
             *chartInstance->c42_task_protocol_block_sequence_length) &&
            (*chartInstance->c42_temp <= *chartInstance->c42_block_in_set)) {
          chartInstance->c42_JITTransitionAnimation[29U] = 1U;
          *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
          *chartInstance->c42_is_c42_General = c42_IN_Finished;
          *chartInstance->c42_task_status = 4U;
          c42_exitg1 = 1;
        } else {
          chartInstance->c42_JITTransitionAnimation[20U] = 1U;
          *chartInstance->c42_block =
            (*chartInstance->c42_task_protocol_block_sequence)[(uint32_T)
            sf_array_bounds_check(NULL, chartInstance->S, 32U, 65, 28, 17U,
            (int32_T)c42__u32_minus__(chartInstance, *chartInstance->c42_i, 1U,
            0, 32U, 65, 28), 1, 1000)];
          *chartInstance->c42_block_idx = c42__u32_d_(chartInstance,
            (*chartInstance->c42_task_protocol_block_sequence)[2000 +
            sf_array_bounds_check(NULL, chartInstance->S, 32U, 116, 28, 17U,
            (int32_T)c42__u32_minus__(chartInstance, *chartInstance->c42_i, 1U,
            0, 32U, 116, 28), 1, 1000)], 0, 32U, 116, 28);
          chartInstance->c42_JITTransitionAnimation[2U] = 1U;
          chartInstance->c42_JITTransitionAnimation[35U] = 1U;
          *chartInstance->c42_block_in_set = c42__u32_add__(chartInstance,
            *chartInstance->c42_block_in_set, 1U, 0, 49U, 2, 14);
          *chartInstance->c42_i = 1U;
          (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
            chartInstance->S, 49U, 28, 12, 28U, c42__s32_d_(chartInstance,
            *chartInstance->c42_BLOCK - 1.0, 0, 49U, 41, 5), 1, 2)] = 0.0;
          do {
            c42_exitg2 = 0;
            chartInstance->c42_JITTransitionAnimation[24U] = 1U;
            c42_b_temp = (*chartInstance->c42_i <=
                          *chartInstance->c42_trial_queue_max_length);
            if (c42_b_temp) {
              c42_b_temp = (*chartInstance->c42_block > 0.0);
            }

            if (c42_b_temp) {
              c42_b_temp = ((*chartInstance->c42_block_definitions)
                            [sf_array_bounds_check(NULL, chartInstance->S, 16U,
                115, 17, 15U, c42__s32_d_(chartInstance,
                *chartInstance->c42_block - 1.0, 0, 16U, 115, 17), 1, 50) + 50 *
                            sf_array_bounds_check(NULL, chartInstance->S, 16U,
                115, 17, 15U, (int32_T)c42__u32_minus__(chartInstance,
                c42__u32_add__(chartInstance, *chartInstance->c42_i, 1U, 0, 16U,
                               115, 17), 1U, 0, 16U, 115, 17), 1, 500)] != 0.0);
            }

            if (c42_b_temp) {
              chartInstance->c42_JITTransitionAnimation[5U] = 1U;
              (*chartInstance->c42_trial_queue)[(uint32_T)sf_array_bounds_check
                (NULL, chartInstance->S, 16U, 153, 11, 9U, (int32_T)
                 c42__u32_minus__(chartInstance, *chartInstance->c42_i, 1U, 0,
                                  16U, 153, 11), 1, 499)] =
                (*chartInstance->c42_block_definitions)[sf_array_bounds_check
                (NULL, chartInstance->S, 16U, 170, 17, 15U, c42__s32_d_
                 (chartInstance, *chartInstance->c42_block - 1.0, 0, 16U, 170,
                  17), 1, 50) + 50 * sf_array_bounds_check(NULL,
                chartInstance->S, 16U, 170, 17, 15U, (int32_T)c42__u32_minus__
                (chartInstance, c42__u32_add__(chartInstance,
                *chartInstance->c42_i, 1U, 0, 16U, 170, 17), 1U, 0, 16U, 170, 17),
                1, 500)];
              *chartInstance->c42_i = c42__u32_add__(chartInstance,
                *chartInstance->c42_i, 1U, 0, 16U, 201, 3);
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            } else {
              c42_exitg2 = 1;
            }
          } while (c42_exitg2 == 0);

          chartInstance->c42_JITTransitionAnimation[28U] = 1U;
          *chartInstance->c42_trial_queue_length = c42__u32_minus__
            (chartInstance, *chartInstance->c42_i, 1U, 0, 41U, 24, 1);
          if (*chartInstance->c42_trial_queue_length > 0U) {
            chartInstance->c42_JITTransitionAnimation[52U] = 1U;
            *chartInstance->c42_trial_in_block = 0U;
            chartInstance->c42_JITTransitionAnimation[6U] = 1U;
            *chartInstance->c42_trial_in_mini_block = 0U;
            c42_b_temp = ((*chartInstance->c42_block_definitions)
                          [sf_array_bounds_check(NULL, chartInstance->S, 18U, 62,
              17, 15U, c42__s32_d_(chartInstance, *chartInstance->c42_block -
              1.0, 0, 18U, 62, 17), 1, 50)] == 1.0);
            if (c42_b_temp) {
              chartInstance->c42_JITTransitionAnimation[7U] = 1U;
              *chartInstance->c42_i = 1U;
              do {
                c42_exitg2 = 0;
                chartInstance->c42_JITTransitionAnimation[11U] = 1U;
                if (*chartInstance->c42_i <=
                    *chartInstance->c42_trial_queue_length) {
                  chartInstance->c42_JITTransitionAnimation[12U] = 1U;
                  *chartInstance->c42_swap_index = c42__u32_d_(chartInstance,
                    muDoubleScalarRem((real_T)rand(), (real_T)
                                      *chartInstance->c42_trial_queue_length) +
                    1.0, 0, 23U, 118, 1);
                  *chartInstance->c42_temp = c42__u32_d_(chartInstance,
                    (*chartInstance->c42_trial_queue)[(uint32_T)
                    sf_array_bounds_check(NULL, chartInstance->S, 23U, 130, 11,
                    9U, (int32_T)c42__u32_minus__(chartInstance,
                    *chartInstance->c42_swap_index, 1U, 0, 23U, 130, 11), 1, 499)],
                    0, 23U, 130, 11);
                  (*chartInstance->c42_trial_queue)[(uint32_T)
                    sf_array_bounds_check(NULL, chartInstance->S, 23U, 155, 11,
                    9U, (int32_T)c42__u32_minus__(chartInstance,
                    *chartInstance->c42_swap_index, 1U, 0, 23U, 155, 11), 1, 499)]
                    = (*chartInstance->c42_trial_queue)[(uint32_T)
                    sf_array_bounds_check(NULL, chartInstance->S, 23U, 181, 11,
                    9U, (int32_T)c42__u32_minus__(chartInstance,
                    *chartInstance->c42_i, 1U, 0, 23U, 181, 11), 1, 499)];
                  (*chartInstance->c42_trial_queue)[(uint32_T)
                    sf_array_bounds_check(NULL, chartInstance->S, 23U, 197, 11,
                    9U, (int32_T)c42__u32_minus__(chartInstance,
                    *chartInstance->c42_i, 1U, 0, 23U, 209, 1), 1, 499)] =
                    (real_T)*chartInstance->c42_temp;
                  *chartInstance->c42_i = c42__u32_add__(chartInstance,
                    *chartInstance->c42_i, 1U, 0, 23U, 220, 3);
                  _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                } else {
                  c42_exitg2 = 1;
                }
              } while (c42_exitg2 == 0);

              chartInstance->c42_JITTransitionAnimation[53U] = 1U;
            } else {
              chartInstance->c42_JITTransitionAnimation[8U] = 1U;
              chartInstance->c42_JITTransitionAnimation[9U] = 1U;
            }

            chartInstance->c42_JITTransitionAnimation[10U] = 1U;
            if (*chartInstance->c42_run_command != 1) {
              chartInstance->c42_JITTransitionAnimation[54U] = 1U;
              chartInstance->c42_JITTransitionAnimation[55U] = 1U;
              *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_c42_General = c42_IN_PausedBetweenTrials;
              *chartInstance->c42_task_status = 3U;
            } else {
              chartInstance->c42_JITTransitionAnimation[56U] = 1U;
              *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_c42_General = c42_IN_InTrial;
              *chartInstance->c42_trial_in_set = c42__u32_add__(chartInstance,
                *chartInstance->c42_trial_in_set, 1U, 0, 8U, 16, 14);
              *chartInstance->c42_trial_in_block = c42__u32_add__(chartInstance,
                *chartInstance->c42_trial_in_block, 1U, 0, 8U, 32, 16);
              *chartInstance->c42_trial_in_mini_block = c42__u32_add__
                (chartInstance, *chartInstance->c42_trial_in_mini_block, 1U, 0,
                 8U, 51, 21);
              *chartInstance->c42_tp = c42__u32_d_(chartInstance,
                (*chartInstance->c42_trial_queue)[(uint32_T)
                sf_array_bounds_check(NULL, chartInstance->S, 8U, 80, 11, 9U,
                (int32_T)c42__u32_minus__(chartInstance,
                *chartInstance->c42_trial_in_mini_block, 1U, 0, 8U, 80, 11), 1,
                499)], 0, 8U, 80, 11);
              chartInstance->c42_JITTransitionAnimation[33U] = 1U;
              *chartInstance->c42_is_InTrial = c42_IN_Running;
              *chartInstance->c42_task_status = 2U;
            }

            c42_exitg1 = 1;
          } else {
            chartInstance->c42_JITTransitionAnimation[51U] = 1U;
            chartInstance->c42_JITTransitionAnimation[14U] = 1U;
            if (*chartInstance->c42_run_command == 1) {
              chartInstance->c42_JITTransitionAnimation[23U] = 1U;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            } else {
              chartInstance->c42_JITTransitionAnimation[21U] = 1U;
              *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_c42_General = c42_IN_PausedBetweenBlocks;
              *chartInstance->c42_task_status = 3U;
              c42_exitg1 = 1;
            }
          }
        }
      } while (c42_exitg1 == 0);
    }
  }
}

static void c42_PausedBetweenBlocks(SFc42_GeneralInstanceStruct *chartInstance)
{
  int32_T c42_exitg1;
  int32_T c42_exitg2;
  boolean_T c42_b_temp;
  *chartInstance->c42_task_status = 3U;
  if (*chartInstance->c42_run_command == 1) {
    chartInstance->c42_JITTransitionAnimation[22U] = 1U;
    if (*chartInstance->c42_is_custom_tp_sequence == 1.0) {
      chartInstance->c42_JITTransitionAnimation[57U] = 1U;
      chartInstance->c42_JITTransitionAnimation[58U] = 1U;
      *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_c42_General = c42_IN_PausedBetweenTrials1;
      *chartInstance->c42_temporalCounter_i1 = 0U;
      *chartInstance->c42_task_status = 3U;
    } else {
      chartInstance->c42_JITTransitionAnimation[16U] = 1U;
      do {
        c42_exitg1 = 0;
        chartInstance->c42_JITTransitionAnimation[41U] = 1U;
        chartInstance->c42_JITTransitionAnimation[36U] = 1U;
        *chartInstance->c42_i = 1U;
        *chartInstance->c42_temp = c42__u32_d_(chartInstance,
          (*chartInstance->c42_task_protocol_block_sequence)[1000], 0, 50U, 16,
          28);
        do {
          c42_exitg2 = 0;
          chartInstance->c42_JITTransitionAnimation[15U] = 1U;
          if ((*chartInstance->c42_temp <= *chartInstance->c42_block_in_set) &&
              (*chartInstance->c42_i <
               *chartInstance->c42_task_protocol_block_sequence_length)) {
            chartInstance->c42_JITTransitionAnimation[13U] = 1U;
            *chartInstance->c42_i = c42__u32_add__(chartInstance,
              *chartInstance->c42_i, 1U, 0, 25U, 73, 3);
            *chartInstance->c42_temp = c42__u32_d_(chartInstance, (real_T)
              *chartInstance->c42_temp +
              (*chartInstance->c42_task_protocol_block_sequence)[1000 +
              sf_array_bounds_check(NULL, chartInstance->S, 25U, 92, 28, 17U,
              (int32_T)c42__u32_minus__(chartInstance, *chartInstance->c42_i, 1U,
              0, 25U, 92, 28), 1, 1000)], 0, 25U, 90, 1);
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          } else {
            c42_exitg2 = 1;
          }
        } while (c42_exitg2 == 0);

        chartInstance->c42_JITTransitionAnimation[1U] = 1U;
        if ((*chartInstance->c42_i ==
             *chartInstance->c42_task_protocol_block_sequence_length) &&
            (*chartInstance->c42_temp <= *chartInstance->c42_block_in_set)) {
          chartInstance->c42_JITTransitionAnimation[29U] = 1U;
          *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
          *chartInstance->c42_is_c42_General = c42_IN_Finished;
          *chartInstance->c42_task_status = 4U;
          c42_exitg1 = 1;
        } else {
          chartInstance->c42_JITTransitionAnimation[20U] = 1U;
          *chartInstance->c42_block =
            (*chartInstance->c42_task_protocol_block_sequence)[(uint32_T)
            sf_array_bounds_check(NULL, chartInstance->S, 32U, 65, 28, 17U,
            (int32_T)c42__u32_minus__(chartInstance, *chartInstance->c42_i, 1U,
            0, 32U, 65, 28), 1, 1000)];
          *chartInstance->c42_block_idx = c42__u32_d_(chartInstance,
            (*chartInstance->c42_task_protocol_block_sequence)[2000 +
            sf_array_bounds_check(NULL, chartInstance->S, 32U, 116, 28, 17U,
            (int32_T)c42__u32_minus__(chartInstance, *chartInstance->c42_i, 1U,
            0, 32U, 116, 28), 1, 1000)], 0, 32U, 116, 28);
          chartInstance->c42_JITTransitionAnimation[2U] = 1U;
          chartInstance->c42_JITTransitionAnimation[35U] = 1U;
          *chartInstance->c42_block_in_set = c42__u32_add__(chartInstance,
            *chartInstance->c42_block_in_set, 1U, 0, 49U, 2, 14);
          *chartInstance->c42_i = 1U;
          (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
            chartInstance->S, 49U, 28, 12, 28U, c42__s32_d_(chartInstance,
            *chartInstance->c42_BLOCK - 1.0, 0, 49U, 41, 5), 1, 2)] = 0.0;
          do {
            c42_exitg2 = 0;
            chartInstance->c42_JITTransitionAnimation[24U] = 1U;
            c42_b_temp = (*chartInstance->c42_i <=
                          *chartInstance->c42_trial_queue_max_length);
            if (c42_b_temp) {
              c42_b_temp = (*chartInstance->c42_block > 0.0);
            }

            if (c42_b_temp) {
              c42_b_temp = ((*chartInstance->c42_block_definitions)
                            [sf_array_bounds_check(NULL, chartInstance->S, 16U,
                115, 17, 15U, c42__s32_d_(chartInstance,
                *chartInstance->c42_block - 1.0, 0, 16U, 115, 17), 1, 50) + 50 *
                            sf_array_bounds_check(NULL, chartInstance->S, 16U,
                115, 17, 15U, (int32_T)c42__u32_minus__(chartInstance,
                c42__u32_add__(chartInstance, *chartInstance->c42_i, 1U, 0, 16U,
                               115, 17), 1U, 0, 16U, 115, 17), 1, 500)] != 0.0);
            }

            if (c42_b_temp) {
              chartInstance->c42_JITTransitionAnimation[5U] = 1U;
              (*chartInstance->c42_trial_queue)[(uint32_T)sf_array_bounds_check
                (NULL, chartInstance->S, 16U, 153, 11, 9U, (int32_T)
                 c42__u32_minus__(chartInstance, *chartInstance->c42_i, 1U, 0,
                                  16U, 153, 11), 1, 499)] =
                (*chartInstance->c42_block_definitions)[sf_array_bounds_check
                (NULL, chartInstance->S, 16U, 170, 17, 15U, c42__s32_d_
                 (chartInstance, *chartInstance->c42_block - 1.0, 0, 16U, 170,
                  17), 1, 50) + 50 * sf_array_bounds_check(NULL,
                chartInstance->S, 16U, 170, 17, 15U, (int32_T)c42__u32_minus__
                (chartInstance, c42__u32_add__(chartInstance,
                *chartInstance->c42_i, 1U, 0, 16U, 170, 17), 1U, 0, 16U, 170, 17),
                1, 500)];
              *chartInstance->c42_i = c42__u32_add__(chartInstance,
                *chartInstance->c42_i, 1U, 0, 16U, 201, 3);
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            } else {
              c42_exitg2 = 1;
            }
          } while (c42_exitg2 == 0);

          chartInstance->c42_JITTransitionAnimation[28U] = 1U;
          *chartInstance->c42_trial_queue_length = c42__u32_minus__
            (chartInstance, *chartInstance->c42_i, 1U, 0, 41U, 24, 1);
          if (*chartInstance->c42_trial_queue_length > 0U) {
            chartInstance->c42_JITTransitionAnimation[52U] = 1U;
            *chartInstance->c42_trial_in_block = 0U;
            chartInstance->c42_JITTransitionAnimation[6U] = 1U;
            *chartInstance->c42_trial_in_mini_block = 0U;
            c42_b_temp = ((*chartInstance->c42_block_definitions)
                          [sf_array_bounds_check(NULL, chartInstance->S, 18U, 62,
              17, 15U, c42__s32_d_(chartInstance, *chartInstance->c42_block -
              1.0, 0, 18U, 62, 17), 1, 50)] == 1.0);
            if (c42_b_temp) {
              chartInstance->c42_JITTransitionAnimation[7U] = 1U;
              *chartInstance->c42_i = 1U;
              do {
                c42_exitg2 = 0;
                chartInstance->c42_JITTransitionAnimation[11U] = 1U;
                if (*chartInstance->c42_i <=
                    *chartInstance->c42_trial_queue_length) {
                  chartInstance->c42_JITTransitionAnimation[12U] = 1U;
                  *chartInstance->c42_swap_index = c42__u32_d_(chartInstance,
                    muDoubleScalarRem((real_T)rand(), (real_T)
                                      *chartInstance->c42_trial_queue_length) +
                    1.0, 0, 23U, 118, 1);
                  *chartInstance->c42_temp = c42__u32_d_(chartInstance,
                    (*chartInstance->c42_trial_queue)[(uint32_T)
                    sf_array_bounds_check(NULL, chartInstance->S, 23U, 130, 11,
                    9U, (int32_T)c42__u32_minus__(chartInstance,
                    *chartInstance->c42_swap_index, 1U, 0, 23U, 130, 11), 1, 499)],
                    0, 23U, 130, 11);
                  (*chartInstance->c42_trial_queue)[(uint32_T)
                    sf_array_bounds_check(NULL, chartInstance->S, 23U, 155, 11,
                    9U, (int32_T)c42__u32_minus__(chartInstance,
                    *chartInstance->c42_swap_index, 1U, 0, 23U, 155, 11), 1, 499)]
                    = (*chartInstance->c42_trial_queue)[(uint32_T)
                    sf_array_bounds_check(NULL, chartInstance->S, 23U, 181, 11,
                    9U, (int32_T)c42__u32_minus__(chartInstance,
                    *chartInstance->c42_i, 1U, 0, 23U, 181, 11), 1, 499)];
                  (*chartInstance->c42_trial_queue)[(uint32_T)
                    sf_array_bounds_check(NULL, chartInstance->S, 23U, 197, 11,
                    9U, (int32_T)c42__u32_minus__(chartInstance,
                    *chartInstance->c42_i, 1U, 0, 23U, 209, 1), 1, 499)] =
                    (real_T)*chartInstance->c42_temp;
                  *chartInstance->c42_i = c42__u32_add__(chartInstance,
                    *chartInstance->c42_i, 1U, 0, 23U, 220, 3);
                  _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                } else {
                  c42_exitg2 = 1;
                }
              } while (c42_exitg2 == 0);

              chartInstance->c42_JITTransitionAnimation[53U] = 1U;
            } else {
              chartInstance->c42_JITTransitionAnimation[8U] = 1U;
              chartInstance->c42_JITTransitionAnimation[9U] = 1U;
            }

            chartInstance->c42_JITTransitionAnimation[10U] = 1U;
            if (*chartInstance->c42_run_command != 1) {
              chartInstance->c42_JITTransitionAnimation[54U] = 1U;
              chartInstance->c42_JITTransitionAnimation[55U] = 1U;
              *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_c42_General = c42_IN_PausedBetweenTrials;
              *chartInstance->c42_task_status = 3U;
            } else {
              chartInstance->c42_JITTransitionAnimation[56U] = 1U;
              *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_c42_General = c42_IN_InTrial;
              *chartInstance->c42_trial_in_set = c42__u32_add__(chartInstance,
                *chartInstance->c42_trial_in_set, 1U, 0, 8U, 16, 14);
              *chartInstance->c42_trial_in_block = c42__u32_add__(chartInstance,
                *chartInstance->c42_trial_in_block, 1U, 0, 8U, 32, 16);
              *chartInstance->c42_trial_in_mini_block = c42__u32_add__
                (chartInstance, *chartInstance->c42_trial_in_mini_block, 1U, 0,
                 8U, 51, 21);
              *chartInstance->c42_tp = c42__u32_d_(chartInstance,
                (*chartInstance->c42_trial_queue)[(uint32_T)
                sf_array_bounds_check(NULL, chartInstance->S, 8U, 80, 11, 9U,
                (int32_T)c42__u32_minus__(chartInstance,
                *chartInstance->c42_trial_in_mini_block, 1U, 0, 8U, 80, 11), 1,
                499)], 0, 8U, 80, 11);
              chartInstance->c42_JITTransitionAnimation[33U] = 1U;
              *chartInstance->c42_is_InTrial = c42_IN_Running;
              *chartInstance->c42_task_status = 2U;
            }

            c42_exitg1 = 1;
          } else {
            chartInstance->c42_JITTransitionAnimation[51U] = 1U;
            chartInstance->c42_JITTransitionAnimation[14U] = 1U;
            if (*chartInstance->c42_run_command == 1) {
              chartInstance->c42_JITTransitionAnimation[23U] = 1U;
              _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
            } else {
              chartInstance->c42_JITTransitionAnimation[21U] = 1U;
              *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_c42_General = c42_IN_PausedBetweenBlocks;
              *chartInstance->c42_task_status = 3U;
              c42_exitg1 = 1;
            }
          }
        }
      } while (c42_exitg1 == 0);
    }
  }
}

static void c42_InTrial(SFc42_GeneralInstanceStruct *chartInstance)
{
  boolean_T c42_b_temp;
  boolean_T c42_guard1 = false;
  boolean_T c42_guard2 = false;
  boolean_T c42_guard3 = false;
  int32_T c42_exitg1;
  int32_T c42_b_i;
  int32_T c42_exitg2;
  if (*chartInstance->c42_sfEvent == c42_event_e_trial_over) {
    chartInstance->c42_JITTransitionAnimation[25U] = 1U;
    chartInstance->c42_JITTransitionAnimation[60U] = 1U;
    c42_b_temp = (*chartInstance->c42_run_command != 1);
    if (c42_b_temp) {
      c42_b_temp = (*chartInstance->c42_pause_type == 3.0);
    }

    c42_guard1 = false;
    if (c42_b_temp) {
      chartInstance->c42_JITTransitionAnimation[26U] = 1U;
      chartInstance->c42_JITTransitionAnimation[45U] = 1U;
      c42_guard1 = true;
    } else {
      chartInstance->c42_JITTransitionAnimation[31U] = 1U;
      c42_b_temp = (*chartInstance->c42_repeat_trial_flag > 0.0);
      if (c42_b_temp) {
        c42_b_temp = (*chartInstance->c42_run_command == 1);
        if (!c42_b_temp) {
          c42_b_temp = (*chartInstance->c42_pause_type == 0.0);
        }
      }

      if (c42_b_temp) {
        chartInstance->c42_JITTransitionAnimation[30U] = 1U;
        (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
          chartInstance->S, 43U, 239, 12, 28U, c42__s32_d_(chartInstance,
          *chartInstance->c42_EXAM - 1.0, 0, 43U, 239, 12), 1, 2)] =
          (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
          chartInstance->S, 43U, 239, 12, 28U, c42__s32_d_(chartInstance,
          *chartInstance->c42_EXAM - 1.0, 0, 43U, 239, 12), 1, 2)] + 1.0;
        (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
          chartInstance->S, 43U, 261, 12, 28U, c42__s32_d_(chartInstance,
          *chartInstance->c42_BLOCK - 1.0, 0, 43U, 261, 12), 1, 2)] =
          (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
          chartInstance->S, 43U, 261, 12, 28U, c42__s32_d_(chartInstance,
          *chartInstance->c42_BLOCK - 1.0, 0, 43U, 261, 12), 1, 2)] + 1.0;
        c42_guard1 = true;
      } else {
        chartInstance->c42_JITTransitionAnimation[46U] = 1U;
        *chartInstance->c42_repeat_last_trial = 0.0;
      }
    }

    if (c42_guard1) {
      chartInstance->c42_JITTransitionAnimation[44U] = 1U;
      chartInstance->c42_JITTransitionAnimation[32U] = 1U;
      *chartInstance->c42_repeat_list_length = c42__u32_add__(chartInstance,
        *chartInstance->c42_repeat_list_length, 1U, 0, 46U, 47, 20);
      (*chartInstance->c42_repeat_list)[(uint32_T)sf_array_bounds_check(NULL,
        chartInstance->S, 46U, 69, 11, 4U, (int32_T)c42__u32_minus__
        (chartInstance, *chartInstance->c42_repeat_list_length, 1U, 0, 46U, 81,
         18), 1, 499)] = (real_T)*chartInstance->c42_tp;
      *chartInstance->c42_repeat_last_trial = 1.0;
    }

    c42_b_temp = (*chartInstance->c42_trial_in_mini_block >=
                  *chartInstance->c42_trial_queue_length);
    c42_guard1 = false;
    c42_guard2 = false;
    c42_guard3 = false;
    if (c42_b_temp) {
      chartInstance->c42_JITTransitionAnimation[4U] = 1U;
      if (*chartInstance->c42_repeat_list_length > 0U) {
        chartInstance->c42_JITTransitionAnimation[0U] = 1U;
        *chartInstance->c42_trial_queue_length =
          *chartInstance->c42_repeat_list_length;
        for (c42_b_i = 0; c42_b_i < 499; c42_b_i++) {
          (*chartInstance->c42_trial_queue)[c42_b_i] =
            (*chartInstance->c42_repeat_list)[c42_b_i];
          (*chartInstance->c42_repeat_list)[c42_b_i] = 0.0;
        }

        *chartInstance->c42_repeat_list_length = 0U;
        c42_guard3 = true;
      } else {
        chartInstance->c42_JITTransitionAnimation[50U] = 1U;
        do {
          c42_exitg1 = 0;
          chartInstance->c42_JITTransitionAnimation[14U] = 1U;
          if (*chartInstance->c42_run_command == 1) {
            chartInstance->c42_JITTransitionAnimation[23U] = 1U;
            chartInstance->c42_JITTransitionAnimation[41U] = 1U;
            chartInstance->c42_JITTransitionAnimation[36U] = 1U;
            *chartInstance->c42_i = 1U;
            *chartInstance->c42_temp = c42__u32_d_(chartInstance,
              (*chartInstance->c42_task_protocol_block_sequence)[1000], 0, 50U,
              16, 28);
            do {
              c42_exitg2 = 0;
              chartInstance->c42_JITTransitionAnimation[15U] = 1U;
              if ((*chartInstance->c42_temp <= *chartInstance->c42_block_in_set)
                  && (*chartInstance->c42_i <
                      *chartInstance->c42_task_protocol_block_sequence_length))
              {
                chartInstance->c42_JITTransitionAnimation[13U] = 1U;
                *chartInstance->c42_i = c42__u32_add__(chartInstance,
                  *chartInstance->c42_i, 1U, 0, 25U, 73, 3);
                *chartInstance->c42_temp = c42__u32_d_(chartInstance, (real_T)
                  *chartInstance->c42_temp +
                  (*chartInstance->c42_task_protocol_block_sequence)[1000 +
                  sf_array_bounds_check(NULL, chartInstance->S, 25U, 92, 28, 17U,
                  (int32_T)c42__u32_minus__(chartInstance, *chartInstance->c42_i,
                  1U, 0, 25U, 92, 28), 1, 1000)], 0, 25U, 90, 1);
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              } else {
                c42_exitg2 = 1;
              }
            } while (c42_exitg2 == 0);

            chartInstance->c42_JITTransitionAnimation[1U] = 1U;
            if ((*chartInstance->c42_i ==
                 *chartInstance->c42_task_protocol_block_sequence_length) &&
                (*chartInstance->c42_temp <= *chartInstance->c42_block_in_set))
            {
              chartInstance->c42_JITTransitionAnimation[29U] = 1U;
              *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_c42_General = c42_IN_Finished;
              *chartInstance->c42_task_status = 4U;
              c42_exitg1 = 1;
            } else {
              chartInstance->c42_JITTransitionAnimation[20U] = 1U;
              *chartInstance->c42_block =
                (*chartInstance->c42_task_protocol_block_sequence)[(uint32_T)
                sf_array_bounds_check(NULL, chartInstance->S, 32U, 65, 28, 17U,
                (int32_T)c42__u32_minus__(chartInstance, *chartInstance->c42_i,
                1U, 0, 32U, 65, 28), 1, 1000)];
              *chartInstance->c42_block_idx = c42__u32_d_(chartInstance,
                (*chartInstance->c42_task_protocol_block_sequence)[2000 +
                sf_array_bounds_check(NULL, chartInstance->S, 32U, 116, 28, 17U,
                (int32_T)c42__u32_minus__(chartInstance, *chartInstance->c42_i,
                1U, 0, 32U, 116, 28), 1, 1000)], 0, 32U, 116, 28);
              chartInstance->c42_JITTransitionAnimation[2U] = 1U;
              chartInstance->c42_JITTransitionAnimation[35U] = 1U;
              *chartInstance->c42_block_in_set = c42__u32_add__(chartInstance,
                *chartInstance->c42_block_in_set, 1U, 0, 49U, 2, 14);
              *chartInstance->c42_i = 1U;
              (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
                chartInstance->S, 49U, 28, 12, 28U, c42__s32_d_(chartInstance,
                *chartInstance->c42_BLOCK - 1.0, 0, 49U, 41, 5), 1, 2)] = 0.0;
              do {
                c42_exitg2 = 0;
                chartInstance->c42_JITTransitionAnimation[24U] = 1U;
                c42_b_temp = (*chartInstance->c42_i <=
                              *chartInstance->c42_trial_queue_max_length);
                if (c42_b_temp) {
                  c42_b_temp = (*chartInstance->c42_block > 0.0);
                }

                if (c42_b_temp) {
                  c42_b_temp = ((*chartInstance->c42_block_definitions)
                                [sf_array_bounds_check(NULL, chartInstance->S,
                    16U, 115, 17, 15U, c42__s32_d_(chartInstance,
                    *chartInstance->c42_block - 1.0, 0, 16U, 115, 17), 1, 50) +
                                50 * sf_array_bounds_check(NULL,
                    chartInstance->S, 16U, 115, 17, 15U, (int32_T)
                    c42__u32_minus__(chartInstance, c42__u32_add__(chartInstance,
                    *chartInstance->c42_i, 1U, 0, 16U, 115, 17), 1U, 0, 16U, 115,
                                     17), 1, 500)] != 0.0);
                }

                if (c42_b_temp) {
                  chartInstance->c42_JITTransitionAnimation[5U] = 1U;
                  (*chartInstance->c42_trial_queue)[(uint32_T)
                    sf_array_bounds_check(NULL, chartInstance->S, 16U, 153, 11,
                    9U, (int32_T)c42__u32_minus__(chartInstance,
                    *chartInstance->c42_i, 1U, 0, 16U, 153, 11), 1, 499)] =
                    (*chartInstance->c42_block_definitions)
                    [sf_array_bounds_check(NULL, chartInstance->S, 16U, 170, 17,
                    15U, c42__s32_d_(chartInstance, *chartInstance->c42_block -
                                     1.0, 0, 16U, 170, 17), 1, 50) + 50 *
                    sf_array_bounds_check(NULL, chartInstance->S, 16U, 170, 17,
                    15U, (int32_T)c42__u32_minus__(chartInstance, c42__u32_add__
                    (chartInstance, *chartInstance->c42_i, 1U, 0, 16U, 170, 17),
                    1U, 0, 16U, 170, 17), 1, 500)];
                  *chartInstance->c42_i = c42__u32_add__(chartInstance,
                    *chartInstance->c42_i, 1U, 0, 16U, 201, 3);
                  _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
                } else {
                  c42_exitg2 = 1;
                }
              } while (c42_exitg2 == 0);

              chartInstance->c42_JITTransitionAnimation[28U] = 1U;
              *chartInstance->c42_trial_queue_length = c42__u32_minus__
                (chartInstance, *chartInstance->c42_i, 1U, 0, 41U, 24, 1);
              if (*chartInstance->c42_trial_queue_length > 0U) {
                chartInstance->c42_JITTransitionAnimation[52U] = 1U;
                *chartInstance->c42_trial_in_block = 0U;
                c42_guard3 = true;
                c42_exitg1 = 1;
              } else {
                chartInstance->c42_JITTransitionAnimation[51U] = 1U;
                _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
              }
            }
          } else {
            chartInstance->c42_JITTransitionAnimation[21U] = 1U;
            *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
            *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
            *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
            *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
            *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
            *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
            *chartInstance->c42_is_c42_General = c42_IN_PausedBetweenBlocks;
            *chartInstance->c42_task_status = 3U;
            c42_exitg1 = 1;
          }
        } while (c42_exitg1 == 0);
      }
    } else {
      chartInstance->c42_JITTransitionAnimation[3U] = 1U;
      if (*chartInstance->c42_run_command == 1) {
        chartInstance->c42_JITTransitionAnimation[17U] = 1U;
        c42_guard2 = true;
      } else {
        chartInstance->c42_JITTransitionAnimation[18U] = 1U;
        c42_guard1 = true;
      }
    }

    if (c42_guard3) {
      chartInstance->c42_JITTransitionAnimation[6U] = 1U;
      *chartInstance->c42_trial_in_mini_block = 0U;
      c42_b_temp = ((*chartInstance->c42_block_definitions)
                    [sf_array_bounds_check(NULL, chartInstance->S, 18U, 62, 17,
        15U, c42__s32_d_(chartInstance, *chartInstance->c42_block - 1.0, 0, 18U,
                         62, 17), 1, 50)] == 1.0);
      if (c42_b_temp) {
        chartInstance->c42_JITTransitionAnimation[7U] = 1U;
        *chartInstance->c42_i = 1U;
        do {
          c42_exitg1 = 0;
          chartInstance->c42_JITTransitionAnimation[11U] = 1U;
          if (*chartInstance->c42_i <= *chartInstance->c42_trial_queue_length) {
            chartInstance->c42_JITTransitionAnimation[12U] = 1U;
            *chartInstance->c42_swap_index = c42__u32_d_(chartInstance,
              muDoubleScalarRem((real_T)rand(), (real_T)
                                *chartInstance->c42_trial_queue_length) + 1.0, 0,
              23U, 118, 1);
            *chartInstance->c42_temp = c42__u32_d_(chartInstance,
              (*chartInstance->c42_trial_queue)[(uint32_T)sf_array_bounds_check
              (NULL, chartInstance->S, 23U, 130, 11, 9U, (int32_T)
               c42__u32_minus__(chartInstance, *chartInstance->c42_swap_index,
                                1U, 0, 23U, 130, 11), 1, 499)], 0, 23U, 130, 11);
            (*chartInstance->c42_trial_queue)[(uint32_T)sf_array_bounds_check
              (NULL, chartInstance->S, 23U, 155, 11, 9U, (int32_T)
               c42__u32_minus__(chartInstance, *chartInstance->c42_swap_index,
                                1U, 0, 23U, 155, 11), 1, 499)] =
              (*chartInstance->c42_trial_queue)[(uint32_T)sf_array_bounds_check
              (NULL, chartInstance->S, 23U, 181, 11, 9U, (int32_T)
               c42__u32_minus__(chartInstance, *chartInstance->c42_i, 1U, 0, 23U,
                                181, 11), 1, 499)];
            (*chartInstance->c42_trial_queue)[(uint32_T)sf_array_bounds_check
              (NULL, chartInstance->S, 23U, 197, 11, 9U, (int32_T)
               c42__u32_minus__(chartInstance, *chartInstance->c42_i, 1U, 0, 23U,
                                209, 1), 1, 499)] = (real_T)
              *chartInstance->c42_temp;
            *chartInstance->c42_i = c42__u32_add__(chartInstance,
              *chartInstance->c42_i, 1U, 0, 23U, 220, 3);
            _SF_MEX_LISTEN_FOR_CTRL_C(chartInstance->S);
          } else {
            c42_exitg1 = 1;
          }
        } while (c42_exitg1 == 0);

        chartInstance->c42_JITTransitionAnimation[53U] = 1U;
      } else {
        chartInstance->c42_JITTransitionAnimation[8U] = 1U;
        chartInstance->c42_JITTransitionAnimation[9U] = 1U;
      }

      chartInstance->c42_JITTransitionAnimation[10U] = 1U;
      if (*chartInstance->c42_run_command != 1) {
        chartInstance->c42_JITTransitionAnimation[54U] = 1U;
        chartInstance->c42_JITTransitionAnimation[55U] = 1U;
        c42_guard1 = true;
      } else {
        chartInstance->c42_JITTransitionAnimation[56U] = 1U;
        c42_guard2 = true;
      }
    }

    if (c42_guard2) {
      *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_c42_General = c42_IN_InTrial;
      *chartInstance->c42_trial_in_set = c42__u32_add__(chartInstance,
        *chartInstance->c42_trial_in_set, 1U, 0, 8U, 16, 14);
      *chartInstance->c42_trial_in_block = c42__u32_add__(chartInstance,
        *chartInstance->c42_trial_in_block, 1U, 0, 8U, 32, 16);
      *chartInstance->c42_trial_in_mini_block = c42__u32_add__(chartInstance,
        *chartInstance->c42_trial_in_mini_block, 1U, 0, 8U, 51, 21);
      *chartInstance->c42_tp = c42__u32_d_(chartInstance,
        (*chartInstance->c42_trial_queue)[(uint32_T)sf_array_bounds_check(NULL,
        chartInstance->S, 8U, 80, 11, 9U, (int32_T)c42__u32_minus__
        (chartInstance, *chartInstance->c42_trial_in_mini_block, 1U, 0, 8U, 80,
         11), 1, 499)], 0, 8U, 80, 11);
      chartInstance->c42_JITTransitionAnimation[33U] = 1U;
      *chartInstance->c42_is_InTrial = c42_IN_Running;
      *chartInstance->c42_task_status = 2U;
    }

    if (c42_guard1) {
      *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_c42_General = c42_IN_NO_ACTIVE_CHILD;
      *chartInstance->c42_is_c42_General = c42_IN_PausedBetweenTrials;
      *chartInstance->c42_task_status = 3U;
    }
  } else {
    switch (*chartInstance->c42_is_InTrial) {
     case c42_IN_Paused:
      c42_Paused(chartInstance);
      break;

     case c42_IN_RepeatTrialLater:
     case c42_IN_RepeatTrialNow:
     case c42_IN_SkipTrial:
      break;

     case c42_IN_Running:
      *chartInstance->c42_task_status = 2U;
      c42_b_temp = (*chartInstance->c42_run_command != 1);
      if (c42_b_temp) {
        c42_b_temp = (*chartInstance->c42_pause_type > 0.0);
      }

      if (c42_b_temp) {
        chartInstance->c42_JITTransitionAnimation[39U] = 1U;
        if (*chartInstance->c42_pause_type == 1.0) {
          chartInstance->c42_JITTransitionAnimation[38U] = 1U;
          *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
          *chartInstance->c42_is_InTrial = c42_IN_SkipTrial;
          *chartInstance->c42_e_exit_trialEventCounter = c42__u32_add__
            (chartInstance, *chartInstance->c42_e_exit_trialEventCounter, 1U, 0,
             2U, 18, 12);
        } else {
          chartInstance->c42_JITTransitionAnimation[47U] = 1U;
          if (*chartInstance->c42_pause_type == 2.0) {
            chartInstance->c42_JITTransitionAnimation[37U] = 1U;
            *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
            *chartInstance->c42_is_InTrial = c42_IN_RepeatTrialNow;
            *chartInstance->c42_trial_in_mini_block = c42__u32_minus__
              (chartInstance, *chartInstance->c42_trial_in_mini_block, 1U, 0, 9U,
               23, 21);
            (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
              chartInstance->S, 9U, 46, 12, 28U, c42__s32_d_(chartInstance,
              *chartInstance->c42_EXAM - 1.0, 0, 9U, 46, 12), 1, 2)] =
              (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
              chartInstance->S, 9U, 46, 12, 28U, c42__s32_d_(chartInstance,
              *chartInstance->c42_EXAM - 1.0, 0, 9U, 46, 12), 1, 2)] + 1.0;
            (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
              chartInstance->S, 9U, 68, 12, 28U, c42__s32_d_(chartInstance,
              *chartInstance->c42_BLOCK - 1.0, 0, 9U, 68, 12), 1, 2)] =
              (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
              chartInstance->S, 9U, 68, 12, 28U, c42__s32_d_(chartInstance,
              *chartInstance->c42_BLOCK - 1.0, 0, 9U, 68, 12), 1, 2)] + 1.0;
            *chartInstance->c42_e_exit_trialEventCounter = c42__u32_add__
              (chartInstance, *chartInstance->c42_e_exit_trialEventCounter, 1U,
               0, 9U, 91, 12);
          } else {
            chartInstance->c42_JITTransitionAnimation[48U] = 1U;
            if (*chartInstance->c42_pause_type == 3.0) {
              chartInstance->c42_JITTransitionAnimation[34U] = 1U;
              *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_InTrial = c42_IN_RepeatTrialLater;
              (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
                chartInstance->S, 7U, 25, 12, 28U, c42__s32_d_(chartInstance,
                *chartInstance->c42_EXAM - 1.0, 0, 7U, 25, 12), 1, 2)] =
                (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
                chartInstance->S, 7U, 25, 12, 28U, c42__s32_d_(chartInstance,
                *chartInstance->c42_EXAM - 1.0, 0, 7U, 25, 12), 1, 2)] + 1.0;
              (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
                chartInstance->S, 7U, 47, 12, 28U, c42__s32_d_(chartInstance,
                *chartInstance->c42_BLOCK - 1.0, 0, 7U, 47, 12), 1, 2)] =
                (*chartInstance->c42_extra_trials)[sf_array_bounds_check(NULL,
                chartInstance->S, 7U, 47, 12, 28U, c42__s32_d_(chartInstance,
                *chartInstance->c42_BLOCK - 1.0, 0, 7U, 47, 12), 1, 2)] + 1.0;
              *chartInstance->c42_e_exit_trialEventCounter = c42__u32_add__
                (chartInstance, *chartInstance->c42_e_exit_trialEventCounter, 1U,
                 0, 7U, 70, 12);
            } else {
              chartInstance->c42_JITTransitionAnimation[49U] = 1U;
              chartInstance->c42_JITTransitionAnimation[42U] = 1U;
              *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
              *chartInstance->c42_is_InTrial = c42_IN_Paused;
              *chartInstance->c42_task_status = 3U;
            }
          }
        }
      }
      break;

     default:
      /* Unreachable state, for coverage only */
      *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
      break;
    }
  }
}

static void c42_Paused(SFc42_GeneralInstanceStruct *chartInstance)
{
  *chartInstance->c42_task_status = 3U;
  if (*chartInstance->c42_run_command == 1) {
    chartInstance->c42_JITTransitionAnimation[40U] = 1U;
    *chartInstance->c42_is_InTrial = c42_IN_NO_ACTIVE_CHILD;
    *chartInstance->c42_is_InTrial = c42_IN_Running;
    *chartInstance->c42_task_status = 2U;
  }
}

const mxArray *sf_c42_General_get_eml_resolved_functions_info(void)
{
  const mxArray *c42_nameCaptureInfo = NULL;
  c42_nameCaptureInfo = NULL;
  sf_mex_assign(&c42_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1), false);
  return c42_nameCaptureInfo;
}

static uint32_T c42_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_b_block_idx, const char_T *c42_identifier)
{
  uint32_T c42_y;
  emlrtMsgIdentifier c42_thisId;
  c42_thisId.fIdentifier = (const char *)c42_identifier;
  c42_thisId.fParent = NULL;
  c42_thisId.bParentIsCell = false;
  c42_y = c42_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c42_b_block_idx),
    &c42_thisId);
  sf_mex_destroy(&c42_b_block_idx);
  return c42_y;
}

static uint32_T c42_b_emlrt_marshallIn(SFc42_GeneralInstanceStruct
  *chartInstance, const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId)
{
  uint32_T c42_y;
  uint32_T c42_b_u;
  (void)chartInstance;
  sf_mex_import(c42_parentId, sf_mex_dup(c42_u), &c42_b_u, 1, 7, 0U, 0, 0U, 0);
  c42_y = c42_b_u;
  sf_mex_destroy(&c42_u);
  return c42_y;
}

static void c42_c_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_b_extra_trials, const char_T *c42_identifier, real_T c42_y
  [2])
{
  emlrtMsgIdentifier c42_thisId;
  c42_thisId.fIdentifier = (const char *)c42_identifier;
  c42_thisId.fParent = NULL;
  c42_thisId.bParentIsCell = false;
  c42_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c42_b_extra_trials),
    &c42_thisId, c42_y);
  sf_mex_destroy(&c42_b_extra_trials);
}

static void c42_d_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId, real_T c42_y[2])
{
  real_T c42_dv[2];
  int32_T c42_b_i;
  (void)chartInstance;
  sf_mex_import(c42_parentId, sf_mex_dup(c42_u), c42_dv, 1, 0, 0U, 1, 0U, 1, 2);
  for (c42_b_i = 0; c42_b_i < 2; c42_b_i++) {
    c42_y[c42_b_i] = c42_dv[c42_b_i];
  }

  sf_mex_destroy(&c42_u);
}

static real_T c42_e_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_b_repeat_last_trial, const char_T *c42_identifier)
{
  real_T c42_y;
  emlrtMsgIdentifier c42_thisId;
  c42_thisId.fIdentifier = (const char *)c42_identifier;
  c42_thisId.fParent = NULL;
  c42_thisId.bParentIsCell = false;
  c42_y = c42_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c42_b_repeat_last_trial), &c42_thisId);
  sf_mex_destroy(&c42_b_repeat_last_trial);
  return c42_y;
}

static real_T c42_f_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId)
{
  real_T c42_y;
  real_T c42_d;
  (void)chartInstance;
  sf_mex_import(c42_parentId, sf_mex_dup(c42_u), &c42_d, 1, 0, 0U, 0, 0U, 0);
  c42_y = c42_d;
  sf_mex_destroy(&c42_u);
  return c42_y;
}

static void c42_g_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_b_repeat_list, const char_T *c42_identifier, real_T c42_y
  [499])
{
  emlrtMsgIdentifier c42_thisId;
  c42_thisId.fIdentifier = (const char *)c42_identifier;
  c42_thisId.fParent = NULL;
  c42_thisId.bParentIsCell = false;
  c42_h_emlrt_marshallIn(chartInstance, sf_mex_dup(c42_b_repeat_list),
    &c42_thisId, c42_y);
  sf_mex_destroy(&c42_b_repeat_list);
}

static void c42_h_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId, real_T c42_y[499])
{
  real_T c42_dv[499];
  int32_T c42_b_i;
  (void)chartInstance;
  sf_mex_import(c42_parentId, sf_mex_dup(c42_u), c42_dv, 1, 0, 0U, 1, 0U, 1, 499);
  for (c42_b_i = 0; c42_b_i < 499; c42_b_i++) {
    c42_y[c42_b_i] = c42_dv[c42_b_i];
  }

  sf_mex_destroy(&c42_u);
}

static boolean_T c42_i_emlrt_marshallIn(SFc42_GeneralInstanceStruct
  *chartInstance, const mxArray *c42_b_e_exit_trial, const char_T
  *c42_identifier)
{
  boolean_T c42_y;
  emlrtMsgIdentifier c42_thisId;
  c42_thisId.fIdentifier = (const char *)c42_identifier;
  c42_thisId.fParent = NULL;
  c42_thisId.bParentIsCell = false;
  c42_y = c42_j_emlrt_marshallIn(chartInstance, sf_mex_dup(c42_b_e_exit_trial),
    &c42_thisId);
  sf_mex_destroy(&c42_b_e_exit_trial);
  return c42_y;
}

static boolean_T c42_j_emlrt_marshallIn(SFc42_GeneralInstanceStruct
  *chartInstance, const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId)
{
  boolean_T c42_y;
  boolean_T c42_b;
  (void)chartInstance;
  sf_mex_import(c42_parentId, sf_mex_dup(c42_u), &c42_b, 1, 11, 0U, 0, 0U, 0);
  c42_y = c42_b;
  sf_mex_destroy(&c42_u);
  return c42_y;
}

static uint8_T c42_k_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_b_is_active_c42_General, const char_T *c42_identifier)
{
  uint8_T c42_y;
  emlrtMsgIdentifier c42_thisId;
  c42_thisId.fIdentifier = (const char *)c42_identifier;
  c42_thisId.fParent = NULL;
  c42_thisId.bParentIsCell = false;
  c42_y = c42_l_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c42_b_is_active_c42_General), &c42_thisId);
  sf_mex_destroy(&c42_b_is_active_c42_General);
  return c42_y;
}

static uint8_T c42_l_emlrt_marshallIn(SFc42_GeneralInstanceStruct *chartInstance,
  const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId)
{
  uint8_T c42_y;
  uint8_T c42_b_u;
  (void)chartInstance;
  sf_mex_import(c42_parentId, sf_mex_dup(c42_u), &c42_b_u, 1, 3, 0U, 0, 0U, 0);
  c42_y = c42_b_u;
  sf_mex_destroy(&c42_u);
  return c42_y;
}

static const mxArray *c42_m_emlrt_marshallIn(SFc42_GeneralInstanceStruct
  *chartInstance, const mxArray *c42_b_setSimStateSideEffectsInfo, const char_T *
  c42_identifier)
{
  const mxArray *c42_y = NULL;
  emlrtMsgIdentifier c42_thisId;
  c42_y = NULL;
  c42_thisId.fIdentifier = (const char *)c42_identifier;
  c42_thisId.fParent = NULL;
  c42_thisId.bParentIsCell = false;
  sf_mex_assign(&c42_y, c42_n_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c42_b_setSimStateSideEffectsInfo), &c42_thisId), false);
  sf_mex_destroy(&c42_b_setSimStateSideEffectsInfo);
  return c42_y;
}

static const mxArray *c42_n_emlrt_marshallIn(SFc42_GeneralInstanceStruct
  *chartInstance, const mxArray *c42_u, const emlrtMsgIdentifier *c42_parentId)
{
  const mxArray *c42_y = NULL;
  (void)chartInstance;
  (void)c42_parentId;
  c42_y = NULL;
  sf_mex_assign(&c42_y, sf_mex_duplicatearraysafe(&c42_u), false);
  sf_mex_destroy(&c42_u);
  return c42_y;
}

static uint8_T c42__u8_u32_(SFc42_GeneralInstanceStruct *chartInstance, uint32_T
  c42_b, int32_T c42_EMLOvCount_src_loc, uint32_T c42_ssid_src_loc, int32_T
  c42_offset_src_loc, int32_T c42_length_src_loc)
{
  uint8_T c42_a;
  (void)c42_EMLOvCount_src_loc;
  c42_a = (uint8_T)c42_b;
  if (c42_a != c42_b) {
    sf_data_overflow_error(chartInstance->S, c42_ssid_src_loc,
      c42_offset_src_loc, c42_length_src_loc);
  }

  return c42_a;
}

static int32_T c42__s32_d_(SFc42_GeneralInstanceStruct *chartInstance, real_T
  c42_b, int32_T c42_EMLOvCount_src_loc, uint32_T c42_ssid_src_loc, int32_T
  c42_offset_src_loc, int32_T c42_length_src_loc)
{
  int32_T c42_a;
  real_T c42_b_b;
  (void)c42_EMLOvCount_src_loc;
  c42_a = (int32_T)c42_b;
  if (c42_b < 0.0) {
    c42_b_b = muDoubleScalarCeil(c42_b);
  } else {
    c42_b_b = muDoubleScalarFloor(c42_b);
  }

  if ((real_T)c42_a != c42_b_b) {
    sf_data_overflow_error(chartInstance->S, c42_ssid_src_loc,
      c42_offset_src_loc, c42_length_src_loc);
  }

  return c42_a;
}

static uint32_T c42__u32_d_(SFc42_GeneralInstanceStruct *chartInstance, real_T
  c42_b, int32_T c42_EMLOvCount_src_loc, uint32_T c42_ssid_src_loc, int32_T
  c42_offset_src_loc, int32_T c42_length_src_loc)
{
  uint32_T c42_a;
  (void)c42_EMLOvCount_src_loc;
  c42_a = (uint32_T)c42_b;
  if ((c42_b < 0.0) || ((real_T)c42_a != muDoubleScalarFloor(c42_b))) {
    sf_data_overflow_error(chartInstance->S, c42_ssid_src_loc,
      c42_offset_src_loc, c42_length_src_loc);
  }

  return c42_a;
}

static uint32_T c42__u32_add__(SFc42_GeneralInstanceStruct *chartInstance,
  uint32_T c42_b, uint32_T c42_c, int32_T c42_EMLOvCount_src_loc, uint32_T
  c42_ssid_src_loc, int32_T c42_offset_src_loc, int32_T c42_length_src_loc)
{
  uint32_T c42_a;
  (void)c42_EMLOvCount_src_loc;
  c42_a = c42_b + c42_c;
  if (c42_a < c42_b) {
    sf_data_overflow_error(chartInstance->S, c42_ssid_src_loc,
      c42_offset_src_loc, c42_length_src_loc);
  }

  return c42_a;
}

static uint32_T c42__u32_minus__(SFc42_GeneralInstanceStruct *chartInstance,
  uint32_T c42_b, uint32_T c42_c, int32_T c42_EMLOvCount_src_loc, uint32_T
  c42_ssid_src_loc, int32_T c42_offset_src_loc, int32_T c42_length_src_loc)
{
  uint32_T c42_a;
  (void)c42_EMLOvCount_src_loc;
  c42_a = c42_b - c42_c;
  if (c42_b < c42_c) {
    sf_data_overflow_error(chartInstance->S, c42_ssid_src_loc,
      c42_offset_src_loc, c42_length_src_loc);
  }

  return c42_a;
}

static void init_dsm_address_info(SFc42_GeneralInstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address(SFc42_GeneralInstanceStruct *chartInstance)
{
  chartInstance->c42_e_clk = (int8_T *)(ssGetInputPortSignalPtrs_wrapper
    (chartInstance->S, 10))[0U];
  chartInstance->c42_e_trial_over = (int8_T *)(ssGetInputPortSignalPtrs_wrapper
    (chartInstance->S, 10))[1U];
  chartInstance->c42_e_exit_trial = (boolean_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 9);
  chartInstance->c42_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c42_e_exit_trialEventCounter = (uint32_T *)ssGetDWork_wrapper
    (chartInstance->S, 0);
  chartInstance->c42_sfEvent = (int32_T *)ssGetDWork_wrapper(chartInstance->S, 1);
  chartInstance->c42_is_active_c42_General = (uint8_T *)ssGetDWork_wrapper
    (chartInstance->S, 2);
  chartInstance->c42_is_c42_General = (uint8_T *)ssGetDWork_wrapper
    (chartInstance->S, 3);
  chartInstance->c42_is_InTrial1 = (uint8_T *)ssGetDWork_wrapper
    (chartInstance->S, 4);
  chartInstance->c42_is_InTrial = (uint8_T *)ssGetDWork_wrapper(chartInstance->S,
    5);
  chartInstance->c42_repeat_trial_flag = (real_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 0);
  chartInstance->c42_task_status = (uint32_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c42_tp = (uint32_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 2);
  chartInstance->c42_block_idx = (uint32_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 3);
  chartInstance->c42_trial_in_block = (uint32_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 4);
  chartInstance->c42_block_in_set = (uint32_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 5);
  chartInstance->c42_trial_in_set = (uint32_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 6);
  chartInstance->c42_trial_queue = (real_T (*)[499])ssGetDWork_wrapper
    (chartInstance->S, 6);
  chartInstance->c42_repeat_list = (real_T (*)[499])ssGetDWork_wrapper
    (chartInstance->S, 7);
  chartInstance->c42_run_command = (uint8_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c42_pause_type = (real_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 2);
  chartInstance->c42_seed = (uint32_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 3);
  chartInstance->c42_block_definitions = (real_T (*)[25000])
    ssGetInputPortSignal_wrapper(chartInstance->S, 4);
  chartInstance->c42_trial_queue_max_length = (uint32_T *)
    ssGetInputPortSignal_wrapper(chartInstance->S, 5);
  chartInstance->c42_task_protocol_block_sequence = (real_T (*)[3000])
    ssGetInputPortSignal_wrapper(chartInstance->S, 6);
  chartInstance->c42_task_protocol_block_sequence_length = (uint32_T *)
    ssGetInputPortSignal_wrapper(chartInstance->S, 7);
  chartInstance->c42_is_custom_tp_sequence = (real_T *)
    ssGetInputPortSignal_wrapper(chartInstance->S, 8);
  chartInstance->c42_repeat_list_length = (uint32_T *)ssGetDWork_wrapper
    (chartInstance->S, 8);
  chartInstance->c42_i = (uint32_T *)ssGetDWork_wrapper(chartInstance->S, 9);
  chartInstance->c42_swap_index = (uint32_T *)ssGetDWork_wrapper
    (chartInstance->S, 10);
  chartInstance->c42_temp = (uint32_T *)ssGetDWork_wrapper(chartInstance->S, 11);
  chartInstance->c42_next_custom_tp = (real_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 9);
  chartInstance->c42_trial_queue_length = (uint32_T *)ssGetDWork_wrapper
    (chartInstance->S, 12);
  chartInstance->c42_trial_in_mini_block = (uint32_T *)ssGetDWork_wrapper
    (chartInstance->S, 13);
  chartInstance->c42_repeat_last_trial = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 7);
  chartInstance->c42_extra_trials = (real_T (*)[2])ssGetOutputPortSignal_wrapper
    (chartInstance->S, 8);
  chartInstance->c42_EXAM = (real_T *)ssGetDWork_wrapper(chartInstance->S, 14);
  chartInstance->c42_BLOCK = (real_T *)ssGetDWork_wrapper(chartInstance->S, 15);
  chartInstance->c42_block = (real_T *)ssGetDWork_wrapper(chartInstance->S, 16);
  chartInstance->c42_temporalCounter_i1 = (uint8_T *)ssGetDWork_wrapper
    (chartInstance->S, 17);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* SFunction Glue Code */
void sf_c42_General_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3626219573U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3259712176U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(1306434204U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(383080266U);
}

mxArray *sf_c42_General_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c42_General_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("late");
  mxArray *fallbackReason = mxCreateString("ir_function_calls");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("srand");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c42_General_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

static const mxArray *sf_get_sim_state_info_c42_General(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  mxArray *mxVarInfo = sf_mex_decode(
    "eNrNmEFv0zAUx52umzaYKti0qUIcKg6cGeLAjcA0jQomLhwQIFwvfYC11slip4TbPso+Sj8KH2E"
    "fYXaSrY6paLCDcCTLepae61+f/X/2Q8HwBMmvJ9toH6EN2W/K1kHlt17ZgWwPqr4c796OD2QTPx"
    "NQ4zyNhmPZMzItbJLlQ/Y1LuZ/jhbzbyyZP9Dm36rGy+/qhZv/p1D5h5p/d4n/luZ/r7JPJ3F0h"
    "uk4r8Z7Wv/feC6a8WwbPNsLHoY5CG945iNrHshFSrBIKZlwb3guS57XK3juGzzKTiEBIvCEcFFS"
    "ebXvPjaK012DS9mC8DPMBREZ94dnXvI8WcHTqfF0kEg8WX/YTAd6RjyUXewtpQOFIPgSD3tdu+V"
    "pVdc2Qzd/8pv/Mp51g0fZr96+O3zjC8evUaNz0q1xdNHRh5cnfqwfrONQHQ9P9hNuFIegxhEg6s"
    "v6w8/W+eMmL1IukDfne/6lUZ7fMXh26jx4Auyb+I784QpxozjdMbiUzX+QRMrwGHKPeC6wlX4Jm"
    "CZerH/Q7D65a8RjV8+LU8roTbL3Rs/s9aDkOs8gA494RtZ6oPH8Az3oO54fh/cZhpxqT5l2eB62"
    "wrMqTn2Dp2/wHM2AicM4YwLSdrgGjvuv/P1VXHsGl7IpxyQSdAY4evYUHwODtAhYO1yPWuGyeed"
    "IrhqQHzwD6/wqeYbs/aIw4AXP5am1ji94Dlrkeex4/3HQcXlniOVOq2QB0wMtTsGf66uBUV9d0+"
    "qS8lUbcxQJ/Tz8bd0CZo7/65yErvWBa42M3Zc="
    );
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c42_General_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const char* sf_get_instance_specialization(void)
{
  return "sHJM5UOkuWYjWuYEBj8rXgG";
}

static void sf_opaque_initialize_c42_General(void *chartInstanceVar)
{
  initialize_params_c42_General((SFc42_GeneralInstanceStruct*) chartInstanceVar);
  initialize_c42_General((SFc42_GeneralInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c42_General(void *chartInstanceVar)
{
  enable_c42_General((SFc42_GeneralInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c42_General(void *chartInstanceVar)
{
  disable_c42_General((SFc42_GeneralInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c42_General(void *chartInstanceVar)
{
  sf_gateway_c42_General((SFc42_GeneralInstanceStruct*) chartInstanceVar);
}

static void sf_opaque_ext_mode_exec_c42_General(void *chartInstanceVar)
{
  ext_mode_exec_c42_General((SFc42_GeneralInstanceStruct*) chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c42_General(SimStruct* S)
{
  return get_sim_state_c42_General((SFc42_GeneralInstanceStruct *)
    sf_get_chart_instance_ptr(S));     /* raw sim ctx */
}

static void sf_opaque_set_sim_state_c42_General(SimStruct* S, const mxArray *st)
{
  set_sim_state_c42_General((SFc42_GeneralInstanceStruct*)
    sf_get_chart_instance_ptr(S), st);
}

static void sf_opaque_terminate_c42_General(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc42_GeneralInstanceStruct*) chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_General_optimization_info();
    }

    finalize_c42_General((SFc42_GeneralInstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc42_General((SFc42_GeneralInstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c42_General(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  sf_warn_if_symbolic_dimension_param_changed(S);
  if (sf_machine_global_initializer_called()) {
    initialize_params_c42_General((SFc42_GeneralInstanceStruct*)
      sf_get_chart_instance_ptr(S));
    initSimStructsc42_General((SFc42_GeneralInstanceStruct*)
      sf_get_chart_instance_ptr(S));
  }
}

const char* sf_c42_General_get_post_codegen_info(void)
{
  int i;
  const char* encStrCodegen [36] = {
    "eNrtXN1u2zYUlrO0TfqTZS36s6HAgl2su9hF2m1AgV3MjeO03pwmmJOm3YY5tHRiM9ZfRcpxd7O",
    "+x24K7EGWBxiw+10V2B6g2BOMlC1bpmVLkRVbTSnAcSifc8SP5+gjeUhJyZU2FXYssc8jR1HOs+",
    "8F9plTOse5bjkX+HTOzyt3uuXfmZDpGtvIQQZRxh4mMuB7IJbuUmyZJfPAChXD5gE4YKpM1rYcO",
    "soawYarY7O54Zoqt0f2GlhtVBqWq2trTBdpW6b+glmzXbrN7KxjB1S6AaDRhmO59caGjuq9Gjv0",
    "qNAAtUlcYxwEArTi2rxaZNPVKbZ1KLZBLZmEIlZj0q9bhSIKBdoeCZMjJRVf0DJsHSMzFG0DkQr",
    "YrIEp7Noa+7vlUgZKFFMbyKFr0EAtIGXc9GxaJog2MWE/1LCJqOVgpBcNvcAVh+u2rbP6bFoa6G",
    "MahNVtzQHUtC1s0tH+r2wwpEUT1XRYh5pbH22tAs9d7vwnGI7AGdluBwWrBQ6qw5Y58qJegxTbn",
    "rd6UTIsRrEBT5DzQGX+I6CNjF4WOaSCmJ9gh2mMEgMPZInsOLjFmnekNdco8ciMumVco+NsEiXm",
    "WSu2YJwXetY2VLOAdJ2MFNux7DK0QPesriOKxot1rIbL2Y5lozqLWo01Mg/xgmVqeMgXqkuoZRR",
    "YuK2Xy48ZU4RXri9WMik4B0iFsPuWqA3QXB0YUMZM1LtciFENE+6tCKmuT6OkFHLgmutHltNkQM",
    "fc9n0I3AcjBQ1SZ63PYneXsDAfJ8ZbP1LO5/lVpc/zl2PwvK8nfn8WsJMLsaMEvrl8PiC/ODcof",
    "0m47px/rn+E2rkiXHdesMPlltnn4+1/l75+/d9v//z1+Z93mh/+LbaDWJ/cUH1y3v9cb/nmyfrJ",
    "pW75tk9IvXBtDUWJ1w8H6jUfYv9mwP5yt0wefbv51e5W0917drjnPiuuHd53ntYfevb2b4yv70d",
    "Cff3zK5wZX9gezxFHLWndDpyXkdvp1rj9+4H6no9oj8Xu+c7x5pvJ9H/Mi/EQ1l6LQnvxck231G",
    "YVa+2QuJ4Znpfx8FwW8Fzu4zGrbHiSGTzH+4nxQJs6qEr58IRkBs+rDp6o+/MDAQ8vO2ADolUdE",
    "dpBlam4+yGWny4JuHiZItKsspEvdUl28Bx38KxG4JkbwDOnUDsj9c/H44ElwR+87MUW5wGPELLi",
    "j+S81sOTKq8t5CfTR0P6YXjOCXh4ea28VfguKzhe78e6T+YHcMwrxacPNrNRf0jsh+7tkZF4qsb",
    "yQ24AR07BWal//qfE/YffL2JClczc38c/x+rnrwp4rg7iqepg1mlDyQ6ufDWWny4KuHiZHCGb0b",
    "AG7QzheVlNxF8UDDsT9V+JN568JvjjWrBfNLCJ/c4+M3yWnA86uJ674EKG8Own5oMAnlPgg1sT3",
    "j8TzM+q0MaBqUw6eG6ngifKT7cEPLcEPF4KtWC5PLuYDq6VCeMvXl7ouoDrupcnryKV4hZU1S/v",
    "VR+CCY7nsHRwfZIKriTzHIZrAFA28Kwk7l8ZnpK5008MZALPq1piHu/juZsink8nHP9MwONszGC",
    "xSOvSQhXfDfgpd7J88HuBvCSb1VpEUemo/HycvAW0JmzXY5RPIz+QNJ9+Uj1F6km9KejlEq6XXU",
    "yot5hQb27Cdb1p4VtIuG54Uvlx/KkI8ssTXOe05bcfj+9Xrgrte6NbXmbCLeQ8RkNbFPzVvOE9K",
    "HVT3PZwZDlaOTBj6Rw1jEJW5YluhRiGdvjmk4qKdNDWLbemw8CWFFv30wu9TTS/hNSXvDBqlo7V",
    "ysCvNUz3sDZYW28die9f2bV1C2kD7VAZso3Jlo2eu0Nnd4DQbb65JXDWqh2GtK+NxOt7WwyAqA6",
    "2+aaBwFmHb4NqwY7FGx/pW7VDYMMANpHvzRc1vpHAW6MMnsU9GMRRy+wHwa6B2hU2jTHrA847jX",
    "lRVN71vGCPl13WjF/cC99PEPU96TxjNUJfEfTTvv7s9JfzWah/Ul5OKz+RZNzf2dYUjPws+PPNH",
    "2noJ/VHWP3D2vOCoH/B2yDltaWSdN2mSx+SPyR/xI7X0+KdZUGPfx54yTZvO60X6JIn0s9bJuEN",
    "Pu64L3ljyvvzJtU/m7xxRdDjZe8RgBLp0IccX6S6LiD5QvLFWRtneHzhDzawrkm+SG+dSvKF5It",
    "p8EVUnC0IerzsB6vkjenxRtz1eskbkjeywBtheTc/WCVvzHa8Eba/Mck6itZdPZsFbyTWX/01fz",
    "byoStnej0lbtwm6Te9zChftdTlOsok/gh7bkLyiOSRrPNIWNxKHpnOOstJn1eS+zvk+uw0eCTtu",
    "JV8kg6fJH0eVfKG5I1Zr7eMi0/JD7PLm4Y9Ryz5QvJFFuYrceNV8sd0xhejntuXfCH5Igvji1Hx",
    "KflhdvmMce9bkLwheSOr+YxxcSv5ZDp8ctL37Eg+kXySBT45adxKPpnN/MV/b+Lbtk777vLGyjs",
    "1f/HjU/LDdJ6PjXo/rOQJyRNZ2E8aFaeSL2bHF8H3GEu+kHyRVb4IxqnkixnmR8e8x1A+v/K28I",
    "d8TjYsPt8X9Hh5ZzDeJW8Evk/z/XX/A/8Nbic=",
    ""
  };

  static char newstr [2589] = "";
  newstr[0] = '\0';
  for (i = 0; i < 36; i++) {
    strcat(newstr, encStrCodegen[i]);
  }

  return newstr;
}

static void mdlSetWorkWidths_c42_General(SimStruct *S)
{
  const char* newstr = sf_c42_General_get_post_codegen_info();
  sf_set_work_widths(S, newstr);
  ssSetChecksum0(S,(249843743U));
  ssSetChecksum1(S,(2616385595U));
  ssSetChecksum2(S,(3425488867U));
  ssSetChecksum3(S,(3659098919U));
}

static void mdlRTW_c42_General(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Stateflow");
  }
}

static void mdlStart_c42_General(SimStruct *S)
{
  SFc42_GeneralInstanceStruct *chartInstance;
  chartInstance = (SFc42_GeneralInstanceStruct *)utMalloc(sizeof
    (SFc42_GeneralInstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc42_GeneralInstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 0;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway = sf_opaque_gateway_c42_General;
  chartInstance->chartInfo.initializeChart = sf_opaque_initialize_c42_General;
  chartInstance->chartInfo.terminateChart = sf_opaque_terminate_c42_General;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c42_General;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c42_General;
  chartInstance->chartInfo.getSimState = sf_opaque_get_sim_state_c42_General;
  chartInstance->chartInfo.setSimState = sf_opaque_set_sim_state_c42_General;
  chartInstance->chartInfo.getSimStateInfo = sf_get_sim_state_info_c42_General;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c42_General;
  chartInstance->chartInfo.mdlStart = mdlStart_c42_General;
  chartInstance->chartInfo.mdlSetWorkWidths = mdlSetWorkWidths_c42_General;
  chartInstance->chartInfo.callGetHoverDataForMsg = NULL;
  chartInstance->chartInfo.extModeExec = sf_opaque_ext_mode_exec_c42_General;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartEventFcn = NULL;
  chartInstance->S = S;
  chartInstance->chartInfo.dispatchToExportedFcn = NULL;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0,
    chartInstance->c42_JITStateAnimation,
    chartInstance->c42_JITTransitionAnimation);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  mdl_start_c42_General(chartInstance);
}

void c42_General_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c42_General(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c42_General(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c42_General(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c42_General_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
