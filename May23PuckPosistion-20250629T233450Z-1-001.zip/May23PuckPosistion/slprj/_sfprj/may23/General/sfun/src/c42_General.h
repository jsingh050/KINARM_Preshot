#ifndef __c42_General_h__
#define __c42_General_h__

/* Type Definitions */
#ifndef typedef_SFc42_GeneralInstanceStruct
#define typedef_SFc42_GeneralInstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint8_T c42_JITStateAnimation[18];
  uint8_T c42_JITTransitionAnimation[73];
  uint8_T c42_doSetSimStateSideEffects;
  const mxArray *c42_setSimStateSideEffectsInfo;
  int8_T *c42_e_clk;
  int8_T *c42_e_trial_over;
  boolean_T *c42_e_exit_trial;
  void *c42_fEmlrtCtx;
  uint32_T *c42_e_exit_trialEventCounter;
  int32_T *c42_sfEvent;
  uint8_T *c42_is_active_c42_General;
  uint8_T *c42_is_c42_General;
  uint8_T *c42_is_InTrial1;
  uint8_T *c42_is_InTrial;
  real_T *c42_repeat_trial_flag;
  uint32_T *c42_task_status;
  uint32_T *c42_tp;
  uint32_T *c42_block_idx;
  uint32_T *c42_trial_in_block;
  uint32_T *c42_block_in_set;
  uint32_T *c42_trial_in_set;
  real_T (*c42_trial_queue)[499];
  real_T (*c42_repeat_list)[499];
  uint8_T *c42_run_command;
  real_T *c42_pause_type;
  uint32_T *c42_seed;
  real_T (*c42_block_definitions)[25000];
  uint32_T *c42_trial_queue_max_length;
  real_T (*c42_task_protocol_block_sequence)[3000];
  uint32_T *c42_task_protocol_block_sequence_length;
  real_T *c42_is_custom_tp_sequence;
  uint32_T *c42_repeat_list_length;
  uint32_T *c42_i;
  uint32_T *c42_swap_index;
  uint32_T *c42_temp;
  real_T *c42_next_custom_tp;
  uint32_T *c42_trial_queue_length;
  uint32_T *c42_trial_in_mini_block;
  real_T *c42_repeat_last_trial;
  real_T (*c42_extra_trials)[2];
  real_T *c42_EXAM;
  real_T *c42_BLOCK;
  real_T *c42_block;
  uint8_T *c42_temporalCounter_i1;
} SFc42_GeneralInstanceStruct;

#endif                                 /*typedef_SFc42_GeneralInstanceStruct*/

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c42_General_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c42_General_get_check_sum(mxArray *plhs[]);
extern void c42_General_method_dispatcher(SimStruct *S, int_T method, void *data);

#endif
