/* Include files */

#include "may23_sfun.h"
#include "c1_may23.h"
#include "c3_may23.h"

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */
real_T col_x;
real_T col_y;
real_T SECONDS;
real_T E_NO_EVENT;
real_T WIDTH;
real_T HEIGHT;
real_T ROTATION;
real_T FORCE_MULTIPLIER;
real_T LOAD_ROW;
real_T F_BUMP;
real_T MASS_CIRCLE;
real_T MASS_RECT;
real_T PERT_RAMP;
real_T PERT_DUR;
real_T START_ROW;
real_T GOAL_ROW;
real_T RADIUS_LOG;
real_T RADIUS_VIS;
real_T BARRIER_ROW;
real_T PRESHOT_ROW;
real_T START_HOLD_TIME;
real_T SHOT_READY_TIME;
real_T SHOT_SET_TIME;
real_T GOAL_TIME;
real_T FIRST_FILL;
real_T SECOND_FILL;
real_T THIRD_FILL;
real_T PUCK_ROW;
real_T CURSOR_ROW;
real_T E_START_TARGET_ON;
real_T E_ENTER_START;
real_T E_TRIAL_START;
real_T E_BEGIN_PRESHOT;
real_T E_SHOT_READY;
real_T E_SHOT_GO;
real_T E_PUCK_IN_GOAL;
real_T E_HAND_IN_BARRIER;
real_T E_PUCK_IN_BARRIER;
real_T E_SUCCESS;
real_T E_FAILURE;
real_T E_TIMEOUT;
real_T STROKE_COLOR;
real_T STROKE_WIDTH;
real_T PUCK_DAMPING;
real_T E_PUCK_MISS;
real_T SHOT_TIME;

/* Function Declarations */

/* Function Definitions */
void may23_initializer(void)
{
  col_x = 1.0;
  col_y = 2.0;
  SECONDS = 1.0;
  E_NO_EVENT = 0.0;
  WIDTH = 3.0;
  HEIGHT = 6.0;
  ROTATION = 7.0;
  FORCE_MULTIPLIER = 1.0;
  LOAD_ROW = 4.0;
  F_BUMP = 1.0;
  MASS_CIRCLE = 2.0;
  MASS_RECT = 3.0;
  PERT_RAMP = 4.0;
  PERT_DUR = 5.0;
  START_ROW = 6.0;
  GOAL_ROW = 8.0;
  RADIUS_LOG = 4.0;
  RADIUS_VIS = 5.0;
  BARRIER_ROW = 5.0;
  PRESHOT_ROW = 7.0;
  START_HOLD_TIME = 9.0;
  SHOT_READY_TIME = 10.0;
  SHOT_SET_TIME = 11.0;
  GOAL_TIME = 13.0;
  FIRST_FILL = 8.0;
  SECOND_FILL = 9.0;
  THIRD_FILL = 10.0;
  PUCK_ROW = 3.0;
  CURSOR_ROW = 2.0;
  E_START_TARGET_ON = 1.0;
  E_ENTER_START = 2.0;
  E_TRIAL_START = 3.0;
  E_BEGIN_PRESHOT = 4.0;
  E_SHOT_READY = 5.0;
  E_SHOT_GO = 6.0;
  E_PUCK_IN_GOAL = 7.0;
  E_HAND_IN_BARRIER = 9.0;
  E_PUCK_IN_BARRIER = 10.0;
  E_SUCCESS = 8.0;
  E_FAILURE = 13.0;
  E_TIMEOUT = 14.0;
  STROKE_COLOR = 11.0;
  STROKE_WIDTH = 12.0;
  PUCK_DAMPING = 14.0;
  E_PUCK_MISS = 11.0;
  SHOT_TIME = 12.0;
}

void may23_terminator(void)
{
}

/* SFunction Glue Code */
unsigned int sf_may23_method_dispatcher(SimStruct *simstructPtr, unsigned int
  chartFileNumber, const char* specsCksum, int_T method, void *data)
{
  if (chartFileNumber==1) {
    c1_may23_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  if (chartFileNumber==3) {
    c3_may23_method_dispatcher(simstructPtr, method, data);
    return 1;
  }

  return 0;
}

unsigned int sf_may23_process_check_sum_call( int nlhs, mxArray * plhs[], int
  nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[20];
  if (nrhs<1 || !mxIsChar(prhs[0]) )
    return 0;

  /* Possible call to get the checksum */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"sf_get_check_sum"))
    return 0;
  plhs[0] = mxCreateDoubleMatrix( 1,4,mxREAL);
  if (nrhs>1 && mxIsChar(prhs[1])) {
    mxGetString(prhs[1], commandName,sizeof(commandName)/sizeof(char));
    commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
    if (!strcmp(commandName,"machine")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1174598067U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(200591314U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(4073620417U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(2460360030U);
    } else if (nrhs==3 && !strcmp(commandName,"chart")) {
      unsigned int chartFileNumber;
      chartFileNumber = (unsigned int)mxGetScalar(prhs[2]);
      switch (chartFileNumber) {
       case 1:
        {
          extern void sf_c1_may23_get_check_sum(mxArray *plhs[]);
          sf_c1_may23_get_check_sum(plhs);
          break;
        }

       case 3:
        {
          extern void sf_c3_may23_get_check_sum(mxArray *plhs[]);
          sf_c3_may23_get_check_sum(plhs);
          break;
        }

       default:
        ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(0.0);
        ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(0.0);
      }
    } else if (!strcmp(commandName,"target")) {
      ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(1879480016U);
      ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(1017718258U);
      ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3197657639U);
      ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(2131608836U);
    } else {
      return 0;
    }
  } else {
    ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(985003356U);
    ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3207306741U);
    ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(127218194U);
    ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1772838872U);
  }

  return 1;

#else

  return 0;

#endif

}

unsigned int sf_may23_get_eml_resolved_functions_info( int nlhs, mxArray * plhs[],
  int nrhs, const mxArray * prhs[] )
{

#ifdef MATLAB_MEX_FILE

  char commandName[64];
  char instanceChksum[64];
  if (nrhs<3 || !mxIsChar(prhs[0]))
    return 0;

  /* Possible call to get the get_eml_resolved_functions_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_eml_resolved_functions_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    mxGetString(prhs[2], instanceChksum,sizeof(instanceChksum)/sizeof(char));
    instanceChksum[(sizeof(instanceChksum)/sizeof(char)-1)] = '\0';
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 1:
      {
        if (strcmp(instanceChksum, "sxnujNqimFT7hyfjS45qMLH") == 0) {
          extern const mxArray *sf_c1_may23_get_eml_resolved_functions_info(void);
          mxArray *persistentMxArray = (mxArray *)
            sf_c1_may23_get_eml_resolved_functions_info();
          plhs[0] = mxDuplicateArray(persistentMxArray);
          mxDestroyArray(persistentMxArray);
          break;
        }
      }

     case 3:
      {
        if (strcmp(instanceChksum, "smCIWm1J9sGqZhiLVjSqKeH") == 0) {
          extern const mxArray *sf_c3_may23_get_eml_resolved_functions_info(void);
          mxArray *persistentMxArray = (mxArray *)
            sf_c3_may23_get_eml_resolved_functions_info();
          plhs[0] = mxDuplicateArray(persistentMxArray);
          mxDestroyArray(persistentMxArray);
          break;
        }
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;

#else

  return 0;

#endif

}

unsigned int sf_may23_third_party_uses_info( int nlhs, mxArray * plhs[], int
  nrhs, const mxArray * prhs[] )
{
  char commandName[64];
  char tpChksum[64];
  if (nrhs<3 || !mxIsChar(prhs[0]))
    return 0;

  /* Possible call to get the third_party_uses_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  mxGetString(prhs[2], tpChksum,sizeof(tpChksum)/sizeof(char));
  tpChksum[(sizeof(tpChksum)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_third_party_uses_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 1:
      {
        if (strcmp(tpChksum, "sxnujNqimFT7hyfjS45qMLH") == 0) {
          extern mxArray *sf_c1_may23_third_party_uses_info(void);
          plhs[0] = sf_c1_may23_third_party_uses_info();
          break;
        }
      }

     case 3:
      {
        if (strcmp(tpChksum, "smCIWm1J9sGqZhiLVjSqKeH") == 0) {
          extern mxArray *sf_c3_may23_third_party_uses_info(void);
          plhs[0] = sf_c3_may23_third_party_uses_info();
          break;
        }
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;
}

unsigned int sf_may23_jit_fallback_info( int nlhs, mxArray * plhs[], int nrhs,
  const mxArray * prhs[] )
{
  char commandName[64];
  char tpChksum[64];
  if (nrhs<3 || !mxIsChar(prhs[0]))
    return 0;

  /* Possible call to get the jit_fallback_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  mxGetString(prhs[2], tpChksum,sizeof(tpChksum)/sizeof(char));
  tpChksum[(sizeof(tpChksum)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_jit_fallback_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 1:
      {
        if (strcmp(tpChksum, "sxnujNqimFT7hyfjS45qMLH") == 0) {
          extern mxArray *sf_c1_may23_jit_fallback_info(void);
          plhs[0] = sf_c1_may23_jit_fallback_info();
          break;
        }
      }

     case 3:
      {
        if (strcmp(tpChksum, "smCIWm1J9sGqZhiLVjSqKeH") == 0) {
          extern mxArray *sf_c3_may23_jit_fallback_info(void);
          plhs[0] = sf_c3_may23_jit_fallback_info();
          break;
        }
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;
}

unsigned int sf_may23_get_post_codegen_info( int nlhs, mxArray * plhs[], int
  nrhs, const mxArray * prhs[] )
{
  char commandName[64];
  char tpChksum[64];
  if (nrhs<3 || !mxIsChar(prhs[0]))
    return 0;

  /* Possible call to get_post_codegen_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  mxGetString(prhs[2], tpChksum,sizeof(tpChksum)/sizeof(char));
  tpChksum[(sizeof(tpChksum)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_post_codegen_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 1:
      {
        if (strcmp(tpChksum, "sxnujNqimFT7hyfjS45qMLH") == 0) {
          const char *sf_c1_may23_get_post_codegen_info(void);
          const char* encoded_post_codegen_info =
            sf_c1_may23_get_post_codegen_info();
          plhs[0] = sf_mex_decode(encoded_post_codegen_info);
          break;
        }
      }

     case 3:
      {
        if (strcmp(tpChksum, "smCIWm1J9sGqZhiLVjSqKeH") == 0) {
          const char *sf_c3_may23_get_post_codegen_info(void);
          const char* encoded_post_codegen_info =
            sf_c3_may23_get_post_codegen_info();
          plhs[0] = sf_mex_decode(encoded_post_codegen_info);
          break;
        }
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;
}

unsigned int sf_may23_updateBuildInfo_args_info( int nlhs, mxArray * plhs[], int
  nrhs, const mxArray * prhs[] )
{
  char commandName[64];
  char tpChksum[64];
  if (nrhs<3 || !mxIsChar(prhs[0]))
    return 0;

  /* Possible call to get the updateBuildInfo_args_info */
  mxGetString(prhs[0], commandName,sizeof(commandName)/sizeof(char));
  commandName[(sizeof(commandName)/sizeof(char)-1)] = '\0';
  mxGetString(prhs[2], tpChksum,sizeof(tpChksum)/sizeof(char));
  tpChksum[(sizeof(tpChksum)/sizeof(char)-1)] = '\0';
  if (strcmp(commandName,"get_updateBuildInfo_args_info"))
    return 0;

  {
    unsigned int chartFileNumber;
    chartFileNumber = (unsigned int)mxGetScalar(prhs[1]);
    switch (chartFileNumber) {
     case 1:
      {
        if (strcmp(tpChksum, "sxnujNqimFT7hyfjS45qMLH") == 0) {
          extern mxArray *sf_c1_may23_updateBuildInfo_args_info(void);
          plhs[0] = sf_c1_may23_updateBuildInfo_args_info();
          break;
        }
      }

     case 3:
      {
        if (strcmp(tpChksum, "smCIWm1J9sGqZhiLVjSqKeH") == 0) {
          extern mxArray *sf_c3_may23_updateBuildInfo_args_info(void);
          plhs[0] = sf_c3_may23_updateBuildInfo_args_info();
          break;
        }
      }

     default:
      plhs[0] = mxCreateDoubleMatrix(0,0,mxREAL);
    }
  }

  return 1;
}

void may23_register_exported_symbols(SimStruct* S)
{
  ssRegMdlInfo(S, "BARRIER_ROW", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "CURSOR_ROW", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "E_BEGIN_PRESHOT", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "E_ENTER_START", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "E_FAILURE", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "E_HAND_IN_BARRIER", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "E_NO_EVENT", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "E_PUCK_IN_BARRIER", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "E_PUCK_IN_GOAL", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "E_PUCK_MISS", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "E_SHOT_GO", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "E_SHOT_READY", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "E_START_TARGET_ON", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "E_SUCCESS", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "E_TIMEOUT", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "E_TRIAL_START", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "FIRST_FILL", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "FORCE_MULTIPLIER", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "F_BUMP", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "GOAL_ROW", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "GOAL_TIME", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "HEIGHT", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "LOAD_ROW", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "MASS_CIRCLE", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "MASS_RECT", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "PERT_DUR", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "PERT_RAMP", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "PRESHOT_ROW", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "PUCK_DAMPING", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "PUCK_ROW", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "RADIUS_LOG", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "RADIUS_VIS", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "ROTATION", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "SECONDS", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "SECOND_FILL", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "SHOT_READY_TIME", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "SHOT_SET_TIME", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "SHOT_TIME", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "START_HOLD_TIME", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "START_ROW", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "STROKE_COLOR", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "STROKE_WIDTH", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*)
               NULL);
  ssRegMdlInfo(S, "THIRD_FILL", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "WIDTH", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "col_x", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
  ssRegMdlInfo(S, "col_y", MDL_INFO_ID_MACHINE_EXPORTED, 0, 0, (void*) NULL);
}

static mxArray* sRtwOptimizationInfoStruct= NULL;
typedef struct SfOptimizationInfoFlagsTag {
  boolean_T isRtwGen;
  boolean_T isModelRef;
  boolean_T isExternal;
} SfOptimizationInfoFlags;

static SfOptimizationInfoFlags sOptimizationInfoFlags;
void unload_may23_optimization_info(void);
mxArray* load_may23_optimization_info(boolean_T isRtwGen, boolean_T isModelRef,
  boolean_T isExternal)
{
  if (sOptimizationInfoFlags.isRtwGen != isRtwGen ||
      sOptimizationInfoFlags.isModelRef != isModelRef ||
      sOptimizationInfoFlags.isExternal != isExternal) {
    unload_may23_optimization_info();
  }

  sOptimizationInfoFlags.isRtwGen = isRtwGen;
  sOptimizationInfoFlags.isModelRef = isModelRef;
  sOptimizationInfoFlags.isExternal = isExternal;
  if (sRtwOptimizationInfoStruct==NULL) {
    sRtwOptimizationInfoStruct = sf_load_rtw_optimization_info("may23", "may23");
    mexMakeArrayPersistent(sRtwOptimizationInfoStruct);
  }

  return(sRtwOptimizationInfoStruct);
}

void unload_may23_optimization_info(void)
{
  if (sRtwOptimizationInfoStruct!=NULL) {
    mxDestroyArray(sRtwOptimizationInfoStruct);
    sRtwOptimizationInfoStruct = NULL;
  }
}
