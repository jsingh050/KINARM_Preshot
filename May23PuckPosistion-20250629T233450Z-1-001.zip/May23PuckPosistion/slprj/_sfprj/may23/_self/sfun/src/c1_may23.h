#ifndef __c1_may23_h__
#define __c1_may23_h__

/* Type Definitions */
#ifndef typedef_SFc1_may23InstanceStruct
#define typedef_SFc1_may23InstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint8_T c1_JITStateAnimation[10];
  uint8_T c1_JITTransitionAnimation[9];
  boolean_T c1_dataWrittenToVector[25];
  uint8_T c1_doSetSimStateSideEffects;
  const mxArray *c1_setSimStateSideEffectsInfo;
  int8_T *c1_e_clk;
  int8_T *c1_e_Trial_Start;
  boolean_T *c1_e_Puck_Stopped;
  boolean_T *c1_e_Puck_Hit;
  void *c1_fEmlrtCtx;
  uint32_T *c1_e_Puck_StoppedEventCounter;
  uint32_T *c1_e_Puck_HitEventCounter;
  int32_T *c1_sfEvent;
  uint8_T *c1_is_active_c1_may23;
  uint8_T *c1_is_c1_may23;
  uint8_T *c1_is_active_UpdatePosition;
  uint8_T *c1_is_CollisionWithHand;
  uint8_T *c1_is_active_CollisionWithHand;
  uint8_T *c1_is_active_UpdateVelocity;
  real_T (*c1_cursor_vcode_in)[140];
  real_T (*c1_puck_vcode_output)[70];
  real_T (*c1_puck_vcode_in)[70];
  real_T (*c1_goal_target)[70];
  real_T (*c1_display_size)[2];
  real_T (*c1_force_scaling)[4];
  real_T *c1_mass_hand;
  real_T *c1_mass_puck;
  real_T (*c1_hand_vector)[2];
  real_T (*c1_prev_vel)[2];
  real_T *c1_target_colliding;
  real_T (*c1_hand_vel)[2];
  real_T *c1_rect_offset_position;
  real_T *c1_barrier_colliding;
  real_T (*c1_hand_speed)[4];
  real_T *c1_check_collision_barrier1;
  real_T *c1_barrier_vel;
  real_T *c1_force_scaling_barrier;
  real_T *c1_hand_offset_position;
  real_T *c1_prev_hand_vel;
  real_T *c1_rect_left;
  real_T *c1_rect_bottom;
  real_T *c1_goal_right;
  real_T *c1_rect_right;
  real_T *c1_goal_bottom;
  real_T *c1_goal_left;
  real_T *c1_new_hand_posistion_c;
  real_T (*c1_puck_offset_position)[2];
  real_T (*c1_puck_velocity)[2];
  real_T (*c1_Trial_Protocol)[50];
  real_T *c1_puck_damping;
} SFc1_may23InstanceStruct;

#endif                                 /*typedef_SFc1_may23InstanceStruct*/

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c1_may23_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c1_may23_get_check_sum(mxArray *plhs[]);
extern void c1_may23_method_dispatcher(SimStruct *S, int_T method, void *data);

#endif
