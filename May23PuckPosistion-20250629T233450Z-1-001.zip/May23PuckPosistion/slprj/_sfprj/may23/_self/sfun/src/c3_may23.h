#ifndef __c3_may23_h__
#define __c3_may23_h__

/* Type Definitions */
#ifndef typedef_SFc3_may23InstanceStruct
#define typedef_SFc3_may23InstanceStruct

typedef struct {
  SimStruct *S;
  ChartInfoStruct chartInfo;
  uint8_T c3_JITStateAnimation[14];
  uint8_T c3_JITTransitionAnimation[25];
  boolean_T c3_dataWrittenToVector[21];
  uint8_T c3_doSetSimStateSideEffects;
  const mxArray *c3_setSimStateSideEffectsInfo;
  int8_T *c3_e_clk;
  int8_T *c3_e_ExitTrialNow;
  boolean_T *c3_e_Trial_Start;
  boolean_T *c3_e_Trial_End;
  int8_T *c3_e_Puck_Stopped;
  int8_T *c3_e_Puck_Hit;
  void *c3_fEmlrtCtx;
  uint32_T *c3_e_Trial_StartEventCounter;
  uint32_T *c3_e_Trial_EndEventCounter;
  int32_T *c3_sfEvent;
  uint8_T *c3_is_active_c3_may23;
  uint8_T *c3_is_c3_may23;
  uint8_T *c3_is_Main_Trial;
  boolean_T *c3_logging_enable;
  real_T *c3_event_code;
  real_T *c3_cursor_row;
  real_T *c3_cursor_state;
  real_T *c3_puck_row;
  real_T *c3_puck_state;
  real_T *c3_load_row;
  real_T (*c3_Trial_Protocol)[50];
  real_T *c3_trial_duration;
  real_T *c3_barrier_target_row;
  real_T *c3_barrier_target_state;
  real_T *c3_start_target_row;
  real_T *c3_start_target_state;
  real_T *c3_goal_target_row;
  real_T *c3_goal_target_state;
  real_T (*c3_HandInTarget)[64];
  real_T *c3_preshot_area_row;
  real_T *c3_preshot_area_state;
  real_T *c3_start_hold_time;
  real_T *c3_shot_set_time;
  real_T *c3_shot_ready_time;
  real_T (*c3_HandInBarrier)[64];
  real_T (*c3_PuckInTarget)[64];
  real_T *c3_goal_time;
  real_T (*c3_PuckInBarrier)[64];
  real_T *c3_PuckInDisplay;
  real_T *c3_shot_time;
  uint32_T *c3_temporalCounter_i1;
  uint32_T *c3_presentTicks;
  uint32_T *c3_elapsedTicks;
  uint32_T *c3_previousTicks;
} SFc3_may23InstanceStruct;

#endif                                 /*typedef_SFc3_may23InstanceStruct*/

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
extern const mxArray *sf_c3_may23_get_eml_resolved_functions_info(void);

/* Function Definitions */
extern void sf_c3_may23_get_check_sum(mxArray *plhs[]);
extern void c3_may23_method_dispatcher(SimStruct *S, int_T method, void *data);

#endif
