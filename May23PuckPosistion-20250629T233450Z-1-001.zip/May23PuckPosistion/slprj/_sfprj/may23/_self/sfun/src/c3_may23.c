/* Include files */

#include "may23_sfun.h"
#include "c3_may23.h"
#include "mwmathutil.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(S);
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

/* Type Definitions */

/* Named Constants */
#define c3_event_e_clk                 (0)
#define c3_event_e_ExitTrialNow        (1)
#define c3_event_e_Puck_Stopped        (2)
#define c3_event_e_Puck_Hit            (3)
#define CALL_EVENT                     (-1)
#define c3_IN_NO_ACTIVE_CHILD          ((uint8_T)0U)
#define c3_IN_Initialize               ((uint8_T)1U)
#define c3_IN_Inter_Trial_State        ((uint8_T)2U)
#define c3_IN_Main_Trial               ((uint8_T)3U)
#define c3_IN_Fail                     ((uint8_T)1U)
#define c3_IN_PreshotMove              ((uint8_T)2U)
#define c3_IN_PreshotStart             ((uint8_T)3U)
#define c3_IN_PuckMoving               ((uint8_T)4U)
#define c3_IN_Shot                     ((uint8_T)5U)
#define c3_IN_ShotEnd                  ((uint8_T)6U)
#define c3_IN_ShotReady                ((uint8_T)7U)
#define c3_IN_ShotSet                  ((uint8_T)8U)
#define c3_IN_StartHold                ((uint8_T)9U)
#define c3_IN_StartOn                  ((uint8_T)10U)
#define c3_IN_Success                  ((uint8_T)11U)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;

/* Function Declarations */
static void initialize_c3_may23(SFc3_may23InstanceStruct *chartInstance);
static void initialize_params_c3_may23(SFc3_may23InstanceStruct *chartInstance);
static void enable_c3_may23(SFc3_may23InstanceStruct *chartInstance);
static void disable_c3_may23(SFc3_may23InstanceStruct *chartInstance);
static void c3_update_jit_animation_state_c3_may23(SFc3_may23InstanceStruct
  *chartInstance);
static void c3_do_animation_call_c3_may23(SFc3_may23InstanceStruct
  *chartInstance);
static void ext_mode_exec_c3_may23(SFc3_may23InstanceStruct *chartInstance);
static const mxArray *get_sim_state_c3_may23(SFc3_may23InstanceStruct
  *chartInstance);
static void set_sim_state_c3_may23(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_st);
static void c3_set_sim_state_side_effects_c3_may23(SFc3_may23InstanceStruct
  *chartInstance);
static void finalize_c3_may23(SFc3_may23InstanceStruct *chartInstance);
static void sf_gateway_c3_may23(SFc3_may23InstanceStruct *chartInstance);
static void mdl_start_c3_may23(SFc3_may23InstanceStruct *chartInstance);
static void c3_chartstep_c3_may23(SFc3_may23InstanceStruct *chartInstance);
static void initSimStructsc3_may23(SFc3_may23InstanceStruct *chartInstance);
static void c3_Main_Trial(SFc3_may23InstanceStruct *chartInstance);
static void c3_enter_atomic_StartOn(SFc3_may23InstanceStruct *chartInstance);
static void c3_PreshotStart(SFc3_may23InstanceStruct *chartInstance);
static void c3_PreshotMove(SFc3_may23InstanceStruct *chartInstance);
static void c3_ShotReady(SFc3_may23InstanceStruct *chartInstance);
static void c3_Shot(SFc3_may23InstanceStruct *chartInstance);
static void c3_ShotEnd(SFc3_may23InstanceStruct *chartInstance);
static void c3_enter_atomic_Fail(SFc3_may23InstanceStruct *chartInstance);
static void c3_Fail(SFc3_may23InstanceStruct *chartInstance);
static real_T c3_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance, const
  mxArray *c3_b_barrier_target_row, const char_T *c3_identifier);
static real_T c3_b_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static boolean_T c3_c_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_b_logging_enable, const char_T *c3_identifier);
static boolean_T c3_d_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static uint32_T c3_e_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_b_e_Trial_EndEventCounter, const char_T *c3_identifier);
static uint32_T c3_f_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static uint8_T c3_g_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_b_is_active_c3_may23, const char_T *c3_identifier);
static uint8_T c3_h_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static void c3_i_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance, const
  mxArray *c3_b_dataWrittenToVector, const char_T *c3_identifier, boolean_T
  c3_y[21]);
static void c3_j_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance, const
  mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId, boolean_T c3_y[21]);
static const mxArray *c3_k_emlrt_marshallIn(SFc3_may23InstanceStruct
  *chartInstance, const mxArray *c3_b_setSimStateSideEffectsInfo, const char_T
  *c3_identifier);
static const mxArray *c3_l_emlrt_marshallIn(SFc3_may23InstanceStruct
  *chartInstance, const mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId);
static uint32_T c3__u32_d_(SFc3_may23InstanceStruct *chartInstance, real_T c3_b,
  int32_T c3_EMLOvCount_src_loc, uint32_T c3_ssid_src_loc, int32_T
  c3_offset_src_loc, int32_T c3_length_src_loc);
static uint32_T c3__u32_add__(SFc3_may23InstanceStruct *chartInstance, uint32_T
  c3_b, uint32_T c3_c, int32_T c3_EMLOvCount_src_loc, uint32_T c3_ssid_src_loc,
  int32_T c3_offset_src_loc, int32_T c3_length_src_loc);
static void init_dsm_address_info(SFc3_may23InstanceStruct *chartInstance);
static void init_simulink_io_address(SFc3_may23InstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c3_may23(SFc3_may23InstanceStruct *chartInstance)
{
  sim_mode_is_external(chartInstance->S);
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c3_doSetSimStateSideEffects = 0U;
  chartInstance->c3_setSimStateSideEffectsInfo = NULL;
  *chartInstance->c3_temporalCounter_i1 = 0U;
  *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
  *chartInstance->c3_temporalCounter_i1 = 0U;
  *chartInstance->c3_temporalCounter_i1 = 0U;
  *chartInstance->c3_temporalCounter_i1 = 0U;
  *chartInstance->c3_temporalCounter_i1 = 0U;
  *chartInstance->c3_temporalCounter_i1 = 0U;
  *chartInstance->c3_temporalCounter_i1 = 0U;
  *chartInstance->c3_temporalCounter_i1 = 0U;
  *chartInstance->c3_is_active_c3_may23 = 0U;
  *chartInstance->c3_is_c3_may23 = c3_IN_NO_ACTIVE_CHILD;
  *chartInstance->c3_e_Trial_StartEventCounter = 0U;
  *chartInstance->c3_e_Trial_Start = false;
  *chartInstance->c3_e_Trial_EndEventCounter = 0U;
  *chartInstance->c3_e_Trial_End = false;
  *chartInstance->c3_presentTicks = 0U;
  *chartInstance->c3_elapsedTicks = 0U;
  *chartInstance->c3_previousTicks = 0U;
}

static void initialize_params_c3_may23(SFc3_may23InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void enable_c3_may23(SFc3_may23InstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
  *chartInstance->c3_presentTicks = (uint32_T)muDoubleScalarFloor((_sfTime_ -
    sf_get_start_time(chartInstance->S)) / 0.00025 + 0.5);
  *chartInstance->c3_previousTicks = *chartInstance->c3_presentTicks;
}

static void disable_c3_may23(SFc3_may23InstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
  *chartInstance->c3_presentTicks = (uint32_T)muDoubleScalarFloor((_sfTime_ -
    sf_get_start_time(chartInstance->S)) / 0.00025 + 0.5);
  *chartInstance->c3_elapsedTicks = *chartInstance->c3_presentTicks -
    *chartInstance->c3_previousTicks;
  *chartInstance->c3_previousTicks = *chartInstance->c3_presentTicks;
  *chartInstance->c3_temporalCounter_i1 += *chartInstance->c3_elapsedTicks;
}

static void c3_update_jit_animation_state_c3_may23(SFc3_may23InstanceStruct
  *chartInstance)
{
  chartInstance->c3_JITStateAnimation[0U] = (uint8_T)
    (*chartInstance->c3_is_c3_may23 == c3_IN_Inter_Trial_State);
  chartInstance->c3_JITStateAnimation[1U] = (uint8_T)
    (*chartInstance->c3_is_c3_may23 == c3_IN_Initialize);
  chartInstance->c3_JITStateAnimation[2U] = (uint8_T)
    (*chartInstance->c3_is_c3_may23 == c3_IN_Main_Trial);
  chartInstance->c3_JITStateAnimation[3U] = (uint8_T)
    (*chartInstance->c3_is_Main_Trial == c3_IN_StartOn);
  chartInstance->c3_JITStateAnimation[4U] = (uint8_T)
    (*chartInstance->c3_is_Main_Trial == c3_IN_StartHold);
  chartInstance->c3_JITStateAnimation[5U] = (uint8_T)
    (*chartInstance->c3_is_Main_Trial == c3_IN_PreshotStart);
  chartInstance->c3_JITStateAnimation[6U] = (uint8_T)
    (*chartInstance->c3_is_Main_Trial == c3_IN_ShotReady);
  chartInstance->c3_JITStateAnimation[7U] = (uint8_T)
    (*chartInstance->c3_is_Main_Trial == c3_IN_ShotSet);
  chartInstance->c3_JITStateAnimation[8U] = (uint8_T)
    (*chartInstance->c3_is_Main_Trial == c3_IN_Shot);
  chartInstance->c3_JITStateAnimation[9U] = (uint8_T)
    (*chartInstance->c3_is_Main_Trial == c3_IN_Fail);
  chartInstance->c3_JITStateAnimation[10U] = (uint8_T)
    (*chartInstance->c3_is_Main_Trial == c3_IN_PreshotMove);
  chartInstance->c3_JITStateAnimation[11U] = (uint8_T)
    (*chartInstance->c3_is_Main_Trial == c3_IN_Success);
  chartInstance->c3_JITStateAnimation[12U] = (uint8_T)
    (*chartInstance->c3_is_Main_Trial == c3_IN_ShotEnd);
  chartInstance->c3_JITStateAnimation[13U] = (uint8_T)
    (*chartInstance->c3_is_Main_Trial == c3_IN_PuckMoving);
}

static void c3_do_animation_call_c3_may23(SFc3_may23InstanceStruct
  *chartInstance)
{
  sfDoAnimationWrapper(chartInstance->S, false, true);
  sfDoAnimationWrapper(chartInstance->S, false, false);
}

static void ext_mode_exec_c3_may23(SFc3_may23InstanceStruct *chartInstance)
{
  c3_update_jit_animation_state_c3_may23(chartInstance);
  c3_do_animation_call_c3_may23(chartInstance);
}

static const mxArray *get_sim_state_c3_may23(SFc3_may23InstanceStruct
  *chartInstance)
{
  const mxArray *c3_st;
  const mxArray *c3_y = NULL;
  const mxArray *c3_b_y = NULL;
  const mxArray *c3_c_y = NULL;
  const mxArray *c3_d_y = NULL;
  const mxArray *c3_e_y = NULL;
  const mxArray *c3_f_y = NULL;
  const mxArray *c3_g_y = NULL;
  const mxArray *c3_h_y = NULL;
  const mxArray *c3_i_y = NULL;
  const mxArray *c3_j_y = NULL;
  const mxArray *c3_k_y = NULL;
  const mxArray *c3_l_y = NULL;
  const mxArray *c3_m_y = NULL;
  const mxArray *c3_n_y = NULL;
  const mxArray *c3_o_y = NULL;
  const mxArray *c3_p_y = NULL;
  const mxArray *c3_q_y = NULL;
  const mxArray *c3_r_y = NULL;
  const mxArray *c3_s_y = NULL;
  const mxArray *c3_t_y = NULL;
  const mxArray *c3_u_y = NULL;
  const mxArray *c3_v_y = NULL;
  const mxArray *c3_w_y = NULL;
  const mxArray *c3_x_y = NULL;
  const mxArray *c3_y_y = NULL;
  const mxArray *c3_ab_y = NULL;
  const mxArray *c3_bb_y = NULL;
  const mxArray *c3_cb_y = NULL;
  const mxArray *c3_db_y = NULL;
  const mxArray *c3_eb_y = NULL;
  const mxArray *c3_fb_y = NULL;
  const mxArray *c3_gb_y = NULL;
  c3_st = NULL;
  c3_st = NULL;
  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_createcellmatrix(31, 1), false);
  c3_b_y = NULL;
  sf_mex_assign(&c3_b_y, sf_mex_create("y", chartInstance->c3_barrier_target_row,
    0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 0, c3_b_y);
  c3_c_y = NULL;
  sf_mex_assign(&c3_c_y, sf_mex_create("y",
    chartInstance->c3_barrier_target_state, 0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 1, c3_c_y);
  c3_d_y = NULL;
  sf_mex_assign(&c3_d_y, sf_mex_create("y", chartInstance->c3_cursor_row, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 2, c3_d_y);
  c3_e_y = NULL;
  sf_mex_assign(&c3_e_y, sf_mex_create("y", chartInstance->c3_cursor_state, 0,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 3, c3_e_y);
  c3_f_y = NULL;
  sf_mex_assign(&c3_f_y, sf_mex_create("y", chartInstance->c3_event_code, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 4, c3_f_y);
  c3_g_y = NULL;
  sf_mex_assign(&c3_g_y, sf_mex_create("y", chartInstance->c3_goal_target_row, 0,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 5, c3_g_y);
  c3_h_y = NULL;
  sf_mex_assign(&c3_h_y, sf_mex_create("y", chartInstance->c3_goal_target_state,
    0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 6, c3_h_y);
  c3_i_y = NULL;
  sf_mex_assign(&c3_i_y, sf_mex_create("y", chartInstance->c3_load_row, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 7, c3_i_y);
  c3_j_y = NULL;
  sf_mex_assign(&c3_j_y, sf_mex_create("y", chartInstance->c3_logging_enable, 11,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 8, c3_j_y);
  c3_k_y = NULL;
  sf_mex_assign(&c3_k_y, sf_mex_create("y", chartInstance->c3_preshot_area_row,
    0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 9, c3_k_y);
  c3_l_y = NULL;
  sf_mex_assign(&c3_l_y, sf_mex_create("y", chartInstance->c3_preshot_area_state,
    0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 10, c3_l_y);
  c3_m_y = NULL;
  sf_mex_assign(&c3_m_y, sf_mex_create("y", chartInstance->c3_puck_row, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 11, c3_m_y);
  c3_n_y = NULL;
  sf_mex_assign(&c3_n_y, sf_mex_create("y", chartInstance->c3_puck_state, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 12, c3_n_y);
  c3_o_y = NULL;
  sf_mex_assign(&c3_o_y, sf_mex_create("y", chartInstance->c3_start_target_row,
    0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 13, c3_o_y);
  c3_p_y = NULL;
  sf_mex_assign(&c3_p_y, sf_mex_create("y", chartInstance->c3_start_target_state,
    0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 14, c3_p_y);
  c3_q_y = NULL;
  sf_mex_assign(&c3_q_y, sf_mex_create("y", chartInstance->c3_goal_time, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 15, c3_q_y);
  c3_r_y = NULL;
  sf_mex_assign(&c3_r_y, sf_mex_create("y", chartInstance->c3_shot_ready_time, 0,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 16, c3_r_y);
  c3_s_y = NULL;
  sf_mex_assign(&c3_s_y, sf_mex_create("y", chartInstance->c3_shot_set_time, 0,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 17, c3_s_y);
  c3_t_y = NULL;
  sf_mex_assign(&c3_t_y, sf_mex_create("y", chartInstance->c3_shot_time, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 18, c3_t_y);
  c3_u_y = NULL;
  sf_mex_assign(&c3_u_y, sf_mex_create("y", chartInstance->c3_start_hold_time, 0,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 19, c3_u_y);
  c3_v_y = NULL;
  sf_mex_assign(&c3_v_y, sf_mex_create("y", chartInstance->c3_trial_duration, 0,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 20, c3_v_y);
  c3_w_y = NULL;
  sf_mex_assign(&c3_w_y, sf_mex_create("y", chartInstance->c3_e_Trial_End, 11,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 21, c3_w_y);
  c3_x_y = NULL;
  sf_mex_assign(&c3_x_y, sf_mex_create("y", chartInstance->c3_e_Trial_Start, 11,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 22, c3_x_y);
  c3_y_y = NULL;
  sf_mex_assign(&c3_y_y, sf_mex_create("y",
    chartInstance->c3_e_Trial_EndEventCounter, 7, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 23, c3_y_y);
  c3_ab_y = NULL;
  sf_mex_assign(&c3_ab_y, sf_mex_create("y",
    chartInstance->c3_e_Trial_StartEventCounter, 7, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 24, c3_ab_y);
  c3_bb_y = NULL;
  sf_mex_assign(&c3_bb_y, sf_mex_create("y",
    chartInstance->c3_is_active_c3_may23, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 25, c3_bb_y);
  c3_cb_y = NULL;
  sf_mex_assign(&c3_cb_y, sf_mex_create("y", chartInstance->c3_is_c3_may23, 3,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 26, c3_cb_y);
  c3_db_y = NULL;
  sf_mex_assign(&c3_db_y, sf_mex_create("y", chartInstance->c3_is_Main_Trial, 3,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 27, c3_db_y);
  c3_eb_y = NULL;
  sf_mex_assign(&c3_eb_y, sf_mex_create("y",
    chartInstance->c3_temporalCounter_i1, 7, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 28, c3_eb_y);
  c3_fb_y = NULL;
  sf_mex_assign(&c3_fb_y, sf_mex_create("y", chartInstance->c3_previousTicks, 7,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c3_y, 29, c3_fb_y);
  c3_gb_y = NULL;
  sf_mex_assign(&c3_gb_y, sf_mex_create("y",
    chartInstance->c3_dataWrittenToVector, 11, 0U, 1U, 0U, 1, 21), false);
  sf_mex_setcell(c3_y, 30, c3_gb_y);
  sf_mex_assign(&c3_st, c3_y, false);
  return c3_st;
}

static void set_sim_state_c3_may23(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_st)
{
  const mxArray *c3_u;
  c3_u = sf_mex_dup(c3_st);
  *chartInstance->c3_barrier_target_row = c3_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 0)), "barrier_target_row");
  *chartInstance->c3_barrier_target_state = c3_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 1)), "barrier_target_state");
  *chartInstance->c3_cursor_row = c3_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c3_u, 2)), "cursor_row");
  *chartInstance->c3_cursor_state = c3_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 3)), "cursor_state");
  *chartInstance->c3_event_code = c3_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c3_u, 4)), "event_code");
  *chartInstance->c3_goal_target_row = c3_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 5)), "goal_target_row");
  *chartInstance->c3_goal_target_state = c3_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 6)), "goal_target_state");
  *chartInstance->c3_load_row = c3_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c3_u, 7)), "load_row");
  *chartInstance->c3_logging_enable = c3_c_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 8)), "logging_enable");
  *chartInstance->c3_preshot_area_row = c3_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 9)), "preshot_area_row");
  *chartInstance->c3_preshot_area_state = c3_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 10)), "preshot_area_state");
  *chartInstance->c3_puck_row = c3_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c3_u, 11)), "puck_row");
  *chartInstance->c3_puck_state = c3_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c3_u, 12)), "puck_state");
  *chartInstance->c3_start_target_row = c3_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 13)), "start_target_row");
  *chartInstance->c3_start_target_state = c3_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 14)), "start_target_state");
  *chartInstance->c3_goal_time = c3_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c3_u, 15)), "goal_time");
  *chartInstance->c3_shot_ready_time = c3_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 16)), "shot_ready_time");
  *chartInstance->c3_shot_set_time = c3_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 17)), "shot_set_time");
  *chartInstance->c3_shot_time = c3_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c3_u, 18)), "shot_time");
  *chartInstance->c3_start_hold_time = c3_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 19)), "start_hold_time");
  *chartInstance->c3_trial_duration = c3_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 20)), "trial_duration");
  *chartInstance->c3_e_Trial_End = c3_c_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 21)), "e_Trial_End");
  *chartInstance->c3_e_Trial_Start = c3_c_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 22)), "e_Trial_Start");
  *chartInstance->c3_e_Trial_EndEventCounter = c3_e_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c3_u, 23)),
     "e_Trial_EndEventCounter");
  *chartInstance->c3_e_Trial_StartEventCounter = c3_e_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c3_u, 24)),
     "e_Trial_StartEventCounter");
  *chartInstance->c3_is_active_c3_may23 = c3_g_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 25)), "is_active_c3_may23");
  *chartInstance->c3_is_c3_may23 = c3_g_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 26)), "is_c3_may23");
  *chartInstance->c3_is_Main_Trial = c3_g_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 27)), "is_Main_Trial");
  *chartInstance->c3_temporalCounter_i1 = c3_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 28)), "temporalCounter_i1");
  *chartInstance->c3_previousTicks = c3_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c3_u, 29)), "previousTicks");
  c3_i_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c3_u, 30)),
                        "dataWrittenToVector",
                        chartInstance->c3_dataWrittenToVector);
  sf_mex_assign(&chartInstance->c3_setSimStateSideEffectsInfo,
                c3_k_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c3_u, 31)), "setSimStateSideEffectsInfo"), true);
  sf_mex_destroy(&c3_u);
  chartInstance->c3_doSetSimStateSideEffects = 1U;
  c3_update_jit_animation_state_c3_may23(chartInstance);
  sf_mex_destroy(&c3_st);
}

static void c3_set_sim_state_side_effects_c3_may23(SFc3_may23InstanceStruct
  *chartInstance)
{
  if (chartInstance->c3_doSetSimStateSideEffects != 0) {
    if ((*chartInstance->c3_is_c3_may23 == c3_IN_Inter_Trial_State) &&
        (sf_mex_sub(chartInstance->c3_setSimStateSideEffectsInfo,
                    "setSimStateSideEffectsInfo", 1, 3) == 0.0)) {
      *chartInstance->c3_temporalCounter_i1 = 0U;
    }

    if ((*chartInstance->c3_is_Main_Trial == c3_IN_Fail) && (sf_mex_sub
         (chartInstance->c3_setSimStateSideEffectsInfo,
          "setSimStateSideEffectsInfo", 1, 5) == 0.0)) {
      *chartInstance->c3_temporalCounter_i1 = 0U;
    }

    if ((*chartInstance->c3_is_Main_Trial == c3_IN_Shot) && (sf_mex_sub
         (chartInstance->c3_setSimStateSideEffectsInfo,
          "setSimStateSideEffectsInfo", 1, 9) == 0.0)) {
      *chartInstance->c3_temporalCounter_i1 = 0U;
    }

    if ((*chartInstance->c3_is_Main_Trial == c3_IN_ShotReady) && (sf_mex_sub
         (chartInstance->c3_setSimStateSideEffectsInfo,
          "setSimStateSideEffectsInfo", 1, 11) == 0.0)) {
      *chartInstance->c3_temporalCounter_i1 = 0U;
    }

    if ((*chartInstance->c3_is_Main_Trial == c3_IN_ShotSet) && (sf_mex_sub
         (chartInstance->c3_setSimStateSideEffectsInfo,
          "setSimStateSideEffectsInfo", 1, 12) == 0.0)) {
      *chartInstance->c3_temporalCounter_i1 = 0U;
    }

    if ((*chartInstance->c3_is_Main_Trial == c3_IN_StartHold) && (sf_mex_sub
         (chartInstance->c3_setSimStateSideEffectsInfo,
          "setSimStateSideEffectsInfo", 1, 13) == 0.0)) {
      *chartInstance->c3_temporalCounter_i1 = 0U;
    }

    if ((*chartInstance->c3_is_Main_Trial == c3_IN_StartOn) && (sf_mex_sub
         (chartInstance->c3_setSimStateSideEffectsInfo,
          "setSimStateSideEffectsInfo", 1, 14) == 0.0)) {
      *chartInstance->c3_temporalCounter_i1 = 0U;
    }

    if ((*chartInstance->c3_is_Main_Trial == c3_IN_Success) && (sf_mex_sub
         (chartInstance->c3_setSimStateSideEffectsInfo,
          "setSimStateSideEffectsInfo", 1, 15) == 0.0)) {
      *chartInstance->c3_temporalCounter_i1 = 0U;
    }

    chartInstance->c3_doSetSimStateSideEffects = 0U;
  }
}

static void finalize_c3_may23(SFc3_may23InstanceStruct *chartInstance)
{
  sf_mex_destroy(&chartInstance->c3_setSimStateSideEffectsInfo);
}

static void sf_gateway_c3_may23(SFc3_may23InstanceStruct *chartInstance)
{
  int32_T c3_inputEventFiredFlag;
  c3_set_sim_state_side_effects_c3_may23(chartInstance);
  chartInstance->c3_JITTransitionAnimation[0] = 0U;
  chartInstance->c3_JITTransitionAnimation[1] = 0U;
  chartInstance->c3_JITTransitionAnimation[2] = 0U;
  chartInstance->c3_JITTransitionAnimation[3] = 0U;
  chartInstance->c3_JITTransitionAnimation[4] = 0U;
  chartInstance->c3_JITTransitionAnimation[5] = 0U;
  chartInstance->c3_JITTransitionAnimation[6] = 0U;
  chartInstance->c3_JITTransitionAnimation[7] = 0U;
  chartInstance->c3_JITTransitionAnimation[8] = 0U;
  chartInstance->c3_JITTransitionAnimation[9] = 0U;
  chartInstance->c3_JITTransitionAnimation[10] = 0U;
  chartInstance->c3_JITTransitionAnimation[11] = 0U;
  chartInstance->c3_JITTransitionAnimation[12] = 0U;
  chartInstance->c3_JITTransitionAnimation[13] = 0U;
  chartInstance->c3_JITTransitionAnimation[14] = 0U;
  chartInstance->c3_JITTransitionAnimation[15] = 0U;
  chartInstance->c3_JITTransitionAnimation[16] = 0U;
  chartInstance->c3_JITTransitionAnimation[17] = 0U;
  chartInstance->c3_JITTransitionAnimation[18] = 0U;
  chartInstance->c3_JITTransitionAnimation[19] = 0U;
  chartInstance->c3_JITTransitionAnimation[20] = 0U;
  chartInstance->c3_JITTransitionAnimation[21] = 0U;
  chartInstance->c3_JITTransitionAnimation[22] = 0U;
  chartInstance->c3_JITTransitionAnimation[23] = 0U;
  chartInstance->c3_JITTransitionAnimation[24] = 0U;
  _sfTime_ = sf_get_time(chartInstance->S);
  *chartInstance->c3_presentTicks = (uint32_T)muDoubleScalarFloor((_sfTime_ -
    sf_get_start_time(chartInstance->S)) / 0.00025 + 0.5);
  *chartInstance->c3_elapsedTicks = *chartInstance->c3_presentTicks -
    *chartInstance->c3_previousTicks;
  *chartInstance->c3_previousTicks = *chartInstance->c3_presentTicks;
  *chartInstance->c3_temporalCounter_i1 += *chartInstance->c3_elapsedTicks;
  c3_inputEventFiredFlag = 0;
  if (*chartInstance->c3_e_clk == 1) {
    c3_inputEventFiredFlag = 1;
    *chartInstance->c3_sfEvent = c3_event_e_clk;
    c3_chartstep_c3_may23(chartInstance);
  }

  if (*chartInstance->c3_e_ExitTrialNow != 0) {
    c3_inputEventFiredFlag = 1;
    *chartInstance->c3_sfEvent = c3_event_e_ExitTrialNow;
    c3_chartstep_c3_may23(chartInstance);
  }

  if (*chartInstance->c3_e_Puck_Stopped != 0) {
    c3_inputEventFiredFlag = 1;
    *chartInstance->c3_sfEvent = c3_event_e_Puck_Stopped;
    c3_chartstep_c3_may23(chartInstance);
  }

  if (*chartInstance->c3_e_Puck_Hit != 0) {
    c3_inputEventFiredFlag = 1;
    *chartInstance->c3_sfEvent = c3_event_e_Puck_Hit;
    c3_chartstep_c3_may23(chartInstance);
  }

  if (c3_inputEventFiredFlag != 0) {
    if (*chartInstance->c3_e_Trial_StartEventCounter > 0U) {
      *chartInstance->c3_e_Trial_Start = !*chartInstance->c3_e_Trial_Start;
      (*chartInstance->c3_e_Trial_StartEventCounter)--;
    }

    if (*chartInstance->c3_e_Trial_EndEventCounter > 0U) {
      *chartInstance->c3_e_Trial_End = !*chartInstance->c3_e_Trial_End;
      (*chartInstance->c3_e_Trial_EndEventCounter)--;
    }
  }

  c3_update_jit_animation_state_c3_may23(chartInstance);
  c3_do_animation_call_c3_may23(chartInstance);
}

static void mdl_start_c3_may23(SFc3_may23InstanceStruct *chartInstance)
{
  setLegacyDebuggerFlag(chartInstance->S, false);
  setDebuggerFlag(chartInstance->S, true);
  sim_mode_is_external(chartInstance->S);
}

static void c3_chartstep_c3_may23(SFc3_may23InstanceStruct *chartInstance)
{
  const mxArray *c3_y = NULL;
  const mxArray *c3_b_y = NULL;
  if (*chartInstance->c3_is_active_c3_may23 == 0U) {
    *chartInstance->c3_is_active_c3_may23 = 1U;
    chartInstance->c3_JITTransitionAnimation[1U] = 1U;
    *chartInstance->c3_is_c3_may23 = c3_IN_Initialize;
    *chartInstance->c3_logging_enable = true;
    chartInstance->c3_dataWrittenToVector[0U] = true;
    *chartInstance->c3_start_target_row = (*chartInstance->c3_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 77, 25, 52U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 77U, 25U, START_ROW), 1,
      50) - 1];
    chartInstance->c3_dataWrittenToVector[10U] = true;
    *chartInstance->c3_preshot_area_row = (*chartInstance->c3_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 123, 27, 52U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 123U, 27U, PRESHOT_ROW), 1,
      50) - 1];
    chartInstance->c3_dataWrittenToVector[14U] = true;
    *chartInstance->c3_cursor_row = (*chartInstance->c3_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 165, 26, 52U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 165U, 26U, CURSOR_ROW), 1,
      50) - 1];
    chartInstance->c3_dataWrittenToVector[2U] = true;
    *chartInstance->c3_puck_row = (*chartInstance->c3_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 204, 24, 52U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 204U, 24U, PUCK_ROW), 1,
      50) - 1];
    chartInstance->c3_dataWrittenToVector[4U] = true;
    *chartInstance->c3_barrier_target_row = (*chartInstance->c3_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 251, 27, 52U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 251U, 27U, BARRIER_ROW), 1,
      50) - 1];
    chartInstance->c3_dataWrittenToVector[8U] = true;
    *chartInstance->c3_goal_target_row = (*chartInstance->c3_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 298, 24, 52U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 298U, 24U, GOAL_ROW), 1,
      50) - 1];
    chartInstance->c3_dataWrittenToVector[12U] = true;
    *chartInstance->c3_load_row = (*chartInstance->c3_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 335, 24, 52U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 335U, 24U, LOAD_ROW), 1,
      50) - 1];
    chartInstance->c3_dataWrittenToVector[6U] = true;
    *chartInstance->c3_trial_duration = (*chartInstance->c3_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 378, 23, 52U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 378U, 23U, SECONDS), 1, 50)
      - 1];
    chartInstance->c3_dataWrittenToVector[7U] = true;
    *chartInstance->c3_start_hold_time = (*chartInstance->c3_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 421, 31, 52U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 421U, 31U, START_HOLD_TIME),
      1, 50) - 1];
    chartInstance->c3_dataWrittenToVector[16U] = true;
    *chartInstance->c3_shot_ready_time = (*chartInstance->c3_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 472, 31, 52U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 472U, 31U, SHOT_READY_TIME),
      1, 50) - 1];
    chartInstance->c3_dataWrittenToVector[18U] = true;
    *chartInstance->c3_shot_set_time = (*chartInstance->c3_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 521, 29, 52U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 521U, 29U, SHOT_SET_TIME),
      1, 50) - 1];
    chartInstance->c3_dataWrittenToVector[17U] = true;
    *chartInstance->c3_shot_time = (*chartInstance->c3_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 564, 25, 52U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 564U, 25U, SHOT_TIME), 1,
      50) - 1];
    chartInstance->c3_dataWrittenToVector[20U] = true;
    *chartInstance->c3_goal_time = (*chartInstance->c3_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 603, 25, 52U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 603U, 25U, GOAL_TIME), 1,
      50) - 1];
    chartInstance->c3_dataWrittenToVector[19U] = true;
  } else {
    switch (*chartInstance->c3_is_c3_may23) {
     case c3_IN_Initialize:
      *chartInstance->c3_logging_enable = true;
      chartInstance->c3_dataWrittenToVector[0U] = true;
      chartInstance->c3_JITTransitionAnimation[2U] = 1U;
      *chartInstance->c3_event_code = E_START_TARGET_ON;
      chartInstance->c3_dataWrittenToVector[1U] = true;
      if (!chartInstance->c3_dataWrittenToVector[1U]) {
        sf_read_before_write_error(chartInstance->S, 59U, 11U, 1, 10);
      }

      sf_mex_printf("%s =\\n", "event_code");
      c3_y = NULL;
      sf_mex_assign(&c3_y, sf_mex_create("y", chartInstance->c3_event_code, 0,
        0U, 0U, 0U, 0), false);
      sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_y);
      *chartInstance->c3_is_c3_may23 = c3_IN_NO_ACTIVE_CHILD;
      *chartInstance->c3_is_c3_may23 = c3_IN_Main_Trial;
      *chartInstance->c3_is_Main_Trial = c3_IN_StartOn;
      *chartInstance->c3_temporalCounter_i1 = 0U;
      c3_enter_atomic_StartOn(chartInstance);
      break;

     case c3_IN_Inter_Trial_State:
      if (*chartInstance->c3_temporalCounter_i1 >= 4000U) {
        chartInstance->c3_JITTransitionAnimation[3U] = 1U;
        *chartInstance->c3_is_c3_may23 = c3_IN_NO_ACTIVE_CHILD;
        *chartInstance->c3_event_code = E_START_TARGET_ON;
        chartInstance->c3_dataWrittenToVector[1U] = true;
        if (!chartInstance->c3_dataWrittenToVector[1U]) {
          sf_read_before_write_error(chartInstance->S, 59U, 12U, 16, 10);
        }

        sf_mex_printf("%s =\\n", "event_code");
        c3_b_y = NULL;
        sf_mex_assign(&c3_b_y, sf_mex_create("y", chartInstance->c3_event_code,
          0, 0U, 0U, 0U, 0), false);
        sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_b_y);
        *chartInstance->c3_is_c3_may23 = c3_IN_Main_Trial;
        *chartInstance->c3_is_Main_Trial = c3_IN_StartOn;
        *chartInstance->c3_temporalCounter_i1 = 0U;
        c3_enter_atomic_StartOn(chartInstance);
      }
      break;

     case c3_IN_Main_Trial:
      c3_Main_Trial(chartInstance);
      break;

     default:
      /* Unreachable state, for coverage only */
      *chartInstance->c3_is_c3_may23 = c3_IN_NO_ACTIVE_CHILD;
      break;
    }
  }
}

static void initSimStructsc3_may23(SFc3_may23InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c3_Main_Trial(SFc3_may23InstanceStruct *chartInstance)
{
  const mxArray *c3_y = NULL;
  const mxArray *c3_b_y = NULL;
  const mxArray *c3_c_y = NULL;
  const mxArray *c3_d_y = NULL;
  const mxArray *c3_e_y = NULL;
  const mxArray *c3_f_y = NULL;
  const mxArray *c3_g_y = NULL;
  if (*chartInstance->c3_sfEvent == c3_event_e_ExitTrialNow) {
    chartInstance->c3_JITTransitionAnimation[4U] = 1U;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_c3_may23 = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_c3_may23 = c3_IN_Inter_Trial_State;
    *chartInstance->c3_temporalCounter_i1 = 0U;
    *chartInstance->c3_e_Trial_EndEventCounter = c3__u32_add__(chartInstance,
      *chartInstance->c3_e_Trial_EndEventCounter, 1U, 0, 1U, 26, 11);
  } else {
    switch (*chartInstance->c3_is_Main_Trial) {
     case c3_IN_Fail:
      c3_Fail(chartInstance);
      break;

     case c3_IN_PreshotMove:
      c3_PreshotMove(chartInstance);
      break;

     case c3_IN_PreshotStart:
      c3_PreshotStart(chartInstance);
      break;

     case c3_IN_PuckMoving:
      if (*chartInstance->c3_sfEvent == c3_event_e_Puck_Stopped) {
        chartInstance->c3_JITTransitionAnimation[22U] = 1U;
        *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
        *chartInstance->c3_is_Main_Trial = c3_IN_ShotEnd;
      }
      break;

     case c3_IN_Shot:
      c3_Shot(chartInstance);
      break;

     case c3_IN_ShotEnd:
      c3_ShotEnd(chartInstance);
      break;

     case c3_IN_ShotReady:
      c3_ShotReady(chartInstance);
      break;

     case c3_IN_ShotSet:
      *chartInstance->c3_preshot_area_state = 0.0;
      chartInstance->c3_dataWrittenToVector[15U] = true;
      *chartInstance->c3_start_target_state = 3.0;
      chartInstance->c3_dataWrittenToVector[11U] = true;
      if (!chartInstance->c3_dataWrittenToVector[10U]) {
        sf_read_before_write_error(chartInstance->S, 67U, 238U, 14, 16);
      }

      sf_eml_array_bounds_check(NULL, chartInstance->S, 238U, 14, 16,
        MAX_uint32_T, (int32_T)sf_integer_check(chartInstance->S, 238U, 14U, 16U,
        *chartInstance->c3_start_target_row), 1, 64);
      if ((*chartInstance->c3_HandInTarget)[(int32_T)
          *chartInstance->c3_start_target_row - 1] == 0.0) {
        chartInstance->c3_JITTransitionAnimation[12U] = 1U;
        *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
        *chartInstance->c3_event_code = E_START_TARGET_ON;
        chartInstance->c3_dataWrittenToVector[1U] = true;
        if (!chartInstance->c3_dataWrittenToVector[1U]) {
          sf_read_before_write_error(chartInstance->S, 59U, 238U, 40, 10);
        }

        sf_mex_printf("%s =\\n", "event_code");
        c3_d_y = NULL;
        sf_mex_assign(&c3_d_y, sf_mex_create("y", chartInstance->c3_event_code,
          0, 0U, 0U, 0U, 0), false);
        sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_d_y);
        *chartInstance->c3_is_Main_Trial = c3_IN_StartOn;
        *chartInstance->c3_temporalCounter_i1 = 0U;
        c3_enter_atomic_StartOn(chartInstance);
      } else {
        if (!chartInstance->c3_dataWrittenToVector[17U]) {
          sf_read_before_write_error(chartInstance->S, 48U, 240U, 6, 13);
        }

        if (*chartInstance->c3_temporalCounter_i1 >= c3__u32_d_(chartInstance,
             muDoubleScalarCeil(*chartInstance->c3_shot_set_time / 0.00025 -
                                2.5000000000000003E-12), 0, 240U, 0, 24)) {
          chartInstance->c3_JITTransitionAnimation[13U] = 1U;
          *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
          *chartInstance->c3_event_code = E_SHOT_GO;
          chartInstance->c3_dataWrittenToVector[1U] = true;
          if (!chartInstance->c3_dataWrittenToVector[1U]) {
            sf_read_before_write_error(chartInstance->S, 59U, 240U, 27, 10);
          }

          sf_mex_printf("%s =\\n", "event_code");
          c3_e_y = NULL;
          sf_mex_assign(&c3_e_y, sf_mex_create("y", chartInstance->c3_event_code,
            0, 0U, 0U, 0U, 0), false);
          sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_e_y);
          *chartInstance->c3_is_Main_Trial = c3_IN_Shot;
          *chartInstance->c3_temporalCounter_i1 = 0U;
          *chartInstance->c3_start_target_state = 0.0;
          chartInstance->c3_dataWrittenToVector[11U] = true;
          *chartInstance->c3_cursor_state = 2.0;
          chartInstance->c3_dataWrittenToVector[3U] = true;
          *chartInstance->c3_puck_state = 2.0;
          chartInstance->c3_dataWrittenToVector[5U] = true;
          *chartInstance->c3_goal_target_state = 2.0;
          chartInstance->c3_dataWrittenToVector[13U] = true;
          *chartInstance->c3_barrier_target_state = 2.0;
          chartInstance->c3_dataWrittenToVector[9U] = true;
        }
      }
      break;

     case c3_IN_StartHold:
      if (!chartInstance->c3_dataWrittenToVector[10U]) {
        sf_read_before_write_error(chartInstance->S, 67U, 175U, 14, 16);
      }

      sf_eml_array_bounds_check(NULL, chartInstance->S, 175U, 14, 16,
        MAX_uint32_T, (int32_T)sf_integer_check(chartInstance->S, 175U, 14U, 16U,
        *chartInstance->c3_start_target_row), 1, 64);
      if ((*chartInstance->c3_HandInTarget)[(int32_T)
          *chartInstance->c3_start_target_row - 1] == 0.0) {
        chartInstance->c3_JITTransitionAnimation[6U] = 1U;
        *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
        *chartInstance->c3_event_code = E_START_TARGET_ON;
        chartInstance->c3_dataWrittenToVector[1U] = true;
        if (!chartInstance->c3_dataWrittenToVector[1U]) {
          sf_read_before_write_error(chartInstance->S, 59U, 175U, 40, 10);
        }

        sf_mex_printf("%s =\\n", "event_code");
        c3_y = NULL;
        sf_mex_assign(&c3_y, sf_mex_create("y", chartInstance->c3_event_code, 0,
          0U, 0U, 0U, 0), false);
        sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_y);
        *chartInstance->c3_is_Main_Trial = c3_IN_StartOn;
        *chartInstance->c3_temporalCounter_i1 = 0U;
        c3_enter_atomic_StartOn(chartInstance);
      } else {
        if (!chartInstance->c3_dataWrittenToVector[16U]) {
          sf_read_before_write_error(chartInstance->S, 50U, 229U, 6, 15);
        }

        if (*chartInstance->c3_temporalCounter_i1 >= c3__u32_d_(chartInstance,
             muDoubleScalarCeil(*chartInstance->c3_start_hold_time / 0.00025 -
                                2.5000000000000003E-12), 0, 229U, 0, 26)) {
          chartInstance->c3_JITTransitionAnimation[7U] = 1U;
          *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
          *chartInstance->c3_event_code = E_TRIAL_START;
          chartInstance->c3_dataWrittenToVector[1U] = true;
          if (!chartInstance->c3_dataWrittenToVector[1U]) {
            sf_read_before_write_error(chartInstance->S, 59U, 229U, 29, 10);
          }

          sf_mex_printf("%s =\\n", "event_code");
          c3_c_y = NULL;
          sf_mex_assign(&c3_c_y, sf_mex_create("y", chartInstance->c3_event_code,
            0, 0U, 0U, 0U, 0), false);
          sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_c_y);
          *chartInstance->c3_is_Main_Trial = c3_IN_PreshotStart;
          *chartInstance->c3_preshot_area_state = 1.0;
          chartInstance->c3_dataWrittenToVector[15U] = true;
          *chartInstance->c3_start_target_state = 2.0;
          chartInstance->c3_dataWrittenToVector[11U] = true;
          *chartInstance->c3_puck_state = 1.0;
          chartInstance->c3_dataWrittenToVector[5U] = true;
          *chartInstance->c3_goal_target_state = 1.0;
          chartInstance->c3_dataWrittenToVector[13U] = true;
          *chartInstance->c3_barrier_target_state = 1.0;
          chartInstance->c3_dataWrittenToVector[9U] = true;
          *chartInstance->c3_e_Trial_StartEventCounter = c3__u32_add__
            (chartInstance, *chartInstance->c3_e_Trial_StartEventCounter, 1U, 0,
             222U, 148, 13);
        }
      }
      break;

     case c3_IN_StartOn:
      *chartInstance->c3_start_target_state = 1.0;
      chartInstance->c3_dataWrittenToVector[11U] = true;
      *chartInstance->c3_preshot_area_state = 0.0;
      chartInstance->c3_dataWrittenToVector[15U] = true;
      *chartInstance->c3_cursor_state = 1.0;
      chartInstance->c3_dataWrittenToVector[3U] = true;
      *chartInstance->c3_puck_state = 0.0;
      chartInstance->c3_dataWrittenToVector[5U] = true;
      *chartInstance->c3_barrier_target_state = 0.0;
      chartInstance->c3_dataWrittenToVector[9U] = true;
      *chartInstance->c3_goal_target_state = 0.0;
      chartInstance->c3_dataWrittenToVector[13U] = true;
      if (!chartInstance->c3_dataWrittenToVector[10U]) {
        sf_read_before_write_error(chartInstance->S, 67U, 174U, 14, 16);
      }

      sf_eml_array_bounds_check(NULL, chartInstance->S, 174U, 14, 16,
        MAX_uint32_T, (int32_T)sf_integer_check(chartInstance->S, 174U, 14U, 16U,
        *chartInstance->c3_start_target_row), 1, 64);
      if ((*chartInstance->c3_HandInTarget)[(int32_T)
          *chartInstance->c3_start_target_row - 1] == 1.0) {
        chartInstance->c3_JITTransitionAnimation[5U] = 1U;
        *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
        *chartInstance->c3_event_code = E_ENTER_START;
        chartInstance->c3_dataWrittenToVector[1U] = true;
        if (!chartInstance->c3_dataWrittenToVector[1U]) {
          sf_read_before_write_error(chartInstance->S, 59U, 174U, 40, 10);
        }

        sf_mex_printf("%s =\\n", "event_code");
        c3_f_y = NULL;
        sf_mex_assign(&c3_f_y, sf_mex_create("y", chartInstance->c3_event_code,
          0, 0U, 0U, 0U, 0), false);
        sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_f_y);
        *chartInstance->c3_is_Main_Trial = c3_IN_StartHold;
        *chartInstance->c3_temporalCounter_i1 = 0U;
      } else {
        if (!chartInstance->c3_dataWrittenToVector[7U]) {
          sf_read_before_write_error(chartInstance->S, 51U, 7U, 6, 14);
        }

        if (*chartInstance->c3_temporalCounter_i1 >= c3__u32_d_(chartInstance,
             muDoubleScalarCeil(*chartInstance->c3_trial_duration / 0.00025 -
                                2.5000000000000003E-12), 0, 7U, 0, 26)) {
          chartInstance->c3_JITTransitionAnimation[0U] = 1U;
          *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
          *chartInstance->c3_is_c3_may23 = c3_IN_NO_ACTIVE_CHILD;
          *chartInstance->c3_event_code = E_TIMEOUT;
          chartInstance->c3_dataWrittenToVector[1U] = true;
          if (!chartInstance->c3_dataWrittenToVector[1U]) {
            sf_read_before_write_error(chartInstance->S, 59U, 7U, 29, 10);
          }

          sf_mex_printf("%s =\\n", "event_code");
          c3_g_y = NULL;
          sf_mex_assign(&c3_g_y, sf_mex_create("y", chartInstance->c3_event_code,
            0, 0U, 0U, 0U, 0), false);
          sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_g_y);
          *chartInstance->c3_is_c3_may23 = c3_IN_Inter_Trial_State;
          *chartInstance->c3_temporalCounter_i1 = 0U;
          *chartInstance->c3_e_Trial_EndEventCounter = c3__u32_add__
            (chartInstance, *chartInstance->c3_e_Trial_EndEventCounter, 1U, 0,
             1U, 26, 11);
        }
      }
      break;

     case c3_IN_Success:
      *chartInstance->c3_puck_state = 0.0;
      chartInstance->c3_dataWrittenToVector[5U] = true;
      *chartInstance->c3_goal_target_state = 3.0;
      chartInstance->c3_dataWrittenToVector[13U] = true;
      if (*chartInstance->c3_temporalCounter_i1 >= 1200U) {
        chartInstance->c3_JITTransitionAnimation[18U] = 1U;
        *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
        *chartInstance->c3_is_c3_may23 = c3_IN_NO_ACTIVE_CHILD;
        *chartInstance->c3_event_code = E_SUCCESS;
        chartInstance->c3_dataWrittenToVector[1U] = true;
        if (!chartInstance->c3_dataWrittenToVector[1U]) {
          sf_read_before_write_error(chartInstance->S, 59U, 252U, 17, 10);
        }

        sf_mex_printf("%s =\\n", "event_code");
        c3_b_y = NULL;
        sf_mex_assign(&c3_b_y, sf_mex_create("y", chartInstance->c3_event_code,
          0, 0U, 0U, 0U, 0), false);
        sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_b_y);
        *chartInstance->c3_is_c3_may23 = c3_IN_Inter_Trial_State;
        *chartInstance->c3_temporalCounter_i1 = 0U;
        *chartInstance->c3_e_Trial_EndEventCounter = c3__u32_add__(chartInstance,
          *chartInstance->c3_e_Trial_EndEventCounter, 1U, 0, 1U, 26, 11);
      }
      break;

     default:
      /* Unreachable state, for coverage only */
      *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
      break;
    }
  }
}

static void c3_enter_atomic_StartOn(SFc3_may23InstanceStruct *chartInstance)
{
  *chartInstance->c3_start_target_state = 1.0;
  chartInstance->c3_dataWrittenToVector[11U] = true;
  *chartInstance->c3_preshot_area_state = 0.0;
  chartInstance->c3_dataWrittenToVector[15U] = true;
  *chartInstance->c3_cursor_state = 1.0;
  chartInstance->c3_dataWrittenToVector[3U] = true;
  *chartInstance->c3_puck_state = 0.0;
  chartInstance->c3_dataWrittenToVector[5U] = true;
  *chartInstance->c3_barrier_target_state = 0.0;
  chartInstance->c3_dataWrittenToVector[9U] = true;
  *chartInstance->c3_goal_target_state = 0.0;
  chartInstance->c3_dataWrittenToVector[13U] = true;
}

static void c3_PreshotStart(SFc3_may23InstanceStruct *chartInstance)
{
  const mxArray *c3_y = NULL;
  const mxArray *c3_b_y = NULL;
  *chartInstance->c3_preshot_area_state = 1.0;
  chartInstance->c3_dataWrittenToVector[15U] = true;
  *chartInstance->c3_start_target_state = 2.0;
  chartInstance->c3_dataWrittenToVector[11U] = true;
  *chartInstance->c3_puck_state = 1.0;
  chartInstance->c3_dataWrittenToVector[5U] = true;
  *chartInstance->c3_goal_target_state = 1.0;
  chartInstance->c3_dataWrittenToVector[13U] = true;
  *chartInstance->c3_barrier_target_state = 1.0;
  chartInstance->c3_dataWrittenToVector[9U] = true;
  if (!chartInstance->c3_dataWrittenToVector[14U]) {
    sf_read_before_write_error(chartInstance->S, 71U, 230U, 14, 16);
  }

  sf_eml_array_bounds_check(NULL, chartInstance->S, 230U, 14, 16, MAX_uint32_T,
    (int32_T)sf_integer_check(chartInstance->S, 230U, 14U, 16U,
    *chartInstance->c3_preshot_area_row), 1, 64);
  if ((*chartInstance->c3_HandInTarget)[(int32_T)
      *chartInstance->c3_preshot_area_row - 1] == 0.0) {
    chartInstance->c3_JITTransitionAnimation[8U] = 1U;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_event_code = E_START_TARGET_ON;
    chartInstance->c3_dataWrittenToVector[1U] = true;
    if (!chartInstance->c3_dataWrittenToVector[1U]) {
      sf_read_before_write_error(chartInstance->S, 59U, 230U, 40, 10);
    }

    sf_mex_printf("%s =\\n", "event_code");
    c3_y = NULL;
    sf_mex_assign(&c3_y, sf_mex_create("y", chartInstance->c3_event_code, 0, 0U,
      0U, 0U, 0), false);
    sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_y);
    *chartInstance->c3_is_Main_Trial = c3_IN_StartOn;
    *chartInstance->c3_temporalCounter_i1 = 0U;
    c3_enter_atomic_StartOn(chartInstance);
  } else {
    if (!chartInstance->c3_dataWrittenToVector[10U]) {
      sf_read_before_write_error(chartInstance->S, 67U, 247U, 14, 16);
    }

    sf_eml_array_bounds_check(NULL, chartInstance->S, 247U, 14, 16, MAX_uint32_T,
      (int32_T)sf_integer_check(chartInstance->S, 247U, 14U, 16U,
      *chartInstance->c3_start_target_row), 1, 64);
    if ((*chartInstance->c3_HandInTarget)[(int32_T)
        *chartInstance->c3_start_target_row - 1] == 0.0) {
      chartInstance->c3_JITTransitionAnimation[16U] = 1U;
      *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
      *chartInstance->c3_event_code = E_BEGIN_PRESHOT;
      chartInstance->c3_dataWrittenToVector[1U] = true;
      if (!chartInstance->c3_dataWrittenToVector[1U]) {
        sf_read_before_write_error(chartInstance->S, 59U, 247U, 40, 10);
      }

      sf_mex_printf("%s =\\n", "event_code");
      c3_b_y = NULL;
      sf_mex_assign(&c3_b_y, sf_mex_create("y", chartInstance->c3_event_code, 0,
        0U, 0U, 0U, 0), false);
      sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_b_y);
      *chartInstance->c3_is_Main_Trial = c3_IN_PreshotMove;
    }
  }
}

static void c3_PreshotMove(SFc3_may23InstanceStruct *chartInstance)
{
  const mxArray *c3_y = NULL;
  if (!chartInstance->c3_dataWrittenToVector[10U]) {
    sf_read_before_write_error(chartInstance->S, 67U, 235U, 14, 16);
  }

  sf_eml_array_bounds_check(NULL, chartInstance->S, 235U, 14, 16, MAX_uint32_T,
    (int32_T)sf_integer_check(chartInstance->S, 235U, 14U, 16U,
    *chartInstance->c3_start_target_row), 1, 64);
  if ((*chartInstance->c3_HandInTarget)[(int32_T)
      *chartInstance->c3_start_target_row - 1] == 1.0) {
    chartInstance->c3_JITTransitionAnimation[10U] = 1U;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_Main_Trial = c3_IN_ShotReady;
    *chartInstance->c3_temporalCounter_i1 = 0U;
  } else {
    if (!chartInstance->c3_dataWrittenToVector[14U]) {
      sf_read_before_write_error(chartInstance->S, 71U, 260U, 14, 16);
    }

    sf_eml_array_bounds_check(NULL, chartInstance->S, 260U, 14, 16, MAX_uint32_T,
      (int32_T)sf_integer_check(chartInstance->S, 260U, 14U, 16U,
      *chartInstance->c3_preshot_area_row), 1, 64);
    if ((*chartInstance->c3_HandInTarget)[(int32_T)
        *chartInstance->c3_preshot_area_row - 1] == 0.0) {
      chartInstance->c3_JITTransitionAnimation[20U] = 1U;
      *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
      *chartInstance->c3_event_code = E_START_TARGET_ON;
      chartInstance->c3_dataWrittenToVector[1U] = true;
      if (!chartInstance->c3_dataWrittenToVector[1U]) {
        sf_read_before_write_error(chartInstance->S, 59U, 260U, 40, 10);
      }

      sf_mex_printf("%s =\\n", "event_code");
      c3_y = NULL;
      sf_mex_assign(&c3_y, sf_mex_create("y", chartInstance->c3_event_code, 0,
        0U, 0U, 0U, 0), false);
      sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_y);
      *chartInstance->c3_is_Main_Trial = c3_IN_StartOn;
      *chartInstance->c3_temporalCounter_i1 = 0U;
      c3_enter_atomic_StartOn(chartInstance);
    }
  }
}

static void c3_ShotReady(SFc3_may23InstanceStruct *chartInstance)
{
  const mxArray *c3_y = NULL;
  if (!chartInstance->c3_dataWrittenToVector[10U]) {
    sf_read_before_write_error(chartInstance->S, 67U, 234U, 14, 16);
  }

  sf_eml_array_bounds_check(NULL, chartInstance->S, 234U, 14, 16, MAX_uint32_T,
    (int32_T)sf_integer_check(chartInstance->S, 234U, 14U, 16U,
    *chartInstance->c3_start_target_row), 1, 64);
  if ((*chartInstance->c3_HandInTarget)[(int32_T)
      *chartInstance->c3_start_target_row - 1] == 0.0) {
    chartInstance->c3_JITTransitionAnimation[9U] = 1U;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_Main_Trial = c3_IN_PreshotMove;
  } else {
    if (!chartInstance->c3_dataWrittenToVector[18U]) {
      sf_read_before_write_error(chartInstance->S, 47U, 237U, 6, 15);
    }

    if (*chartInstance->c3_temporalCounter_i1 >= c3__u32_d_(chartInstance,
         muDoubleScalarCeil(*chartInstance->c3_shot_ready_time / 0.00025 -
                            2.5000000000000003E-12), 0, 237U, 0, 26)) {
      chartInstance->c3_JITTransitionAnimation[11U] = 1U;
      *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
      *chartInstance->c3_event_code = E_SHOT_READY;
      chartInstance->c3_dataWrittenToVector[1U] = true;
      if (!chartInstance->c3_dataWrittenToVector[1U]) {
        sf_read_before_write_error(chartInstance->S, 59U, 237U, 29, 10);
      }

      sf_mex_printf("%s =\\n", "event_code");
      c3_y = NULL;
      sf_mex_assign(&c3_y, sf_mex_create("y", chartInstance->c3_event_code, 0,
        0U, 0U, 0U, 0), false);
      sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_y);
      *chartInstance->c3_is_Main_Trial = c3_IN_ShotSet;
      *chartInstance->c3_temporalCounter_i1 = 0U;
      *chartInstance->c3_preshot_area_state = 0.0;
      chartInstance->c3_dataWrittenToVector[15U] = true;
      *chartInstance->c3_start_target_state = 3.0;
      chartInstance->c3_dataWrittenToVector[11U] = true;
    }
  }
}

static void c3_Shot(SFc3_may23InstanceStruct *chartInstance)
{
  const mxArray *c3_y = NULL;
  const mxArray *c3_b_y = NULL;
  const mxArray *c3_c_y = NULL;
  *chartInstance->c3_start_target_state = 0.0;
  chartInstance->c3_dataWrittenToVector[11U] = true;
  *chartInstance->c3_cursor_state = 2.0;
  chartInstance->c3_dataWrittenToVector[3U] = true;
  *chartInstance->c3_puck_state = 2.0;
  chartInstance->c3_dataWrittenToVector[5U] = true;
  *chartInstance->c3_goal_target_state = 2.0;
  chartInstance->c3_dataWrittenToVector[13U] = true;
  *chartInstance->c3_barrier_target_state = 2.0;
  chartInstance->c3_dataWrittenToVector[9U] = true;
  if (!chartInstance->c3_dataWrittenToVector[8U]) {
    sf_read_before_write_error(chartInstance->S, 65U, 267U, 15, 18);
  }

  sf_eml_array_bounds_check(NULL, chartInstance->S, 267U, 15, 18, MAX_uint32_T,
    (int32_T)sf_integer_check(chartInstance->S, 267U, 15U, 18U,
    *chartInstance->c3_barrier_target_row), 1, 64);
  if ((*chartInstance->c3_PuckInBarrier)[(int32_T)
      *chartInstance->c3_barrier_target_row - 1] == 1.0) {
    chartInstance->c3_JITTransitionAnimation[21U] = 1U;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_event_code = E_PUCK_IN_BARRIER;
    chartInstance->c3_dataWrittenToVector[1U] = true;
    if (!chartInstance->c3_dataWrittenToVector[1U]) {
      sf_read_before_write_error(chartInstance->S, 59U, 267U, 43, 10);
    }

    sf_mex_printf("%s =\\n", "event_code");
    c3_y = NULL;
    sf_mex_assign(&c3_y, sf_mex_create("y", chartInstance->c3_event_code, 0, 0U,
      0U, 0U, 0), false);
    sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_y);
    *chartInstance->c3_is_Main_Trial = c3_IN_Fail;
    *chartInstance->c3_temporalCounter_i1 = 0U;
    c3_enter_atomic_Fail(chartInstance);
  } else {
    if (!chartInstance->c3_dataWrittenToVector[20U]) {
      sf_read_before_write_error(chartInstance->S, 49U, 242U, 6, 9);
    }

    if (*chartInstance->c3_temporalCounter_i1 >= c3__u32_d_(chartInstance,
         muDoubleScalarCeil(*chartInstance->c3_shot_time / 0.00025 -
                            2.5000000000000003E-12), 0, 242U, 0, 20)) {
      chartInstance->c3_JITTransitionAnimation[14U] = 1U;
      *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
      *chartInstance->c3_event_code = E_TIMEOUT;
      chartInstance->c3_dataWrittenToVector[1U] = true;
      if (!chartInstance->c3_dataWrittenToVector[1U]) {
        sf_read_before_write_error(chartInstance->S, 59U, 242U, 23, 10);
      }

      sf_mex_printf("%s =\\n", "event_code");
      c3_b_y = NULL;
      sf_mex_assign(&c3_b_y, sf_mex_create("y", chartInstance->c3_event_code, 0,
        0U, 0U, 0U, 0), false);
      sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_b_y);
      *chartInstance->c3_is_Main_Trial = c3_IN_Fail;
      *chartInstance->c3_temporalCounter_i1 = 0U;
      c3_enter_atomic_Fail(chartInstance);
    } else {
      if (!chartInstance->c3_dataWrittenToVector[8U]) {
        sf_read_before_write_error(chartInstance->S, 65U, 248U, 15, 18);
      }

      sf_eml_array_bounds_check(NULL, chartInstance->S, 248U, 15, 18,
        MAX_uint32_T, (int32_T)sf_integer_check(chartInstance->S, 248U, 15U, 18U,
        *chartInstance->c3_barrier_target_row), 1, 64);
      if ((*chartInstance->c3_HandInBarrier)[(int32_T)
          *chartInstance->c3_barrier_target_row - 1] == 1.0) {
        chartInstance->c3_JITTransitionAnimation[17U] = 1U;
        *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
        *chartInstance->c3_event_code = E_HAND_IN_BARRIER;
        chartInstance->c3_dataWrittenToVector[1U] = true;
        if (!chartInstance->c3_dataWrittenToVector[1U]) {
          sf_read_before_write_error(chartInstance->S, 59U, 248U, 43, 10);
        }

        sf_mex_printf("%s =\\n", "event_code");
        c3_c_y = NULL;
        sf_mex_assign(&c3_c_y, sf_mex_create("y", chartInstance->c3_event_code,
          0, 0U, 0U, 0U, 0), false);
        sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_c_y);
        *chartInstance->c3_is_Main_Trial = c3_IN_Fail;
        *chartInstance->c3_temporalCounter_i1 = 0U;
        c3_enter_atomic_Fail(chartInstance);
      } else {
        if (*chartInstance->c3_sfEvent == c3_event_e_Puck_Hit) {
          chartInstance->c3_JITTransitionAnimation[24U] = 1U;
          *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
          *chartInstance->c3_is_Main_Trial = c3_IN_PuckMoving;
        }
      }
    }
  }
}

static void c3_ShotEnd(SFc3_may23InstanceStruct *chartInstance)
{
  const mxArray *c3_y = NULL;
  const mxArray *c3_b_y = NULL;
  if (!chartInstance->c3_dataWrittenToVector[12U]) {
    sf_read_before_write_error(chartInstance->S, 69U, 253U, 14, 15);
  }

  sf_eml_array_bounds_check(NULL, chartInstance->S, 253U, 14, 15, MAX_uint32_T,
    (int32_T)sf_integer_check(chartInstance->S, 253U, 14U, 15U,
    *chartInstance->c3_goal_target_row), 1, 64);
  if ((*chartInstance->c3_PuckInTarget)[(int32_T)
      *chartInstance->c3_goal_target_row - 1] == 1.0) {
    chartInstance->c3_JITTransitionAnimation[19U] = 1U;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_event_code = E_PUCK_IN_GOAL;
    chartInstance->c3_dataWrittenToVector[1U] = true;
    if (!chartInstance->c3_dataWrittenToVector[1U]) {
      sf_read_before_write_error(chartInstance->S, 59U, 253U, 39, 10);
    }

    sf_mex_printf("%s =\\n", "event_code");
    c3_y = NULL;
    sf_mex_assign(&c3_y, sf_mex_create("y", chartInstance->c3_event_code, 0, 0U,
      0U, 0U, 0), false);
    sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_y);
    *chartInstance->c3_is_Main_Trial = c3_IN_Success;
    *chartInstance->c3_temporalCounter_i1 = 0U;
    *chartInstance->c3_puck_state = 0.0;
    chartInstance->c3_dataWrittenToVector[5U] = true;
    *chartInstance->c3_goal_target_state = 3.0;
    chartInstance->c3_dataWrittenToVector[13U] = true;
  } else {
    if (!chartInstance->c3_dataWrittenToVector[12U]) {
      sf_read_before_write_error(chartInstance->S, 69U, 280U, 14, 15);
    }

    sf_eml_array_bounds_check(NULL, chartInstance->S, 280U, 14, 15, MAX_uint32_T,
      (int32_T)sf_integer_check(chartInstance->S, 280U, 14U, 15U,
      *chartInstance->c3_goal_target_row), 1, 64);
    if ((*chartInstance->c3_PuckInTarget)[(int32_T)
        *chartInstance->c3_goal_target_row - 1] == 0.0) {
      chartInstance->c3_JITTransitionAnimation[23U] = 1U;
      *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
      *chartInstance->c3_event_code = E_PUCK_MISS;
      chartInstance->c3_dataWrittenToVector[1U] = true;
      if (!chartInstance->c3_dataWrittenToVector[1U]) {
        sf_read_before_write_error(chartInstance->S, 59U, 280U, 39, 10);
      }

      sf_mex_printf("%s =\\n", "event_code");
      c3_b_y = NULL;
      sf_mex_assign(&c3_b_y, sf_mex_create("y", chartInstance->c3_event_code, 0,
        0U, 0U, 0U, 0), false);
      sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_b_y);
      *chartInstance->c3_is_Main_Trial = c3_IN_Fail;
      *chartInstance->c3_temporalCounter_i1 = 0U;
      c3_enter_atomic_Fail(chartInstance);
    }
  }
}

static void c3_enter_atomic_Fail(SFc3_may23InstanceStruct *chartInstance)
{
  *chartInstance->c3_start_target_state = 0.0;
  chartInstance->c3_dataWrittenToVector[11U] = true;
  *chartInstance->c3_preshot_area_state = 0.0;
  chartInstance->c3_dataWrittenToVector[15U] = true;
  *chartInstance->c3_cursor_state = 3.0;
  chartInstance->c3_dataWrittenToVector[3U] = true;
  *chartInstance->c3_puck_state = 0.0;
  chartInstance->c3_dataWrittenToVector[5U] = true;
  *chartInstance->c3_barrier_target_state = 0.0;
  chartInstance->c3_dataWrittenToVector[9U] = true;
  *chartInstance->c3_goal_target_state = 0.0;
  chartInstance->c3_dataWrittenToVector[13U] = true;
}

static void c3_Fail(SFc3_may23InstanceStruct *chartInstance)
{
  const mxArray *c3_y = NULL;
  *chartInstance->c3_start_target_state = 0.0;
  chartInstance->c3_dataWrittenToVector[11U] = true;
  *chartInstance->c3_preshot_area_state = 0.0;
  chartInstance->c3_dataWrittenToVector[15U] = true;
  *chartInstance->c3_cursor_state = 3.0;
  chartInstance->c3_dataWrittenToVector[3U] = true;
  *chartInstance->c3_puck_state = 0.0;
  chartInstance->c3_dataWrittenToVector[5U] = true;
  *chartInstance->c3_barrier_target_state = 0.0;
  chartInstance->c3_dataWrittenToVector[9U] = true;
  *chartInstance->c3_goal_target_state = 0.0;
  chartInstance->c3_dataWrittenToVector[13U] = true;
  if (*chartInstance->c3_temporalCounter_i1 >= 1200U) {
    chartInstance->c3_JITTransitionAnimation[15U] = 1U;
    *chartInstance->c3_is_Main_Trial = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_is_c3_may23 = c3_IN_NO_ACTIVE_CHILD;
    *chartInstance->c3_event_code = E_FAILURE;
    chartInstance->c3_dataWrittenToVector[1U] = true;
    if (!chartInstance->c3_dataWrittenToVector[1U]) {
      sf_read_before_write_error(chartInstance->S, 59U, 243U, 17, 10);
    }

    sf_mex_printf("%s =\\n", "event_code");
    c3_y = NULL;
    sf_mex_assign(&c3_y, sf_mex_create("y", chartInstance->c3_event_code, 0, 0U,
      0U, 0U, 0), false);
    sf_mex_call(chartInstance->c3_fEmlrtCtx, "disp", 0U, 1U, 14, c3_y);
    *chartInstance->c3_is_c3_may23 = c3_IN_Inter_Trial_State;
    *chartInstance->c3_temporalCounter_i1 = 0U;
    *chartInstance->c3_e_Trial_EndEventCounter = c3__u32_add__(chartInstance,
      *chartInstance->c3_e_Trial_EndEventCounter, 1U, 0, 1U, 26, 11);
  }
}

const mxArray *sf_c3_may23_get_eml_resolved_functions_info(void)
{
  const mxArray *c3_nameCaptureInfo = NULL;
  c3_nameCaptureInfo = NULL;
  sf_mex_assign(&c3_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1), false);
  return c3_nameCaptureInfo;
}

static real_T c3_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance, const
  mxArray *c3_b_barrier_target_row, const char_T *c3_identifier)
{
  real_T c3_y;
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fIdentifier = (const char *)c3_identifier;
  c3_thisId.fParent = NULL;
  c3_thisId.bParentIsCell = false;
  c3_y = c3_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c3_b_barrier_target_row),
    &c3_thisId);
  sf_mex_destroy(&c3_b_barrier_target_row);
  return c3_y;
}

static real_T c3_b_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  real_T c3_y;
  real_T c3_d;
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), &c3_d, 1, 0, 0U, 0, 0U, 0);
  c3_y = c3_d;
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static boolean_T c3_c_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_b_logging_enable, const char_T *c3_identifier)
{
  boolean_T c3_y;
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fIdentifier = (const char *)c3_identifier;
  c3_thisId.fParent = NULL;
  c3_thisId.bParentIsCell = false;
  c3_y = c3_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c3_b_logging_enable),
    &c3_thisId);
  sf_mex_destroy(&c3_b_logging_enable);
  return c3_y;
}

static boolean_T c3_d_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  boolean_T c3_y;
  boolean_T c3_b;
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), &c3_b, 1, 11, 0U, 0, 0U, 0);
  c3_y = c3_b;
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static uint32_T c3_e_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_b_e_Trial_EndEventCounter, const char_T *c3_identifier)
{
  uint32_T c3_y;
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fIdentifier = (const char *)c3_identifier;
  c3_thisId.fParent = NULL;
  c3_thisId.bParentIsCell = false;
  c3_y = c3_f_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c3_b_e_Trial_EndEventCounter), &c3_thisId);
  sf_mex_destroy(&c3_b_e_Trial_EndEventCounter);
  return c3_y;
}

static uint32_T c3_f_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  uint32_T c3_y;
  uint32_T c3_b_u;
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), &c3_b_u, 1, 7, 0U, 0, 0U, 0);
  c3_y = c3_b_u;
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static uint8_T c3_g_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_b_is_active_c3_may23, const char_T *c3_identifier)
{
  uint8_T c3_y;
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fIdentifier = (const char *)c3_identifier;
  c3_thisId.fParent = NULL;
  c3_thisId.bParentIsCell = false;
  c3_y = c3_h_emlrt_marshallIn(chartInstance, sf_mex_dup(c3_b_is_active_c3_may23),
    &c3_thisId);
  sf_mex_destroy(&c3_b_is_active_c3_may23);
  return c3_y;
}

static uint8_T c3_h_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance,
  const mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  uint8_T c3_y;
  uint8_T c3_b_u;
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), &c3_b_u, 1, 3, 0U, 0, 0U, 0);
  c3_y = c3_b_u;
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static void c3_i_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance, const
  mxArray *c3_b_dataWrittenToVector, const char_T *c3_identifier, boolean_T
  c3_y[21])
{
  emlrtMsgIdentifier c3_thisId;
  c3_thisId.fIdentifier = (const char *)c3_identifier;
  c3_thisId.fParent = NULL;
  c3_thisId.bParentIsCell = false;
  c3_j_emlrt_marshallIn(chartInstance, sf_mex_dup(c3_b_dataWrittenToVector),
                        &c3_thisId, c3_y);
  sf_mex_destroy(&c3_b_dataWrittenToVector);
}

static void c3_j_emlrt_marshallIn(SFc3_may23InstanceStruct *chartInstance, const
  mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId, boolean_T c3_y[21])
{
  boolean_T c3_bv[21];
  int32_T c3_i;
  (void)chartInstance;
  sf_mex_import(c3_parentId, sf_mex_dup(c3_u), c3_bv, 1, 11, 0U, 1, 0U, 1, 21);
  for (c3_i = 0; c3_i < 21; c3_i++) {
    c3_y[c3_i] = c3_bv[c3_i];
  }

  sf_mex_destroy(&c3_u);
}

static const mxArray *c3_k_emlrt_marshallIn(SFc3_may23InstanceStruct
  *chartInstance, const mxArray *c3_b_setSimStateSideEffectsInfo, const char_T
  *c3_identifier)
{
  const mxArray *c3_y = NULL;
  emlrtMsgIdentifier c3_thisId;
  c3_y = NULL;
  c3_thisId.fIdentifier = (const char *)c3_identifier;
  c3_thisId.fParent = NULL;
  c3_thisId.bParentIsCell = false;
  sf_mex_assign(&c3_y, c3_l_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c3_b_setSimStateSideEffectsInfo), &c3_thisId), false);
  sf_mex_destroy(&c3_b_setSimStateSideEffectsInfo);
  return c3_y;
}

static const mxArray *c3_l_emlrt_marshallIn(SFc3_may23InstanceStruct
  *chartInstance, const mxArray *c3_u, const emlrtMsgIdentifier *c3_parentId)
{
  const mxArray *c3_y = NULL;
  (void)chartInstance;
  (void)c3_parentId;
  c3_y = NULL;
  sf_mex_assign(&c3_y, sf_mex_duplicatearraysafe(&c3_u), false);
  sf_mex_destroy(&c3_u);
  return c3_y;
}

static uint32_T c3__u32_d_(SFc3_may23InstanceStruct *chartInstance, real_T c3_b,
  int32_T c3_EMLOvCount_src_loc, uint32_T c3_ssid_src_loc, int32_T
  c3_offset_src_loc, int32_T c3_length_src_loc)
{
  uint32_T c3_a;
  (void)c3_EMLOvCount_src_loc;
  c3_a = (uint32_T)c3_b;
  if ((c3_b < 0.0) || ((real_T)c3_a != muDoubleScalarFloor(c3_b))) {
    sf_data_overflow_error(chartInstance->S, c3_ssid_src_loc, c3_offset_src_loc,
      c3_length_src_loc);
  }

  return c3_a;
}

static uint32_T c3__u32_add__(SFc3_may23InstanceStruct *chartInstance, uint32_T
  c3_b, uint32_T c3_c, int32_T c3_EMLOvCount_src_loc, uint32_T c3_ssid_src_loc,
  int32_T c3_offset_src_loc, int32_T c3_length_src_loc)
{
  uint32_T c3_a;
  (void)c3_EMLOvCount_src_loc;
  c3_a = c3_b + c3_c;
  if (c3_a < c3_b) {
    sf_data_overflow_error(chartInstance->S, c3_ssid_src_loc, c3_offset_src_loc,
      c3_length_src_loc);
  }

  return c3_a;
}

static void init_dsm_address_info(SFc3_may23InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address(SFc3_may23InstanceStruct *chartInstance)
{
  chartInstance->c3_e_clk = (int8_T *)(ssGetInputPortSignalPtrs_wrapper
    (chartInstance->S, 6))[0U];
  chartInstance->c3_e_ExitTrialNow = (int8_T *)(ssGetInputPortSignalPtrs_wrapper
    (chartInstance->S, 6))[1U];
  chartInstance->c3_e_Trial_Start = (boolean_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 16);
  chartInstance->c3_e_Trial_End = (boolean_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 17);
  chartInstance->c3_e_Puck_Stopped = (int8_T *)(ssGetInputPortSignalPtrs_wrapper
    (chartInstance->S, 6))[2U];
  chartInstance->c3_e_Puck_Hit = (int8_T *)(ssGetInputPortSignalPtrs_wrapper
    (chartInstance->S, 6))[3U];
  chartInstance->c3_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c3_e_Trial_StartEventCounter = (uint32_T *)ssGetDWork_wrapper
    (chartInstance->S, 0);
  chartInstance->c3_e_Trial_EndEventCounter = (uint32_T *)ssGetDWork_wrapper
    (chartInstance->S, 1);
  chartInstance->c3_sfEvent = (int32_T *)ssGetDWork_wrapper(chartInstance->S, 2);
  chartInstance->c3_is_active_c3_may23 = (uint8_T *)ssGetDWork_wrapper
    (chartInstance->S, 3);
  chartInstance->c3_is_c3_may23 = (uint8_T *)ssGetDWork_wrapper(chartInstance->S,
    4);
  chartInstance->c3_is_Main_Trial = (uint8_T *)ssGetDWork_wrapper
    (chartInstance->S, 5);
  chartInstance->c3_logging_enable = (boolean_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c3_event_code = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 2);
  chartInstance->c3_cursor_row = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 3);
  chartInstance->c3_cursor_state = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 4);
  chartInstance->c3_puck_row = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 5);
  chartInstance->c3_puck_state = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 6);
  chartInstance->c3_load_row = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 7);
  chartInstance->c3_Trial_Protocol = (real_T (*)[50])
    ssGetInputPortSignal_wrapper(chartInstance->S, 0);
  chartInstance->c3_trial_duration = (real_T *)ssGetDWork_wrapper
    (chartInstance->S, 6);
  chartInstance->c3_barrier_target_row = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 8);
  chartInstance->c3_barrier_target_state = (real_T *)
    ssGetOutputPortSignal_wrapper(chartInstance->S, 9);
  chartInstance->c3_start_target_row = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 10);
  chartInstance->c3_start_target_state = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 11);
  chartInstance->c3_goal_target_row = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 12);
  chartInstance->c3_goal_target_state = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 13);
  chartInstance->c3_HandInTarget = (real_T (*)[64])ssGetInputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c3_preshot_area_row = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 14);
  chartInstance->c3_preshot_area_state = (real_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 15);
  chartInstance->c3_start_hold_time = (real_T *)ssGetDWork_wrapper
    (chartInstance->S, 7);
  chartInstance->c3_shot_set_time = (real_T *)ssGetDWork_wrapper
    (chartInstance->S, 8);
  chartInstance->c3_shot_ready_time = (real_T *)ssGetDWork_wrapper
    (chartInstance->S, 9);
  chartInstance->c3_HandInBarrier = (real_T (*)[64])ssGetInputPortSignal_wrapper
    (chartInstance->S, 2);
  chartInstance->c3_PuckInTarget = (real_T (*)[64])ssGetInputPortSignal_wrapper
    (chartInstance->S, 3);
  chartInstance->c3_goal_time = (real_T *)ssGetDWork_wrapper(chartInstance->S,
    10);
  chartInstance->c3_PuckInBarrier = (real_T (*)[64])ssGetInputPortSignal_wrapper
    (chartInstance->S, 4);
  chartInstance->c3_PuckInDisplay = (real_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 5);
  chartInstance->c3_shot_time = (real_T *)ssGetDWork_wrapper(chartInstance->S,
    11);
  chartInstance->c3_temporalCounter_i1 = (uint32_T *)ssGetDWork_wrapper
    (chartInstance->S, 12);
  chartInstance->c3_presentTicks = (uint32_T *)ssGetDWork_wrapper
    (chartInstance->S, 13);
  chartInstance->c3_elapsedTicks = (uint32_T *)ssGetDWork_wrapper
    (chartInstance->S, 14);
  chartInstance->c3_previousTicks = (uint32_T *)ssGetDWork_wrapper
    (chartInstance->S, 15);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* SFunction Glue Code */
void sf_c3_may23_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3025712831U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(3652516782U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(3737701816U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(1207541834U);
}

mxArray *sf_c3_may23_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c3_may23_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("early");
  mxArray *fallbackReason = mxCreateString("machine_data");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c3_may23_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

static const mxArray *sf_get_sim_state_info_c3_may23(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  mxArray *mxVarInfo = sf_mex_decode(
    "eNrNmcFu0zAYx90xpha2ssGkMYFExYEDhwnYZZyIhCbRwyQkChyDF3ud1cYOjlPorY/AI/RReJQ"
    "+Ao+AnXhtYioSOdHqSNbXz62T/Pr/+7OjgFb/AsijK1v7CQA7Ksq2BbLjrs5bsj3TMevfXvb3ZB"
    "PTCKv+mAd9JCOFYZrD5GefXrH0/Gdgdf6dNedv5c7f0f3Z8eddrfEL5KnxH3Ljt9eMf5gbv6/zS"
    "8g5wdwXkA+x8Dn7kX3fBau4MS6AK3EdGlyH/3LFAgrsDNciSLm8Eq57BpfKg4THjDum0zdUiWfX"
    "4Nld8bilz+/P1vrgCabCDxjCLumDK/E8MHhUPmRwnC8OTvDMqtWFA4PnwOBZms4VnXrZPDor4Wo"
    "bXCofM4iUQG7U7ZNKfusaHN2UYzgkdOhjCi/H2BFdZqNKPPsGj2oRx/E1Ez7kGDqjjzey3i8UeH"
    "ITyA3f2c+fKAlG7uiDrNeflMM1XXrYev5IFC5yC5Ab+mDr+VPgaVyntldr/K+okk4dg6uzXFdJ2"
    "Ox6WpNnTq33PWmRkzUOTTMqJ3hm1Xj2DJ69G55Yek5r5Ibfvlv7LeVxzW8gtPdbWheu2Rg55Lc5"
    "st7HCU5kQUAJh4Iw2pQ+j2vq87YSz32DR+XYH6RE5xQ16LeaPPPIuh7c8HxSvmuM52kj+pStq0c"
    "Gz1FRn3P1CP6eJVRg7gaX1uljCdexwXVs6lQga7Lu9Wrqll3fZj9EYh8GgkywH5z6IZy+OW2S63"
    "kjXDb1QnIVgNzgaVvXC8lzAQnN3NgYz4uN+U7gMGIcjvVs8snrHE/r/+8JWsZ7gju5fQoWgMUgE"
    "Pn7e1Vyf1uF+9sCUGTjopL/pW38L96y3lxlH3thFmc6LnSUzz/6avp3VEfmbfb5/eWtzNd1/o44"
    "nhCWxAMSjOLG/H1yK/5+ZPCoHEEBv3IiBKYD9gUHgvFCHfoL/wkzeQ=="
    );
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c3_may23_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const char* sf_get_instance_specialization(void)
{
  return "smCIWm1J9sGqZhiLVjSqKeH";
}

static void sf_opaque_initialize_c3_may23(void *chartInstanceVar)
{
  initialize_params_c3_may23((SFc3_may23InstanceStruct*) chartInstanceVar);
  initialize_c3_may23((SFc3_may23InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c3_may23(void *chartInstanceVar)
{
  enable_c3_may23((SFc3_may23InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c3_may23(void *chartInstanceVar)
{
  disable_c3_may23((SFc3_may23InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c3_may23(void *chartInstanceVar)
{
  sf_gateway_c3_may23((SFc3_may23InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_ext_mode_exec_c3_may23(void *chartInstanceVar)
{
  ext_mode_exec_c3_may23((SFc3_may23InstanceStruct*) chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c3_may23(SimStruct* S)
{
  return get_sim_state_c3_may23((SFc3_may23InstanceStruct *)
    sf_get_chart_instance_ptr(S));     /* raw sim ctx */
}

static void sf_opaque_set_sim_state_c3_may23(SimStruct* S, const mxArray *st)
{
  set_sim_state_c3_may23((SFc3_may23InstanceStruct*)sf_get_chart_instance_ptr(S),
    st);
}

static void sf_opaque_terminate_c3_may23(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc3_may23InstanceStruct*) chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_may23_optimization_info();
    }

    finalize_c3_may23((SFc3_may23InstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc3_may23((SFc3_may23InstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c3_may23(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  sf_warn_if_symbolic_dimension_param_changed(S);
  if (sf_machine_global_initializer_called()) {
    initialize_params_c3_may23((SFc3_may23InstanceStruct*)
      sf_get_chart_instance_ptr(S));
    initSimStructsc3_may23((SFc3_may23InstanceStruct*)sf_get_chart_instance_ptr
      (S));
  }
}

const char* sf_c3_may23_get_post_codegen_info(void)
{
  int i;
  const char* encStrCodegen [37] = {
    "eNrtXE9z20QUl0OaJqVNU+gUOnSGTA/AcOj0z6U9Na2TUEPSZLCTzHAxa+nF3lrSKrsrJ+GUAyd",
    "ODJ8gM73xCZjhAFc+Bb3CqR+BXUl27LVsK7ISq2E946qrvPe0v/fe/rTafbJRKK0b4jMvvseuYc",
    "yI46z4Thnh51LULnR9w/PTxudR+7UQcn1nE1HkMGPox0UOfAuM2D7HxC25uyRWDLu7QME1haxHK",
    "B9kjWHHt7HbXPVdU9pjOw1sNsoN4tvWc6GLrA3XPhTWPJ9vCjvLmILJVwEs3qDErzdWbVTv9Jjy",
    "/WIDzCbznWEQGPCy78lusXXf5tizYeUAzJLLOBI9Zid9K3PEocgPBsKUSFm5LUgcz8bIjUXbQKw",
    "MnnAwhy3PEv9u+FyAUsXMBqL8OTRQC9gabgY2iQuqTczEH2rYRZxQjOwVxy5Kxf6+bdqiP+vEAn",
    "uIQ0TfnlNATY9glw+Of3lVIF1xUc2GZaj59cHWyrDny+BvY9gHOtBvu0XSAorqsOEOvGjgkJWDI",
    "FqdLOkX49iBbUSfmSJ+DKyB2Ssyh5WRiBNUhMYgMQhAlliF4pZw70BrvlOSmTlqyPhOGGw2Siyw",
    "ttKCYVHoWFs13SKybTZQrEK8NWiBHVhdRhwNFwutxst5lHioLrLWEk6WKV4kroX7YmH6jBOnKNJ",
    "teW3tpWCK+M6diJVcDnQXmRA3bpnZAMu3QQAVzMSDy8UYtTCT0RohFcV0lJTBdn13eZ/QpgA6ZN",
    "ifQJAxGCjosLrwvsjdLSbSfJiY9P5IuTbP3zdOeP5qAp5v66nHL7rsFGLsGF1HKf+4S35uqlf+s",
    "nLdqfa58BPoL3XpX1OuN63oS7kF8b31y09/Pb372T+vL/3+69Mf//1bxa/2o9DXj0Kn/799crr7",
    "43zUvtMmok6atvqyQ8q+6OrXdIz9j7rsL0Rt5hRLO86Dr5+wr/a+a+C17VflvW/gRWBvdkR/P1X",
    "62z6/KBnx0Av4jVGzZEU3btlGfng7U+M5M8Ifc9H58PP26Vj6b6ylJP76QPGXbNcQpRholSNaB1",
    "6lZL8/ryeGy4BEuG4quG7242JyRpEbXG/MJXX8xuG6ouC6EjAlZYTmLE7fW4nwXFXwXD3Bk6/4/",
    "LmVOj4gpxtVU9zJ8hQfSITnuoJHtusE2d3kkAs8R8l44YaC54aCp5N0eYnTYjiOHo/ANavgkm2b",
    "IEsGKB+8fS9Rvs0rOOYDHPU6duvVcH6Zk7gcNRPhWVDwLARTfWANwqtIPBHmJj5LzdTzhR48XQM",
    "oH3mXfvx4vtnMT3ys1PefAEfe4rIIqcePgEJ51w0oH/GB1OOnB0/mcZpdGkv/Zy9RnOYUXHOd++",
    "rJIlAu8By7qec9AckJjrMOQ1S5wHOUDM81Bc+1Nh4mci6KUT7ybS91vgV48pZvhpM+3wJeaBDby",
    "lG+HVup53FcLqRXLZ8iuTaYVXw+HjM+TxLheV/BI9tQrQSIVlwrw3wbE8+xl5oP2njKPNzoyAbP",
    "nUzik2bdrys+wYp/kfhyMTwfuKI4bY7AdVvBdVuNUw+yLHlvccy4JVuvjZsPYVZFJsctqJqPqg4",
    "6fPgoS1x3M8GVhi8Erh5A+cAzm5ovBJ51hN0wGzPD89nE8o6D4xGK7Gg0VfGDLjyF0+1rvNc1Tw",
    "FuEGaYfND+Ulz/pnr6N2UgHup5I/wyq/hlqcM3u+F/F53weBQd30RH8fwTXS2Sc6MjWZrs8/uX5",
    "zJe4/Lbo9DCxGcVbDZZZvl971zy+0MFj2xbiKMdijkHt0K2weSE9vHQaff9Cin1DK33v9Qr5CDP",
    "kuznz6TUu5FSb3rMuoPzwnc9ZV3DaeWH3R8NRX5hjOuctfzs6vB5w4Li31vt80K4hehL1FdC1a4",
    "66K+Rq7tqWdY+odYauHXe6D5bwyimaojZJMYwHMQXx5VNZIO1TPxgR6arZM6z4UApQPwhpr/s0K",
    "kRG5vlnr/WMN/BVm9vZR+C+rotT25o9fih3Gcbsw0P7fl9ZyvA+KYsvus6S2qvYvzrIfX6wS4CM",
    "JNiL1y46HyoLNNsQYVI5yN7o/ZK3FUNmwjnVEUnfKhastCpiq2DnrO4A4NRc038QbHroIMyp9it",
    "9wTvLJ8XR+2PzCh2ZdsX7nz0ML7uadRx3PnP/RH6hqKf9fUnp7+wlIf+p+XnrNal0jzfheWX/QN",
    "gsv58+0cW+mnjMU5d3bD1Nc0nmk/ywCdJ1+01n2TLJ6PG/2VFX7bZbuDLRPqXFH3ZjuhD84fmj8",
    "T5ela8E1e38izY1AheIwoSXfNE9vtDaXhDzjsea94453X9cfUvJm/EPf8Erz6WWEgfen6R6f6r5",
    "gvNFxdtnhHwRXuygW1L80V29Q2aLzRf5GFdI67OvydZNX+cK38krXdNsy5qRbtsmj/OU3/xQq+L",
    "Js3XNDwUrHDIXU1br4cmjUfS+n/NH5o/8sAfSfNV88fknl/i3u/S/KH5I691HnH5qvljgvOPmPd",
    "dNX9o/sjt/CMmXzV/nA9/JH3/X/OH5o888EfSfNX8MTn+iPs9B80fmj/yyh9x+ar5Y3J1YkPf5z",
    "Z0fbquL3136z7inn8qvfmuecNI9/uz8vcMweXt1/41X2i+eOf5Ii7Piz6l7XdX9DwjvR/BRh4DS",
    "/OF5osLzRcrYZ5rvhhznyvud4U0X2i+uGjvrWxGed4mDM0XJ8ez/N2Z/wB3aaBX",
    ""
  };

  static char newstr [2689] = "";
  newstr[0] = '\0';
  for (i = 0; i < 37; i++) {
    strcat(newstr, encStrCodegen[i]);
  }

  return newstr;
}

static void mdlSetWorkWidths_c3_may23(SimStruct *S)
{
  const char* newstr = sf_c3_may23_get_post_codegen_info();
  sf_set_work_widths(S, newstr);
  ssSetChecksum0(S,(3381301782U));
  ssSetChecksum1(S,(3911590463U));
  ssSetChecksum2(S,(2864383395U));
  ssSetChecksum3(S,(3756688447U));
}

static void mdlRTW_c3_may23(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Stateflow");
  }
}

static void mdlStart_c3_may23(SimStruct *S)
{
  SFc3_may23InstanceStruct *chartInstance;
  chartInstance = (SFc3_may23InstanceStruct *)utMalloc(sizeof
    (SFc3_may23InstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc3_may23InstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 0;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway = sf_opaque_gateway_c3_may23;
  chartInstance->chartInfo.initializeChart = sf_opaque_initialize_c3_may23;
  chartInstance->chartInfo.terminateChart = sf_opaque_terminate_c3_may23;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c3_may23;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c3_may23;
  chartInstance->chartInfo.getSimState = sf_opaque_get_sim_state_c3_may23;
  chartInstance->chartInfo.setSimState = sf_opaque_set_sim_state_c3_may23;
  chartInstance->chartInfo.getSimStateInfo = sf_get_sim_state_info_c3_may23;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c3_may23;
  chartInstance->chartInfo.mdlStart = mdlStart_c3_may23;
  chartInstance->chartInfo.mdlSetWorkWidths = mdlSetWorkWidths_c3_may23;
  chartInstance->chartInfo.callGetHoverDataForMsg = NULL;
  chartInstance->chartInfo.extModeExec = sf_opaque_ext_mode_exec_c3_may23;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartEventFcn = NULL;
  chartInstance->S = S;
  chartInstance->chartInfo.dispatchToExportedFcn = NULL;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0,
    chartInstance->c3_JITStateAnimation,
    chartInstance->c3_JITTransitionAnimation);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  mdl_start_c3_may23(chartInstance);
}

void c3_may23_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c3_may23(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c3_may23(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c3_may23(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c3_may23_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
