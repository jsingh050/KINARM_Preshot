/* Include files */

#include "may23_sfun.h"
#include "c1_may23.h"
#include "mwmathutil.h"
#define _SF_MEX_LISTEN_FOR_CTRL_C(S)   sf_mex_listen_for_ctrl_c(S);
#ifdef utFree
#undef utFree
#endif

#ifdef utMalloc
#undef utMalloc
#endif

#ifdef __cplusplus

extern "C" void *utMalloc(size_t size);
extern "C" void utFree(void*);

#else

extern void *utMalloc(size_t size);
extern void utFree(void*);

#endif

/* Type Definitions */

/* Named Constants */
#define c1_event_e_clk                 (0)
#define c1_event_e_Trial_Start         (1)
#define CALL_EVENT                     (-1)
#define c1_IN_NO_ACTIVE_CHILD          ((uint8_T)0U)
#define c1_IN_Initialize               ((uint8_T)1U)
#define c1_IN_Moving_Targets_and_Colliding_Them ((uint8_T)2U)
#define c1_IN_PuckMoving               ((uint8_T)1U)
#define c1_IN_PuckStopped              ((uint8_T)2U)
#define c1_IN_ResolveTargetCollision   ((uint8_T)3U)
#define c1_IN_StartWithSpeed0          ((uint8_T)4U)
#define c1_IN_WaitForCollision         ((uint8_T)5U)

/* Variable Declarations */

/* Variable Definitions */
static real_T _sfTime_;

/* Function Declarations */
static void initialize_c1_may23(SFc1_may23InstanceStruct *chartInstance);
static void initialize_params_c1_may23(SFc1_may23InstanceStruct *chartInstance);
static void enable_c1_may23(SFc1_may23InstanceStruct *chartInstance);
static void disable_c1_may23(SFc1_may23InstanceStruct *chartInstance);
static void c1_update_jit_animation_state_c1_may23(SFc1_may23InstanceStruct
  *chartInstance);
static void c1_do_animation_call_c1_may23(SFc1_may23InstanceStruct
  *chartInstance);
static void ext_mode_exec_c1_may23(SFc1_may23InstanceStruct *chartInstance);
static const mxArray *get_sim_state_c1_may23(SFc1_may23InstanceStruct
  *chartInstance);
static void set_sim_state_c1_may23(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_st);
static void c1_set_sim_state_side_effects_c1_may23(SFc1_may23InstanceStruct
  *chartInstance);
static void finalize_c1_may23(SFc1_may23InstanceStruct *chartInstance);
static void sf_gateway_c1_may23(SFc1_may23InstanceStruct *chartInstance);
static void mdl_start_c1_may23(SFc1_may23InstanceStruct *chartInstance);
static void c1_chartstep_c1_may23(SFc1_may23InstanceStruct *chartInstance);
static void initSimStructsc1_may23(SFc1_may23InstanceStruct *chartInstance);
static void c1_CollisionWithHand(SFc1_may23InstanceStruct *chartInstance);
static real_T c1_check_collision(SFc1_may23InstanceStruct *chartInstance, real_T
  c1_cursor_vcode[140], real_T c1_puck_vcode[70], real_T c1_puck_offset[2]);
static void c1_eject(SFc1_may23InstanceStruct *chartInstance, real_T
                     c1_cursor_vcode[70], real_T c1_puck_vcode[70], real_T
                     c1_puck_offset[2], real_T c1_ejected_puck_offset[2]);
static real_T c1_b_check_collision(SFc1_may23InstanceStruct *chartInstance,
  real_T c1_cursor_vcode[70], real_T c1_puck_vcode[70], real_T c1_puck_offset[2]);
static void c1_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_b_force_scaling, const char_T *c1_identifier, real_T c1_y[4]);
static void c1_b_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId, real_T c1_y[4]);
static void c1_c_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_b_puck_vcode_output, const char_T *c1_identifier, real_T c1_y[70]);
static void c1_d_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId, real_T c1_y[70]);
static real_T c1_e_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_b_barrier_colliding, const char_T *c1_identifier);
static real_T c1_f_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId);
static void c1_g_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_b_hand_vector, const char_T *c1_identifier, real_T c1_y[2]);
static void c1_h_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId, real_T c1_y[2]);
static boolean_T c1_i_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_b_e_Puck_Hit, const char_T *c1_identifier);
static boolean_T c1_j_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId);
static uint32_T c1_k_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_b_e_Puck_HitEventCounter, const char_T *c1_identifier);
static uint32_T c1_l_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId);
static uint8_T c1_m_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_b_is_active_c1_may23, const char_T *c1_identifier);
static uint8_T c1_n_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId);
static void c1_o_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_b_dataWrittenToVector, const char_T *c1_identifier, boolean_T
  c1_y[25]);
static void c1_p_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId, boolean_T c1_y[25]);
static const mxArray *c1_q_emlrt_marshallIn(SFc1_may23InstanceStruct
  *chartInstance, const mxArray *c1_b_setSimStateSideEffectsInfo, const char_T
  *c1_identifier);
static const mxArray *c1_r_emlrt_marshallIn(SFc1_may23InstanceStruct
  *chartInstance, const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId);
static void c1_sqrt(SFc1_may23InstanceStruct *chartInstance, real_T *c1_x);
static uint32_T c1__u32_add__(SFc1_may23InstanceStruct *chartInstance, uint32_T
  c1_b, uint32_T c1_c, int32_T c1_EMLOvCount_src_loc, uint32_T c1_ssid_src_loc,
  int32_T c1_offset_src_loc, int32_T c1_length_src_loc);
static void init_dsm_address_info(SFc1_may23InstanceStruct *chartInstance);
static void init_simulink_io_address(SFc1_may23InstanceStruct *chartInstance);

/* Function Definitions */
static void initialize_c1_may23(SFc1_may23InstanceStruct *chartInstance)
{
  sim_mode_is_external(chartInstance->S);
  _sfTime_ = sf_get_time(chartInstance->S);
  chartInstance->c1_doSetSimStateSideEffects = 0U;
  chartInstance->c1_setSimStateSideEffectsInfo = NULL;
  *chartInstance->c1_is_active_CollisionWithHand = 0U;
  *chartInstance->c1_is_CollisionWithHand = c1_IN_NO_ACTIVE_CHILD;
  *chartInstance->c1_is_active_UpdatePosition = 0U;
  *chartInstance->c1_is_active_UpdateVelocity = 0U;
  *chartInstance->c1_is_active_c1_may23 = 0U;
  *chartInstance->c1_is_c1_may23 = c1_IN_NO_ACTIVE_CHILD;
  *chartInstance->c1_e_Puck_StoppedEventCounter = 0U;
  *chartInstance->c1_e_Puck_Stopped = false;
  *chartInstance->c1_e_Puck_HitEventCounter = 0U;
  *chartInstance->c1_e_Puck_Hit = false;
}

static void initialize_params_c1_may23(SFc1_may23InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void enable_c1_may23(SFc1_may23InstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void disable_c1_may23(SFc1_may23InstanceStruct *chartInstance)
{
  _sfTime_ = sf_get_time(chartInstance->S);
}

static void c1_update_jit_animation_state_c1_may23(SFc1_may23InstanceStruct
  *chartInstance)
{
  chartInstance->c1_JITStateAnimation[0U] = (uint8_T)
    (*chartInstance->c1_is_c1_may23 == c1_IN_Initialize);
  chartInstance->c1_JITStateAnimation[1U] = (uint8_T)
    (*chartInstance->c1_is_c1_may23 == c1_IN_Moving_Targets_and_Colliding_Them);
  chartInstance->c1_JITStateAnimation[2U] = (uint8_T)
    (*chartInstance->c1_is_CollisionWithHand == c1_IN_WaitForCollision);
  chartInstance->c1_JITStateAnimation[3U] = (uint8_T)
    (*chartInstance->c1_is_CollisionWithHand == c1_IN_ResolveTargetCollision);
  chartInstance->c1_JITStateAnimation[4U] = (uint8_T)
    (*chartInstance->c1_is_CollisionWithHand == c1_IN_StartWithSpeed0);
  chartInstance->c1_JITStateAnimation[5U] = (uint8_T)
    (*chartInstance->c1_is_active_CollisionWithHand == 1U);
  chartInstance->c1_JITStateAnimation[6U] = (uint8_T)
    (*chartInstance->c1_is_active_UpdatePosition == 1U);
  chartInstance->c1_JITStateAnimation[7U] = (uint8_T)
    (*chartInstance->c1_is_active_UpdateVelocity == 1U);
  chartInstance->c1_JITStateAnimation[8U] = (uint8_T)
    (*chartInstance->c1_is_CollisionWithHand == c1_IN_PuckMoving);
  chartInstance->c1_JITStateAnimation[9U] = (uint8_T)
    (*chartInstance->c1_is_CollisionWithHand == c1_IN_PuckStopped);
}

static void c1_do_animation_call_c1_may23(SFc1_may23InstanceStruct
  *chartInstance)
{
  sfDoAnimationWrapper(chartInstance->S, false, true);
  sfDoAnimationWrapper(chartInstance->S, false, false);
}

static void ext_mode_exec_c1_may23(SFc1_may23InstanceStruct *chartInstance)
{
  c1_update_jit_animation_state_c1_may23(chartInstance);
  c1_do_animation_call_c1_may23(chartInstance);
}

static const mxArray *get_sim_state_c1_may23(SFc1_may23InstanceStruct
  *chartInstance)
{
  const mxArray *c1_st;
  const mxArray *c1_y = NULL;
  const mxArray *c1_b_y = NULL;
  const mxArray *c1_c_y = NULL;
  const mxArray *c1_d_y = NULL;
  const mxArray *c1_e_y = NULL;
  const mxArray *c1_f_y = NULL;
  const mxArray *c1_g_y = NULL;
  const mxArray *c1_h_y = NULL;
  const mxArray *c1_i_y = NULL;
  const mxArray *c1_j_y = NULL;
  const mxArray *c1_k_y = NULL;
  const mxArray *c1_l_y = NULL;
  const mxArray *c1_m_y = NULL;
  const mxArray *c1_n_y = NULL;
  const mxArray *c1_o_y = NULL;
  const mxArray *c1_p_y = NULL;
  const mxArray *c1_q_y = NULL;
  const mxArray *c1_r_y = NULL;
  const mxArray *c1_s_y = NULL;
  const mxArray *c1_t_y = NULL;
  const mxArray *c1_u_y = NULL;
  const mxArray *c1_v_y = NULL;
  const mxArray *c1_w_y = NULL;
  const mxArray *c1_x_y = NULL;
  const mxArray *c1_y_y = NULL;
  const mxArray *c1_ab_y = NULL;
  const mxArray *c1_bb_y = NULL;
  const mxArray *c1_cb_y = NULL;
  const mxArray *c1_db_y = NULL;
  const mxArray *c1_eb_y = NULL;
  const mxArray *c1_fb_y = NULL;
  const mxArray *c1_gb_y = NULL;
  const mxArray *c1_hb_y = NULL;
  const mxArray *c1_ib_y = NULL;
  const mxArray *c1_jb_y = NULL;
  c1_st = NULL;
  c1_st = NULL;
  c1_y = NULL;
  sf_mex_assign(&c1_y, sf_mex_createcellmatrix(34, 1), false);
  c1_b_y = NULL;
  sf_mex_assign(&c1_b_y, sf_mex_create("y", *chartInstance->c1_force_scaling, 0,
    0U, 1U, 0U, 2, 1, 4), false);
  sf_mex_setcell(c1_y, 0, c1_b_y);
  c1_c_y = NULL;
  sf_mex_assign(&c1_c_y, sf_mex_create("y", *chartInstance->c1_puck_vcode_output,
    0, 0U, 1U, 0U, 2, 1, 70), false);
  sf_mex_setcell(c1_y, 1, c1_c_y);
  c1_d_y = NULL;
  sf_mex_assign(&c1_d_y, sf_mex_create("y", chartInstance->c1_barrier_colliding,
    0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 2, c1_d_y);
  c1_e_y = NULL;
  sf_mex_assign(&c1_e_y, sf_mex_create("y", chartInstance->c1_barrier_vel, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 3, c1_e_y);
  c1_f_y = NULL;
  sf_mex_assign(&c1_f_y, sf_mex_create("y",
    chartInstance->c1_check_collision_barrier1, 0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 4, c1_f_y);
  c1_g_y = NULL;
  sf_mex_assign(&c1_g_y, sf_mex_create("y",
    chartInstance->c1_force_scaling_barrier, 0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 5, c1_g_y);
  c1_h_y = NULL;
  sf_mex_assign(&c1_h_y, sf_mex_create("y", chartInstance->c1_goal_bottom, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 6, c1_h_y);
  c1_i_y = NULL;
  sf_mex_assign(&c1_i_y, sf_mex_create("y", chartInstance->c1_goal_left, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 7, c1_i_y);
  c1_j_y = NULL;
  sf_mex_assign(&c1_j_y, sf_mex_create("y", chartInstance->c1_goal_right, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 8, c1_j_y);
  c1_k_y = NULL;
  sf_mex_assign(&c1_k_y, sf_mex_create("y",
    chartInstance->c1_hand_offset_position, 0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 9, c1_k_y);
  c1_l_y = NULL;
  sf_mex_assign(&c1_l_y, sf_mex_create("y", *chartInstance->c1_hand_vector, 0,
    0U, 1U, 0U, 2, 1, 2), false);
  sf_mex_setcell(c1_y, 10, c1_l_y);
  c1_m_y = NULL;
  sf_mex_assign(&c1_m_y, sf_mex_create("y", *chartInstance->c1_hand_vel, 0, 0U,
    1U, 0U, 2, 1, 2), false);
  sf_mex_setcell(c1_y, 11, c1_m_y);
  c1_n_y = NULL;
  sf_mex_assign(&c1_n_y, sf_mex_create("y",
    chartInstance->c1_new_hand_posistion_c, 0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 12, c1_n_y);
  c1_o_y = NULL;
  sf_mex_assign(&c1_o_y, sf_mex_create("y", chartInstance->c1_prev_hand_vel, 0,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 13, c1_o_y);
  c1_p_y = NULL;
  sf_mex_assign(&c1_p_y, sf_mex_create("y", *chartInstance->c1_prev_vel, 0, 0U,
    1U, 0U, 2, 1, 2), false);
  sf_mex_setcell(c1_y, 14, c1_p_y);
  c1_q_y = NULL;
  sf_mex_assign(&c1_q_y, sf_mex_create("y", chartInstance->c1_puck_damping, 0,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 15, c1_q_y);
  c1_r_y = NULL;
  sf_mex_assign(&c1_r_y, sf_mex_create("y",
    *chartInstance->c1_puck_offset_position, 0, 0U, 1U, 0U, 2, 1, 2), false);
  sf_mex_setcell(c1_y, 16, c1_r_y);
  c1_s_y = NULL;
  sf_mex_assign(&c1_s_y, sf_mex_create("y", *chartInstance->c1_puck_velocity, 0,
    0U, 1U, 0U, 2, 1, 2), false);
  sf_mex_setcell(c1_y, 17, c1_s_y);
  c1_t_y = NULL;
  sf_mex_assign(&c1_t_y, sf_mex_create("y", chartInstance->c1_rect_bottom, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 18, c1_t_y);
  c1_u_y = NULL;
  sf_mex_assign(&c1_u_y, sf_mex_create("y", chartInstance->c1_rect_left, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 19, c1_u_y);
  c1_v_y = NULL;
  sf_mex_assign(&c1_v_y, sf_mex_create("y",
    chartInstance->c1_rect_offset_position, 0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 20, c1_v_y);
  c1_w_y = NULL;
  sf_mex_assign(&c1_w_y, sf_mex_create("y", chartInstance->c1_rect_right, 0, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 21, c1_w_y);
  c1_x_y = NULL;
  sf_mex_assign(&c1_x_y, sf_mex_create("y", chartInstance->c1_target_colliding,
    0, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 22, c1_x_y);
  c1_y_y = NULL;
  sf_mex_assign(&c1_y_y, sf_mex_create("y", chartInstance->c1_e_Puck_Hit, 11, 0U,
    0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 23, c1_y_y);
  c1_ab_y = NULL;
  sf_mex_assign(&c1_ab_y, sf_mex_create("y", chartInstance->c1_e_Puck_Stopped,
    11, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 24, c1_ab_y);
  c1_bb_y = NULL;
  sf_mex_assign(&c1_bb_y, sf_mex_create("y",
    chartInstance->c1_e_Puck_HitEventCounter, 7, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 25, c1_bb_y);
  c1_cb_y = NULL;
  sf_mex_assign(&c1_cb_y, sf_mex_create("y",
    chartInstance->c1_e_Puck_StoppedEventCounter, 7, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 26, c1_cb_y);
  c1_db_y = NULL;
  sf_mex_assign(&c1_db_y, sf_mex_create("y",
    chartInstance->c1_is_active_c1_may23, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 27, c1_db_y);
  c1_eb_y = NULL;
  sf_mex_assign(&c1_eb_y, sf_mex_create("y",
    chartInstance->c1_is_active_CollisionWithHand, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 28, c1_eb_y);
  c1_fb_y = NULL;
  sf_mex_assign(&c1_fb_y, sf_mex_create("y",
    chartInstance->c1_is_active_UpdatePosition, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 29, c1_fb_y);
  c1_gb_y = NULL;
  sf_mex_assign(&c1_gb_y, sf_mex_create("y",
    chartInstance->c1_is_active_UpdateVelocity, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 30, c1_gb_y);
  c1_hb_y = NULL;
  sf_mex_assign(&c1_hb_y, sf_mex_create("y", chartInstance->c1_is_c1_may23, 3,
    0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 31, c1_hb_y);
  c1_ib_y = NULL;
  sf_mex_assign(&c1_ib_y, sf_mex_create("y",
    chartInstance->c1_is_CollisionWithHand, 3, 0U, 0U, 0U, 0), false);
  sf_mex_setcell(c1_y, 32, c1_ib_y);
  c1_jb_y = NULL;
  sf_mex_assign(&c1_jb_y, sf_mex_create("y",
    chartInstance->c1_dataWrittenToVector, 11, 0U, 1U, 0U, 1, 25), false);
  sf_mex_setcell(c1_y, 33, c1_jb_y);
  sf_mex_assign(&c1_st, c1_y, false);
  return c1_st;
}

static void set_sim_state_c1_may23(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_st)
{
  const mxArray *c1_u;
  c1_u = sf_mex_dup(c1_st);
  c1_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 0)),
                      "force_scaling", *chartInstance->c1_force_scaling);
  c1_c_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 1)),
                        "puck_vcode_output",
                        *chartInstance->c1_puck_vcode_output);
  *chartInstance->c1_barrier_colliding = c1_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 2)), "barrier_colliding");
  *chartInstance->c1_barrier_vel = c1_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 3)), "barrier_vel");
  *chartInstance->c1_check_collision_barrier1 = c1_e_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 4)),
     "check_collision_barrier1");
  *chartInstance->c1_force_scaling_barrier = c1_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 5)), "force_scaling_barrier");
  *chartInstance->c1_goal_bottom = c1_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 6)), "goal_bottom");
  *chartInstance->c1_goal_left = c1_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c1_u, 7)), "goal_left");
  *chartInstance->c1_goal_right = c1_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 8)), "goal_right");
  *chartInstance->c1_hand_offset_position = c1_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 9)), "hand_offset_position");
  c1_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 10)),
                        "hand_vector", *chartInstance->c1_hand_vector);
  c1_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 11)),
                        "hand_vel", *chartInstance->c1_hand_vel);
  *chartInstance->c1_new_hand_posistion_c = c1_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 12)), "new_hand_posistion_c");
  *chartInstance->c1_prev_hand_vel = c1_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 13)), "prev_hand_vel");
  c1_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 14)),
                        "prev_vel", *chartInstance->c1_prev_vel);
  *chartInstance->c1_puck_damping = c1_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 15)), "puck_damping");
  c1_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 16)),
                        "puck_offset_position",
                        *chartInstance->c1_puck_offset_position);
  c1_g_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 17)),
                        "puck_velocity", *chartInstance->c1_puck_velocity);
  *chartInstance->c1_rect_bottom = c1_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 18)), "rect_bottom");
  *chartInstance->c1_rect_left = c1_e_emlrt_marshallIn(chartInstance, sf_mex_dup
    (sf_mex_getcell(c1_u, 19)), "rect_left");
  *chartInstance->c1_rect_offset_position = c1_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 20)), "rect_offset_position");
  *chartInstance->c1_rect_right = c1_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 21)), "rect_right");
  *chartInstance->c1_target_colliding = c1_e_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 22)), "target_colliding");
  *chartInstance->c1_e_Puck_Hit = c1_i_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 23)), "e_Puck_Hit");
  *chartInstance->c1_e_Puck_Stopped = c1_i_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 24)), "e_Puck_Stopped");
  *chartInstance->c1_e_Puck_HitEventCounter = c1_k_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 25)),
     "e_Puck_HitEventCounter");
  *chartInstance->c1_e_Puck_StoppedEventCounter = c1_k_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 26)),
     "e_Puck_StoppedEventCounter");
  *chartInstance->c1_is_active_c1_may23 = c1_m_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 27)), "is_active_c1_may23");
  *chartInstance->c1_is_active_CollisionWithHand = c1_m_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 28)),
     "is_active_CollisionWithHand");
  *chartInstance->c1_is_active_UpdatePosition = c1_m_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 29)),
     "is_active_UpdatePosition");
  *chartInstance->c1_is_active_UpdateVelocity = c1_m_emlrt_marshallIn
    (chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 30)),
     "is_active_UpdateVelocity");
  *chartInstance->c1_is_c1_may23 = c1_m_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 31)), "is_c1_may23");
  *chartInstance->c1_is_CollisionWithHand = c1_m_emlrt_marshallIn(chartInstance,
    sf_mex_dup(sf_mex_getcell(c1_u, 32)), "is_CollisionWithHand");
  c1_o_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell(c1_u, 33)),
                        "dataWrittenToVector",
                        chartInstance->c1_dataWrittenToVector);
  sf_mex_assign(&chartInstance->c1_setSimStateSideEffectsInfo,
                c1_q_emlrt_marshallIn(chartInstance, sf_mex_dup(sf_mex_getcell
    (c1_u, 34)), "setSimStateSideEffectsInfo"), true);
  sf_mex_destroy(&c1_u);
  chartInstance->c1_doSetSimStateSideEffects = 1U;
  c1_update_jit_animation_state_c1_may23(chartInstance);
  sf_mex_destroy(&c1_st);
}

static void c1_set_sim_state_side_effects_c1_may23(SFc1_may23InstanceStruct
  *chartInstance)
{
  if (chartInstance->c1_doSetSimStateSideEffects != 0) {
    chartInstance->c1_doSetSimStateSideEffects = 0U;
  }
}

static void finalize_c1_may23(SFc1_may23InstanceStruct *chartInstance)
{
  sf_mex_destroy(&chartInstance->c1_setSimStateSideEffectsInfo);
}

static void sf_gateway_c1_may23(SFc1_may23InstanceStruct *chartInstance)
{
  int32_T c1_inputEventFiredFlag;
  c1_set_sim_state_side_effects_c1_may23(chartInstance);
  chartInstance->c1_JITTransitionAnimation[0] = 0U;
  chartInstance->c1_JITTransitionAnimation[1] = 0U;
  chartInstance->c1_JITTransitionAnimation[2] = 0U;
  chartInstance->c1_JITTransitionAnimation[3] = 0U;
  chartInstance->c1_JITTransitionAnimation[4] = 0U;
  chartInstance->c1_JITTransitionAnimation[5] = 0U;
  chartInstance->c1_JITTransitionAnimation[6] = 0U;
  chartInstance->c1_JITTransitionAnimation[7] = 0U;
  chartInstance->c1_JITTransitionAnimation[8] = 0U;
  _sfTime_ = sf_get_time(chartInstance->S);
  c1_inputEventFiredFlag = 0;
  if (*chartInstance->c1_e_clk == 1) {
    c1_inputEventFiredFlag = 1;
    *chartInstance->c1_sfEvent = c1_event_e_clk;
    c1_chartstep_c1_may23(chartInstance);
  }

  if (*chartInstance->c1_e_Trial_Start != 0) {
    c1_inputEventFiredFlag = 1;
    *chartInstance->c1_sfEvent = c1_event_e_Trial_Start;
    c1_chartstep_c1_may23(chartInstance);
  }

  if (c1_inputEventFiredFlag != 0) {
    if (*chartInstance->c1_e_Puck_StoppedEventCounter > 0U) {
      *chartInstance->c1_e_Puck_Stopped = !*chartInstance->c1_e_Puck_Stopped;
      (*chartInstance->c1_e_Puck_StoppedEventCounter)--;
    }

    if (*chartInstance->c1_e_Puck_HitEventCounter > 0U) {
      *chartInstance->c1_e_Puck_Hit = !*chartInstance->c1_e_Puck_Hit;
      (*chartInstance->c1_e_Puck_HitEventCounter)--;
    }
  }

  c1_update_jit_animation_state_c1_may23(chartInstance);
  c1_do_animation_call_c1_may23(chartInstance);
}

static void mdl_start_c1_may23(SFc1_may23InstanceStruct *chartInstance)
{
  setLegacyDebuggerFlag(chartInstance->S, false);
  setDebuggerFlag(chartInstance->S, true);
  sim_mode_is_external(chartInstance->S);
}

static void c1_chartstep_c1_may23(SFc1_may23InstanceStruct *chartInstance)
{
  int32_T c1_i;
  const mxArray *c1_y = NULL;
  const mxArray *c1_b_y = NULL;
  if (*chartInstance->c1_is_active_c1_may23 == 0U) {
    *chartInstance->c1_is_active_c1_may23 = 1U;
    chartInstance->c1_JITTransitionAnimation[0U] = 1U;
    *chartInstance->c1_is_c1_may23 = c1_IN_Initialize;
    for (c1_i = 0; c1_i < 4; c1_i++) {
      (*chartInstance->c1_force_scaling)[c1_i] = 0.0;
    }

    chartInstance->c1_dataWrittenToVector[1U] = true;
    for (c1_i = 0; c1_i < 70; c1_i++) {
      (*chartInstance->c1_puck_vcode_output)[c1_i] = 0.0;
    }

    chartInstance->c1_dataWrittenToVector[0U] = true;
    chartInstance->c1_dataWrittenToVector[21U] = true;
    for (c1_i = 0; c1_i < 2; c1_i++) {
      (*chartInstance->c1_puck_velocity)[c1_i] = 0.0;
      (*chartInstance->c1_puck_offset_position)[c1_i] = 0.0;
    }

    chartInstance->c1_dataWrittenToVector[20U] = true;
    *chartInstance->c1_puck_damping = (*chartInstance->c1_Trial_Protocol)
      [sf_eml_array_bounds_check(NULL, chartInstance->S, 2U, 195, 28, 74U,
      (int32_T)sf_integer_check(chartInstance->S, 2U, 195U, 28U, PUCK_DAMPING),
      1, 50) - 1];
    chartInstance->c1_dataWrittenToVector[22U] = true;
  } else {
    switch (*chartInstance->c1_is_c1_may23) {
     case c1_IN_Initialize:
      chartInstance->c1_JITTransitionAnimation[1U] = 1U;
      *chartInstance->c1_is_c1_may23 = c1_IN_NO_ACTIVE_CHILD;
      *chartInstance->c1_is_c1_may23 = c1_IN_Moving_Targets_and_Colliding_Them;
      *chartInstance->c1_is_active_UpdatePosition = 1U;
      *chartInstance->c1_is_active_UpdateVelocity = 1U;
      *chartInstance->c1_is_active_CollisionWithHand = 1U;
      *chartInstance->c1_is_CollisionWithHand = c1_IN_StartWithSpeed0;
      chartInstance->c1_dataWrittenToVector[21U] = true;
      for (c1_i = 0; c1_i < 2; c1_i++) {
        (*chartInstance->c1_puck_velocity)[c1_i] = 0.0;
        (*chartInstance->c1_puck_offset_position)[c1_i] = 0.0;
      }

      chartInstance->c1_dataWrittenToVector[20U] = true;
      break;

     case c1_IN_Moving_Targets_and_Colliding_Them:
      for (c1_i = 0; c1_i < 70; c1_i++) {
        (*chartInstance->c1_puck_vcode_output)[c1_i] =
          (*chartInstance->c1_puck_vcode_in)[c1_i];
      }

      chartInstance->c1_dataWrittenToVector[0U] = true;
      if (!chartInstance->c1_dataWrittenToVector[20U]) {
        sf_read_before_write_error(chartInstance->S, 60U, 337U, 82, 20);
      }

      if (!chartInstance->c1_dataWrittenToVector[21U]) {
        sf_read_before_write_error(chartInstance->S, 61U, 337U, 104, 13);
      }

      for (c1_i = 0; c1_i < 2; c1_i++) {
        (*chartInstance->c1_puck_offset_position)[c1_i] +=
          (*chartInstance->c1_puck_velocity)[c1_i];
      }

      chartInstance->c1_dataWrittenToVector[20U] = true;
      if (!chartInstance->c1_dataWrittenToVector[0U]) {
        sf_read_before_write_error(chartInstance->S, 75U, 337U, 144, 17);
      }

      if (!chartInstance->c1_dataWrittenToVector[20U]) {
        sf_read_before_write_error(chartInstance->S, 60U, 337U, 167, 20);
      }

      for (c1_i = 0; c1_i < 2; c1_i++) {
        (*chartInstance->c1_puck_vcode_output)[c1_i + 2] +=
          (*chartInstance->c1_puck_offset_position)[c1_i];
      }

      chartInstance->c1_dataWrittenToVector[0U] = true;
      if (!chartInstance->c1_dataWrittenToVector[0U]) {
        sf_read_before_write_error(chartInstance->S, 75U, 337U, 119, 17);
      }

      sf_mex_printf("%s =\\n", "puck_vcode_output");
      c1_y = NULL;
      sf_mex_assign(&c1_y, sf_mex_create("y",
        *chartInstance->c1_puck_vcode_output, 0, 0U, 1U, 0U, 2, 1, 70), false);
      sf_mex_call(chartInstance->c1_fEmlrtCtx, "disp", 0U, 1U, 14, c1_y);
      if (!chartInstance->c1_dataWrittenToVector[22U]) {
        sf_read_before_write_error(chartInstance->S, 59U, 349U, 40, 12);
      }

      if (!chartInstance->c1_dataWrittenToVector[21U]) {
        sf_read_before_write_error(chartInstance->S, 61U, 349U, 55, 13);
      }

      for (c1_i = 0; c1_i < 2; c1_i++) {
        (*chartInstance->c1_puck_velocity)[c1_i] *=
          *chartInstance->c1_puck_damping;
      }

      chartInstance->c1_dataWrittenToVector[21U] = true;
      if (!chartInstance->c1_dataWrittenToVector[21U]) {
        sf_read_before_write_error(chartInstance->S, 61U, 349U, 24, 13);
      }

      sf_mex_printf("%s =\\n", "puck_velocity");
      c1_b_y = NULL;
      sf_mex_assign(&c1_b_y, sf_mex_create("y", *chartInstance->c1_puck_velocity,
        0, 0U, 1U, 0U, 2, 1, 2), false);
      sf_mex_call(chartInstance->c1_fEmlrtCtx, "disp", 0U, 1U, 14, c1_b_y);
      c1_CollisionWithHand(chartInstance);
      break;

     default:
      /* Unreachable state, for coverage only */
      *chartInstance->c1_is_c1_may23 = c1_IN_NO_ACTIVE_CHILD;
      break;
    }
  }
}

static void initSimStructsc1_may23(SFc1_may23InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void c1_CollisionWithHand(SFc1_may23InstanceStruct *chartInstance)
{
  int32_T c1_k;
  real_T c1_z1[2];
  real_T c1_x;
  real_T c1_dv[70];
  const mxArray *c1_y = NULL;
  static char_T c1_cv[19] = { 'M', 'A', 'T', 'L', 'A', 'B', ':', 'n', 'o', 'l',
    'o', 'g', 'i', 'c', 'a', 'l', 'n', 'a', 'n' };

  const mxArray *c1_b_y = NULL;
  const mxArray *c1_c_y = NULL;
  const mxArray *c1_d_y = NULL;
  real_T c1_a;
  switch (*chartInstance->c1_is_CollisionWithHand) {
   case c1_IN_PuckMoving:
    if (!chartInstance->c1_dataWrittenToVector[21U]) {
      sf_read_before_write_error(chartInstance->S, 61U, 354U, 5, 13);
    }

    for (c1_k = 0; c1_k < 2; c1_k++) {
      c1_z1[c1_k] = (*chartInstance->c1_puck_velocity)[c1_k] *
        (*chartInstance->c1_puck_velocity)[c1_k];
    }

    if (c1_z1[0] + c1_z1[1] < 2.2204460492503131E-16) {
      chartInstance->c1_JITTransitionAnimation[7U] = 1U;
      *chartInstance->c1_is_CollisionWithHand = c1_IN_NO_ACTIVE_CHILD;
      *chartInstance->c1_is_CollisionWithHand = c1_IN_PuckStopped;
      *chartInstance->c1_e_Puck_StoppedEventCounter = c1__u32_add__
        (chartInstance, *chartInstance->c1_e_Puck_StoppedEventCounter, 1U, 0,
         355U, 19, 14);
    }
    break;

   case c1_IN_PuckStopped:
    if (*chartInstance->c1_sfEvent == c1_event_e_Trial_Start) {
      chartInstance->c1_JITTransitionAnimation[8U] = 1U;
      *chartInstance->c1_is_CollisionWithHand = c1_IN_NO_ACTIVE_CHILD;
      *chartInstance->c1_is_CollisionWithHand = c1_IN_StartWithSpeed0;
      chartInstance->c1_dataWrittenToVector[21U] = true;
      for (c1_k = 0; c1_k < 2; c1_k++) {
        (*chartInstance->c1_puck_velocity)[c1_k] = 0.0;
        (*chartInstance->c1_puck_offset_position)[c1_k] = 0.0;
      }

      chartInstance->c1_dataWrittenToVector[20U] = true;
    }
    break;

   case c1_IN_ResolveTargetCollision:
    if (!chartInstance->c1_dataWrittenToVector[4U]) {
      sf_read_before_write_error(chartInstance->S, 66U, 49U, 35, 16);
    }

    if (!chartInstance->c1_dataWrittenToVector[20U]) {
      sf_read_before_write_error(chartInstance->S, 60U, 49U, 71, 20);
    }

    sf_eml_array_bounds_check(NULL, chartInstance->S, 49U, 35, 16, MAX_uint32_T,
      (int32_T)sf_integer_check(chartInstance->S, 49U, 35U, 16U,
      *chartInstance->c1_target_colliding), 1, 2);
    for (c1_k = 0; c1_k < 70; c1_k++) {
      c1_dv[c1_k] = (*chartInstance->c1_cursor_vcode_in)[((int32_T)
        *chartInstance->c1_target_colliding + (c1_k << 1)) - 1];
    }

    c1_x = c1_b_check_collision(chartInstance, c1_dv,
      *chartInstance->c1_puck_vcode_in, *chartInstance->c1_puck_offset_position);
    if (muDoubleScalarIsNaN(c1_x)) {
      c1_y = NULL;
      sf_mex_assign(&c1_y, sf_mex_create("y", c1_cv, 10, 0U, 1U, 0U, 2, 1, 19),
                    false);
      c1_b_y = NULL;
      sf_mex_assign(&c1_b_y, sf_mex_create("y", c1_cv, 10, 0U, 1U, 0U, 2, 1, 19),
                    false);
      sf_mex_call(chartInstance->c1_fEmlrtCtx, "error", 0U, 2U, 14, c1_y, 14,
                  sf_mex_call(chartInstance->c1_fEmlrtCtx, "getString", 1U, 1U,
        14, sf_mex_call(chartInstance->c1_fEmlrtCtx, "message", 1U, 1U, 14,
                        c1_b_y)));
    }

    if (!(c1_x != 0.0)) {
      chartInstance->c1_JITTransitionAnimation[2U] = 1U;
      *chartInstance->c1_is_CollisionWithHand = c1_IN_NO_ACTIVE_CHILD;
      *chartInstance->c1_target_colliding = 0.0;
      chartInstance->c1_dataWrittenToVector[4U] = true;
      if (!chartInstance->c1_dataWrittenToVector[4U]) {
        sf_read_before_write_error(chartInstance->S, 66U, 49U, 96, 16);
      }

      sf_mex_printf("%s =\\n", "target_colliding");
      c1_d_y = NULL;
      sf_mex_assign(&c1_d_y, sf_mex_create("y",
        chartInstance->c1_target_colliding, 0, 0U, 0U, 0U, 0), false);
      sf_mex_call(chartInstance->c1_fEmlrtCtx, "disp", 0U, 1U, 14, c1_d_y);
      *chartInstance->c1_is_CollisionWithHand = c1_IN_PuckMoving;
    } else {
      if (*chartInstance->c1_sfEvent == c1_event_e_Trial_Start) {
        chartInstance->c1_JITTransitionAnimation[6U] = 1U;
        *chartInstance->c1_is_CollisionWithHand = c1_IN_NO_ACTIVE_CHILD;
        *chartInstance->c1_is_CollisionWithHand = c1_IN_StartWithSpeed0;
        chartInstance->c1_dataWrittenToVector[21U] = true;
        for (c1_k = 0; c1_k < 2; c1_k++) {
          (*chartInstance->c1_puck_velocity)[c1_k] = 0.0;
          (*chartInstance->c1_puck_offset_position)[c1_k] = 0.0;
        }

        chartInstance->c1_dataWrittenToVector[20U] = true;
      }
    }
    break;

   case c1_IN_StartWithSpeed0:
    chartInstance->c1_JITTransitionAnimation[3U] = 1U;
    *chartInstance->c1_is_CollisionWithHand = c1_IN_NO_ACTIVE_CHILD;
    *chartInstance->c1_is_CollisionWithHand = c1_IN_WaitForCollision;
    for (c1_k = 0; c1_k < 4; c1_k++) {
      (*chartInstance->c1_force_scaling)[c1_k] = 0.0;
    }

    chartInstance->c1_dataWrittenToVector[1U] = true;
    break;

   case c1_IN_WaitForCollision:
    if (!chartInstance->c1_dataWrittenToVector[4U]) {
      sf_read_before_write_error(chartInstance->S, 66U, 117U, 2, 16);
    }

    if (*chartInstance->c1_target_colliding != 0.0) {
      chartInstance->c1_JITTransitionAnimation[4U] = 1U;
      *chartInstance->c1_is_CollisionWithHand = c1_IN_NO_ACTIVE_CHILD;
      *chartInstance->c1_is_CollisionWithHand = c1_IN_ResolveTargetCollision;
      if (!chartInstance->c1_dataWrittenToVector[4U]) {
        sf_read_before_write_error(chartInstance->S, 66U, 45U, 218, 16);
      }

      if (!chartInstance->c1_dataWrittenToVector[20U]) {
        sf_read_before_write_error(chartInstance->S, 60U, 45U, 254, 20);
      }

      sf_eml_array_bounds_check(NULL, chartInstance->S, 45U, 218, 16,
        MAX_uint32_T, (int32_T)sf_integer_check(chartInstance->S, 45U, 218U, 16U,
        *chartInstance->c1_target_colliding), 1, 2);
      for (c1_k = 0; c1_k < 70; c1_k++) {
        c1_dv[c1_k] = (*chartInstance->c1_cursor_vcode_in)[((int32_T)
          *chartInstance->c1_target_colliding + (c1_k << 1)) - 1];
      }

      for (c1_k = 0; c1_k < 2; c1_k++) {
        c1_z1[c1_k] = (*chartInstance->c1_puck_offset_position)[c1_k];
      }

      c1_eject(chartInstance, c1_dv, *chartInstance->c1_puck_vcode_in, c1_z1,
               *chartInstance->c1_puck_offset_position);
      chartInstance->c1_dataWrittenToVector[20U] = true;
      if (!chartInstance->c1_dataWrittenToVector[21U]) {
        sf_read_before_write_error(chartInstance->S, 61U, 45U, 289, 13);
      }

      for (c1_k = 0; c1_k < 2; c1_k++) {
        (*chartInstance->c1_prev_vel)[c1_k] = (*chartInstance->c1_puck_velocity)
          [c1_k];
      }

      chartInstance->c1_dataWrittenToVector[3U] = true;
      if (!chartInstance->c1_dataWrittenToVector[4U]) {
        sf_read_before_write_error(chartInstance->S, 66U, 45U, 328, 16);
      }

      sf_eml_array_bounds_check(NULL, chartInstance->S, 45U, 328, 16,
        MAX_uint32_T, (int32_T)sf_integer_check(chartInstance->S, 45U, 328U, 16U,
        *chartInstance->c1_target_colliding), 1, 2);
      for (c1_k = 0; c1_k < 2; c1_k++) {
        (*chartInstance->c1_hand_vel)[c1_k] = (*chartInstance->c1_hand_speed)
          [((int32_T)*chartInstance->c1_target_colliding + (c1_k << 1)) - 1] /
          1000.0;
      }

      chartInstance->c1_dataWrittenToVector[5U] = true;
      if (!chartInstance->c1_dataWrittenToVector[21U]) {
        sf_read_before_write_error(chartInstance->S, 61U, 45U, 661, 13);
      }

      if (!chartInstance->c1_dataWrittenToVector[5U]) {
        sf_read_before_write_error(chartInstance->S, 55U, 45U, 713, 8);
      }

      c1_x = (*chartInstance->c1_mass_puck - *chartInstance->c1_mass_hand) /
        (*chartInstance->c1_mass_puck + *chartInstance->c1_mass_hand);
      c1_a = 2.0 * *chartInstance->c1_mass_hand / (*chartInstance->c1_mass_hand
        + *chartInstance->c1_mass_puck);
      chartInstance->c1_dataWrittenToVector[21U] = true;
      for (c1_k = 0; c1_k < 2; c1_k++) {
        (*chartInstance->c1_puck_velocity)[c1_k] = c1_x *
          (*chartInstance->c1_puck_velocity)[c1_k] + c1_a *
          (*chartInstance->c1_hand_vel)[c1_k];
        (*chartInstance->c1_hand_vector)[c1_k] = (real_T)c1_k + 1.0;
      }

      chartInstance->c1_dataWrittenToVector[2U] = true;
      if (!chartInstance->c1_dataWrittenToVector[2U]) {
        sf_read_before_write_error(chartInstance->S, 54U, 45U, 865, 11);
      }

      if (!chartInstance->c1_dataWrittenToVector[4U]) {
        sf_read_before_write_error(chartInstance->S, 66U, 45U, 877, 16);
      }

      if (!chartInstance->c1_dataWrittenToVector[3U]) {
        sf_read_before_write_error(chartInstance->S, 58U, 45U, 900, 8);
      }

      if (!chartInstance->c1_dataWrittenToVector[21U]) {
        sf_read_before_write_error(chartInstance->S, 61U, 45U, 911, 13);
      }

      sf_eml_array_bounds_check(NULL, chartInstance->S, 45U, 877, 16,
        MAX_uint32_T, (int32_T)sf_integer_check(chartInstance->S, 45U, 877U, 16U,
        *chartInstance->c1_target_colliding), 1, 1);
      for (c1_k = 0; c1_k < 2; c1_k++) {
        (*chartInstance->c1_force_scaling)[sf_eml_array_bounds_check(NULL,
          chartInstance->S, 45U, 851, 46, 76U, (int32_T)sf_integer_check
          (chartInstance->S, 45U, 851U, 46U, (*chartInstance->c1_hand_vector)
           [c1_k]), 1, 4) - 1] = (*chartInstance->c1_prev_vel)[c1_k] -
          (*chartInstance->c1_puck_velocity)[c1_k];
      }

      chartInstance->c1_dataWrittenToVector[1U] = true;
      *chartInstance->c1_e_Puck_HitEventCounter = c1__u32_add__(chartInstance,
        *chartInstance->c1_e_Puck_HitEventCounter, 1U, 0, 45U, 927, 10);
    } else if (*chartInstance->c1_sfEvent == c1_event_e_Trial_Start) {
      chartInstance->c1_JITTransitionAnimation[5U] = 1U;
      *chartInstance->c1_is_CollisionWithHand = c1_IN_NO_ACTIVE_CHILD;
      *chartInstance->c1_is_CollisionWithHand = c1_IN_StartWithSpeed0;
      chartInstance->c1_dataWrittenToVector[21U] = true;
      for (c1_k = 0; c1_k < 2; c1_k++) {
        (*chartInstance->c1_puck_velocity)[c1_k] = 0.0;
        (*chartInstance->c1_puck_offset_position)[c1_k] = 0.0;
      }

      chartInstance->c1_dataWrittenToVector[20U] = true;
    } else {
      for (c1_k = 0; c1_k < 4; c1_k++) {
        (*chartInstance->c1_force_scaling)[c1_k] = 0.0;
      }

      chartInstance->c1_dataWrittenToVector[1U] = true;
      if (!chartInstance->c1_dataWrittenToVector[20U]) {
        sf_read_before_write_error(chartInstance->S, 60U, 4U, 182, 20);
      }

      *chartInstance->c1_target_colliding = c1_check_collision(chartInstance,
        *chartInstance->c1_cursor_vcode_in, *chartInstance->c1_puck_vcode_in,
        *chartInstance->c1_puck_offset_position);
      chartInstance->c1_dataWrittenToVector[4U] = true;
      if (!chartInstance->c1_dataWrittenToVector[4U]) {
        sf_read_before_write_error(chartInstance->S, 66U, 4U, 115, 16);
      }

      sf_mex_printf("%s =\\n", "target_colliding");
      c1_c_y = NULL;
      sf_mex_assign(&c1_c_y, sf_mex_create("y",
        chartInstance->c1_target_colliding, 0, 0U, 0U, 0U, 0), false);
      sf_mex_call(chartInstance->c1_fEmlrtCtx, "disp", 0U, 1U, 14, c1_c_y);
    }
    break;

   default:
    /* Unreachable state, for coverage only */
    *chartInstance->c1_is_CollisionWithHand = c1_IN_NO_ACTIVE_CHILD;
    break;
  }
}

const mxArray *sf_c1_may23_get_eml_resolved_functions_info(void)
{
  const mxArray *c1_nameCaptureInfo = NULL;
  c1_nameCaptureInfo = NULL;
  sf_mex_assign(&c1_nameCaptureInfo, sf_mex_create("nameCaptureInfo", NULL, 0,
    0U, 1U, 0U, 2, 0, 1), false);
  return c1_nameCaptureInfo;
}

static real_T c1_check_collision(SFc1_may23InstanceStruct *chartInstance, real_T
  c1_cursor_vcode[140], real_T c1_puck_vcode[70], real_T c1_puck_offset[2])
{
  real_T c1_colliding_target;
  int32_T c1_k;
  int32_T c1_b_k;
  real_T c1_d;
  real_T c1_z1[2];
  real_T c1_delta_loc[2];
  c1_colliding_target = 0.0;
  c1_k = 0;
  for (c1_b_k = 0; c1_b_k < 2; c1_b_k++) {
    c1_delta_loc[c1_b_k] = c1_cursor_vcode[c1_k + 4] - (c1_puck_vcode[c1_b_k + 2]
      + c1_puck_offset[c1_b_k]);
    c1_z1[c1_b_k] = c1_delta_loc[c1_b_k] * c1_delta_loc[c1_b_k];
    c1_k += 2;
  }

  c1_d = c1_z1[0] + c1_z1[1];
  c1_sqrt(chartInstance, &c1_d);
  if (c1_d < c1_cursor_vcode[18] + c1_puck_vcode[9]) {
    c1_colliding_target = 1.0;
  }

  return c1_colliding_target;
}

static void c1_eject(SFc1_may23InstanceStruct *chartInstance, real_T
                     c1_cursor_vcode[70], real_T c1_puck_vcode[70], real_T
                     c1_puck_offset[2], real_T c1_ejected_puck_offset[2])
{
  int32_T c1_k;
  real_T c1_current_puck_distance;
  real_T c1_z1[2];
  real_T c1_delta_loc[2];
  real_T c1_ejected_puck_distance;
  real_T c1_cursor_loc[2];
  for (c1_k = 0; c1_k < 2; c1_k++) {
    c1_delta_loc[c1_k] = (c1_puck_vcode[c1_k + 2] + c1_puck_offset[c1_k]) -
      c1_cursor_vcode[c1_k + 2];
    c1_z1[c1_k] = c1_delta_loc[c1_k] * c1_delta_loc[c1_k];
    c1_cursor_loc[c1_k] = c1_cursor_vcode[c1_k + 2];
  }

  c1_current_puck_distance = c1_z1[0] + c1_z1[1];
  c1_sqrt(chartInstance, &c1_current_puck_distance);
  c1_ejected_puck_distance = c1_cursor_vcode[9] + c1_puck_vcode[9];
  for (c1_k = 0; c1_k < 2; c1_k++) {
    c1_ejected_puck_offset[c1_k] = (c1_cursor_loc[c1_k] + c1_delta_loc[c1_k] /
      c1_current_puck_distance * c1_ejected_puck_distance) - c1_puck_vcode[c1_k
      + 2];
  }

  chartInstance->c1_dataWrittenToVector[24U] = true;
}

static real_T c1_b_check_collision(SFc1_may23InstanceStruct *chartInstance,
  real_T c1_cursor_vcode[70], real_T c1_puck_vcode[70], real_T c1_puck_offset[2])
{
  real_T c1_colliding_target;
  int32_T c1_k;
  real_T c1_d;
  real_T c1_z1[2];
  real_T c1_delta_loc[2];
  c1_colliding_target = 0.0;
  chartInstance->c1_dataWrittenToVector[23U] = true;
  for (c1_k = 0; c1_k < 2; c1_k++) {
    c1_delta_loc[c1_k] = c1_cursor_vcode[c1_k + 2] - (c1_puck_vcode[c1_k + 2] +
      c1_puck_offset[c1_k]);
    c1_z1[c1_k] = c1_delta_loc[c1_k] * c1_delta_loc[c1_k];
  }

  c1_d = c1_z1[0] + c1_z1[1];
  c1_sqrt(chartInstance, &c1_d);
  if (c1_d < c1_cursor_vcode[9] + c1_puck_vcode[9]) {
    c1_colliding_target = 1.0;
    chartInstance->c1_dataWrittenToVector[23U] = true;
  }

  return c1_colliding_target;
}

static void c1_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_b_force_scaling, const char_T *c1_identifier, real_T c1_y[4])
{
  emlrtMsgIdentifier c1_thisId;
  c1_thisId.fIdentifier = (const char *)c1_identifier;
  c1_thisId.fParent = NULL;
  c1_thisId.bParentIsCell = false;
  c1_b_emlrt_marshallIn(chartInstance, sf_mex_dup(c1_b_force_scaling),
                        &c1_thisId, c1_y);
  sf_mex_destroy(&c1_b_force_scaling);
}

static void c1_b_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId, real_T c1_y[4])
{
  real_T c1_dv[4];
  int32_T c1_i;
  (void)chartInstance;
  sf_mex_import(c1_parentId, sf_mex_dup(c1_u), c1_dv, 1, 0, 0U, 1, 0U, 2, 1, 4);
  for (c1_i = 0; c1_i < 4; c1_i++) {
    c1_y[c1_i] = c1_dv[c1_i];
  }

  sf_mex_destroy(&c1_u);
}

static void c1_c_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_b_puck_vcode_output, const char_T *c1_identifier, real_T c1_y[70])
{
  emlrtMsgIdentifier c1_thisId;
  c1_thisId.fIdentifier = (const char *)c1_identifier;
  c1_thisId.fParent = NULL;
  c1_thisId.bParentIsCell = false;
  c1_d_emlrt_marshallIn(chartInstance, sf_mex_dup(c1_b_puck_vcode_output),
                        &c1_thisId, c1_y);
  sf_mex_destroy(&c1_b_puck_vcode_output);
}

static void c1_d_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId, real_T c1_y[70])
{
  real_T c1_dv[70];
  int32_T c1_i;
  (void)chartInstance;
  sf_mex_import(c1_parentId, sf_mex_dup(c1_u), c1_dv, 1, 0, 0U, 1, 0U, 2, 1, 70);
  for (c1_i = 0; c1_i < 70; c1_i++) {
    c1_y[c1_i] = c1_dv[c1_i];
  }

  sf_mex_destroy(&c1_u);
}

static real_T c1_e_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_b_barrier_colliding, const char_T *c1_identifier)
{
  real_T c1_y;
  emlrtMsgIdentifier c1_thisId;
  c1_thisId.fIdentifier = (const char *)c1_identifier;
  c1_thisId.fParent = NULL;
  c1_thisId.bParentIsCell = false;
  c1_y = c1_f_emlrt_marshallIn(chartInstance, sf_mex_dup(c1_b_barrier_colliding),
    &c1_thisId);
  sf_mex_destroy(&c1_b_barrier_colliding);
  return c1_y;
}

static real_T c1_f_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId)
{
  real_T c1_y;
  real_T c1_d;
  (void)chartInstance;
  sf_mex_import(c1_parentId, sf_mex_dup(c1_u), &c1_d, 1, 0, 0U, 0, 0U, 0);
  c1_y = c1_d;
  sf_mex_destroy(&c1_u);
  return c1_y;
}

static void c1_g_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_b_hand_vector, const char_T *c1_identifier, real_T c1_y[2])
{
  emlrtMsgIdentifier c1_thisId;
  c1_thisId.fIdentifier = (const char *)c1_identifier;
  c1_thisId.fParent = NULL;
  c1_thisId.bParentIsCell = false;
  c1_h_emlrt_marshallIn(chartInstance, sf_mex_dup(c1_b_hand_vector), &c1_thisId,
                        c1_y);
  sf_mex_destroy(&c1_b_hand_vector);
}

static void c1_h_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId, real_T c1_y[2])
{
  real_T c1_dv[2];
  int32_T c1_i;
  (void)chartInstance;
  sf_mex_import(c1_parentId, sf_mex_dup(c1_u), c1_dv, 1, 0, 0U, 1, 0U, 2, 1, 2);
  for (c1_i = 0; c1_i < 2; c1_i++) {
    c1_y[c1_i] = c1_dv[c1_i];
  }

  sf_mex_destroy(&c1_u);
}

static boolean_T c1_i_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_b_e_Puck_Hit, const char_T *c1_identifier)
{
  boolean_T c1_y;
  emlrtMsgIdentifier c1_thisId;
  c1_thisId.fIdentifier = (const char *)c1_identifier;
  c1_thisId.fParent = NULL;
  c1_thisId.bParentIsCell = false;
  c1_y = c1_j_emlrt_marshallIn(chartInstance, sf_mex_dup(c1_b_e_Puck_Hit),
    &c1_thisId);
  sf_mex_destroy(&c1_b_e_Puck_Hit);
  return c1_y;
}

static boolean_T c1_j_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId)
{
  boolean_T c1_y;
  boolean_T c1_b;
  (void)chartInstance;
  sf_mex_import(c1_parentId, sf_mex_dup(c1_u), &c1_b, 1, 11, 0U, 0, 0U, 0);
  c1_y = c1_b;
  sf_mex_destroy(&c1_u);
  return c1_y;
}

static uint32_T c1_k_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_b_e_Puck_HitEventCounter, const char_T *c1_identifier)
{
  uint32_T c1_y;
  emlrtMsgIdentifier c1_thisId;
  c1_thisId.fIdentifier = (const char *)c1_identifier;
  c1_thisId.fParent = NULL;
  c1_thisId.bParentIsCell = false;
  c1_y = c1_l_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c1_b_e_Puck_HitEventCounter), &c1_thisId);
  sf_mex_destroy(&c1_b_e_Puck_HitEventCounter);
  return c1_y;
}

static uint32_T c1_l_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId)
{
  uint32_T c1_y;
  uint32_T c1_b_u;
  (void)chartInstance;
  sf_mex_import(c1_parentId, sf_mex_dup(c1_u), &c1_b_u, 1, 7, 0U, 0, 0U, 0);
  c1_y = c1_b_u;
  sf_mex_destroy(&c1_u);
  return c1_y;
}

static uint8_T c1_m_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_b_is_active_c1_may23, const char_T *c1_identifier)
{
  uint8_T c1_y;
  emlrtMsgIdentifier c1_thisId;
  c1_thisId.fIdentifier = (const char *)c1_identifier;
  c1_thisId.fParent = NULL;
  c1_thisId.bParentIsCell = false;
  c1_y = c1_n_emlrt_marshallIn(chartInstance, sf_mex_dup(c1_b_is_active_c1_may23),
    &c1_thisId);
  sf_mex_destroy(&c1_b_is_active_c1_may23);
  return c1_y;
}

static uint8_T c1_n_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance,
  const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId)
{
  uint8_T c1_y;
  uint8_T c1_b_u;
  (void)chartInstance;
  sf_mex_import(c1_parentId, sf_mex_dup(c1_u), &c1_b_u, 1, 3, 0U, 0, 0U, 0);
  c1_y = c1_b_u;
  sf_mex_destroy(&c1_u);
  return c1_y;
}

static void c1_o_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_b_dataWrittenToVector, const char_T *c1_identifier, boolean_T
  c1_y[25])
{
  emlrtMsgIdentifier c1_thisId;
  c1_thisId.fIdentifier = (const char *)c1_identifier;
  c1_thisId.fParent = NULL;
  c1_thisId.bParentIsCell = false;
  c1_p_emlrt_marshallIn(chartInstance, sf_mex_dup(c1_b_dataWrittenToVector),
                        &c1_thisId, c1_y);
  sf_mex_destroy(&c1_b_dataWrittenToVector);
}

static void c1_p_emlrt_marshallIn(SFc1_may23InstanceStruct *chartInstance, const
  mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId, boolean_T c1_y[25])
{
  boolean_T c1_bv[25];
  int32_T c1_i;
  (void)chartInstance;
  sf_mex_import(c1_parentId, sf_mex_dup(c1_u), c1_bv, 1, 11, 0U, 1, 0U, 1, 25);
  for (c1_i = 0; c1_i < 25; c1_i++) {
    c1_y[c1_i] = c1_bv[c1_i];
  }

  sf_mex_destroy(&c1_u);
}

static const mxArray *c1_q_emlrt_marshallIn(SFc1_may23InstanceStruct
  *chartInstance, const mxArray *c1_b_setSimStateSideEffectsInfo, const char_T
  *c1_identifier)
{
  const mxArray *c1_y = NULL;
  emlrtMsgIdentifier c1_thisId;
  c1_y = NULL;
  c1_thisId.fIdentifier = (const char *)c1_identifier;
  c1_thisId.fParent = NULL;
  c1_thisId.bParentIsCell = false;
  sf_mex_assign(&c1_y, c1_r_emlrt_marshallIn(chartInstance, sf_mex_dup
    (c1_b_setSimStateSideEffectsInfo), &c1_thisId), false);
  sf_mex_destroy(&c1_b_setSimStateSideEffectsInfo);
  return c1_y;
}

static const mxArray *c1_r_emlrt_marshallIn(SFc1_may23InstanceStruct
  *chartInstance, const mxArray *c1_u, const emlrtMsgIdentifier *c1_parentId)
{
  const mxArray *c1_y = NULL;
  (void)chartInstance;
  (void)c1_parentId;
  c1_y = NULL;
  sf_mex_assign(&c1_y, sf_mex_duplicatearraysafe(&c1_u), false);
  sf_mex_destroy(&c1_u);
  return c1_y;
}

static void c1_sqrt(SFc1_may23InstanceStruct *chartInstance, real_T *c1_x)
{
  const mxArray *c1_y = NULL;
  static char_T c1_cv[30] = { 'C', 'o', 'd', 'e', 'r', ':', 't', 'o', 'o', 'l',
    'b', 'o', 'x', ':', 'E', 'l', 'F', 'u', 'n', 'D', 'o', 'm', 'a', 'i', 'n',
    'E', 'r', 'r', 'o', 'r' };

  const mxArray *c1_b_y = NULL;
  const mxArray *c1_c_y = NULL;
  static char_T c1_cv1[4] = { 's', 'q', 'r', 't' };

  if (*c1_x < 0.0) {
    c1_y = NULL;
    sf_mex_assign(&c1_y, sf_mex_create("y", c1_cv, 10, 0U, 1U, 0U, 2, 1, 30),
                  false);
    c1_b_y = NULL;
    sf_mex_assign(&c1_b_y, sf_mex_create("y", c1_cv, 10, 0U, 1U, 0U, 2, 1, 30),
                  false);
    c1_c_y = NULL;
    sf_mex_assign(&c1_c_y, sf_mex_create("y", c1_cv1, 10, 0U, 1U, 0U, 2, 1, 4),
                  false);
    sf_mex_call(chartInstance->c1_fEmlrtCtx, "error", 0U, 2U, 14, c1_y, 14,
                sf_mex_call(chartInstance->c1_fEmlrtCtx, "getString", 1U, 1U, 14,
      sf_mex_call(chartInstance->c1_fEmlrtCtx, "message", 1U, 2U, 14, c1_b_y, 14,
                  c1_c_y)));
  }

  *c1_x = muDoubleScalarSqrt(*c1_x);
}

static uint32_T c1__u32_add__(SFc1_may23InstanceStruct *chartInstance, uint32_T
  c1_b, uint32_T c1_c, int32_T c1_EMLOvCount_src_loc, uint32_T c1_ssid_src_loc,
  int32_T c1_offset_src_loc, int32_T c1_length_src_loc)
{
  uint32_T c1_a;
  (void)c1_EMLOvCount_src_loc;
  c1_a = c1_b + c1_c;
  if (c1_a < c1_b) {
    sf_data_overflow_error(chartInstance->S, c1_ssid_src_loc, c1_offset_src_loc,
      c1_length_src_loc);
  }

  return c1_a;
}

static void init_dsm_address_info(SFc1_may23InstanceStruct *chartInstance)
{
  (void)chartInstance;
}

static void init_simulink_io_address(SFc1_may23InstanceStruct *chartInstance)
{
  chartInstance->c1_e_clk = (int8_T *)(ssGetInputPortSignalPtrs_wrapper
    (chartInstance->S, 8))[0U];
  chartInstance->c1_e_Trial_Start = (int8_T *)(ssGetInputPortSignalPtrs_wrapper
    (chartInstance->S, 8))[1U];
  chartInstance->c1_e_Puck_Stopped = (boolean_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 3);
  chartInstance->c1_e_Puck_Hit = (boolean_T *)ssGetOutputPortSignal_wrapper
    (chartInstance->S, 4);
  chartInstance->c1_fEmlrtCtx = (void *)sfrtGetEmlrtCtx(chartInstance->S);
  chartInstance->c1_e_Puck_StoppedEventCounter = (uint32_T *)ssGetDWork_wrapper
    (chartInstance->S, 0);
  chartInstance->c1_e_Puck_HitEventCounter = (uint32_T *)ssGetDWork_wrapper
    (chartInstance->S, 1);
  chartInstance->c1_sfEvent = (int32_T *)ssGetDWork_wrapper(chartInstance->S, 2);
  chartInstance->c1_is_active_c1_may23 = (uint8_T *)ssGetDWork_wrapper
    (chartInstance->S, 3);
  chartInstance->c1_is_c1_may23 = (uint8_T *)ssGetDWork_wrapper(chartInstance->S,
    4);
  chartInstance->c1_is_active_UpdatePosition = (uint8_T *)ssGetDWork_wrapper
    (chartInstance->S, 5);
  chartInstance->c1_is_CollisionWithHand = (uint8_T *)ssGetDWork_wrapper
    (chartInstance->S, 6);
  chartInstance->c1_is_active_CollisionWithHand = (uint8_T *)ssGetDWork_wrapper
    (chartInstance->S, 7);
  chartInstance->c1_is_active_UpdateVelocity = (uint8_T *)ssGetDWork_wrapper
    (chartInstance->S, 8);
  chartInstance->c1_cursor_vcode_in = (real_T (*)[140])
    ssGetInputPortSignal_wrapper(chartInstance->S, 0);
  chartInstance->c1_puck_vcode_output = (real_T (*)[70])
    ssGetOutputPortSignal_wrapper(chartInstance->S, 1);
  chartInstance->c1_puck_vcode_in = (real_T (*)[70])ssGetInputPortSignal_wrapper
    (chartInstance->S, 1);
  chartInstance->c1_goal_target = (real_T (*)[70])ssGetInputPortSignal_wrapper
    (chartInstance->S, 2);
  chartInstance->c1_display_size = (real_T (*)[2])ssGetInputPortSignal_wrapper
    (chartInstance->S, 3);
  chartInstance->c1_force_scaling = (real_T (*)[4])ssGetOutputPortSignal_wrapper
    (chartInstance->S, 2);
  chartInstance->c1_mass_hand = (real_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 4);
  chartInstance->c1_mass_puck = (real_T *)ssGetInputPortSignal_wrapper
    (chartInstance->S, 5);
  chartInstance->c1_hand_vector = (real_T (*)[2])ssGetDWork_wrapper
    (chartInstance->S, 9);
  chartInstance->c1_prev_vel = (real_T (*)[2])ssGetDWork_wrapper
    (chartInstance->S, 10);
  chartInstance->c1_target_colliding = (real_T *)ssGetDWork_wrapper
    (chartInstance->S, 11);
  chartInstance->c1_hand_vel = (real_T (*)[2])ssGetDWork_wrapper
    (chartInstance->S, 12);
  chartInstance->c1_rect_offset_position = (real_T *)ssGetDWork_wrapper
    (chartInstance->S, 13);
  chartInstance->c1_barrier_colliding = (real_T *)ssGetDWork_wrapper
    (chartInstance->S, 14);
  chartInstance->c1_hand_speed = (real_T (*)[4])ssGetInputPortSignal_wrapper
    (chartInstance->S, 6);
  chartInstance->c1_check_collision_barrier1 = (real_T *)ssGetDWork_wrapper
    (chartInstance->S, 15);
  chartInstance->c1_barrier_vel = (real_T *)ssGetDWork_wrapper(chartInstance->S,
    16);
  chartInstance->c1_force_scaling_barrier = (real_T *)ssGetDWork_wrapper
    (chartInstance->S, 17);
  chartInstance->c1_hand_offset_position = (real_T *)ssGetDWork_wrapper
    (chartInstance->S, 18);
  chartInstance->c1_prev_hand_vel = (real_T *)ssGetDWork_wrapper
    (chartInstance->S, 19);
  chartInstance->c1_rect_left = (real_T *)ssGetDWork_wrapper(chartInstance->S,
    20);
  chartInstance->c1_rect_bottom = (real_T *)ssGetDWork_wrapper(chartInstance->S,
    21);
  chartInstance->c1_goal_right = (real_T *)ssGetDWork_wrapper(chartInstance->S,
    22);
  chartInstance->c1_rect_right = (real_T *)ssGetDWork_wrapper(chartInstance->S,
    23);
  chartInstance->c1_goal_bottom = (real_T *)ssGetDWork_wrapper(chartInstance->S,
    24);
  chartInstance->c1_goal_left = (real_T *)ssGetDWork_wrapper(chartInstance->S,
    25);
  chartInstance->c1_new_hand_posistion_c = (real_T *)ssGetDWork_wrapper
    (chartInstance->S, 26);
  chartInstance->c1_puck_offset_position = (real_T (*)[2])ssGetDWork_wrapper
    (chartInstance->S, 27);
  chartInstance->c1_puck_velocity = (real_T (*)[2])ssGetDWork_wrapper
    (chartInstance->S, 28);
  chartInstance->c1_Trial_Protocol = (real_T (*)[50])
    ssGetInputPortSignal_wrapper(chartInstance->S, 7);
  chartInstance->c1_puck_damping = (real_T *)ssGetDWork_wrapper(chartInstance->S,
    29);
}

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* SFunction Glue Code */
void sf_c1_may23_get_check_sum(mxArray *plhs[])
{
  ((real_T *)mxGetPr((plhs[0])))[0] = (real_T)(3066590595U);
  ((real_T *)mxGetPr((plhs[0])))[1] = (real_T)(2394570794U);
  ((real_T *)mxGetPr((plhs[0])))[2] = (real_T)(4032845074U);
  ((real_T *)mxGetPr((plhs[0])))[3] = (real_T)(4265521403U);
}

mxArray *sf_c1_may23_third_party_uses_info(void)
{
  mxArray * mxcell3p = mxCreateCellMatrix(1,0);
  return(mxcell3p);
}

mxArray *sf_c1_may23_jit_fallback_info(void)
{
  const char *infoFields[] = { "fallbackType", "fallbackReason",
    "hiddenFallbackType", "hiddenFallbackReason", "incompatibleSymbol" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 5, infoFields);
  mxArray *fallbackType = mxCreateString("early");
  mxArray *fallbackReason = mxCreateString("machine_data");
  mxArray *hiddenFallbackType = mxCreateString("");
  mxArray *hiddenFallbackReason = mxCreateString("");
  mxArray *incompatibleSymbol = mxCreateString("");
  mxSetField(mxInfo, 0, infoFields[0], fallbackType);
  mxSetField(mxInfo, 0, infoFields[1], fallbackReason);
  mxSetField(mxInfo, 0, infoFields[2], hiddenFallbackType);
  mxSetField(mxInfo, 0, infoFields[3], hiddenFallbackReason);
  mxSetField(mxInfo, 0, infoFields[4], incompatibleSymbol);
  return mxInfo;
}

mxArray *sf_c1_may23_updateBuildInfo_args_info(void)
{
  mxArray *mxBIArgs = mxCreateCellMatrix(1,0);
  return mxBIArgs;
}

static const mxArray *sf_get_sim_state_info_c1_may23(void)
{
  const char *infoFields[] = { "chartChecksum", "varInfo" };

  mxArray *mxInfo = mxCreateStructMatrix(1, 1, 2, infoFields);
  mxArray *mxVarInfo = sf_mex_decode(
    "eNrN2F9q2zAYAHBndCVpu5D9aSltH0IPMNbtZW8zhEHCGAS2pS8DzZWVRMyxXFn2mrceYUfYUXK"
    "EHWFHyBEmKXaTKIEY2WyfQRgZ5PDz933KZzu13kdHHk057i4cZ1+e63I8chbH42xek+MyOy+u7z"
    "1cb8shphFR12OOe748h95Ez73krhcOmb7/W2d5//0t96+t3L+RXV8c83el1rsDV613V9bvbVn/Z"
    "GV9K5sPGccExdgLaDjKnlP+vP6bx+loT3eH56nhUfMowd9RiplPEEtElIgVT3lX3S21fnZr7brx"
    "OKeEI8yCgPqLWIFxveKF8u/QcB2uuFISwPG0eaE4nRoeNcdjIhNQRymmLESZ7wqEyy3mOjZcx+Y"
    "+kaugxOtbbJ1/I+YF6IYJwSZw8i8q5mkYnkbuCcgQ1L7nFvMcGJ6D3MPpaCwAeebF6uiF4VHzsR"
    "f6iA2HMREoYjEVcpMA4/qFretIu1KCBeNw4nSPN9Zv89QNT33pCUA4fsbW+RaSH0hbVLLFKtsQB"
    "hOfVmzdt0acpCgPEhSPM7DON+2Bkm/zpFBcjgzHUd5/+94kylpUEJ5+Yl0/2gN1v54l9vWj35NI"
    "wDAVUzDvEfZ9HJd/PeD6uLZ9H6c90Pq4+w/WdaQ9UOuob9+fahe0/nT2tZCnZXjUEB4fyRA9fGa"
    "oxnNa8v0utY4PQX2103VppfEp6XGLeZqGp7n0fBIsiohfleeikvjs2hdODM/JWnzepyQUHZaEQn"
    "1YAOHK4tTf4TozXGcbcVq3VZeH7ZL96uL3d8XtmeFTcxojDwuaEoSv0MSbvn4DyPUHF4rbueE6X"
    "3N18m9411SMu/JNA46vlVh/n1z6vkS+J0g/+y8G4fpdnWuQtbbVuC4rqTObvla61goMhCerL5s+"
    "UHq2FlY1rpf/ZD98brjUXOacd82pECT8zAab38H+AlyFS+Y="
    );
  mxArray *mxChecksum = mxCreateDoubleMatrix(1, 4, mxREAL);
  sf_c1_may23_get_check_sum(&mxChecksum);
  mxSetField(mxInfo, 0, infoFields[0], mxChecksum);
  mxSetField(mxInfo, 0, infoFields[1], mxVarInfo);
  return mxInfo;
}

static const char* sf_get_instance_specialization(void)
{
  return "sxnujNqimFT7hyfjS45qMLH";
}

static void sf_opaque_initialize_c1_may23(void *chartInstanceVar)
{
  initialize_params_c1_may23((SFc1_may23InstanceStruct*) chartInstanceVar);
  initialize_c1_may23((SFc1_may23InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_enable_c1_may23(void *chartInstanceVar)
{
  enable_c1_may23((SFc1_may23InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_disable_c1_may23(void *chartInstanceVar)
{
  disable_c1_may23((SFc1_may23InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_gateway_c1_may23(void *chartInstanceVar)
{
  sf_gateway_c1_may23((SFc1_may23InstanceStruct*) chartInstanceVar);
}

static void sf_opaque_ext_mode_exec_c1_may23(void *chartInstanceVar)
{
  ext_mode_exec_c1_may23((SFc1_may23InstanceStruct*) chartInstanceVar);
}

static const mxArray* sf_opaque_get_sim_state_c1_may23(SimStruct* S)
{
  return get_sim_state_c1_may23((SFc1_may23InstanceStruct *)
    sf_get_chart_instance_ptr(S));     /* raw sim ctx */
}

static void sf_opaque_set_sim_state_c1_may23(SimStruct* S, const mxArray *st)
{
  set_sim_state_c1_may23((SFc1_may23InstanceStruct*)sf_get_chart_instance_ptr(S),
    st);
}

static void sf_opaque_terminate_c1_may23(void *chartInstanceVar)
{
  if (chartInstanceVar!=NULL) {
    SimStruct *S = ((SFc1_may23InstanceStruct*) chartInstanceVar)->S;
    if (sim_mode_is_rtw_gen(S) || sim_mode_is_external(S)) {
      sf_clear_rtw_identifier(S);
      unload_may23_optimization_info();
    }

    finalize_c1_may23((SFc1_may23InstanceStruct*) chartInstanceVar);
    utFree(chartInstanceVar);
    if (ssGetUserData(S)!= NULL) {
      sf_free_ChartRunTimeInfo(S);
    }

    ssSetUserData(S,NULL);
  }
}

static void sf_opaque_init_subchart_simstructs(void *chartInstanceVar)
{
  initSimStructsc1_may23((SFc1_may23InstanceStruct*) chartInstanceVar);
}

extern unsigned int sf_machine_global_initializer_called(void);
static void mdlProcessParameters_c1_may23(SimStruct *S)
{
  int i;
  for (i=0;i<ssGetNumRunTimeParams(S);i++) {
    if (ssGetSFcnParamTunable(S,i)) {
      ssUpdateDlgParamAsRunTimeParam(S,i);
    }
  }

  sf_warn_if_symbolic_dimension_param_changed(S);
  if (sf_machine_global_initializer_called()) {
    initialize_params_c1_may23((SFc1_may23InstanceStruct*)
      sf_get_chart_instance_ptr(S));
    initSimStructsc1_may23((SFc1_may23InstanceStruct*)sf_get_chart_instance_ptr
      (S));
  }
}

const char* sf_c1_may23_get_post_codegen_info(void)
{
  int i;
  const char* encStrCodegen [43] = {
    "eNrtnUFv28gVx2kjm9obb6Bud7fBbloYe2lOC++6RfdWbWS7MWrHQuU4lxbcETmSJiY5NGcoyz0",
    "UC/QLtN+gQFGgl97bU/MR+gUK9CPk2ltnRqQtjSiRohhp7DwBikJ5ZjT/eY8/vZl5Iq21w2NLPB",
    "6K55O/W9Z98bohnuvW8PFecrw28hy+f8/6SXL8F1EoiP0mipDPrJmPAPn415hRL+aEBodBh2YWI",
    "0EHRzhwRNmQRnxaa4z4sUeC84M4cGR77GWPOL1Wj8ae+1TURe5J4F2J1sKYN0U7eyTCDj/A2OW9",
    "iMbd3oGHutc9jvhlo4edcxb7syQwzFtxKLvFjmOPk9DD+wPsHAaMI9FjdtO3FkccN/hgqkyplLX",
    "SgtQPPYKCTLU9xFo4FAPM8YvQFf+exFyI0os5PRTxp7iH+pgdkXPVJg2w3iZh4g9tEiBOI4K8fd",
    "9ryIqTfWt6oj/H1MXejAERfXsaYXQeUhLw6fZvHQil+wFqe3gPt+Pu9NZa+CKWxj8j+BJHU8et0",
    "6B9HKEuPgmmfqgakP2Bsta1l0wW48THZyj6xhH2Y9id6r3Cc1gLCTvhU1FjWjGsRB6y04j0xfBO",
    "bS32D6Vn5p0ysT80Nssrplrb7+NZVrhu7cAJGsjz2NRipzQ8wn3sqVb3EEeziw1bzS4XRjREXeG",
    "1rhhk6eINGrhkwhZOzDj1G8Ld9o6OngtSZHfupthhwHHUQQ7OOm+Z08Nu7GEhVJCJq4/LaNQlTF",
    "orp1Ri07xSFuvEwd4ljc6F0Bmn/Y0EaYOpBX3WFaMvfPcFE24+q5gc/dxyKed3rBvObxXgfFpPf",
    "30y0s5aRjvWyKssXx8pv7k+Xn5T+9z19L30MaWdD7TPvae1I8vVxNP77YM/uf/72y//+Z/ds79u",
    "/OP3+jjo/Vmb6M/aje4fzfc9+TA5fpwC6dpd+xNeIss+G+nXvYz2fzjSfi05ZoMgfvX8gvgHpz/",
    "vXXVetX76s4vjo2eqvcHj2f39XOtv+v62JONVqDjHIufQTb7A5TGKh19rsv2vR/p7P2c8NpP3h4",
    "83v1iofv2srvtD1nh9oI2XPO7QyME2c5CIH7qaX69Mj9WoF7H/9zU98jiMnXO77wii2HQ0NKhG1",
    "0Z9ofqvL0rraqMoIjiyHep5xB3ayhhdO1Eh/3ug6XowoqufhFZG6NmOCtnpkabnkeKaQNrQSkx8",
    "OdqJvi+N0FUvputjTdfHOidSVabY61tW2v+6FHl2m3IRhpjjf2ExPZuans1Uj4c7RnGvXkzP+5q",
    "e91M9Een2uEF63hQ7jz7S9HykpnWBa9NOR8ye7ZAyFUEbo+vPTunzSOnqY0fMpM2x03fORP0sPR",
    "uano0bPZ4ROv7ISvtbgC9tpUU6G5PeZjvG2KfGSsetYYT7dmokU/RYZ6X9Tekxxd/exIXssqXp2",
    "Erjbxf5YRKiGqGnGZc+f5QeU3n9Oi5//qh5EvaoQ/iVMfOI8nGcXNA2Lo7bLh/HKT2mxXHf/ar0",
    "eaT0mHoeNcvHp0qXafHp698U0lPT9MgnR1FXmOh6maEaPY8WnN/1S9sH201JumekUvssqKdeTM9",
    "DTc/DGz0tTsNQbtBUo+dxJfbJ48Inmp5PxuyjNmwaNJZ7GYboSuzUzNH1qabr0wk7jWurzg+3F4",
    "xXi62zf6jp+1DtO9rI4aSPbedL20dXX+0apOu/TiG7fabp+mxMVyNdw3tJeO+ZmGmYo68Wl16fv",
    "NE33D9vJt/FRuj6d3W6zpLQthpdn1dynpWJa4WusRPMCD3J+VUmDhR6Mk+sanR9sRQe/kDTJY+F",
    "z6GXEeEcB6f0LHsdbN591rWS9SyoB/WWUG+tZB7FRsl690rWW18w32NZ+tZL5pPMW35nBt8srXx",
    "tgc952+Uf/WF2PsePtfFN5x81UbiPoudoInUtzfKYzE3sBno63CWN3CMcdHlv9N02QRnZWsyjGQ",
    "3jQXZSYstBHnb3aNz28FiqYujhwXi75HcZ/WVXfpt6xGmN/bVN+EvijvdW9kHlNb4IPYrcsXFoT",
    "bRN2EmILuKJd08x402Z9DjyLm2/yhjfEOmfr1LPMHMiEqZLQskjkumxfXxK5eAj76T9SnyrWiKq",
    "Q54tOhFj25UJZjZxB2PvkmsZLHKOxB+0dn00aPGIBN0x473NeV7efsB9rV15HIvh3P0qO98s73X",
    "R+Gcnp76l1a/681dXv1Y3of9l+VzVelKZ9YBh2mu+/y93PN/8q4r6Ze1RdD4x77oY8AR4YgJPiq",
    "63A0+q5Une+f89rb48Zh01loXqv6fVl8cJPoAfwI/C/vq2uJO1b/mNWvxVP99Sjg6cqH5fpww3Z",
    "NzxNXBjyb+fWLT+3eRGVh6U+snpIRviA+KLSvepgBfAi7sWZyhepMEG8VzgRfV5CMAN4MYyuPFt",
    "jp/taPXk8THtyx/Anao0SeHDgTvMZ3DVuz3sfzHpzxCXLIcz8+abAGeAM8vgTC/Hz3a1eruFODM",
    "9PxHimmp487byR4E7wJ13kTsQ5yxvPjWa/wy8Ad7c9vnUqD8DZ1a3zpt1nYcy+Shukt24Cr7Uc+",
    "qva/VrI+dn8p/63dhf3r7T+SlF/bdMnovaaZbZpR7kpRTlQN51L4AjwJFVcGRRvwV+LCceKXq9g",
    "tvGkXc3v+1uxx9F/RX4sbr4Y/Q6bxB/AEduS/wx6rfAj9XtL8+6rhXEIcCPZfCjar8FniyHJ/Ne",
    "5x14AjwxgSfz+i3wZHX7wrPuRwA8AZ6YwJN5/RZ4srr936z7tQBHgCOm7vdm+SvwYznxyLz3EQK",
    "OAEdMiEfm9VvgyerWX2fdTwl4Ajwxdf11lt8CT5Yzvyl6XyngCHDEhPlNUX8FfiyHH0Xv2wT8AH",
    "6YwI+i/gr8WN36atZ97IAfwA9T11ez/BX4sRx+FL1fNvAD+GHq9aKz/BX4sTp+ZN3PFPgB/DCVH",
    "1n+CvxY3fxF8RzmL8CPWzJ/yfJX4Mfq1k+VPWD9FPhxS9ZPs/wV+LG6fJAAXw63w+SmOpO76rYD",
    "HAGOmJ4PMstvgSer40ko72Z2R/LL6hZcL+Bd5cssPwa+rDDfTNqln1zcErgCXLFuWf5Zhv8CT5b",
    "Dky2t/lZqDxf5YfITbJj3AD9M4UdRfwV+VMOP9PXJSDtrOefTvOX/DzbV0ys=",
    ""
  };

  static char newstr [3137] = "";
  newstr[0] = '\0';
  for (i = 0; i < 43; i++) {
    strcat(newstr, encStrCodegen[i]);
  }

  return newstr;
}

static void mdlSetWorkWidths_c1_may23(SimStruct *S)
{
  const char* newstr = sf_c1_may23_get_post_codegen_info();
  sf_set_work_widths(S, newstr);
  ssSetChecksum0(S,(2433441132U));
  ssSetChecksum1(S,(1202256228U));
  ssSetChecksum2(S,(1446239673U));
  ssSetChecksum3(S,(2125990053U));
}

static void mdlRTW_c1_may23(SimStruct *S)
{
  if (sim_mode_is_rtw_gen(S)) {
    ssWriteRTWStrParam(S, "StateflowChartType", "Stateflow");
  }
}

static void mdlStart_c1_may23(SimStruct *S)
{
  SFc1_may23InstanceStruct *chartInstance;
  chartInstance = (SFc1_may23InstanceStruct *)utMalloc(sizeof
    (SFc1_may23InstanceStruct));
  if (chartInstance==NULL) {
    sf_mex_error_message("Could not allocate memory for chart instance.");
  }

  memset(chartInstance, 0, sizeof(SFc1_may23InstanceStruct));
  chartInstance->chartInfo.chartInstance = chartInstance;
  chartInstance->chartInfo.isEMLChart = 0;
  chartInstance->chartInfo.chartInitialized = 0;
  chartInstance->chartInfo.sFunctionGateway = sf_opaque_gateway_c1_may23;
  chartInstance->chartInfo.initializeChart = sf_opaque_initialize_c1_may23;
  chartInstance->chartInfo.terminateChart = sf_opaque_terminate_c1_may23;
  chartInstance->chartInfo.enableChart = sf_opaque_enable_c1_may23;
  chartInstance->chartInfo.disableChart = sf_opaque_disable_c1_may23;
  chartInstance->chartInfo.getSimState = sf_opaque_get_sim_state_c1_may23;
  chartInstance->chartInfo.setSimState = sf_opaque_set_sim_state_c1_may23;
  chartInstance->chartInfo.getSimStateInfo = sf_get_sim_state_info_c1_may23;
  chartInstance->chartInfo.zeroCrossings = NULL;
  chartInstance->chartInfo.outputs = NULL;
  chartInstance->chartInfo.derivatives = NULL;
  chartInstance->chartInfo.mdlRTW = mdlRTW_c1_may23;
  chartInstance->chartInfo.mdlStart = mdlStart_c1_may23;
  chartInstance->chartInfo.mdlSetWorkWidths = mdlSetWorkWidths_c1_may23;
  chartInstance->chartInfo.callGetHoverDataForMsg = NULL;
  chartInstance->chartInfo.extModeExec = sf_opaque_ext_mode_exec_c1_may23;
  chartInstance->chartInfo.restoreLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.restoreBeforeLastMajorStepConfiguration = NULL;
  chartInstance->chartInfo.storeCurrentConfiguration = NULL;
  chartInstance->chartInfo.callAtomicSubchartUserFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartAutoFcn = NULL;
  chartInstance->chartInfo.callAtomicSubchartEventFcn = NULL;
  chartInstance->S = S;
  chartInstance->chartInfo.dispatchToExportedFcn = NULL;
  sf_init_ChartRunTimeInfo(S, &(chartInstance->chartInfo), false, 0,
    chartInstance->c1_JITStateAnimation,
    chartInstance->c1_JITTransitionAnimation);
  init_dsm_address_info(chartInstance);
  init_simulink_io_address(chartInstance);
  if (!sim_mode_is_rtw_gen(S)) {
  }

  mdl_start_c1_may23(chartInstance);
}

void c1_may23_method_dispatcher(SimStruct *S, int_T method, void *data)
{
  switch (method) {
   case SS_CALL_MDL_START:
    mdlStart_c1_may23(S);
    break;

   case SS_CALL_MDL_SET_WORK_WIDTHS:
    mdlSetWorkWidths_c1_may23(S);
    break;

   case SS_CALL_MDL_PROCESS_PARAMETERS:
    mdlProcessParameters_c1_may23(S);
    break;

   default:
    /* Unhandled method */
    sf_mex_error_message("Stateflow Internal Error:\n"
                         "Error calling c1_may23_method_dispatcher.\n"
                         "Can't handle method %d.\n", method);
    break;
  }
}
