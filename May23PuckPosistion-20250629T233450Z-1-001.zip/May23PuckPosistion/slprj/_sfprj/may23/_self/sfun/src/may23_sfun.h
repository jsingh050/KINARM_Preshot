#ifndef __may23_sfun_h__
#define __may23_sfun_h__

/* Include files */
#define S_FUNCTION_NAME                sf_sfun
#include "covrt.h"
#include "sf_runtime/sfc_sf.h"
#include "sf_runtime/MessageServiceLayer.h"
#include "sf_runtime/DebuggerRuntimeInterface.h"
#include "sf_runtime/sfc_mex.h"
#include "sf_runtime/sf_runtime_errors.h"
#include "sf_runtime/sf_partitioning_execution_bridge.h"
#include "rtwtypes.h"
#include "simtarget/slSimTgtClientServerAPIBridge.h"
#include "sf_runtime/sfc_sdi.h"
#include "sf_runtime/sf_test_language.h"
#include "simlogCIntrf.h"
#include "multiword_types.h"
#include "sf_runtime/sfc_messages.h"
#define rtInf                          (mxGetInf())
#define rtMinusInf                     (-(mxGetInf()))
#define rtNaN                          (mxGetNaN())
#define rtInfF                         ((real32_T)mxGetInf())
#define rtMinusInfF                    (-(real32_T)mxGetInf())
#define rtNaNF                         ((real32_T)mxGetNaN())
#define rtIsNaN(X)                     ((int)mxIsNaN(X))
#define rtIsInf(X)                     ((int)mxIsInf(X))

/* Type Definitions */

/* Named Constants */

/* Variable Declarations */
extern real_T col_x;
extern real_T col_y;
extern real_T SECONDS;
extern real_T E_NO_EVENT;
extern real_T WIDTH;
extern real_T HEIGHT;
extern real_T ROTATION;
extern real_T FORCE_MULTIPLIER;
extern real_T LOAD_ROW;
extern real_T F_BUMP;
extern real_T MASS_CIRCLE;
extern real_T MASS_RECT;
extern real_T PERT_RAMP;
extern real_T PERT_DUR;
extern real_T START_ROW;
extern real_T GOAL_ROW;
extern real_T RADIUS_LOG;
extern real_T RADIUS_VIS;
extern real_T BARRIER_ROW;
extern real_T PRESHOT_ROW;
extern real_T START_HOLD_TIME;
extern real_T SHOT_READY_TIME;
extern real_T SHOT_SET_TIME;
extern real_T GOAL_TIME;
extern real_T FIRST_FILL;
extern real_T SECOND_FILL;
extern real_T THIRD_FILL;
extern real_T PUCK_ROW;
extern real_T CURSOR_ROW;
extern real_T E_START_TARGET_ON;
extern real_T E_ENTER_START;
extern real_T E_TRIAL_START;
extern real_T E_BEGIN_PRESHOT;
extern real_T E_SHOT_READY;
extern real_T E_SHOT_GO;
extern real_T E_PUCK_IN_GOAL;
extern real_T E_HAND_IN_BARRIER;
extern real_T E_PUCK_IN_BARRIER;
extern real_T E_SUCCESS;
extern real_T E_FAILURE;
extern real_T E_TIMEOUT;
extern real_T STROKE_COLOR;
extern real_T STROKE_WIDTH;
extern real_T PUCK_DAMPING;
extern real_T E_PUCK_MISS;
extern real_T SHOT_TIME;

/* Variable Definitions */

/* Function Declarations */
extern void may23_initializer(void);
extern void may23_terminator(void);

/* Function Definitions */

/* We load infoStruct for rtw_optimation_info on demand in mdlSetWorkWidths and
   free it immediately in mdlStart. Given that this is machine-wide as
   opposed to chart specific, we use NULL check to make sure it gets loaded
   and unloaded once per machine even though the  methods mdlSetWorkWidths/mdlStart
   are chart/instance specific. The following methods abstract this out. */
extern mxArray* load_may23_optimization_info(boolean_T isRtwGen, boolean_T
  isModelRef, boolean_T isExternal);
extern void unload_may23_optimization_info(void);

#endif
