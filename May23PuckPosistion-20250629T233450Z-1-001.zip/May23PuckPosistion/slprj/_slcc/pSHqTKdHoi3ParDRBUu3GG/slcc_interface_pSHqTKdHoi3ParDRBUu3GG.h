#include "customcode_pSHqTKdHoi3ParDRBUu3GG.h"
#ifdef __cplusplus
extern "C" {
#endif


/* Type Definitions */

/* Named Constants */

/* Variable Declarations */

/* Variable Definitions */

/* Function Declarations */
DLL_EXPORT_CC extern const char_T *get_dll_checksum_pSHqTKdHoi3ParDRBUu3GG(void);
DLL_EXPORT_CC extern real32_T crc32C_pSHqTKdHoi3ParDRBUu3GG(real32_T *packet, int32_T packet_size);
DLL_EXPORT_CC extern void buildOutputPacket_pSHqTKdHoi3ParDRBUu3GG(real32_T *dest, real32_T *src, int32_T packetSize, real32_T queueLen, real32_T total_timeouts, real32_T runID);
DLL_EXPORT_CC extern void recordPacket_pSHqTKdHoi3ParDRBUu3GG(real32_T *dest, int32_T dest_size, real32_T *src, int32_T src_size);

/* Function Definitions */
DLL_EXPORT_CC const uint8_T *get_checksum_source_info(int32_T *size);
#ifdef __cplusplus
}
#endif

