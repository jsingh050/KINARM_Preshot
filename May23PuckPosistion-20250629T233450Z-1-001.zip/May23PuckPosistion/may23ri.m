function ri = may23ri

ri = [];

